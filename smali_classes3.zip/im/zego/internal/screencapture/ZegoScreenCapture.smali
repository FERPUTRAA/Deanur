.class public Lim/zego/internal/screencapture/ZegoScreenCapture;
.super Ljava/lang/Object;


# static fields
.field private static mThis:J


# instance fields
.field private final callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

.field private capturing:Z

.field private componentCallbacks:Landroid/content/ComponentCallbacks;

.field private final context:Landroid/content/Context;

.field private display:Landroid/view/Display;

.field private final factory:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;

.field private final mediaProjection:Landroid/media/projection/MediaProjection;

.field private final publishChannel:I

.field private rotation:I


# direct methods
.method public constructor <init>(Landroid/content/Context;Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;Landroid/media/projection/MediaProjection;ILim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "context",
            "factory",
            "mediaProjection",
            "publishChannel",
            "callback"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    iput-object p1, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->context:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p3, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->mediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p2, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->factory:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p4, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->publishChannel:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p5, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$000(Lim/zego/internal/screencapture/ZegoScreenCapture;)Landroid/view/Display;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "cys~l@~~o./b~~~ ii@oos@~~of~@ o@~@@4~@ n @ ~@ ~m @~t@@~rM  1u ~~ib~ ~t@dv@  K/lo~~@@ @fbS~   a@-"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->display:Landroid/view/Display;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$100(Lim/zego/internal/screencapture/ZegoScreenCapture;)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    iget p0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->rotation:I

    const/4 v0, 0x3

    move v1, v0

    return p0
.end method

.method static synthetic access$102(Lim/zego/internal/screencapture/ZegoScreenCapture;I)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->rotation:I

    return p1
.end method

.method static synthetic access$200(Lim/zego/internal/screencapture/ZegoScreenCapture;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Lim/zego/internal/screencapture/ZegoScreenCapture;->updateCaptureResolution()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic access$300(Lim/zego/internal/screencapture/ZegoScreenCapture;)Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget-object p0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic access$400()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    sget-wide v0, Lim/zego/internal/screencapture/ZegoScreenCapture;->mThis:J

    const/4 v2, 0x0

    move v3, v2

    return-wide v0
.end method

.method private initCapture()Z
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->display:Landroid/view/Display;

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-interface {v0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_CAPTURE_START_REPEATED()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    sget-wide v0, Lim/zego/internal/screencapture/ZegoScreenCapture;->mThis:J

    const/4 v4, 0x4

    const/4 v2, 0x6

    const/4 v4, 0x7

    or-int/2addr v3, v2

    const/4 v4, 0x4

    invoke-static {v0, v1, v2}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    return v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->context:Landroid/content/Context;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v1, "siwmnw"

    const-string/jumbo v1, "insdww"

    const/4 v4, 0x3

    const-string v1, "dnwwoo"

    const-string/jumbo v1, "window"

    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    check-cast v0, Landroid/view/WindowManager;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {v0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->display:Landroid/view/Display;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v0, -0x1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->rotation:I

    const/4 v3, 0x7

    move v4, v3

    invoke-direct {p0}, Lim/zego/internal/screencapture/ZegoScreenCapture;->updateCaptureResolution()V

    const/4 v4, 0x3

    const/4 v3, 0x6

    new-instance v0, Lim/zego/internal/screencapture/ZegoScreenCapture$1;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {v0, p0}, Lim/zego/internal/screencapture/ZegoScreenCapture$1;-><init>(Lim/zego/internal/screencapture/ZegoScreenCapture;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->componentCallbacks:Landroid/content/ComponentCallbacks;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v1, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->context:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1, v0}, Landroid/content/Context;->registerComponentCallbacks(Landroid/content/ComponentCallbacks;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    return v0
.end method

.method private static native setCaptureResolution(III)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "width",
            "height",
            "idx"
        }
    .end annotation
.end method

.method private updateCaptureResolution()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    new-instance v0, Landroid/util/DisplayMetrics;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {v0}, Landroid/util/DisplayMetrics;-><init>()V

    const/4 v4, 0x2

    iget-object v1, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->display:Landroid/view/Display;

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Landroid/view/Display;->getRealMetrics(Landroid/util/DisplayMetrics;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget v1, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget v0, v0, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v2, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->publishChannel:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v1, v0, v2}, Lim/zego/internal/screencapture/ZegoScreenCapture;->setCaptureResolution(III)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method


# virtual methods
.method public setThis(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "pThis"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    sput-wide p1, Lim/zego/internal/screencapture/ZegoScreenCapture;->mThis:J

    const/4 v1, 0x3

    const/4 v0, 0x7

    return-void
.end method

.method public startCapture()Z
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {p0}, Lim/zego/internal/screencapture/ZegoScreenCapture;->initCapture()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x5

    return v1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->factory:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-nez v0, :cond_1

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-interface {v0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_VIDEO_EXTERNAL_FACTORY()V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget-wide v2, Lim/zego/internal/screencapture/ZegoScreenCapture;->mThis:J

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/16 v0, 0x8

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v2, v3, v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v4, 0x5

    const/4 v5, 0x6

    return v1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v1, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->mediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->setMediaProjection(Landroid/media/projection/MediaProjection;)V

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x0

    shl-int/2addr v4, v0

    const/4 v5, 0x1

    iput-boolean v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->capturing:Z

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    return v0
.end method

.method public stopCapture()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x5

    move v4, v3

    iput-boolean v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->capturing:Z

    const/4 v4, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->factory:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;->setMediaProjection(Landroid/media/projection/MediaProjection;)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->componentCallbacks:Landroid/content/ComponentCallbacks;

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    iget-object v2, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->context:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x1

    invoke-virtual {v2, v0}, Landroid/content/Context;->unregisterComponentCallbacks(Landroid/content/ComponentCallbacks;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object v1, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->componentCallbacks:Landroid/content/ComponentCallbacks;

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->display:Landroid/view/Display;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object v1, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->display:Landroid/view/Display;

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void
.end method

.method public updateVideoConfig(Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "captureVideo"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-boolean v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->capturing:Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Lim/zego/internal/screencapture/ZegoScreenCapture;->startCapture()Z

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-nez p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-boolean p1, p0, Lim/zego/internal/screencapture/ZegoScreenCapture;->capturing:Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Lim/zego/internal/screencapture/ZegoScreenCapture;->stopCapture()V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method
