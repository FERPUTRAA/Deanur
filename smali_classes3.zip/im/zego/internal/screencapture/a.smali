.class public final synthetic Lim/zego/internal/screencapture/a;
.super Ljava/lang/Object;


# direct methods
.method public static synthetic a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ns ~~K~f/f@~om~.v@@as  ~iy~ ~ @ ~lt~bc~@@@@@ o @~ ti1~/  oo~@@l @~u~@o~@~b-S @o r @ d@~~@i4@bM~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    new-instance v0, Landroid/media/AudioPlaybackCaptureConfiguration$Builder;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method
