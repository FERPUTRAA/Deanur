.class public Lim/zego/internal/screencapture/ZegoScreenCaptureManager;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lim/zego/internal/screencapture/ZegoScreenCaptureManager$ZegoScreenCaptureAssistantActivity;
    }
.end annotation


# static fields
.field private static final instance:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

.field private static mThis:J


# instance fields
.field private audioCapture:Lim/zego/internal/screencapture/ZegoAudioCapture;

.field private captureAudio:Z

.field private captureVideo:Z

.field private channels:I

.field private connection:Landroid/content/ServiceConnection;

.field private context:Landroid/content/Context;

.field private eventHandler:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

.field private factory:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;

.field private mediaProjection:Landroid/media/projection/MediaProjection;

.field private publishChannel:I

.field private sampleRate:I

.field private screenCapture:Lim/zego/internal/screencapture/ZegoScreenCapture;

.field private sourceAudio:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    sput-object v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->instance:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->publishChannel:I

    const/4 v1, 0x3

    move v2, v1

    return-void
.end method

.method public static native OnScreenCaptureExceptionOccurredNative(JI)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "pThis",
            "exception"
        }
    .end annotation
.end method

.method static synthetic access$000(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)Landroid/content/Context;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@dso@o @ @oo @@~~n i~.a~ @~b @@@/~~ c~K4~~@ ~~@ ~~@t~@  yM1@~@S  @ uib@/ r@~ o-@~~~~tl~m iovsflf"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->context:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic access$100(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iget-object p0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->eventHandler:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic access$200()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    sget-wide v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mThis:J

    const/4 v3, 0x0

    return-wide v0
.end method

.method static synthetic access$300()Lim/zego/internal/screencapture/ZegoScreenCaptureManager;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->instance:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic access$400(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)Landroid/content/ServiceConnection;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iget-object p0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->connection:Landroid/content/ServiceConnection;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$500(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;Landroid/media/projection/MediaProjection;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->setMediaProjection(Landroid/media/projection/MediaProjection;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public static destroyScreenCapture()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    sget-object v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->instance:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget v1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->publishChannel:I

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x4

    invoke-static {v2, v1}, Lcom/zego/zegoavkit2/ZegoExternalVideoCapture;->setVideoCaptureFactory(Lcom/zego/zegoavkit2/ZegoVideoCaptureFactory;I)Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-boolean v1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->sourceAudio:Z

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->stopCapture()V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-void
.end method

.method public static setAudioCaptureFactory(Landroid/content/Context;IZ)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "context",
            "channel",
            "sourceAudio"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->instance:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v3, 0x2

    if-eqz v1, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->publishChannel:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eq v1, p1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->eventHandler:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v3, 0x6

    if-eqz p0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {p0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_CAPTURE_START_REPEATED()V

    :cond_1
    const/4 v3, 0x4

    sget-wide p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mThis:J

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 p2, 0x6

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, p1, p2}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v3, 0x3

    return-void

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput-object p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->context:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput p1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->publishChannel:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-boolean p2, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->sourceAudio:Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->audioCapture:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz p0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->updateMediaConfig()V

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public static setEventHandler(Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "handler"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->instance:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v2, 0x6

    const/4 v1, 0x1

    iput-object p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->eventHandler:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method private setMediaProjection(Landroid/media/projection/MediaProjection;)V
    .locals 10
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "projection"
        }
    .end annotation

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    iput-object p1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v8, 0x7

    shl-int/2addr v9, v8

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->screenCapture:Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-nez v0, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    new-instance v0, Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget-object v2, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->context:Landroid/content/Context;

    const/4 v9, 0x7

    iget-object v3, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->factory:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget v5, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->publishChannel:I

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    iget-object v6, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->eventHandler:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-direct/range {v1 .. v6}, Lim/zego/internal/screencapture/ZegoScreenCapture;-><init>(Landroid/content/Context;Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;Landroid/media/projection/MediaProjection;ILim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;)V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    iput-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->screenCapture:Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    sget-wide v1, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mThis:J

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v0, v1, v2}, Lim/zego/internal/screencapture/ZegoScreenCapture;->setThis(J)V

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x3

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->audioCapture:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-nez v0, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance v0, Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v8, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v2, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->context:Landroid/content/Context;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget v3, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->channels:I

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget v4, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->sampleRate:I

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget v6, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->publishChannel:I

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v7, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->eventHandler:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-direct/range {v1 .. v7}, Lim/zego/internal/screencapture/ZegoAudioCapture;-><init>(Landroid/content/Context;IILandroid/media/projection/MediaProjection;ILim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;)V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    iput-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->audioCapture:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v9, 0x4

    const/4 v8, 0x3

    sget-wide v1, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mThis:J

    const/4 v9, 0x2

    invoke-virtual {v0, v1, v2}, Lim/zego/internal/screencapture/ZegoAudioCapture;->setThis(J)V

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-direct {p0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->updateMediaConfig()V

    const/4 v9, 0x2

    const/4 v8, 0x6

    return-void
.end method

.method public static setVideoCaptureFactory(Landroid/content/Context;I)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "context",
            "channel"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-nez p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-void

    :cond_0
    const/4 v4, 0x0

    sget-object v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->instance:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v4, 0x3

    if-eqz v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget v1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->publishChannel:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eq v1, p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->eventHandler:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v4, 0x7

    const/4 v3, 0x1

    if-eqz p0, :cond_1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-interface {p0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_CAPTURE_START_REPEATED()V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    sget-wide p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mThis:J

    const/4 v4, 0x0

    const/4 v0, 0x6

    const/4 v4, 0x0

    move v3, v0

    move v3, v0

    const/4 v4, 0x5

    invoke-static {p0, p1, v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget v1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->publishChannel:I

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eq v1, p1, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x7

    iget-object v2, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->factory:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-eqz v2, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v2, v1}, Lcom/zego/zegoavkit2/ZegoExternalVideoCapture;->setVideoCaptureFactory(Lcom/zego/zegoavkit2/ZegoVideoCaptureFactory;I)Z

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->factory:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;

    const/4 v4, 0x2

    if-nez v1, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v1, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v1, p0}, Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-object v1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->factory:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;

    :cond_4
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->factory:Lcom/zego/zegoavkit2/screencapture/ZegoScreenCaptureFactory;

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v1, p1}, Lcom/zego/zegoavkit2/ZegoExternalVideoCapture;->setVideoCaptureFactory(Lcom/zego/zegoavkit2/ZegoVideoCaptureFactory;I)Z

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-object p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->context:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput p1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->publishChannel:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    iget-object p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->screenCapture:Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v4, 0x6

    if-eqz p0, :cond_5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0}, Lim/zego/internal/screencapture/ZegoScreenCapture;->stopCapture()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->updateMediaConfig()V

    :cond_5
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method private startCapture()V
    .locals 6
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v5, 0x5

    new-instance v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$1;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {v0, p0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$1;-><init>(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)V

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->connection:Landroid/content/ServiceConnection;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->context:Landroid/content/Context;

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-class v2, Lim/zego/internal/screencapture/ZegoScreenCaptureService;

    const-class v2, Lim/zego/internal/screencapture/ZegoScreenCaptureService;

    const/4 v5, 0x4

    const-class v2, Lim/zego/internal/screencapture/ZegoScreenCaptureService;

    const-class v2, Lim/zego/internal/screencapture/ZegoScreenCaptureService;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v0, v1, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->context:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x7

    iget-object v2, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->connection:Landroid/content/ServiceConnection;

    const/4 v5, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x5

    const/4 v3, 0x1

    const/4 v5, 0x5

    invoke-virtual {v1, v0, v2, v3}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-void
.end method

.method public static startScreenCapture(Landroid/content/Context;Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Integer;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "context",
            "captureVideo",
            "captureAudio",
            "sampleRate",
            "channels"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->instance:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v3, 0x1

    const/4 v2, 0x1

    iget-object v1, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v2, 0x4

    or-int/2addr v3, v2

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->eventHandler:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-interface {p0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_CAPTURE_START_REPEATED()V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-wide p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mThis:J

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 p2, 0x6

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0, p1, p2}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->context:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-boolean p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->captureVideo:Z

    const/4 v3, 0x0

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-boolean p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->captureAudio:Z

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->sampleRate:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p4}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->channels:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->startCapture()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method private stopCapture()V
    .locals 5
    .annotation build Landroid/annotation/TargetApi;
        value = 0x15
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->connection:Landroid/content/ServiceConnection;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x1

    move v4, v3

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v2, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->context:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v2, v0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-object v1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->connection:Landroid/content/ServiceConnection;

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->screenCapture:Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Lim/zego/internal/screencapture/ZegoScreenCapture;->stopCapture()V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object v1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->screenCapture:Lim/zego/internal/screencapture/ZegoScreenCapture;

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->audioCapture:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v3, 0x5

    move v4, v3

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->stopCapture()V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput-object v1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->audioCapture:Lim/zego/internal/screencapture/ZegoAudioCapture;

    :cond_2
    const/4 v4, 0x7

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz v0, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Landroid/media/projection/MediaProjection;->stop()V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-object v1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mediaProjection:Landroid/media/projection/MediaProjection;

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method

.method public static stopScreenCapture()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->instance:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->stopCapture()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method private updateMediaConfig()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->audioCapture:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v0, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->screenCapture:Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v5, 0x0

    if-nez v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_2

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/16 v2, 0x1d

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-lt v1, v2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-boolean v1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->captureAudio:Z

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-boolean v1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->sourceAudio:Z

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v5, 0x2

    iget v2, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->sampleRate:I

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v3, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->channels:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lim/zego/internal/screencapture/ZegoAudioCapture;->updateAudioConfig(ZII)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->eventHandler:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v0, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-interface {v0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_AUDIO_SYSTEM_NOT_SUPPORTED()V

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    sget-wide v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mThis:J

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v2, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v0, v1, v2}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->screenCapture:Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-boolean v1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->captureVideo:Z

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Lim/zego/internal/screencapture/ZegoScreenCapture;->updateVideoConfig(Z)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void

    :cond_4
    :goto_2
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->eventHandler:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v5, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_5

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-interface {v0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_NOT_START_CAPTURE()V

    :cond_5
    const/4 v5, 0x7

    sget-wide v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mThis:J

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v0, v1, v2}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-void
.end method

.method public static updateScreenCaptureConfig(Ljava/lang/Boolean;Ljava/lang/Boolean;Ljava/lang/Integer;Ljava/lang/Integer;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "captureVideo",
            "captureAudio",
            "sampleRate",
            "channels"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->instance:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-boolean p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->captureVideo:Z

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-boolean p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->captureAudio:Z

    const/4 v1, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->sampleRate:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p3}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput p0, v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->channels:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->updateMediaConfig()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public setThis(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "pThis"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    sput-wide p1, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->mThis:J

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method
