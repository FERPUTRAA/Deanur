.class public Lim/zego/internal/screencapture/ZegoAudioCapture;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;
    }
.end annotation


# static fields
.field private static mThis:J


# instance fields
.field private audioRecord:Landroid/media/AudioRecord;

.field private audioThread:Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;

.field private byteBuffer:Ljava/nio/ByteBuffer;

.field private final callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

.field private capturing:Z

.field private channels:I

.field private final context:Landroid/content/Context;

.field private final mediaProjection:Landroid/media/projection/MediaProjection;

.field private final publishChannel:I

.field private sampleRate:I


# direct methods
.method public constructor <init>(Landroid/content/Context;IILandroid/media/projection/MediaProjection;ILim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "context",
            "channels",
            "sampleRate",
            "mediaProjection",
            "publishChannel",
            "callback"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->context:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p4, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->mediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p2, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->channels:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p3, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->sampleRate:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p5, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->publishChannel:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p6, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v1, 0x0

    const/4 v0, 0x6

    return-void
.end method

.method static synthetic access$000(Lim/zego/internal/screencapture/ZegoAudioCapture;)Landroid/media/AudioRecord;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->audioRecord:Landroid/media/AudioRecord;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic access$100(Lim/zego/internal/screencapture/ZegoAudioCapture;)Ljava/nio/ByteBuffer;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget-object p0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$200(Lim/zego/internal/screencapture/ZegoAudioCapture;)I
    .locals 2

    const/4 v1, 0x3

    iget p0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->publishChannel:I

    const/4 v0, 0x6

    move v1, v0

    return p0
.end method

.method static synthetic access$300(Lim/zego/internal/screencapture/ZegoAudioCapture;)I
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    iget p0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->sampleRate:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic access$400(Lim/zego/internal/screencapture/ZegoAudioCapture;)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    iget p0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->channels:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return p0
.end method

.method public static native initCapture(I)I
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "publish_channel_index"
        }
    .end annotation
.end method

.method public static native onRecordAudioFrame(ILjava/nio/ByteBuffer;III)I
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "publish_channel_index",
            "buffer",
            "bufLen",
            "sampleRate",
            "channels"
        }
    .end annotation
.end method

.method private releaseAudio()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->audioRecord:Landroid/media/AudioRecord;

    const/4 v2, 0x3

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/media/AudioRecord;->stop()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->audioRecord:Landroid/media/AudioRecord;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Landroid/media/AudioRecord;->release()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->audioRecord:Landroid/media/AudioRecord;

    :cond_0
    const/4 v1, 0x5

    move v2, v1

    return-void
.end method

.method public static native startCapture(I)I
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "publish_channel_index"
        }
    .end annotation
.end method

.method public static native stopCapture(I)I
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "publish_channel_index"
        }
    .end annotation
.end method


# virtual methods
.method public initCapture()Z
    .locals 10
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1d
    .end annotation

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->context:Landroid/content/Context;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string v1, "UissDR.aIrCOAOnrdRn_Eodo.sieDip"

    const-string v1, "android.permission.RECORD_AUDIO"

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Landroid/content/Context;->checkSelfPermission(Ljava/lang/String;)I

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    const/4 v2, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-eqz v0, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-interface {v0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_AUDIO_RECORD_PERMISSION_DENIED()V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    sget-wide v3, Lim/zego/internal/screencapture/ZegoAudioCapture;->mThis:J

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {v3, v4, v1}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    return v2

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->audioRecord:Landroid/media/AudioRecord;

    const/4 v9, 0x5

    const/4 v8, 0x2

    if-eqz v0, :cond_1

    const/4 v8, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-interface {v0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_CAPTURE_START_REPEATED()V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    sget-wide v0, Lim/zego/internal/screencapture/ZegoAudioCapture;->mThis:J

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/4 v3, 0x6

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {v0, v1, v3}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    return v2

    :cond_1
    const/4 v8, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->channels:I

    const/4 v9, 0x1

    const/4 v3, 0x2

    const/4 v9, 0x0

    move v8, v3

    move v8, v3

    const/4 v9, 0x3

    if-nez v0, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    iput v3, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->channels:I

    :cond_2
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->sampleRate:I

    const/4 v8, 0x2

    xor-int/2addr v9, v8

    if-nez v0, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    const/16 v0, 0x3e80

    const/4 v9, 0x1

    const/4 v8, 0x2

    iput v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->sampleRate:I

    :cond_3
    const/4 v8, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->channels:I

    const/4 v8, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-ne v0, v3, :cond_4

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    const/16 v0, 0xc

    const/4 v9, 0x6

    const/4 v8, 0x0

    goto :goto_0

    :cond_4
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    const/16 v0, 0x10

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    iget v4, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->sampleRate:I

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {v4, v0, v3}, Landroid/media/AudioRecord;->getMinBufferSize(III)I

    move-result v4

    const/4 v9, 0x7

    if-gez v4, :cond_5

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-interface {v0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_SYSTEM_EXCEPTION()V

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    sget-wide v0, Lim/zego/internal/screencapture/ZegoAudioCapture;->mThis:J

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    const/16 v3, 0x9

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {v0, v1, v3}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    return v2

    :cond_5
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    mul-int/2addr v4, v3

    const/4 v9, 0x1

    invoke-static {v4}, Ljava/nio/ByteBuffer;->allocateDirect(I)Ljava/nio/ByteBuffer;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    iput-object v5, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->byteBuffer:Ljava/nio/ByteBuffer;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v5}, Ljava/nio/ByteBuffer;->hasArray()Z

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x0

    if-nez v5, :cond_6

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-interface {v0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_AUDIO_CREATED_READ_BUFFER()V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    sget-wide v3, Lim/zego/internal/screencapture/ZegoAudioCapture;->mThis:J

    const/4 v8, 0x0

    move v9, v8

    invoke-static {v3, v4, v1}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    return v2

    :cond_6
    const/4 v9, 0x2

    invoke-static {}, Lim/zego/internal/screencapture/a;->a()V

    const/4 v9, 0x3

    const/4 v8, 0x1

    iget-object v5, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->mediaProjection:Landroid/media/projection/MediaProjection;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static {v5}, Lcom/tencent/liteav/audio/e;->a(Landroid/media/projection/MediaProjection;)Landroid/media/AudioPlaybackCaptureConfiguration$Builder;

    move-result-object v5

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    const/4 v6, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v5, v6}, Lcom/tencent/liteav/audio/a;->a(Landroid/media/AudioPlaybackCaptureConfiguration$Builder;I)Landroid/media/AudioPlaybackCaptureConfiguration$Builder;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/16 v7, 0xe

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {v5, v7}, Lcom/tencent/liteav/audio/a;->a(Landroid/media/AudioPlaybackCaptureConfiguration$Builder;I)Landroid/media/AudioPlaybackCaptureConfiguration$Builder;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-static {v5, v2}, Lcom/tencent/liteav/audio/a;->a(Landroid/media/AudioPlaybackCaptureConfiguration$Builder;I)Landroid/media/AudioPlaybackCaptureConfiguration$Builder;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v5}, Lcom/tencent/liteav/audio/b;->a(Landroid/media/AudioPlaybackCaptureConfiguration$Builder;)Landroid/media/AudioPlaybackCaptureConfiguration;

    move-result-object v5

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    new-instance v7, Landroid/media/AudioFormat$Builder;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-direct {v7}, Landroid/media/AudioFormat$Builder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v7, v3}, Landroid/media/AudioFormat$Builder;->setEncoding(I)Landroid/media/AudioFormat$Builder;

    const/4 v8, 0x1

    move v9, v8

    iget v3, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->sampleRate:I

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v7, v3}, Landroid/media/AudioFormat$Builder;->setSampleRate(I)Landroid/media/AudioFormat$Builder;

    const/4 v8, 0x1

    move v9, v8

    invoke-virtual {v7, v0}, Landroid/media/AudioFormat$Builder;->setChannelMask(I)Landroid/media/AudioFormat$Builder;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v7}, Landroid/media/AudioFormat$Builder;->build()Landroid/media/AudioFormat;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    new-instance v3, Landroid/media/AudioRecord$Builder;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-direct {v3}, Landroid/media/AudioRecord$Builder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v3, v0}, Landroid/media/AudioRecord$Builder;->setAudioFormat(Landroid/media/AudioFormat;)Landroid/media/AudioRecord$Builder;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {v3, v5}, Lcom/tencent/liteav/audio/c;->a(Landroid/media/AudioRecord$Builder;Landroid/media/AudioPlaybackCaptureConfiguration;)Landroid/media/AudioRecord$Builder;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v3, v4}, Landroid/media/AudioRecord$Builder;->setBufferSizeInBytes(I)Landroid/media/AudioRecord$Builder;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v3}, Landroid/media/AudioRecord$Builder;->build()Landroid/media/AudioRecord;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    iput-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->audioRecord:Landroid/media/AudioRecord;

    const/4 v9, 0x7

    const/4 v8, 0x0

    if-eqz v0, :cond_8

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getState()I

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eq v0, v6, :cond_7

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_1

    :cond_7
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    return v6

    :cond_8
    :goto_1
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-interface {v0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_AUDIO_RECORD_BUILD()V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    sget-wide v3, Lim/zego/internal/screencapture/ZegoAudioCapture;->mThis:J

    const/4 v9, 0x1

    invoke-static {v3, v4, v1}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-direct {p0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->releaseAudio()V

    const/4 v8, 0x6

    move v9, v8

    return v2
.end method

.method public setThis(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "pThis"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    sput-wide p1, Lim/zego/internal/screencapture/ZegoAudioCapture;->mThis:J

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public startCapture()Z
    .locals 6
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1d
    .end annotation

    const/4 v4, 0x5

    move v5, v4

    invoke-virtual {p0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->initCapture()Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    return v1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 v0, 0x3

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v2, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->audioRecord:Landroid/media/AudioRecord;

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v2}, Landroid/media/AudioRecord;->startRecording()V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    iget-object v2, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->audioRecord:Landroid/media/AudioRecord;

    const/4 v5, 0x6

    invoke-virtual {v2}, Landroid/media/AudioRecord;->getRecordingState()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eq v2, v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v2, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-interface {v2}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_AUDIO_RECORD_BUILD()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    sget-wide v2, Lim/zego/internal/screencapture/ZegoAudioCapture;->mThis:J

    const/4 v4, 0x4

    move v5, v4

    invoke-static {v2, v3, v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    return v1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->publishChannel:I

    const/4 v5, 0x6

    invoke-static {v0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->initCapture(I)I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->publishChannel:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->startCapture(I)I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string v1, "dosgdieorrAeadTcZRueo"

    const/4 v5, 0x5

    const-string v1, "adomorehTeeiduZrAcdgR"

    const-string v1, "ZegoAudioRecordThread"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v0, p0, v1}, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;-><init>(Lim/zego/internal/screencapture/ZegoAudioCapture;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iput-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->audioThread:Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v5, 0x4

    shl-int/2addr v4, v0

    const/4 v5, 0x0

    iput-boolean v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->capturing:Z

    const/4 v5, 0x2

    const/4 v4, 0x4

    return v0

    :catch_0
    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v2, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->callback:Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {v2}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_AUDIO_RECORD_BUILD()V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    sget-wide v2, Lim/zego/internal/screencapture/ZegoAudioCapture;->mThis:J

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v2, v3, v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    return v1
.end method

.method public stopCapture()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-boolean v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->capturing:Z

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->publishChannel:I

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->stopCapture(I)I

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->audioThread:Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->stopThread()V

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->audioThread:Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-wide/16 v1, 0x1f4

    const-wide/16 v1, 0x1f4

    const/4 v4, 0x7

    const-wide/16 v1, 0x1f4

    const-wide/16 v1, 0x1f4

    const/4 v3, 0x0

    xor-int/2addr v4, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/Thread;->join(J)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->audioThread:Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-direct {p0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->releaseAudio()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void
.end method

.method public updateAudioConfig(ZII)V
    .locals 3
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1d
    .end annotation

    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "captureAudio",
            "sampleRate",
            "channels"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-boolean v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->capturing:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->startCapture()Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    if-nez p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-boolean v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->capturing:Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->stopCapture()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    return-void

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x7

    if-eqz p1, :cond_3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget p1, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->sampleRate:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-ne p2, p1, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget p1, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->channels:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-ne p3, p1, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x4

    return-void

    :cond_2
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->stopCapture()V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput p2, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->sampleRate:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput p3, p0, Lim/zego/internal/screencapture/ZegoAudioCapture;->channels:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->startCapture()Z

    :cond_3
    const/4 v2, 0x2

    const/4 v1, 0x0

    return-void
.end method
