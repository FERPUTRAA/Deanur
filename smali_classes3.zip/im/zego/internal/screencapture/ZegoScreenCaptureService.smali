.class public Lim/zego/internal/screencapture/ZegoScreenCaptureService;
.super Landroid/app/Service;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x15
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lim/zego/internal/screencapture/ZegoScreenCaptureService$ZegoScreenCaptureLocalBinder;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method private createNotificationChannel()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " ~s@@@o~lo@@~@ df@@ ~-~v~~@n@@4@~~@@f/~bS ~s~~ ~@    @m~~tta   1@oio~.ioMol yc  b~ ~@/~br@~i~K@ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    new-instance v0, Landroid/app/Notification$Builder;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {v0, v1}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x1

    move v6, v5

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v2, "isnmndfattoocii"

    const-string/jumbo v2, "iisinocfoittadn"

    const/4 v6, 0x1

    const-string/jumbo v2, "noioodiif_iantc"

    const-string/jumbo v2, "notification_id"

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/16 v3, 0x1a

    const/4 v6, 0x5

    if-lt v1, v3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v0, v2}, Landroidx/browser/trusted/i;->a(Landroid/app/Notification$Builder;Ljava/lang/String;)Landroid/app/Notification$Builder;

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-lt v1, v3, :cond_1

    const/4 v5, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo v1, "iacombniontt"

    const-string/jumbo v1, "focmnoinatit"

    const/4 v6, 0x3

    const-string/jumbo v1, "iotannuoicfi"

    const-string/jumbo v1, "notification"

    const/4 v6, 0x5

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    check-cast v1, Landroid/app/NotificationManager;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string/jumbo v3, "oeimnnaptoafni_to"

    const-string v3, "emn_oinatioofntac"

    const/4 v6, 0x0

    const-string/jumbo v3, "neim_notqfaitnico"

    const-string/jumbo v3, "notification_name"

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v4, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v2, v3, v4}, Landroidx/browser/trusted/j;->a(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/app/NotificationChannel;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {v1, v2}, Landroidx/browser/trusted/e;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    iput v1, v0, Landroid/app/Notification;->defaults:I

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/16 v1, 0x6e

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p0, v1, v0}, Landroid/app/Service;->startForeground(ILandroid/app/Notification;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "intent"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Lim/zego/internal/screencapture/ZegoScreenCaptureService;->createNotificationChannel()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance p1, Lim/zego/internal/screencapture/ZegoScreenCaptureService$ZegoScreenCaptureLocalBinder;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p1, p0, v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureService$ZegoScreenCaptureLocalBinder;-><init>(Lim/zego/internal/screencapture/ZegoScreenCaptureService;Lim/zego/internal/screencapture/ZegoScreenCaptureService$1;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p1
.end method

.method public onUnbind(Landroid/content/Intent;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "intent"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/app/Service;->stopForeground(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-super {p0, p1}, Landroid/app/Service;->onUnbind(Landroid/content/Intent;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p1
.end method
