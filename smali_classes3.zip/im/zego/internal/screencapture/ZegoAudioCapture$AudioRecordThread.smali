.class Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;
.super Ljava/lang/Thread;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lim/zego/internal/screencapture/ZegoAudioCapture;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "AudioRecordThread"
.end annotation


# instance fields
.field private volatile keepAlive:Z

.field final synthetic this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;


# direct methods
.method public constructor <init>(Lim/zego/internal/screencapture/ZegoAudioCapture;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x0
        }
        names = {
            "this$0",
            "name"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p2}, Ljava/lang/Thread;-><init>(Ljava/lang/String;)V

    const/4 v0, 0x4

    move v1, v0

    const/4 p1, 0x1

    move v1, p1

    const/4 v0, 0x3

    shl-int/2addr v1, v0

    iput-boolean p1, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->keepAlive:Z

    const/4 v0, 0x1

    or-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "ios@~@o~ 4@@Md  ~-@K@  i~@yl @tt~~@of@ ~~ ~l@@/c  s~~~ n ~ o~v~ab1m@@u .@f ~o~~/@ori@ ~~@~bS~ b@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->access$000(Lim/zego/internal/screencapture/ZegoAudioCapture;)Landroid/media/AudioRecord;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/media/AudioRecord;->getRecordingState()I

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v1, 0x3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eq v0, v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    return-void

    :cond_0
    :goto_0
    const/4 v6, 0x5

    iget-boolean v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->keepAlive:Z

    const/4 v5, 0x2

    move v6, v5

    if-eqz v0, :cond_2

    const/4 v6, 0x1

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->access$000(Lim/zego/internal/screencapture/ZegoAudioCapture;)Landroid/media/AudioRecord;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v1}, Lim/zego/internal/screencapture/ZegoAudioCapture;->access$100(Lim/zego/internal/screencapture/ZegoAudioCapture;)Ljava/nio/ByteBuffer;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v2, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v2}, Lim/zego/internal/screencapture/ZegoAudioCapture;->access$100(Lim/zego/internal/screencapture/ZegoAudioCapture;)Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/nio/Buffer;->capacity()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/media/AudioRecord;->read(Ljava/nio/ByteBuffer;I)I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-lez v0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-boolean v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->keepAlive:Z

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->access$200(Lim/zego/internal/screencapture/ZegoAudioCapture;)I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v1, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v1}, Lim/zego/internal/screencapture/ZegoAudioCapture;->access$100(Lim/zego/internal/screencapture/ZegoAudioCapture;)Ljava/nio/ByteBuffer;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v2, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v2}, Lim/zego/internal/screencapture/ZegoAudioCapture;->access$100(Lim/zego/internal/screencapture/ZegoAudioCapture;)Ljava/nio/ByteBuffer;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/nio/Buffer;->capacity()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v3, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v6, 0x2

    const/4 v5, 0x4

    invoke-static {v3}, Lim/zego/internal/screencapture/ZegoAudioCapture;->access$300(Lim/zego/internal/screencapture/ZegoAudioCapture;)I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v4, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v4}, Lim/zego/internal/screencapture/ZegoAudioCapture;->access$400(Lim/zego/internal/screencapture/ZegoAudioCapture;)I

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v0, v1, v2, v3, v4}, Lim/zego/internal/screencapture/ZegoAudioCapture;->onRecordAudioFrame(ILjava/nio/ByteBuffer;III)I

    const/4 v6, 0x1

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v1, -0x3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-ne v0, v1, :cond_0

    const/4 v6, 0x4

    const/4 v0, 0x0

    const/4 v6, 0x6

    move v5, v0

    move v5, v0

    const/4 v6, 0x7

    iput-boolean v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->keepAlive:Z

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto/16 :goto_0

    :cond_2
    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->access$000(Lim/zego/internal/screencapture/ZegoAudioCapture;)Landroid/media/AudioRecord;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->this$0:Lim/zego/internal/screencapture/ZegoAudioCapture;

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-static {v0}, Lim/zego/internal/screencapture/ZegoAudioCapture;->access$000(Lim/zego/internal/screencapture/ZegoAudioCapture;)Landroid/media/AudioRecord;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroid/media/AudioRecord;->stop()V
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-void
.end method

.method public stopThread()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x6

    iput-boolean v0, p0, Lim/zego/internal/screencapture/ZegoAudioCapture$AudioRecordThread;->keepAlive:Z

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method
