.class public Lim/zego/internal/screencapture/ZegoScreenCaptureManager$ZegoScreenCaptureAssistantActivity;
.super Landroid/app/Activity;


# annotations
.annotation build Landroid/annotation/TargetApi;
    value = 0x15
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lim/zego/internal/screencapture/ZegoScreenCaptureManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "ZegoScreenCaptureAssistantActivity"
.end annotation


# instance fields
.field private final REQUEST_CODE:I

.field private projectionManager:Landroid/media/projection/MediaProjectionManager;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/16 v0, 0x3e9

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$ZegoScreenCaptureAssistantActivity;->REQUEST_CODE:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected onActivityResult(IILandroid/content/Intent;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "requestCode",
            "resultCode",
            "intent"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b@sloa@d ~@~4y@ @@~i@n1o~@f~.-biot io~f~@ ~@@ oK ~@~~   @@~b~@~u  @~ m~@@@~s@~//~vrSl t  ~~M co~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-super {p0, p1, p2, p3}, Landroid/app/Activity;->onActivityResult(IILandroid/content/Intent;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$300()Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {v0}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$400(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)Landroid/content/ServiceConnection;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-static {}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$300()Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p1}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$100(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$300()Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p1}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$100(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-interface {p1}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_FOREGROUND_SERVICE()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    invoke-static {}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$200()J

    move-result-wide p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 p3, 0x7

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p1, p2, p3}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    const/16 v0, 0x3e9

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-ne p1, v0, :cond_2

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 p1, -0x5

    const/4 p1, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-ne p2, p1, :cond_2

    iget-object p1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$ZegoScreenCaptureAssistantActivity;->projectionManager:Landroid/media/projection/MediaProjectionManager;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1, p2, p3}, Landroid/media/projection/MediaProjectionManager;->getMediaProjection(ILandroid/content/Intent;)Landroid/media/projection/MediaProjection;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$300()Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p2, p1}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$500(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;Landroid/media/projection/MediaProjection;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    goto :goto_0

    :cond_2
    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$300()Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p1}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$100(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p1, :cond_3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$300()Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p1}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$100(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {p1}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_MEDIA_PROJECTION_PERMISSION_DENIED()V

    :cond_3
    invoke-static {}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$200()J

    move-result-wide p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 p3, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p1, p2, p3}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method protected onCreate(Landroid/os/Bundle;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "savedInstanceState"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 p1, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Landroid/app/Activity;->requestWindowFeature(I)Z

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string/jumbo p1, "picmertdmnjoio_s"

    const-string/jumbo p1, "nisip_teojamrdco"

    const/4 v2, 0x0

    const-string p1, "damroocneiiptoej"

    const-string/jumbo p1, "media_projection"

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, p1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    check-cast p1, Landroid/media/projection/MediaProjectionManager;

    const/4 v2, 0x7

    iput-object p1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$ZegoScreenCaptureAssistantActivity;->projectionManager:Landroid/media/projection/MediaProjectionManager;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/media/projection/MediaProjectionManager;->createScreenCaptureIntent()Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/16 v0, 0x3e9

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Landroid/app/Activity;->startActivityForResult(Landroid/content/Intent;I)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method
