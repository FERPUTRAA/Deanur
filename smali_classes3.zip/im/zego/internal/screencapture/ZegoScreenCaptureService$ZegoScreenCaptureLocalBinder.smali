.class Lim/zego/internal/screencapture/ZegoScreenCaptureService$ZegoScreenCaptureLocalBinder;
.super Landroid/os/Binder;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lim/zego/internal/screencapture/ZegoScreenCaptureService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "ZegoScreenCaptureLocalBinder"
.end annotation


# instance fields
.field final synthetic this$0:Lim/zego/internal/screencapture/ZegoScreenCaptureService;


# direct methods
.method private constructor <init>(Lim/zego/internal/screencapture/ZegoScreenCaptureService;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureService$ZegoScreenCaptureLocalBinder;->this$0:Lim/zego/internal/screencapture/ZegoScreenCaptureService;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method synthetic constructor <init>(Lim/zego/internal/screencapture/ZegoScreenCaptureService;Lim/zego/internal/screencapture/ZegoScreenCaptureService$1;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lim/zego/internal/screencapture/ZegoScreenCaptureService$ZegoScreenCaptureLocalBinder;-><init>(Lim/zego/internal/screencapture/ZegoScreenCaptureService;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public getService()Lim/zego/internal/screencapture/ZegoScreenCaptureService;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "bssalt@  ~@~n  m@ ~@l f-~@@c~ ~4~@ @~@~o~~u.S @~t@ Ky~d @~@b@iMoo@oi@r  ~~@ @ ~@~~o1// ~bf~v io@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureService$ZegoScreenCaptureLocalBinder;->this$0:Lim/zego/internal/screencapture/ZegoScreenCaptureService;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method
