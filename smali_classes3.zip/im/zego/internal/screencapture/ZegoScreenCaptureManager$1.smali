.class Lim/zego/internal/screencapture/ZegoScreenCaptureManager$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->startCapture()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;


# direct methods
.method constructor <init>(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$1;->this$0:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "name",
            "service"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@os ~to@i@1f@.- K/4m~b dn~uo s/@@~ r~~a@~~  ~  @ oS~c@t~@M ~@b@@~@lli~@@  v@ob@~i ~@o~f~ y  ~~~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    new-instance p1, Landroid/content/Intent;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object p2, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$1;->this$0:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v2, 0x3

    invoke-static {p2}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$000(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-class v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$ZegoScreenCaptureAssistantActivity;

    const-class v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$ZegoScreenCaptureAssistantActivity;

    const/4 v2, 0x3

    const-class v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$ZegoScreenCaptureAssistantActivity;

    const-class v0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$ZegoScreenCaptureAssistantActivity;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p1, p2, v0}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/high16 p2, 0x10000000

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1, p2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object p2, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$1;->this$0:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p2}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$000(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p2, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object p1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$1;->this$0:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p1}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$100(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object p1, p0, Lim/zego/internal/screencapture/ZegoScreenCaptureManager$1;->this$0:Lim/zego/internal/screencapture/ZegoScreenCaptureManager;

    const/4 v3, 0x6

    invoke-static {p1}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$100(Lim/zego/internal/screencapture/ZegoScreenCaptureManager;)Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    move-result-object p1

    const/4 v2, 0x2

    move v3, v2

    invoke-interface {p1}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_FOREGROUND_SERVICE()V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->access$200()J

    move-result-wide v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p1, 0x7

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0, v1, p1}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method
