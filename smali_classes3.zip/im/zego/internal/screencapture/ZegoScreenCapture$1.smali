.class Lim/zego/internal/screencapture/ZegoScreenCapture$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ComponentCallbacks;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/internal/screencapture/ZegoScreenCapture;->initCapture()Z
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic this$0:Lim/zego/internal/screencapture/ZegoScreenCapture;


# direct methods
.method constructor <init>(Lim/zego/internal/screencapture/ZegoScreenCapture;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8010
        }
        names = {
            "this$0"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lim/zego/internal/screencapture/ZegoScreenCapture$1;->this$0:Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v1, 0x3

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onConfigurationChanged(Landroid/content/res/Configuration;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "newConfig"
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object p1, p0, Lim/zego/internal/screencapture/ZegoScreenCapture$1;->this$0:Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1}, Lim/zego/internal/screencapture/ZegoScreenCapture;->access$000(Lim/zego/internal/screencapture/ZegoScreenCapture;)Landroid/view/Display;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/view/Display;->getRotation()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture$1;->this$0:Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v0}, Lim/zego/internal/screencapture/ZegoScreenCapture;->access$100(Lim/zego/internal/screencapture/ZegoScreenCapture;)I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-ne p1, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture$1;->this$0:Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lim/zego/internal/screencapture/ZegoScreenCapture;->access$102(Lim/zego/internal/screencapture/ZegoScreenCapture;I)I

    const/4 v2, 0x1

    iget-object p1, p0, Lim/zego/internal/screencapture/ZegoScreenCapture$1;->this$0:Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p1}, Lim/zego/internal/screencapture/ZegoScreenCapture;->access$200(Lim/zego/internal/screencapture/ZegoScreenCapture;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public onLowMemory()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v0, p0, Lim/zego/internal/screencapture/ZegoScreenCapture$1;->this$0:Lim/zego/internal/screencapture/ZegoScreenCapture;

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v0}, Lim/zego/internal/screencapture/ZegoScreenCapture;->access$300(Lim/zego/internal/screencapture/ZegoScreenCapture;)Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {v0}, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;->ERROR_SYSTEM_EXCEPTION()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {}, Lim/zego/internal/screencapture/ZegoScreenCapture;->access$400()J

    move-result-wide v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/16 v2, 0x9

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v0, v1, v2}, Lim/zego/internal/screencapture/ZegoScreenCaptureManager;->OnScreenCaptureExceptionOccurredNative(JI)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method
