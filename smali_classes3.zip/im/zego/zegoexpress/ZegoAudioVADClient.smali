.class public abstract Lim/zego/zegoexpress/ZegoAudioVADClient;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public abstract reset()Z
.end method

.method public abstract update(Ljava/nio/ByteBuffer;III)Lim/zego/zegoexpress/constants/ZegoAudioVADType;
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "dataLength",
            "sampleRate",
            "channels"
        }
    .end annotation
.end method
