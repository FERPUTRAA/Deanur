.class public Lim/zego/zegoexpress/entity/ZegoEngineConfig;
.super Ljava/lang/Object;


# instance fields
.field public advancedConfig:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public logConfig:Lim/zego/zegoexpress/entity/ZegoLogConfig;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public soFullPath:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoEngineConfig;->advancedConfig:Ljava/util/HashMap;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Lim/zego/zegoexpress/entity/ZegoLogConfig;

    const/4 v1, 0x2

    and-int/2addr v2, v1

    invoke-direct {v0}, Lim/zego/zegoexpress/entity/ZegoLogConfig;-><init>()V

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoEngineConfig;->logConfig:Lim/zego/zegoexpress/entity/ZegoLogConfig;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoEngineConfig;->soFullPath:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-void
.end method
