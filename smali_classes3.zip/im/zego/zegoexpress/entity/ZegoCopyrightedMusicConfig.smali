.class public Lim/zego/zegoexpress/entity/ZegoCopyrightedMusicConfig;
.super Ljava/lang/Object;


# instance fields
.field public user:Lim/zego/zegoexpress/entity/ZegoUser;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    or-int/2addr v1, v0

    return-void
.end method
