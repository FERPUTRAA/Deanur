.class public Lim/zego/zegoexpress/entity/ZegoRoomConfig;
.super Ljava/lang/Object;


# instance fields
.field public isUserStatusNotify:Z

.field public maxMemberCount:I

.field public token:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoRoomConfig;->maxMemberCount:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-boolean v0, p0, Lim/zego/zegoexpress/entity/ZegoRoomConfig;->isUserStatusNotify:Z

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoRoomConfig;->token:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method
