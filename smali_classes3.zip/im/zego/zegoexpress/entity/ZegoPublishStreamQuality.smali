.class public Lim/zego/zegoexpress/entity/ZegoPublishStreamQuality;
.super Ljava/lang/Object;


# instance fields
.field public audioCaptureFPS:D

.field public audioKBPS:D

.field public audioSendBytes:D

.field public audioSendFPS:D

.field public isHardwareEncode:Z

.field public level:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

.field public packetLostRate:D

.field public rtt:I

.field public totalSendBytes:D

.field public videoCaptureFPS:D

.field public videoCodecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

.field public videoEncodeFPS:D

.field public videoKBPS:D

.field public videoSendBytes:D

.field public videoSendFPS:D


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method
