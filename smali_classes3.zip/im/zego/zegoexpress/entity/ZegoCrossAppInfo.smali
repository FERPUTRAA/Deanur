.class public Lim/zego/zegoexpress/entity/ZegoCrossAppInfo;
.super Ljava/lang/Object;


# instance fields
.field public appID:J

.field public token:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method
