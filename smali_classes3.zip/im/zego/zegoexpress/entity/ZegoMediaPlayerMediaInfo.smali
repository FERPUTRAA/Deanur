.class public Lim/zego/zegoexpress/entity/ZegoMediaPlayerMediaInfo;
.super Ljava/lang/Object;


# instance fields
.field public frameRate:I

.field public height:I

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMediaPlayerMediaInfo;->width:I

    const/4 v1, 0x2

    move v2, v1

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMediaPlayerMediaInfo;->height:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMediaPlayerMediaInfo;->frameRate:I

    const/4 v1, 0x1

    shl-int/2addr v2, v1

    return-void
.end method
