.class public Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;
.super Ljava/lang/Object;


# instance fields
.field public bitrate:I

.field public encodeLatency:I

.field public encodeProfile:Lim/zego/zegoexpress/constants/ZegoEncodeProfile;

.field public videoCodecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v3, 0x6

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->videoCodecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->bitrate:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    sget-object v1, Lim/zego/zegoexpress/constants/ZegoEncodeProfile;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoEncodeProfile;

    const/4 v3, 0x7

    const/4 v2, 0x0

    iput-object v1, p0, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->encodeProfile:Lim/zego/zegoexpress/constants/ZegoEncodeProfile;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->encodeLatency:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method public constructor <init>(Lim/zego/zegoexpress/constants/ZegoVideoCodecID;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "codecID",
            "bitrate"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->videoCodecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->bitrate:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoEncodeProfile;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoEncodeProfile;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->encodeProfile:Lim/zego/zegoexpress/constants/ZegoEncodeProfile;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x1

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->encodeLatency:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    return-void
.end method

.method public constructor <init>(Lim/zego/zegoexpress/constants/ZegoVideoCodecID;ILim/zego/zegoexpress/constants/ZegoEncodeProfile;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "codecID",
            "bitrate",
            "profile",
            "encodeLatency"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->videoCodecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v1, 0x0

    const/4 v0, 0x0

    iput p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->bitrate:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p3, p0, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->encodeProfile:Lim/zego/zegoexpress/constants/ZegoEncodeProfile;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p4, p0, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->encodeLatency:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method
