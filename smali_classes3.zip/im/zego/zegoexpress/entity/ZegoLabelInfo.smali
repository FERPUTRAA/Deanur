.class public Lim/zego/zegoexpress/entity/ZegoLabelInfo;
.super Ljava/lang/Object;


# instance fields
.field public font:Lim/zego/zegoexpress/entity/ZegoFontStyle;

.field public left:I

.field public text:Ljava/lang/String;

.field public top:I


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "text"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoLabelInfo;->text:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x7

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoLabelInfo;->left:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoLabelInfo;->top:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    new-instance p1, Lim/zego/zegoexpress/entity/ZegoFontStyle;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p1}, Lim/zego/zegoexpress/entity/ZegoFontStyle;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoLabelInfo;->font:Lim/zego/zegoexpress/entity/ZegoFontStyle;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method
