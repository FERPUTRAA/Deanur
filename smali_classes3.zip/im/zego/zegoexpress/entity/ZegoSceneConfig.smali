.class public Lim/zego/zegoexpress/entity/ZegoSceneConfig;
.super Ljava/lang/Object;


# instance fields
.field public channelCount:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoSceneConfig;->channelCount:I

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method
