.class public Lim/zego/zegoexpress/entity/ZegoCustomVideoProcessConfig;
.super Ljava/lang/Object;


# instance fields
.field public bufferType:Lim/zego/zegoexpress/constants/ZegoVideoBufferType;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoBufferType;->SURFACE_TEXTURE:Lim/zego/zegoexpress/constants/ZegoVideoBufferType;

    const/4 v1, 0x0

    and-int/2addr v2, v1

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoCustomVideoProcessConfig;->bufferType:Lim/zego/zegoexpress/constants/ZegoVideoBufferType;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method
