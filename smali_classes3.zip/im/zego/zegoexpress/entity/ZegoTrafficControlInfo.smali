.class public Lim/zego/zegoexpress/entity/ZegoTrafficControlInfo;
.super Ljava/lang/Object;


# instance fields
.field public bitrate:I

.field public fps:I

.field public height:I

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method
