.class public Lim/zego/zegoexpress/entity/ZegoFontStyle;
.super Ljava/lang/Object;


# instance fields
.field public border:Z

.field public borderColor:I

.field public color:I

.field public size:I

.field public transparency:I

.field public type:Lim/zego/zegoexpress/constants/ZegoFontType;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoFontType;->SOURCE_HAN_SANS:Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoFontStyle;->type:Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/16 v0, 0x18

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoFontStyle;->size:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    const v0, 0xffffff

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoFontStyle;->color:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoFontStyle;->transparency:I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-boolean v0, p0, Lim/zego/zegoexpress/entity/ZegoFontStyle;->border:Z

    const/4 v2, 0x4

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoFontStyle;->borderColor:I

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method
