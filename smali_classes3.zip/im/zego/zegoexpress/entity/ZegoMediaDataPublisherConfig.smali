.class public Lim/zego/zegoexpress/entity/ZegoMediaDataPublisherConfig;
.super Ljava/lang/Object;


# instance fields
.field public channel:I

.field public mode:Lim/zego/zegoexpress/constants/ZegoMediaDataPublisherMode;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    return-void
.end method
