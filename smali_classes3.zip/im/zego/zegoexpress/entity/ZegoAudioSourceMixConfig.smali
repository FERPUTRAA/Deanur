.class public Lim/zego/zegoexpress/entity/ZegoAudioSourceMixConfig;
.super Ljava/lang/Object;


# instance fields
.field public audioEffectPlayerIndexList:[I

.field public mediaPlayerIndexList:[I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method
