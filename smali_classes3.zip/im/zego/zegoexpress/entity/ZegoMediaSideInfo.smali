.class public Lim/zego/zegoexpress/entity/ZegoMediaSideInfo;
.super Ljava/lang/Object;


# instance fields
.field public SEIData:Ljava/nio/ByteBuffer;

.field public SEIDataLength:I

.field public streamID:Ljava/lang/String;

.field public timestampNs:J


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method
