.class public Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;
.super Ljava/lang/Object;


# instance fields
.field public bitrate:I

.field public fps:I

.field public height:I

.field public quality:I

.field public rateControlMode:Lim/zego/zegoexpress/constants/ZegoVideoRateControlMode;

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/16 v0, 0x168

    const/4 v2, 0x4

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->width:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/16 v0, 0x280

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->height:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/16 v0, 0xf

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->fps:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/16 v0, 0x258

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->bitrate:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/16 v0, 0x17

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->quality:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoRateControlMode;->CONSTANT_RATE:Lim/zego/zegoexpress/constants/ZegoVideoRateControlMode;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->rateControlMode:Lim/zego/zegoexpress/constants/ZegoVideoRateControlMode;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(IIII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "width",
            "height",
            "fps",
            "bitrate"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->width:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->height:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p3, p0, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->fps:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput p4, p0, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->bitrate:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    const/16 p1, 0x17

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->quality:I

    const/4 v0, 0x4

    const/4 v1, 0x6

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoVideoRateControlMode;->CONSTANT_RATE:Lim/zego/zegoexpress/constants/ZegoVideoRateControlMode;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->rateControlMode:Lim/zego/zegoexpress/constants/ZegoVideoRateControlMode;

    const/4 v1, 0x2

    return-void
.end method
