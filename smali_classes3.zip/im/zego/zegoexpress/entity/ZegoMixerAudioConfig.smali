.class public Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;
.super Ljava/lang/Object;


# instance fields
.field public bitrate:I

.field public channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

.field public codecID:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

.field public mixMode:Lim/zego/zegoexpress/constants/ZegoAudioMixMode;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/16 v0, 0x30

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;->bitrate:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->MONO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v2, 0x6

    const/4 v1, 0x0

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;->codecID:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioMixMode;->RAW:Lim/zego/zegoexpress/constants/ZegoAudioMixMode;

    const/4 v2, 0x5

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;->mixMode:Lim/zego/zegoexpress/constants/ZegoAudioMixMode;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method
