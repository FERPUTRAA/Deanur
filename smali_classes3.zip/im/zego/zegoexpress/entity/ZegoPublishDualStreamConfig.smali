.class public Lim/zego/zegoexpress/entity/ZegoPublishDualStreamConfig;
.super Ljava/lang/Object;


# instance fields
.field public bitrate:I

.field public encodeHeight:I

.field public encodeWidth:I

.field public fps:I

.field public streamType:Lim/zego/zegoexpress/constants/ZegoVideoStreamType;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method
