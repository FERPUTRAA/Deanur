.class public Lim/zego/zegoexpress/entity/ZegoBeautifyOption;
.super Ljava/lang/Object;


# instance fields
.field public polishStep:D

.field public sharpenFactor:D

.field public whitenFactor:D


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method
