.class public Lim/zego/zegoexpress/entity/ZegoBroadcastMessageInfo;
.super Ljava/lang/Object;


# instance fields
.field public fromUser:Lim/zego/zegoexpress/entity/ZegoUser;

.field public message:Ljava/lang/String;

.field public messageID:J

.field public sendTime:J


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method
