.class public Lim/zego/zegoexpress/entity/ZegoRoomExtraInfo;
.super Ljava/lang/Object;


# instance fields
.field public key:Ljava/lang/String;

.field public updateTime:J

.field public updateUser:Lim/zego/zegoexpress/entity/ZegoUser;

.field public value:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method
