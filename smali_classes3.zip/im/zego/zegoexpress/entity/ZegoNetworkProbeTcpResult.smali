.class public Lim/zego/zegoexpress/entity/ZegoNetworkProbeTcpResult;
.super Ljava/lang/Object;


# instance fields
.field public connectCostTime:I

.field public errorCode:I

.field public rtt:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method
