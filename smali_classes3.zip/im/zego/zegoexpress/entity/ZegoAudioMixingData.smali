.class public Lim/zego/zegoexpress/entity/ZegoAudioMixingData;
.super Ljava/lang/Object;


# instance fields
.field public SEIData:Ljava/nio/ByteBuffer;

.field public SEIDataLength:I

.field public audioData:Ljava/nio/ByteBuffer;

.field public audioDataLength:I

.field public param:Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance v0, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {v0}, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoAudioMixingData;->param:Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method
