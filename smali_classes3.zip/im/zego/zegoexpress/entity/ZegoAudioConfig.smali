.class public Lim/zego/zegoexpress/entity/ZegoAudioConfig;
.super Ljava/lang/Object;


# instance fields
.field public bitrate:I

.field public channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

.field public codecID:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;->STANDARD_QUALITY:Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, v0}, Lim/zego/zegoexpress/entity/ZegoAudioConfig;-><init>(Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;)V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "presetType"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v1, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->codecID:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v2, 0x0

    const/4 v1, 0x7

    sget-object v0, Lim/zego/zegoexpress/entity/ZegoAudioConfig$1;->$SwitchMap$im$zego$zegoexpress$constants$ZegoAudioConfigPreset:[I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    aget p1, v0, p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    if-eq p1, v0, :cond_4

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eq p1, v0, :cond_3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    move v2, v1

    if-eq p1, v0, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eq p1, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x5

    const/4 v2, 0x2

    if-eq p1, v0, :cond_0

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/16 p1, 0xc0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->bitrate:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->STEREO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/16 p1, 0x80

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->bitrate:I

    const/4 v2, 0x3

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->MONO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    goto :goto_0

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/16 p1, 0x38

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->bitrate:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->STEREO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_3
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/16 p1, 0x30

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->bitrate:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->MONO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    goto :goto_0

    :cond_4
    const/4 v1, 0x1

    const/4 v1, 0x2

    const/16 p1, 0x10

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->bitrate:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->MONO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method
