.class public Lim/zego/zegoexpress/entity/ZegoPosition;
.super Ljava/lang/Object;


# instance fields
.field public cameraOrientation:Lim/zego/zegoexpress/entity/ZegoPositionOrientation;

.field public coordinate:[F

.field public motionOrientation:Lim/zego/zegoexpress/entity/ZegoPositionOrientation;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    new-array v0, v0, [F

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoPosition;->coordinate:[F

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method
