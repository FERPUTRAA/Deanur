.class synthetic Lim/zego/zegoexpress/entity/ZegoAudioConfig$1;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lim/zego/zegoexpress/entity/ZegoAudioConfig;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1008
    name = null
.end annotation


# static fields
.field static final synthetic $SwitchMap$im$zego$zegoexpress$constants$ZegoAudioConfigPreset:[I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;->values()[Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    array-length v0, v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-array v0, v0, [I

    const/4 v4, 0x4

    sput-object v0, Lim/zego/zegoexpress/entity/ZegoAudioConfig$1;->$SwitchMap$im$zego$zegoexpress$constants$ZegoAudioConfigPreset:[I

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    sget-object v1, Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;->BASIC_QUALITY:Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    aput v2, v0, v1
    :try_end_0
    .catch Ljava/lang/NoSuchFieldError; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :try_start_1
    const/4 v4, 0x5

    sget-object v0, Lim/zego/zegoexpress/entity/ZegoAudioConfig$1;->$SwitchMap$im$zego$zegoexpress$constants$ZegoAudioConfigPreset:[I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object v1, Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;->STANDARD_QUALITY:Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    aput v2, v0, v1
    :try_end_1
    .catch Ljava/lang/NoSuchFieldError; {:try_start_1 .. :try_end_1} :catch_1

    :catch_1
    :try_start_2
    const/4 v4, 0x6

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/entity/ZegoAudioConfig$1;->$SwitchMap$im$zego$zegoexpress$constants$ZegoAudioConfigPreset:[I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    sget-object v1, Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;->STANDARD_QUALITY_STEREO:Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v2, 0x3

    const/4 v4, 0x0

    const/4 v3, 0x5

    aput v2, v0, v1
    :try_end_2
    .catch Ljava/lang/NoSuchFieldError; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    :try_start_3
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    sget-object v0, Lim/zego/zegoexpress/entity/ZegoAudioConfig$1;->$SwitchMap$im$zego$zegoexpress$constants$ZegoAudioConfigPreset:[I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    sget-object v1, Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;->HIGH_QUALITY:Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v2, 0x4

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    aput v2, v0, v1
    :try_end_3
    .catch Ljava/lang/NoSuchFieldError; {:try_start_3 .. :try_end_3} :catch_3

    :catch_3
    :try_start_4
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget-object v0, Lim/zego/zegoexpress/entity/ZegoAudioConfig$1;->$SwitchMap$im$zego$zegoexpress$constants$ZegoAudioConfigPreset:[I

    const/4 v4, 0x2

    sget-object v1, Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;->HIGH_QUALITY_STEREO:Lim/zego/zegoexpress/constants/ZegoAudioConfigPreset;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v2, 0x5

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    aput v2, v0, v1
    :try_end_4
    .catch Ljava/lang/NoSuchFieldError; {:try_start_4 .. :try_end_4} :catch_4

    :catch_4
    const/4 v4, 0x5

    const/4 v3, 0x0

    return-void
.end method
