.class public Lim/zego/zegoexpress/entity/ZegoVoiceChangerParam;
.super Ljava/lang/Object;


# instance fields
.field public pitch:F


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoVoiceChangerParam;->pitch:F

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method
