.class public Lim/zego/zegoexpress/entity/ZegoSoundLevelInfo;
.super Ljava/lang/Object;


# instance fields
.field public soundLevel:F

.field public vad:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method
