.class public Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;
.super Ljava/lang/Object;


# instance fields
.field public damping:F

.field public dryGain:F

.field public preDelay:F

.field public reverberance:F

.field public roomSize:F

.field public stereoWidth:F

.field public toneHigh:F

.field public toneLow:F

.field public wetGain:F

.field public wetOnly:Z


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->roomSize:F

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->reverberance:F

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->damping:F

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-boolean v1, p0, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->wetOnly:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->wetGain:F

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->dryGain:F

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/high16 v1, 0x42c80000    # 100.0f

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->toneLow:F

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->toneHigh:F

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->preDelay:F

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->stereoWidth:F

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method
