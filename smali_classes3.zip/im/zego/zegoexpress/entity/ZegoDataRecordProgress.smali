.class public Lim/zego/zegoexpress/entity/ZegoDataRecordProgress;
.super Ljava/lang/Object;


# instance fields
.field public currentFileSize:J

.field public duration:J


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method
