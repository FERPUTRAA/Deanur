.class public Lim/zego/zegoexpress/entity/ZegoStreamRelayCDNInfo;
.super Ljava/lang/Object;


# instance fields
.field public state:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

.field public stateTime:J

.field public updateReason:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

.field public url:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method
