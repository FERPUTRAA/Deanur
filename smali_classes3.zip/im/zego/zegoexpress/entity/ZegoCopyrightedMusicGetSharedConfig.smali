.class public Lim/zego/zegoexpress/entity/ZegoCopyrightedMusicGetSharedConfig;
.super Ljava/lang/Object;


# instance fields
.field public roomID:Ljava/lang/String;

.field public songID:Ljava/lang/String;

.field public vendorID:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->getZegoCopyrightedMusicVendorID(I)Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoCopyrightedMusicGetSharedConfig;->vendorID:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v1, 0x6

    move v2, v1

    return-void
.end method
