.class public Lim/zego/zegoexpress/entity/ZegoItemParam;
.super Ljava/lang/Object;


# instance fields
.field public capacity:I

.field public createMode:Lim/zego/zegoexpress/constants/ZegoCreateItemMode;

.field public itemID:J

.field public position:Lim/zego/zegoexpress/entity/ZegoPosition;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-wide v0, p0, Lim/zego/zegoexpress/entity/ZegoItemParam;->itemID:J

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoItemParam;->capacity:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCreateItemMode;->NO_BIND:Lim/zego/zegoexpress/constants/ZegoCreateItemMode;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoItemParam;->createMode:Lim/zego/zegoexpress/constants/ZegoCreateItemMode;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method
