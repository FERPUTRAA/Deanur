.class public Lim/zego/zegoexpress/entity/ZegoCustomVideoRenderConfig;
.super Ljava/lang/Object;


# instance fields
.field public bufferType:Lim/zego/zegoexpress/constants/ZegoVideoBufferType;

.field public enableEngineRender:Z

.field public frameFormatSeries:Lim/zego/zegoexpress/constants/ZegoVideoFrameFormatSeries;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoBufferType;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoVideoBufferType;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoCustomVideoRenderConfig;->bufferType:Lim/zego/zegoexpress/constants/ZegoVideoBufferType;

    const/4 v1, 0x3

    move v2, v1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoFrameFormatSeries;->RGB:Lim/zego/zegoexpress/constants/ZegoVideoFrameFormatSeries;

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoCustomVideoRenderConfig;->frameFormatSeries:Lim/zego/zegoexpress/constants/ZegoVideoFrameFormatSeries;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method
