.class public Lim/zego/zegoexpress/entity/ZegoObjectSegmentationConfig;
.super Ljava/lang/Object;


# instance fields
.field public backgroundConfig:Lim/zego/zegoexpress/entity/ZegoBackgroundConfig;

.field public objectSegmentationType:Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->ANY_BACKGROUND:Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoObjectSegmentationConfig;->objectSegmentationType:Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance v0, Lim/zego/zegoexpress/entity/ZegoBackgroundConfig;

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-direct {v0}, Lim/zego/zegoexpress/entity/ZegoBackgroundConfig;-><init>()V

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoObjectSegmentationConfig;->backgroundConfig:Lim/zego/zegoexpress/entity/ZegoBackgroundConfig;

    const/4 v1, 0x7

    move v2, v1

    return-void
.end method
