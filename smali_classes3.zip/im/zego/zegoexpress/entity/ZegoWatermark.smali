.class public Lim/zego/zegoexpress/entity/ZegoWatermark;
.super Ljava/lang/Object;


# instance fields
.field public imageURL:Ljava/lang/String;

.field public layout:Landroid/graphics/Rect;


# direct methods
.method public constructor <init>(Ljava/lang/String;Landroid/graphics/Rect;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "imageURL",
            "layout"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoWatermark;->imageURL:Ljava/lang/String;

    const/4 v1, 0x0

    iput-object p2, p0, Lim/zego/zegoexpress/entity/ZegoWatermark;->layout:Landroid/graphics/Rect;

    const/4 v0, 0x6

    return-void
.end method
