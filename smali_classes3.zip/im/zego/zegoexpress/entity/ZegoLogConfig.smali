.class public Lim/zego/zegoexpress/entity/ZegoLogConfig;
.super Ljava/lang/Object;


# instance fields
.field public logCount:I

.field public logPath:Ljava/lang/String;

.field public logSize:J


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v2, 0x4

    move v3, v2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoLogConfig;->logPath:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-wide/32 v0, 0x500000

    const-wide/32 v0, 0x500000

    const/4 v3, 0x3

    const-wide/32 v0, 0x500000

    const-wide/32 v0, 0x500000

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-wide v0, p0, Lim/zego/zegoexpress/entity/ZegoLogConfig;->logSize:J

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v0, 0x3

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoLogConfig;->logCount:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method
