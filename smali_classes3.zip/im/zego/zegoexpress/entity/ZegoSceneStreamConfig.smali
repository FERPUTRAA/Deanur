.class public Lim/zego/zegoexpress/entity/ZegoSceneStreamConfig;
.super Ljava/lang/Object;


# instance fields
.field public enablePlayInRange:Z

.field public enablePublishToWorld:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-boolean v0, p0, Lim/zego/zegoexpress/entity/ZegoSceneStreamConfig;->enablePlayInRange:Z

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    iput-boolean v0, p0, Lim/zego/zegoexpress/entity/ZegoSceneStreamConfig;->enablePublishToWorld:Z

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method
