.class public Lim/zego/zegoexpress/entity/ZegoCanvas;
.super Ljava/lang/Object;


# instance fields
.field public alphaBlend:Z

.field public backgroundColor:I

.field public view:Ljava/lang/Object;

.field public viewMode:Lim/zego/zegoexpress/constants/ZegoViewMode;


# direct methods
.method public constructor <init>(Ljava/lang/Object;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "view"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoCanvas;->view:Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoViewMode;->ASPECT_FIT:Lim/zego/zegoexpress/constants/ZegoViewMode;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoCanvas;->viewMode:Lim/zego/zegoexpress/constants/ZegoViewMode;

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x4

    move v0, p1

    move v0, p1

    const/4 v1, 0x1

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoCanvas;->backgroundColor:I

    const/4 v1, 0x2

    iput-boolean p1, p0, Lim/zego/zegoexpress/entity/ZegoCanvas;->alphaBlend:Z

    const/4 v1, 0x0

    const/4 v0, 0x5

    return-void
.end method
