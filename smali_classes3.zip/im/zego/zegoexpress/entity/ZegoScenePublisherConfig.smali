.class public Lim/zego/zegoexpress/entity/ZegoScenePublisherConfig;
.super Ljava/lang/Object;


# instance fields
.field public rangeSceneHandle:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v2, 0x6

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoScenePublisherConfig;->rangeSceneHandle:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method
