.class public Lim/zego/zegoexpress/entity/ZegoCustomVideoCaptureConfig;
.super Ljava/lang/Object;


# instance fields
.field public bufferType:Lim/zego/zegoexpress/constants/ZegoVideoBufferType;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoBufferType;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoVideoBufferType;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoCustomVideoCaptureConfig;->bufferType:Lim/zego/zegoexpress/constants/ZegoVideoBufferType;

    const/4 v2, 0x4

    return-void
.end method
