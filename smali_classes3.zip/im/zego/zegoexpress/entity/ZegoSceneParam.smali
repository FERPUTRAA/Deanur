.class public Lim/zego/zegoexpress/entity/ZegoSceneParam;
.super Ljava/lang/Object;


# instance fields
.field public broadcastMode:Lim/zego/zegoexpress/constants/ZegoBroadcastMode;

.field public position:Lim/zego/zegoexpress/entity/ZegoPosition;

.field public sceneID:J

.field public templateID:I

.field public token:Ljava/lang/String;

.field public user:Lim/zego/zegoexpress/entity/ZegoUser;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    move v3, v2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    iput-wide v0, p0, Lim/zego/zegoexpress/entity/ZegoSceneParam;->sceneID:J

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoSceneParam;->templateID:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoBroadcastMode;->ALL:Lim/zego/zegoexpress/constants/ZegoBroadcastMode;

    const/4 v3, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoSceneParam;->broadcastMode:Lim/zego/zegoexpress/constants/ZegoBroadcastMode;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoSceneParam;->token:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method
