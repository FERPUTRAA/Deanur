.class public Lim/zego/zegoexpress/entity/ZegoVideoConfig;
.super Ljava/lang/Object;


# instance fields
.field public bitrate:I

.field public captureHeight:I

.field public captureWidth:I

.field public codecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

.field public encodeHeight:I

.field public encodeWidth:I

.field public fps:I

.field public keyFrameInterval:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_360P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Lim/zego/zegoexpress/entity/ZegoVideoConfig;-><init>(Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "preset"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->codecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x1

    move v3, v2

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->keyFrameInterval:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/entity/ZegoVideoConfig$1;->$SwitchMap$im$zego$zegoexpress$constants$ZegoVideoConfigPreset:[I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    aget p1, v0, p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/16 v0, 0xf

    const/4 v3, 0x2

    packed-switch p1, :pswitch_data_0

    goto/16 :goto_0

    :pswitch_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/16 p1, 0x438

    const/4 v2, 0x0

    xor-int/2addr v3, v2

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureWidth:I

    const/4 v3, 0x6

    const/16 v1, 0x780

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureHeight:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeWidth:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeHeight:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/16 p1, 0xbb8

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->bitrate:I

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->fps:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    goto/16 :goto_0

    :pswitch_1
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/16 p1, 0x2d0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureWidth:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/16 v1, 0x500

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureHeight:I

    const/4 v3, 0x5

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeWidth:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeHeight:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/16 p1, 0x5dc

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->bitrate:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->fps:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto/16 :goto_0

    :pswitch_2
    const/4 v3, 0x4

    const/16 p1, 0x21c

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureWidth:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/16 v1, 0x3c0

    const/4 v3, 0x0

    const/4 v2, 0x1

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureHeight:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeWidth:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeHeight:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/16 p1, 0x4b0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->bitrate:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->fps:I

    const/4 v2, 0x6

    move v3, v2

    goto/16 :goto_0

    :pswitch_3
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/16 p1, 0x168

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureWidth:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/16 v1, 0x280

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureHeight:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeWidth:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeHeight:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/16 p1, 0x258

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->bitrate:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->fps:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :pswitch_4
    const/4 v3, 0x6

    const/16 p1, 0x10e

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureWidth:I

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/16 v1, 0x1e0

    const/4 v3, 0x5

    const/4 v2, 0x3

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureHeight:I

    const/4 v3, 0x2

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeWidth:I

    const/4 v3, 0x3

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeHeight:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/16 p1, 0x190

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->bitrate:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->fps:I

    const/4 v3, 0x4

    goto :goto_0

    :pswitch_5
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/16 p1, 0xb4

    const/4 v3, 0x2

    const/4 v2, 0x4

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureWidth:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/16 v1, 0x140

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureHeight:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeWidth:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeHeight:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/16 p1, 0x12c

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->bitrate:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->fps:I

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method


# virtual methods
.method public setCaptureResolution(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "width",
            "height"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "f@s b~.b- @~y~  @4/ so~ln~~o~@~@~tKS@~ @rv@md@t~o~@ co i ~  @ b~i1fo@@~ M~@@ai~~@~@~@ o~/@ lu@~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureWidth:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p2, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->captureHeight:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public setCodecID(Lim/zego/zegoexpress/constants/ZegoVideoCodecID;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "codecID"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->codecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public setEncodeResolution(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "width",
            "height"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeWidth:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput p2, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->encodeHeight:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public setVideoBitrate(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "bitrate"
        }
    .end annotation

    const/4 v0, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->bitrate:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public setVideoFPS(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "fps"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->fps:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method
