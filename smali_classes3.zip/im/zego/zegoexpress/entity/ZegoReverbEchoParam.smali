.class public Lim/zego/zegoexpress/entity/ZegoReverbEchoParam;
.super Ljava/lang/Object;


# instance fields
.field public decay:[F

.field public delay:[I

.field public inGain:F

.field public numDelays:I

.field public outGain:F


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v0, 0x7

    const/4 v3, 0x2

    move v2, v0

    move v2, v0

    const/4 v3, 0x0

    new-array v1, v0, [I

    const/4 v3, 0x6

    const/4 v2, 0x3

    iput-object v1, p0, Lim/zego/zegoexpress/entity/ZegoReverbEchoParam;->delay:[I

    const/4 v3, 0x6

    new-array v0, v0, [F

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoReverbEchoParam;->decay:[F

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method
