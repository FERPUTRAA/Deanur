.class public Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;
.super Ljava/lang/Object;


# instance fields
.field public filePath:Ljava/lang/String;

.field public recordType:Lim/zego/zegoexpress/constants/ZegoDataRecordType;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDataRecordType;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoDataRecordType;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;->recordType:Lim/zego/zegoexpress/constants/ZegoDataRecordType;

    const/4 v2, 0x6

    return-void
.end method
