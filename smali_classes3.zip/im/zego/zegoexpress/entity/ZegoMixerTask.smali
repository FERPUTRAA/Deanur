.class public Lim/zego/zegoexpress/entity/ZegoMixerTask;
.super Ljava/lang/Object;


# instance fields
.field public advancedConfig:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field public audioConfig:Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;

.field public backgroundColor:I

.field public backgroundImageURL:Ljava/lang/String;

.field public inputList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lim/zego/zegoexpress/entity/ZegoMixerInput;",
            ">;"
        }
    .end annotation
.end field

.field public minPlayStreamBufferLength:I

.field public outputList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lim/zego/zegoexpress/entity/ZegoMixerOutput;",
            ">;"
        }
    .end annotation
.end field

.field public soundLevel:Z

.field private streamAlignmentMode:Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

.field private taskID:Ljava/lang/String;

.field public userData:Ljava/nio/ByteBuffer;

.field public userDataLength:I

.field public videoConfig:Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;

.field public watermark:Lim/zego/zegoexpress/entity/ZegoWatermark;

.field public whiteboard:Lim/zego/zegoexpress/entity/ZegoMixerWhiteboard;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "taskID"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->taskID:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance p1, Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->inputList:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance p1, Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->outputList:Ljava/util/ArrayList;

    const/4 v2, 0x1

    new-instance p1, Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p1}, Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->audioConfig:Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    new-instance p1, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p1}, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->videoConfig:Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->backgroundColor:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->backgroundImageURL:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->userData:Ljava/nio/ByteBuffer;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->userDataLength:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance p1, Ljava/util/HashMap;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p1}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->advancedConfig:Ljava/util/HashMap;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 p1, -0x1

    xor-int/2addr v2, p1

    const/4 v1, 0x5

    move v2, v1

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->minPlayStreamBufferLength:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public enableSoundLevel(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "aKs@@f@il~~~ @f@t~n@4 m @s@~~lo tyi .~ @b ~v1 ~bM@~@@/~o @d  @S~ ~o@uoi@@cb@  /  ~o~ ~o-~r~~~@@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iput-boolean p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->soundLevel:Z

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public getTaskID()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->taskID:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public setAdvancedConfig(Ljava/util/HashMap;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "advancedConfig"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->advancedConfig:Ljava/util/HashMap;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public setAudioConfig(Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "config"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->audioConfig:Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public setBackgroundColor(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "backgroundColor"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->backgroundColor:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public setBackgroundImageURL(Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "backgroundImageURL"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->backgroundImageURL:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x5

    return-void
.end method

.method public setInputList(Ljava/util/ArrayList;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "inputList"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lim/zego/zegoexpress/entity/ZegoMixerInput;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->inputList:Ljava/util/ArrayList;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public setMinPlayStreamBufferLength(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "minPlayStreamBufferLength"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->minPlayStreamBufferLength:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public setOutputList(Ljava/util/ArrayList;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "outputList"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lim/zego/zegoexpress/entity/ZegoMixerOutput;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->outputList:Ljava/util/ArrayList;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public setStreamAlignmentMode(Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mode"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->streamAlignmentMode:Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public setUserData(Ljava/nio/ByteBuffer;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "length"
        }
    .end annotation

    const/4 v1, 0x7

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->userData:Ljava/nio/ByteBuffer;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->userDataLength:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public setVideoConfig(Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "config"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->videoConfig:Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public setWatermark(Lim/zego/zegoexpress/entity/ZegoWatermark;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "watermark"
        }
    .end annotation

    const/4 v0, 0x0

    move v1, v0

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->watermark:Lim/zego/zegoexpress/entity/ZegoWatermark;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public setWhiteboard(Lim/zego/zegoexpress/entity/ZegoMixerWhiteboard;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "whiteboard"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerTask;->whiteboard:Lim/zego/zegoexpress/entity/ZegoMixerWhiteboard;

    const/4 v1, 0x2

    const/4 v0, 0x3

    return-void
.end method
