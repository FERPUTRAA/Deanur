.class public Lim/zego/zegoexpress/entity/ZegoPerformanceStatus;
.super Ljava/lang/Object;


# instance fields
.field public cpuUsageApp:D

.field public cpuUsageSystem:D

.field public memoryUsageApp:D

.field public memoryUsageSystem:D

.field public memoryUsedApp:D


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method
