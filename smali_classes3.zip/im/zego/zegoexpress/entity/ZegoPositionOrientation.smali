.class public Lim/zego/zegoexpress/entity/ZegoPositionOrientation;
.super Ljava/lang/Object;


# instance fields
.field public axisForward:[F

.field public axisRight:[F

.field public axisUp:[F


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-array v1, v0, [F

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v1, p0, Lim/zego/zegoexpress/entity/ZegoPositionOrientation;->axisForward:[F

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-array v1, v0, [F

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object v1, p0, Lim/zego/zegoexpress/entity/ZegoPositionOrientation;->axisRight:[F

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-array v0, v0, [F

    const/4 v3, 0x5

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoPositionOrientation;->axisUp:[F

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method
