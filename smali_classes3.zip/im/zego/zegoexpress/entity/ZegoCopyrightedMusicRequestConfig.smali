.class public Lim/zego/zegoexpress/entity/ZegoCopyrightedMusicRequestConfig;
.super Ljava/lang/Object;


# instance fields
.field public masterID:Ljava/lang/String;

.field public mode:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicBillingMode;

.field public roomID:Ljava/lang/String;

.field public sceneID:I

.field public songID:Ljava/lang/String;

.field public vendorID:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x7

    invoke-static {v0}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicBillingMode;->getZegoCopyrightedMusicBillingMode(I)Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicBillingMode;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-object v1, p0, Lim/zego/zegoexpress/entity/ZegoCopyrightedMusicRequestConfig;->mode:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicBillingMode;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->getZegoCopyrightedMusicVendorID(I)Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v1, p0, Lim/zego/zegoexpress/entity/ZegoCopyrightedMusicRequestConfig;->vendorID:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v3, 0x2

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoCopyrightedMusicRequestConfig;->sceneID:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method
