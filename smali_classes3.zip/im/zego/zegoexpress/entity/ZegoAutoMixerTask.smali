.class public Lim/zego/zegoexpress/entity/ZegoAutoMixerTask;
.super Ljava/lang/Object;


# instance fields
.field public audioConfig:Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;

.field public enableSoundLevel:Z

.field public outputList:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lim/zego/zegoexpress/entity/ZegoMixerOutput;",
            ">;"
        }
    .end annotation
.end field

.field public roomID:Ljava/lang/String;

.field public streamAlignmentMode:Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

.field public taskID:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoAutoMixerTask;->taskID:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoAutoMixerTask;->roomID:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoAutoMixerTask;->outputList:Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    new-instance v0, Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoAutoMixerTask;->audioConfig:Lim/zego/zegoexpress/entity/ZegoMixerAudioConfig;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput-boolean v0, p0, Lim/zego/zegoexpress/entity/ZegoAutoMixerTask;->enableSoundLevel:Z

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->NONE:Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoAutoMixerTask;->streamAlignmentMode:Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method
