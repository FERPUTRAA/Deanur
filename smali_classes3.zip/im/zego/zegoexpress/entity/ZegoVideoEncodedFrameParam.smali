.class public Lim/zego/zegoexpress/entity/ZegoVideoEncodedFrameParam;
.super Ljava/lang/Object;


# instance fields
.field public SEIData:Ljava/nio/ByteBuffer;

.field public SEIDataLength:I

.field public format:Lim/zego/zegoexpress/constants/ZegoVideoEncodedFrameFormat;

.field public height:I

.field public isKeyFrame:Z

.field public rotation:I

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method
