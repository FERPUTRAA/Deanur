.class public Lim/zego/zegoexpress/entity/ZegoAccurateSeekConfig;
.super Ljava/lang/Object;


# instance fields
.field public timeout:J


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const-wide/16 v0, 0x1388

    const-wide/16 v0, 0x1388

    const-wide/16 v0, 0x1388

    const-wide/16 v0, 0x1388

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-wide v0, p0, Lim/zego/zegoexpress/entity/ZegoAccurateSeekConfig;->timeout:J

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method
