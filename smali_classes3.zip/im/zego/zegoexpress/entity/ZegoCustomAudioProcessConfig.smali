.class public Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;
.super Ljava/lang/Object;


# instance fields
.field public channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

.field public sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

.field public samples:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v2, 0x0

    const/4 v1, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->samples:I

    const/4 v2, 0x5

    return-void
.end method
