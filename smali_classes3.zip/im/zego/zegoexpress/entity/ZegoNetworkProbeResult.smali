.class public Lim/zego/zegoexpress/entity/ZegoNetworkProbeResult;
.super Ljava/lang/Object;


# instance fields
.field public httpProbeResult:Lim/zego/zegoexpress/entity/ZegoNetworkProbeHttpResult;

.field public tcpProbeResult:Lim/zego/zegoexpress/entity/ZegoNetworkProbeTcpResult;

.field public tracerouteResult:Lim/zego/zegoexpress/entity/ZegoNetworkProbeTracerouteResult;

.field public udpProbeResult:Lim/zego/zegoexpress/entity/ZegoNetworkProbeUdpResult;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method
