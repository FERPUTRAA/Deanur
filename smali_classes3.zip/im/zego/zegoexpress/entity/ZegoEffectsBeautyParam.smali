.class public Lim/zego/zegoexpress/entity/ZegoEffectsBeautyParam;
.super Ljava/lang/Object;


# instance fields
.field public rosyIntensity:I

.field public sharpenIntensity:I

.field public smoothIntensity:I

.field public whitenIntensity:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/16 v0, 0x32

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoEffectsBeautyParam;->whitenIntensity:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoEffectsBeautyParam;->rosyIntensity:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoEffectsBeautyParam;->smoothIntensity:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoEffectsBeautyParam;->sharpenIntensity:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method
