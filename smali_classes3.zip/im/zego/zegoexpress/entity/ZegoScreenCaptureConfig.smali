.class public Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;
.super Ljava/lang/Object;


# instance fields
.field public audioParam:Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

.field public captureAudio:Z

.field public captureVideo:Z


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x3

    iput-boolean v0, p0, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->captureVideo:Z

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-boolean v0, p0, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->captureAudio:Z

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0}, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->audioParam:Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object v1, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_16K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object v1, v0, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v1, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->STEREO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v1, v0, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method
