.class public Lim/zego/zegoexpress/entity/ZegoNetworkProbeConfig;
.super Ljava/lang/Object;


# instance fields
.field public enableTraceroute:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method
