.class public Lim/zego/zegoexpress/entity/ZegoProxyInfo;
.super Ljava/lang/Object;


# instance fields
.field public hostName:Ljava/lang/String;

.field public ip:Ljava/lang/String;

.field public password:Ljava/lang/String;

.field public port:I

.field public userName:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    shl-int/2addr v3, v2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoProxyInfo;->ip:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoProxyInfo;->port:I

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoProxyInfo;->hostName:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoProxyInfo;->userName:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoProxyInfo;->password:Ljava/lang/String;

    const/4 v3, 0x0

    return-void
.end method
