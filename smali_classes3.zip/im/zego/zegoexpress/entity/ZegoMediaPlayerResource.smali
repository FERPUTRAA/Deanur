.class public Lim/zego/zegoexpress/entity/ZegoMediaPlayerResource;
.super Ljava/lang/Object;


# instance fields
.field public alphaLayout:Lim/zego/zegoexpress/constants/ZegoAlphaLayoutType;

.field public filePath:Ljava/lang/String;

.field public loadType:Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

.field public memory:Ljava/nio/ByteBuffer;

.field public memoryLength:I

.field public resourceID:Ljava/lang/String;

.field public startPosition:J


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->FILE_PATH:Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoMediaPlayerResource;->loadType:Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-wide v0, p0, Lim/zego/zegoexpress/entity/ZegoMediaPlayerResource;->startPosition:J

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAlphaLayoutType;->NONE:Lim/zego/zegoexpress/constants/ZegoAlphaLayoutType;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoMediaPlayerResource;->alphaLayout:Lim/zego/zegoexpress/constants/ZegoAlphaLayoutType;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoMediaPlayerResource;->filePath:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    iput-object v1, p0, Lim/zego/zegoexpress/entity/ZegoMediaPlayerResource;->memory:Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput v1, p0, Lim/zego/zegoexpress/entity/ZegoMediaPlayerResource;->memoryLength:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoMediaPlayerResource;->resourceID:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method
