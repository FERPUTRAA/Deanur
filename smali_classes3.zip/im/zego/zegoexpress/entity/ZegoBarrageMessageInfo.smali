.class public Lim/zego/zegoexpress/entity/ZegoBarrageMessageInfo;
.super Ljava/lang/Object;


# instance fields
.field public fromUser:Lim/zego/zegoexpress/entity/ZegoUser;

.field public message:Ljava/lang/String;

.field public messageID:Ljava/lang/String;

.field public sendTime:J


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    return-void
.end method
