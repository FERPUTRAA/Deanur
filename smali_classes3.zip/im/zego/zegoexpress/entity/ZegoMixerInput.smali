.class public Lim/zego/zegoexpress/entity/ZegoMixerInput;
.super Ljava/lang/Object;


# instance fields
.field public audioDirection:I

.field public contentType:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

.field public cornerRadius:I

.field public imageInfo:Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;

.field public isAudioFocus:Z

.field public label:Lim/zego/zegoexpress/entity/ZegoLabelInfo;

.field public layout:Landroid/graphics/Rect;

.field public renderMode:Lim/zego/zegoexpress/constants/ZegoMixRenderMode;

.field public soundLevelID:I

.field public streamID:Ljava/lang/String;

.field public volume:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;Landroid/graphics/Rect;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "streamID",
            "contentType",
            "layout"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->streamID:Ljava/lang/String;

    const/4 v0, 0x6

    or-int/2addr v1, v0

    iput-object p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->contentType:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p3, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->layout:Landroid/graphics/Rect;

    const/4 v0, 0x6

    move v1, v0

    const/4 p1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x6

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->soundLevelID:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/16 p2, 0x64

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->volume:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->isAudioFocus:Z

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p2, -0x1

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->audioDirection:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    new-instance p2, Lim/zego/zegoexpress/entity/ZegoLabelInfo;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    const-string p3, ""

    const-string p3, ""

    const/4 v1, 0x5

    const-string p3, ""

    const-string p3, ""

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p2, p3}, Lim/zego/zegoexpress/entity/ZegoLabelInfo;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->label:Lim/zego/zegoexpress/entity/ZegoLabelInfo;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    sget-object p2, Lim/zego/zegoexpress/constants/ZegoMixRenderMode;->FILL:Lim/zego/zegoexpress/constants/ZegoMixRenderMode;

    const/4 v1, 0x0

    const/4 v0, 0x1

    iput-object p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->renderMode:Lim/zego/zegoexpress/constants/ZegoMixRenderMode;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    new-instance p2, Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p2, p3}, Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->imageInfo:Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;

    const/4 v1, 0x5

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->cornerRadius:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;Landroid/graphics/Rect;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "streamID",
            "contentType",
            "layout",
            "soundLevelID"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->streamID:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->contentType:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p3, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->layout:Landroid/graphics/Rect;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p4, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->soundLevelID:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/16 p1, 0x64

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->volume:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x4

    iput-boolean p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->isAudioFocus:Z

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 p2, -0x1

    xor-int/2addr v1, p2

    const/4 v0, 0x2

    and-int/2addr v1, v0

    iput p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->audioDirection:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    new-instance p2, Lim/zego/zegoexpress/entity/ZegoLabelInfo;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    const-string p3, ""

    const-string p3, ""

    const/4 v1, 0x4

    const-string p3, ""

    const-string p3, ""

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p2, p3}, Lim/zego/zegoexpress/entity/ZegoLabelInfo;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->label:Lim/zego/zegoexpress/entity/ZegoLabelInfo;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    sget-object p2, Lim/zego/zegoexpress/constants/ZegoMixRenderMode;->FILL:Lim/zego/zegoexpress/constants/ZegoMixRenderMode;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->renderMode:Lim/zego/zegoexpress/constants/ZegoMixRenderMode;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    new-instance p2, Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p2, p3}, Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->imageInfo:Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->cornerRadius:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;Landroid/graphics/Rect;IZI)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "streamID",
            "contentType",
            "layout",
            "soundLevelID",
            "isAudioFocus",
            "audioDirection"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->streamID:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->contentType:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p3, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->layout:Landroid/graphics/Rect;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p4, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->soundLevelID:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    const/16 p1, 0x64

    const/4 v1, 0x6

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->volume:I

    const/4 v1, 0x2

    iput-boolean p5, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->isAudioFocus:Z

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p6, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->audioDirection:I

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    new-instance p1, Lim/zego/zegoexpress/entity/ZegoLabelInfo;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    const-string p2, ""

    const-string p2, ""

    const/4 v1, 0x5

    const-string p2, ""

    const-string p2, ""

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p1, p2}, Lim/zego/zegoexpress/entity/ZegoLabelInfo;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->label:Lim/zego/zegoexpress/entity/ZegoLabelInfo;

    const/4 v1, 0x7

    const/4 v0, 0x5

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoMixRenderMode;->FILL:Lim/zego/zegoexpress/constants/ZegoMixRenderMode;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->renderMode:Lim/zego/zegoexpress/constants/ZegoMixRenderMode;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    new-instance p1, Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p1, p2}, Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->imageInfo:Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x2

    iput p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerInput;->cornerRadius:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    return-void
.end method
