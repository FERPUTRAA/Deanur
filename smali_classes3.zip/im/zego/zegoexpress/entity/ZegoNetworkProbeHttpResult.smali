.class public Lim/zego/zegoexpress/entity/ZegoNetworkProbeHttpResult;
.super Ljava/lang/Object;


# instance fields
.field public errorCode:I

.field public requestCostTime:I


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method
