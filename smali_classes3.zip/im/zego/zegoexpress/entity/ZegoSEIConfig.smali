.class public Lim/zego/zegoexpress/entity/ZegoSEIConfig;
.super Ljava/lang/Object;


# instance fields
.field public type:Lim/zego/zegoexpress/constants/ZegoSEIType;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoSEIType;->ZEGO_DEFINED:Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoSEIConfig;->type:Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method
