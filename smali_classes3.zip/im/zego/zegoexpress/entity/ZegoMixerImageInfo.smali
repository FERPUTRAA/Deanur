.class public Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;
.super Ljava/lang/Object;


# instance fields
.field public displayMode:I

.field public url:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "url"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {p0, p1, v0}, Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;-><init>(Ljava/lang/String;I)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "url",
            "displayMode"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;->url:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p2, p0, Lim/zego/zegoexpress/entity/ZegoMixerImageInfo;->displayMode:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method
