.class public Lim/zego/zegoexpress/entity/ZegoReverbParam;
.super Ljava/lang/Object;


# instance fields
.field public damping:F

.field public dryWetRatio:F

.field public reverberance:F

.field public roomSize:F


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoReverbParam;->roomSize:F

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoReverbParam;->reverberance:F

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoReverbParam;->damping:F

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoReverbParam;->dryWetRatio:F

    const/4 v2, 0x4

    const/4 v1, 0x6

    return-void
.end method
