.class public Lim/zego/zegoexpress/entity/ZegoPlayerConfig;
.super Ljava/lang/Object;


# instance fields
.field public cdnConfig:Lim/zego/zegoexpress/entity/ZegoCDNConfig;

.field public codecTemplateID:I

.field public resourceMode:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

.field public resourceSwitchMode:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

.field public roomID:Ljava/lang/String;

.field public sourceResourceType:Lim/zego/zegoexpress/constants/ZegoResourceType;

.field public videoCodecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoPlayerConfig;->resourceMode:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoPlayerConfig;->videoCodecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoResourceType;->RTC:Lim/zego/zegoexpress/constants/ZegoResourceType;

    const/4 v2, 0x6

    const/4 v1, 0x0

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoPlayerConfig;->sourceResourceType:Lim/zego/zegoexpress/constants/ZegoResourceType;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v2, 0x3

    const/4 v1, 0x0

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoPlayerConfig;->resourceSwitchMode:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method
