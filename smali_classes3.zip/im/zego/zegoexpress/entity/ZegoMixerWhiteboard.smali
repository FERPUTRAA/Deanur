.class public Lim/zego/zegoexpress/entity/ZegoMixerWhiteboard;
.super Ljava/lang/Object;


# instance fields
.field public backgroundColor:I

.field public horizontalRatio:I

.field public isPPTAnimation:Z

.field public layout:Landroid/graphics/Rect;

.field public verticalRatio:I

.field public whiteboardID:J

.field public zOrder:I


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    iput-wide v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerWhiteboard;->whiteboardID:J

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/16 v0, 0x10

    const/4 v3, 0x6

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerWhiteboard;->horizontalRatio:I

    const/4 v2, 0x0

    move v3, v2

    const/16 v0, 0x9

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerWhiteboard;->verticalRatio:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-boolean v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerWhiteboard;->isPPTAnimation:Z

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v1, Landroid/graphics/Rect;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    const/4 v3, 0x5

    iput-object v1, p0, Lim/zego/zegoexpress/entity/ZegoMixerWhiteboard;->layout:Landroid/graphics/Rect;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerWhiteboard;->zOrder:I

    const/4 v3, 0x4

    const v0, -0xe0c0c00

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoMixerWhiteboard;->backgroundColor:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method
