.class public Lim/zego/zegoexpress/entity/ZegoStream;
.super Ljava/lang/Object;


# instance fields
.field public extraInfo:Ljava/lang/String;

.field public streamID:Ljava/lang/String;

.field public user:Lim/zego/zegoexpress/entity/ZegoUser;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
