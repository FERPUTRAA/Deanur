.class public Lim/zego/zegoexpress/entity/ZegoCDNConfig;
.super Ljava/lang/Object;


# instance fields
.field public authParam:Ljava/lang/String;

.field public httpdns:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

.field public protocol:Ljava/lang/String;

.field public quicVersion:Ljava/lang/String;

.field public url:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    or-int/2addr v2, v1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x0

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoCDNConfig;->url:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method
