.class public Lim/zego/zegoexpress/entity/ZegoCustomAudioConfig;
.super Ljava/lang/Object;


# instance fields
.field public sourceType:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoCustomAudioConfig;->sourceType:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v2, 0x3

    const/4 v1, 0x3

    return-void
.end method
