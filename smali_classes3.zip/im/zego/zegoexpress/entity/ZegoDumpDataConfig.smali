.class public Lim/zego/zegoexpress/entity/ZegoDumpDataConfig;
.super Ljava/lang/Object;


# instance fields
.field public dataType:Lim/zego/zegoexpress/constants/ZegoDumpDataType;


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method
