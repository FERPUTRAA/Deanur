.class public Lim/zego/zegoexpress/entity/ZegoPublisherConfig;
.super Ljava/lang/Object;


# instance fields
.field public forceSynchronousNetworkTime:I

.field public roomID:Ljava/lang/String;

.field public streamCensorshipMode:Lim/zego/zegoexpress/constants/ZegoStreamCensorshipMode;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method
