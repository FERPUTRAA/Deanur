.class public Lim/zego/zegoexpress/entity/ZegoNetWorkResourceCache;
.super Ljava/lang/Object;


# instance fields
.field public size:I

.field public time:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method
