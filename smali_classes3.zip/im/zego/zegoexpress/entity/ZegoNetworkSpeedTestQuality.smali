.class public Lim/zego/zegoexpress/entity/ZegoNetworkSpeedTestQuality;
.super Ljava/lang/Object;


# instance fields
.field public connectCost:I

.field public packetLostRate:D

.field public quality:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

.field public rtt:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method
