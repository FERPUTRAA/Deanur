.class public Lim/zego/zegoexpress/entity/ZegoEngineProfile;
.super Ljava/lang/Object;


# instance fields
.field public appID:J

.field public appSign:Ljava/lang/String;

.field public application:Landroid/app/Application;

.field public scenario:Lim/zego/zegoexpress/constants/ZegoScenario;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method
