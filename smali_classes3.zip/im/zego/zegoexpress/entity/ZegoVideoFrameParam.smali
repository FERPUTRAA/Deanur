.class public Lim/zego/zegoexpress/entity/ZegoVideoFrameParam;
.super Ljava/lang/Object;


# instance fields
.field public format:Lim/zego/zegoexpress/constants/ZegoVideoFrameFormat;

.field public height:I

.field public rotation:I

.field public final strides:[I

.field public width:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-array v0, v0, [I

    const/4 v1, 0x7

    move v2, v1

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoVideoFrameParam;->strides:[I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method
