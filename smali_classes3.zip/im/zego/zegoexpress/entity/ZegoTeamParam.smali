.class public Lim/zego/zegoexpress/entity/ZegoTeamParam;
.super Ljava/lang/Object;


# instance fields
.field public teamID:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    move v2, v1

    const/4 v0, 0x0

    or-int/2addr v2, v0

    const/4 v1, 0x2

    move v2, v1

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoTeamParam;->teamID:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method
