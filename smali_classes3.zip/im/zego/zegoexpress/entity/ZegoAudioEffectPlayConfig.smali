.class public Lim/zego/zegoexpress/entity/ZegoAudioEffectPlayConfig;
.super Ljava/lang/Object;


# instance fields
.field public isPublishOut:Z

.field public playCount:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoAudioEffectPlayConfig;->playCount:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-boolean v0, p0, Lim/zego/zegoexpress/entity/ZegoAudioEffectPlayConfig;->isPublishOut:Z

    const/4 v2, 0x7

    return-void
.end method
