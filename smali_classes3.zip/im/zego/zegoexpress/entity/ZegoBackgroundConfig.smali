.class public Lim/zego/zegoexpress/entity/ZegoBackgroundConfig;
.super Ljava/lang/Object;


# instance fields
.field public blurLevel:Lim/zego/zegoexpress/constants/ZegoBackgroundBlurLevel;

.field public color:I

.field public imageURL:Ljava/lang/String;

.field public processType:Lim/zego/zegoexpress/constants/ZegoBackgroundProcessType;

.field public videoURL:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoBackgroundProcessType;->TRANSPARENT:Lim/zego/zegoexpress/constants/ZegoBackgroundProcessType;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoBackgroundConfig;->processType:Lim/zego/zegoexpress/constants/ZegoBackgroundProcessType;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoBackgroundConfig;->color:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    const-string v0, ""

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoBackgroundConfig;->imageURL:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x6

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoBackgroundConfig;->videoURL:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoBackgroundBlurLevel;->MEDIUM:Lim/zego/zegoexpress/constants/ZegoBackgroundBlurLevel;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoBackgroundConfig;->blurLevel:Lim/zego/zegoexpress/constants/ZegoBackgroundBlurLevel;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method
