.class public Lim/zego/zegoexpress/entity/ZegoSoundLevelConfig;
.super Ljava/lang/Object;


# instance fields
.field public enableVAD:Z

.field public millisecond:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method
