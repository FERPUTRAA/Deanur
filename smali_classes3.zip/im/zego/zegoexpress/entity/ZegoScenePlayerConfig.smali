.class public Lim/zego/zegoexpress/entity/ZegoScenePlayerConfig;
.super Ljava/lang/Object;


# instance fields
.field public cdnConfig:Lim/zego/zegoexpress/entity/ZegoCDNConfig;

.field public rangeSceneHandle:I

.field public resourceMode:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput v0, p0, Lim/zego/zegoexpress/entity/ZegoScenePlayerConfig;->rangeSceneHandle:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v2, 0x2

    const/4 v1, 0x6

    iput-object v0, p0, Lim/zego/zegoexpress/entity/ZegoScenePlayerConfig;->resourceMode:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method
