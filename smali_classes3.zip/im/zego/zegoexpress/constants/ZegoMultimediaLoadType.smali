.class public final enum Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

.field public static final enum FILE_PATH:Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

.field public static final enum MEMORY:Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

.field public static final enum RESOURCE_ID:Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string v1, "E_ssHPAIT"

    const-string v1, "EIsLAHT_P"

    const/4 v8, 0x7

    const-string v1, "IEPm_TLFA"

    const-string v1, "FILE_PATH"

    const/4 v8, 0x2

    const/4 v2, 0x2

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;-><init>(Ljava/lang/String;II)V

    const/4 v7, 0x0

    const/4 v7, 0x6

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->FILE_PATH:Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string v3, "YOMMoR"

    const-string v3, "RYOmMM"

    const/4 v8, 0x0

    const-string v3, "OREYMb"

    const-string v3, "MEMORY"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    const/4 v4, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;-><init>(Ljava/lang/String;II)V

    const/4 v7, 0x7

    xor-int/2addr v8, v7

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->MEMORY:Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v7, 0x3

    move v8, v7

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-string v5, "CDOIoRuSRE_"

    const-string v5, "SRRIoDUE_CO"

    const/4 v8, 0x6

    const-string v5, "R_RDOEUpESC"

    const-string v5, "RESOURCE_ID"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/4 v6, 0x2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->RESOURCE_ID:Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    const/4 v5, 0x3

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    new-array v5, v5, [Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    aput-object v0, v5, v2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    aput-object v1, v5, v4

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    aput-object v3, v5, v6

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v8, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->value:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public static getZegoMultimediaLoadType(I)Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @@  @o@qi@ -@ao~vd~~~ @~s@ @l~o ~MKn~@ ~~~~/o@ b~ i~ ~ ~~f~S~y@mblb~@f. /1@ti@o @4@~c ort~@@u  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->FILE_PATH:Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-ne v1, p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->MEMORY:Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    if-ne v1, p0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->RESOURCE_ID:Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-ne v1, p0, :cond_2

    const/4 v3, 0x2

    return-object v0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0

    :catch_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v0, "fbs ontuneeamuoa Thdre ei nbtnc"

    const-string/jumbo v0, "n mahbcnaueof itobeuer t nTnend"

    const/4 v3, 0x6

    const-string v0, "e Tmnfhdueatun teinomancrb enoo"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-class v0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoMultimediaLoadType;->value:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method
