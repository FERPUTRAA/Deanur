.class public final enum Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_VENDOR1:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_VENDOR2:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_VENDOR3:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_VENDOR_DEFAULT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 12

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v11, 0x3

    const-string v1, "O_sTLHEIVUGDCRYsFANC_EDMZEDU_P_IOERTO"

    const-string v1, "ULsICSGHDCVTOEDEIT_O_ME_YP_AOEUNRZRFD"

    const/4 v11, 0x4

    const-string v1, "NEEmARGM__ZIGCDEICHF_VTPSORDDYOEU_UTL"

    const-string v1, "ZEGO_COPYRIGHTED_MUSIC_VENDOR_DEFAULT"

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v2, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;-><init>(Ljava/lang/String;II)V

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->ZEGO_COPYRIGHTED_MUSIC_VENDOR_DEFAULT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const-string v3, "C_GmOI_ERV_DTRZC1ODGUMIPYOENEH"

    const/4 v11, 0x0

    const-string v3, "N1EIoI_OEURGDSMD_ZPHEVTOC_GCOY"

    const-string v3, "ZEGO_COPYRIGHTED_MUSIC_VENDOR1"

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    const/4 v4, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x1

    shl-int/2addr v11, v10

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->ZEGO_COPYRIGHTED_MUSIC_VENDOR1:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v10, 0x3

    const/4 v11, 0x0

    const-string v5, "RHGI_bEPVUOD_OODNCCI_oSETYMERG"

    const-string v5, "GYVOoGR_CE_SMDRIPTIDUC_ZEOHNOE"

    const/4 v11, 0x1

    const-string v5, "IEO_MDuRRG_SUIPONCTC2YEGZ_OHDV"

    const-string v5, "ZEGO_COPYRIGHTED_MUSIC_VENDOR2"

    const/4 v11, 0x6

    const/4 v6, 0x2

    const/4 v11, 0x3

    and-int/2addr v10, v6

    const/4 v11, 0x6

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;-><init>(Ljava/lang/String;II)V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x2

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->ZEGO_COPYRIGHTED_MUSIC_VENDOR2:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v10, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    const-string v7, "DDYIPMCpOEHEEOO3TSRGUN_bRGCV_I"

    const-string v7, "_DGVEbGENOYCHSROEOC3_MPDUT_RII"

    const/4 v11, 0x3

    const-string v7, "YVUDGRPCq3DOHEIEIES_GROOMZ_NT_"

    const-string v7, "ZEGO_COPYRIGHTED_MUSIC_VENDOR3"

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v8, 0x3

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    const/4 v9, 0x4

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-direct {v5, v7, v8, v9}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;-><init>(Ljava/lang/String;II)V

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->ZEGO_COPYRIGHTED_MUSIC_VENDOR3:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    new-array v7, v9, [Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    aput-object v0, v7, v2

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    aput-object v1, v7, v4

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    aput-object v3, v7, v6

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    aput-object v5, v7, v8

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->value:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public static getZegoCopyrightedMusicVendorID(I)Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->ZEGO_COPYRIGHTED_MUSIC_VENDOR_DEFAULT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->value:I

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-ne v1, p0, :cond_0

    const/4 v2, 0x6

    move v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->ZEGO_COPYRIGHTED_MUSIC_VENDOR1:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-ne v1, p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->ZEGO_COPYRIGHTED_MUSIC_VENDOR2:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-ne v1, p0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->ZEGO_COPYRIGHTED_MUSIC_VENDOR3:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-ne v1, p0, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p0

    :catch_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v0, "  staierfmne euuuoennnd ahTcoto"

    const-string v0, "Teo hnumonaeatncu entirfnou ed "

    const/4 v3, 0x6

    const-string v0, "eeame tnh nfduoo i aemuoncnbnTt"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v1, 0x4

    or-int/2addr v2, v1

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicVendorID;->value:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method
