.class public final enum Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

.field public static final enum ACCESS_POINT_ERROR:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

.field public static final enum BAD_NAME:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

.field public static final enum CDN_SERVER_DISCONNECTED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

.field public static final enum CREATE_STREAM_FAILED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

.field public static final enum DISCONNECTED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

.field public static final enum HANDSHAKE_FAILED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

.field public static final enum MIX_STREAM_ALL_INPUT_STREAM_CLOSED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

.field public static final enum MIX_STREAM_ALL_INPUT_STREAM_NO_DATA:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

.field public static final enum MIX_STREAM_SERVER_INTERNAL_ERROR:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

.field public static final enum NONE:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

.field public static final enum SERVER_ERROR:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-string v1, "EONN"

    const-string v1, "NONE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->NONE:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-string/jumbo v3, "sVsERRREOSR_"

    const-string v3, "EOsRRVRES_RE"

    const-string v3, "SERVER_ERROR"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->SERVER_ERROR:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-string v5, "EHEm_LNIKAmAFDDA"

    const-string v5, "KDEmIANESAFADL_H"

    const-string v5, "SHAEoI_HDFANEKDA"

    const-string v5, "HANDSHAKE_FAILED"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->HANDSHAKE_FAILED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-string v7, "I_OSCbSEAo_CRPRNOR"

    const-string v7, "CAPOo_RTRSONIE_RSC"

    const-string v7, "SRANRRuC_ECESPOI_T"

    const-string v7, "ACCESS_POINT_ERROR"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->ACCESS_POINT_ERROR:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-string v9, "EASE_bETCAIFEMDRTL_R"

    const-string v9, "_CL_AMEpTTRARDASFEEI"

    const-string v9, "CREATE_STREAM_FAILED"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->CREATE_STREAM_FAILED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-string v11, "DBEAA_uM"

    const-string/jumbo v11, "qBDMAN_A"

    const-string v11, "BAD_NAME"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->BAD_NAME:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    new-instance v11, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-string v13, "NNsSRCDEOCDTpD_CNEES_EI"

    const-string v13, "NE_SEIEpNCDECTDVDRSC_ON"

    const-string v13, "NNDmTSCNVER_SED_DCECOER"

    const-string v13, "CDN_SERVER_DISCONNECTED"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14, v14}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->CDN_SERVER_DISCONNECTED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    new-instance v13, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-string v15, "DISCONNECTED"

    const/4 v14, 0x7

    invoke-direct {v13, v15, v14, v14}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;-><init>(Ljava/lang/String;II)V

    sput-object v13, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->DISCONNECTED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    new-instance v15, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-string v14, "TR_IoTAEL_qECLA__SIRMAULDT_XSEMMNO"

    const-string v14, "I_A_SLRAqTE_COLDLIMTM_TXUSN_MSREAE"

    const-string v14, "MRSXNbTEIMA__TTMLRILUS_E_LOASDPE_A"

    const-string v14, "MIX_STREAM_ALL_INPUT_STREAM_CLOSED"

    const/16 v12, 0x8

    invoke-direct {v15, v14, v12, v12}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;-><init>(Ljava/lang/String;II)V

    sput-object v15, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->MIX_STREAM_ALL_INPUT_STREAM_CLOSED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    new-instance v14, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-string v12, "UDsTARuRELATOAI__AE__XSMLNPTMTS_ANI"

    const-string v12, "AAsTAE_A_NRMIDSSTIRTPX_U_E__TLNMOAL"

    const-string v12, "L_MRSN_pT_ARD_XA_MO_ITALAETEMSATNUP"

    const-string v12, "MIX_STREAM_ALL_INPUT_STREAM_NO_DATA"

    const/16 v10, 0x9

    invoke-direct {v14, v12, v10, v10}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;-><init>(Ljava/lang/String;II)V

    sput-object v14, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->MIX_STREAM_ALL_INPUT_STREAM_NO_DATA:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    new-instance v12, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-string v10, "_EEMLRXRqR_RAESETSIVmRINNRT__AMO"

    const-string v10, "ME_mNRIOEVNE_XRI_AE_RARMLSTESTRR"

    const-string v10, "MIX_STREAM_SERVER_INTERNAL_ERROR"

    const/16 v8, 0xa

    invoke-direct {v12, v10, v8, v8}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;-><init>(Ljava/lang/String;II)V

    sput-object v12, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->MIX_STREAM_SERVER_INTERNAL_ERROR:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/16 v10, 0xb

    new-array v10, v10, [Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    aput-object v0, v10, v2

    aput-object v1, v10, v4

    aput-object v3, v10, v6

    const/4 v0, 0x3

    aput-object v5, v10, v0

    const/4 v0, 0x4

    aput-object v7, v10, v0

    const/4 v0, 0x5

    aput-object v9, v10, v0

    const/4 v0, 0x6

    aput-object v11, v10, v0

    const/4 v0, 0x7

    aput-object v13, v10, v0

    const/16 v0, 0x8

    aput-object v15, v10, v0

    const/16 v0, 0x9

    aput-object v14, v10, v0

    aput-object v12, v10, v8

    sput-object v10, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v0, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public static getZegoStreamRelayCDNUpdateReason(I)Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->NONE:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I

    const/4 v3, 0x5

    if-ne v1, p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->SERVER_ERROR:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v2, 0x5

    move v3, v2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-ne v1, p0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->HANDSHAKE_FAILED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-ne v1, p0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x4

    return-object v0

    :cond_2
    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->ACCESS_POINT_ERROR:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    if-ne v1, p0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->CREATE_STREAM_FAILED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ne v1, p0, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->BAD_NAME:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ne v1, p0, :cond_5

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0

    :cond_5
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->CDN_SERVER_DISCONNECTED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I

    const/4 v2, 0x4

    move v3, v2

    if-ne v1, p0, :cond_6

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :cond_6
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->DISCONNECTED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I

    const/4 v3, 0x5

    if-ne v1, p0, :cond_7

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0

    :cond_7
    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->MIX_STREAM_ALL_INPUT_STREAM_CLOSED:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-ne v1, p0, :cond_8

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0

    :cond_8
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->MIX_STREAM_ALL_INPUT_STREAM_NO_DATA:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-ne v1, p0, :cond_9

    const/4 v3, 0x5

    return-object v0

    :cond_9
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->MIX_STREAM_SERVER_INTERNAL_ERROR:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-ne v1, p0, :cond_a

    const/4 v3, 0x1

    return-object v0

    :cond_a
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p0

    :catch_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo v0, "thsamfnobecnieonuoen u tTeo na "

    const-string v0, " unno nnehmaofebc roo antTtiuee"

    const/4 v3, 0x6

    const-string/jumbo v0, "taamoner umbcotin ueonTdne  nhf"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v2, 0x7

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNUpdateReason;->value:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method
