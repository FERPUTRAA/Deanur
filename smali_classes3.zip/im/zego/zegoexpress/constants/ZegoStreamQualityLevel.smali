.class public final enum Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

.field public static final enum BAD:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

.field public static final enum DIE:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

.field public static final enum EXCELLENT:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

.field public static final enum GOOD:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

.field public static final enum MEDIUM:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

.field public static final enum UNKNOWN:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 15

    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x5

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x1

    const-string v1, "LTsCEsELN"

    const-string v1, "LEsCTENEL"

    const/4 v14, 0x4

    const-string v1, "TNEmLCEXE"

    const-string v1, "EXCELLENT"

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x7

    const/4 v2, 0x0

    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x6

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x2

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->EXCELLENT:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x4

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x0

    const/4 v13, 0x7

    const-string v3, "OGOD"

    const-string v3, "GODO"

    const/4 v14, 0x5

    const-string v3, "OGOD"

    const-string v3, "GOOD"

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x1

    const/4 v4, 0x1

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x4

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x5

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->GOOD:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x6

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x3

    const/4 v13, 0x3

    const-string v5, "ImUDoM"

    const-string v5, "IUEmDM"

    const/4 v14, 0x7

    const-string v5, "MIDMUb"

    const-string v5, "MEDIUM"

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v6, 0x2

    and-int/2addr v14, v6

    const/4 v13, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x7

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x2

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->MEDIUM:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x4

    const/4 v13, 0x0

    const/4 v14, 0x4

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x3

    const-string v7, "DBA"

    const-string v7, "BAD"

    const/4 v14, 0x6

    const-string v7, "BDA"

    const-string v7, "BAD"

    const/4 v14, 0x4

    const/4 v13, 0x0

    const/4 v14, 0x6

    const/4 v8, 0x3

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x5

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x2

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->BAD:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x2

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x4

    const-string v9, "EID"

    const-string v9, "DIE"

    const/4 v14, 0x1

    const-string v9, "IDE"

    const-string v9, "DIE"

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x6

    const/4 v10, 0x4

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x1

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x2

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->DIE:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x7

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v13, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x4

    const-string v11, "UOKWoNN"

    const/4 v14, 0x6

    const-string v11, "NWNOKUu"

    const-string v11, "UNKNOWN"

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x7

    const/4 v12, 0x5

    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x0

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x1

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v11, 0x6

    shl-int/2addr v14, v11

    const/4 v13, 0x0

    or-int/2addr v14, v13

    new-array v11, v11, [Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x1

    const/4 v13, 0x6

    aput-object v0, v11, v2

    const/4 v14, 0x2

    const/4 v13, 0x7

    aput-object v1, v11, v4

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x7

    aput-object v3, v11, v6

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x1

    aput-object v5, v11, v8

    const/4 v14, 0x7

    const/4 v13, 0x4

    aput-object v7, v11, v10

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x6

    aput-object v9, v11, v12

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x5

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v14, 0x4

    const/4 v13, 0x6

    const/4 v14, 0x0

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->value:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public static getZegoStreamQualityLevel(I)Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~~ @Ssp~lu  fo~l~on t~  ~c @@~@/@@Ko@@~~@@o  Ma@ @@~4  b~i~@ -@fro/b@ tmi~~~ v~@yo~ ~d~i@~@1b@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->EXCELLENT:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ne v1, p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->GOOD:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->value:I

    const/4 v2, 0x1

    shl-int/2addr v3, v2

    if-ne v1, p0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->MEDIUM:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v2, 0x6

    or-int/2addr v3, v2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->value:I

    const/4 v3, 0x4

    if-ne v1, p0, :cond_2

    const/4 v3, 0x0

    return-object v0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->BAD:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-ne v1, p0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->DIE:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->value:I

    if-ne v1, p0, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object v0

    :cond_4
    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-ne v1, p0, :cond_5

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0

    :cond_5
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    return-object p0

    :catch_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/RuntimeException;

    const-string/jumbo v0, "no utnneq ri mbcTaenueebafhtono"

    const-string/jumbo v0, "nonitbeaeunTadhoutcfoe mbennr  "

    const/4 v3, 0x3

    const-string v0, "easd encTtbunoontamonune e ri h"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoStreamQualityLevel;->value:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method
