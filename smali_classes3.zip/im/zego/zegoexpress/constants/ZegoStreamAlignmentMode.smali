.class public final enum Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

.field public static final enum NONE:Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

.field public static final enum TRY:Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v1, "NENO"

    const/4 v6, 0x1

    const-string v1, "OENN"

    const-string v1, "NONE"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;-><init>(Ljava/lang/String;II)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->NONE:Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string v3, "TYR"

    const-string v3, "TYR"

    const/4 v6, 0x6

    const-string v3, "RYT"

    const-string v3, "TRY"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v4, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;-><init>(Ljava/lang/String;II)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->TRY:Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v3, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-array v3, v3, [Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    aput-object v0, v3, v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    aput-object v1, v3, v4

    const/4 v5, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v6, 0x5

    const/4 v5, 0x0

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->value:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    return-void
.end method

.method public static getZegoStreamAlignmentMode(I)Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s ~ v /~~f@@~sd~bi ~~ f@ ~~ol ~@@@~-@  1im@S~~@@a~@K cootbt ~ @@@/@ o@4Mb~y ~@ nlri~o~~u ~@.@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->NONE:Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->value:I

    if-ne v1, p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->TRY:Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v1, p0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object p0

    :catch_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string/jumbo v0, "tn mdnsmioanoenuaur Toenfc eehb"

    const-string v0, "crsmeathoenbeuoda  eonTunn fin "

    const/4 v3, 0x2

    const-string/jumbo v0, "uucoonhnfrnmn bited tneT eaaoeo"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;
    .locals 3

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->value:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    return v0
.end method
