.class public final enum Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

.field public static final enum NONE:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

.field public static final enum POLISH:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

.field public static final enum SHARPEN:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

.field public static final enum SKIN_WHITEN:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

.field public static final enum WHITEN:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 14

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x4

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x4

    const-string v1, "NEON"

    const-string v1, "OENN"

    const-string v1, "NNOE"

    const-string v1, "NONE"

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x5

    const/4 v2, 0x0

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x5

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x2

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->NONE:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x5

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v12, 0x6

    or-int/2addr v13, v12

    const-string v3, "SHssOP"

    const-string v3, "PLsOHS"

    const/4 v13, 0x6

    const-string v3, "IHLmOP"

    const-string v3, "POLISH"

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x7

    const/4 v4, 0x1

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x5

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x5

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->POLISH:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v13, 0x2

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x4

    const-string v5, "WHITom"

    const-string v5, "HNImWT"

    const/4 v13, 0x0

    const-string v5, "NHTWIb"

    const-string v5, "WHITEN"

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x5

    const/4 v6, 0x2

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x0

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x3

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->WHITEN:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v13, 0x1

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x4

    const-string v7, "SW_EoNIIKHT"

    const/4 v13, 0x0

    const-string v7, "NNKSEIuIT_H"

    const-string v7, "SKIN_WHITEN"

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x6

    const/4 v8, 0x3

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x7

    const/4 v9, 0x4

    const/4 v13, 0x2

    const/4 v12, 0x7

    invoke-direct {v5, v7, v8, v9}, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x7

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->SKIN_WHITEN:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x4

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x4

    const-string/jumbo v10, "pHbNPES"

    const-string v10, "PAHESbN"

    const/4 v13, 0x7

    const-string v10, "NqEHRAS"

    const-string v10, "SHARPEN"

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x4

    const/16 v11, 0x8

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x2

    invoke-direct {v7, v10, v9, v11}, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x2

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->SHARPEN:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x6

    const/4 v10, 0x5

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x6

    new-array v10, v10, [Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x7

    aput-object v0, v10, v2

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x3

    aput-object v1, v10, v4

    const/4 v13, 0x0

    aput-object v3, v10, v6

    const/4 v12, 0x1

    const/4 v13, 0x6

    aput-object v5, v10, v8

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x4

    aput-object v7, v10, v9

    const/4 v12, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x4

    sput-object v10, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x5

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->value:I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public static getZegoBeautifyFeature(I)Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s~ n  4~/c@~~~@ @ @@  @o~us@f@@@fd io~@~ a @S @~lvor-~/~Ko@ 1~ ~~m~.~@@ Mt~~b~ilit@ o@o~ @ ybb"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->NONE:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-ne v1, p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->POLISH:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-ne v1, p0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0

    :cond_1
    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->WHITEN:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    if-ne v1, p0, :cond_2

    const/4 v3, 0x5

    return-object v0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->SKIN_WHITEN:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ne v1, p0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x5

    return-object v0

    :cond_3
    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->SHARPEN:Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ne v1, p0, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p0

    :catch_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v0, "  omfuonucdmnataboue neerneiT n"

    const-string v0, "b neooumeirtnaTedf uacnoutnn  e"

    const/4 v3, 0x7

    const-string/jumbo v0, "ueT ontoi  fhcednnrunbea otamne"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-class v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v2, 0x2

    const-class v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoBeautifyFeature;->value:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method
