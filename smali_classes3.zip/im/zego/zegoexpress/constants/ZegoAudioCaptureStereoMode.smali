.class public final enum Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

.field public static final enum ADAPTIVE:Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final enum ALWAYS:Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

.field public static final enum NONE:Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v1, "NENO"

    const-string v1, "NEON"

    const/4 v8, 0x7

    const-string v1, "ONNE"

    const-string v1, "NONE"

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v2, 0x0

    or-int/2addr v8, v2

    const/4 v7, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x2

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->NONE:Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string v3, "SssYLA"

    const-string v3, "SYsLAA"

    const/4 v8, 0x6

    const-string v3, "ALWAYS"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    const/4 v4, 0x1

    const/4 v8, 0x0

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->ALWAYS:Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-string/jumbo v5, "mTAmIPAD"

    const-string v5, "EADmIPTA"

    const/4 v8, 0x0

    const-string v5, "PATIoVEA"

    const-string v5, "ADAPTIVE"

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v6, 0x2

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->ADAPTIVE:Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v8, 0x4

    const/4 v5, 0x3

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    new-array v5, v5, [Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    aput-object v0, v5, v2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    aput-object v1, v5, v4

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    aput-object v3, v5, v6

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->value:I

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public static getZegoAudioCaptureStereoMode(I)Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ @~ b@~oo ~ t@    c@i iu~~@/~oyt@~@@@d@r~@~@-~4a~io~ @mo~nlfl@b  @@~@ob@~fb~1~K~ v M@/ ~~  s.S@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->NONE:Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v3, 0x6

    const/4 v2, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    if-ne v1, p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->ALWAYS:Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ne v1, p0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->ADAPTIVE:Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-ne v1, p0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v2, 0x5

    move v3, v2

    return-object p0

    :catch_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v0, " Toic uorbnohne amtnuedeaont nf"

    const-string v0, "efndo etTiotmnnn ruhanaeooceb  "

    const/4 v3, 0x5

    const-string/jumbo v0, "fn eni p atnm ndTbaneuhrecouoet"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v2, 0x2

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->value:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method
