.class public final enum Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum AUDIO_SESSION_CATEGORY_CHANGE:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum AUDIO_SESSION_DEACTIVE:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum DEVICE_OCCUPIED:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum DEVICE_UNPLUGGED:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum GENERIC:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum INVALID_ID:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum MAGNETIC_CASE:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum MEDIA_SERVICES_WERE_LOST:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum PERMISSION_NOT_GRANTED:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum REBOOT_REQUIRED:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum SIRI_IS_RECORDING:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum SOUND_LEVEL_TOO_LOW:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum UNKNOWN:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

.field public static final enum ZERO_CAPTURE_FPS:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 17

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string/jumbo v1, "sKsOWNU"

    const-string v1, "WUsNONK"

    const-string v1, "NKNmNWO"

    const-string v1, "UNKNOWN"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v3, "GEmEoIN"

    const-string v3, "ICEmEGN"

    const-string v3, "NECRGbE"

    const-string v3, "GENERIC"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->GENERIC:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v5, "A_NIVIuoDI"

    const-string v5, "IVADo_ILIN"

    const-string v5, "IDIV_AIpLD"

    const-string v5, "INVALID_ID"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->INVALID_ID:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v7, "NNNAEM_EqRDb_SPGSOTTOI"

    const-string v7, "TRSANb_NTRIO_NMEEPODSG"

    const-string v7, "PAsSGREONO_TE_RTMNSINI"

    const-string v7, "PERMISSION_NOT_GRANTED"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->PERMISSION_NOT_GRANTED:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v9, "OR_mTSEAFUZuR_PE"

    const-string v9, "_ZETEUuCPARFR_SO"

    const-string v9, "RZFAoPE_ER_OCSPU"

    const-string v9, "ZERO_CAPTURE_FPS"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->ZERO_CAPTURE_FPS:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v11, "EpECUbIODVICPE_"

    const-string v11, "C_PDCEIpEUDOEIV"

    const-string v11, "OV_EIIuDUCPECDE"

    const-string v11, "DEVICE_OCCUPIED"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->DEVICE_OCCUPIED:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v11, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v13, "LNCqG_EpIVUEPDEG"

    const-string v13, "UEVGCNDPq_LEEDIG"

    const-string v13, "IPUENULDqVDCEGG_"

    const-string v13, "DEVICE_UNPLUGGED"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14, v14}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->DEVICE_UNPLUGGED:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v13, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v15, "ORsBTERIUEODEQR"

    const-string v15, "REBOOT_REQUIRED"

    const/4 v14, 0x7

    invoke-direct {v13, v15, v14, v14}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v13, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->REBOOT_REQUIRED:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v15, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v14, "MC_mSTROEAVIsSDI_ESREEE_"

    const-string v14, "IEsER_O_RCESIVSMTSWEA_DE"

    const-string v14, "MEDIA_SERVICES_WERE_LOST"

    const/16 v12, 0x8

    invoke-direct {v15, v14, v12, v12}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v15, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->MEDIA_SERVICES_WERE_LOST:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v14, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v12, "__IDoGRSSERmONRIC"

    const-string v12, "__RmCISORIGRDESNI"

    const-string v12, "SIRI_IS_RECORDING"

    const/16 v10, 0x9

    invoke-direct {v14, v12, v10, v10}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v14, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->SIRI_IS_RECORDING:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v12, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v10, "LT_UNbL_OVSoLOEODWE"

    const-string v10, "ES_DoL_EOLOTOUWVNOL"

    const-string v10, "D__OVEuNLOLO_ESTWOL"

    const-string v10, "SOUND_LEVEL_TOO_LOW"

    const/16 v8, 0xa

    invoke-direct {v12, v10, v8, v8}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v12, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->SOUND_LEVEL_TOO_LOW:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v10, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v8, "SECAITAp_MENG"

    const-string v8, "GC_AAbMIEETNS"

    const-string v8, "AGT_CICEqMSAN"

    const-string v8, "MAGNETIC_CASE"

    const/16 v6, 0xb

    invoke-direct {v10, v8, v6, v6}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v10, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->MAGNETIC_CASE:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v8, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v6, "E_sEDuOCVANSTSI_ADSUOI"

    const-string v6, "SENTSIuID_U_ODCAOVESAE"

    const-string v6, "EOImTSUN_EDSSIECADAOVI"

    const-string v6, "AUDIO_SESSION_DEACTIVE"

    const/16 v4, 0xc

    invoke-direct {v8, v6, v4, v4}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v8, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->AUDIO_SESSION_DEACTIVE:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    new-instance v6, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-string v4, "SSC_o_DANYEEIO_RGTOSHCApIGUEO"

    const-string v4, "_ESSGNIpEYCNGADIASOT_OEROHCU_"

    const-string v4, "_SNA_bCOOANICAIEOSHGDGERSE_UT"

    const-string v4, "AUDIO_SESSION_CATEGORY_CHANGE"

    const/16 v2, 0xd

    invoke-direct {v6, v4, v2, v2}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->AUDIO_SESSION_CATEGORY_CHANGE:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/16 v4, 0xe

    new-array v4, v4, [Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/16 v16, 0x0

    aput-object v0, v4, v16

    const/4 v0, 0x1

    aput-object v1, v4, v0

    const/4 v0, 0x2

    aput-object v3, v4, v0

    const/4 v0, 0x3

    aput-object v5, v4, v0

    const/4 v0, 0x4

    aput-object v7, v4, v0

    const/4 v0, 0x5

    aput-object v9, v4, v0

    const/4 v0, 0x6

    aput-object v11, v4, v0

    const/4 v0, 0x7

    aput-object v13, v4, v0

    const/16 v0, 0x8

    aput-object v15, v4, v0

    const/16 v0, 0x9

    aput-object v14, v4, v0

    const/16 v0, 0xa

    aput-object v12, v4, v0

    const/16 v0, 0xb

    aput-object v10, v4, v0

    const/16 v0, 0xc

    aput-object v8, v4, v0

    aput-object v6, v4, v2

    sput-object v4, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v0, 0x2

    const/4 v0, 0x2

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public static getZegoDeviceExceptionType(I)Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~i4@ ~u~@~ ~@li@f@t ~@c~ ~f r~. ~vy@ @mM lo@~S~~@@~@o~a ~uo/ o~d@~@~   b@/o -@@ bs@1o ~@~K@b~int"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    if-ne v1, p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->GENERIC:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    if-ne v1, p0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->INVALID_ID:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-ne v1, p0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->PERMISSION_NOT_GRANTED:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-ne v1, p0, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->ZERO_CAPTURE_FPS:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-ne v1, p0, :cond_4

    const/4 v2, 0x6

    move v3, v2

    return-object v0

    :cond_4
    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->DEVICE_OCCUPIED:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-ne v1, p0, :cond_5

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0

    :cond_5
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->DEVICE_UNPLUGGED:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-ne v1, p0, :cond_6

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_6
    const/4 v3, 0x1

    const/4 v2, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->REBOOT_REQUIRED:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v3, 0x3

    if-ne v1, p0, :cond_7

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0

    :cond_7
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->MEDIA_SERVICES_WERE_LOST:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    if-ne v1, p0, :cond_8

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0

    :cond_8
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->SIRI_IS_RECORDING:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-ne v1, p0, :cond_9

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0

    :cond_9
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->SOUND_LEVEL_TOO_LOW:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v2, 0x0

    if-ne v1, p0, :cond_a

    const/4 v3, 0x1

    return-object v0

    :cond_a
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->MAGNETIC_CASE:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v2, 0x1

    or-int/2addr v3, v2

    if-ne v1, p0, :cond_b

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0

    :cond_b
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->AUDIO_SESSION_DEACTIVE:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v3, 0x5

    if-ne v1, p0, :cond_c

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0

    :cond_c
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->AUDIO_SESSION_CATEGORY_CHANGE:Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-ne v1, p0, :cond_d

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0

    :cond_d
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    return-object p0

    :catch_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v0, "tentubeiqemn a hucordaTnf no en"

    const/4 v3, 0x4

    const-string/jumbo v0, "tomne opnubnaenc neeof uaT rdht"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-class v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v2, 0x0

    const-class v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v2, 0x4

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v2, 0x6

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->value:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method
