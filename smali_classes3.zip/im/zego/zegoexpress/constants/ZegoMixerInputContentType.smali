.class public final enum Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

.field public static final enum AUDIO:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

.field public static final enum VIDEO:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

.field public static final enum VIDEO_ONLY:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string v1, "DssAO"

    const-string v1, "UAsDO"

    const/4 v8, 0x3

    const-string v1, "ADImO"

    const-string v1, "AUDIO"

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v2, 0x0

    move v8, v2

    const/4 v7, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->AUDIO:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string v3, "DmIOo"

    const-string v3, "IOVmD"

    const/4 v8, 0x5

    const-string v3, "VIDEO"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/4 v4, 0x1

    const/4 v8, 0x2

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x7

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->VIDEO:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v8, 0x3

    const/4 v7, 0x6

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string v5, "ENLo_bVIYO"

    const-string v5, "IEONoYD_LV"

    const/4 v8, 0x3

    const-string v5, "OI_LOEuVDN"

    const-string v5, "VIDEO_ONLY"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/4 v6, 0x2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;-><init>(Ljava/lang/String;II)V

    const/4 v7, 0x3

    move v8, v7

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->VIDEO_ONLY:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v7, 0x7

    shr-int/2addr v8, v7

    const/4 v5, 0x3

    move v8, v5

    const/4 v7, 0x4

    move v8, v7

    new-array v5, v5, [Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    aput-object v0, v5, v2

    const/4 v8, 0x2

    const/4 v7, 0x1

    aput-object v1, v5, v4

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    aput-object v3, v5, v6

    const/4 v7, 0x0

    move v8, v7

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->value:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public static getZegoMixerInputContentType(I)Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "ua/ of~p~~~ofo@~s tiS@  1@@~  ~-4~@~@~~cb/~  @  .Ml~~no~bK@@@ rl@ tyd@m oi~~v@@o~@@b~@  @@i~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->AUDIO:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-ne v1, p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->VIDEO:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-ne v1, p0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->VIDEO_ONLY:Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v3, 0x2

    const/4 v2, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ne v1, p0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x7

    xor-int/2addr v3, v2

    return-object p0

    :catch_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x0

    const-string/jumbo v0, "rnnoamfoqoea uneu denhb nt ctbi"

    const-string/jumbo v0, "nirnobeamho   tbeteen afnundcuo"

    const/4 v3, 0x2

    const-string/jumbo v0, "musnebT onun tnhi a eodefroaecn"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const-class v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v2, 0x0

    const-class v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;
    .locals 3

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoMixerInputContentType;->value:I

    const/4 v2, 0x3

    return v0
.end method
