.class public final enum Lim/zego/zegoexpress/constants/ZegoOrientation;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoOrientation;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoOrientation;

.field public static final enum ORIENTATION_0:Lim/zego/zegoexpress/constants/ZegoOrientation;

.field public static final enum ORIENTATION_180:Lim/zego/zegoexpress/constants/ZegoOrientation;

.field public static final enum ORIENTATION_270:Lim/zego/zegoexpress/constants/ZegoOrientation;

.field public static final enum ORIENTATION_90:Lim/zego/zegoexpress/constants/ZegoOrientation;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x1

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const-string v1, "NIsTRO0O_sTIN"

    const-string v1, "TOs0OTEI_NINR"

    const/4 v10, 0x1

    const-string v1, "RI0mOOTITAENN"

    const-string v1, "ORIENTATION_0"

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    const/4 v2, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x1

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoOrientation;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoOrientation;->ORIENTATION_0:Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v9, 0x3

    move v10, v9

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-string v3, "TNOIo_NO9mRIET"

    const-string v3, "IITmONRENO9_0T"

    const/4 v10, 0x1

    const-string v3, "TO0_AbIONN9RTE"

    const-string v3, "ORIENTATION_90"

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    const/4 v4, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoOrientation;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x4

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoOrientation;->ORIENTATION_90:Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v10, 0x7

    const/4 v9, 0x0

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    const-string v5, "OTRNo8uNTAO1IIE"

    const-string v5, "1ONToOAIR8TNEI0"

    const/4 v10, 0x7

    const-string v5, "R0NTOANpIT_I8OE"

    const-string v5, "ORIENTATION_180"

    const/4 v10, 0x3

    const/4 v6, 0x2

    const/4 v10, 0x0

    shr-int/2addr v9, v6

    const/4 v10, 0x0

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoOrientation;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoOrientation;->ORIENTATION_180:Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v10, 0x2

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-string v7, "I0TAORTOqN_E7b2"

    const-string v7, "TON0IbRO_TA72NE"

    const/4 v10, 0x1

    const-string v7, "_NsINI7AOTRTEO2"

    const-string v7, "ORIENTATION_270"

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 v8, 0x3

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoOrientation;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoOrientation;->ORIENTATION_270:Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    const/4 v7, 0x4

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    new-array v7, v7, [Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v9, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    aput-object v0, v7, v2

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    aput-object v1, v7, v4

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    aput-object v3, v7, v6

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    aput-object v5, v7, v8

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoOrientation;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoOrientation;->value:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public static getZegoOrientation(I)Lim/zego/zegoexpress/constants/ZegoOrientation;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@.am-~c@ ~@i~@~db 1bfuo /4n @o ty~ @@~ lv~~Mf br~~@@/i~@~~ @~l@o~m~ i@@~o~oS@~o @@    ~ @@sK ~@t"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoOrientation;->ORIENTATION_0:Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoOrientation;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-ne v1, p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoOrientation;->ORIENTATION_90:Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoOrientation;->value:I

    const/4 v2, 0x0

    move v3, v2

    if-ne v1, p0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoOrientation;->ORIENTATION_180:Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoOrientation;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v1, p0, :cond_2

    const/4 v3, 0x5

    return-object v0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoOrientation;->ORIENTATION_270:Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoOrientation;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-ne v1, p0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object p0

    :catch_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v0, "  oeo uteaodhenuirnceu baTfmton"

    const-string/jumbo v0, "uenmeeu aTo cbd enonhutfatniro "

    const/4 v3, 0x5

    const-string/jumbo v0, "ufnoTbe buoecranm  aeodnnihtn t"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoOrientation;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-class v0, Lim/zego/zegoexpress/constants/ZegoOrientation;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v2, 0x5

    const-class v0, Lim/zego/zegoexpress/constants/ZegoOrientation;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoOrientation;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoOrientation;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoOrientation;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x1

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoOrientation;->value:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method
