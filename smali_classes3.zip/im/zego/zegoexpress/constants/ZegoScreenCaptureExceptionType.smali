.class public final enum Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

.field public static final enum ALREADY_STARTED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

.field public static final enum AUDIO_CREATE_FAILED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

.field public static final enum AUDIO_NOT_SUPPORTED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

.field public static final enum FOREGROUND_SERVICE_FAILED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

.field public static final enum MEDIA_PROJECTION_PERMISSION_DENIED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

.field public static final enum NOT_START_CAPTURE:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

.field public static final enum SOURCE_NOT_SPECIFIED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

.field public static final enum SYSTEM_ERROR:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

.field public static final enum UNKNOWN:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

.field public static final enum VIDEO_NOT_SUPPORTED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-string v1, "OKsUWsN"

    const-string v1, "NOsWUKN"

    const-string v1, "NWNmUKO"

    const-string v1, "UNKNOWN"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-string v3, "PONOoETERmOP_VDU_TD"

    const-string v3, "I_DmUTTOEVDOPRPON_E"

    const-string v3, "_SNIDbPROETVDTOPEO_"

    const-string v3, "VIDEO_NOT_SUPPORTED"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->VIDEO_NOT_SUPPORTED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-string v5, "RUO_oTu_OADNTPIUODE"

    const-string v5, "RDT_oTDPOAIOUS_ENOU"

    const-string v5, "PETUP_DpIOTSRNODUAO"

    const-string v5, "AUDIO_NOT_SUPPORTED"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->AUDIO_NOT_SUPPORTED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-string v7, "C_EOE_IEqTURAAFbLDA"

    const-string v7, "ELDTUbE_IFA_DECARAO"

    const-string v7, "IUsOR_IADEECALFTDAE"

    const-string v7, "AUDIO_CREATE_FAILED"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->AUDIO_CREATE_FAILED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-string v9, "NS_mESDEO_MJIE_NOTIMIOuIIPEERDRNCD"

    const-string v9, "EIRDOIuED__OPMNOMIIRENEP_SJSICNTDE"

    const-string v9, "JMSEoOIIDDPO_TNNRIS_AMEIOCEED_PNIE"

    const-string v9, "MEDIA_PROJECTION_PERMISSION_DENIED"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->MEDIA_PROJECTION_PERMISSION_DENIED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-string v11, "TTS_AbAPRTCNORET_"

    const-string v11, "NOT_START_CAPTURE"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->NOT_START_CAPTURE:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    new-instance v11, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-string v13, "ApSERTuDY_LTDAA"

    const-string v13, "AAARTY_pESRLDDT"

    const-string v13, "EATEDD_pTLRYARA"

    const-string v13, "ALREADY_STARTED"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14, v14}, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->ALREADY_STARTED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    new-instance v13, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-string v15, "FEDI_RNOqCIFqDGEERA_VESUR"

    const-string v15, "ERRIENEFqRVALI_DCDUSOGFE_"

    const-string v15, "ERsNI_EU_ROCGIFVERDDSLEOA"

    const-string v15, "FOREGROUND_SERVICE_FAILED"

    const/4 v14, 0x7

    invoke-direct {v13, v15, v14, v14}, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v13, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->FOREGROUND_SERVICE_FAILED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    new-instance v15, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-string v14, "RN_mFsDTOISSE_PUOEIC"

    const-string v14, "E_sUETFIOSNCDIP_SEOR"

    const-string v14, "CCEDoROFOEUSE_TIISNP"

    const-string v14, "SOURCE_NOT_SPECIFIED"

    const/16 v12, 0x8

    invoke-direct {v15, v14, v12, v12}, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v15, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->SOURCE_NOT_SPECIFIED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    new-instance v14, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-string v12, "REEYTbmOSSMR"

    const-string v12, "YRSmERSRMEOT"

    const-string v12, "TEERSMuO_RYS"

    const-string v12, "SYSTEM_ERROR"

    const/16 v10, 0x9

    invoke-direct {v14, v12, v10, v10}, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;-><init>(Ljava/lang/String;II)V

    sput-object v14, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->SYSTEM_ERROR:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/16 v12, 0xa

    new-array v12, v12, [Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    aput-object v0, v12, v2

    aput-object v1, v12, v4

    aput-object v3, v12, v6

    aput-object v5, v12, v8

    const/4 v0, 0x4

    aput-object v7, v12, v0

    const/4 v0, 0x5

    aput-object v9, v12, v0

    const/4 v0, 0x6

    aput-object v11, v12, v0

    const/4 v0, 0x7

    aput-object v13, v12, v0

    const/16 v0, 0x8

    aput-object v15, v12, v0

    aput-object v14, v12, v10

    sput-object v12, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->value:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public static getZegoScreenCaptureExceptionType(I)Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@ oSvbpm~~K~@ ~~@ao~d/@ot @@iit li@ n ~y~~/~  @@ uo@f@@@~  @o~~ls~~ @bM@~  ~~@@.r1~@ 4 -oc~~b@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-ne v1, p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->VIDEO_NOT_SUPPORTED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-ne v1, p0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->AUDIO_NOT_SUPPORTED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-ne v1, p0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->AUDIO_CREATE_FAILED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-ne v1, p0, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->MEDIA_PROJECTION_PERMISSION_DENIED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ne v1, p0, :cond_4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->NOT_START_CAPTURE:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->value:I

    const/4 v2, 0x7

    move v3, v2

    if-ne v1, p0, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0

    :cond_5
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->ALREADY_STARTED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v1, p0, :cond_6

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_6
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->FOREGROUND_SERVICE_FAILED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-ne v1, p0, :cond_7

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0

    :cond_7
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->SOURCE_NOT_SPECIFIED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-ne v1, p0, :cond_8

    const/4 v3, 0x3

    return-object v0

    :cond_8
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->SYSTEM_ERROR:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    move v3, v2

    if-ne v1, p0, :cond_9

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0

    :cond_9
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object p0

    :catch_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string v0, "botTco dqnutanm euaoeiornhen f "

    const-string v0, "acerouaoboutTmd nhnn eo  intnef"

    const/4 v3, 0x1

    const-string/jumbo v0, "nnsndmTnhaba on tceefo etiueru "

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-class v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->value:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    return v0
.end method
