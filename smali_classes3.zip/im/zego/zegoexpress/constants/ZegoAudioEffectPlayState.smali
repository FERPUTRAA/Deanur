.class public final enum Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

.field public static final enum NO_PLAY:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

.field public static final enum PAUSING:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

.field public static final enum PLAYING:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

.field public static final enum PLAY_ENDED:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v9, 0x5

    xor-int/2addr v10, v9

    const-string v1, "NssP_OY"

    const-string v1, "_NsYOPL"

    const/4 v10, 0x4

    const-string v1, "YP_mONA"

    const-string v1, "NO_PLAY"

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    const/4 v2, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->NO_PLAY:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    const-string v3, "LIGmNPY"

    const/4 v10, 0x3

    const-string v3, "NYALoIG"

    const-string v3, "PLAYING"

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    const/4 v4, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->PLAYING:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    const-string v5, "NAPSobG"

    const-string v5, "AIPSoGN"

    const-string v5, "UPNSAGu"

    const-string v5, "PAUSING"

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v6, 0x2

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->PAUSING:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-string v7, "NDbD_PApYE"

    const-string v7, "_LDDEbNYAP"

    const-string v7, "YDE_NLDPqE"

    const-string v7, "PLAY_ENDED"

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    const/4 v8, 0x3

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x6

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->PLAY_ENDED:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v9, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x4

    const/4 v7, 0x4

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    new-array v7, v7, [Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    aput-object v0, v7, v2

    const/4 v9, 0x3

    shr-int/2addr v10, v9

    aput-object v1, v7, v4

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    aput-object v3, v7, v6

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    aput-object v5, v7, v8

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->value:I

    const/4 v1, 0x7

    return-void
.end method

.method public static getZegoAudioEffectPlayState(I)Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "c@s~d@-~~  o@ym@@ @fM@~~~S oo@~sK~ ~vti@/   @~@@~i  @~ /. l~@u l@~~@b~ tf~@ob @o@r~bio~  ~n4~1a~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->NO_PLAY:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->value:I

    const/4 v2, 0x2

    move v3, v2

    if-ne v1, p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->PLAYING:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v1, p0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->PAUSING:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-ne v1, p0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->PLAY_ENDED:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-ne v1, p0, :cond_3

    const/4 v3, 0x5

    return-object v0

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p0

    :catch_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v0, "n omrchad nefaeuem t oTenniuntu"

    const-string/jumbo v0, "utae  u nTtdinoaonmhufrecne enb"

    const-string v0, "ceidobunhn metnaon eoTt  enauro"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v2, 0x5

    const/4 v1, 0x2

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;
    .locals 3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->value:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method
