.class public final enum Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

.field public static final enum ANY_BACKGROUND:Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

.field public static final enum GREEN_SCREEN_BACKGROUND:Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v5, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string v1, "RCsABAUsDYONK_"

    const-string v1, "AGsABCRK_YDONU"

    const-string v1, "OGAmURNBYA_KCN"

    const-string v1, "ANY_BACKGROUND"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;-><init>(Ljava/lang/String;II)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->ANY_BACKGROUND:Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v6, 0x7

    const/4 v5, 0x4

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v3, "_EGCoBRREOGAN_ENUESRKCD"

    const-string v3, "GREEN_SCREEN_BACKGROUND"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    const/4 v4, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;-><init>(Ljava/lang/String;II)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->GREEN_SCREEN_BACKGROUND:Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v3, 0x2

    const/4 v6, 0x7

    new-array v3, v3, [Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    aput-object v0, v3, v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    aput-object v1, v3, v4

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->value:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public static getZegoObjectSegmentationType(I)Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " -/m bd@ S t@@i~ft @oc@v~@@~@~~4sfni~o@ ~o~~~  /olo~~~1~u~@ b~  @~~@@i~ ~@~a Kb@ .@ r loM@~@@b@y"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->ANY_BACKGROUND:Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ne v1, p0, :cond_0

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->GREEN_SCREEN_BACKGROUND:Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    if-ne v1, p0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0

    :cond_1
    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p0

    :catch_0
    const/4 v2, 0x1

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const-string/jumbo v0, "uhomfeu nocaein nrmebTne tundat"

    const-string/jumbo v0, "naimroet   n necomfhutneTdubaen"

    const/4 v3, 0x2

    const-string v0, "dorneTopeen iuhubac nn enomat t"

    const-string v0, "The enumeration cannot be found"

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-class v0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v2, 0x3

    const-class v0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->value:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method
