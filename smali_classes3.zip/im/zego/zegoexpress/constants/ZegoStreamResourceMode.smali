.class public final enum Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

.field public static final enum CDN_PLUS:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

.field public static final enum DEFAULT:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

.field public static final enum ONLY_CDN:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

.field public static final enum ONLY_L3:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

.field public static final enum ONLY_RTC:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 13

    const/4 v12, 0x0

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x7

    const-string v1, "ADssUEF"

    const-string v1, "FEsLUDA"

    const/4 v12, 0x3

    const-string v1, "TFLmDEU"

    const-string v1, "DEFAULT"

    const/4 v11, 0x2

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;-><init>(Ljava/lang/String;II)V

    const/4 v11, 0x1

    or-int/2addr v12, v11

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v11, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x1

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x7

    const-string v3, "COYLomDN"

    const-string v3, "NCDmYLNO"

    const/4 v12, 0x6

    const-string v3, "NYDLNbO_"

    const-string v3, "ONLY_CDN"

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    const/4 v4, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;-><init>(Ljava/lang/String;II)V

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->ONLY_CDN:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x1

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x6

    const-string v5, "YoLL3Nu"

    const-string v5, "L3YOoNL"

    const/4 v12, 0x1

    const-string/jumbo v5, "p_NL3OY"

    const-string v5, "ONLY_L3"

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/4 v6, 0x2

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;-><init>(Ljava/lang/String;II)V

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x7

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->ONLY_L3:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x0

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x4

    const-string/jumbo v7, "qONRLb_C"

    const-string v7, "LC_ONbRT"

    const/4 v12, 0x3

    const-string v7, "CRsOYTL_"

    const-string v7, "ONLY_RTC"

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x4

    const/4 v8, 0x3

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x0

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;-><init>(Ljava/lang/String;II)V

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->ONLY_RTC:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x3

    const-string v9, "D_CmSPuU"

    const-string v9, "DCS_ULuP"

    const/4 v12, 0x2

    const-string v9, "LSDNoC_U"

    const-string v9, "CDN_PLUS"

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x7

    const/4 v10, 0x4

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;-><init>(Ljava/lang/String;II)V

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x3

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->CDN_PLUS:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/4 v9, 0x5

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x2

    new-array v9, v9, [Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    aput-object v0, v9, v2

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x7

    aput-object v1, v9, v4

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x0

    aput-object v3, v9, v6

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x2

    aput-object v5, v9, v8

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x2

    aput-object v7, v9, v10

    const/4 v11, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->value:I

    const/4 v0, 0x3

    const/4 v0, 0x0

    return-void
.end method

.method public static getZegoStreamResourceMode(I)Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ ~@mb~ i @~@fti~~@y~fb~ -avn @~~oo ~~  s@o @~@KM~loS  @c@@ .t @/@4~ ~~1io /bud ~~~@~~@@r@o bl@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ne v1, p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->ONLY_CDN:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-ne v1, p0, :cond_1

    const/4 v3, 0x1

    return-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->ONLY_L3:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    if-ne v1, p0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->ONLY_RTC:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-ne v1, p0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0

    :cond_3
    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->CDN_PLUS:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    if-ne v1, p0, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object v0

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p0

    :catch_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v0, "aiu ebuttnnoed noTfa op ehemucn"

    const-string v0, "ennnmnapi eutooe  fnua dtcTeobh"

    const/4 v3, 0x2

    const-string/jumbo v0, "nifeuaapn T d noeotoehremctnnbu"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->value:I

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method
