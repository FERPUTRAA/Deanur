.class public final enum Lim/zego/zegoexpress/constants/ZegoReverbPreset;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoReverbPreset;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum BASEMENT:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum CONCERT_HALL:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum ENHANCED_KTV:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum GRAMO_PHONE:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum KTV:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum LARGE_ROOM:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum NONE:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum POPULAR:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum RECORDING_STUDIO:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum ROCK:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum SOFT_ROOM:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum VALLEY:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

.field public static final enum VOCAL_CONCERT:Lim/zego/zegoexpress/constants/ZegoReverbPreset;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string v1, "NONE"

    const-string v1, "NOEN"

    const-string v1, "NNOE"

    const-string v1, "NONE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->NONE:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string v3, "_RsOOsMFS"

    const-string v3, "S_sOOFROM"

    const-string v3, "ORFmOSO_M"

    const-string v3, "SOFT_ROOM"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->SOFT_ROOM:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string v5, "E_OAomGRLR"

    const-string v5, "E_RmOLRAOG"

    const-string v5, "G_OLAbERRO"

    const-string v5, "LARGE_ROOM"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->LARGE_ROOM:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string v7, "CAOLCRuNoH_E"

    const-string v7, "NATRoHCCEL_O"

    const-string v7, "CNRHCO_pLTAL"

    const-string v7, "CONCERT_HALL"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->CONCERT_HALL:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string v9, "AEqVLY"

    const-string v9, "VALLEY"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->VALLEY:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string v11, "bEsGOTDICSRUID_N"

    const-string v11, "SCIO_bDGERNIRUDT"

    const-string v11, "_CEmGNOURDSRODII"

    const-string v11, "RECORDING_STUDIO"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->RECORDING_STUDIO:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    new-instance v11, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string/jumbo v13, "uSEBoEAT"

    const-string v13, "SEEBTNuA"

    const-string v13, "EMEBAbTS"

    const-string v13, "BASEMENT"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14, v14}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->BASEMENT:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    new-instance v13, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string v15, "KVT"

    const-string v15, "VKT"

    const-string v15, "KTV"

    const/4 v14, 0x7

    invoke-direct {v13, v15, v14, v14}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v13, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->KTV:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    new-instance v15, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string v14, "ALOUPPu"

    const-string v14, "POPULAR"

    const/16 v12, 0x8

    invoke-direct {v15, v14, v12, v12}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v15, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->POPULAR:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    new-instance v14, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string v12, "CKOR"

    const-string v12, "COKR"

    const-string v12, "KCOR"

    const-string v12, "ROCK"

    const/16 v10, 0x9

    invoke-direct {v14, v12, v10, v10}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v14, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->ROCK:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    new-instance v12, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string v10, "OCpTAC_pOVNRC"

    const-string v10, "VCOALCOp_CTNR"

    const-string v10, "VOCAL_CONCERT"

    const/16 v8, 0xa

    invoke-direct {v12, v10, v8, v8}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v12, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->VOCAL_CONCERT:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    new-instance v10, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string/jumbo v8, "qHOO_ANEqPR"

    const-string v8, "OHAREONPq_M"

    const-string v8, "PMsROGENOA_"

    const-string v8, "GRAMO_PHONE"

    const/16 v6, 0xb

    invoke-direct {v10, v8, v6, v6}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v10, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->GRAMO_PHONE:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    new-instance v8, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-string v6, "EECmHKTADsN_"

    const-string v6, "KTs_HDNNEEAC"

    const-string v6, "HKTDo_VCNANE"

    const-string v6, "ENHANCED_KTV"

    const/16 v4, 0xc

    invoke-direct {v8, v6, v4, v4}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;-><init>(Ljava/lang/String;II)V

    sput-object v8, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->ENHANCED_KTV:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/16 v6, 0xd

    new-array v6, v6, [Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    aput-object v0, v6, v2

    const/4 v0, 0x1

    aput-object v1, v6, v0

    const/4 v0, 0x2

    aput-object v3, v6, v0

    const/4 v0, 0x3

    aput-object v5, v6, v0

    const/4 v0, 0x4

    aput-object v7, v6, v0

    const/4 v0, 0x5

    aput-object v9, v6, v0

    const/4 v0, 0x6

    aput-object v11, v6, v0

    const/4 v0, 0x7

    aput-object v13, v6, v0

    const/16 v0, 0x8

    aput-object v15, v6, v0

    const/16 v0, 0x9

    aput-object v14, v6, v0

    const/16 v0, 0xa

    aput-object v12, v6, v0

    const/16 v0, 0xb

    aput-object v10, v6, v0

    aput-object v8, v6, v4

    sput-object v6, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x1

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public static getZegoReverbPreset(I)Lim/zego/zegoexpress/constants/ZegoReverbPreset;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "-nl@obmy/1 @t~@@~K c~~~ ~bl~@@~@~a~@o@~ /  @~sr~b~.i4 ~@ @@if@@@~ @Sdu~~ i @ o fo b~@oov~ @ ~tM "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->NONE:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v2, 0x2

    move v3, v2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-ne v1, p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->SOFT_ROOM:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-ne v1, p0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->LARGE_ROOM:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-ne v1, p0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->CONCERT_HALL:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-ne v1, p0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->VALLEY:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-ne v1, p0, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0

    :cond_4
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->RECORDING_STUDIO:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-ne v1, p0, :cond_5

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0

    :cond_5
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->BASEMENT:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-ne v1, p0, :cond_6

    const/4 v3, 0x5

    const/4 v2, 0x3

    return-object v0

    :cond_6
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->KTV:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v2, 0x5

    or-int/2addr v3, v2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-ne v1, p0, :cond_7

    const/4 v3, 0x0

    const/4 v2, 0x2

    return-object v0

    :cond_7
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->POPULAR:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    if-ne v1, p0, :cond_8

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0

    :cond_8
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->ROCK:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ne v1, p0, :cond_9

    const/4 v3, 0x7

    const/4 v2, 0x3

    return-object v0

    :cond_9
    const/4 v3, 0x7

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->VOCAL_CONCERT:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-ne v1, p0, :cond_a

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0

    :cond_a
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->GRAMO_PHONE:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    if-ne v1, p0, :cond_b

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0

    :cond_b
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->ENHANCED_KTV:Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-ne v1, p0, :cond_c

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v0

    :cond_c
    const/4 v2, 0x4

    move v3, v2

    const/4 p0, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object p0

    :catch_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v0, " oau huomeennmTbtrtee nnucf iad"

    const-string/jumbo v0, "ottm cTfuoumnoaean en hredne ib"

    const/4 v3, 0x0

    const-string/jumbo v0, "n  tubepoahftodoTimcnnnu eeaenr"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoReverbPreset;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v2, 0x4

    const-class v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoReverbPreset;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoReverbPreset;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoReverbPreset;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method
