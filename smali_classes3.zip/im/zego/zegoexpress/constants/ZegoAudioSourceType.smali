.class public final enum Lim/zego/zegoexpress/constants/ZegoAudioSourceType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoAudioSourceType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

.field public static final enum CUSTOM:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

.field public static final enum DEFAULT:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

.field public static final enum MAIN_PUBLISH_CHANNEL:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

.field public static final enum MEDIA_PLAYER:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

.field public static final enum MICROPHONE:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

.field public static final enum NONE:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

.field public static final enum SCREEN_CAPTURE:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 15

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const-string/jumbo v1, "sEsDTUL"

    const-string v1, "DTsFLEU"

    const-string v1, "UELmAFT"

    const-string v1, "DEFAULT"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const-string v3, "MTCOoU"

    const-string v3, "CUSTOM"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->CUSTOM:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const-string v5, "DR_MPbEEAmAY"

    const-string v5, "DAEmAPEMYI_R"

    const-string v5, "MEDIA_PLAYER"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->MEDIA_PLAYER:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const-string v7, "ENON"

    const-string v7, "NNEO"

    const-string v7, "ONEN"

    const-string v7, "NONE"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->NONE:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const-string v9, "MOoOERuPCI"

    const-string v9, "EPRMoCIHOO"

    const-string v9, "IOECORMpNP"

    const-string v9, "MICROPHONE"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->MICROPHONE:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const-string v11, "AHL_UIMSqNLBENHIAPNC"

    const-string v11, "HN_INbAPLIAHMNESULBC"

    const-string v11, "NCsSAPB_ULIHIHEN_MLN"

    const-string v11, "MAIN_PUBLISH_CHANNEL"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->MAIN_PUBLISH_CHANNEL:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    new-instance v11, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const-string v13, "CCumPAR_ESNUER"

    const-string v13, "TC_ERCuRAUPENS"

    const-string v13, "SN_EoTEPCEURCR"

    const-string v13, "SCREEN_CAPTURE"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14, v14}, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->SCREEN_CAPTURE:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v13, 0x7

    new-array v13, v13, [Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    aput-object v0, v13, v2

    aput-object v1, v13, v4

    aput-object v3, v13, v6

    aput-object v5, v13, v8

    aput-object v7, v13, v10

    aput-object v9, v13, v12

    aput-object v11, v13, v14

    sput-object v13, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->value:I

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public static getZegoAudioSourceType(I)Lim/zego/zegoexpress/constants/ZegoAudioSourceType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@/~ b@@~mu~@f ~ ybav@.~~~@@~t@il loMf~@~~d~ro  @cs@~~bo1@o@iK S@ @b~@~/oo@~ ~ n   @@i~~~ 4t   -"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-ne v1, p0, :cond_0

    const/4 v2, 0x3

    move v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->CUSTOM:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-ne v1, p0, :cond_1

    const/4 v3, 0x1

    return-object v0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->MEDIA_PLAYER:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    if-ne v1, p0, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x5

    return-object v0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->NONE:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->value:I

    if-ne v1, p0, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->MICROPHONE:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-ne v1, p0, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v0

    :cond_4
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->MAIN_PUBLISH_CHANNEL:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-ne v1, p0, :cond_5

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object v0

    :cond_5
    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->SCREEN_CAPTURE:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-ne v1, p0, :cond_6

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0

    :cond_6
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object p0

    :catch_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v0, "naebouuacfee rpunotnnTdoim et h"

    const-string/jumbo v0, "hbont ipeut onacTfnn ueeaemrndo"

    const/4 v3, 0x1

    const-string/jumbo v0, "menuafrpoc nonhn doei btTtea ue"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoAudioSourceType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v2, 0x3

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v2, 0x0

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoAudioSourceType;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->value:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method
