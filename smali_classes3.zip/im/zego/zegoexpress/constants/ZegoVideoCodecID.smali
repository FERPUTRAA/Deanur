.class public final enum Lim/zego/zegoexpress/constants/ZegoVideoCodecID;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoVideoCodecID;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

.field public static final enum DEFAULT:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

.field public static final enum H264_DUAL_STREAM:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

.field public static final enum H265:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

.field public static final enum SVC:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

.field public static final enum UNKNOWN:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

.field public static final enum VP8:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 15

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x5

    const-string v1, "FUsTsAD"

    const-string v1, "UFsDATL"

    const-string v1, "TUEmLFA"

    const-string v1, "DEFAULT"

    const/4 v14, 0x7

    const/4 v2, 0x0

    const/4 v14, 0x6

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x0

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x6

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x2

    const-string v3, "VSC"

    const-string v3, "CVS"

    const-string v3, "SCV"

    const-string v3, "SVC"

    const/4 v14, 0x5

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x2

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->SVC:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x7

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x7

    const-string v5, "P8V"

    const-string v5, "P8V"

    const-string v5, "P8V"

    const-string v5, "VP8"

    const/4 v14, 0x7

    const/4 v6, 0x2

    const/4 v14, 0x4

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->VP8:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x6

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x6

    const-string v7, "6H52"

    const-string v7, "52H6"

    const-string v7, "2H65"

    const-string v7, "H265"

    const/4 v14, 0x1

    const/4 v8, 0x3

    const/4 v14, 0x0

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x6

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->H265:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x1

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x7

    const-string/jumbo v9, "m4M2oLADRSHATU__"

    const-string v9, "H_RmEMUS4ALTA_2D"

    const-string v9, "2__6RbUMATH4EDAL"

    const-string v9, "H264_DUAL_STREAM"

    const/4 v14, 0x4

    const/4 v10, 0x4

    const/4 v14, 0x1

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x3

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->H264_DUAL_STREAM:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x3

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x5

    const/16 v11, 0x64

    const-string v12, "NNKWUOu"

    const-string v12, "OKWUoNN"

    const-string/jumbo v12, "pNWONKU"

    const-string v12, "UNKNOWN"

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x5

    invoke-direct {v9, v12, v13, v11}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x6

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x6

    const/4 v11, 0x6

    new-array v11, v11, [Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x6

    aput-object v0, v11, v2

    const/4 v14, 0x2

    aput-object v1, v11, v4

    const/4 v14, 0x6

    aput-object v3, v11, v6

    const/4 v14, 0x5

    aput-object v5, v11, v8

    const/4 v14, 0x7

    aput-object v7, v11, v10

    aput-object v9, v11, v13

    const/4 v14, 0x3

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v14, 0x5

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public static getZegoVideoCodecID(I)Lim/zego/zegoexpress/constants/ZegoVideoCodecID;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "4is@@~l~q@~bo~@~ -/@bd~/i~ ~@fm @~@~@1v@@~.o iuco  @ o~t~@@@@~ ~t@~ @M~oay~S~K@~n  l   @~rob  f "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ne v1, p0, :cond_0

    const/4 v2, 0x5

    move v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->SVC:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v1, p0, :cond_1

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->VP8:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v2, 0x0

    move v3, v2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v1, p0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object v0

    :cond_2
    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->H265:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-ne v1, p0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x2

    return-object v0

    :cond_3
    const/4 v3, 0x2

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->H264_DUAL_STREAM:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value:I

    const/4 v3, 0x2

    if-ne v1, p0, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-ne v1, p0, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_5
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v2, 0x4

    and-int/2addr v3, v2

    return-object p0

    :catch_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string v0, " osubuTnmenf  iodhtnoneeneratba"

    const-string/jumbo v0, "heenobmTnnadnruf atu entbi  eoo"

    const/4 v3, 0x6

    const-string/jumbo v0, "huemncubm  ontenfea nrentaoTi d"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoVideoCodecID;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoVideoCodecID;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v2, 0x0

    const/4 v1, 0x2

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value:I

    const/4 v1, 0x3

    move v2, v1

    return v0
.end method
