.class public final enum Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_ACCOMPANIMENT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_ACCOMPANIMENT_CLIP:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_ACCOMPANIMENT_SEGMENT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_SONG:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_SONG_HQ:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_SONG_SQ:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 15

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x7

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x3

    const-string v1, "ESs_OUO__GIYIHMONGRsCESPTDG"

    const-string v1, "SDsZIUYHEONSRGIEOCMO___GPGT"

    const/4 v14, 0x0

    const-string v1, "NOUmE_MPIHSRO_DGY_OCSIGZEGT"

    const-string v1, "ZEGO_COPYRIGHTED_MUSIC_SONG"

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v14, 0x3

    const/4 v2, 0x0

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x6

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x6

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->ZEGO_COPYRIGHTED_MUSIC_SONG:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v14, 0x4

    const/4 v13, 0x3

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x1

    const-string v3, "RG_IoCPSOEHCMmTGSGE__DOQYUNHZ_"

    const-string v3, "SOUmGGTIP_YCEHMCGOHQ_IRNS__ZDE"

    const/4 v14, 0x7

    const-string v3, "ZEGO_COPYRIGHTED_MUSIC_SONG_HQ"

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x5

    const/4 v4, 0x1

    const/4 v14, 0x4

    const/4 v13, 0x3

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x7

    const/4 v13, 0x6

    const/4 v14, 0x0

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->ZEGO_COPYRIGHTED_MUSIC_SONG_HQ:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x3

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x2

    const-string v5, "__CRIb_TQYSIHUSGOOPZNMSDGG_EOE"

    const-string v5, "ZEGO_COPYRIGHTED_MUSIC_SONG_SQ"

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x2

    const/4 v6, 0x2

    const/4 v14, 0x5

    const/4 v13, 0x1

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x4

    const/4 v13, 0x6

    const/4 v14, 0x3

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->ZEGO_COPYRIGHTED_MUSIC_SONG_SQ:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v13, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x2

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x1

    const-string v7, "AIPOTHuYDMNOMO___RECUPZACGNIToMCGECI"

    const-string v7, "A_PDoPMYSO_NGIET_MCUNCICRAGOOEZMHTIC"

    const/4 v14, 0x4

    const-string v7, "HIYIOZOpCNEOICSEPMANEMCCMT_RTGGU_A_D"

    const-string v7, "ZEGO_COPYRIGHTED_MUSIC_ACCOMPANIMENT"

    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x6

    const/4 v8, 0x3

    const/4 v14, 0x4

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x0

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->ZEGO_COPYRIGHTED_MUSIC_ACCOMPANIMENT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x6

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x4

    const-string v9, "PYNAAD_NqRTCOMGCITU_H_GOMZPEEPMIOCSCLII_C"

    const-string v9, "ZEGO_COPYRIGHTED_MUSIC_ACCOMPANIMENT_CLIP"

    const/4 v14, 0x7

    const/4 v13, 0x6

    const/4 v14, 0x4

    const/4 v10, 0x4

    const/4 v14, 0x5

    const/4 v13, 0x5

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x7

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->ZEGO_COPYRIGHTED_MUSIC_ACCOMPANIMENT_CLIP:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x2

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v13, 0x1

    const/4 v14, 0x7

    const-string v11, "_NsGG_MIMCANSRIPYD_OZHEbOOTIMEACSTPNUCTGECE_"

    const-string v11, "ENEYNbZEMN_IET_GH_A_PRMCGICMSCGADOSTIMCTOOUP"

    const/4 v14, 0x6

    const-string v11, "TCEmUASMZEOSPGIYIM_DOMCGNPNC_EMTGA_RNCIOE_HE"

    const-string v11, "ZEGO_COPYRIGHTED_MUSIC_ACCOMPANIMENT_SEGMENT"

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x6

    const/4 v12, 0x5

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x1

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x2

    const/4 v13, 0x2

    const/4 v14, 0x7

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->ZEGO_COPYRIGHTED_MUSIC_ACCOMPANIMENT_SEGMENT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x2

    const/4 v11, 0x6

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x6

    new-array v11, v11, [Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x5

    aput-object v0, v11, v2

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x0

    aput-object v1, v11, v4

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x4

    aput-object v3, v11, v6

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x5

    aput-object v5, v11, v8

    const/4 v14, 0x4

    const/4 v13, 0x3

    const/4 v14, 0x1

    aput-object v7, v11, v10

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x2

    aput-object v9, v11, v12

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x5

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x4

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->value:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public static getZegoCopyrightedMusicType(I)Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~~@o~@~~-~ri~@~ @@@  n@@ @~~fdf @ b/toc @K l@ou4~ami/  @~s ~@li~~b o~St~ @@~b M@y~.@@o~~ov1 ~o "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->ZEGO_COPYRIGHTED_MUSIC_SONG:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-ne v1, p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->ZEGO_COPYRIGHTED_MUSIC_SONG_HQ:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-ne v1, p0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->ZEGO_COPYRIGHTED_MUSIC_SONG_SQ:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-ne v1, p0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->ZEGO_COPYRIGHTED_MUSIC_ACCOMPANIMENT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-ne v1, p0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->ZEGO_COPYRIGHTED_MUSIC_ACCOMPANIMENT_CLIP:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ne v1, p0, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0

    :cond_4
    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->ZEGO_COPYRIGHTED_MUSIC_ACCOMPANIMENT_SEGMENT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    if-ne v1, p0, :cond_5

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_5
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object p0

    :catch_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x5

    const-string v0, " aorbbTuonn ndetfihe uuat cenen"

    const-string/jumbo v0, "ntb a uT udoneaneu homcfritneen"

    const-string/jumbo v0, "ri ueouneatTtf nnonea bho endcu"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v2, 0x7

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;
    .locals 3

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicType;->value:I

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method
