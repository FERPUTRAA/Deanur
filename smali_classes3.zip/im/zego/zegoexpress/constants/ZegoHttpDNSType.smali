.class public final enum Lim/zego/zegoexpress/constants/ZegoHttpDNSType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoHttpDNSType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

.field public static final enum ALIYUN:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

.field public static final enum NONE:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

.field public static final enum TENCENT:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

.field public static final enum WANGSU:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v9, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-string v1, "ONEN"

    const-string v1, "NEON"

    const/4 v10, 0x6

    const-string v1, "OENN"

    const-string v1, "NONE"

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x4

    const/4 v2, 0x0

    const/4 v9, 0x4

    and-int/2addr v10, v9

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->NONE:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-string/jumbo v3, "sAsGWU"

    const-string v3, "GSsWUA"

    const/4 v10, 0x3

    const-string v3, "NAWmGS"

    const-string v3, "WANGSU"

    const/4 v9, 0x6

    move v10, v9

    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v9, 0x0

    move v10, v9

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->WANGSU:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x5

    const-string/jumbo v5, "mCNNoEE"

    const-string v5, "ENTmECN"

    const/4 v10, 0x2

    const-string v5, "CTTENbN"

    const-string v5, "TENCENT"

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/4 v6, 0x2

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x0

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->TENCENT:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const-string/jumbo v7, "uNUoIY"

    const-string v7, "LYIUoN"

    const/4 v10, 0x0

    const-string v7, "YpINLA"

    const-string v7, "ALIYUN"

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    const/4 v8, 0x3

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x5

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->ALIYUN:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    const/4 v7, 0x4

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    new-array v7, v7, [Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    aput-object v0, v7, v2

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    aput-object v1, v7, v4

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    aput-object v3, v7, v6

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    aput-object v5, v7, v8

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v9, 0x7

    shr-int/2addr v10, v9

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->value:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public static getZegoHttpDNSType(I)Lim/zego/zegoexpress/constants/ZegoHttpDNSType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " f /~@ @q@~@m~@~ K ~n@c  ~ id@~~o a oo@~l~@b@M~~ro l /y@@@1t i~@u ~~~4 o@@@.~v~S ti~@-~bof s~@b@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->NONE:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-ne v1, p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->WANGSU:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ne v1, p0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->TENCENT:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-ne v1, p0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->ALIYUN:Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v3, 0x0

    const/4 v2, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ne v1, p0, :cond_3

    const/4 v2, 0x2

    return-object v0

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p0

    :catch_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string/jumbo v0, "onsnftbhennud eoa ot rembceiT a"

    const-string/jumbo v0, "nnennboremi fa u uctoTbhated oe"

    const/4 v3, 0x7

    const-string/jumbo v0, "o emncoohrnadn e uenTanmettiufb"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoHttpDNSType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-class v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v1, 0x3

    and-int/2addr v2, v1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoHttpDNSType;
    .locals 3

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoHttpDNSType;

    const/4 v2, 0x1

    const/4 v1, 0x6

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoHttpDNSType;->value:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method
