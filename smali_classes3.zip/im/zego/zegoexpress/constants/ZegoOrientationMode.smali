.class public final enum Lim/zego/zegoexpress/constants/ZegoOrientationMode;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoOrientationMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoOrientationMode;

.field public static final enum ADAPTION:Lim/zego/zegoexpress/constants/ZegoOrientationMode;

.field public static final enum ALIGNMENT:Lim/zego/zegoexpress/constants/ZegoOrientationMode;

.field public static final enum CUSTOM:Lim/zego/zegoexpress/constants/ZegoOrientationMode;

.field public static final enum FIXED_RESOLUTION_RATIO:Lim/zego/zegoexpress/constants/ZegoOrientationMode;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    const-string v1, "CUsSOT"

    const/4 v10, 0x2

    const-string v1, "OUsMCT"

    const-string v1, "CUSTOM"

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    const/4 v2, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoOrientationMode;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->CUSTOM:Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-string v3, "PIAmDTOA"

    const-string v3, "ADAmTPIO"

    const/4 v10, 0x1

    const-string v3, "PAAToIDN"

    const-string v3, "ADAPTION"

    const/4 v10, 0x3

    const/4 v4, 0x1

    const/4 v10, 0x7

    move v9, v4

    const/4 v10, 0x4

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoOrientationMode;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->ADAPTION:Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    const-string v5, "AGNNobLMI"

    const-string v5, "MAILoGNTN"

    const/4 v10, 0x2

    const-string v5, "NIMAGEuTL"

    const-string v5, "ALIGNMENT"

    const/4 v10, 0x6

    const/4 v6, 0x7

    const/4 v10, 0x5

    const/4 v6, 0x2

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoOrientationMode;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->ALIGNMENT:Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v10, 0x1

    const/4 v9, 0x2

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const-string v7, "OISAEUFpRITN_TIERDOLbO"

    const-string v7, "E__NTbEUFIDIOSOTOAIRLR"

    const/4 v10, 0x6

    const-string v7, "L_TIOONEqRRIOF_DTXEUAS"

    const-string v7, "FIXED_RESOLUTION_RATIO"

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 v8, 0x3

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoOrientationMode;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x7

    const/4 v9, 0x1

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->FIXED_RESOLUTION_RATIO:Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/4 v7, 0x4

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    new-array v7, v7, [Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x6

    aput-object v0, v7, v2

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    aput-object v1, v7, v4

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    aput-object v3, v7, v6

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    aput-object v5, v7, v8

    const/4 v10, 0x2

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->value:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public static getZegoOrientationMode(I)Lim/zego/zegoexpress/constants/ZegoOrientationMode;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o~sf ~o~  @c@4o@@i@@~~~ ~~ / @l@@b~ dtb@@ @  ~ foS@@rmitu~@ v@  1  ~n~~~~@@~@Ki/a-~@Ms yb.~oo~~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->CUSTOM:Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    if-ne v1, p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->ADAPTION:Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-ne v1, p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->ALIGNMENT:Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-ne v1, p0, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->FIXED_RESOLUTION_RATIO:Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-ne v1, p0, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 p0, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object p0

    :catch_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string/jumbo v0, "nntanoumtbnreo i oa ehfdTeuuc e"

    const/4 v3, 0x2

    const-string/jumbo v0, "nfemh t tne oeoebrn uaodnncimTa"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoOrientationMode;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x0

    const-class v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoOrientationMode;
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoOrientationMode;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoOrientationMode;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->value:I

    const/4 v2, 0x3

    return v0
.end method
