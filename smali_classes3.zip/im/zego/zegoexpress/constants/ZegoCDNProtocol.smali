.class public final enum Lim/zego/zegoexpress/constants/ZegoCDNProtocol;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoCDNProtocol;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

.field public static final enum QUIC:Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

.field public static final enum TCP:Lim/zego/zegoexpress/constants/ZegoCDNProtocol;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string v1, "TCP"

    const-string v1, "TPC"

    const/4 v7, 0x7

    const-string v1, "PCT"

    const-string v1, "TCP"

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v2, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {v0, v1, v2, v3}, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;-><init>(Ljava/lang/String;II)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;->TCP:Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v4, "ICUQ"

    const-string v4, "IQCU"

    const/4 v7, 0x1

    const-string v4, "QICU"

    const-string v4, "QUIC"

    const/4 v7, 0x7

    const/4 v5, 0x2

    move v6, v5

    move v6, v5

    const/4 v7, 0x2

    invoke-direct {v1, v4, v3, v5}, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;-><init>(Ljava/lang/String;II)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;->QUIC:Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-array v4, v5, [Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v7, 0x0

    aput-object v0, v4, v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    aput-object v1, v4, v3

    const/4 v6, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    sput-object v4, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;->value:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public static getZegoCDNProtocol(I)Lim/zego/zegoexpress/constants/ZegoCDNProtocol;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "tus@b@ @1~@ vto~~ r@c@ol~fo S@n@@@~y~~ ~~i@o ~-~@o    ~ ~ ~@~l~si.@~@@~   M~ 4~@~/amK@@@o bbd/~i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;->TCP:Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-ne v1, p0, :cond_0

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;->QUIC:Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    if-ne v1, p0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x4

    return-object p0

    :catch_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v0, " ormteco umnsta eiTenondnna buf"

    const-string v0, "e sftotaeeo ncnd anirTnm eounbu"

    const/4 v3, 0x1

    const-string v0, "Tee oomatibnnfranehu   ndtuenco"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoCDNProtocol;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x2

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v2, 0x4

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoCDNProtocol;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoCDNProtocol;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoCDNProtocol;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoCDNProtocol;->value:I

    const/4 v2, 0x1

    return v0
.end method
