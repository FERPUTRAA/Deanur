.class public final enum Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

.field public static final enum AS:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

.field public static final enum CN:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

.field public static final enum EU:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

.field public static final enum IN:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

.field public static final enum NA:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 15

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x4

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x4

    const-string v1, "NC"

    const-string v1, "NC"

    const/4 v14, 0x4

    const-string v1, "CN"

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x5

    const/4 v2, 0x0

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x3

    const/4 v3, 0x2

    const/4 v13, 0x2

    move v14, v13

    invoke-direct {v0, v1, v2, v3}, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x5

    const/4 v13, 0x7

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->CN:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x5

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x7

    const-string v4, "AN"

    const-string v4, "AN"

    const/4 v14, 0x5

    const-string v4, "NA"

    const-string v4, "NA"

    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x7

    const/4 v5, 0x1

    const/4 v14, 0x6

    const/4 v6, 0x3

    const/4 v13, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x2

    invoke-direct {v1, v4, v5, v6}, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x5

    const/4 v13, 0x0

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->NA:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x7

    new-instance v4, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x0

    const-string v7, "EU"

    const-string v7, "UE"

    const/4 v14, 0x6

    const-string v7, "EU"

    const-string v7, "EU"

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v8, 0x2

    const/4 v8, 0x4

    const/4 v14, 0x4

    const/4 v13, 0x6

    const/4 v14, 0x4

    invoke-direct {v4, v7, v3, v8}, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x4

    const/4 v13, 0x1

    sput-object v4, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->EU:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x6

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x7

    const-string v9, "SA"

    const-string v9, "SA"

    const/4 v14, 0x0

    const-string v9, "AS"

    const-string v9, "AS"

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x4

    const/4 v10, 0x5

    const/4 v14, 0x5

    const/4 v13, 0x3

    invoke-direct {v7, v9, v6, v10}, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x2

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->AS:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x2

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x4

    const-string v11, "IN"

    const-string v11, "NI"

    const/4 v14, 0x5

    const-string v11, "IN"

    const-string v11, "IN"

    const/4 v13, 0x6

    shl-int/2addr v14, v13

    const/4 v12, 0x6

    move v14, v12

    const/4 v13, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x3

    invoke-direct {v9, v11, v8, v12}, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x5

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->IN:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x6

    new-array v10, v10, [Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x4

    aput-object v0, v10, v2

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x0

    aput-object v1, v10, v5

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x1

    aput-object v4, v10, v3

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x4

    aput-object v7, v10, v6

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x5

    aput-object v9, v10, v8

    const/4 v14, 0x3

    const/4 v13, 0x6

    const/4 v14, 0x4

    sput-object v10, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v14, 0x7

    const/4 v13, 0x3

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->value:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public static getZegoGeoFenceAreaCode(I)Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "r@s @o~oS~/  ~os @@bav~/~- ~u o~@m~o ~ @ @ ~~@li~c@y~ @~f~@~~ l@@ M@. ~@~ii@4@n~o~fdttbK  @@b~@1"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->CN:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-ne v1, p0, :cond_0

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->NA:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->value:I

    const/4 v2, 0x0

    move v3, v2

    if-ne v1, p0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->EU:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ne v1, p0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->AS:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->value:I

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-ne v1, p0, :cond_3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->IN:Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-ne v1, p0, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object p0

    :catch_0
    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v2, 0x1

    and-int/2addr v3, v2

    const-string v0, "  sm nbemTcuue ooiaodaftnenhrne"

    const-string v0, "Thsne auuoe me iot ocndbrefnnat"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-class v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v2, 0x2

    const-class v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoGeoFenceAreaCode;->value:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method
