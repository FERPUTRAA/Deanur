.class public final enum Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

.field public static final enum ZEGO_TRAFFIC_CONTROL_FOUNS_ON_LOCAL_ONLY:Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

.field public static final enum ZEGO_TRAFFIC_CONTROL_FOUNS_ON_REMOTE:Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string v1, "LCsOINAFCOR_E_FsOFSY__NLTLCNGOOORU_ZTL_O"

    const-string v1, "FLsZ_CYTRTSLCLFOC_IONUNOAOR__OF_ENGOONL_"

    const/4 v6, 0x4

    const-string v1, "CLOmFLNZ_LL_FROONFNOACNTC_SOTGYI__EORUA_"

    const-string v1, "ZEGO_TRAFFIC_CONTROL_FOUNS_ON_LOCAL_ONLY"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;-><init>(Ljava/lang/String;II)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;->ZEGO_TRAFFIC_CONTROL_FOUNS_ON_LOCAL_ONLY:Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v6, 0x3

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const-string v3, "_TF_o_ONL_AFONCGCEESZT_MIUmNROROEFOR"

    const-string v3, "_GOm_COOZFFRNEOEFRLSETIAUCO__O_NRTMN"

    const/4 v6, 0x4

    const-string v3, "OLEIObOZONCGCTTRESF_FNFOA_UR_MNTE_OR"

    const-string v3, "ZEGO_TRAFFIC_CONTROL_FOUNS_ON_REMOTE"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v4, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;-><init>(Ljava/lang/String;II)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;->ZEGO_TRAFFIC_CONTROL_FOUNS_ON_REMOTE:Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v3, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-array v3, v3, [Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    aput-object v0, v3, v2

    const/4 v5, 0x1

    const/4 v6, 0x3

    aput-object v1, v3, v4

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x2

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;->value:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public static getZegoTrafficControlFocusOnMode(I)Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~b~o u@o@~@iv@ @~@~n@@ ~it@ @@-1d@~~~@ @toM~b~@o b KSr @~yf~ ~~. s   @ ~~ @~fo~ul c@~~ oal/im4/"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;->ZEGO_TRAFFIC_CONTROL_FOUNS_ON_LOCAL_ONLY:Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;->value:I

    if-ne v1, p0, :cond_0

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;->ZEGO_TRAFFIC_CONTROL_FOUNS_ON_REMOTE:Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-ne v1, p0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object p0

    :catch_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v0, "Tonomuap bonnaenfteedoi n rt ce"

    const-string v0, "T mnoeantbrenfo euindhaooc  tne"

    const/4 v3, 0x6

    const-string v0, "aetruoefq Tmnuaenondn ntci heob"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x4

    const-class v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v2, 0x3

    const-class v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;->value:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method
