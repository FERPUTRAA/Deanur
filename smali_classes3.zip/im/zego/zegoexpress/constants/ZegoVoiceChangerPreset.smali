.class public final enum Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum ANDROID:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum CLEAR:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum ETHEREAL:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum FALSETTO:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum FEMALE_ENERGETIC:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum FEMALE_FRESH:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum FOREIGNER:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum FULLNESS:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum HARMONIC_MINOR:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum HIGHLY_RESONANT:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum LOUD_CLEAR:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum MAJOR_C:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum MALE_MAGNETIC:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum MEN_TO_CHILD:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum MEN_TO_WOMEN:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum MINIONS:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum MINOR_A:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum MUFFLED:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum NONE:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum OPTIMUS_PRIME:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum RICH_NESS:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum ROUNDNESS:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum WOMEN_TO_CHILD:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

.field public static final enum WOMEN_TO_MEN:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 27

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v1, "OENN"

    const-string v1, "ONNE"

    const-string v1, "NNEO"

    const-string v1, "NONE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->NONE:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v3, "MTs_ELDNICH_"

    const-string v3, "MEN_TO_CHILD"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MEN_TO_CHILD:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v5, "N_EmWTEOMONs"

    const-string v5, "WEsTNONMO_ME"

    const-string v5, "TNEOo_NEMMOW"

    const-string v5, "MEN_TO_WOMEN"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MEN_TO_WOMEN:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v7, "NLTC_bEmHMO_WD"

    const-string v7, "HONmCMLE__ITDW"

    const-string v7, "NHWIOCuLD__MTE"

    const-string v7, "WOMEN_TO_CHILD"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->WOMEN_TO_CHILD:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v9, "E_WENO_pMNTO"

    const-string v9, "WOMEN_TO_MEN"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->WOMEN_TO_MEN:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v11, "EGFNRREoq"

    const-string v11, "FEONoRRGE"

    const-string v11, "NIsRFGEER"

    const-string v11, "FOREIGNER"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->FOREIGNER:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v11, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v13, "OMImPISbP_UMR"

    const-string v13, "UOIRIbSMT_PMP"

    const-string v13, "IMPPoMUOTRSI_"

    const-string v13, "OPTIMUS_PRIME"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14, v14}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->OPTIMUS_PRIME:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v13, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v15, "DDANObR"

    const-string v15, "ARDONDu"

    const-string v15, "IANDDRu"

    const-string v15, "ANDROID"

    const/4 v14, 0x7

    invoke-direct {v13, v15, v14, v14}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v13, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->ANDROID:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v15, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v14, "LpETAHEp"

    const-string v14, "EALTEHEp"

    const-string/jumbo v14, "qEEALRHT"

    const-string v14, "ETHEREAL"

    const/16 v12, 0x8

    invoke-direct {v15, v14, v12, v12}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v15, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->ETHEREAL:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v14, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v12, "EIsAqN_CTGLMM"

    const-string v12, "TENMMGILq_EAC"

    const-string v12, "ME_mMLAIEATGN"

    const-string v12, "MALE_MAGNETIC"

    const/16 v10, 0x9

    invoke-direct {v14, v12, v10, v10}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v14, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MALE_MAGNETIC:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v12, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v10, "RHLFoFMEEESs"

    const-string v10, "HMsELERFF_SE"

    const-string v10, "FEMALE_FRESH"

    const/16 v8, 0xa

    invoke-direct {v12, v10, v8, v8}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v12, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->FEMALE_FRESH:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v10, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v8, "JmMRAb_"

    const-string v8, "JAMm_CR"

    const-string v8, "M_CROAu"

    const-string v8, "MAJOR_C"

    const/16 v6, 0xb

    invoke-direct {v10, v8, v6, v6}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v10, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MAJOR_C:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v8, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string/jumbo v6, "poIMONA"

    const-string v6, "RMNAoOI"

    const-string v6, "MINOR_A"

    const/16 v4, 0xc

    invoke-direct {v8, v6, v4, v4}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v8, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MINOR_A:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v6, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v4, "NRAI_CHMqNIOMO"

    const-string v4, "MNCHRbAI_NOIMO"

    const-string v4, "ARsOI_NRMOHCMI"

    const-string v4, "HARMONIC_MINOR"

    const/16 v2, 0xd

    invoke-direct {v6, v4, v2, v2}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->HARMONIC_MINOR:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v4, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v2, "ITNmAuEE_ELFGMRC"

    const-string v2, "LAEGCFuENERTMEI_"

    const-string v2, "MLRCoNEAEIEETEF_"

    const-string v2, "FEMALE_ENERGETIC"

    move-object/from16 v16, v6

    move-object/from16 v16, v6

    move-object/from16 v16, v6

    const/16 v6, 0xe

    invoke-direct {v4, v2, v6, v6}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->FEMALE_ENERGETIC:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v2, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v6, "HSNI_bSCp"

    const-string v6, "I_CSSHRpN"

    const-string v6, "I_HENRuSC"

    const-string v6, "RICH_NESS"

    move-object/from16 v17, v4

    move-object/from16 v17, v4

    move-object/from16 v17, v4

    move-object/from16 v17, v4

    const/16 v4, 0xf

    invoke-direct {v2, v6, v4, v4}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->RICH_NESS:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v6, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string/jumbo v4, "pULEFqF"

    const-string v4, "FqLUFME"

    const-string v4, "FqDUMLE"

    const-string v4, "MUFFLED"

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    const/16 v2, 0x10

    invoke-direct {v6, v4, v2, v2}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MUFFLED:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v4, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v2, "SRsODNUSE"

    const-string v2, "ROUNDNESS"

    move-object/from16 v19, v6

    move-object/from16 v19, v6

    move-object/from16 v19, v6

    move-object/from16 v19, v6

    const/16 v6, 0x11

    invoke-direct {v4, v2, v6, v6}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->ROUNDNESS:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v2, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v6, "FTLmSOTE"

    const-string v6, "FALSETTO"

    move-object/from16 v20, v4

    move-object/from16 v20, v4

    move-object/from16 v20, v4

    move-object/from16 v20, v4

    const/16 v4, 0x12

    invoke-direct {v2, v6, v4, v4}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->FALSETTO:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v6, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v4, "SSsUoFLE"

    const-string v4, "NSsESLUF"

    const-string v4, "LSLSFbUE"

    const-string v4, "FULLNESS"

    move-object/from16 v21, v2

    move-object/from16 v21, v2

    move-object/from16 v21, v2

    move-object/from16 v21, v2

    const/16 v2, 0x13

    invoke-direct {v6, v4, v2, v2}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->FULLNESS:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v4, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v2, "LumRE"

    const-string v2, "LECmR"

    const-string v2, "CLEAR"

    move-object/from16 v22, v6

    move-object/from16 v22, v6

    move-object/from16 v22, v6

    move-object/from16 v22, v6

    const/16 v6, 0x14

    invoke-direct {v4, v2, v6, v6}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->CLEAR:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v2, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-string v6, "SIGNYTEpRHHA_NL"

    const-string v6, "HIGHLY_RESONANT"

    move-object/from16 v23, v4

    move-object/from16 v23, v4

    move-object/from16 v23, v4

    move-object/from16 v23, v4

    const/16 v4, 0x15

    invoke-direct {v2, v6, v4, v4}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->HIGHLY_RESONANT:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v6, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/16 v4, 0x16

    move-object/from16 v24, v2

    move-object/from16 v24, v2

    move-object/from16 v24, v2

    move-object/from16 v24, v2

    const/16 v2, 0x16

    move-object/from16 v25, v8

    move-object/from16 v25, v8

    move-object/from16 v25, v8

    const-string v8, "Do_LOCREqL"

    const-string v8, "AOE_oRLCLD"

    const-string v8, "UOsELRALC_"

    const-string v8, "LOUD_CLEAR"

    invoke-direct {v6, v8, v4, v2}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->LOUD_CLEAR:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    new-instance v2, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/16 v4, 0x17

    const/16 v8, 0x17

    move-object/from16 v26, v6

    move-object/from16 v26, v6

    move-object/from16 v26, v6

    move-object/from16 v26, v6

    const-string v6, "IINmbMN"

    const-string v6, "INNSMbI"

    const-string v6, "SNIOoNI"

    const-string v6, "MINIONS"

    invoke-direct {v2, v6, v4, v8}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;-><init>(Ljava/lang/String;II)V

    sput-object v2, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MINIONS:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/16 v4, 0x18

    new-array v4, v4, [Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v6, 0x0

    aput-object v0, v4, v6

    const/4 v0, 0x1

    aput-object v1, v4, v0

    const/4 v0, 0x2

    aput-object v3, v4, v0

    const/4 v0, 0x3

    aput-object v5, v4, v0

    const/4 v0, 0x4

    aput-object v7, v4, v0

    const/4 v0, 0x5

    aput-object v9, v4, v0

    const/4 v0, 0x6

    aput-object v11, v4, v0

    const/4 v0, 0x7

    aput-object v13, v4, v0

    const/16 v0, 0x8

    aput-object v15, v4, v0

    const/16 v0, 0x9

    aput-object v14, v4, v0

    const/16 v0, 0xa

    aput-object v12, v4, v0

    const/16 v0, 0xb

    aput-object v10, v4, v0

    const/16 v0, 0xc

    aput-object v25, v4, v0

    const/16 v0, 0xd

    aput-object v16, v4, v0

    const/16 v0, 0xe

    aput-object v17, v4, v0

    const/16 v0, 0xf

    aput-object v18, v4, v0

    const/16 v0, 0x10

    aput-object v19, v4, v0

    const/16 v0, 0x11

    aput-object v20, v4, v0

    const/16 v0, 0x12

    aput-object v21, v4, v0

    const/16 v0, 0x13

    aput-object v22, v4, v0

    const/16 v0, 0x14

    aput-object v23, v4, v0

    const/16 v0, 0x15

    aput-object v24, v4, v0

    const/16 v0, 0x16

    aput-object v26, v4, v0

    const/16 v0, 0x17

    aput-object v2, v4, v0

    sput-object v4, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v0, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public static getZegoVoiceChangerPreset(I)Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@ ~ b@@-@~@ @~@a@@@@r @ /~~ @sm.~o ~t~oc liulb/~y~  @f@ ~o@iS~  ~ot~o~ ~K~@b~b@df4~i1n~  ov@~ M"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->NONE:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    if-ne v1, p0, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v2, 0x3

    move v3, v2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MEN_TO_CHILD:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-ne v1, p0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MEN_TO_WOMEN:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v1, p0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :cond_2
    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->WOMEN_TO_CHILD:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-ne v1, p0, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->WOMEN_TO_MEN:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-ne v1, p0, :cond_4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v0

    :cond_4
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->FOREIGNER:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-ne v1, p0, :cond_5

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0

    :cond_5
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->OPTIMUS_PRIME:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ne v1, p0, :cond_6

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0

    :cond_6
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->ANDROID:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ne v1, p0, :cond_7

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0

    :cond_7
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->ETHEREAL:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ne v1, p0, :cond_8

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0

    :cond_8
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MALE_MAGNETIC:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-ne v1, p0, :cond_9

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0

    :cond_9
    const/4 v3, 0x6

    const/4 v2, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->FEMALE_FRESH:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v2, 0x0

    move v3, v2

    if-ne v1, p0, :cond_a

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0

    :cond_a
    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MAJOR_C:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-ne v1, p0, :cond_b

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0

    :cond_b
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MINOR_A:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ne v1, p0, :cond_c

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_c
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->HARMONIC_MINOR:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-ne v1, p0, :cond_d

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object v0

    :cond_d
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->FEMALE_ENERGETIC:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v1, p0, :cond_e

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0

    :cond_e
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->RICH_NESS:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-ne v1, p0, :cond_f

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0

    :cond_f
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MUFFLED:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ne v1, p0, :cond_10

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object v0

    :cond_10
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->ROUNDNESS:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x0

    const/4 v2, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v2, 0x6

    and-int/2addr v3, v2

    if-ne v1, p0, :cond_11

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0

    :cond_11
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->FALSETTO:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-ne v1, p0, :cond_12

    const/4 v2, 0x7

    move v3, v2

    return-object v0

    :cond_12
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->FULLNESS:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-ne v1, p0, :cond_13

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0

    :cond_13
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->CLEAR:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x3

    const/4 v2, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-ne v1, p0, :cond_14

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0

    :cond_14
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->HIGHLY_RESONANT:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-ne v1, p0, :cond_15

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0

    :cond_15
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->LOUD_CLEAR:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-ne v1, p0, :cond_16

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0

    :cond_16
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->MINIONS:Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v1, p0, :cond_17

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :cond_17
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object p0

    :catch_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const-string v0, "duentnuucm haba eoeroTn ionue n"

    const-string/jumbo v0, "tTne cuniofdunaubem ee  hanrnoo"

    const-string/jumbo v0, "hTnedeapntimoe a enbunocuf rnot"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x0

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v2, 0x3

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v2, 0x3

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v2, 0x1

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value:I

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method
