.class public final enum Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_RESOURCE_ACCOMPANIMENT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_RESOURCE_ACCOMPANIMENT_CLIP:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_RESOURCE_ACCOMPANIMENT_SEGMENT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

.field public static final enum ZEGO_COPYRIGHTED_MUSIC_RESOURCE_SONG:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-string v1, "_OsTZIYE_R_HECCNSSGRCMOGPOSE_UORsGED"

    const-string v1, "OSsERYDSUCU_SEEGENORZ__RG_CGOTIMOCPH"

    const/4 v10, 0x3

    const-string v1, "UREmTESOISOGE__ORH_MCISYGDNP_UCGOZRE"

    const-string v1, "ZEGO_COPYRIGHTED_MUSIC_RESOURCE_SONG"

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    const/4 v2, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->ZEGO_COPYRIGHTED_MUSIC_RESOURCE_SONG:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    const-string v3, "G_TUoCPOYSHNO_IMCRMECRT_ECAEOAmUGMENSEI_DZICR"

    const-string v3, "NCOm_ENAY_ECEERRISCHCI_ITGT_RCUSMAPGUEOZPDOMM"

    const/4 v10, 0x4

    const-string v3, "OSPGIbOUCOZS_MMTNCPNERRCGEY_RICAHMI_OEEADECTU"

    const-string v3, "ZEGO_COPYRIGHTED_MUSIC_RESOURCE_ACCOMPANIMENT"

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    const/4 v4, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x4

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->ZEGO_COPYRIGHTED_MUSIC_RESOURCE_ACCOMPANIMENT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string v5, "CYP_REuOGUCEZToOAAPLTMS_MIPOE_NICCINGDEU_SREHM_CRC"

    const-string v5, "R__NoNOCMD_PITCSGEEPAMOEIR_SGUIE_OCPTLRZCCYOCMUEHA"

    const/4 v10, 0x4

    const-string v5, "OUNERCOpIIYCAMCOMEAC_PPSGDCCUZEHIP_MO_IGRTS_E_LNET"

    const-string v5, "ZEGO_COPYRIGHTED_MUSIC_RESOURCE_ACCOMPANIMENT_CLIP"

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v6, 0x2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->ZEGO_COPYRIGHTED_MUSIC_RESOURCE_ACCOMPANIMENT_CLIP:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    const-string v7, "EEEEMMCNqTbS_CS_U_RHTOCMZPRAMGAUGYEIPIGEI_NTCE_DOCRNO"

    const-string v7, "_ACTSbOCEEMR_ENUPG_YACRTHDMGCNSMIRSUNMECPTEIEIEO_OG_Z"

    const/4 v10, 0x6

    const-string v7, "EDsMOYGCGN_ECNCUITMMTRCEZURAI_TEAE_HISSCONOS_RPEGMPO_"

    const-string v7, "ZEGO_COPYRIGHTED_MUSIC_RESOURCE_ACCOMPANIMENT_SEGMENT"

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v8, 0x3

    move v10, v8

    const/4 v9, 0x3

    and-int/2addr v10, v9

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->ZEGO_COPYRIGHTED_MUSIC_RESOURCE_ACCOMPANIMENT_SEGMENT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    const/4 v7, 0x4

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    new-array v7, v7, [Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v10, 0x7

    const/4 v9, 0x3

    aput-object v0, v7, v2

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x4

    aput-object v1, v7, v4

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    aput-object v3, v7, v6

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    aput-object v5, v7, v8

    const/4 v10, 0x7

    const/4 v9, 0x2

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->value:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public static getZegoCopyrightedMusicResourceType(I)Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@oKm@ udl@~@4n@m~/b~ l  ~ /~~t.~-o@@@1@oi~~t~ i~csS~ b o ~~ ~ro~@@  a@@v~~   ~@@f~@@oMy@@ibf@  ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->ZEGO_COPYRIGHTED_MUSIC_RESOURCE_SONG:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ne v1, p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->ZEGO_COPYRIGHTED_MUSIC_RESOURCE_ACCOMPANIMENT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ne v1, p0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->ZEGO_COPYRIGHTED_MUSIC_RESOURCE_ACCOMPANIMENT_CLIP:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-ne v1, p0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->ZEGO_COPYRIGHTED_MUSIC_RESOURCE_ACCOMPANIMENT_SEGMENT:Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-ne v1, p0, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p0

    :catch_0
    const/4 v3, 0x0

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string/jumbo v0, "utocoueT  ahbnfdraeieutoomne n "

    const-string/jumbo v0, "f oaiTuedner  bmanhuoncu tenteo"

    const/4 v3, 0x6

    const-string/jumbo v0, "u T  bnaamifetnntedo bnorenueco"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v2, 0x1

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;

    const/4 v1, 0x2

    move v2, v1

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoCopyrightedMusicResourceType;->value:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    return v0
.end method
