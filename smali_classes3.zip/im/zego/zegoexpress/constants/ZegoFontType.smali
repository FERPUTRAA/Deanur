.class public final enum Lim/zego/zegoexpress/constants/ZegoFontType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoFontType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoFontType;

.field public static final enum ALIBABA_SANS:Lim/zego/zegoexpress/constants/ZegoFontType;

.field public static final enum HAPPY_ZCOOL:Lim/zego/zegoexpress/constants/ZegoFontType;

.field public static final enum PANG_MEN_ZHENG_DAO_TITLE:Lim/zego/zegoexpress/constants/ZegoFontType;

.field public static final enum SOURCE_HAN_SANS:Lim/zego/zegoexpress/constants/ZegoFontType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 11

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v10, 0x2

    const-string v1, "S_sAASSHURCOE_N"

    const-string v1, "U_s_SAHCSSRNEOA"

    const/4 v10, 0x7

    const-string v1, "RC_mSU_SNAOHSAE"

    const-string v1, "SOURCE_HAN_SANS"

    const/4 v10, 0x6

    const/4 v2, 0x1

    const/4 v10, 0x2

    const/4 v2, 0x0

    const/4 v9, 0x0

    move v10, v9

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoFontType;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoFontType;->SOURCE_HAN_SANS:Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x2

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-string v3, "ASNAoBS_ImBA"

    const-string v3, "ALBm_NBSAIAS"

    const/4 v10, 0x3

    const-string v3, "SL_AAbNASBBI"

    const-string v3, "ALIBABA_SANS"

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    const/4 v4, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoFontType;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoFontType;->ALIBABA_SANS:Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-string v5, "INAT_EuNGM_DHNoLGT_ZO_EP"

    const-string v5, "PGLGoHMN__N_DT_TNAOEIAZE"

    const/4 v10, 0x5

    const-string v5, "NEZ_NEGpTAHMTPOLNDG_AI__"

    const-string v5, "PANG_MEN_ZHENG_DAO_TITLE"

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    const/4 v6, 0x2

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoFontType;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoFontType;->PANG_MEN_ZHENG_DAO_TITLE:Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v9, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    const-string v7, "YOZPA_OHqPb"

    const-string v7, "OAPOCbHZYP_"

    const-string v7, "LYsPPCAOO_Z"

    const-string v7, "HAPPY_ZCOOL"

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v8, 0x3

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoFontType;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoFontType;->HAPPY_ZCOOL:Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    const/4 v7, 0x4

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    new-array v7, v7, [Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    aput-object v0, v7, v2

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    aput-object v1, v7, v4

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    aput-object v3, v7, v6

    aput-object v5, v7, v8

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoFontType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoFontType;->value:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public static getZegoFontType(I)Lim/zego/zegoexpress/constants/ZegoFontType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~m~@@@ of~c@~~io@M~m    @@i@@~~ ~ a@~@~@@o~.i~t~bod  @~-b@~ v r/@@S~  ~~/@n~ l~fob1u~yt4@ oKl@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoFontType;->SOURCE_HAN_SANS:Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoFontType;->value:I

    const/4 v2, 0x3

    move v3, v2

    if-ne v1, p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoFontType;->ALIBABA_SANS:Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoFontType;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-ne v1, p0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoFontType;->PANG_MEN_ZHENG_DAO_TITLE:Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoFontType;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-ne v1, p0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoFontType;->HAPPY_ZCOOL:Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoFontType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    if-ne v1, p0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x1

    return-object v0

    :cond_3
    const/4 v2, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0

    :catch_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v0, "ero ouoonde ttanenTeumiabf h un"

    const-string v0, "aemiTnuoc efuhn teo adb onnuter"

    const/4 v3, 0x2

    const-string/jumbo v0, "t bdhbu erenee T ocfaannonuonim"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoFontType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/constants/ZegoFontType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v2, 0x3

    const-class v0, Lim/zego/zegoexpress/constants/ZegoFontType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoFontType;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoFontType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoFontType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoFontType;

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoFontType;->value:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method
