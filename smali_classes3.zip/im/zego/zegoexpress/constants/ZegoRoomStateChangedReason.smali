.class public final enum Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

.field public static final enum KICK_OUT:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

.field public static final enum LOGINED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

.field public static final enum LOGINING:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

.field public static final enum LOGIN_FAILED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

.field public static final enum LOGOUT:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

.field public static final enum LOGOUT_FAILED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

.field public static final enum RECONNECTED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

.field public static final enum RECONNECTING:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

.field public static final enum RECONNECT_FAILED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const-string v1, "GOsNGIsL"

    const-string v1, "LOsGNIGI"

    const-string v1, "GILmNONG"

    const-string v1, "LOGINING"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->LOGINING:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const-string v3, "NDLmIOG"

    const-string v3, "NEGDoOL"

    const-string v3, "LOGINED"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->LOGINED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const-string v5, "IEDoObL_AIGL"

    const-string v5, "OIIDoL_AFGLE"

    const-string v5, "LO_FGAuIELNI"

    const-string v5, "LOGIN_FAILED"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->LOGIN_FAILED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const-string v7, "GNENNRCpEIbO"

    const-string v7, "NCEGCbORNENI"

    const-string v7, "TGEONNNCqCER"

    const-string v7, "RECONNECTING"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->RECONNECTING:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const-string v9, "CEsNOREDTuN"

    const-string v9, "ECRTODuENEN"

    const-string v9, "EEDmRTCCEON"

    const-string v9, "RECONNECTED"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->RECONNECTED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const-string v11, "EECLoFODCTEIpANR"

    const-string v11, "LEEEDRNpCIFTNOCA"

    const-string v11, "FN_ANbRCTICOEELE"

    const-string v11, "RECONNECT_FAILED"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->RECONNECT_FAILED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    new-instance v11, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const-string/jumbo v13, "qKUTCIK_"

    const-string v13, "TKIO_CuU"

    const-string v13, "KICK_OUT"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14, v14}, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->KICK_OUT:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    new-instance v13, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const-string v15, "UpTOOG"

    const-string v15, "TOsGOU"

    const-string v15, "TUqOGO"

    const-string v15, "LOGOUT"

    const/4 v14, 0x7

    invoke-direct {v13, v15, v14, v14}, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;-><init>(Ljava/lang/String;II)V

    sput-object v13, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->LOGOUT:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    new-instance v15, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const-string v14, "L_sGLmUOTEIFO"

    const-string v14, "TLFmOGEOUI_AL"

    const-string v14, "DGOmETALU_OIF"

    const-string v14, "LOGOUT_FAILED"

    const/16 v12, 0x8

    invoke-direct {v15, v14, v12, v12}, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;-><init>(Ljava/lang/String;II)V

    sput-object v15, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->LOGOUT_FAILED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/16 v14, 0x9

    new-array v14, v14, [Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    aput-object v0, v14, v2

    aput-object v1, v14, v4

    aput-object v3, v14, v6

    aput-object v5, v14, v8

    aput-object v7, v14, v10

    const/4 v0, 0x5

    aput-object v9, v14, v0

    const/4 v0, 0x6

    aput-object v11, v14, v0

    const/4 v0, 0x7

    aput-object v13, v14, v0

    aput-object v15, v14, v12

    sput-object v14, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->value:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public static getZegoRoomStateChangedReason(I)Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~i ~o~@@r os@~~o@@@~~@S ~ioi.c   @y@1/ ~ bvK~ n~ lt@-@@~~f@ @~ o   ~~l4@du~ ob@~Mbt@omf@~~@@/~a~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->LOGINING:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v1, p0, :cond_0

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->LOGINED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v1, p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->LOGIN_FAILED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ne v1, p0, :cond_2

    const/4 v3, 0x6

    return-object v0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->RECONNECTING:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-ne v1, p0, :cond_3

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object v0

    :cond_3
    sget-object v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->RECONNECTED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ne v1, p0, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object v0

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->RECONNECT_FAILED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v1, p0, :cond_5

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0

    :cond_5
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->KICK_OUT:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    if-ne v1, p0, :cond_6

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0

    :cond_6
    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->LOGOUT:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->value:I

    const/4 v3, 0x4

    if-ne v1, p0, :cond_7

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0

    :cond_7
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->LOGOUT_FAILED:Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    if-ne v1, p0, :cond_8

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object v0

    :cond_8
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object p0

    :catch_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo v0, "fentnbadcbeu  oohoinem u nTtaen"

    const-string/jumbo v0, "oiauononfeehntm bedaTtnounc e  "

    const/4 v3, 0x3

    const-string v0, "detn iuhenmtfuoab une eoanno cT"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-class v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v2, 0x5

    const-class v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->value:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method
