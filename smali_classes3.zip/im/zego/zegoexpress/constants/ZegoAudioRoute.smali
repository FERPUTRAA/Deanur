.class public final enum Lim/zego/zegoexpress/constants/ZegoAudioRoute;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoAudioRoute;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioRoute;

.field public static final enum AIR_PLAY:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

.field public static final enum BLUETOOTH:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

.field public static final enum EXTERNAL_USB:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

.field public static final enum HEADPHONE:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

.field public static final enum RECEIVER:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

.field public static final enum SPEAKER:Lim/zego/zegoexpress/constants/ZegoAudioRoute;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 15

    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x4

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x0

    const-string v1, "PEsAKES"

    const-string v1, "EEsAPKS"

    const/4 v14, 0x6

    const-string v1, "PSKmEEA"

    const-string v1, "SPEAKER"

    const/4 v14, 0x7

    const/4 v2, 0x0

    const/4 v14, 0x3

    shl-int/2addr v13, v2

    const/4 v14, 0x2

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoAudioRoute;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x6

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->SPEAKER:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x4

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x5

    const-string v3, "NEDHoAEOm"

    const-string v3, "NDPmAOEHE"

    const/4 v14, 0x6

    const-string v3, "NOEEHbPHA"

    const-string v3, "HEADPHONE"

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x2

    const/4 v4, 0x1

    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x4

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoAudioRoute;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x5

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->HEADPHONE:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x5

    const/4 v13, 0x6

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x4

    const-string v5, "OHETLOuTB"

    const-string v5, "BTTOoOEHL"

    const/4 v14, 0x5

    const-string v5, "OEUTLHBpO"

    const-string v5, "BLUETOOTH"

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x2

    const/4 v6, 0x2

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x6

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoAudioRoute;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x4

    const/4 v13, 0x1

    const/4 v14, 0x3

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->BLUETOOTH:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x5

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x5

    const-string/jumbo v7, "qCREVREE"

    const-string v7, "RECEIVER"

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x3

    const/4 v8, 0x3

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x7

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoAudioRoute;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x5

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->RECEIVER:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x6

    const/4 v13, 0x4

    const/4 v14, 0x1

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x0

    const-string v9, "SbsULNEE_ABT"

    const-string v9, "XSTALbEE_UBN"

    const/4 v14, 0x2

    const-string v9, "RUEmLEN_ATSB"

    const-string v9, "EXTERNAL_USB"

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x3

    const/4 v10, 0x4

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x3

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoAudioRoute;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x5

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->EXTERNAL_USB:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x4

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x3

    const-string v11, "A_AYoLIR"

    const-string v11, "AIR_PLAY"

    const/4 v14, 0x7

    const/4 v13, 0x6

    const/4 v14, 0x1

    const/4 v12, 0x5

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x7

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoAudioRoute;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x3

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->AIR_PLAY:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x7

    const/4 v11, 0x6

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x0

    new-array v11, v11, [Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x3

    const/4 v13, 0x6

    const/4 v14, 0x4

    aput-object v0, v11, v2

    const/4 v14, 0x4

    const/4 v13, 0x0

    const/4 v14, 0x4

    aput-object v1, v11, v4

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x2

    aput-object v3, v11, v6

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x7

    aput-object v5, v11, v8

    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x2

    aput-object v7, v11, v10

    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x7

    aput-object v9, v11, v12

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x4

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x5

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->value:I

    const/4 v1, 0x0

    return-void
.end method

.method public static getZegoAudioRoute(I)Lim/zego/zegoexpress/constants/ZegoAudioRoute;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o~ iob @y ~l~@@~f@@~@o@o~~ ~@S/ r4~~@ @o~@ t~iclK  ~@/@@b@~ u@nam~ ~~1 bi~~@@ Mo fd~-~t  b@v .@s"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->SPEAKER:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x3

    if-ne v1, p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->HEADPHONE:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v3, 0x5

    const/4 v2, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-ne v1, p0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->BLUETOOTH:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-ne v1, p0, :cond_2

    const/4 v3, 0x5

    return-object v0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->RECEIVER:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-ne v1, p0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->EXTERNAL_USB:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-ne v1, p0, :cond_4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object v0

    :cond_4
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->AIR_PLAY:Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v3, 0x5

    const/4 v2, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-ne v1, p0, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0

    :cond_5
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object p0

    :catch_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo v0, "mu oTbunnt aheteafeuun inrc noe"

    const-string/jumbo v0, "otonieu cfeeub m entnn Thnuraao"

    const/4 v3, 0x1

    const-string/jumbo v0, "nnTfimnpc  oabeene uatodhoe nur"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoAudioRoute;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v2, 0x5

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoAudioRoute;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoAudioRoute;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->value:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method
