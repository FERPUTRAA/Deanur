.class public final enum Lim/zego/zegoexpress/constants/ZegoNetworkMode;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoNetworkMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoNetworkMode;

.field public static final enum ETHERNET:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

.field public static final enum MODE_2G:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

.field public static final enum MODE_3G:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

.field public static final enum MODE_4G:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

.field public static final enum MODE_5G:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

.field public static final enum OFFLINE:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

.field public static final enum UNKNOWN:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

.field public static final enum WIFI:Lim/zego/zegoexpress/constants/ZegoNetworkMode;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const-string v1, "LNsEOFI"

    const-string v1, "FNsFELO"

    const-string v1, "OFFLINE"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoNetworkMode;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->OFFLINE:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const-string v3, "WUOmNNm"

    const-string v3, "UWNmNON"

    const-string v3, "UNKNOWN"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoNetworkMode;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const-string v5, "ETRTooHE"

    const-string v5, "HTRToEEE"

    const-string v5, "ETERNbHE"

    const-string v5, "ETHERNET"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoNetworkMode;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->ETHERNET:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const-string v7, "IWIF"

    const-string v7, "FIWI"

    const-string v7, "IWFI"

    const-string v7, "WIFI"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoNetworkMode;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->WIFI:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const-string v9, "G2Db_Ou"

    const-string v9, "2DMO_bG"

    const-string/jumbo v9, "pOD2GME"

    const-string v9, "MODE_2G"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoNetworkMode;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->MODE_2G:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const-string v11, "DqEO3u_"

    const-string v11, "E3_ODMu"

    const-string v11, "DEsM3_G"

    const-string v11, "MODE_3G"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoNetworkMode;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->MODE_3G:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    new-instance v11, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const-string v13, "OpEmD_M"

    const-string/jumbo v13, "p_ODMEG"

    const-string v13, "OED4oMG"

    const-string v13, "MODE_4G"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14, v14}, Lim/zego/zegoexpress/constants/ZegoNetworkMode;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->MODE_4G:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    new-instance v13, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const-string v15, "_qODEbG"

    const-string v15, "EqMG_DO"

    const-string v15, "_MO5EGu"

    const-string v15, "MODE_5G"

    const/4 v14, 0x7

    invoke-direct {v13, v15, v14, v14}, Lim/zego/zegoexpress/constants/ZegoNetworkMode;-><init>(Ljava/lang/String;II)V

    sput-object v13, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->MODE_5G:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/16 v15, 0x8

    new-array v15, v15, [Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    aput-object v0, v15, v2

    aput-object v1, v15, v4

    aput-object v3, v15, v6

    aput-object v5, v15, v8

    aput-object v7, v15, v10

    aput-object v9, v15, v12

    const/4 v0, 0x6

    aput-object v11, v15, v0

    aput-object v13, v15, v14

    sput-object v15, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->value:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public static getZegoNetworkMode(I)Lim/zego/zegoexpress/constants/ZegoNetworkMode;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  @t @ p~~r o~~a@~s ~St@@u4o1b @b@@i~~ vo~i ~~obK~  df@@@@ -i@@yo~~l@M@l@/ ~c @/.n~ m~~~fo~ @ ~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->OFFLINE:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-ne v1, p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v2, 0x0

    move v3, v2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-ne v1, p0, :cond_1

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->ETHERNET:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v2, 0x7

    const/4 v2, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-ne v1, p0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->WIFI:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->value:I

    const/4 v3, 0x0

    if-ne v1, p0, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object v0

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->MODE_2G:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-ne v1, p0, :cond_4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object v0

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->MODE_3G:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-ne v1, p0, :cond_5

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0

    :cond_5
    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->MODE_4G:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-ne v1, p0, :cond_6

    const/4 v2, 0x5

    or-int/2addr v3, v2

    return-object v0

    :cond_6
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->MODE_5G:Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ne v1, p0, :cond_7

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0

    :cond_7
    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p0

    :catch_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string v0, "The enumeration cannot be found"

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoNetworkMode;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-class v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v2, 0x5

    const-class v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoNetworkMode;
    .locals 3

    const/4 v2, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoNetworkMode;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoNetworkMode;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoNetworkMode;->value:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method
