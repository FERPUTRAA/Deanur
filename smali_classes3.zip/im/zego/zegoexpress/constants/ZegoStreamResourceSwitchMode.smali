.class public final enum Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

.field public static final enum DEFAULT:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

.field public static final enum KEEP_ORIGINAL:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

.field public static final enum SWITCH_TO_RTC:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v7, 0x0

    shl-int/2addr v8, v7

    const-string v1, "FLssEUT"

    const-string v1, "TDsLEFU"

    const/4 v8, 0x4

    const-string v1, "EDAmLFT"

    const-string v1, "DEFAULT"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    const/4 v2, 0x0

    const/4 v8, 0x7

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-string v3, "RCT_omSCTI_HW"

    const-string v3, "HCImTWSTO_C_R"

    const/4 v8, 0x0

    const-string v3, "ST_CRbTOTHW_C"

    const-string v3, "SWITCH_TO_RTC"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    const/4 v4, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;-><init>(Ljava/lang/String;II)V

    const/4 v7, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->SWITCH_TO_RTC:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string/jumbo v5, "oOKEPGuAIRNEL"

    const-string v5, "KGOPoLNIRAIEE"

    const/4 v8, 0x4

    const-string v5, "OEIIRNGpLPAK_"

    const-string v5, "KEEP_ORIGINAL"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v6, 0x2

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->KEEP_ORIGINAL:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    const/4 v5, 0x3

    const/4 v7, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    new-array v5, v5, [Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    aput-object v0, v5, v2

    const/4 v7, 0x7

    shr-int/2addr v8, v7

    aput-object v1, v5, v4

    const/4 v7, 0x3

    shr-int/2addr v8, v7

    aput-object v3, v5, v6

    const/4 v8, 0x3

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v8, 0x5

    const/4 v7, 0x7

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->value:I

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static getZegoStreamResourceSwitchMode(I)Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o~o t.~ q~r~ oK ~@@  o @b/@~ 1~ @v@~~~b@@@ao@t n~l~ @ 4@/iS@  s ~~-~u fo~c@ @~b~fd~@m@ilMi~@~@~y"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v3, 0x1

    const/4 v2, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-ne v1, p0, :cond_0

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->SWITCH_TO_RTC:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-ne v1, p0, :cond_1

    const/4 v3, 0x0

    return-object v0

    :cond_1
    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->KEEP_ORIGINAL:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-ne v1, p0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :cond_2
    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p0

    :catch_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v0, "tnsobncfoh ueaetumnTe rn deb in"

    const-string v0, "ecmoubeotbtrinn   naefu ohdTnne"

    const-string v0, "cn m et urf oTodenuaamnennhiotb"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v2, 0x1

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x5

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->value:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method
