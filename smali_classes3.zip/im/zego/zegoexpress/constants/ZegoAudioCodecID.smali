.class public final enum Lim/zego/zegoexpress/constants/ZegoAudioCodecID;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoAudioCodecID;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

.field public static final enum DEFAULT:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

.field public static final enum LOW:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

.field public static final enum LOW2:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

.field public static final enum LOW3:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

.field public static final enum NORMAL:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

.field public static final enum NORMAL2:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

.field public static final enum NORMAL3:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 15

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const-string v1, "FUsLDET"

    const-string v1, "TFsAEUL"

    const-string v1, "DEFAULT"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const-string v3, "LRmmAN"

    const-string v3, "RNOmLA"

    const-string v3, "AORNoM"

    const-string v3, "NORMAL"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->NORMAL:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const-string v5, "ANL2ObM"

    const-string v5, "NORMAL2"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->NORMAL2:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const-string v7, "M3RoLNu"

    const-string v7, "RMOLoN3"

    const-string/jumbo v7, "pRALONM"

    const-string v7, "NORMAL3"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->NORMAL3:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const-string v9, "WOL"

    const-string v9, "OWL"

    const-string v9, "LOW"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->LOW:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const-string v11, "WO2L"

    const-string v11, "2WLO"

    const-string v11, "L2OW"

    const-string v11, "LOW2"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->LOW2:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    new-instance v11, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const-string v13, "3OLW"

    const-string v13, "W3LO"

    const-string v13, "WLO3"

    const-string v13, "LOW3"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14, v14}, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->LOW3:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v13, 0x7

    new-array v13, v13, [Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    aput-object v0, v13, v2

    aput-object v1, v13, v4

    aput-object v3, v13, v6

    aput-object v5, v13, v8

    aput-object v7, v13, v10

    aput-object v9, v13, v12

    aput-object v11, v13, v14

    sput-object v13, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->value:I

    const/4 v1, 0x4

    return-void
.end method

.method public static getZegoAudioCodecID(I)Lim/zego/zegoexpress/constants/ZegoAudioCodecID;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "    istoq/Mlo~uK  ~S@@o  il-~i.~@~@ f ~@m~ ~@r@o ~~@ @yd @@~@~~o~~@n~4v@t@b@ ~~~~~@o ~/@fb@c @ab"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v2, 0x0

    shl-int/2addr v3, v2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-ne v1, p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0

    :cond_0
    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->NORMAL:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    if-ne v1, p0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->NORMAL2:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    if-ne v1, p0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->NORMAL3:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-ne v1, p0, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0

    :cond_3
    const/4 v2, 0x7

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->LOW:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-ne v1, p0, :cond_4

    const/4 v3, 0x3

    return-object v0

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->LOW2:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-ne v1, p0, :cond_5

    const/4 v3, 0x2

    const/4 v2, 0x3

    return-object v0

    :cond_5
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->LOW3:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ne v1, p0, :cond_6

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0

    :cond_6
    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p0

    :catch_0
    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v0, "cese euunn db bieofrton aToannt"

    const-string v0, "enhorbnfaibtneTceued   nunooat "

    const/4 v3, 0x1

    const-string/jumbo v0, "f cmnonrnato Tnumnt ieebhuoda e"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoAudioCodecID;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v2, 0x5

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoAudioCodecID;
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v2, 0x4

    const/4 v1, 0x7

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x4

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->value:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method
