.class public final enum Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

.field public static final enum PRESET_1080P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

.field public static final enum PRESET_180P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

.field public static final enum PRESET_270P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

.field public static final enum PRESET_360P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

.field public static final enum PRESET_540P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

.field public static final enum PRESET_720P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 15

    const/4 v14, 0x4

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x2

    const-string v1, "EPsTRS_P0E8"

    const-string v1, "PRESET_180P"

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x1

    const/4 v2, 0x0

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x1

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x4

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_180P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v14, 0x6

    const/4 v13, 0x4

    const/4 v14, 0x5

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x5

    const-string v3, "TPSmE0_PRsE"

    const-string v3, "EPsESTR0P_2"

    const/4 v14, 0x0

    const-string v3, "RT0Po7PES_E"

    const-string v3, "PRESET_270P"

    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x4

    const/4 v4, 0x1

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x4

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x6

    move v14, v13

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_270P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x3

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v13, 0x4

    move v14, v13

    const-string v5, "PES60b3TP_R"

    const-string v5, "0P3mTE6SPR_"

    const-string v5, "_0SEREu63PP"

    const-string v5, "PRESET_360P"

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x6

    const/4 v6, 0x2

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x6

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x6

    shl-int/2addr v14, v13

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_360P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x4

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v14, 0x7

    const/4 v13, 0x6

    const/4 v14, 0x7

    const-string v7, "0RP_5PTpE4o"

    const-string v7, "S_R5o0PP4ET"

    const/4 v14, 0x4

    const-string v7, "SRPEEP0_q4T"

    const-string v7, "PRESET_540P"

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x5

    const/4 v8, 0x3

    const/4 v14, 0x4

    const/4 v13, 0x2

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x0

    const/4 v13, 0x5

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_540P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v13, 0x6

    shl-int/2addr v14, v13

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x1

    const-string v9, "S_sP7TbER0E"

    const-string v9, "70TS_b2EPRE"

    const/4 v14, 0x7

    const-string v9, "RP_m2E7E0ST"

    const-string v9, "PRESET_720P"

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x7

    const/4 v10, 0x4

    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x6

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x7

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_720P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x0

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v14, 0x4

    const/4 v13, 0x6

    const/4 v14, 0x1

    const-string v11, "_EuRo10PST0E"

    const-string v11, "1PS0ETuE_R80"

    const/4 v14, 0x6

    const-string v11, "81EE_bTRS00P"

    const-string v11, "PRESET_1080P"

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x0

    const/4 v12, 0x5

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x4

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x1

    move v14, v13

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_1080P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v14, 0x4

    const/4 v13, 0x3

    const/4 v14, 0x7

    const/4 v11, 0x6

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x1

    new-array v11, v11, [Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v14, 0x5

    aput-object v0, v11, v2

    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x5

    aput-object v1, v11, v4

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x3

    aput-object v3, v11, v6

    const/4 v13, 0x6

    move v14, v13

    aput-object v5, v11, v8

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x3

    aput-object v7, v11, v10

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x6

    aput-object v9, v11, v12

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x7

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x2

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->value:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public static getZegoVideoConfigPreset(I)Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @ ~o~u.~af~v~@ @ @@~~oi ~~@@~rlo ~4~M~l @b~o@@bb@@t@/@@@dt   @o~S y m@@ ~ -~@u ~n~ fic1i~ /Ks~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_180P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-ne v1, p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_270P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-ne v1, p0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_360P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-ne v1, p0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0

    :cond_2
    const/4 v2, 0x1

    move v3, v2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_540P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->value:I

    const/4 v3, 0x5

    if-ne v1, p0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_720P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-ne v1, p0, :cond_4

    const/4 v3, 0x6

    const/4 v2, 0x6

    return-object v0

    :cond_4
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->PRESET_1080P:Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-ne v1, p0, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0

    :cond_5
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p0

    :catch_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v0, "oTinuebpt cno pn  harndeuafmeon"

    const-string v0, "ahuebneptnfodu  nnrc enio mTtao"

    const/4 v3, 0x7

    const-string v0, " iuf teoqnheaaortn uonTedne cbn"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v2, 0x2

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoVideoConfigPreset;->value:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return v0
.end method
