.class public final enum Lim/zego/zegoexpress/constants/ZegoVideoSourceType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoVideoSourceType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

.field public static final enum CAMERA:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

.field public static final enum CUSTOM:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

.field public static final enum MAIN_PUBLISH_CHANNEL:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

.field public static final enum NONE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

.field public static final enum PLAYER:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

.field public static final enum SCREEN_CAPTURE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

.field public static final enum ZEGO_VIDEO_SOURCE_CAMERA:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final enum ZEGO_VIDEO_SOURCE_DEFAULT:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final enum ZEGO_VIDEO_SOURCE_EXTERNAL_CAPTURE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final enum ZEGO_VIDEO_SOURCE_MAIN_PUBLISH_CHANNEL:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final enum ZEGO_VIDEO_SOURCE_NONE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final enum ZEGO_VIDEO_SOURCE_PLAYER:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field

.field public static final enum ZEGO_VIDEO_SOURCE_SCREEN_CAPTURE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation
.end field


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v1, "ENNO"

    const-string v1, "NENO"

    const-string v1, "NEON"

    const-string v1, "NONE"

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v1, v2, v3}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->NONE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v4, "CAssME"

    const-string v4, "REsAMC"

    const-string v4, "ERAmAM"

    const-string v4, "CAMERA"

    const/4 v5, 0x2

    invoke-direct {v1, v4, v3, v5}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->CAMERA:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-instance v4, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v6, "UmSCoT"

    const-string v6, "SUCmTO"

    const-string v6, "UTCSOb"

    const-string v6, "CUSTOM"

    const/4 v7, 0x3

    invoke-direct {v4, v6, v5, v7}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->CUSTOM:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-instance v6, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v8, "HPNCILuENALNSUHoMAI_"

    const-string v8, "HNSEoCIP_AAHLUNL_IMN"

    const-string v8, "MAIN_PUBLISH_CHANNEL"

    const/4 v9, 0x4

    invoke-direct {v6, v8, v7, v9}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->MAIN_PUBLISH_CHANNEL:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-instance v8, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v10, "RpLYPA"

    const-string v10, "RAPYLb"

    const-string v10, "YEqAPR"

    const-string v10, "PLAYER"

    const/4 v11, 0x5

    invoke-direct {v8, v10, v9, v11}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v8, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->PLAYER:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-instance v10, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v12, "ARsPECRETuNSCE"

    const-string v12, "NEEAREuRCUTPSC"

    const-string v12, "SCREEN_CAPTURE"

    const/4 v13, 0x6

    invoke-direct {v10, v12, v11, v13}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v10, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->SCREEN_CAPTURE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-instance v12, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v14, "LASmOTRE_EODU_FOpGUCIVZ_E"

    const-string v14, "VDFCSTZpOL_DAOOIGUUREE__E"

    const-string v14, "FTIEoEOOOUES_DDZ_GLUCV_AR"

    const-string v14, "ZEGO_VIDEO_SOURCE_DEFAULT"

    const/4 v15, 0x7

    invoke-direct {v12, v14, v13, v15}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v12, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_DEFAULT:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-instance v14, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v13, "ENZU_b_qGR_VEOEOOCDSEO"

    const-string v13, "_COEEOSRqNNO_D_EOZEVGU"

    const-string v13, "NUO_EEuONSCRGVIEOO_DZ_"

    const-string v13, "ZEGO_VIDEO_SOURCE_NONE"

    const/16 v11, 0x8

    invoke-direct {v14, v13, v15, v11}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v14, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_NONE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-instance v13, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v15, "EVCUEECpDA_GsR_EAOO_ZMIR"

    const-string v15, "VSsUE_OGMOAC_RZEEDEI_RCA"

    const-string v15, "_CAREODVqOESOI_EAEURC_MG"

    const-string v15, "ZEGO_VIDEO_SOURCE_CAMERA"

    const/16 v9, 0x9

    invoke-direct {v13, v15, v11, v9}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v13, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_CAMERA:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-instance v15, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v11, "UOEmNEGLT_TECEPVOAEROERR_AD__UCISZ"

    const-string v11, "EOsERP_ECZ_RNAGOUOIVALCTX__SETEDEU"

    const-string v11, "ZEGO_VIDEO_SOURCE_EXTERNAL_CAPTURE"

    const/16 v7, 0xa

    invoke-direct {v15, v11, v9, v7}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v15, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_EXTERNAL_CAPTURE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-instance v11, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v9, "EHRm_N_SONAI_oVSE_CLAPOG_ILIOEUBUZCNDH"

    const-string v9, "_EINoUUGAOC_LOHNLSEZI_ERBHIA__POVDSCNE"

    const-string v9, "HDLHoMZEEUNOC__V_OCA_NRILEGAIBUI_ESPON"

    const-string v9, "ZEGO_VIDEO_SOURCE_MAIN_PUBLISH_CHANNEL"

    const/16 v5, 0xb

    invoke-direct {v11, v9, v7, v5}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_MAIN_PUBLISH_CHANNEL:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v7, "ORSbObIPOE_AEZVCEUE_YDRL"

    const-string v7, "RLYOPb__VRCZO_EEDEUIOSAE"

    const-string v7, "YP_OLZuO_EECVSDUREOE_IGA"

    const-string v7, "ZEGO_VIDEO_SOURCE_PLAYER"

    const/16 v3, 0xc

    invoke-direct {v9, v7, v5, v3}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_PLAYER:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-string v5, "DOCA_GEpEUEZCEOENUuSECRIS_P_RR_V"

    const-string v5, "VCCEORuEO_EDZESPNSUACO_IRE__UEGR"

    const-string v5, "NOC_RZUSqGEE_URDVCO_EIRCAPE_EESO"

    const-string v5, "ZEGO_VIDEO_SOURCE_SCREEN_CAPTURE"

    const/16 v2, 0xd

    invoke-direct {v7, v5, v3, v2}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_SCREEN_CAPTURE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    new-array v2, v2, [Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v5, 0x0

    aput-object v0, v2, v5

    const/4 v0, 0x1

    aput-object v1, v2, v0

    const/4 v0, 0x2

    aput-object v4, v2, v0

    const/4 v0, 0x3

    aput-object v6, v2, v0

    const/4 v0, 0x4

    aput-object v8, v2, v0

    const/4 v0, 0x5

    aput-object v10, v2, v0

    const/4 v0, 0x6

    aput-object v12, v2, v0

    const/4 v0, 0x7

    aput-object v14, v2, v0

    const/16 v0, 0x8

    aput-object v13, v2, v0

    const/16 v0, 0x9

    aput-object v15, v2, v0

    const/16 v0, 0xa

    aput-object v11, v2, v0

    const/16 v0, 0xb

    aput-object v9, v2, v0

    aput-object v7, v2, v3

    sput-object v2, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v1, 0x5

    return-void
.end method

.method public static getZegoVideoSourceType(I)Lim/zego/zegoexpress/constants/ZegoVideoSourceType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " /sa~~o@ @@~y~v~f@n~~M@4 b~oKou@@ o@/~~@~~l f~otS  ~l ~i@-b m@@@i@sr ~@i@ ~@ ~c~  @b1 ~d.o~t@ ~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->NONE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ne v1, p0, :cond_0

    const/4 v2, 0x3

    move v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->CAMERA:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v3, 0x2

    if-ne v1, p0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->CUSTOM:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    if-ne v1, p0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-object v0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->MAIN_PUBLISH_CHANNEL:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-ne v1, p0, :cond_3

    const/4 v3, 0x2

    return-object v0

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->PLAYER:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-ne v1, p0, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0

    :cond_4
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->SCREEN_CAPTURE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-ne v1, p0, :cond_5

    const/4 v3, 0x2

    return-object v0

    :cond_5
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_DEFAULT:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v1, p0, :cond_6

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0

    :cond_6
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_NONE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-ne v1, p0, :cond_7

    return-object v0

    :cond_7
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_CAMERA:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-ne v1, p0, :cond_8

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0

    :cond_8
    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_EXTERNAL_CAPTURE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-ne v1, p0, :cond_9

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object v0

    :cond_9
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_MAIN_PUBLISH_CHANNEL:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-ne v1, p0, :cond_a

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0

    :cond_a
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_PLAYER:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    if-ne v1, p0, :cond_b

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object v0

    :cond_b
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->ZEGO_VIDEO_SOURCE_SCREEN_CAPTURE:Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-ne v1, p0, :cond_c

    const/4 v3, 0x2

    return-object v0

    :cond_c
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x3

    return-object p0

    :catch_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v0, "ruem neanbnetnTcifeuompntho   o"

    const-string v0, "e oieeopnn r fdnoumbeTtnah ctun"

    const/4 v3, 0x3

    const-string/jumbo v0, "o tnocoreTeeu unafmnnbin h daot"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoVideoSourceType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v2, 0x3

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoVideoSourceType;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoVideoSourceType;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method
