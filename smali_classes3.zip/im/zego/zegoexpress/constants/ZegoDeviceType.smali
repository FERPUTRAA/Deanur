.class public final enum Lim/zego/zegoexpress/constants/ZegoDeviceType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoDeviceType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoDeviceType;

.field public static final enum AUDIO_DEVICE:Lim/zego/zegoexpress/constants/ZegoDeviceType;

.field public static final enum AUDIO_SESSION:Lim/zego/zegoexpress/constants/ZegoDeviceType;

.field public static final enum CAMERA:Lim/zego/zegoexpress/constants/ZegoDeviceType;

.field public static final enum MICROPHONE:Lim/zego/zegoexpress/constants/ZegoDeviceType;

.field public static final enum SPEAKER:Lim/zego/zegoexpress/constants/ZegoDeviceType;

.field public static final enum UNKNOWN:Lim/zego/zegoexpress/constants/ZegoDeviceType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 15

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x7

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v13, 0x7

    move v14, v13

    const-string v1, "ONsUWKN"

    const-string v1, "UOsNNKW"

    const-string v1, "NKNmOUW"

    const-string v1, "UNKNOWN"

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x1

    const/4 v2, 0x0

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x6

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoDeviceType;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x0

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x1

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v14, 0x4

    const/4 v13, 0x6

    const-string v3, "AmCAoM"

    const-string v3, "AMCmEA"

    const/4 v14, 0x0

    const-string v3, "AAREMb"

    const-string v3, "CAMERA"

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x1

    const/4 v4, 0x1

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x6

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoDeviceType;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x4

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoDeviceType;->CAMERA:Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x3

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x5

    const-string/jumbo v5, "oEOPONuIMC"

    const-string v5, "ICOOoHMNPE"

    const/4 v14, 0x2

    const-string v5, "MIRNOCOpEP"

    const-string v5, "MICROPHONE"

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x6

    const/4 v6, 0x2

    const/4 v14, 0x0

    const/4 v13, 0x5

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoDeviceType;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x1

    const/4 v13, 0x2

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoDeviceType;->MICROPHONE:Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x3

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v14, 0x4

    const/4 v13, 0x1

    const-string v7, "bqRAPEK"

    const-string v7, "EPEKAbR"

    const-string v7, "ASsPEEK"

    const-string v7, "SPEAKER"

    const/4 v14, 0x4

    const/4 v8, 0x6

    const/4 v14, 0x5

    const/4 v8, 0x3

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x0

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoDeviceType;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x0

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoDeviceType;->SPEAKER:Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x1

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x0

    const-string v9, "I_EmDUOADCVE"

    const-string v9, "AUDIO_DEVICE"

    const/4 v13, 0x7

    move v14, v13

    const/4 v10, 0x4

    or-int/2addr v14, v10

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoDeviceType;-><init>(Ljava/lang/String;II)V

    const/4 v13, 0x1

    move v14, v13

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoDeviceType;->AUDIO_DEVICE:Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v14, 0x4

    const/4 v13, 0x3

    const/4 v14, 0x4

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x2

    const-string v11, "NOSOoSu_ESAUD"

    const-string v11, "NOOE_SuDSSAUI"

    const/4 v14, 0x5

    const-string v11, "ID_SObNEAUIOS"

    const-string v11, "AUDIO_SESSION"

    const/4 v14, 0x4

    const/4 v13, 0x3

    const/4 v14, 0x3

    const/4 v12, 0x5

    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x0

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoDeviceType;-><init>(Ljava/lang/String;II)V

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x7

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoDeviceType;->AUDIO_SESSION:Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v13, 0x0

    move v14, v13

    const/4 v11, 0x4

    const/4 v11, 0x6

    const/4 v14, 0x0

    new-array v11, v11, [Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v13, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x0

    aput-object v0, v11, v2

    const/4 v14, 0x7

    aput-object v1, v11, v4

    const/4 v14, 0x6

    const/4 v13, 0x6

    aput-object v3, v11, v6

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x2

    aput-object v5, v11, v8

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x0

    aput-object v7, v11, v10

    const/4 v14, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x3

    aput-object v9, v11, v12

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x4

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoDeviceType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x3

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->value:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public static getZegoDeviceType(I)Lim/zego/zegoexpress/constants/ZegoDeviceType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@d@@~@u@@ f/~@r~ b@ 1oo@lmM@@@i~/@.S-t o@~   ~ b@@yo@ft ~ ~@bin~@vsi~ o@4 ~~l~u~  ~ a~  ~K~~~c~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-ne v1, p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->CAMERA:Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-ne v1, p0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->MICROPHONE:Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->value:I

    const/4 v3, 0x3

    if-ne v1, p0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x5

    return-object v0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->SPEAKER:Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ne v1, p0, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->AUDIO_DEVICE:Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->value:I

    const/4 v3, 0x3

    if-ne v1, p0, :cond_4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object v0

    :cond_4
    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->AUDIO_SESSION:Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-ne v1, p0, :cond_5

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object v0

    :cond_5
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object p0

    :catch_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v0, "en oo npndea oinnftTcba prmeeth"

    const-string v0, "eim nfnp aonnotdroauec  tnebeTh"

    const/4 v3, 0x3

    const-string v0, "eTut ha qrbae fnotnoinum ceoedn"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoDeviceType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-class v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v2, 0x4

    const-class v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoDeviceType;

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoDeviceType;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoDeviceType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoDeviceType;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoDeviceType;->value:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method
