.class public final enum Lim/zego/zegoexpress/constants/ZegoDumpDataType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoDumpDataType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoDumpDataType;

.field public static final enum AUDIO:Lim/zego/zegoexpress/constants/ZegoDumpDataType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x2

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string v1, "UAsIs"

    const-string v1, "AUsID"

    const/4 v4, 0x2

    const-string v1, "DIUmA"

    const-string v1, "AUDIO"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoDumpDataType;-><init>(Ljava/lang/String;II)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoDumpDataType;->AUDIO:Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v1, 0x1

    move v4, v1

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-array v1, v1, [Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const/4 v3, 0x2

    move v4, v3

    aput-object v0, v1, v2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoDumpDataType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const/4 v4, 0x4

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoDumpDataType;->value:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public static getZegoDumpDataType(I)Lim/zego/zegoexpress/constants/ZegoDumpDataType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "u@~~o~@~c@ o M@~o-@ls@ ~mvrb~~d  f~@i@4~ ~oS@ i y@~ K @@b~~~t.o@o@fb@~ @@o@i~  /~@~n a1/t ~ l~@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDumpDataType;->AUDIO:Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoDumpDataType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-ne v1, p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p0

    :catch_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v0, " eembtThu o aoenn rudfeninaocmn"

    const/4 v3, 0x2

    const-string v0, "aufe bdothconrTtine e aneubn mo"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoDumpDataType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoDumpDataType;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDumpDataType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoDumpDataType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoDumpDataType;->value:I

    const/4 v2, 0x3

    const/4 v1, 0x4

    return v0
.end method
