.class public final enum Lim/zego/zegoexpress/constants/ZegoAudioChannel;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoAudioChannel;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioChannel;

.field public static final enum MONO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

.field public static final enum STEREO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

.field public static final enum UNKNOWN:Lim/zego/zegoexpress/constants/ZegoAudioChannel;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v8, 0x7

    const-string v1, "NUsOWNs"

    const-string v1, "ONsNUKW"

    const/4 v8, 0x3

    const-string v1, "NNKmUWN"

    const-string v1, "UNKNOWN"

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    const/4 v2, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v8, 0x7

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string v3, "NOOM"

    const/4 v8, 0x6

    const-string v3, "MNOO"

    const-string v3, "MONO"

    const/4 v8, 0x1

    const/4 v4, 0x1

    const/4 v7, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->MONO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-string v5, "OEmEoS"

    const-string v5, "ESOmET"

    const/4 v8, 0x3

    const-string v5, "SEOTEb"

    const-string v5, "STEREO"

    const/4 v7, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    const/4 v6, 0x2

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->STEREO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v7, 0x4

    shr-int/2addr v8, v7

    const/4 v5, 0x3

    move v8, v5

    const/4 v7, 0x3

    xor-int/2addr v8, v7

    new-array v5, v5, [Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    aput-object v0, v5, v2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    aput-object v1, v5, v4

    const/4 v8, 0x1

    aput-object v3, v5, v6

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v8, 0x2

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public static getZegoAudioChannel(I)Lim/zego/zegoexpress/constants/ZegoAudioChannel;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " r@~  u ~@~~- ~ @d~~ @@if@@vM@~o@~@o ~/~@~~ tb.ytS ~ba~@c~obi@ / l~li@Ku@ ~o~f@1@@~ 4soo ~~ @ m@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-ne v1, p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->MONO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-ne v1, p0, :cond_1

    const/4 v3, 0x3

    return-object v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->STEREO:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-ne v1, p0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-object p0

    :catch_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v0, "oTmnntnpoecbu eftnun eoi erhoa "

    const-string/jumbo v0, "h orobneTfu ttec noeaannmoi eun"

    const/4 v3, 0x6

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    move v3, v2

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoAudioChannel;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoAudioChannel;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoAudioChannel;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value:I

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method
