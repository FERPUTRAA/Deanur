.class public final enum Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

.field public static final enum AUTO_FOCUS:Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

.field public static final enum CONTINUOUS_AUTO_FOCUS:Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x0

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const/4 v5, 0x3

    shl-int/2addr v6, v5

    const-string v1, "TAsFUOC_sO"

    const-string v1, "_TsCAFOUUO"

    const/4 v6, 0x2

    const-string v1, "SU_mATOFUC"

    const-string v1, "AUTO_FOCUS"

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x2

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;-><init>(Ljava/lang/String;II)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;->AUTO_FOCUS:Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string v3, "CONAo_UCmOUOTTFUIS_SO"

    const-string v3, "OUCmSFNTOCISU_OUOT_AU"

    const/4 v6, 0x3

    const-string v3, "ONFUUbUCUCTAOOOT_ISSN"

    const-string v3, "CONTINUOUS_AUTO_FOCUS"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v4, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;-><init>(Ljava/lang/String;II)V

    const/4 v6, 0x3

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;->CONTINUOUS_AUTO_FOCUS:Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v3, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x6

    new-array v3, v3, [Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    aput-object v0, v3, v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    aput-object v1, v3, v4

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const/4 v6, 0x2

    const/4 v5, 0x7

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v0, 0x6

    const/4 v0, 0x7

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;->value:I

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public static getZegoCameraFocusMode(I)Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~a/t@~u@s1@ ~/~~@ l~y~~@mn@ @  dilf~~o~ ~-@.@@oS 4@o  @r~  ~@@  bbc o~ uo~~~~@ @f@bMi@@Ki~o~v~ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;->AUTO_FOCUS:Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const/4 v2, 0x2

    move v3, v2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;->value:I

    const/4 v2, 0x5

    move v3, v2

    if-ne v1, p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    return-object v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;->CONTINUOUS_AUTO_FOCUS:Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-ne v1, p0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object p0

    :catch_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v0, "uh ae npbcn touooeoadne mtrniTf"

    const-string v0, "anoeo d t Ttneoeuoneracnmhfbui "

    const-string/jumbo v0, "teehd biq ono nuTtocenufaanermn"

    const-string v0, "The enumeration cannot be found"

    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    or-int/2addr v3, v2

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;->value:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method
