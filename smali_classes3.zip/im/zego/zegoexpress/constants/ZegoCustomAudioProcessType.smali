.class public final enum Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

.field public static final enum CAPTURE:Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

.field public static final enum CAPTURE_AND_REMOTE:Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

.field public static final enum REMOTE:Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v7, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string v1, "MTsEsR"

    const-string v1, "OTsMER"

    const/4 v8, 0x0

    const-string v1, "EROmME"

    const-string v1, "REMOTE"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/4 v2, 0x0

    const/4 v8, 0x5

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->REMOTE:Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v8, 0x6

    const/4 v7, 0x7

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string v3, "UACmoTP"

    const-string v3, "TCRmPUA"

    const/4 v8, 0x6

    const-string v3, "TAUPCbR"

    const-string v3, "CAPTURE"

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 v4, 0x1

    const/4 v7, 0x7

    move v8, v7

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->CAPTURE:Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    const-string v5, "EURORTuAC_TAM_PDNo"

    const-string v5, "ETOToCARP_D_RAEMUN"

    const-string v5, "_TCDOEEpARAUETMR_P"

    const-string v5, "CAPTURE_AND_REMOTE"

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/4 v6, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->CAPTURE_AND_REMOTE:Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/4 v5, 0x3

    const/4 v8, 0x7

    new-array v5, v5, [Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    aput-object v0, v5, v2

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    aput-object v1, v5, v4

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    aput-object v3, v5, v6

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->value:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static getZegoCustomAudioProcessType(I)Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "u @@@ v q~ @@~ i~am~.@/@i o @Kol~~@o~nt~o~bo~@ ~o t  c~@s@f@i~/r  ~4@b~@d~~~S~f-@@  l~M@~@1~@b  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->REMOTE:Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v1, p0, :cond_0

    const/4 v2, 0x0

    or-int/2addr v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->CAPTURE:Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->value:I

    if-ne v1, p0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->CAPTURE_AND_REMOTE:Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    move v3, v2

    if-ne v1, p0, :cond_2

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p0

    :catch_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v0, "netmnb hn aneueorioTe tabo nudf"

    const/4 v3, 0x4

    const-string/jumbo v0, "testecmnoo rond ehu ea nTfbuian"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v2, 0x5

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v1, 0x5

    shr-int/2addr v2, v1

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;

    const/4 v2, 0x6

    const/4 v1, 0x6

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoCustomAudioProcessType;->value:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method
