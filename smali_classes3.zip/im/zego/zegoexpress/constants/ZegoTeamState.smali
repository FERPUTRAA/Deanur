.class public final enum Lim/zego/zegoexpress/constants/ZegoTeamState;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoTeamState;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoTeamState;

.field public static final enum KICK_OUT:Lim/zego/zegoexpress/constants/ZegoTeamState;

.field public static final enum LOGINED:Lim/zego/zegoexpress/constants/ZegoTeamState;

.field public static final enum LOGINING:Lim/zego/zegoexpress/constants/ZegoTeamState;

.field public static final enum LOGIN_FAILED:Lim/zego/zegoexpress/constants/ZegoTeamState;

.field public static final enum LOGOUT:Lim/zego/zegoexpress/constants/ZegoTeamState;

.field public static final enum RECONNECTED:Lim/zego/zegoexpress/constants/ZegoTeamState;

.field public static final enum RECONNECTING:Lim/zego/zegoexpress/constants/ZegoTeamState;

.field public static final enum RECONNECT_FAILED:Lim/zego/zegoexpress/constants/ZegoTeamState;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const-string v1, "NGssINGL"

    const-string v1, "GIsLOGNN"

    const-string v1, "LOImGIGN"

    const-string v1, "LOGINING"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoTeamState;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->LOGINING:Lim/zego/zegoexpress/constants/ZegoTeamState;

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const-string/jumbo v3, "mDLIoOE"

    const-string v3, "NILmODE"

    const-string v3, "LNEDIbG"

    const-string v3, "LOGINED"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoTeamState;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoTeamState;->LOGINED:Lim/zego/zegoexpress/constants/ZegoTeamState;

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const-string v5, "EIFGDouN_IOA"

    const-string v5, "FAOIoENLD_GI"

    const-string v5, "LLDONFGpEAII"

    const-string v5, "LOGIN_FAILED"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoTeamState;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoTeamState;->LOGIN_FAILED:Lim/zego/zegoexpress/constants/ZegoTeamState;

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const-string v7, "RbCEGOTNqNNE"

    const-string v7, "NCENTbCEGONR"

    const-string v7, "RTsNEOECNICG"

    const-string v7, "RECONNECTING"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v8}, Lim/zego/zegoexpress/constants/ZegoTeamState;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoTeamState;->RECONNECTING:Lim/zego/zegoexpress/constants/ZegoTeamState;

    new-instance v7, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const-string/jumbo v9, "uERmDCNCENE"

    const-string v9, "EETERCuCNND"

    const-string v9, "ONRDoCEENTC"

    const-string v9, "RECONNECTED"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10, v10}, Lim/zego/zegoexpress/constants/ZegoTeamState;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoTeamState;->RECONNECTED:Lim/zego/zegoexpress/constants/ZegoTeamState;

    new-instance v9, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const-string v11, "ERCpAbLOTDNE_NCI"

    const-string v11, "EROETALpCNDC_INE"

    const-string v11, "ECTCRLuEDOEN_INA"

    const-string v11, "RECONNECT_FAILED"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12, v12}, Lim/zego/zegoexpress/constants/ZegoTeamState;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lim/zego/zegoexpress/constants/ZegoTeamState;->RECONNECT_FAILED:Lim/zego/zegoexpress/constants/ZegoTeamState;

    new-instance v11, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const-string v13, "KCOqITUp"

    const-string/jumbo v13, "qUKTCKIO"

    const-string/jumbo v13, "qTICKO_U"

    const-string v13, "KICK_OUT"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14, v14}, Lim/zego/zegoexpress/constants/ZegoTeamState;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lim/zego/zegoexpress/constants/ZegoTeamState;->KICK_OUT:Lim/zego/zegoexpress/constants/ZegoTeamState;

    new-instance v13, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const-string v15, "OGsOTU"

    const-string v15, "TOsLOU"

    const-string v15, "LOGOUT"

    const/4 v14, 0x7

    invoke-direct {v13, v15, v14, v14}, Lim/zego/zegoexpress/constants/ZegoTeamState;-><init>(Ljava/lang/String;II)V

    sput-object v13, Lim/zego/zegoexpress/constants/ZegoTeamState;->LOGOUT:Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/16 v15, 0x8

    new-array v15, v15, [Lim/zego/zegoexpress/constants/ZegoTeamState;

    aput-object v0, v15, v2

    aput-object v1, v15, v4

    aput-object v3, v15, v6

    aput-object v5, v15, v8

    aput-object v7, v15, v10

    aput-object v9, v15, v12

    const/4 v0, 0x6

    aput-object v11, v15, v0

    aput-object v13, v15, v14

    sput-object v15, Lim/zego/zegoexpress/constants/ZegoTeamState;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoTeamState;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoTeamState;->value:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public static getZegoTeamState(I)Lim/zego/zegoexpress/constants/ZegoTeamState;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ sm~~o~ oyMv~~o@~d@ @t b~ inbr~@@a@ @ ~~4 @b m@uoot~ S /  i ~@@@c K~-~~.f@~@@ @l@l~1fo@~@@ ~~/i"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->LOGINING:Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-ne v1, p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->LOGINED:Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->value:I

    const/4 v3, 0x5

    if-ne v1, p0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->LOGIN_FAILED:Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    if-ne v1, p0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object v0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->RECONNECTING:Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-ne v1, p0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->RECONNECTED:Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-ne v1, p0, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0

    :cond_4
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->RECONNECT_FAILED:Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-ne v1, p0, :cond_5

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0

    :cond_5
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->KICK_OUT:Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-ne v1, p0, :cond_6

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0

    :cond_6
    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->LOGOUT:Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-ne v1, p0, :cond_7

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0

    :cond_7
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p0

    :catch_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo v0, "n emTeni mae eurtabon coundhtof"

    const/4 v3, 0x3

    const-string v0, "bodnof cor tTieuntnna euhnmeao "

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoTeamState;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoTeamState;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTeamState;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoTeamState;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoTeamState;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoTeamState;->value:I

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method
