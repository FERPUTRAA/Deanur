.class public final enum Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

.field public static final enum CAPTURED:Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

.field public static final enum MIXED:Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

.field public static final enum PLAYBACK:Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

.field public static final enum PLAYER:Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 13

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x0

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-string v1, "PRsEDATC"

    const-string v1, "CAPTURED"

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x3

    const/4 v2, 0x0

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x4

    const/4 v3, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-direct {v0, v1, v2, v3}, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;-><init>(Ljava/lang/String;II)V

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x4

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->CAPTURED:Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    const-string v4, "LCKmAAPs"

    const-string v4, "BAsALKPC"

    const-string v4, "PBYKoLCA"

    const-string v4, "PLAYBACK"

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x6

    const/4 v5, 0x2

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-direct {v1, v4, v3, v5}, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;-><init>(Ljava/lang/String;II)V

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x2

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->PLAYBACK:Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    new-instance v4, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string v6, "bEImM"

    const-string v6, "IEDmM"

    const/4 v12, 0x1

    const-string v6, "XuDIM"

    const-string v6, "MIXED"

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x4

    const/4 v7, 0x4

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-direct {v4, v6, v5, v7}, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;-><init>(Ljava/lang/String;II)V

    const/4 v11, 0x1

    shr-int/2addr v12, v11

    sput-object v4, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->MIXED:Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x5

    new-instance v6, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v12, 0x0

    const/16 v8, 0x8

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x0

    const-string v9, "YpAELP"

    const-string v9, "PLAYER"

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v10, 0x3

    move v12, v10

    const/4 v11, 0x1

    const/4 v11, 0x3

    invoke-direct {v6, v9, v10, v8}, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;-><init>(Ljava/lang/String;II)V

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x2

    sput-object v6, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->PLAYER:Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    new-array v7, v7, [Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    aput-object v0, v7, v2

    const/4 v12, 0x0

    aput-object v1, v7, v3

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x5

    aput-object v4, v7, v5

    const/4 v12, 0x5

    const/4 v11, 0x3

    aput-object v6, v7, v10

    const/4 v12, 0x7

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->value:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static getZegoAudioDataCallbackBitMask(I)Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " -@o@rdfq o@ ~~u @.~ o KbiloSc~ 1~@f~m@o@@~v4b~~@Msb~n~~  /l ~~~~@y   ~~~i@ o@t~@ /@@~tia~@@ @@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->CAPTURED:Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v3, 0x4

    const/4 v2, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->value:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-ne v1, p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->PLAYBACK:Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->value:I

    const/4 v2, 0x7

    move v3, v2

    if-ne v1, p0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->MIXED:Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-ne v1, p0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0

    :cond_2
    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->PLAYER:Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    move v3, v2

    if-ne v1, p0, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x5

    return-object v0

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p0

    :catch_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo v0, "oestoecunhbfinmnt n n eTaaoeud "

    const-string/jumbo v0, "nidaonn bTenu feueco hoone tatm"

    const/4 v3, 0x2

    const-string/jumbo v0, "un mtt fhncmadebeeTao noiern nu"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v2, 0x1

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoAudioDataCallbackBitMask;->value:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method
