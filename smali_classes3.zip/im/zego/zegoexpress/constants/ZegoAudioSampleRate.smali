.class public final enum Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

.field public static final enum UNKNOWN:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

.field public static final enum ZEGO_AUDIO_SAMPLE_RATE_16K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

.field public static final enum ZEGO_AUDIO_SAMPLE_RATE_22K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

.field public static final enum ZEGO_AUDIO_SAMPLE_RATE_24K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

.field public static final enum ZEGO_AUDIO_SAMPLE_RATE_32K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

.field public static final enum ZEGO_AUDIO_SAMPLE_RATE_44K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

.field public static final enum ZEGO_AUDIO_SAMPLE_RATE_48K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

.field public static final enum ZEGO_AUDIO_SAMPLE_RATE_8K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const-string v1, "NUsNNsK"

    const-string v1, "NNsKNOU"

    const-string v1, "UNKNOWN"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/16 v3, 0x1f40

    const-string v4, "_DOmRPKE_EOA_EIAMGAZTU8_L"

    const-string v4, "_OPmIR_EE_A_ASODUTMEG8LZK"

    const-string v4, "ZEGO_AUDIO_SAMPLE_RATE_8K"

    const/4 v5, 0x1

    invoke-direct {v1, v4, v5, v3}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_8K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/16 v4, 0x3e80

    const-string v6, "E1O_oKP_AEREGOIZAoMTU6ASD_"

    const-string v6, "_MZDoGAE_OOERS_I_UEAP61ATK"

    const-string v6, "_ULEEbSOO1MADAAZ_TE_G_6KRP"

    const-string v6, "ZEGO_AUDIO_SAMPLE_RATE_16K"

    const/4 v7, 0x2

    invoke-direct {v3, v6, v7, v4}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_16K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    new-instance v4, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/16 v6, 0x5622

    const-string v8, "AEDGALuRPT_I_OME2b_SKE2A_Z"

    const-string v8, "A_2ATbZLAO_EPUS2EKDGI_M_RE"

    const-string v8, "S_PADAEpIL2OERZ_MGKOT_A2_E"

    const-string v8, "ZEGO_AUDIO_SAMPLE_RATE_22K"

    const/4 v9, 0x3

    invoke-direct {v4, v8, v9, v6}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_22K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    new-instance v6, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/16 v8, 0x5dc0

    const-string v10, "D_EOAM__qK_ZULGEPAOIR42ETA"

    const-string v10, "DULEOKu_GAOA2EEMTPZRAI__4_"

    const-string v10, "EKs2PAE_MO_EAORTUS_D_A4ZGL"

    const-string v10, "ZEGO_AUDIO_SAMPLE_RATE_24K"

    const/4 v11, 0x4

    invoke-direct {v6, v10, v11, v8}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_24K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    new-instance v8, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/16 v10, 0x7d00

    const-string v12, "TLZmEGRSP_U3OKpMD_AI_OEEAA"

    const-string v12, "MA3IETKpA_EP___UOOGLDARZES"

    const-string v12, "_AEIoS23ZPRDL_E_U_GOATKEAO"

    const-string v12, "ZEGO_AUDIO_SAMPLE_RATE_32K"

    const/4 v13, 0x5

    invoke-direct {v8, v12, v13, v10}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;-><init>(Ljava/lang/String;II)V

    sput-object v8, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_32K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    new-instance v10, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const v12, 0xac44

    const-string v14, "D4ZMPbEEAS_G4KURLqIT_O_EA_"

    const-string v14, "RELE4TDZqEK_GUMOA4SIPA___A"

    const-string v14, "GOKTPAu__AA_SEEOUEI4_DLMRZ"

    const-string v14, "ZEGO_AUDIO_SAMPLE_RATE_44K"

    const/4 v15, 0x6

    invoke-direct {v10, v14, v15, v12}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;-><init>(Ljava/lang/String;II)V

    sput-object v10, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_44K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    new-instance v12, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const v14, 0xbb80

    const-string v15, "SEAI_sZpOO_RTUGKAEPL__ME4D"

    const-string v15, "KAs_ZAPRUGEMOA_T_LS_OE4IDE"

    const-string v15, "R_OZPAOEq_ULG4EAITKMAD_8SE"

    const-string v15, "ZEGO_AUDIO_SAMPLE_RATE_48K"

    const/4 v13, 0x7

    invoke-direct {v12, v15, v13, v14}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;-><init>(Ljava/lang/String;II)V

    sput-object v12, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_48K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/16 v14, 0x8

    new-array v14, v14, [Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    aput-object v0, v14, v2

    aput-object v1, v14, v5

    aput-object v3, v14, v7

    aput-object v4, v14, v9

    aput-object v6, v14, v11

    const/4 v0, 0x5

    aput-object v8, v14, v0

    const/4 v0, 0x6

    aput-object v10, v14, v0

    aput-object v12, v14, v13

    sput-object v14, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public static getZegoAudioSampleRate(I)Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @s~iv~  l ~@@lyiob~ru @@o1 K~@~ s~~/ t/fd @~. @@ o4 @~@@~obo@@~~o ~@ifmtb~@~-@M@~c@~~~~ n@ aS~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-ne v1, p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_8K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-ne v1, p0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object v0

    :cond_1
    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_16K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-ne v1, p0, :cond_2

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_22K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-ne v1, p0, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0

    :cond_3
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_24K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-ne v1, p0, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object v0

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_32K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value:I

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-ne v1, p0, :cond_5

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object v0

    :cond_5
    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_44K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-ne v1, p0, :cond_6

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v0

    :cond_6
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->ZEGO_AUDIO_SAMPLE_RATE_48K:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-ne v1, p0, :cond_7

    const/4 v3, 0x0

    const/4 v2, 0x6

    return-object v0

    :cond_7
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p0

    :catch_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x6

    const-string/jumbo v0, "ndumoainaefmcn eoe  brtmnnu oht"

    const-string/jumbo v0, "icnmmhonue  bn aaredun tTooeftn"

    const/4 v3, 0x1

    const-string/jumbo v0, "tedfoeTa ba  n nmonntoeciuurenh"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    return v0
.end method
