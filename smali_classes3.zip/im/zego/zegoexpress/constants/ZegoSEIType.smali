.class public final enum Lim/zego/zegoexpress/constants/ZegoSEIType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoSEIType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoSEIType;

.field public static final enum USER_UNREGISTER:Lim/zego/zegoexpress/constants/ZegoSEIType;

.field public static final enum ZEGO_DEFINED:Lim/zego/zegoexpress/constants/ZegoSEIType;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const-string v1, "FDsE_EGIDsEO"

    const-string v1, "EFsDIEGEODN_"

    const/4 v6, 0x3

    const-string v1, "DEFm_ENOZGEI"

    const-string v1, "ZEGO_DEFINED"

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v6, 0x7

    move v5, v2

    move v5, v2

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoSEIType;-><init>(Ljava/lang/String;II)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoSEIType;->ZEGO_DEFINED:Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v6, 0x2

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v3, "GERIoUTRSNSUEER"

    const-string v3, "USER_UNREGISTER"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v4, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoSEIType;-><init>(Ljava/lang/String;II)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoSEIType;->USER_UNREGISTER:Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v3, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x6

    new-array v3, v3, [Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v6, 0x0

    const/4 v5, 0x0

    aput-object v0, v3, v2

    const/4 v5, 0x6

    xor-int/2addr v6, v5

    aput-object v1, v3, v4

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoSEIType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v0, 0x4

    or-int/2addr v1, v0

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoSEIType;->value:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public static getZegoSEIType(I)Lim/zego/zegoexpress/constants/ZegoSEIType;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~o@ob@~tfo@iyo@o/@@M-~v/m4@~~~K ~a~u @~ ~t ~ ~ ~ nd@@~ @r@os  l  f @@@~.@@lc@ @ib~S  1i~b~@~ ~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoSEIType;->ZEGO_DEFINED:Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoSEIType;->value:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-ne v1, p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoSEIType;->USER_UNREGISTER:Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoSEIType;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-ne v1, p0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object v0

    :cond_1
    const/4 v2, 0x0

    move v3, v2

    const/4 p0, 0x0

    move v3, p0

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    return-object p0

    :catch_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v0, "bu mnmeordunateh   tneaofcoTnen"

    const/4 v3, 0x3

    const-string/jumbo v0, "teeT iunnt nemornfuuchbdnooa  e"

    const-string v0, "The enumeration cannot be found"

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoSEIType;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x3

    const-class v0, Lim/zego/zegoexpress/constants/ZegoSEIType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v2, 0x1

    const-class v0, Lim/zego/zegoexpress/constants/ZegoSEIType;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoSEIType;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoSEIType;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoSEIType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoSEIType;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoSEIType;->value:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method
