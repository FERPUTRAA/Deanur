.class public final enum Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

.field public static final enum NO_RELAY:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

.field public static final enum RELAYING:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

.field public static final enum RELAY_REQUESTING:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string v1, "AEs_ONsL"

    const-string v1, "EOsAL_NR"

    const/4 v8, 0x1

    const-string v1, "YRNmLAEO"

    const-string v1, "NO_RELAY"

    const/4 v7, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v2, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->NO_RELAY:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v8, 0x0

    const-string v3, "NSE_oGELUYIQTERA"

    const-string v3, "UE_mYNESAGQLRTEI"

    const/4 v8, 0x7

    const-string v3, "_EINLbARQGEEUSYT"

    const-string v3, "RELAY_REQUESTING"

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/4 v4, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->RELAY_REQUESTING:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string/jumbo v5, "oALEYNuR"

    const-string v5, "LNYEoGRA"

    const-string v5, "GILAYNEp"

    const-string v5, "RELAYING"

    const/4 v8, 0x6

    const/4 v6, 0x2

    const/4 v8, 0x7

    move v7, v6

    move v7, v6

    const/4 v8, 0x0

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->RELAYING:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v5, 0x3

    move v8, v5

    move v7, v5

    move v7, v5

    const/4 v8, 0x3

    new-array v5, v5, [Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v7, 0x3

    const/4 v8, 0x3

    aput-object v0, v5, v2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    aput-object v1, v5, v4

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    aput-object v3, v5, v6

    const/4 v8, 0x5

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->value:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public static getZegoStreamRelayCDNState(I)Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " @K@@~ @q~@~~M @f~oo/~ao  ~.~o- fbi@t bi~c@/@s ~i~~~n 4mv@@~ ~u b  yt @@@o~~~@~rl lS@ o@~~@~ 1@d"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->NO_RELAY:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->value:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-ne v1, p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->RELAY_REQUESTING:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->value:I

    const/4 v3, 0x3

    if-ne v1, p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->RELAYING:Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v3, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ne v1, p0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object p0

    :catch_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string/jumbo v0, "etsTr tuubabd minnonnenhf oae e"

    const-string/jumbo v0, "tfueubienhaeoo b dmnton nernTa "

    const/4 v3, 0x0

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoStreamRelayCDNState;->value:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method
