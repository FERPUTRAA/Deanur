.class public final enum Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

.field public static final enum ADAPTIVE_AUDIO_BITRATE:Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

.field public static final enum ADAPTIVE_FPS:Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

.field public static final enum ADAPTIVE_RESOLUTION:Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

.field public static final enum BASIC:Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 12

    const/4 v10, 0x6

    const/4 v11, 0x7

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string v1, "ASsIs"

    const-string v1, "CSsIA"

    const-string v1, "SICmA"

    const-string v1, "BASIC"

    const/4 v11, 0x0

    const/4 v2, 0x4

    const/4 v11, 0x3

    const/4 v2, 0x0

    const/4 v10, 0x0

    or-int/2addr v11, v10

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;-><init>(Ljava/lang/String;II)V

    const/4 v11, 0x4

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->BASIC:Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    const-string v3, "SmAFoDA_IETV"

    const-string v3, "_VEmIPADASFT"

    const/4 v11, 0x5

    const-string v3, "PDATSbEIFV_A"

    const-string v3, "ADAPTIVE_FPS"

    const/4 v10, 0x0

    move v11, v10

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;-><init>(Ljava/lang/String;II)V

    const/4 v10, 0x1

    shr-int/2addr v11, v10

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->ADAPTIVE_FPS:Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    const-string v5, "NAAOETuVRISELIDUPO_"

    const-string v5, "PIANo_IEOLRUASTVDEO"

    const-string v5, "PSTTLDUpVI_AIEOARON"

    const-string v5, "ADAPTIVE_RESOLUTION"

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x1

    const/4 v6, 0x2

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;-><init>(Ljava/lang/String;II)V

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->ADAPTIVE_RESOLUTION:Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    new-instance v5, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    const-string v7, "EEBbAVUTq__PDOTITDAIRI"

    const-string v7, "UAIOEbTAREV_TDBPI_DITA"

    const/4 v11, 0x0

    const-string v7, "EDsIVEIABAPA_IO_TUDTTA"

    const-string v7, "ADAPTIVE_AUDIO_BITRATE"

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    const/4 v8, 0x3

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x5

    const/4 v9, 0x4

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-direct {v5, v7, v8, v9}, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;-><init>(Ljava/lang/String;II)V

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->ADAPTIVE_AUDIO_BITRATE:Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    new-array v7, v9, [Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v11, 0x7

    aput-object v0, v7, v2

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x7

    aput-object v1, v7, v4

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    aput-object v3, v7, v6

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x4

    aput-object v5, v7, v8

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    sput-object v7, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v11, 0x0

    const/4 v10, 0x0

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->value:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public static getZegoTrafficControlProperty(I)Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@@m  M@ oy~~@r-~@ Kd~/i~ ~@~~v~ @~@so t@f~ a~~@tb1  u .S@fl boo~ m l~~oon@@b@ @ 4@c~@i@~/@~ i@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->BASIC:Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-ne v1, p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->ADAPTIVE_FPS:Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->value:I

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-ne v1, p0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->ADAPTIVE_RESOLUTION:Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v3, 0x5

    const/4 v2, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-ne v1, p0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->ADAPTIVE_AUDIO_BITRATE:Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x1

    if-ne v1, p0, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p0

    :catch_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v0, "a beodmurcote nfuneo nnTtuoeian"

    const-string v0, "T unnnuned cobfato aiunet ermoe"

    const/4 v3, 0x5

    const-string v0, "aTnnabodei ettcemon uuf h nbneo"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-class v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v2, 0x7

    const-class v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoTrafficControlProperty;->value:I

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method
