.class public final enum Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

.field public static final enum AUTO:Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

.field public static final enum OFF:Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

.field public static final enum ON:Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;


# instance fields
.field private value:I


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    new-instance v0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v1, "OFF"

    const-string v1, "FFO"

    const/4 v8, 0x0

    const-string v1, "FFO"

    const-string v1, "OFF"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/4 v2, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {v0, v1, v2, v2}, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    sput-object v0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->OFF:Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance v1, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const-string v3, "NO"

    const-string v3, "NO"

    const/4 v8, 0x2

    const-string v3, "NO"

    const-string v3, "ON"

    const/4 v8, 0x1

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-direct {v1, v3, v4, v4}, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    sput-object v1, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->ON:Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance v3, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string v5, "AOTU"

    const-string v5, "UAOT"

    const/4 v8, 0x6

    const-string v5, "OUTA"

    const-string v5, "AUTO"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/4 v6, 0x2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-direct {v3, v5, v6, v6}, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;-><init>(Ljava/lang/String;II)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    sput-object v3, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->AUTO:Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v5, 0x3

    new-array v5, v5, [Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    aput-object v0, v5, v2

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    aput-object v1, v5, v4

    const/4 v7, 0x3

    xor-int/2addr v8, v7

    aput-object v3, v5, v6

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    sput-object v5, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1000,
            0x1000,
            0x0
        }
        names = {
            "$enum$name",
            "$enum$ordinal",
            "value"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p3, p0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->value:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public static getZegoLowlightEnhancementMode(I)Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " -s@@@r~~  ~1~Kl~~@@@no~@iMy co  b~ @@~v b@ oS@~ d~  @@a @t@~4@~~ u@b~ .~@~ @~o slft~/@~~/ofmii~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->OFF:Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v3, 0x3

    const/4 v2, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->value:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ne v1, p0, :cond_0

    const/4 v2, 0x4

    move v3, v2

    return-object v0

    :cond_0
    const/4 v3, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->ON:Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v2, 0x0

    const/4 v2, 0x1

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->value:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-ne v1, p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->AUTO:Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget v1, v0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->value:I
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-ne v1, p0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0

    :cond_2
    const/4 v3, 0x4

    const/4 p0, 0x5

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object p0

    :catch_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/RuntimeException;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v0, "nunmeiT ambtehofo ore ns dannec"

    const-string/jumbo v0, "ots fdTin bcmnornnntaeeue oh ae"

    const/4 v3, 0x0

    const-string/jumbo v0, "urfeonoua dn oeten othab cneinm"

    const-string v0, "The enumeration cannot be found"

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    throw p0
.end method

.method public static valueOf(Ljava/lang/String;)Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x8000
        }
        names = {
            "name"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-class v0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const-class v0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v2, 0x1

    const-class v0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    check-cast p0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p0
.end method

.method public static values()[Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->$VALUES:[Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    check-cast v0, [Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public value()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->value:I

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return v0
.end method
