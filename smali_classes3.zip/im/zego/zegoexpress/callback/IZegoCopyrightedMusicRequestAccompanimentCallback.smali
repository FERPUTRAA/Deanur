.class public interface abstract Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestAccompanimentCallback;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onRequestAccompanimentCallback(ILjava/lang/String;)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "errorCode",
            "resource"
        }
    .end annotation
.end method
