.class public abstract Lim/zego/zegoexpress/callback/IZegoRangeAudioEventHandler;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onRangeAudioMicrophoneStateUpdate(Lim/zego/zegoexpress/ZegoRangeAudio;Lim/zego/zegoexpress/constants/ZegoRangeAudioMicrophoneState;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeAudio",
            "state",
            "errorCode"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " @s ao K oc/rv@o@~ f- ~st~du@ol~ ~ ~ @S ~io@@Mby@~  ~~@ @ m~f~@~@l~i@~ b@@~~ ~~@/@@@~4tn~i~.o1 @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    return-void
.end method
