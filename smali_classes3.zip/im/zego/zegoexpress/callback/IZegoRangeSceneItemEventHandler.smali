.class public abstract Lim/zego/zegoexpress/callback/IZegoRangeSceneItemEventHandler;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onItemBindUpdate(Lim/zego/zegoexpress/ZegoRangeScene;JLjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "itemID",
            "userID"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~so/i @. ~  b~~s@ @f@~@i~m/S@~o~~cl-  @vl~@~~b@ @t~@@o@ ~@n~t~o @@  1d@@ fr~M~ @K~4a~~oo i ~yu@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    return-void
.end method

.method public onItemCommandUpdate(Lim/zego/zegoexpress/ZegoRangeScene;JLim/zego/zegoexpress/entity/ZegoPosition;I[B)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "itemID",
            "position",
            "channel",
            "command"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public onItemEnterView(Lim/zego/zegoexpress/ZegoRangeScene;JILim/zego/zegoexpress/entity/ZegoPosition;Ljava/util/ArrayList;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "itemID",
            "capacity",
            "position",
            "userList"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lim/zego/zegoexpress/ZegoRangeScene;",
            "JI",
            "Lim/zego/zegoexpress/entity/ZegoPosition;",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public onItemLeaveView(Lim/zego/zegoexpress/ZegoRangeScene;J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "itemID"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public onItemStatusUpdate(Lim/zego/zegoexpress/ZegoRangeScene;JLim/zego/zegoexpress/entity/ZegoPosition;I[B)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "itemID",
            "position",
            "channel",
            "status"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public onItemUnbindUpdate(Lim/zego/zegoexpress/ZegoRangeScene;JLjava/util/ArrayList;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "itemID",
            "userList"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lim/zego/zegoexpress/ZegoRangeScene;",
            "J",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method
