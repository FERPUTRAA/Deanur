.class public interface abstract Lim/zego/zegoexpress/callback/IZegoDestroyCompletionCallback;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onDestroyCompletion()V
.end method
