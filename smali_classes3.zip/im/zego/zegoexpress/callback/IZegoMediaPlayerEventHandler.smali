.class public abstract Lim/zego/zegoexpress/callback/IZegoMediaPlayerEventHandler;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onMediaPlayerFirstFrameEvent(Lim/zego/zegoexpress/ZegoMediaPlayer;Lim/zego/zegoexpress/constants/ZegoMediaPlayerFirstFrameEvent;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mediaPlayer",
            "event"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ sbbf@@ 4 ~ @@d~.~i~ o/@@S -~r ~K@@l ~@ ~ li~ooco@@v ~~~ b @ @oM~ @~~fm @s@ut~tan~o~~@/~i@ @y~@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    return-void
.end method

.method public onMediaPlayerFrequencySpectrumUpdate(Lim/zego/zegoexpress/ZegoMediaPlayer;[F)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mediaPlayer",
            "spectrumList"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public onMediaPlayerNetworkEvent(Lim/zego/zegoexpress/ZegoMediaPlayer;Lim/zego/zegoexpress/constants/ZegoMediaPlayerNetworkEvent;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mediaPlayer",
            "networkEvent"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public onMediaPlayerPlayingProgress(Lim/zego/zegoexpress/ZegoMediaPlayer;J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mediaPlayer",
            "millisecond"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public onMediaPlayerRecvSEI(Lim/zego/zegoexpress/ZegoMediaPlayer;[B)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mediaPlayer",
            "data"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public onMediaPlayerRenderingProgress(Lim/zego/zegoexpress/ZegoMediaPlayer;J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mediaPlayer",
            "millisecond"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public onMediaPlayerSoundLevelUpdate(Lim/zego/zegoexpress/ZegoMediaPlayer;F)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mediaPlayer",
            "soundLevel"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public onMediaPlayerStateUpdate(Lim/zego/zegoexpress/ZegoMediaPlayer;Lim/zego/zegoexpress/constants/ZegoMediaPlayerState;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "mediaPlayer",
            "state",
            "errorCode"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method
