.class public abstract Lim/zego/zegoexpress/callback/IZegoMediaDataPublisherEventHandler;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public onMediaDataPublisherFileClose(Lim/zego/zegoexpress/ZegoMediaDataPublisher;ILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "mediaDataPublisher",
            "errorCode",
            "path"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s/lM~~y  @ m~i~@@@@of~~b@Sc@~Kr@ u l 1@/@t~ai4b~sbf~o@~~~~oo@.~o ~@@ ~~ ~ n~  @~ @io - @t@ d v"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    return-void
.end method

.method public onMediaDataPublisherFileDataBegin(Lim/zego/zegoexpress/ZegoMediaDataPublisher;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mediaDataPublisher",
            "path"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public onMediaDataPublisherFileOpen(Lim/zego/zegoexpress/ZegoMediaDataPublisher;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mediaDataPublisher",
            "path"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x0

    return-void
.end method
