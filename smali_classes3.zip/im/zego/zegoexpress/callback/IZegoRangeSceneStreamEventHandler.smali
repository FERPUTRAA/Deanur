.class public abstract Lim/zego/zegoexpress/callback/IZegoRangeSceneStreamEventHandler;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public onUserCameraUpdate(Lim/zego/zegoexpress/ZegoRangeScene;Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoDeviceState;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "userID",
            "state"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "c@s@~o@~i~~ bal@f@ t.o v~i ro @@@S~~~ - ~@f tlo Ms@~14@im @ob @~@yndb@~~~/~/ ~@ @ uK@~@ ~~o~ ~@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    return-void
.end method

.method public onUserMicUpdate(Lim/zego/zegoexpress/ZegoRangeScene;Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoDeviceState;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "userID",
            "state"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public onUserSpeakerUpdate(Lim/zego/zegoexpress/ZegoRangeScene;Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoDeviceState;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "userID",
            "state"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    return-void
.end method

.method public onUserStreamStateUpdate(Lim/zego/zegoexpress/ZegoRangeScene;Ljava/lang/String;Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoStreamState;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "userID",
            "streamID",
            "state"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method
