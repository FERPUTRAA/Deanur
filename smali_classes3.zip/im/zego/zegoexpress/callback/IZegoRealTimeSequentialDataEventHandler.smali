.class public abstract Lim/zego/zegoexpress/callback/IZegoRealTimeSequentialDataEventHandler;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public onReceiveRealTimeSequentialData(Lim/zego/zegoexpress/ZegoRealTimeSequentialDataManager;[BLjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "manager",
            "data",
            "streamID"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~os@1~ial vuo@ @@~ @df. ~@@/   ~  ~@o ~~ @@@y~~ ~M-ob4~b@rtmc~@t@  ~ @@f~~lbons~@@ i~~~/~o~@i @S"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    return-void
.end method
