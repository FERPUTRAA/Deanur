.class public abstract Lim/zego/zegoexpress/callback/IZegoRangeSceneEventHandler;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onCustomCommandUpdate(Lim/zego/zegoexpress/ZegoRangeScene;[B)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "command"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~fsl@di@o@o ~b~v~@Mbsi~~ otK@~@a S @~fn@@ /r   ~ 4@~-@ @i~ @@~@~ @~~~ucb m o~l.~ @o@/ y1 ~@~~@~t"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    return-void
.end method

.method public onEnterView(Lim/zego/zegoexpress/ZegoRangeScene;Lim/zego/zegoexpress/entity/ZegoUser;Lim/zego/zegoexpress/entity/ZegoPosition;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "user",
            "position"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public onLeaveView(Lim/zego/zegoexpress/ZegoRangeScene;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "userID"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public onSceneStateUpdate(Lim/zego/zegoexpress/ZegoRangeScene;Lim/zego/zegoexpress/constants/ZegoSceneState;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "state",
            "errorCode"
        }
    .end annotation

    const/4 v0, 0x3

    move v1, v0

    return-void
.end method

.method public onSceneTokenWillExpire(Lim/zego/zegoexpress/ZegoRangeScene;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "remainTimeInSecond"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public onUserCommandUpdate(Lim/zego/zegoexpress/ZegoRangeScene;Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoPosition;I[B)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "userID",
            "position",
            "channel",
            "command"
        }
    .end annotation

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public onUserStatusUpdate(Lim/zego/zegoexpress/ZegoRangeScene;Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoPosition;I[B)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "rangeScene",
            "userID",
            "position",
            "channel",
            "status"
        }
    .end annotation

    const/4 v1, 0x0

    return-void
.end method
