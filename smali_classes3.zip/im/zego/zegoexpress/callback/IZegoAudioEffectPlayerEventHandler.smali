.class public abstract Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerEventHandler;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onAudioEffectPlayStateUpdate(Lim/zego/zegoexpress/ZegoAudioEffectPlayer;ILim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "audioEffectPlayer",
            "audioEffectID",
            "state",
            "errorCode"
        }
    .end annotation

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s~~dc@ S y @~/~u~@4 b@@ ~~aon@@@ b@@~~i~@ lbsl@@f  o-  o@fr~~~ / 1 o. @@K~tM~m t~~~~@~@io @iov"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    return-void
.end method
