.class public interface abstract Lim/zego/zegoexpress/callback/IZegoRangeSceneSendCustomCommandCallback;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onSendCustomCommandCallback(I)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "errorCode"
        }
    .end annotation
.end method
