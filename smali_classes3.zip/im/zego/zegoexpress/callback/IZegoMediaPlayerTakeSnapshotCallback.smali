.class public interface abstract Lim/zego/zegoexpress/callback/IZegoMediaPlayerTakeSnapshotCallback;
.super Ljava/lang/Object;


# virtual methods
.method public abstract onPlayerTakeSnapshotResult(ILandroid/graphics/Bitmap;)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "errorCode",
            "image"
        }
    .end annotation
.end method
