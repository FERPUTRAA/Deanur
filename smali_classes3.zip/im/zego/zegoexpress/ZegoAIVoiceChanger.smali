.class public abstract Lim/zego/zegoexpress/ZegoAIVoiceChanger;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public abstract getIndex()I
.end method

.method public abstract getSpeakerList()V
.end method

.method public abstract initEngine()V
.end method

.method public abstract setEventHandler(Lim/zego/zegoexpress/callback/IZegoAIVoiceChangerEventHandler;)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "handler"
        }
    .end annotation
.end method

.method public abstract setSpeaker(I)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "speakerID"
        }
    .end annotation
.end method

.method public abstract update()V
.end method
