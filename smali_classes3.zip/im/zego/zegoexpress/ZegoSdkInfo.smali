.class public final Lim/zego/zegoexpress/ZegoSdkInfo;
.super Ljava/lang/Object;


# static fields
.field public static final LIBRARY_NAME:Ljava/lang/String; = "ZegoExpressVideo"

.field public static final VERSION:Ljava/lang/String; = "3.10.0.32675"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method
