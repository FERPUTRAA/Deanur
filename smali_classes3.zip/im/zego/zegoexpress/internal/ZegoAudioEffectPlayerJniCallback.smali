.class Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback;
.super Ljava/lang/Object;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public static onAudioEffectPlayerPlayStateUpdate(IIII)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0,
            0x10,
            0x0
        }
        names = {
            "audio_effect_id",
            "state",
            "error_code",
            "instance_index"
        }
    .end annotation

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "~ls  @@~b~ S -4K~to@o~b~fy@i@@ ~@@/a ~@~ @b~d@.@ ~~f1M@~t~nlom~~uc~ v @ @~~ ~@ o  ~i/o@s @i~o@@ "

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x2

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;->values()[Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    aget-object p1, v0, p1

    const/4 v9, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x2

    if-eqz v1, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v3, v1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    check-cast v3, Ljava/util/Map$Entry;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    check-cast v1, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget v1, v1, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-ne v1, p3, :cond_0

    const/4 v10, 0x2

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    check-cast v1, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    iget-object v2, v1, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->eventHandler:Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerEventHandler;

    const/4 v9, 0x0

    shl-int/2addr v10, v9

    if-nez v2, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    return-void

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    sget-object v7, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    new-instance v8, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    move v4, p0

    move v4, p0

    const/4 v10, 0x1

    move v4, p0

    move v4, p0

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    move v6, p2

    move v6, p2

    const/4 v10, 0x1

    move v6, p2

    move v6, p2

    const/4 v10, 0x6

    invoke-direct/range {v1 .. v6}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;-><init>(Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerEventHandler;Ljava/util/Map$Entry;ILim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;I)V

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {v7, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    goto :goto_0

    :cond_2
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    return-void
.end method

.method public static onLoadResourceCallback(III)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0,
            0x10
        }
        names = {
            "seq",
            "idx",
            "errorcode"
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-class v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const/4 v7, 0x7

    const-class v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-eqz v2, :cond_2

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x7

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v7, 0x5

    const/4 v6, 0x3

    if-ne v3, p1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x1

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->loadResourceCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerLoadResourceCallback;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-nez v3, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    monitor-exit v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    return-void

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    sget-object v4, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance v5, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {v5, v3, p2, v2, p0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;-><init>(Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerLoadResourceCallback;ILjava/util/Map$Entry;I)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v7, 0x6

    const/4 v6, 0x6

    goto :goto_0

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    monitor-exit v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    return-void

    :catchall_0
    move-exception p0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    throw p0
.end method

.method public static onSeekToTimeCallback(III)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x0,
            0x10
        }
        names = {
            "seq",
            "idx",
            "errorcode"
        }
    .end annotation

    const/4 v7, 0x0

    const-class v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const/4 v7, 0x3

    const-class v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v7, 0x6

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v2, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    if-ne v3, p1, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->seekToTimeCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerSeekToCallback;

    const/4 v7, 0x7

    if-nez v3, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    monitor-exit v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    return-void

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    sget-object v4, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance v5, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;

    const/4 v6, 0x3

    move v7, v6

    invoke-direct {v5, v3, p2, v2, p0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;-><init>(Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerSeekToCallback;ILjava/util/Map$Entry;I)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v4, v5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto :goto_0

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    monitor-exit v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-void

    :catchall_0
    move-exception p0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x7

    throw p0
.end method
