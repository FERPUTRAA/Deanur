.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$46;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onIMSendBroadcastMessageResult(Ljava/lang/String;IIJ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$messageID:J

.field final synthetic val$seq:I


# direct methods
.method constructor <init>(IIJ)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$seq",
            "val$errorCode",
            "val$messageID"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$46;->val$seq:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$46;->val$errorCode:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-wide p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$46;->val$messageID:J

    const/4 v1, 0x7

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " @s/@@ro@~io~ oil ~@ bu ~~@ i@a@~-~ o~ t@M~1 o@~@~b @d~ym ~K~f~~S@ ~@b~@~@@cf.s4/ t~~  ~@@  olv@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v6, 0x6

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendBroadcastMessageHandler:Ljava/util/HashMap;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$46;->val$seq:I

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    check-cast v1, Lim/zego/zegoexpress/callback/IZegoIMSendBroadcastMessageCallback;

    const/4 v6, 0x5

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$46;->val$errorCode:I

    const/4 v6, 0x1

    const/4 v5, 0x1

    iget-wide v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$46;->val$messageID:J

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-interface {v1, v2, v3, v4}, Lim/zego/zegoexpress/callback/IZegoIMSendBroadcastMessageCallback;->onIMSendBroadcastMessageResult(IJ)V

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendBroadcastMessageHandler:Ljava/util/HashMap;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$46;->val$seq:I

    const/4 v6, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    monitor-exit v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    return-void

    :catchall_0
    move-exception v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    throw v1
.end method
