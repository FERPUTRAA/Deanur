.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$5;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onRoomStreamUpdate(Ljava/lang/String;I[Lim/zego/zegoexpress/entity/ZegoStream;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$extendedData:Ljava/lang/String;

.field final synthetic val$roomID:Ljava/lang/String;

.field final synthetic val$streamArrayList:Ljava/util/ArrayList;

.field final synthetic val$updateType:I


# direct methods
.method constructor <init>(Ljava/lang/String;ILjava/util/ArrayList;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$roomID",
            "val$updateType",
            "val$streamArrayList",
            "val$extendedData"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$5;->val$roomID:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$5;->val$updateType:I

    const/4 v0, 0x0

    move v1, v0

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$5;->val$streamArrayList:Ljava/util/ArrayList;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$5;->val$extendedData:Ljava/lang/String;

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  s ~y~m@K/@~ @fu@- @@ 4@@o ~@ @~@b~do~ot~@S@ ~ @n@ s~~@ b~@  @ar~v@@ibo~c~.~ ~l~lf  o/1M~o~~iti"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x4

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$5;->val$roomID:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoUpdateType;->values()[Lim/zego/zegoexpress/constants/ZegoUpdateType;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$5;->val$updateType:I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    aget-object v2, v2, v3

    const/4 v5, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$5;->val$streamArrayList:Ljava/util/ArrayList;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$5;->val$extendedData:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v4}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->access$000(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v2, v3, v4}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onRoomStreamUpdate(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoUpdateType;Ljava/util/ArrayList;Lorg/json/JSONObject;)V

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-void
.end method
