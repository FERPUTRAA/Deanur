.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$45;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onIMRecvCustomCommand(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoUser;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$command:Ljava/lang/String;

.field final synthetic val$fromUser:Lim/zego/zegoexpress/entity/ZegoUser;

.field final synthetic val$roomID:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoUser;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$roomID",
            "val$fromUser",
            "val$command"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$45;->val$roomID:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$45;->val$fromUser:Lim/zego/zegoexpress/entity/ZegoUser;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$45;->val$command:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@s o@.@@@/i~i S~  d~Kbc@so~/@  ~ ut~~~l~~m~-@4f@~1bo~fo@@l@~r  ~o@@~ ya~@ b@  @~n  t  iv@~~o@M~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v5, 0x3

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$45;->val$roomID:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$45;->val$fromUser:Lim/zego/zegoexpress/entity/ZegoUser;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$45;->val$command:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2, v3}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onIMRecvCustomCommand(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoUser;Ljava/lang/String;)V

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-void
.end method
