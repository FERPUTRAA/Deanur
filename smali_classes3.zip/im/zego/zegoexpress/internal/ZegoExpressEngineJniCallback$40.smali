.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$40;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPublisherStreamEvent(ILjava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$eventID:I

.field final synthetic val$extraInfo:Ljava/lang/String;

.field final synthetic val$streamID:Ljava/lang/String;


# direct methods
.method constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$eventID",
            "val$streamID",
            "val$extraInfo"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$40;->val$eventID:I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$40;->val$streamID:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$40;->val$extraInfo:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "o@s~  /@ mya @bMfKo@ o~~ b@@~d @s~ tt i~ @@i~ u@ ~n4 ~o~~ i~~@l1- r~ .f@@/v~~~ @~@@~o@@S~~c@~lb@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$40;->val$eventID:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v1}, Lim/zego/zegoexpress/constants/ZegoStreamEvent;->getZegoStreamEvent(I)Lim/zego/zegoexpress/constants/ZegoStreamEvent;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$40;->val$streamID:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$40;->val$extraInfo:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2, v3}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onPublisherStreamEvent(Lim/zego/zegoexpress/constants/ZegoStreamEvent;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-void
.end method
