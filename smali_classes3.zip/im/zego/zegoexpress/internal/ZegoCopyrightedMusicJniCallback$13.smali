.class Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$13;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback;->onDownloadCallback(II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$downloadCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicDownloadCallback;

.field final synthetic val$errorCode:I


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicDownloadCallback;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$downloadCallback",
            "val$errorCode"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$13;->val$downloadCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicDownloadCallback;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$13;->val$errorCode:I

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " .s@oi@   o@~ ta~~o@ @M@/  @1@~@@~-b@mr@~@~~ @~~  ~od~~lbv ~@ ~Kbcs~f/ oo@lii~~un~4t @y @~S ~~f@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$13;->val$downloadCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicDownloadCallback;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$13;->val$errorCode:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicDownloadCallback;->onDownloadCallback(I)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method
