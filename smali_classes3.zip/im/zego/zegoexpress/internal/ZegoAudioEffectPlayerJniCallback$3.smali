.class Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback;->onLoadResourceCallback(III)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorcode:I

.field final synthetic val$iZegoAudioEffectPlayerLoadResourceCallback:Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerLoadResourceCallback;

.field final synthetic val$item:Ljava/util/Map$Entry;

.field final synthetic val$seq:I


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerLoadResourceCallback;ILjava/util/Map$Entry;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$iZegoAudioEffectPlayerLoadResourceCallback",
            "val$errorcode",
            "val$item",
            "val$seq"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;->val$iZegoAudioEffectPlayerLoadResourceCallback:Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerLoadResourceCallback;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;->val$errorcode:I

    const/4 v0, 0x6

    move v1, v0

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;->val$item:Ljava/util/Map$Entry;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p4, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;->val$seq:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "s sd~l~~  r~~~/S~~iMti /@b@~f~@@o~ ~@@@o@~f@t4 @a i~~o@l@ov~bn~@1 oK @ @ ~ ~ b~~u@@ @ ~y  c.o@m-"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;->val$iZegoAudioEffectPlayerLoadResourceCallback:Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerLoadResourceCallback;

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;->val$errorcode:I

    const/4 v2, 0x1

    move v3, v2

    invoke-interface {v0, v1}, Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerLoadResourceCallback;->onLoadResourceCallback(I)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;->val$item:Ljava/util/Map$Entry;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;->val$item:Ljava/util/Map$Entry;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->loadResourceCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;->val$item:Ljava/util/Map$Entry;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->loadResourceCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x1

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$3;->val$seq:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method
