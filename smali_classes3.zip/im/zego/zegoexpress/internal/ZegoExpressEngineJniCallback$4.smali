.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$4;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onCustomVideoCaptureWillStop(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$channel:I


# direct methods
.method constructor <init>(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "val$channel"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$4;->val$channel:I

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~s@~iv@@o@@  @bo@~lsot ~iM~~4 ~@ ~~bf/ @a~ 1-~@ r/@d f@t  @~yo~@@ .~S ~c~ bl@i n~~u o~@@K~~@~ o"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mCustomVideoCaptureHandler:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    sget-boolean v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->isCustomVideoCapturing:Z

    const/4 v3, 0x4

    or-int/2addr v4, v3

    if-eqz v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->values()[Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$4;->val$channel:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    aget-object v1, v1, v2

    const/4 v4, 0x0

    invoke-static {v0, v1}, Lim/zego/zegoexpress/utils/ZegoCallbackHelpers;->callCustomVideoCaptureOnStopMethod(Ljava/lang/Object;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    sput-boolean v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->isCustomVideoCapturing:Z

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void
.end method
