.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$19;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPublisherQualityUpdate(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoPublishStreamQuality;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$quality:Lim/zego/zegoexpress/entity/ZegoPublishStreamQuality;

.field final synthetic val$streamID:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoPublishStreamQuality;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$streamID",
            "val$quality"
        }
    .end annotation

    const/4 v1, 0x6

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$19;->val$streamID:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x6

    iput-object p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$19;->val$quality:Lim/zego/zegoexpress/entity/ZegoPublishStreamQuality;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~s@o @i@o~f   b t@ amly4~~@~n@/@~~t~~ @~ o@f~~c1    Sui~@r@s /@i@b@oM~d@~@ob@ @~ ~~l@vK. ~~-~~o"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$19;->val$streamID:Ljava/lang/String;

    const/4 v4, 0x7

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$19;->val$quality:Lim/zego/zegoexpress/entity/ZegoPublishStreamQuality;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onPublisherQualityUpdate(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoPublishStreamQuality;)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void
.end method
