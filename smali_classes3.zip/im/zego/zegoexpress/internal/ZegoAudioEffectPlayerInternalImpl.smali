.class public Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;
.super Lim/zego/zegoexpress/ZegoAudioEffectPlayer;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;
    }
.end annotation


# static fields
.field public static audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Lim/zego/zegoexpress/ZegoAudioEffectPlayer;",
            "Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;",
            ">;"
        }
    .end annotation
.end field

.field public static mUIHandler:Landroid/os/Handler;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v0, Landroid/os/Handler;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v3, 0x1

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Lim/zego/zegoexpress/ZegoAudioEffectPlayer;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public static createAudioEffectPlayer()Lim/zego/zegoexpress/ZegoAudioEffectPlayer;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~bsfar~ @~~@~@K ~@@i~o b@  ~~ls@t @f@1~~@~i ~@@ @ m~v @~~/dM~~b-~~4~c .S@inu~@ol@o o @@ ty@/ o  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->createZegoAudioEffectPlayerJni()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-ltz v0, :cond_0

    const/4 v3, 0x3

    const/4 v3, 0x5

    new-instance v1, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v1}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    new-instance v2, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v2, v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;-><init>(I)V

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object v0, v2, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->seekToTimeCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-object v0, v2, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->loadResourceCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object v1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object v0
.end method

.method public static destroyAudioEffectPlayer(Lim/zego/zegoexpress/ZegoAudioEffectPlayer;)V
    .locals 6
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "audioEffectPlayer"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-ne v2, p0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    check-cast p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    iput-object v2, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->eventHandler:Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerEventHandler;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    check-cast p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iput-object v2, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->loadResourceCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    check-cast p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object p0, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->seekToTimeCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->remove()V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    check-cast p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-object v2, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->seekToTimeCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    check-cast p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget p0, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->destroyAudioEffectPlayerJni(I)I

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-void
.end method


# virtual methods
.method public getCurrentProgress(I)J
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "audioEffectID"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->getCurrentProgress(II)J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-wide v0

    :cond_0
    const/4 v3, 0x4

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x5

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-wide v0
.end method

.method public getIndex()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method public getTotalDuration(I)J
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "audioEffectID"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->getTotalDuration(II)J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-wide v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x7

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-wide v0
.end method

.method public loadResource(ILjava/lang/String;Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerLoadResourceCallback;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "audioEffectID",
            "path",
            "callback"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget v1, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p1, v1, p2}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->loadResourceJni(IILjava/lang/String;)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-class p2, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const/4 v3, 0x2

    const-class p2, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    monitor-enter p2

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->loadResourceCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p1, p3}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    monitor-exit p2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    throw p1

    :cond_0
    :goto_0
    const/4 v2, 0x1

    move v3, v2

    return-void
.end method

.method public pause(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "audioEffectID"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v1, 0x6

    shl-int/2addr v2, v1

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->pause(II)I

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public pauseAll()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->pauseAll(I)I

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public resume(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "audioEffectID"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->resume(II)I

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public resumeAll()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->resumeAll(I)I

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public seekTo(IJLim/zego/zegoexpress/callback/IZegoAudioEffectPlayerSeekToCallback;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "audioEffectID",
            "millisecond",
            "callback"
        }
    .end annotation

    const/4 v3, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget v1, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v3, 0x0

    invoke-static {p1, v1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->seekToJni(IIJ)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-class p2, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const/4 v3, 0x7

    const-class p2, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    monitor-enter p2

    :try_start_0
    const/4 v3, 0x2

    iget-object p3, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->seekToTimeCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    invoke-virtual {p3, p1, p4}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    monitor-exit p2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    throw p1

    :cond_0
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public setEventHandler(Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerEventHandler;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "handler"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    iput-object p1, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->eventHandler:Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerEventHandler;

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public setPlaySpeed(IF)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "audioEffectID",
            "speed"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x6

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->setPlaySpeed(IFI)I

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public setVolume(II)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "audioEffectID",
            "volume"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->setVolume(III)I

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method

.method public setVolumeAll(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "volume"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->setVolumeAll(II)I

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public start(ILjava/lang/String;Lim/zego/zegoexpress/entity/ZegoAudioEffectPlayConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "audioEffectID",
            "path",
            "config"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1, p2, p3, v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->start(ILjava/lang/String;Lim/zego/zegoexpress/entity/ZegoAudioEffectPlayConfig;I)I

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public stop(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "audioEffectID"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x4

    move v2, v1

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->stop(II)I

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public stopAll()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    shr-int/2addr v2, v1

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->stopAll(I)I

    :cond_0
    const/4 v2, 0x5

    return-void
.end method

.method public unloadResource(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "audioEffectID"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->unloadResource(II)I

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public updatePosition(I[F)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "audioEffectID",
            "position"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->audioEffectPlayerToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v2, 0x4

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->kAudioEffectPlayerIdx:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniAPI;->updatePosition(I[FI)V

    :cond_0
    const/4 v2, 0x0

    return-void
.end method
