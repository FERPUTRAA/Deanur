.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$74;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPlayerTakeSnapshotResult(Ljava/lang/String;ILandroid/graphics/Bitmap;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$bitmap:Landroid/graphics/Bitmap;

.field final synthetic val$errorCode:I

.field final synthetic val$streamId:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;ILandroid/graphics/Bitmap;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$streamId",
            "val$errorCode",
            "val$bitmap"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$74;->val$streamId:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$74;->val$errorCode:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$74;->val$bitmap:Landroid/graphics/Bitmap;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ts @ ibvso1~or@~@@@@~K~f@~ bo~  y/~~@~@~f@~mM@@i  ~ ~t S@~4~  b@ . ~i~ @c l@o da@@@~~l~oo~~n-/u"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPlayerTakeSnapshotResultHandler:Ljava/util/HashMap;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$74;->val$streamId:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    check-cast v0, Lim/zego/zegoexpress/callback/IZegoPlayerTakeSnapshotCallback;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$74;->val$errorCode:I

    const/4 v3, 0x3

    move v4, v3

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$74;->val$bitmap:Landroid/graphics/Bitmap;

    const/4 v3, 0x5

    const/4 v3, 0x7

    invoke-interface {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoPlayerTakeSnapshotCallback;->onPlayerTakeSnapshotResult(ILandroid/graphics/Bitmap;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPlayerTakeSnapshotResultHandler:Ljava/util/HashMap;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$74;->val$streamId:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-void
.end method
