.class Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback;->onSeekToTimeCallback(III)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorcode:I

.field final synthetic val$item:Ljava/util/Map$Entry;

.field final synthetic val$seekToTimeCallback:Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerSeekToCallback;

.field final synthetic val$seq:I


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerSeekToCallback;ILjava/util/Map$Entry;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$seekToTimeCallback",
            "val$errorcode",
            "val$item",
            "val$seq"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;->val$seekToTimeCallback:Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerSeekToCallback;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;->val$errorcode:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;->val$item:Ljava/util/Map$Entry;

    const/4 v1, 0x3

    const/4 v0, 0x1

    iput p4, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;->val$seq:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@sf@ is@~ db m~1o~~@S@- M~yov ~@@~o@~~o~@4 @~@~b / ~ @  @~@~ .cKit~@@lo ~i@~n@l/uoa @fr~ ~t@b ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;->val$seekToTimeCallback:Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerSeekToCallback;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;->val$errorcode:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0, v1}, Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerSeekToCallback;->onSeekToCallback(I)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;->val$item:Ljava/util/Map$Entry;

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;->val$item:Ljava/util/Map$Entry;

    const/4 v2, 0x1

    move v3, v2

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->seekToTimeCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;->val$item:Ljava/util/Map$Entry;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {v0}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;

    const/4 v3, 0x7

    const/4 v2, 0x5

    iget-object v0, v0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl$IdxAndHandler;->seekToTimeCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$2;->val$seq:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method
