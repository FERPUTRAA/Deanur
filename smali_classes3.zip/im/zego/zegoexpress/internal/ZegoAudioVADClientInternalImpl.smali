.class public Lim/zego/zegoexpress/internal/ZegoAudioVADClientInternalImpl;
.super Lim/zego/zegoexpress/ZegoAudioVADClient;


# instance fields
.field private mNativeClient:J


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {p0}, Lim/zego/zegoexpress/ZegoAudioVADClient;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-wide v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioVADClientInternalImpl;->mNativeClient:J

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method public static createAudioVADClient()Lim/zego/zegoexpress/ZegoAudioVADClient;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "K s~~~oM1~/4@o cl~   ~@~ di o oi~b.f@a ~y~@@/~o ~~@~v@utS~@~@~t@@ibfs~-@@@b o  l@~ @ @m~@@ nr ~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoAudioVADClientJniAPI;->createZegoAudioVADClientJni()J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    cmp-long v2, v0, v2

    const/4 v5, 0x7

    if-eqz v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    new-instance v2, Lim/zego/zegoexpress/internal/ZegoAudioVADClientInternalImpl;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v2}, Lim/zego/zegoexpress/internal/ZegoAudioVADClientInternalImpl;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    iput-wide v0, v2, Lim/zego/zegoexpress/internal/ZegoAudioVADClientInternalImpl;->mNativeClient:J

    const/4 v5, 0x1

    return-object v2

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-object v0
.end method

.method public static destroyAudioVADClient(Lim/zego/zegoexpress/ZegoAudioVADClient;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "client"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    check-cast p0, Lim/zego/zegoexpress/internal/ZegoAudioVADClientInternalImpl;

    const/4 v3, 0x6

    iget-wide v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioVADClientInternalImpl;->mNativeClient:J

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lim/zego/zegoexpress/internal/ZegoAudioVADClientJniAPI;->destroyAudioVADClientJni(J)I

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method


# virtual methods
.method public reset()Z
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-wide v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioVADClientInternalImpl;->mNativeClient:J

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    cmp-long v2, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lim/zego/zegoexpress/internal/ZegoAudioVADClientJniAPI;->resetJni(J)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v3, 0x1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    return v3
.end method

.method public update(Ljava/nio/ByteBuffer;III)Lim/zego/zegoexpress/constants/ZegoAudioVADType;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "dataLength",
            "sampleRate",
            "channels"
        }
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x4

    iget-wide v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioVADClientInternalImpl;->mNativeClient:J

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x3

    const-wide/16 v2, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x0

    cmp-long v2, v0, v2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v2, :cond_0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    move v3, p2

    move v3, p2

    const/4 v7, 0x6

    move v3, p2

    move v3, p2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    move v4, p3

    move v4, p3

    const/4 v7, 0x4

    move v4, p3

    move v4, p3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    move v5, p4

    move v5, p4

    const/4 v7, 0x5

    move v5, p4

    move v5, p4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static/range {v0 .. v5}, Lim/zego/zegoexpress/internal/ZegoAudioVADClientJniAPI;->updateJni(JLjava/nio/ByteBuffer;III)I

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {p1}, Lim/zego/zegoexpress/constants/ZegoAudioVADType;->getZegoAudioVADType(I)Lim/zego/zegoexpress/constants/ZegoAudioVADType;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    return-object p1

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoAudioVADType;->NOISE:Lim/zego/zegoexpress/constants/ZegoAudioVADType;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-object p1
.end method
