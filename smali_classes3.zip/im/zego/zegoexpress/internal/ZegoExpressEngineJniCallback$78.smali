.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$78;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onNetworkSpeedTestError(II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$error_code:I

.field final synthetic val$type:I


# direct methods
.method constructor <init>(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$error_code",
            "val$type"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$78;->val$error_code:I

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$78;->val$type:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$78;->val$error_code:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoNetworkSpeedTestType;->values()[Lim/zego/zegoexpress/constants/ZegoNetworkSpeedTestType;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$78;->val$type:I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    aget-object v2, v2, v3

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onNetworkSpeedTestError(ILim/zego/zegoexpress/constants/ZegoNetworkSpeedTestType;)V

    :cond_0
    const/4 v5, 0x4

    return-void
.end method
