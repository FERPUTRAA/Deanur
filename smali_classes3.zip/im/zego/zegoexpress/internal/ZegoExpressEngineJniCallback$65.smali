.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$65;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onAudioVADStateUpdate(II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$state:I

.field final synthetic val$type:I


# direct methods
.method constructor <init>(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$type",
            "val$state"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$65;->val$type:I

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$65;->val$state:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "f s~ms@/4~ @~  @-v @@ ~~~  ~@ @t~@~@f ~~boc/ia~~@S1ui @l yM~o~ tbn@@@~lord  @~@io@ .b@o ~K~~o@~@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$65;->val$type:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v1}, Lim/zego/zegoexpress/constants/ZegoAudioVADStableStateMonitorType;->getZegoAudioVADStableStateMonitorType(I)Lim/zego/zegoexpress/constants/ZegoAudioVADStableStateMonitorType;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$65;->val$state:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v2}, Lim/zego/zegoexpress/constants/ZegoAudioVADType;->getZegoAudioVADType(I)Lim/zego/zegoexpress/constants/ZegoAudioVADType;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onAudioVADStateUpdate(Lim/zego/zegoexpress/constants/ZegoAudioVADStableStateMonitorType;Lim/zego/zegoexpress/constants/ZegoAudioVADType;)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method
