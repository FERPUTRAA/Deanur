.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$85;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onVideoObjectSegmentationStateChanged(III)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$channel:I

.field final synthetic val$errorCode:I

.field final synthetic val$state:I


# direct methods
.method constructor <init>(III)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$state",
            "val$channel",
            "val$errorCode"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$85;->val$state:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$85;->val$channel:I

    const/4 v0, 0x1

    move v1, v0

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$85;->val$errorCode:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "o~s @~ i-K4tao@@b~s~Son ~o~@ t@~~  ~@o~@ @ ~~r~/M~y@ @ ~~@~@ ov@@~@ ~.cib/@~m@@@if1d  ~  ul~b l@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationState;->values()[Lim/zego/zegoexpress/constants/ZegoObjectSegmentationState;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$85;->val$state:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    aget-object v1, v1, v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$85;->val$channel:I

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->getZegoPublishChannel(I)Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$85;->val$errorCode:I

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2, v3}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onVideoObjectSegmentationStateChanged(Lim/zego/zegoexpress/constants/ZegoObjectSegmentationState;Lim/zego/zegoexpress/constants/ZegoPublishChannel;I)V

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-void
.end method
