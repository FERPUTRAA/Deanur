.class Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$14;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback;->onGetStandardPitchCallback(IILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$getStandardPitchCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetStandardPitchCallback;

.field final synthetic val$pitch:Ljava/lang/String;


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetStandardPitchCallback;ILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$getStandardPitchCallback",
            "val$errorCode",
            "val$pitch"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$14;->val$getStandardPitchCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetStandardPitchCallback;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$14;->val$errorCode:I

    const/4 v1, 0x3

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$14;->val$pitch:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " ~s~@@ tb@@i@~~ @i~us~b~@~@~ f @b ~@ lvm~@ @ ~/S 4~ c~iy~l~ o~o@to@@K@ Mr@ o~/1~nf@o o ~a.~~@ @d"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$14;->val$getStandardPitchCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetStandardPitchCallback;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$14;->val$errorCode:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$14;->val$pitch:Ljava/lang/String;

    const/4 v4, 0x6

    invoke-interface {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetStandardPitchCallback;->onGetStandardPitchCallback(ILjava/lang/String;)V

    const/4 v3, 0x1

    move v4, v3

    return-void
.end method
