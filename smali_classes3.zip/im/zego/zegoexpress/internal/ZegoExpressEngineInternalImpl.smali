.class public Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;
.super Lim/zego/zegoexpress/ZegoExpressEngine;

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# static fields
.field public static apiCalledEventHandler:Lim/zego/zegoexpress/callback/IZegoApiCalledEventHandler;

.field private static volatile engine:Lim/zego/zegoexpress/ZegoExpressEngine;

.field public static eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

.field private static volatile hasSoLoaded:Z

.field public static iZegoAudioDataHandler:Lim/zego/zegoexpress/callback/IZegoAudioDataHandler;

.field public static iZegoAudioMixingHandler:Lim/zego/zegoexpress/callback/IZegoAudioMixingHandler;

.field public static iZegoCustomAudioProcessHandler:Lim/zego/zegoexpress/callback/IZegoCustomAudioProcessHandler;

.field public static iZegoDataRecordEventHandler:Lim/zego/zegoexpress/callback/IZegoDataRecordEventHandler;

.field public static iZegoDestroyCompletionCallback:Lim/zego/zegoexpress/callback/IZegoDestroyCompletionCallback;

.field public static isCustomVideoCapturing:Z

.field private static mContext:Landroid/content/Context;

.field public static mCustomVideoCaptureHandler:Ljava/lang/Object;

.field public static mCustomVideoProcessHandler:Ljava/lang/Object;

.field public static mCustomVideoRenderHandler:Ljava/lang/Object;

.field private static mEngineConfig:Lim/zego/zegoexpress/entity/ZegoEngineConfig;

.field public static mUIHandler:Landroid/os/Handler;

.field public static sIMSendBarrageMessageHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoIMSendBarrageMessageCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sIMSendBroadcastMessageHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoIMSendBroadcastMessageCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sIMSendCustomCommandHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoIMSendCustomCommandCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sMixerStartResultHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoMixerStartCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sMixerStopResultHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoMixerStopCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sNetworkProbeResultHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoNetworkProbeResultCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sPlayerTakeSnapshotResultHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Lim/zego/zegoexpress/callback/IZegoPlayerTakeSnapshotCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sPublisherTakeSnapshotResultHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoPublisherTakeSnapshotCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sPublisherUpdateCDNURLHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoPublisherUpdateCdnUrlCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sPublisherUpdateStreamExtraInfoHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoPublisherSetStreamExtraInfoCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sRoomLoginResultHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoRoomLoginCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sRoomLogoutResultHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoRoomLogoutCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sRoomSetExtraInfoHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoRoomSetRoomExtraInfoCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sTestNetworkConnectivityHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoTestNetworkConnectivityCallback;",
            ">;"
        }
    .end annotation
.end field

.field public static sUploadLogResultHandler:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/Integer;",
            "Lim/zego/zegoexpress/callback/IZegoUploadLogResultCallback;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x4

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomSetExtraInfoHandler:Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x7

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomLoginResultHandler:Ljava/util/HashMap;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomLogoutResultHandler:Ljava/util/HashMap;

    const/4 v4, 0x2

    move v5, v4

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPublisherUpdateCDNURLHandler:Ljava/util/HashMap;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPublisherUpdateStreamExtraInfoHandler:Ljava/util/HashMap;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendBarrageMessageHandler:Ljava/util/HashMap;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sMixerStartResultHandler:Ljava/util/HashMap;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sMixerStopResultHandler:Ljava/util/HashMap;

    const/4 v5, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendBroadcastMessageHandler:Ljava/util/HashMap;

    const/4 v5, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendCustomCommandHandler:Ljava/util/HashMap;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPublisherTakeSnapshotResultHandler:Ljava/util/HashMap;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x4

    or-int/2addr v5, v4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPlayerTakeSnapshotResultHandler:Ljava/util/HashMap;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x2

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sTestNetworkConnectivityHandler:Ljava/util/HashMap;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sNetworkProbeResultHandler:Ljava/util/HashMap;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sUploadLogResultHandler:Ljava/util/HashMap;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string/jumbo v1, "ossiEeZegngenrspx"

    const-string/jumbo v1, "irseopgsgxeEZsenn"

    const-string/jumbo v1, "nxemEpgssZEeornie"

    const-string v1, "ZegoExpressEngine"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v1}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V

    const/4 v1, 0x3

    move v5, v1

    const/4 v1, 0x1

    move v5, v1

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    sput-boolean v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->hasSoLoaded:Z
    :try_end_0
    .catch Ljava/lang/UnsatisfiedLinkError; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x4

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v2, "ZEOG"

    const-string v2, "EGZO"

    const/4 v5, 0x2

    const-string v2, "EGZO"

    const-string v2, "ZEGO"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string/jumbo v3, "llafodrbiEixovDnd asrpsgtleeeS  ayiomrZ K"

    const-string v3, "bZlmonx aarSefs royrE eDd pKaaitllisgidev"

    const/4 v5, 0x1

    const-string/jumbo v3, "oe   bKerdeZrpySofdiaeaaEiv naxsitgblllDr"

    const-string/jumbo v3, "load ZegoExpressSDK native library failed"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v2, v3, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v4, 0x7

    move v5, v4

    sput-boolean v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->hasSoLoaded:Z

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    sput-boolean v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->isCustomVideoCapturing:Z

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lim/zego/zegoexpress/ZegoExpressEngine;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    return-void
.end method

.method public static createEngine(JLjava/lang/String;ZLim/zego/zegoexpress/constants/ZegoScenario;Landroid/app/Application;Lim/zego/zegoexpress/callback/IZegoEventHandler;)Lim/zego/zegoexpress/ZegoExpressEngine;
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "appID",
            "appSign",
            "isTestEnvironment",
            "scenario",
            "application",
            "handler"
        }
    .end annotation

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    monitor-enter v0

    :try_start_0
    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->engine:Lim/zego/zegoexpress/ZegoExpressEngine;

    if-eqz v1, :cond_0

    sget-object p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->engine:Lim/zego/zegoexpress/ZegoExpressEngine;

    monitor-exit v0

    return-object p0

    :cond_0
    const-string v1, "007.o3.65321"

    const-string v1, "3600.1u527.3"

    const-string v1, "3.10.0.32675"

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->getVersion()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-eqz v1, :cond_4

    if-eqz p5, :cond_3

    invoke-virtual {p4}, Lim/zego/zegoexpress/constants/ZegoScenario;->value()I

    move-result v6

    move-wide v2, p0

    move-object v4, p2

    move-object v4, p2

    move v5, p3

    move v5, p3

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    invoke-static/range {v2 .. v7}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->engineInitJni(JLjava/lang/String;ZILandroid/content/Context;)I

    move-result p0

    if-eqz p0, :cond_1

    monitor-exit v0

    const/4 p0, 0x0

    return-object p0

    :cond_1
    new-instance p0, Landroid/os/Handler;

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p1

    invoke-direct {p0, p1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    sput-object p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mUIHandler:Landroid/os/Handler;

    new-instance p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    invoke-direct {p0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;-><init>()V

    sput-object p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->engine:Lim/zego/zegoexpress/ZegoExpressEngine;

    sput-object p5, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mContext:Landroid/content/Context;

    if-eqz p6, :cond_2

    sget-object p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->engine:Lim/zego/zegoexpress/ZegoExpressEngine;

    invoke-virtual {p0, p6}, Lim/zego/zegoexpress/ZegoExpressEngine;->setEventHandler(Lim/zego/zegoexpress/callback/IZegoEventHandler;)V

    :cond_2
    sget-object p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->engine:Lim/zego/zegoexpress/ZegoExpressEngine;

    monitor-exit v0

    return-object p0

    :cond_3
    new-instance p0, Ljava/lang/RuntimeException;

    const-string p1, "eOborp pc ttaxtZndeonpcslnto Gt]! oiadinE i"

    const-string p1, "aZGtnbncs!ito otrti  ]dtoOp nadpi xEoe[elnc"

    const-string p1, "E!s ]tAtqtn n p oaandeiccxiorGt[dnlZOooept "

    const-string p1, "[ZEGO] Android application context not set!"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :cond_4
    new-instance p0, Ljava/lang/RuntimeException;

    const-string/jumbo p1, "ihsn daa roGa vhSdjerO  rihr!svmo aT  sa)ynnEtuoZ(]K odit ocrlbe[e stes D aef"

    const-string p1, "T[sd) uv]dn os hv !GriicEeta  eKZsl.stDeiho jrrdon(aao S a embrrhfy ta Oona e"

    const-string p1, "di mr]s on(vseiraa!Gore.SneKns[)dmoheOohr b  otaZrahvE aajct iT dtDs ey n   l"

    const-string p1, "[ZEGO] The version of SDK jar and native shared library (.so) does not match!"

    invoke-direct {p0, p1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p0

    :catchall_0
    move-exception p0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw p0
.end method

.method public static createEngine(Lim/zego/zegoexpress/entity/ZegoEngineProfile;Lim/zego/zegoexpress/callback/IZegoEventHandler;)Lim/zego/zegoexpress/ZegoExpressEngine;
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "profile",
            "handler"
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "i ~so b1c4@~u-i~@do~~@@ ~~~Sra.@ /@l t~@~@@l~@@~ o~b @@ f~@~~ yKo @ v~/~ ~~o@@@o bt~  imM ~@n@fo"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x6

    iget-wide v0, p0, Lim/zego/zegoexpress/entity/ZegoEngineProfile;->appID:J

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    iget-object v2, p0, Lim/zego/zegoexpress/entity/ZegoEngineProfile;->appSign:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v4, p0, Lim/zego/zegoexpress/entity/ZegoEngineProfile;->scenario:Lim/zego/zegoexpress/constants/ZegoScenario;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget-object v5, p0, Lim/zego/zegoexpress/entity/ZegoEngineProfile;->application:Landroid/app/Application;

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static/range {v0 .. v6}, Lim/zego/zegoexpress/ZegoExpressEngine;->createEngine(JLjava/lang/String;ZLim/zego/zegoexpress/constants/ZegoScenario;Landroid/app/Application;Lim/zego/zegoexpress/callback/IZegoEventHandler;)Lim/zego/zegoexpress/ZegoExpressEngine;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    return-object p0
.end method

.method public static destroyEngine(Lim/zego/zegoexpress/callback/IZegoDestroyCompletionCallback;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10
        }
        names = {
            "callback"
        }
    .end annotation

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x3

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x5

    const/4 v2, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->engine:Lim/zego/zegoexpress/ZegoExpressEngine;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    sput-object p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->iZegoDestroyCompletionCallback:Lim/zego/zegoexpress/callback/IZegoDestroyCompletionCallback;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->engine:Lim/zego/zegoexpress/ZegoExpressEngine;

    const/4 v3, 0x0

    const/4 v2, 0x6

    check-cast p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->release()V

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->engineUninitAsyncJni()I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    sget-object p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->iZegoDestroyCompletionCallback:Lim/zego/zegoexpress/callback/IZegoDestroyCompletionCallback;

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz p0, :cond_1

    const/4 v3, 0x3

    invoke-interface {p0}, Lim/zego/zegoexpress/callback/IZegoDestroyCompletionCallback;->onDestroyCompletion()V

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void

    :catchall_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    throw p0
.end method

.method static ensureSoLoaded(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "appContext",
            "customizeSoPath"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-boolean v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->hasSoLoaded:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p1, p0}, Lim/zego/zegoexpress/utils/ZegoLibraryLoadUtil;->loadSpecialLibrary(Ljava/lang/String;Landroid/content/Context;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    sput-boolean p1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->hasSoLoaded:Z

    :cond_0
    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-boolean p1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->hasSoLoaded:Z

    const/4 v1, 0x7

    move v2, v1

    if-nez p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string/jumbo p1, "snZgobsorgesEeiEnxbe.pp"

    const-string/jumbo p1, "sb.pieipEZxregsoegonsEn"

    const/4 v2, 0x7

    const-string/jumbo p1, "oleb.iunrnseExEpgsoiseZ"

    const-string/jumbo p1, "libZegoExpressEngine.so"

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1, p0}, Lim/zego/zegoexpress/utils/ZegoLibraryLoadUtil;->loadSoFile(Ljava/lang/String;Landroid/content/Context;)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x6

    sput-boolean p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->hasSoLoaded:Z

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public static getEngine()Lim/zego/zegoexpress/ZegoExpressEngine;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->engine:Lim/zego/zegoexpress/ZegoExpressEngine;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public static getVersion()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->getVersionJni()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public static isFeatureSupported(Lim/zego/zegoexpress/constants/ZegoFeatureType;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "featureType"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    invoke-virtual {p0}, Lim/zego/zegoexpress/constants/ZegoFeatureType;->value()I

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->isFeatureSupportedJni(I)Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p0
.end method

.method private static logNotice(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "log",
            "module"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x4

    invoke-static {p0, p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->logNoticeJni(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    return-void
.end method

.method private release()V
    .locals 4

    const/4 v2, 0x6

    move v3, v2

    const/4 v0, 0x0

    and-int/2addr v3, v0

    const/4 v2, 0x7

    move v3, v2

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomSetExtraInfoHandler:Ljava/util/HashMap;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomLoginResultHandler:Ljava/util/HashMap;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomLogoutResultHandler:Ljava/util/HashMap;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v1, :cond_2

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPublisherUpdateCDNURLHandler:Ljava/util/HashMap;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v1, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_3
    const/4 v2, 0x2

    move v3, v2

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPublisherUpdateStreamExtraInfoHandler:Ljava/util/HashMap;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz v1, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_4
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sMixerStartResultHandler:Ljava/util/HashMap;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v1, :cond_5

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_5
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sMixerStopResultHandler:Ljava/util/HashMap;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v1, :cond_6

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_6
    const/4 v3, 0x0

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendBroadcastMessageHandler:Ljava/util/HashMap;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v1, :cond_7

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_7
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendCustomCommandHandler:Ljava/util/HashMap;

    const/4 v3, 0x4

    const/4 v2, 0x4

    if-eqz v1, :cond_8

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_8
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendBarrageMessageHandler:Ljava/util/HashMap;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz v1, :cond_9

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_9
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPublisherTakeSnapshotResultHandler:Ljava/util/HashMap;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v1, :cond_a

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_a
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPlayerTakeSnapshotResultHandler:Ljava/util/HashMap;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz v1, :cond_b

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_b
    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sTestNetworkConnectivityHandler:Ljava/util/HashMap;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v1, :cond_c

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_c
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sNetworkProbeResultHandler:Ljava/util/HashMap;

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    if-eqz v1, :cond_d

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_d
    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sUploadLogResultHandler:Ljava/util/HashMap;

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    if-eqz v1, :cond_e

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/util/HashMap;->clear()V

    :cond_e
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->iZegoAudioMixingHandler:Lim/zego/zegoexpress/callback/IZegoAudioMixingHandler;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->iZegoAudioDataHandler:Lim/zego/zegoexpress/callback/IZegoAudioDataHandler;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mCustomVideoRenderHandler:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x5

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mCustomVideoCaptureHandler:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mCustomVideoProcessHandler:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->iZegoDataRecordEventHandler:Lim/zego/zegoexpress/callback/IZegoDataRecordEventHandler;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->iZegoCustomAudioProcessHandler:Lim/zego/zegoexpress/callback/IZegoCustomAudioProcessHandler;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->engine:Lim/zego/zegoexpress/ZegoExpressEngine;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoMediaPlayerInternalImpl;->destroyAllMediaPlayer()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoRangeSceneInternalImpl;->destroyAllRangeSceneInstance()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->destroyAllAIVoiceChangerInstance()V

    const/4 v3, 0x1

    return-void
.end method

.method public static setApiCalledCallback(Lim/zego/zegoexpress/callback/IZegoApiCalledEventHandler;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "callback"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v2, 0x0

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    sput-object p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->apiCalledEventHandler:Lim/zego/zegoexpress/callback/IZegoApiCalledEventHandler;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    monitor-exit v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void

    :catchall_0
    move-exception p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    throw p0
.end method

.method public static setCloudProxyConfig(Ljava/util/ArrayList;Ljava/lang/String;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "proxyList",
            "token",
            "enable"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lim/zego/zegoexpress/entity/ZegoProxyInfo;",
            ">;",
            "Ljava/lang/String;",
            "Z)V"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance p0, Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    new-array v0, v0, [Lim/zego/zegoexpress/entity/ZegoProxyInfo;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    check-cast p0, [Lim/zego/zegoexpress/entity/ZegoProxyInfo;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p0, p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCloudProxyConfigToJni([Lim/zego/zegoexpress/entity/ZegoProxyInfo;Ljava/lang/String;Z)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method public static setEngineConfig(Lim/zego/zegoexpress/entity/ZegoEngineConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "engineConfig"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setEngineConfig(Lim/zego/zegoexpress/entity/ZegoEngineConfig;Landroid/app/Application;)V

    return-void
.end method

.method public static setEngineConfig(Lim/zego/zegoexpress/entity/ZegoEngineConfig;Landroid/app/Application;)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "engineConfig",
            "application"
        }
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-eqz p0, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    sput-object p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mEngineConfig:Lim/zego/zegoexpress/entity/ZegoEngineConfig;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    new-instance p0, Lim/zego/zegoexpress/entity/ZegoEngineConfig;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-direct {p0}, Lim/zego/zegoexpress/entity/ZegoEngineConfig;-><init>()V

    sput-object p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mEngineConfig:Lim/zego/zegoexpress/entity/ZegoEngineConfig;

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x7

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mEngineConfig:Lim/zego/zegoexpress/entity/ZegoEngineConfig;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    iget-object v0, v0, Lim/zego/zegoexpress/entity/ZegoEngineConfig;->advancedConfig:Ljava/util/HashMap;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-eqz v0, :cond_1

    const/4 v8, 0x4

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/util/HashMap;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-eqz v1, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const-string v2, "="

    const-string v2, "="

    const/4 v8, 0x2

    const-string v2, "="

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mEngineConfig:Lim/zego/zegoexpress/entity/ZegoEngineConfig;

    const/4 v8, 0x7

    iget-object v2, v2, Lim/zego/zegoexpress/entity/ZegoEngineConfig;->advancedConfig:Ljava/util/HashMap;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v2, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    check-cast v1, Ljava/lang/String;

    const/4 v8, 0x2

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string v1, ";"

    const-string v1, ";"

    const/4 v8, 0x4

    const-string v1, ";"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    goto :goto_1

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mEngineConfig:Lim/zego/zegoexpress/entity/ZegoEngineConfig;

    const/4 v8, 0x2

    const/4 v7, 0x5

    iget-object v0, v0, Lim/zego/zegoexpress/entity/ZegoEngineConfig;->soFullPath:Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-nez v0, :cond_2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mEngineConfig:Lim/zego/zegoexpress/entity/ZegoEngineConfig;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    iget-object v0, v0, Lim/zego/zegoexpress/entity/ZegoEngineConfig;->soFullPath:Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->ensureSoLoaded(Landroid/content/Context;Ljava/lang/String;)V

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mEngineConfig:Lim/zego/zegoexpress/entity/ZegoEngineConfig;

    const/4 v7, 0x3

    and-int/2addr v8, v7

    iget-object p1, v1, Lim/zego/zegoexpress/entity/ZegoEngineConfig;->logConfig:Lim/zego/zegoexpress/entity/ZegoLogConfig;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object v2, p1, Lim/zego/zegoexpress/entity/ZegoLogConfig;->logPath:Ljava/lang/String;

    const/4 v8, 0x4

    iget-wide v3, p1, Lim/zego/zegoexpress/entity/ZegoLogConfig;->logSize:J

    const/4 v7, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget v5, p1, Lim/zego/zegoexpress/entity/ZegoLogConfig;->logCount:I

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static/range {v1 .. v6}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setEngineInitConfigToJni(Lim/zego/zegoexpress/entity/ZegoEngineConfig;Ljava/lang/String;JILjava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    return-void
.end method

.method public static setGeoFence(Lim/zego/zegoexpress/constants/ZegoGeoFenceType;Ljava/util/List;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "type",
            "areaList"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lim/zego/zegoexpress/constants/ZegoGeoFenceType;",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;)V"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-eqz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    new-array v0, v0, [I

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-ge v1, v2, :cond_1

    const/4 v3, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    check-cast v2, Ljava/lang/Integer;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    aput v2, v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v0, 0x0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0}, Lim/zego/zegoexpress/constants/ZegoGeoFenceType;->value()I

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p0, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setGeoFenceJni(I[I)I

    const/4 v4, 0x2

    return-void
.end method

.method public static setLicense(Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "license"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-static {p0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setLicenseToJni(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public static setLocalProxyConfig(Ljava/util/ArrayList;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "proxyList",
            "enable"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lim/zego/zegoexpress/entity/ZegoProxyInfo;",
            ">;Z)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-nez p0, :cond_0

    const/4 v2, 0x5

    new-instance p0, Ljava/util/ArrayList;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-array v0, v0, [Lim/zego/zegoexpress/entity/ZegoProxyInfo;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    check-cast p0, [Lim/zego/zegoexpress/entity/ZegoProxyInfo;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p0, p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setLocalProxyConfigToJni([Lim/zego/zegoexpress/entity/ZegoProxyInfo;Z)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public static setLogConfig(Lim/zego/zegoexpress/entity/ZegoLogConfig;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "config"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez p0, :cond_0

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    new-instance p0, Lim/zego/zegoexpress/entity/ZegoLogConfig;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-direct {p0}, Lim/zego/zegoexpress/entity/ZegoLogConfig;-><init>()V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lim/zego/zegoexpress/entity/ZegoLogConfig;->logPath:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-wide v1, p0, Lim/zego/zegoexpress/entity/ZegoLogConfig;->logSize:J

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget p0, p0, Lim/zego/zegoexpress/entity/ZegoLogConfig;->logCount:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0, v1, v2, p0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setLogConfigToJni(Ljava/lang/String;JI)V

    const/4 v4, 0x6

    return-void
.end method

.method private static setPlatformLanguage(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "platform"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setPlatformLanguageJni(I)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public static setRoomMode(Lim/zego/zegoexpress/constants/ZegoRoomMode;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mode"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0}, Lim/zego/zegoexpress/constants/ZegoRoomMode;->value()I

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setRoomModeJni(I)I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public static showToastMsg(Ljava/lang/String;Landroid/content/Context;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "msg",
            "context"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz p1, :cond_1

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v1}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ne v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p1, p0, v0}, Landroid/widget/Toast;->makeText(Landroid/content/Context;Ljava/lang/CharSequence;I)Landroid/widget/Toast;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/widget/Toast;->show()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl$2;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v1, p1, p0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl$2;-><init>(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method public static submitLog()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->uploadLogJni()I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public addPublishCdnUrl(Ljava/lang/String;Ljava/lang/String;Lim/zego/zegoexpress/callback/IZegoPublisherUpdateCdnUrlCallback;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "streamID",
            "targetURL",
            "handler"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->addPublishCdnUrlJni(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    monitor-enter p2

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPublisherUpdateCDNURLHandler:Ljava/util/HashMap;

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x1

    monitor-exit p2

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    throw p1
.end method

.method public callExperimentalAPI(Ljava/lang/String;)Ljava/lang/String;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "params"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->callExperimentalAPIJni(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method public createAIVoiceChanger()Lim/zego/zegoexpress/ZegoAIVoiceChanger;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->createAIVoiceChanger()Lim/zego/zegoexpress/ZegoAIVoiceChanger;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public createAudioEffectPlayer()Lim/zego/zegoexpress/ZegoAudioEffectPlayer;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->createAudioEffectPlayer()Lim/zego/zegoexpress/ZegoAudioEffectPlayer;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public createAudioVADClient()Lim/zego/zegoexpress/ZegoAudioVADClient;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoAudioVADClientInternalImpl;->createAudioVADClient()Lim/zego/zegoexpress/ZegoAudioVADClient;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    return-object v0
.end method

.method public createCopyrightedMusic()Lim/zego/zegoexpress/ZegoCopyrightedMusic;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->createCopyrightedMusic()Lim/zego/zegoexpress/ZegoCopyrightedMusic;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public createMediaDataPublisher(Lim/zego/zegoexpress/entity/ZegoMediaDataPublisherConfig;)Lim/zego/zegoexpress/ZegoMediaDataPublisher;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "config"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p1, Lim/zego/zegoexpress/entity/ZegoMediaDataPublisherConfig;->mode:Lim/zego/zegoexpress/constants/ZegoMediaDataPublisherMode;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoMediaDataPublisherMode;->value()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget p1, p1, Lim/zego/zegoexpress/entity/ZegoMediaDataPublisherConfig;->channel:I

    const/4 v1, 0x5

    move v2, v1

    invoke-static {v0, p1}, Lim/zego/zegoexpress/internal/ZegoMediaDataInternalImpl;->createMediaDataPublisher(II)Lim/zego/zegoexpress/ZegoMediaDataPublisher;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object p1
.end method

.method public createMediaPlayer()Lim/zego/zegoexpress/ZegoMediaPlayer;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoMediaPlayerInternalImpl;->createMediaPlayer()Lim/zego/zegoexpress/ZegoMediaPlayer;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object v0
.end method

.method public createRangeAudio()Lim/zego/zegoexpress/ZegoRangeAudio;
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoRangeAudioInternalImpl;->createRangeAudio()Lim/zego/zegoexpress/ZegoRangeAudio;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public createRangeScene()Lim/zego/zegoexpress/ZegoRangeScene;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoRangeSceneInternalImpl;->createRangeScene()Lim/zego/zegoexpress/ZegoRangeScene;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public createRealTimeSequentialDataManager(Ljava/lang/String;)Lim/zego/zegoexpress/ZegoRealTimeSequentialDataManager;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "roomID"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoRealTimeSequentialDataManagerInternalImpl;->createRealTimeSequentialDataManager(Ljava/lang/String;)Lim/zego/zegoexpress/ZegoRealTimeSequentialDataManager;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-object p1
.end method

.method public destroyAIVoiceChanger(Lim/zego/zegoexpress/ZegoAIVoiceChanger;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "aiVoiceChanger"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->destroyAIVoiceChanger(Lim/zego/zegoexpress/ZegoAIVoiceChanger;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public destroyAudioEffectPlayer(Lim/zego/zegoexpress/ZegoAudioEffectPlayer;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "audioEffectPlayer"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerInternalImpl;->destroyAudioEffectPlayer(Lim/zego/zegoexpress/ZegoAudioEffectPlayer;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public destroyAudioVADClient(Lim/zego/zegoexpress/ZegoAudioVADClient;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "client"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoAudioVADClientInternalImpl;->destroyAudioVADClient(Lim/zego/zegoexpress/ZegoAudioVADClient;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public destroyCopyrightedMusic(Lim/zego/zegoexpress/ZegoCopyrightedMusic;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "copyrightedMusic"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->destroyCopyrightedMusic(Lim/zego/zegoexpress/ZegoCopyrightedMusic;)V

    const/4 v0, 0x6

    move v1, v0

    return-void
.end method

.method public destroyMediaDataPublisher(Lim/zego/zegoexpress/ZegoMediaDataPublisher;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mediaDataPublisher"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoMediaDataInternalImpl;->destroyMediaDataPublisher(Lim/zego/zegoexpress/ZegoMediaDataPublisher;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public destroyMediaPlayer(Lim/zego/zegoexpress/ZegoMediaPlayer;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mediaPlayer"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoMediaPlayerInternalImpl;->destroyMediaPlayer(Lim/zego/zegoexpress/ZegoMediaPlayer;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public destroyRangeAudio(Lim/zego/zegoexpress/ZegoRangeAudio;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "rangeAudio"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoRangeAudioInternalImpl;->destroyRangeAudio(Lim/zego/zegoexpress/ZegoRangeAudio;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public destroyRangeScene(Lim/zego/zegoexpress/ZegoRangeScene;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "rangeScene"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoRangeSceneInternalImpl;->destroyRangeSceneInstance(Lim/zego/zegoexpress/ZegoRangeScene;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public destroyRealTimeSequentialDataManager(Lim/zego/zegoexpress/ZegoRealTimeSequentialDataManager;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "manager"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoRealTimeSequentialDataManagerInternalImpl;->destroyRealTimeSequentialDataManager(Lim/zego/zegoexpress/ZegoRealTimeSequentialDataManager;)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public enableAEC(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v1, 0x4

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableAECJni(Z)I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public enableAGC(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableAGCJni(Z)I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public enableANS(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableANSJni(Z)I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public enableAlignedAudioAuxData(ZLim/zego/zegoexpress/entity/ZegoAudioFrameParam;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "param"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p2, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object p2, p2, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value()I

    move-result p2

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p1, v0, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableAlignedAudioAuxData(ZII)I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public enableAlphaChannelVideoEncoder(ZLim/zego/zegoexpress/constants/ZegoAlphaLayoutType;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "enable",
            "alphaLayout",
            "channel"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoAlphaLayoutType;->value()I

    move-result p2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableAlphaChannelVideoEncoderJni(ZII)I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public enableAudioCaptureDevice(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableAudioCaptureDeviceJni(Z)I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public enableAudioMixing(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableAudioMixingJni(Z)I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public enableBeautify(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "featureBitmask"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->enableBeautify(ILim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public enableBeautify(ILim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "feature",
            "channel"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableBeautifyJni(II)I

    const/4 v1, 0x3

    return-void
.end method

.method public enableCamera(Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->enableCamera(ZLim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public enableCamera(ZLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "channel"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableCameraJni(ZI)I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public enableCameraAdaptiveFPS(ZIILim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "enable",
            "minFPS",
            "maxFPS",
            "channel"
        }
    .end annotation

    const/4 v0, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p4}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p4

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p1, p2, p3, p4}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableCameraAdaptiveFPSJni(ZIII)I

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public enableCheckPoc(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v1, 0x3

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableCheckPocJni(Z)I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public enableCustomAudioCaptureProcessing(ZLim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "config"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget v0, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->samples:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v1, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v1}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value()I

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object p2, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value()I

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    move p2, v0

    move p2, v0

    const/4 v3, 0x2

    move p2, v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    move v1, p2

    move v1, p2

    const/4 v3, 0x0

    move v1, p2

    move v1, p2

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p1, v0, v1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableCustomAudioCaptureProcessingJni(ZIII)I

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public enableCustomAudioCaptureProcessingAfterHeadphoneMonitor(ZLim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "config"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget v0, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->samples:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget-object v1, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v1}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p2, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value()I

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    move p2, v0

    move p2, v0

    const/4 v3, 0x6

    move p2, v0

    move p2, v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    move v1, p2

    move v1, p2

    const/4 v3, 0x2

    move v1, p2

    move v1, p2

    :goto_0
    const/4 v2, 0x2

    move v3, v2

    invoke-static {p1, v0, v1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableCustomAudioCaptureProcessingAfterHeadphoneMonitorJni(ZIII)I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method public enableCustomAudioIO(ZLim/zego/zegoexpress/entity/ZegoCustomAudioConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "config"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->enableCustomAudioIO(ZLim/zego/zegoexpress/entity/ZegoCustomAudioConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public enableCustomAudioIO(ZLim/zego/zegoexpress/entity/ZegoCustomAudioConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "enable",
            "config",
            "channel"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    if-nez p2, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    new-instance p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioConfig;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p2}, Lim/zego/zegoexpress/entity/ZegoCustomAudioConfig;-><init>()V

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iget-object p2, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioConfig;->sourceType:Lim/zego/zegoexpress/constants/ZegoAudioSourceType;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->value()I

    move-result p2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    if-eqz p3, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    sget-object p3, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    :goto_0
    const/4 v1, 0x2

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableCustomAudioIOJni(ZII)I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public enableCustomAudioPlaybackProcessing(ZLim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "config"
        }
    .end annotation

    const/4 v3, 0x2

    if-eqz p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v0, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->samples:I

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v1, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v1}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object p2, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value()I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    move p2, v0

    move p2, v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    move v1, p2

    move v1, p2

    const/4 v3, 0x4

    move v1, p2

    move v1, p2

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p1, v0, v1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableCustomAudioPlaybackProcessingJni(ZIII)I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method public enableCustomAudioRemoteProcessing(ZLim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "config"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget v0, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->samples:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v1, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v1}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object p2, p2, Lim/zego/zegoexpress/entity/ZegoCustomAudioProcessConfig;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value()I

    move-result p2

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    move p2, v0

    move p2, v0

    const/4 v3, 0x0

    move p2, v0

    move p2, v0

    const/4 v3, 0x1

    move v1, p2

    move v1, p2

    const/4 v3, 0x0

    move v1, p2

    move v1, p2

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p1, v0, v1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableCustomAudioRemoteProcessingJni(ZIII)I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method public enableCustomVideoCapture(ZLim/zego/zegoexpress/entity/ZegoCustomVideoCaptureConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "config"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->enableCustomVideoCapture(ZLim/zego/zegoexpress/entity/ZegoCustomVideoCaptureConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x5

    return-void
.end method

.method public enableCustomVideoCapture(ZLim/zego/zegoexpress/entity/ZegoCustomVideoCaptureConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "enable",
            "config",
            "channel"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableCustomVideoCaptureJni(ZLim/zego/zegoexpress/entity/ZegoCustomVideoCaptureConfig;I)I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public enableCustomVideoProcessing(ZLim/zego/zegoexpress/entity/ZegoCustomVideoProcessConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "config"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    invoke-virtual {p0, p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->enableCustomVideoProcessing(ZLim/zego/zegoexpress/entity/ZegoCustomVideoProcessConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public enableCustomVideoProcessing(ZLim/zego/zegoexpress/entity/ZegoCustomVideoProcessConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "enable",
            "config",
            "channel"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableCustomVideoProcessingJni(ZLim/zego/zegoexpress/entity/ZegoCustomVideoProcessConfig;I)I

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public enableCustomVideoRender(ZLim/zego/zegoexpress/entity/ZegoCustomVideoRenderConfig;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "config"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableCustomVideoRenderJni(ZLim/zego/zegoexpress/entity/ZegoCustomVideoRenderConfig;)I

    const/4 v1, 0x1

    const/4 v0, 0x0

    return-void
.end method

.method public enableDebugAssistant(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableDebugAssistant(Z)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public enableEffectsBeauty(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableEffectsBeautyJni(Z)I

    const/4 v1, 0x3

    const/4 v0, 0x3

    return-void
.end method

.method public enableH265EncodeFallback(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableH265EncodeFallbackJni(Z)I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public enableHardwareDecoder(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableHardwareDecoderJni(Z)I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public enableHardwareEncoder(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableHardwareEncoderJni(Z)I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public enableHeadphoneAEC(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableHeadphoneAECJni(Z)I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public enableHeadphoneMonitor(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableHeadphoneMonitorJni(Z)I

    const/4 v1, 0x5

    return-void
.end method

.method public enablePlayStreamVirtualStereo(ZILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "enable",
            "angle",
            "streamID"
        }
    .end annotation

    const/4 v0, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enablePlayStreamVirtualStereoJni(ZILjava/lang/String;)I

    const/4 v1, 0x5

    const/4 v0, 0x3

    return-void
.end method

.method public enablePublishDirectToCDN(ZLim/zego/zegoexpress/entity/ZegoCDNConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "config"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->enablePublishDirectToCDN(ZLim/zego/zegoexpress/entity/ZegoCDNConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public enablePublishDirectToCDN(ZLim/zego/zegoexpress/entity/ZegoCDNConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "enable",
            "zegoCDNConfig",
            "channel"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enablePublishDirectToCDNJni(ZLim/zego/zegoexpress/entity/ZegoCDNConfig;I)I

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void
.end method

.method public enableSpeechEnhance(ZI)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "level"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableSpeechEnhanceJni(ZI)I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public enableTrafficControl(ZI)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "property"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->enableTrafficControl(ZILim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public enableTrafficControl(ZILim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "enable",
            "property",
            "channel"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableTrafficControlJni(ZII)I

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-void
.end method

.method public enableTransientANS(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableTransientANSJni(Z)I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public enableVideoObjectSegmentation(ZLim/zego/zegoexpress/constants/ZegoObjectSegmentationType;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "enable",
            "type",
            "channel"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoObjectSegmentationType;->value()I

    move-result p2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableVideoObjectSegmentationJni(ZII)I

    const/4 v1, 0x5

    return-void
.end method

.method public enableVideoObjectSegmentation(ZLim/zego/zegoexpress/entity/ZegoObjectSegmentationConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "enable",
            "config",
            "channel"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableVideoObjectSegmentationWithConfigJni(ZLim/zego/zegoexpress/entity/ZegoObjectSegmentationConfig;I)I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public enableVideoSuperResolution(Ljava/lang/String;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "enable"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableVideoSuperResolutionJni(Ljava/lang/String;Z)I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public enableVirtualStereo(ZI)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "angle"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->enableVirtualStereoJni(ZI)I

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public fetchCustomAudioRenderPCMData(Ljava/nio/ByteBuffer;ILim/zego/zegoexpress/entity/ZegoAudioFrameParam;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "dataLength",
            "param"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    if-nez p3, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance p3, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-direct {p3}, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;-><init>()V

    :cond_0
    const/4 v1, 0x1

    move v2, v1

    iget-object v0, p3, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object p3, p3, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value()I

    move-result p3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p1, p2, v0, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->fetchCustomAudioRenderPCMDataJni(Ljava/nio/ByteBuffer;III)I

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public getAudioConfig()Lim/zego/zegoexpress/entity/ZegoAudioConfig;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->getAudioConfig(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)Lim/zego/zegoexpress/entity/ZegoAudioConfig;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public getAudioConfig(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)Lim/zego/zegoexpress/entity/ZegoAudioConfig;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "channel"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->getAudioConfigJni(I)Lim/zego/zegoexpress/entity/ZegoAudioConfig;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-object p1
.end method

.method public getAudioRouteType()Lim/zego/zegoexpress/constants/ZegoAudioRoute;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->getAudioRouteTypeJni()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {v0}, Lim/zego/zegoexpress/constants/ZegoAudioRoute;->getZegoAudioRoute(I)Lim/zego/zegoexpress/constants/ZegoAudioRoute;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public getCameraMaxZoomFactor()F
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->getCameraMaxZoomFactor(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)F

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public getCameraMaxZoomFactor(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)F
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "channel"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->getCameraMaxZoomFactorJni(I)F

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return p1
.end method

.method public getCustomVideoCaptureSurfaceTexture()Landroid/graphics/SurfaceTexture;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->getCustomVideoCaptureSurfaceTextureJni(I)Landroid/graphics/SurfaceTexture;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object v0
.end method

.method public getCustomVideoCaptureSurfaceTexture(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)Landroid/graphics/SurfaceTexture;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "channel"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->getCustomVideoCaptureSurfaceTextureJni(I)Landroid/graphics/SurfaceTexture;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p1
.end method

.method public getCustomVideoProcessOutputSurfaceTexture(II)Landroid/graphics/SurfaceTexture;
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "width",
            "height"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->getCustomVideoProcessOutputSurfaceTexture(IILim/zego/zegoexpress/constants/ZegoPublishChannel;)Landroid/graphics/SurfaceTexture;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p1
.end method

.method public getCustomVideoProcessOutputSurfaceTexture(IILim/zego/zegoexpress/constants/ZegoPublishChannel;)Landroid/graphics/SurfaceTexture;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "width",
            "height",
            "channel"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    sget-object p3, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x4

    const/4 v0, 0x1

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->getCustomVideoProcessOutputSurfaceTextureJni(III)Landroid/graphics/SurfaceTexture;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method

.method public getNetworkTimeInfo()Lim/zego/zegoexpress/entity/ZegoNetworkTimeInfo;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->getNetworkTimeInfo()Lim/zego/zegoexpress/entity/ZegoNetworkTimeInfo;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    return-object v0
.end method

.method public getVideoConfig()Lim/zego/zegoexpress/entity/ZegoVideoConfig;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->getVideoConfig(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)Lim/zego/zegoexpress/entity/ZegoVideoConfig;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method public getVideoConfig(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)Lim/zego/zegoexpress/entity/ZegoVideoConfig;
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "main"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->getVideoConfigJni(I)Lim/zego/zegoexpress/entity/ZegoVideoConfig;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p1
.end method

.method public initVideoSuperResolution()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->initVideoSuperResolutionJni()I

    const/4 v1, 0x7

    return-void
.end method

.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "proxy",
            "method",
            "args"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Throwable;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->hashCode()I

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p3, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    and-int/2addr v3, v2

    const/4 v1, -0x1

    move v3, v1

    const/4 v2, 0x4

    shl-int/2addr v3, v2

    sparse-switch p2, :sswitch_data_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto/16 :goto_0

    :sswitch_0
    const-string p2, "RC_EAEOpURTAT_TRSRT_NOq"

    const-string p2, "UTTRSC_OqPN_A_OARRTRTEE"

    const-string p2, "A_USRTPEqEOON_RTRRCT_AT"

    const-string p2, "ERROR_NOT_START_CAPTURE"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    goto/16 :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/16 v1, 0xa

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto/16 :goto_0

    :sswitch_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string p2, "O_sRCETON_PIESRMYRXSTE"

    const/4 v3, 0x2

    const-string p2, "ERROR_SYSTEM_EXCEPTION"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto/16 :goto_0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/16 v1, 0x9

    const/4 v2, 0x0

    and-int/2addr v3, v2

    goto/16 :goto_0

    :sswitch_2
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string p2, "IMsIEERO__DAOINSE_DEmDE_CRRURROSORIN"

    const-string p2, "__RmONOERSOUD__MCDREESIDRINORREIIAED"

    const/4 v3, 0x5

    const-string p2, "E_OmDOEREISNIODENPROSMR_DADCR_R_UIRE"

    const-string p2, "ERROR_AUDIO_RECORD_PERMISSION_DENIED"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-nez p1, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto/16 :goto_0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/16 v1, 0x8

    const/4 v3, 0x3

    goto/16 :goto_0

    :sswitch_3
    const/4 v2, 0x0

    move v3, v2

    const-string p2, "IVOEo_ODERRRERRCFoRONEU_"

    const-string p2, "ERREo_R_VFRSOCRIREDNUOOE"

    const-string p2, "N_EGCbUSF_DERIEROVRRROOE"

    const-string p2, "ERROR_FOREGROUND_SERVICE"

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez p1, :cond_3

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto/16 :goto_0

    :cond_3
    const/4 v3, 0x3

    const/4 v1, 0x7

    const/4 v3, 0x2

    move v2, v1

    move v2, v1

    const/4 v3, 0x5

    goto/16 :goto_0

    :sswitch_4
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string p2, "RYESS_uODTIEOR__DR_PRbPNOUETUMAT"

    const-string p2, "UDEPOb__OSNA_YMTRRREOPUD_IRTOTES"

    const/4 v3, 0x3

    const-string p2, "OPSDTSOpT_SIYUNO_RTM_UPDOERERAR_"

    const-string p2, "ERROR_AUDIO_SYSTEM_NOT_SUPPORTED"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez p1, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto/16 :goto_0

    :cond_4
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x6

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    goto/16 :goto_0

    :sswitch_5
    const/4 v2, 0x7

    move v3, v2

    const-string p2, "_RU_E_CRqDOIREUOADIDRuOB"

    const-string p2, "LDD_URuBO_EEICROROD_ARUI"

    const/4 v3, 0x0

    const-string p2, "BIsOCRRU_EDRDREOLDA_RUO_"

    const-string p2, "ERROR_AUDIO_RECORD_BUILD"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez p1, :cond_5

    const/4 v3, 0x3

    goto/16 :goto_0

    :cond_5
    const/4 v2, 0x0

    move v3, v2

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto/16 :goto_0

    :sswitch_6
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string p2, "NRTmS_E_OYOUDEEPPIDEVRTRO__pMSTS"

    const-string p2, "ORDOETRpEPTEOPSDVNMR_RST_EYIU__S"

    const-string p2, "MRDOoT_OP_RONEUSSVETDET__YRROPIS"

    const-string p2, "ERROR_VIDEO_SYSTEM_NOT_SUPPORTED"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez p1, :cond_6

    const/4 v3, 0x5

    goto/16 :goto_0

    :cond_6
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 v1, 0x4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto/16 :goto_0

    :sswitch_7
    const/4 v2, 0x4

    move v3, v2

    const-string p2, "RFADER_UqR_TDBAEUIO_FACEORDRREE"

    const-string p2, "CRAUDbORE_RDEEFA_RDOEU_BAFTIRE_"

    const-string p2, "ERROR_AUDIO_CREATED_READ_BUFFER"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez p1, :cond_7

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    goto :goto_0

    :cond_7
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x3

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :sswitch_8
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string p2, "_UTTREuPPRRTETEDRRAOAE_AS_RE"

    const-string p2, "RRsUT_ATEDO_ARPERR_EETTERSPA"

    const/4 v3, 0x6

    const-string p2, "DP__UA_pEESAREEATORRTRCPERTT"

    const-string p2, "ERROR_CAPTURE_START_REPEATED"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez p1, :cond_8

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_0

    :cond_8
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    goto :goto_0

    :sswitch_9
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string p2, "ETME_RNEqNDDONI_EDI_SIPEOSRRImRRIJPECA_O"

    const-string p2, "_R_mI_TIONDARRRDPOEISOISE_EENDPENCIEMOJR"

    const/4 v3, 0x4

    const-string p2, "ERROR_MEDIA_PROJECTION_PERMISSION_DENIED"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez p1, :cond_9

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    goto :goto_0

    :cond_9
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    move v1, p3

    move v1, p3

    const/4 v3, 0x4

    move v1, p3

    move v1, p3

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    goto :goto_0

    :sswitch_a
    const/4 v3, 0x5

    const-string p2, "_VsE_DRROIOYARARTERCTEXLoOF_"

    const-string p2, "E_ROoRTXCOD_O_RLEEVYTAFARIER"

    const/4 v3, 0x2

    const-string p2, "LTAmIX_RRRETONRVE_YFOCEA_ORD"

    const-string p2, "ERROR_VIDEO_EXTERNAL_FACTORY"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez p1, :cond_a

    const/4 v3, 0x0

    goto :goto_0

    :cond_a
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    move v1, v0

    move v1, v0

    const/4 v3, 0x7

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    packed-switch v1, :pswitch_data_0

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_1

    :pswitch_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->NOT_START_CAPTURE:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    goto :goto_1

    :pswitch_1
    const/4 v3, 0x4

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->SYSTEM_ERROR:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x7

    goto :goto_1

    :pswitch_2
    const/4 v3, 0x0

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->FOREGROUND_SERVICE_FAILED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_1

    :pswitch_3
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->AUDIO_NOT_SUPPORTED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_1

    :pswitch_4
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->VIDEO_NOT_SUPPORTED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_1

    :pswitch_5
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->AUDIO_CREATE_FAILED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_1

    :pswitch_6
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->ALREADY_STARTED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    goto :goto_1

    :pswitch_7
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->MEDIA_PROJECTION_PERMISSION_DENIED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_1

    :pswitch_8
    const/4 v3, 0x0

    const/4 v2, 0x1

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;->SOURCE_NOT_SPECIFIED:Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;

    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-array p2, p3, [Ljava/lang/Object;

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    aput-object p1, p2, v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo p3, "tcbco.%nCerOedros ynrtp:EiaeoeprcpSutne ex"

    const-string p3, "ep.eebx rnOnyccdttrpSCuenoe%erticpc soEa:r"

    const/4 v3, 0x1

    const-string p3, "cndpcbruxerc yeOeoeto pruisC:e%cnapnE.ttSe"

    const-string/jumbo p3, "onScreenCaptureExceptionOccurred. type: %s"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p3, p2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string p3, "eruatcuesnucp"

    const-string/jumbo p3, "utrensucpacre"

    const-string/jumbo p3, "tneceacprsure"

    const-string/jumbo p3, "screencapture"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->logNotice(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz p2, :cond_b

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance p3, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl$1;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p3, p0, p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl$1;-><init>(Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;Lim/zego/zegoexpress/constants/ZegoScreenCaptureExceptionType;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p2, p3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_b
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p1

    nop

    :sswitch_data_0
    .sparse-switch
        -0x561cbbef -> :sswitch_a
        -0x5282f193 -> :sswitch_9
        -0x2cffb6b9 -> :sswitch_8
        -0x2a24498e -> :sswitch_7
        -0x2487f9f3 -> :sswitch_6
        -0x1db49d80 -> :sswitch_5
        0xfae3592 -> :sswitch_4
        0x23fe6f50 -> :sswitch_3
        0x25efbd3d -> :sswitch_2
        0x39062796 -> :sswitch_1
        0x51084906 -> :sswitch_0
    .end sparse-switch

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_5
        :pswitch_3
        :pswitch_2
        :pswitch_5
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public isCameraFocusSupported(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)Z
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "channel"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->isCameraFocusSupportedJni(I)Z

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p1
.end method

.method public isMicrophoneMuted()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->isMicrophoneMutedJni()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public isSpeakerMuted()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->isSpeakerMutedJni()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    return v0
.end method

.method public isVideoDecoderSupported(Lim/zego/zegoexpress/constants/ZegoVideoCodecID;Lim/zego/zegoexpress/constants/ZegoVideoCodecBackend;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "codecID",
            "codecBackend"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoVideoCodecBackend;->value()I

    move-result p2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->isVideoDecoderSupportedJni(II)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return p1
.end method

.method public isVideoDecoderSupported(Lim/zego/zegoexpress/constants/ZegoVideoCodecID;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "codecID"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value()I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecBackend;->ANY:Lim/zego/zegoexpress/constants/ZegoVideoCodecBackend;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoVideoCodecBackend;->value()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->isVideoDecoderSupportedJni(II)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 p1, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    return p1
.end method

.method public isVideoEncoderSupported(Lim/zego/zegoexpress/constants/ZegoVideoCodecID;Lim/zego/zegoexpress/constants/ZegoVideoCodecBackend;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "codecID",
            "codecBackend"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoVideoCodecBackend;->value()I

    move-result p2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->isVideoEncoderSupportedJni(II)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return p1
.end method

.method public isVideoEncoderSupported(Lim/zego/zegoexpress/constants/ZegoVideoCodecID;)Z
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "codecID"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecBackend;->ANY:Lim/zego/zegoexpress/constants/ZegoVideoCodecBackend;

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoVideoCodecBackend;->value()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->isVideoEncoderSupportedJni(II)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x7

    or-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return p1
.end method

.method public loginRoom(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoUser;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "roomID",
            "user"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2, v0, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->loginRoom(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoUser;Lim/zego/zegoexpress/entity/ZegoRoomConfig;Lim/zego/zegoexpress/callback/IZegoRoomLoginCallback;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public loginRoom(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoUser;Lim/zego/zegoexpress/entity/ZegoRoomConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "roomID",
            "user",
            "config"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, p1, p2, p3, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->loginRoom(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoUser;Lim/zego/zegoexpress/entity/ZegoRoomConfig;Lim/zego/zegoexpress/callback/IZegoRoomLoginCallback;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method

.method public loginRoom(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoUser;Lim/zego/zegoexpress/entity/ZegoRoomConfig;Lim/zego/zegoexpress/callback/IZegoRoomLoginCallback;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "roomID",
            "user",
            "config",
            "callback"
        }
    .end annotation

    const/4 v0, 0x6

    const/4 v0, 0x6

    if-nez p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x3

    const-string p1, ""

    const-string p1, ""

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p2, p1, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->loginRoomWithCallbackJni(Lim/zego/zegoexpress/entity/ZegoUser;Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoRoomConfig;)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    if-eqz p4, :cond_1

    const/4 v1, 0x0

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v1, 0x2

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    monitor-enter p2

    :try_start_0
    const/4 v1, 0x3

    const/4 v0, 0x7

    sget-object p3, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomLoginResultHandler:Ljava/util/HashMap;

    const/4 v1, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p3, p1, p4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v0, 0x1

    move v1, v0

    monitor-exit p2

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x2

    throw p1

    :cond_1
    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x1

    return-void
.end method

.method public logoutRoom()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->logoutAllRoomWithCallbackJni()I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public logoutRoom(Lim/zego/zegoexpress/callback/IZegoRoomLogoutCallback;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "callback"
        }
    .end annotation

    const/4 v4, 0x6

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->logoutAllRoomWithCallbackJni()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-class v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v4, 0x4

    const-class v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    monitor-enter v1

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomLogoutResultHandler:Ljava/util/HashMap;

    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v2, v0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    monitor-exit v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    throw p1

    :cond_0
    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method public logoutRoom(Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "roomID"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->logoutRoom(Ljava/lang/String;Lim/zego/zegoexpress/callback/IZegoRoomLogoutCallback;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public logoutRoom(Ljava/lang/String;Lim/zego/zegoexpress/callback/IZegoRoomLogoutCallback;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "roomID",
            "callback"
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->logoutRoomWithCallbackJni(Ljava/lang/String;)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p2, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x0

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomLogoutResultHandler:Ljava/util/HashMap;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-virtual {v1, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    throw p1

    :cond_0
    :goto_0
    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method

.method public muteAllPlayAudioStreams(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mute"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->muteAllPlayAudioStreamsJni(Z)I

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public muteAllPlayStreamAudio(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mute"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->muteAllPlayStreamAudioJni(Z)I

    const/4 v1, 0x5

    const/4 v0, 0x4

    return-void
.end method

.method public muteAllPlayStreamVideo(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mute"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->muteAllPlayStreamVideoJni(Z)I

    const/4 v1, 0x4

    return-void
.end method

.method public muteAllPlayVideoStreams(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mute"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->muteAllPlayVideoStreamsJni(Z)I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public muteLocalAudioMixing(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mute"
        }
    .end annotation

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->muteLocalAudioMixingJni(Z)I

    const/4 v1, 0x2

    const/4 v0, 0x7

    return-void
.end method

.method public muteMicrophone(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mute"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->muteMicrophoneJni(Z)I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public mutePlayStreamAudio(Ljava/lang/String;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "mute"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->mutePlayStreamAudioJni(Ljava/lang/String;Z)I

    const/4 v1, 0x4

    const/4 v0, 0x6

    return-void
.end method

.method public mutePlayStreamVideo(Ljava/lang/String;Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "mute"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->mutePlayStreamVideoJni(Ljava/lang/String;Z)I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public mutePublishStreamAudio(Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mute"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mutePublishStreamAudio(ZLim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public mutePublishStreamAudio(ZLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mute",
            "channel"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x6

    const/4 v0, 0x3

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->mutePublishStreamAudioJni(ZI)I

    const/4 v1, 0x5

    const/4 v0, 0x7

    return-void
.end method

.method public mutePublishStreamVideo(Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mute"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mutePublishStreamVideo(ZLim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x3

    return-void
.end method

.method public mutePublishStreamVideo(ZLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mute",
            "channel"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->mutePublishStreamVideoJni(ZI)I

    const/4 v0, 0x7

    or-int/2addr v1, v0

    return-void
.end method

.method public muteSpeaker(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->muteSpeakerJni(Z)I

    const/4 v1, 0x4

    return-void
.end method

.method public removeDumpData()V
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->removeDumpDataJni()I

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public removePublishCdnUrl(Ljava/lang/String;Ljava/lang/String;Lim/zego/zegoexpress/callback/IZegoPublisherUpdateCdnUrlCallback;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "streamID",
            "targetURL",
            "handler"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->removePublishCdnUrlJni(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    monitor-enter p2

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPublisherUpdateCDNURLHandler:Ljava/util/HashMap;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x1

    monitor-exit p2

    const/4 v2, 0x2

    const/4 v1, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    throw p1
.end method

.method public renewToken(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "roomID",
            "token"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->renewTokenJni(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public sendAudioSideInfo([BDLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "timeStampMs",
            "channel"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p4}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p4

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p1, p2, p3, p4}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->sendAudioSideInfoJni([BDI)I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public sendBarrageMessage(Ljava/lang/String;Ljava/lang/String;Lim/zego/zegoexpress/callback/IZegoIMSendBarrageMessageCallback;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "roomID",
            "message",
            "handler"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->sendBarrageMessageJni(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v2, 0x0

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    monitor-enter p2

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendBarrageMessageHandler:Ljava/util/HashMap;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, p1, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    monitor-exit p2

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    throw p1
.end method

.method public sendBroadcastMessage(Ljava/lang/String;Ljava/lang/String;Lim/zego/zegoexpress/callback/IZegoIMSendBroadcastMessageCallback;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "roomID",
            "message",
            "callback"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->sendBroadcastMessageJni(Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v2, 0x2

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    monitor-enter p2

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendBroadcastMessageHandler:Ljava/util/HashMap;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    monitor-exit p2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    throw p1
.end method

.method public sendCustomAudioCaptureAACData(Ljava/nio/ByteBuffer;IIJILim/zego/zegoexpress/entity/ZegoAudioFrameParam;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "dataLength",
            "configLength",
            "referenceTimeMillisecond",
            "samples",
            "param",
            "channel"
        }
    .end annotation

    if-nez p7, :cond_0

    new-instance v0, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    invoke-direct {v0}, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;-><init>()V

    goto :goto_0

    :cond_0
    move-object/from16 v0, p7

    move-object/from16 v0, p7

    move-object/from16 v0, p7

    move-object/from16 v0, p7

    :goto_0
    iget-object v1, v0, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    invoke-virtual {v1}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value()I

    move-result v8

    iget-object v0, v0, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value()I

    move-result v9

    if-nez p8, :cond_1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result v0

    goto :goto_1

    :cond_1
    invoke-virtual/range {p8 .. p8}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result v0

    :goto_1
    move v10, v0

    move v10, v0

    move v10, v0

    move v10, v0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move v3, p2

    move v3, p2

    move v3, p2

    move v3, p2

    move v4, p3

    move v4, p3

    move v4, p3

    move v4, p3

    move-wide v5, p4

    move/from16 v7, p6

    move/from16 v7, p6

    move/from16 v7, p6

    invoke-static/range {v2 .. v10}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->sendCustomAudioCaptureAACDataJni(Ljava/nio/ByteBuffer;IIJIIII)I

    return-void
.end method

.method public sendCustomAudioCapturePCMData(Ljava/nio/ByteBuffer;ILim/zego/zegoexpress/entity/ZegoAudioFrameParam;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "dataLength",
            "param"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0, p1, p2, p3, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sendCustomAudioCapturePCMData(Ljava/nio/ByteBuffer;ILim/zego/zegoexpress/entity/ZegoAudioFrameParam;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public sendCustomAudioCapturePCMData(Ljava/nio/ByteBuffer;ILim/zego/zegoexpress/entity/ZegoAudioFrameParam;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "dataLength",
            "param",
            "channel"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez p3, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    new-instance p3, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p3}, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;-><init>()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p3, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object p3, p3, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value()I

    move-result p3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez p4, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object p4, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p4}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p4

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1, p2, v0, p3, p4}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->sendCustomAudioCapturePCMDataJni(Ljava/nio/ByteBuffer;IIII)I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public sendCustomCommand(Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;Lim/zego/zegoexpress/callback/IZegoIMSendCustomCommandCallback;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "roomID",
            "command",
            "toUserList",
            "callback"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Lim/zego/zegoexpress/entity/ZegoUser;",
            ">;",
            "Lim/zego/zegoexpress/callback/IZegoIMSendCustomCommandCallback;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-nez p3, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance p3, Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p3}, Ljava/util/ArrayList;-><init>()V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p3}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    new-array v0, v0, [Lim/zego/zegoexpress/entity/ZegoUser;

    const/4 v1, 0x0

    shl-int/2addr v2, v1

    invoke-virtual {p3, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    check-cast p3, [Lim/zego/zegoexpress/entity/ZegoUser;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p2, p3, p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->sendCustomerMessageJni(Ljava/lang/String;[Lim/zego/zegoexpress/entity/ZegoUser;Ljava/lang/String;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v2, 0x6

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    monitor-enter p2

    :try_start_0
    const/4 v2, 0x2

    sget-object p3, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendCustomCommandHandler:Ljava/util/HashMap;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p3, p1, p4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    monitor-exit p2

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    throw p1
.end method

.method public sendCustomVideoCaptureEncodedData(Ljava/nio/ByteBuffer;ILim/zego/zegoexpress/entity/ZegoVideoEncodedFrameParam;J)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "dataLength",
            "params",
            "referenceTimeMillisecond"
        }
    .end annotation

    const/4 v7, 0x0

    move v8, v7

    sget-object v6, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    move v2, p2

    move v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-wide v4, p4

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual/range {v0 .. v6}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sendCustomVideoCaptureEncodedData(Ljava/nio/ByteBuffer;ILim/zego/zegoexpress/entity/ZegoVideoEncodedFrameParam;JLim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    return-void
.end method

.method public sendCustomVideoCaptureEncodedData(Ljava/nio/ByteBuffer;ILim/zego/zegoexpress/entity/ZegoVideoEncodedFrameParam;JLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 14
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "dataLength",
            "params",
            "referenceTimeMillisecond",
            "channel"
        }
    .end annotation

    move-object/from16 v0, p3

    move-object/from16 v0, p3

    move-object/from16 v0, p3

    iget-object v1, v0, Lim/zego/zegoexpress/entity/ZegoVideoEncodedFrameParam;->format:Lim/zego/zegoexpress/constants/ZegoVideoEncodedFrameFormat;

    invoke-virtual {v1}, Lim/zego/zegoexpress/constants/ZegoVideoEncodedFrameFormat;->value()I

    move-result v4

    iget-boolean v5, v0, Lim/zego/zegoexpress/entity/ZegoVideoEncodedFrameParam;->isKeyFrame:Z

    iget v6, v0, Lim/zego/zegoexpress/entity/ZegoVideoEncodedFrameParam;->width:I

    iget v7, v0, Lim/zego/zegoexpress/entity/ZegoVideoEncodedFrameParam;->height:I

    iget-object v8, v0, Lim/zego/zegoexpress/entity/ZegoVideoEncodedFrameParam;->SEIData:Ljava/nio/ByteBuffer;

    iget v9, v0, Lim/zego/zegoexpress/entity/ZegoVideoEncodedFrameParam;->SEIDataLength:I

    iget v10, v0, Lim/zego/zegoexpress/entity/ZegoVideoEncodedFrameParam;->rotation:I

    invoke-virtual/range {p6 .. p6}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result v13

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move/from16 v3, p2

    move/from16 v3, p2

    move/from16 v3, p2

    move/from16 v3, p2

    move-wide/from16 v11, p4

    invoke-static/range {v2 .. v13}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->sendCustomVideoCaptureEncodedDataJni(Ljava/nio/ByteBuffer;IIZIILjava/nio/ByteBuffer;IIJI)I

    return-void
.end method

.method public sendCustomVideoCaptureRawData(Ljava/nio/ByteBuffer;ILim/zego/zegoexpress/entity/ZegoVideoFrameParam;J)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "dataLength",
            "params",
            "referenceTimeMillisecond"
        }
    .end annotation

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    sget-object v6, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    move v2, p2

    const/4 v8, 0x7

    move v2, p2

    move v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-wide v4, p4

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual/range {v0 .. v6}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sendCustomVideoCaptureRawData(Ljava/nio/ByteBuffer;ILim/zego/zegoexpress/entity/ZegoVideoFrameParam;JLim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    return-void
.end method

.method public sendCustomVideoCaptureRawData(Ljava/nio/ByteBuffer;ILim/zego/zegoexpress/entity/ZegoVideoFrameParam;JLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 12
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "dataLength",
            "params",
            "referenceTimeMillisecond",
            "channel"
        }
    .end annotation

    move-object v0, p3

    move-object v0, p3

    iget-object v1, v0, Lim/zego/zegoexpress/entity/ZegoVideoFrameParam;->format:Lim/zego/zegoexpress/constants/ZegoVideoFrameFormat;

    invoke-virtual {v1}, Lim/zego/zegoexpress/constants/ZegoVideoFrameFormat;->value()I

    move-result v4

    iget-object v5, v0, Lim/zego/zegoexpress/entity/ZegoVideoFrameParam;->strides:[I

    iget v6, v0, Lim/zego/zegoexpress/entity/ZegoVideoFrameParam;->width:I

    iget v7, v0, Lim/zego/zegoexpress/entity/ZegoVideoFrameParam;->height:I

    invoke-virtual/range {p6 .. p6}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result v10

    iget v11, v0, Lim/zego/zegoexpress/entity/ZegoVideoFrameParam;->rotation:I

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move v3, p2

    move v3, p2

    move v3, p2

    move-wide/from16 v8, p4

    invoke-static/range {v2 .. v11}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->sendCustomVideoCaptureRawDataJni(Ljava/nio/ByteBuffer;II[IIIJII)I

    return-void
.end method

.method public sendCustomVideoCaptureTextureData(IIID)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "textureID",
            "width",
            "height",
            "referenceTimeMillisecond"
        }
    .end annotation

    const/4 v7, 0x2

    move v8, v7

    sget-object v6, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-object v0, p0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    move v1, p1

    move v1, p1

    const/4 v8, 0x4

    move v1, p1

    move v1, p1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    move v2, p2

    move v2, p2

    const/4 v8, 0x4

    move v2, p2

    move v2, p2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    move v3, p3

    move v3, p3

    const/4 v8, 0x1

    move v3, p3

    move v3, p3

    move-wide v4, p4

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual/range {v0 .. v6}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sendCustomVideoCaptureTextureData(IIIDLim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v7, 0x0

    or-int/2addr v8, v7

    return-void
.end method

.method public sendCustomVideoCaptureTextureData(IIIDLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "textureID",
            "width",
            "height",
            "referenceTimeMillisecond",
            "channel"
        }
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p6}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result v5

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    move v0, p1

    move v0, p1

    const/4 v7, 0x5

    move v0, p1

    move v0, p1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    move v1, p2

    move v1, p2

    const/4 v7, 0x7

    move v1, p2

    move v1, p2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    move v2, p3

    move v2, p3

    move-wide v3, p4

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static/range {v0 .. v5}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->sendCustomVideoCaptureTextureDataJni(IIIDI)I

    return-void
.end method

.method public sendCustomVideoProcessedTextureData(IIIJ)V
    .locals 9
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "textureID",
            "width",
            "height",
            "referenceTimeMillisecond"
        }
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    sget-object v6, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    move v1, p1

    move v1, p1

    const/4 v8, 0x4

    move v1, p1

    move v1, p1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    move v2, p2

    move v2, p2

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    move v3, p3

    move v3, p3

    const/4 v8, 0x0

    move v3, p3

    move v3, p3

    move-wide v4, p4

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual/range {v0 .. v6}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sendCustomVideoProcessedTextureData(IIIJLim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    return-void
.end method

.method public sendCustomVideoProcessedTextureData(IIIJLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 8
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "textureID",
            "width",
            "height",
            "referenceTimeMillisecond",
            "channel"
        }
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p6}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result v5

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    move v0, p1

    move v0, p1

    const/4 v7, 0x4

    move v0, p1

    move v0, p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    move v1, p2

    move v1, p2

    const/4 v7, 0x6

    move v1, p2

    move v1, p2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    move v2, p3

    move v2, p3

    const/4 v7, 0x2

    move v2, p3

    move v2, p3

    move-wide v3, p4

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-static/range {v0 .. v5}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->sendCustomVideoProcessedTextureDataJni(IIIJI)I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-void
.end method

.method public sendSEI([B)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "data"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sendSEI([BLim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public sendSEI([BLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "data",
            "channel"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->sendSEIJni([BI)I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public sendSEISyncWithCustomVideo([BJLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "data",
            "timeStampNs",
            "channel"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p4}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p4

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p1, p2, p3, p4}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->sendSEISyncWithCustomVideoJni([BJI)I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public setAECMode(Lim/zego/zegoexpress/constants/ZegoAECMode;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mode"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoAECMode;->value()I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAECModeJni(I)I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public setANSMode(Lim/zego/zegoexpress/constants/ZegoANSMode;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mode"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoANSMode;->value()I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setANSModeJni(I)I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public setAllPlayStreamVolume(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "volume"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAllPlayStreamVolume(I)I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public setAppOrientation(Lim/zego/zegoexpress/constants/ZegoOrientation;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "orientation"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setAppOrientation(Lim/zego/zegoexpress/constants/ZegoOrientation;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public setAppOrientation(Lim/zego/zegoexpress/constants/ZegoOrientation;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "orientation",
            "channel"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    if-nez p1, :cond_0

    const/4 v1, 0x3

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoOrientation;->ORIENTATION_0:Lim/zego/zegoexpress/constants/ZegoOrientation;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoOrientation;->value()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAppOrientationJni(II)I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoOrientation;->value()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAppOrientationJni(II)I

    :goto_0
    const/4 v0, 0x6

    move v1, v0

    return-void
.end method

.method public setAppOrientationMode(Lim/zego/zegoexpress/constants/ZegoOrientationMode;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mode"
        }
    .end annotation

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoOrientationMode;->value()I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAppOrientationModeJni(I)I

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-void
.end method

.method public setAudioCaptureStereoMode(Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mode"
        }
    .end annotation

    const/4 v0, 0x6

    move v1, v0

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoAudioCaptureStereoMode;->value()I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAudioCaptureStereoModeJni(I)I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public setAudioConfig(Lim/zego/zegoexpress/entity/ZegoAudioConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "config"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v1, 0x7

    move v2, v1

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setAudioConfig(Lim/zego/zegoexpress/entity/ZegoAudioConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public setAudioConfig(Lim/zego/zegoexpress/entity/ZegoAudioConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "config",
            "publishChannel"
        }
    .end annotation

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget v0, p1, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->bitrate:I

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p1, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v1}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p1, p1, Lim/zego/zegoexpress/entity/ZegoAudioConfig;->codecID:Lim/zego/zegoexpress/constants/ZegoAudioCodecID;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoAudioCodecID;->value()I

    move-result p1

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v0, v1, p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAudioConfigJni(IIII)I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 p1, 0x0

    const/4 v3, 0x0

    const/4 p1, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1, p1, p1, p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAudioConfigJni(IIII)I

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method

.method public setAudioDataHandler(Lim/zego/zegoexpress/callback/IZegoAudioDataHandler;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "handler"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    sput-object p1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->iZegoAudioDataHandler:Lim/zego/zegoexpress/callback/IZegoAudioDataHandler;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public setAudioDeviceMode(Lim/zego/zegoexpress/constants/ZegoAudioDeviceMode;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "deviceMode"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoAudioDeviceMode;->value()I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAudioDeviceModeJni(I)I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public setAudioEqualizerGain(IF)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "bandIndex",
            "bandGain"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAudioEqualizerGainJni(IF)I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public setAudioMixingHandler(Lim/zego/zegoexpress/callback/IZegoAudioMixingHandler;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "handler"
        }
    .end annotation

    const/4 v1, 0x4

    sput-object p1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->iZegoAudioMixingHandler:Lim/zego/zegoexpress/callback/IZegoAudioMixingHandler;

    const/4 v1, 0x1

    return-void
.end method

.method public setAudioMixingVolume(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "volume"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAudioMixingVolumeJni(I)I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public setAudioMixingVolume(ILim/zego/zegoexpress/constants/ZegoVolumeType;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "volume",
            "type"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoVolumeType;->value()I

    move-result p2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAudioMixingVolumeJniWithType(II)I

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public setAudioRouteToSpeaker(Z)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "defaultToSpeaker"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAudioRouteToSpeakerJni(Z)I

    const/4 v1, 0x6

    const/4 v0, 0x3

    return-void
.end method

.method public setAudioSource(Lim/zego/zegoexpress/constants/ZegoAudioSourceType;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "source"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setAudioSource(Lim/zego/zegoexpress/constants/ZegoAudioSourceType;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return p1
.end method

.method public setAudioSource(Lim/zego/zegoexpress/constants/ZegoAudioSourceType;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "source",
            "channel"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->value()I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAudioSourceJni(II)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    return p1
.end method

.method public setAudioSource(Lim/zego/zegoexpress/constants/ZegoAudioSourceType;Lim/zego/zegoexpress/entity/ZegoAudioSourceMixConfig;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "source",
            "config"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoAudioSourceType;->value()I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setAudioSourceWithConfigJni(ILim/zego/zegoexpress/entity/ZegoAudioSourceMixConfig;)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return p1
.end method

.method public setBeautifyOption(Lim/zego/zegoexpress/entity/ZegoBeautifyOption;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "option"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setBeautifyOption(Lim/zego/zegoexpress/entity/ZegoBeautifyOption;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method public setBeautifyOption(Lim/zego/zegoexpress/entity/ZegoBeautifyOption;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "option",
            "channel"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setBeautifyOptionJni(Lim/zego/zegoexpress/entity/ZegoBeautifyOption;I)I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public setCameraExposureCompensation(F)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "value"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setCameraExposureCompensation(FLim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public setCameraExposureCompensation(FLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "value",
            "channel"
        }
    .end annotation

    const/4 v0, 0x0

    move v1, v0

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCameraExposureCompensationJni(FI)I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public setCameraExposureMode(Lim/zego/zegoexpress/constants/ZegoCameraExposureMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mode",
            "channel"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoCameraExposureMode;->value()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCameraExposureModeJni(II)I

    const/4 v1, 0x1

    return-void
.end method

.method public setCameraExposurePointInPreview(FFLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "x",
            "y",
            "channel"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCameraExposurePointInPreviewJni(FFI)I

    const/4 v1, 0x7

    return-void
.end method

.method public setCameraFocusMode(Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mode",
            "channel"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoCameraFocusMode;->value()I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCameraFocusModeJni(II)I

    const/4 v1, 0x7

    const/4 v0, 0x4

    return-void
.end method

.method public setCameraFocusPointInPreview(FFLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "x",
            "y",
            "channel"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCameraFocusPointInPreviewJni(FFI)I

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public setCameraZoomFactor(F)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "factor"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setCameraZoomFactor(FLim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public setCameraZoomFactor(FLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "factor",
            "channel"
        }
    .end annotation

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCameraZoomFactorJni(FI)I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public setCapturePipelineScaleMode(Lim/zego/zegoexpress/constants/ZegoCapturePipelineScaleMode;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mode"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoCapturePipelineScaleMode;->value()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCapturePipelineScaleModeJni(I)I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public setCaptureVolume(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "volume"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCaptureVolumeJni(I)I

    const/4 v0, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public setCustomAudioProcessHandler(Lim/zego/zegoexpress/callback/IZegoCustomAudioProcessHandler;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "handler"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    sput-object p1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->iZegoCustomAudioProcessHandler:Lim/zego/zegoexpress/callback/IZegoCustomAudioProcessHandler;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public setCustomVideoCaptureDeviceState(ZLim/zego/zegoexpress/constants/ZegoRemoteDeviceState;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "isEnable",
            "state",
            "channel"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoRemoteDeviceState;->value()I

    move-result p2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCustomVideoCaptureDeviceStateJni(ZII)I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public setCustomVideoCaptureFillMode(Lim/zego/zegoexpress/constants/ZegoViewMode;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mode"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setCustomVideoCaptureFillMode(Lim/zego/zegoexpress/constants/ZegoViewMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public setCustomVideoCaptureFillMode(Lim/zego/zegoexpress/constants/ZegoViewMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mode",
            "channel"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoViewMode;->value()I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCustomVideoCaptureFillModeJni(II)I

    const/4 v1, 0x4

    const/4 v0, 0x5

    return-void
.end method

.method public setCustomVideoCaptureFlipMode(Lim/zego/zegoexpress/constants/ZegoVideoFlipMode;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mode"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setCustomVideoCaptureFlipMode(Lim/zego/zegoexpress/constants/ZegoVideoFlipMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public setCustomVideoCaptureFlipMode(Lim/zego/zegoexpress/constants/ZegoVideoFlipMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mode",
            "channel"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoVideoFlipMode;->value()I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCustomVideoCaptureFlipModeJni(II)I

    const/4 v0, 0x1

    shl-int/2addr v1, v0

    return-void
.end method

.method public setCustomVideoCaptureHandler(Lim/zego/zegoexpress/callback/IZegoCustomVideoCaptureHandler;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "handler"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    sput-object p1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mCustomVideoCaptureHandler:Ljava/lang/Object;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public setCustomVideoCaptureRegionOfInterest(Ljava/util/ArrayList;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "rectList",
            "channel"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lim/zego/zegoexpress/entity/ZegoRoiRect;",
            ">;",
            "Lim/zego/zegoexpress/constants/ZegoPublishChannel;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    new-instance p1, Ljava/util/ArrayList;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    :cond_0
    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    new-array v0, v0, [Lim/zego/zegoexpress/entity/ZegoRoiRect;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    check-cast p1, [Lim/zego/zegoexpress/entity/ZegoRoiRect;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCustomVideoCaptureRegionOfInterestJni([Lim/zego/zegoexpress/entity/ZegoRoiRect;I)I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public setCustomVideoCaptureRotation(ILim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "rotation",
            "channel"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCustomVideoCaptureRotationJni(II)I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public setCustomVideoCaptureTransformMatrix([FLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "matrix",
            "channel"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x0

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setCustomVideoCaptureTransformMatrixJni([FI)I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public setCustomVideoProcessHandler(Lim/zego/zegoexpress/callback/IZegoCustomVideoProcessHandler;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "handler"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    sput-object p1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mCustomVideoProcessHandler:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public setCustomVideoRenderHandler(Lim/zego/zegoexpress/callback/IZegoCustomVideoRenderHandler;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "handler"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    sput-object p1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mCustomVideoRenderHandler:Ljava/lang/Object;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public setDataRecordEventHandler(Lim/zego/zegoexpress/callback/IZegoDataRecordEventHandler;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "handler"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    sput-object p1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->iZegoDataRecordEventHandler:Lim/zego/zegoexpress/callback/IZegoDataRecordEventHandler;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public setDummyCaptureImagePath(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "filePath",
            "channel"
        }
    .end annotation

    const/4 v0, 0x7

    move v1, v0

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setDummyCaptureImagePathJni(Ljava/lang/String;I)V

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method

.method public setEffectsBeautyParam(Lim/zego/zegoexpress/entity/ZegoEffectsBeautyParam;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "param"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setEffectsBeautyParamJni(Lim/zego/zegoexpress/entity/ZegoEffectsBeautyParam;)I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public setElectronicEffects(ZLim/zego/zegoexpress/constants/ZegoElectronicEffectsMode;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "enable",
            "mode",
            "tonal"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoElectronicEffectsMode;->value()I

    move-result p2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setElectronicEffectsJni(ZII)I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public setEventHandler(Lim/zego/zegoexpress/callback/IZegoEventHandler;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "handler"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x2

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->engine:Lim/zego/zegoexpress/ZegoExpressEngine;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    and-int/2addr v3, v2

    const-string p1, "EesnnrdpetHvate"

    const/4 v3, 0x6

    const-string/jumbo p1, "ntdtEeenqearlvs"

    const-string/jumbo p1, "setEventHandler"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    const v1, 0xf4248

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p1, v1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->handleApiCalledResult(Ljava/lang/String;I)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    sput-object p1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    throw p1
.end method

.method public setHeadphoneMonitorVolume(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "volume"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setHeadphoneMonitorVolumeJni(I)I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public setLowlightEnhancement(Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mode",
            "channel"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoLowlightEnhancementMode;->value()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setLowlightEnhancementJni(II)I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public setMinVideoBitrateForTrafficControl(ILim/zego/zegoexpress/constants/ZegoTrafficControlMinVideoBitrateMode;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "bitrate",
            "mode"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setMinVideoBitrateForTrafficControl(ILim/zego/zegoexpress/constants/ZegoTrafficControlMinVideoBitrateMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method public setMinVideoBitrateForTrafficControl(ILim/zego/zegoexpress/constants/ZegoTrafficControlMinVideoBitrateMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "bitrate",
            "mode",
            "channel"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoTrafficControlMinVideoBitrateMode;->value()I

    move-result p2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setMinVideoBitrateForTrafficControlJni(III)I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public setMinVideoFpsForTrafficControl(ILim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fps",
            "channel"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setMinVideoFpsForTrafficControlJni(II)I

    const/4 v1, 0x2

    const/4 v0, 0x3

    return-void
.end method

.method public setMinVideoResolutionForTrafficControl(IILim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "width",
            "height",
            "channel"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setMinVideoResolutionForTrafficControlJni(III)I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public setPlayStreamBufferIntervalRange(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "streamID",
            "minBufferInterval",
            "maxBufferInterval"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setPlayStreamBufferIntervalRangeJni(Ljava/lang/String;II)I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public setPlayStreamCrossAppInfo(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoCrossAppInfo;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "info"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-wide v0, p2, Lim/zego/zegoexpress/entity/ZegoCrossAppInfo;->appID:J

    const/4 v3, 0x5

    const/4 v2, 0x7

    iget-object p2, p2, Lim/zego/zegoexpress/entity/ZegoCrossAppInfo;->token:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p1, v0, v1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setPlayStreamCrossAppInfoJni(Ljava/lang/String;JLjava/lang/String;)I

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method public setPlayStreamDecryptionKey(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "key"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setPlayStreamDecryptionKeyJni(Ljava/lang/String;Ljava/lang/String;)I

    const/4 v1, 0x2

    return-void
.end method

.method public setPlayStreamFocusOn(Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "streamID"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setPlayStreamFocusOnJni(Ljava/lang/String;)I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public setPlayStreamVideoType(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoVideoStreamType;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "streamType"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoVideoStreamType;->value()I

    move-result p2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setPlayStreamVideoTypeJni(Ljava/lang/String;I)I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public setPlayStreamsAlignmentProperty(Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mode"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoStreamAlignmentMode;->value()I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setPlayStreamsAlignmentPropertyJni(I)I

    const/4 v1, 0x5

    return-void
.end method

.method public setPlayVolume(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "volume"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setPlayVolumeJni(Ljava/lang/String;I)I

    const/4 v0, 0x7

    move v1, v0

    return-void
.end method

.method public setPublishDualStreamConfig(Ljava/util/ArrayList;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "configList",
            "channel"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lim/zego/zegoexpress/entity/ZegoPublishDualStreamConfig;",
            ">;",
            "Lim/zego/zegoexpress/constants/ZegoPublishChannel;",
            ")V"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance p1, Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    :cond_0
    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-array v0, v0, [Lim/zego/zegoexpress/entity/ZegoPublishDualStreamConfig;

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    check-cast p1, [Lim/zego/zegoexpress/entity/ZegoPublishDualStreamConfig;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setPublishDualStreamConfigJni([Lim/zego/zegoexpress/entity/ZegoPublishDualStreamConfig;I)I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public setPublishStreamEncryptionKey(Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "key"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setPublishStreamEncryptionKey(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public setPublishStreamEncryptionKey(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "key",
            "channel"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setPublishStreamEncryptionKeyJni(Ljava/lang/String;I)I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public setPublishWatermark(Lim/zego/zegoexpress/entity/ZegoWatermark;Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "watermark",
            "isPreviewVisible"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setPublishWatermark(Lim/zego/zegoexpress/entity/ZegoWatermark;ZLim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public setPublishWatermark(Lim/zego/zegoexpress/entity/ZegoWatermark;ZLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "watermark",
            "isPreviewVisible",
            "channel"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setPublishWatermarkJni(Lim/zego/zegoexpress/entity/ZegoWatermark;ZI)I

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public setReverbAdvancedParam(Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;)V
    .locals 12
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "param"
        }
    .end annotation

    const/4 v11, 0x4

    if-eqz p1, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    iget v0, p1, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->roomSize:F

    const/4 v11, 0x4

    iget v1, p1, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->reverberance:F

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x3

    iget v2, p1, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->damping:F

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x0

    iget-boolean v3, p1, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->wetOnly:Z

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    iget v4, p1, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->wetGain:F

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    iget v5, p1, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->dryGain:F

    const/4 v11, 0x3

    iget v6, p1, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->toneLow:F

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    iget v7, p1, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->toneHigh:F

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    iget v8, p1, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->preDelay:F

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    iget v9, p1, Lim/zego/zegoexpress/entity/ZegoReverbAdvancedParam;->stereoWidth:F

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-static/range {v0 .. v9}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setReverbAdvancedParam(FFFZFFFFFF)I

    :cond_0
    const/4 v11, 0x7

    const/4 v10, 0x5

    return-void
.end method

.method public setReverbEchoParam(Lim/zego/zegoexpress/entity/ZegoReverbEchoParam;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "param"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setReverbEchoParamJni(Lim/zego/zegoexpress/entity/ZegoReverbEchoParam;)I

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x3

    return-void
.end method

.method public setReverbPreset(Lim/zego/zegoexpress/constants/ZegoReverbPreset;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "preset"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoReverbPreset;->value()I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setReverbPresetJni(I)I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public setRoomExtraInfo(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lim/zego/zegoexpress/callback/IZegoRoomSetRoomExtraInfoCallback;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0,
            0x0
        }
        names = {
            "roomID",
            "key",
            "value",
            "callback"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setRoomExtraInfoJni(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v1, 0x6

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    monitor-enter p2

    :try_start_0
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    sget-object p3, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomSetExtraInfoHandler:Ljava/util/HashMap;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p3, p1, p4}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x7

    const/4 v0, 0x1

    monitor-exit p2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    throw p1
.end method

.method public setRoomScenario(Lim/zego/zegoexpress/constants/ZegoScenario;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "scenario"
        }
    .end annotation

    const/4 v0, 0x6

    move v1, v0

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoScenario;->value()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setRoomScenario(I)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public setSEIConfig(Lim/zego/zegoexpress/entity/ZegoSEIConfig;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "config"
        }
    .end annotation

    const/4 v1, 0x7

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setSEIConfigJni(Lim/zego/zegoexpress/entity/ZegoSEIConfig;)I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public setStreamAlignmentProperty(ILim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "alignment",
            "channel"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x7

    const/4 v0, 0x4

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setStreamAlignmentPropertyJni(II)I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public setStreamExtraInfo(Ljava/lang/String;Lim/zego/zegoexpress/callback/IZegoPublisherSetStreamExtraInfoCallback;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "extraInfo",
            "callback"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setStreamExtraInfo(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoPublishChannel;Lim/zego/zegoexpress/callback/IZegoPublisherSetStreamExtraInfoCallback;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public setStreamExtraInfo(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoPublishChannel;Lim/zego/zegoexpress/callback/IZegoPublisherSetStreamExtraInfoCallback;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "extraInfo",
            "channel",
            "handler"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setStreamExtraInfoJni(Ljava/lang/String;I)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v2, 0x0

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class p2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    monitor-enter p2

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPublisherUpdateStreamExtraInfoHandler:Ljava/util/HashMap;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    monitor-exit p2

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    monitor-exit p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    throw p1
.end method

.method public setTrafficControlFocusOn(Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mode"
        }
    .end annotation

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setTrafficControlFocusOn(Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public setTrafficControlFocusOn(Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mode",
            "channel"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoTrafficControlFocusOnMode;->value()I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setTrafficControlFocusOnJni(II)I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public setVideoConfig(Lim/zego/zegoexpress/entity/ZegoVideoConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "config"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setVideoConfig(Lim/zego/zegoexpress/entity/ZegoVideoConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public setVideoConfig(Lim/zego/zegoexpress/entity/ZegoVideoConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "videoConfig",
            "channel"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    iget-object v1, p1, Lim/zego/zegoexpress/entity/ZegoVideoConfig;->codecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v3, 0x6

    const/4 v2, 0x7

    if-eqz v1, :cond_0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setVideoConfigJni(Lim/zego/zegoexpress/entity/ZegoVideoConfig;II)I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method public setVideoMirrorMode(Lim/zego/zegoexpress/constants/ZegoVideoMirrorMode;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "mirrorMode"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setVideoMirrorMode(Lim/zego/zegoexpress/constants/ZegoVideoMirrorMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public setVideoMirrorMode(Lim/zego/zegoexpress/constants/ZegoVideoMirrorMode;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "mirrorMode",
            "channel"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    if-nez p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoVideoMirrorMode;->ONLY_PREVIEW_MIRROR:Lim/zego/zegoexpress/constants/ZegoVideoMirrorMode;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoVideoMirrorMode;->value()I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->ZegoVideoMirrorModeJni(II)I

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x5

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoVideoMirrorMode;->value()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->ZegoVideoMirrorModeJni(II)I

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public setVideoSource(Lim/zego/zegoexpress/constants/ZegoVideoSourceType;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "source"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setVideoSource(Lim/zego/zegoexpress/constants/ZegoVideoSourceType;I)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return p1
.end method

.method public setVideoSource(Lim/zego/zegoexpress/constants/ZegoVideoSourceType;I)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "source",
            "instanceID"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setVideoSource(Lim/zego/zegoexpress/constants/ZegoVideoSourceType;ILim/zego/zegoexpress/constants/ZegoPublishChannel;)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return p1
.end method

.method public setVideoSource(Lim/zego/zegoexpress/constants/ZegoVideoSourceType;ILim/zego/zegoexpress/constants/ZegoPublishChannel;)I
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "source",
            "instanceID",
            "channel"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoVideoSourceType;->value()I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setVideoSourceJni(III)I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p1
.end method

.method public setVideoSource(Lim/zego/zegoexpress/constants/ZegoVideoSourceType;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "source",
            "channel"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p1, v0, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->setVideoSource(Lim/zego/zegoexpress/constants/ZegoVideoSourceType;ILim/zego/zegoexpress/constants/ZegoPublishChannel;)I

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    return p1
.end method

.method public setVoiceChangerParam(Lim/zego/zegoexpress/entity/ZegoVoiceChangerParam;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "param"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget p1, p1, Lim/zego/zegoexpress/entity/ZegoVoiceChangerParam;->pitch:F

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setVoiceChangerParamJni(F)I

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public setVoiceChangerPreset(Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "preset"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoVoiceChangerPreset;->value()I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->setVoiceChangerPresetJni(I)I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public startAudioDataObserver(ILim/zego/zegoexpress/entity/ZegoAudioFrameParam;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "observerBitMask",
            "param"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x5

    if-nez p2, :cond_0

    const/4 v2, 0x2

    new-instance p2, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    const/4 v2, 0x2

    invoke-direct {p2}, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;-><init>()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p2, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    iget-object p2, p2, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value()I

    move-result p2

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-static {p1, v0, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startAudioDataObserver(III)I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public startAudioSpectrumMonitor()V
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    const/16 v0, 0x64

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->startAudioSpectrumMonitor(I)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public startAudioSpectrumMonitor(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "timeInMS"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startFrequencySpectrumMonitorJni(I)I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public startAudioVADStableStateMonitor(Lim/zego/zegoexpress/constants/ZegoAudioVADStableStateMonitorType;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "type"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoAudioVADStableStateMonitorType;->value()I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/16 v0, 0xbb8

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startAudioVADStableStateMonitorJni(II)I

    const/4 v2, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public startAudioVADStableStateMonitor(Lim/zego/zegoexpress/constants/ZegoAudioVADStableStateMonitorType;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "type",
            "millisecond"
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoAudioVADStableStateMonitorType;->value()I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startAudioVADStableStateMonitorJni(II)I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public startAutoMixerTask(Lim/zego/zegoexpress/entity/ZegoAutoMixerTask;Lim/zego/zegoexpress/callback/IZegoMixerStartCallback;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "task",
            "handler"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startOrStopAutoMixerJni(Lim/zego/zegoexpress/entity/ZegoAutoMixerTask;Z)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x1

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sMixerStartResultHandler:Ljava/util/HashMap;

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v1, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    throw p1
.end method

.method public startDumpData(Lim/zego/zegoexpress/entity/ZegoDumpDataConfig;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "config"
        }
    .end annotation

    const/4 v1, 0x1

    iget-object p1, p1, Lim/zego/zegoexpress/entity/ZegoDumpDataConfig;->dataType:Lim/zego/zegoexpress/constants/ZegoDumpDataType;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoDumpDataType;->value()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startDumpDataJni(I)I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public startEffectsEnv()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startEffectsEnvJni()I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public startMixerTask(Lim/zego/zegoexpress/entity/ZegoMixerTask;Lim/zego/zegoexpress/callback/IZegoMixerStartCallback;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "task",
            "handler"
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v1, p1, Lim/zego/zegoexpress/entity/ZegoMixerTask;->outputList:Ljava/util/ArrayList;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-ge v0, v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-instance v1, Lim/zego/zegoexpress/entity/ZegoMixerOutput;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v2, p1, Lim/zego/zegoexpress/entity/ZegoMixerTask;->outputList:Ljava/util/ArrayList;

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    check-cast v2, Lim/zego/zegoexpress/entity/ZegoMixerOutput;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v2, v2, Lim/zego/zegoexpress/entity/ZegoMixerOutput;->target:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x3

    invoke-direct {v1, v2}, Lim/zego/zegoexpress/entity/ZegoMixerOutput;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    iget-object v2, p1, Lim/zego/zegoexpress/entity/ZegoMixerTask;->outputList:Ljava/util/ArrayList;

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    check-cast v2, Lim/zego/zegoexpress/entity/ZegoMixerOutput;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v2, v2, Lim/zego/zegoexpress/entity/ZegoMixerOutput;->videoConfig:Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget v2, v2, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->bitrate:I

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v3, v1, Lim/zego/zegoexpress/entity/ZegoMixerOutput;->videoConfig:Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget v4, v3, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->bitrate:I

    const/4 v6, 0x3

    if-ne v2, v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v2, p1, Lim/zego/zegoexpress/entity/ZegoMixerTask;->videoConfig:Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;

    const/4 v5, 0x1

    shl-int/2addr v6, v5

    iget v2, v2, Lim/zego/zegoexpress/entity/ZegoMixerVideoConfig;->bitrate:I

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    iput v2, v3, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->bitrate:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v2, p1, Lim/zego/zegoexpress/entity/ZegoMixerTask;->outputList:Ljava/util/ArrayList;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v2, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    check-cast v2, Lim/zego/zegoexpress/entity/ZegoMixerOutput;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v2, v2, Lim/zego/zegoexpress/entity/ZegoMixerOutput;->videoConfig:Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v2, v2, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->videoCodecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    iput-object v2, v3, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->videoCodecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    const/4 v6, 0x0

    iget-object v2, v1, Lim/zego/zegoexpress/entity/ZegoMixerOutput;->videoConfig:Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;

    const/4 v6, 0x6

    const/4 v5, 0x4

    iget-object v3, p1, Lim/zego/zegoexpress/entity/ZegoMixerTask;->outputList:Ljava/util/ArrayList;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    check-cast v3, Lim/zego/zegoexpress/entity/ZegoMixerOutput;

    const/4 v5, 0x7

    move v6, v5

    iget-object v3, v3, Lim/zego/zegoexpress/entity/ZegoMixerOutput;->videoConfig:Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v3, v3, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->encodeProfile:Lim/zego/zegoexpress/constants/ZegoEncodeProfile;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    iput-object v3, v2, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->encodeProfile:Lim/zego/zegoexpress/constants/ZegoEncodeProfile;

    const/4 v6, 0x3

    iget-object v2, v1, Lim/zego/zegoexpress/entity/ZegoMixerOutput;->videoConfig:Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v3, p1, Lim/zego/zegoexpress/entity/ZegoMixerTask;->outputList:Ljava/util/ArrayList;

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-virtual {v3, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    check-cast v3, Lim/zego/zegoexpress/entity/ZegoMixerOutput;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v3, v3, Lim/zego/zegoexpress/entity/ZegoMixerOutput;->videoConfig:Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v3, v3, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->encodeLatency:I

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput v3, v2, Lim/zego/zegoexpress/entity/ZegoMixerOutputVideoConfig;->encodeLatency:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v2, p1, Lim/zego/zegoexpress/entity/ZegoMixerTask;->outputList:Ljava/util/ArrayList;

    const/4 v6, 0x3

    invoke-virtual {v2, v0, v1}, Ljava/util/ArrayList;->set(ILjava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v5, 0x3

    const/4 v6, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startMixerJni(Lim/zego/zegoexpress/entity/ZegoMixerTask;)I

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v6, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sMixerStartResultHandler:Ljava/util/HashMap;

    const/4 v5, 0x5

    move v6, v5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v1, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    throw p1
.end method

.method public startNetworkProbe(Lim/zego/zegoexpress/entity/ZegoNetworkProbeConfig;Lim/zego/zegoexpress/callback/IZegoNetworkProbeResultCallback;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "config",
            "callback"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startNetworkProbeJni(Lim/zego/zegoexpress/entity/ZegoNetworkProbeConfig;)I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x4

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sNetworkProbeResultHandler:Ljava/util/HashMap;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v1, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    throw p1
.end method

.method public startNetworkSpeedTest(Lim/zego/zegoexpress/entity/ZegoNetworkSpeedTestConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "config"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/16 v0, 0xbb8

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->startNetworkSpeedTest(Lim/zego/zegoexpress/entity/ZegoNetworkSpeedTestConfig;I)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public startNetworkSpeedTest(Lim/zego/zegoexpress/entity/ZegoNetworkSpeedTestConfig;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "config",
            "interval"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startNetworkSpeedTest(Lim/zego/zegoexpress/entity/ZegoNetworkSpeedTestConfig;I)I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public startPerformanceMonitor(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "millisecond"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startPerformanceMonitorJni(I)I

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method

.method public startPlayingStream(Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "streamID"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->startPlayingStream(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoCanvas;Lim/zego/zegoexpress/entity/ZegoPlayerConfig;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public startPlayingStream(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoCanvas;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "canvas"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    move v1, v0

    move v1, v0

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->startPlayingStream(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoCanvas;Lim/zego/zegoexpress/entity/ZegoPlayerConfig;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public startPlayingStream(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoCanvas;Lim/zego/zegoexpress/entity/ZegoPlayerConfig;)V
    .locals 15
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "streamID",
            "canvas",
            "config"
        }
    .end annotation

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v1, p3

    move-object/from16 v1, p3

    if-eqz v1, :cond_0

    iget-object v2, v1, Lim/zego/zegoexpress/entity/ZegoPlayerConfig;->cdnConfig:Lim/zego/zegoexpress/entity/ZegoCDNConfig;

    if-eqz v2, :cond_0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    :goto_0
    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    sget-object v2, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    if-eqz v1, :cond_1

    iget-object v3, v1, Lim/zego/zegoexpress/entity/ZegoPlayerConfig;->resourceMode:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    if-eqz v3, :cond_1

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    :cond_1
    sget-object v3, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->UNKNOWN:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    if-eqz v1, :cond_2

    iget-object v4, v1, Lim/zego/zegoexpress/entity/ZegoPlayerConfig;->videoCodecID:Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    if-eqz v4, :cond_2

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    :cond_2
    sget-object v4, Lim/zego/zegoexpress/constants/ZegoResourceType;->RTC:Lim/zego/zegoexpress/constants/ZegoResourceType;

    if-eqz v1, :cond_3

    iget-object v5, v1, Lim/zego/zegoexpress/entity/ZegoPlayerConfig;->sourceResourceType:Lim/zego/zegoexpress/constants/ZegoResourceType;

    if-eqz v5, :cond_3

    move-object v4, v5

    move-object v4, v5

    move-object v4, v5

    move-object v4, v5

    :cond_3
    if-eqz v1, :cond_4

    iget v5, v1, Lim/zego/zegoexpress/entity/ZegoPlayerConfig;->codecTemplateID:I

    goto :goto_1

    :cond_4
    const/4 v5, 0x0

    :goto_1
    move v12, v5

    move v12, v5

    move v12, v5

    sget-object v5, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    if-eqz v1, :cond_5

    iget-object v6, v1, Lim/zego/zegoexpress/entity/ZegoPlayerConfig;->resourceSwitchMode:Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;

    if-eqz v6, :cond_5

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    :cond_5
    const-string v6, ""

    const-string v6, ""

    const-string v6, ""

    const-string v6, ""

    if-nez v0, :cond_7

    const/4 v0, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v2}, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->value()I

    move-result v2

    if-eqz v1, :cond_6

    iget-object v1, v1, Lim/zego/zegoexpress/entity/ZegoPlayerConfig;->roomID:Ljava/lang/String;

    goto :goto_2

    :cond_6
    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    :goto_2
    invoke-virtual {v3}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value()I

    move-result v10

    invoke-virtual {v4}, Lim/zego/zegoexpress/constants/ZegoResourceType;->value()I

    move-result v11

    const/4 v13, 0x0

    invoke-virtual {v5}, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->value()I

    move-result v14

    move-object/from16 v3, p1

    move-object/from16 v3, p1

    move-object/from16 v3, p1

    move-object/from16 v3, p1

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move v5, v8

    move v5, v8

    move v5, v8

    move v5, v8

    move v6, v9

    move v6, v9

    move v6, v9

    move v6, v9

    move v8, v2

    move v8, v2

    move v8, v2

    move v8, v2

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    invoke-static/range {v3 .. v14}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startPlayingStreamJni(Ljava/lang/String;Ljava/lang/Object;IILim/zego/zegoexpress/entity/ZegoCDNConfig;ILjava/lang/String;IIIZI)I

    goto :goto_4

    :cond_7
    iget-object v8, v0, Lim/zego/zegoexpress/entity/ZegoCanvas;->view:Ljava/lang/Object;

    iget-object v9, v0, Lim/zego/zegoexpress/entity/ZegoCanvas;->viewMode:Lim/zego/zegoexpress/constants/ZegoViewMode;

    if-nez v9, :cond_8

    sget-object v9, Lim/zego/zegoexpress/constants/ZegoViewMode;->ASPECT_FIT:Lim/zego/zegoexpress/constants/ZegoViewMode;

    :cond_8
    invoke-virtual {v9}, Lim/zego/zegoexpress/constants/ZegoViewMode;->value()I

    move-result v9

    iget v10, v0, Lim/zego/zegoexpress/entity/ZegoCanvas;->backgroundColor:I

    invoke-virtual {v2}, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->value()I

    move-result v2

    if-eqz v1, :cond_9

    iget-object v1, v1, Lim/zego/zegoexpress/entity/ZegoPlayerConfig;->roomID:Ljava/lang/String;

    goto :goto_3

    :cond_9
    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    move-object v1, v6

    :goto_3
    invoke-virtual {v3}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->value()I

    move-result v11

    invoke-virtual {v4}, Lim/zego/zegoexpress/constants/ZegoResourceType;->value()I

    move-result v13

    iget-boolean v0, v0, Lim/zego/zegoexpress/entity/ZegoCanvas;->alphaBlend:Z

    invoke-virtual {v5}, Lim/zego/zegoexpress/constants/ZegoStreamResourceSwitchMode;->value()I

    move-result v14

    move-object/from16 v3, p1

    move-object/from16 v3, p1

    move-object/from16 v3, p1

    move-object/from16 v3, p1

    move-object v4, v8

    move-object v4, v8

    move-object v4, v8

    move-object v4, v8

    move v5, v9

    move v5, v9

    move v5, v9

    move v6, v10

    move v6, v10

    move v6, v10

    move v6, v10

    move v8, v2

    move v8, v2

    move v8, v2

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move v10, v11

    move v10, v11

    move v10, v11

    move v10, v11

    move v11, v13

    move v11, v13

    move v13, v0

    move v13, v0

    move v13, v0

    move v13, v0

    invoke-static/range {v3 .. v14}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startPlayingStreamJni(Ljava/lang/String;Ljava/lang/Object;IILim/zego/zegoexpress/entity/ZegoCDNConfig;ILjava/lang/String;IIIZI)I

    :goto_4
    return-void
.end method

.method public startPlayingStream(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoPlayerConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "config"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->startPlayingStream(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoCanvas;Lim/zego/zegoexpress/entity/ZegoPlayerConfig;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public startPlayingStreamInScene(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoCanvas;Lim/zego/zegoexpress/entity/ZegoScenePlayerConfig;)V
    .locals 12
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "streamID",
            "canvas",
            "config"
        }
    .end annotation

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x5

    if-eqz p3, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    iget-object v1, p3, Lim/zego/zegoexpress/entity/ZegoScenePlayerConfig;->resourceMode:Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-eqz v1, :cond_0

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    :cond_0
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    if-eqz p3, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    iget-object v1, p3, Lim/zego/zegoexpress/entity/ZegoScenePlayerConfig;->cdnConfig:Lim/zego/zegoexpress/entity/ZegoCDNConfig;

    const/4 v10, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    if-eqz v1, :cond_1

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x2

    goto :goto_0

    :cond_1
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x6

    const/4 v1, 0x0

    :goto_0
    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    move-object v9, v1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    const/4 v1, -0x1

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-nez p2, :cond_3

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    const/4 v3, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    const/4 v4, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    const/4 v5, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    const/4 v6, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-eqz p3, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    iget p2, p3, Lim/zego/zegoexpress/entity/ZegoScenePlayerConfig;->rangeSceneHandle:I

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    move v7, p2

    move v7, p2

    const/4 v11, 0x1

    move v7, p2

    move v7, p2

    const/4 v11, 0x5

    goto :goto_1

    :cond_2
    const/4 v11, 0x6

    move v7, v1

    move v7, v1

    const/4 v11, 0x4

    move v7, v1

    move v7, v1

    :goto_1
    const/4 v10, 0x6

    move v11, v10

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->value()I

    move-result v8

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-static/range {v2 .. v9}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startPlayingStreamInSceneJni(Ljava/lang/String;Ljava/lang/Object;IIZIILim/zego/zegoexpress/entity/ZegoCDNConfig;)I

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    goto :goto_3

    :cond_3
    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    iget-object v3, p2, Lim/zego/zegoexpress/entity/ZegoCanvas;->view:Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    iget-object v2, p2, Lim/zego/zegoexpress/entity/ZegoCanvas;->viewMode:Lim/zego/zegoexpress/constants/ZegoViewMode;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    if-nez v2, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    sget-object v2, Lim/zego/zegoexpress/constants/ZegoViewMode;->ASPECT_FIT:Lim/zego/zegoexpress/constants/ZegoViewMode;

    :cond_4
    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {v2}, Lim/zego/zegoexpress/constants/ZegoViewMode;->value()I

    move-result v2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x7

    move v4, v2

    const/4 v11, 0x0

    move v4, v2

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    iget v5, p2, Lim/zego/zegoexpress/entity/ZegoCanvas;->backgroundColor:I

    const/4 v11, 0x0

    iget-boolean v6, p2, Lim/zego/zegoexpress/entity/ZegoCanvas;->alphaBlend:Z

    const/4 v11, 0x5

    const/4 v10, 0x5

    if-eqz p3, :cond_5

    const/4 v11, 0x4

    iget p2, p3, Lim/zego/zegoexpress/entity/ZegoScenePlayerConfig;->rangeSceneHandle:I

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    move v7, p2

    move v7, p2

    const/4 v11, 0x1

    move v7, p2

    move v7, p2

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x1

    goto :goto_2

    :cond_5
    const/4 v11, 0x4

    move v7, v1

    move v7, v1

    const/4 v11, 0x3

    move v7, v1

    move v7, v1

    :goto_2
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoStreamResourceMode;->value()I

    move-result v8

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-static/range {v2 .. v9}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startPlayingStreamInSceneJni(Ljava/lang/String;Ljava/lang/Object;IIZIILim/zego/zegoexpress/entity/ZegoCDNConfig;)I

    :goto_3
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x7

    return-void
.end method

.method public startPlayingStreamInScene(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoScenePlayerConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "config"
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->startPlayingStreamInScene(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoCanvas;Lim/zego/zegoexpress/entity/ZegoScenePlayerConfig;)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public startPreview()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v1, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->startPreview(Lim/zego/zegoexpress/entity/ZegoCanvas;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method public startPreview(Lim/zego/zegoexpress/entity/ZegoCanvas;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "canvas"
        }
    .end annotation

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->startPreview(Lim/zego/zegoexpress/entity/ZegoCanvas;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public startPreview(Lim/zego/zegoexpress/entity/ZegoCanvas;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "canvas",
            "channel"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-nez p1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoViewMode;->ASPECT_FILL:Lim/zego/zegoexpress/constants/ZegoViewMode;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoViewMode;->value()I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x6

    invoke-static {v0, p1, v1, p2, v1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startPreviewJni(Ljava/lang/Object;IIIZ)I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v0, p1, Lim/zego/zegoexpress/entity/ZegoCanvas;->viewMode:Lim/zego/zegoexpress/constants/ZegoViewMode;

    const/4 v4, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x3

    move v4, v3

    iget-object v0, p1, Lim/zego/zegoexpress/entity/ZegoCanvas;->view:Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object v1, Lim/zego/zegoexpress/constants/ZegoViewMode;->ASPECT_FILL:Lim/zego/zegoexpress/constants/ZegoViewMode;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1}, Lim/zego/zegoexpress/constants/ZegoViewMode;->value()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v2, p1, Lim/zego/zegoexpress/entity/ZegoCanvas;->backgroundColor:I

    const/4 v4, 0x0

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-boolean p1, p1, Lim/zego/zegoexpress/entity/ZegoCanvas;->alphaBlend:Z

    const/4 v4, 0x7

    invoke-static {v0, v1, v2, p2, p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startPreviewJni(Ljava/lang/Object;IIIZ)I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v1, p1, Lim/zego/zegoexpress/entity/ZegoCanvas;->view:Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoViewMode;->value()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget v2, p1, Lim/zego/zegoexpress/entity/ZegoCanvas;->backgroundColor:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-boolean p1, p1, Lim/zego/zegoexpress/entity/ZegoCanvas;->alphaBlend:Z

    const/4 v4, 0x6

    const/4 v3, 0x7

    invoke-static {v1, v0, v2, p2, p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startPreviewJni(Ljava/lang/Object;IIIZ)I

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void
.end method

.method public startPublishingStream(Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "streamID"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->startPublishingStream(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public startPublishingStream(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "channel"
        }
    .end annotation

    const/4 v1, 0x5

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startPublishingStreamJni(Ljava/lang/String;I)I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public startPublishingStream(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoPublisherConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "streamID",
            "config",
            "channel"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p3

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p1, p3, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startPublishingStreamWithConfigJni(Ljava/lang/String;ILim/zego/zegoexpress/entity/ZegoPublisherConfig;)I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public startPublishingStreamInScene(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoPublishChannel;Lim/zego/zegoexpress/entity/ZegoScenePublisherConfig;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "streamID",
            "channel",
            "config"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startPublishingStreamInScene(Ljava/lang/String;ILim/zego/zegoexpress/entity/ZegoScenePublisherConfig;)I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public startRecordingCapturedData(Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "config",
            "channel"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance p1, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p1}, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;-><init>()V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    iget-object v0, p1, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;->recordType:Lim/zego/zegoexpress/constants/ZegoDataRecordType;

    const/4 v1, 0x7

    move v2, v1

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoDataRecordType;->DEFAULT:Lim/zego/zegoexpress/constants/ZegoDataRecordType;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object v0, p1, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;->recordType:Lim/zego/zegoexpress/constants/ZegoDataRecordType;

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p1, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;->filePath:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object p1, p1, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;->recordType:Lim/zego/zegoexpress/constants/ZegoDataRecordType;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoDataRecordType;->value()I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz p2, :cond_2

    const/4 v2, 0x6

    const/4 v1, 0x7

    goto :goto_0

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object p2, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0, p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startRecordingCapturedDataJni(Ljava/lang/String;II)I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public startScreenCapture()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {v0}, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->startScreenCapture(Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public startScreenCapture(Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;)V
    .locals 14
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "config"
        }
    .end annotation

    const/4 v13, 0x1

    const-class v0, Ljava/lang/Integer;

    const-class v0, Ljava/lang/Integer;

    const-class v0, Ljava/lang/Integer;

    const-class v0, Ljava/lang/Integer;

    const/4 v13, 0x2

    const-class v1, Ljava/lang/Boolean;

    const-class v1, Ljava/lang/Boolean;

    const-class v1, Ljava/lang/Boolean;

    const-class v1, Ljava/lang/Boolean;

    const/4 v13, 0x6

    const-string/jumbo v2, "pCstarernrsctqSeet"

    const-string v2, "ctrnsuteqreSaCeprt"

    const-string v2, "anemtetreapturScrC"

    const-string/jumbo v2, "startScreenCapture"

    const/4 v13, 0x4

    const/4 v3, 0x4

    const/4 v13, 0x6

    new-array v4, v3, [Ljava/lang/Object;

    const/4 v13, 0x7

    iget-boolean v5, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->captureVideo:Z

    const/4 v13, 0x0

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    const/4 v13, 0x7

    const/4 v6, 0x0

    const/4 v13, 0x1

    aput-object v5, v4, v6

    const/4 v13, 0x4

    iget-boolean v5, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->captureAudio:Z

    const/4 v13, 0x4

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    const/4 v13, 0x2

    const/4 v7, 0x1

    const/4 v13, 0x2

    aput-object v5, v4, v7

    const/4 v13, 0x3

    iget-object v5, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->audioParam:Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    const/4 v13, 0x1

    iget-object v8, v5, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v13, 0x4

    const/4 v9, 0x2

    const/4 v13, 0x6

    aput-object v8, v4, v9

    const/4 v13, 0x5

    iget-object v5, v5, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v8, 0x3

    and-int/2addr v13, v8

    aput-object v5, v4, v8

    const/4 v13, 0x1

    const-string/jumbo v5, "ueesoep%rt:ane criVehsln%iColeesrstars, cptS,t%:so admpe duuptt_r:A,a%ucaenac:sra"

    const-string/jumbo v5, "has.rierA,sptssantearap: ecuuip:%dn:ucarmeCods sa, %alrtte :ucelce,tStos_%rpV%nee"

    const-string v5, "a%rribo:tnenAuopu_tsa:easstdep,uahsreltra cae tr ,ts,:mrasl%udcVsC:.pec%ecee%pni "

    const-string/jumbo v5, "startScreenCapture. captureVideo:%s, captureAudio:%s, sample_rate:%s, channels:%s"

    invoke-static {v5, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const/4 v13, 0x2

    const-string/jumbo v5, "upcnseurrtaee"

    const-string/jumbo v5, "stamerrpcneue"

    const-string/jumbo v5, "unesrpaprectc"

    const-string/jumbo v5, "screencapture"

    invoke-static {v4, v5}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->logNotice(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v13, 0x3

    const-string/jumbo v4, "nr.pCrn.qeorpegnZreguccaieSeMmeianuaoetarzetasrecgl..eo"

    const-string/jumbo v4, "ugeeogrtnmiZorteeSCaee.lecaraeps.azenMranoriugn.ncpecr."

    const-string/jumbo v4, "nisCeleegtn.gzeaesamceSgtnnt.courZeceaorru.pepneaMair.r"

    const-string/jumbo v4, "im.zego.internal.screencapture.ZegoScreenCaptureManager"

    const/4 v13, 0x5

    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    const/4 v13, 0x7

    const-class v5, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const-class v5, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const-class v5, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const-class v5, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v13, 0x6

    const-string v10, "EeemvdntnrbeHts"

    const-string v10, "aeeenbtrHnvsEdt"

    const-string/jumbo v10, "nrvnoetteleEdHs"

    const-string/jumbo v10, "setEventHandler"

    const/4 v13, 0x6

    new-array v11, v7, [Ljava/lang/Class;

    const/4 v13, 0x2

    aput-object v5, v11, v6

    const/4 v13, 0x3

    invoke-virtual {v4, v10, v11}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v10

    const/4 v13, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v11

    const/4 v13, 0x1

    invoke-virtual {v11}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v11

    const/4 v13, 0x1

    new-array v12, v7, [Ljava/lang/Class;

    const/4 v13, 0x6

    aput-object v5, v12, v6

    const/4 v13, 0x5

    invoke-static {v11, v12, p0}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v5

    const/4 v13, 0x6

    new-array v11, v7, [Ljava/lang/Object;

    const/4 v13, 0x0

    aput-object v5, v11, v6

    const/4 v13, 0x6

    const/4 v5, 0x0

    const/4 v13, 0x1

    invoke-virtual {v10, v5, v11}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x5

    const/4 v10, 0x5

    const/4 v13, 0x5

    new-array v11, v10, [Ljava/lang/Class;

    const/4 v13, 0x7

    const-class v12, Landroid/content/Context;

    const-class v12, Landroid/content/Context;

    const-class v12, Landroid/content/Context;

    aput-object v12, v11, v6

    const/4 v13, 0x7

    aput-object v1, v11, v7

    const/4 v13, 0x4

    aput-object v1, v11, v9

    aput-object v0, v11, v8

    const/4 v13, 0x5

    aput-object v0, v11, v3

    const/4 v13, 0x3

    invoke-virtual {v4, v2, v11}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v13, 0x1

    new-array v1, v10, [Ljava/lang/Object;

    const/4 v13, 0x0

    sget-object v4, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mContext:Landroid/content/Context;

    const/4 v13, 0x7

    aput-object v4, v1, v6

    const/4 v13, 0x1

    iget-boolean v4, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->captureVideo:Z

    const/4 v13, 0x6

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const/4 v13, 0x6

    aput-object v4, v1, v7

    const/4 v13, 0x3

    iget-boolean v4, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->captureAudio:Z

    const/4 v13, 0x0

    invoke-static {v4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v4

    const/4 v13, 0x2

    aput-object v4, v1, v9

    const/4 v13, 0x1

    iget-object v4, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->audioParam:Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    const/4 v13, 0x1

    iget-object v4, v4, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v13, 0x2

    invoke-virtual {v4}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value()I

    move-result v4

    const/4 v13, 0x3

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v13, 0x5

    aput-object v4, v1, v8

    const/4 v13, 0x7

    iget-object p1, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->audioParam:Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    iget-object p1, p1, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v13, 0x2

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value()I

    move-result p1

    const/4 v13, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v13, 0x6

    aput-object p1, v1, v3

    invoke-virtual {v0, v5, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x3

    invoke-static {v2, v6}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->handleApiCalledResult(Ljava/lang/String;I)V
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v13, 0x3

    goto :goto_0

    :catch_0
    const/4 v13, 0x3

    const p1, 0xf9062

    const/4 v13, 0x1

    invoke-static {v2, p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->handleApiCalledResult(Ljava/lang/String;I)V

    :goto_0
    const/4 v13, 0x3

    return-void
.end method

.method public startSoundLevelMonitor()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/16 v0, 0x64

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startSoundLevelMonitorJni(IZ)I

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method public startSoundLevelMonitor(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "timeInMS"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startSoundLevelMonitorJni(IZ)I

    const/4 v2, 0x2

    return-void
.end method

.method public startSoundLevelMonitor(Lim/zego/zegoexpress/entity/ZegoSoundLevelConfig;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "config"
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget v0, p1, Lim/zego/zegoexpress/entity/ZegoSoundLevelConfig;->millisecond:I

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-boolean p1, p1, Lim/zego/zegoexpress/entity/ZegoSoundLevelConfig;->enableVAD:Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startSoundLevelMonitorJni(IZ)I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public stopAudioDataObserver()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopAudioDataObserver()I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public stopAudioSpectrumMonitor()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopFrequencySpectrumMonitorJni()I

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public stopAudioVADStableStateMonitor(Lim/zego/zegoexpress/constants/ZegoAudioVADStableStateMonitorType;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "type"
        }
    .end annotation

    const/4 v1, 0x5

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoAudioVADStableStateMonitorType;->value()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopAudioVADStableStateMonitorJni(I)I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public stopAutoMixerTask(Lim/zego/zegoexpress/entity/ZegoAutoMixerTask;Lim/zego/zegoexpress/callback/IZegoMixerStopCallback;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "task",
            "handler"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->startOrStopAutoMixerJni(Lim/zego/zegoexpress/entity/ZegoAutoMixerTask;Z)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x5

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sMixerStopResultHandler:Ljava/util/HashMap;

    const/4 v2, 0x5

    and-int/2addr v3, v2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v1, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x5

    move v3, v2

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    throw p1
.end method

.method public stopDumpData()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopDumpDataJni()I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public stopEffectsEnv()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopEffectsEnvJni()I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public stopMixerTask(Lim/zego/zegoexpress/entity/ZegoMixerTask;Lim/zego/zegoexpress/callback/IZegoMixerStopCallback;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "task",
            "handler"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopMixerJni(Lim/zego/zegoexpress/entity/ZegoMixerTask;)I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x5

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sMixerStopResultHandler:Ljava/util/HashMap;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v1, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    throw p1
.end method

.method public stopNetworkProbe()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopNetworkProbeJni()I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public stopNetworkSpeedTest()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopNetworkSpeedTest()I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public stopPerformanceMonitor()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopPerformanceMonitorJni()I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public stopPlayingStream(Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "streamID"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopPlayingStreamJni(Ljava/lang/String;)I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public stopPreview()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->stopPreview(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public stopPreview(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "channel"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopPreviewJni(I)I

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public stopPublishingStream()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    invoke-virtual {p0, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->stopPublishingStream(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public stopPublishingStream(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "channel"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopPublishingStreamJni(I)I

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public stopRecordingCapturedData(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "channel"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    sget-object p1, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    :goto_0
    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopRecordingCapturedDataJni(I)I

    const/4 v1, 0x0

    const/4 v0, 0x6

    return-void
.end method

.method public stopScreenCapture()V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x5

    const-string/jumbo v0, "urcnebcstaeup"

    const-string/jumbo v0, "raercuucptens"

    const/4 v6, 0x6

    const-string/jumbo v0, "prteacusecrnu"

    const-string/jumbo v0, "screencapture"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string v1, "capetrnpspCpeeSou"

    const-string/jumbo v1, "torcCeppnSurespae"

    const/4 v6, 0x4

    const-string/jumbo v1, "opeaCrreqtncSespt"

    const-string/jumbo v1, "stopScreenCapture"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->logNotice(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string/jumbo v0, "resgcoS.Ceegtrasrtamageteoa.Mnn.reuepn.Zelerinzeuarcncp"

    const-string/jumbo v0, "im.zego.internal.screencapture.ZegoScreenCaptureManager"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {v0, v4, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v1, v2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->handleApiCalledResult(Ljava/lang/String;I)V
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_0

    :catch_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    const v0, 0xf9062

    const/4 v5, 0x1

    move v6, v5

    invoke-static {v1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->handleApiCalledResult(Ljava/lang/String;I)V

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    return-void
.end method

.method public stopSoundLevelMonitor()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->stopSoundLevelMonitorJni()I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public switchRoom(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "fromRoomID",
            "toRoomID"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0, p1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->switchRoom(Ljava/lang/String;Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoRoomConfig;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public switchRoom(Ljava/lang/String;Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoRoomConfig;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "fromRoomID",
            "toRoomID",
            "config"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x3

    invoke-static {p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->switchRoomJni(Ljava/lang/String;Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoRoomConfig;)I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public takePlayStreamSnapshot(Ljava/lang/String;Lim/zego/zegoexpress/callback/IZegoPlayerTakeSnapshotCallback;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "callback"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x2

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPlayerTakeSnapshotResultHandler:Ljava/util/HashMap;

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-virtual {v1, p1, p2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->takePlayStreamSnapshotJni(Ljava/lang/String;)I

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    throw p1
.end method

.method public takePublishStreamSnapshot(Lim/zego/zegoexpress/callback/IZegoPublisherTakeSnapshotCallback;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "callback"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->takePublishStreamSnapshot(Lim/zego/zegoexpress/callback/IZegoPublisherTakeSnapshotCallback;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public takePublishStreamSnapshot(Lim/zego/zegoexpress/callback/IZegoPublisherTakeSnapshotCallback;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "callback",
            "channel"
        }
    .end annotation

    const/4 v4, 0x1

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v4, 0x0

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPublisherTakeSnapshotResultHandler:Ljava/util/HashMap;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-virtual {v1, v2, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-static {p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->takePublishStreamSnapshotJni(I)I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    throw p1
.end method

.method public testNetworkConnectivity(Lim/zego/zegoexpress/callback/IZegoTestNetworkConnectivityCallback;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "callback"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->testNetworkConnectivityJni()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const-class v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v4, 0x1

    const-class v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    monitor-enter v1

    :try_start_0
    const/4 v4, 0x4

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sTestNetworkConnectivityHandler:Ljava/util/HashMap;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v2, v0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    monitor-exit v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    throw p1
.end method

.method public uninitVideoSuperResolution()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->uninitVideoSuperResolutionJni()I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public updatePlayingCanvas(Ljava/lang/String;Lim/zego/zegoexpress/entity/ZegoCanvas;)I
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "streamID",
            "canvas"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object p2, Lim/zego/zegoexpress/constants/ZegoViewMode;->ASPECT_FILL:Lim/zego/zegoexpress/constants/ZegoViewMode;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoViewMode;->value()I

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p1, v1, p2, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->updatePlayingCanvas(Ljava/lang/String;Ljava/lang/Object;II)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p2, Lim/zego/zegoexpress/entity/ZegoCanvas;->viewMode:Lim/zego/zegoexpress/constants/ZegoViewMode;

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p2, Lim/zego/zegoexpress/entity/ZegoCanvas;->view:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v1, Lim/zego/zegoexpress/constants/ZegoViewMode;->ASPECT_FILL:Lim/zego/zegoexpress/constants/ZegoViewMode;

    const/4 v3, 0x6

    const/4 v2, 0x5

    invoke-virtual {v1}, Lim/zego/zegoexpress/constants/ZegoViewMode;->value()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget p2, p2, Lim/zego/zegoexpress/entity/ZegoCanvas;->backgroundColor:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p1, v0, v1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->updatePlayingCanvas(Ljava/lang/String;Ljava/lang/Object;II)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    iget-object v1, p2, Lim/zego/zegoexpress/entity/ZegoCanvas;->view:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Lim/zego/zegoexpress/constants/ZegoViewMode;->value()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget p2, p2, Lim/zego/zegoexpress/entity/ZegoCanvas;->backgroundColor:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1, v1, v0, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->updatePlayingCanvas(Ljava/lang/String;Ljava/lang/Object;II)I

    move-result p1

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    return p1
.end method

.method public updateScreenCaptureConfig(Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;)V
    .locals 14
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "config"
        }
    .end annotation

    const/4 v13, 0x0

    const-class v0, Ljava/lang/Integer;

    const-class v0, Ljava/lang/Integer;

    const-class v0, Ljava/lang/Integer;

    const/4 v13, 0x2

    const-class v1, Ljava/lang/Boolean;

    const-class v1, Ljava/lang/Boolean;

    const-class v1, Ljava/lang/Boolean;

    const-class v1, Ljava/lang/Boolean;

    const/4 v13, 0x1

    const-string v2, "CrtmeqaufeeSincperoauntpg"

    const-string/jumbo v2, "tcprpndoqiSraetfueagCnuee"

    const-string v2, "ecpeorapgfCoireeuduantStC"

    const-string/jumbo v2, "updateScreenCaptureConfig"

    const/4 v13, 0x4

    const/4 v3, 0x4

    const/4 v13, 0x4

    new-array v4, v3, [Ljava/lang/Object;

    const/4 v13, 0x4

    iget-boolean v5, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->captureVideo:Z

    const/4 v13, 0x1

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    const/4 v13, 0x0

    const/4 v6, 0x0

    const/4 v13, 0x7

    aput-object v5, v4, v6

    const/4 v13, 0x4

    iget-boolean v5, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->captureAudio:Z

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    const/4 v13, 0x5

    const/4 v7, 0x1

    const/4 v13, 0x7

    aput-object v5, v4, v7

    const/4 v13, 0x0

    iget-object v5, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->audioParam:Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    const/4 v13, 0x0

    iget-object v8, v5, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v13, 0x4

    const/4 v9, 0x2

    const/4 v13, 0x3

    aput-object v8, v4, v9

    const/4 v13, 0x1

    iget-object v5, v5, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v13, 0x7

    const/4 v8, 0x3

    const/4 v13, 0x1

    aput-object v5, v4, v8

    const/4 v13, 0x4

    const-string v5, ",ai cbu%tspCs sre:aeduilS_%%remn:recdeAutacetlnp :op :eaCtncuVi.,pa%sensrhaoar,upeesftos"

    const-string v5, " _ssarercucpcaonseehduppptCutcsiA%Cl.uu%pt,taeaV,%s ntdsSn,frreoroelnesaae ::ie ::%aeimg"

    const-string v5, "ege,i%up%,se.edcc,Vss eetCspci:ta%ao aeSuafeu%pduosontplt:nrrrue:schraCapmreni_: ud Aant"

    const-string/jumbo v5, "updateScreenCaptureConfig. captureVideo:%s, captureAudio:%s, sample_rate:%s, channels:%s"

    const/4 v13, 0x4

    invoke-static {v5, v4}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const/4 v13, 0x3

    const-string/jumbo v5, "suermenpacpct"

    const-string v5, "ceemuncesprat"

    const-string v5, "crpueteeqnsrc"

    const-string/jumbo v5, "screencapture"

    const/4 v13, 0x1

    invoke-static {v4, v5}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->logNotice(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v13, 0x2

    const-string/jumbo v4, "tesralenainse.eeaura.gzSZcrrrrgtne..etceoipecneuaCogoMn"

    const-string v4, "Zcr.ograeCnoie.czneeSrM.eglmnagusntteen.croeeruaprietaa"

    const-string/jumbo v4, "ptZmnunengs.eruroletecacanSgir.M.zeaeriCaeartpeeegroc.m"

    const-string/jumbo v4, "im.zego.internal.screencapture.ZegoScreenCaptureManager"

    const/4 v13, 0x7

    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    const/4 v13, 0x1

    const-class v5, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const-class v5, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const-class v5, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const-class v5, Lim/zego/internal/screencapture/IZegoScreenCaptureErrorCallback;

    const/4 v13, 0x1

    const-string/jumbo v10, "etnsoHblandeErt"

    const-string/jumbo v10, "tEltHbrnsneevad"

    const-string/jumbo v10, "rdtHtbnlaeensve"

    const-string/jumbo v10, "setEventHandler"

    const/4 v13, 0x1

    new-array v11, v7, [Ljava/lang/Class;

    const/4 v13, 0x5

    aput-object v5, v11, v6

    const/4 v13, 0x4

    invoke-virtual {v4, v10, v11}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v10

    const/4 v13, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v11

    const/4 v13, 0x1

    invoke-virtual {v11}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v11

    const/4 v13, 0x2

    new-array v12, v7, [Ljava/lang/Class;

    const/4 v13, 0x2

    aput-object v5, v12, v6

    const/4 v13, 0x7

    invoke-static {v11, v12, p0}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v5

    const/4 v13, 0x5

    new-array v11, v7, [Ljava/lang/Object;

    const/4 v13, 0x7

    aput-object v5, v11, v6

    const/4 v13, 0x7

    const/4 v5, 0x0

    const/4 v13, 0x5

    invoke-virtual {v10, v5, v11}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x4

    new-array v10, v3, [Ljava/lang/Class;

    const/4 v13, 0x1

    aput-object v1, v10, v6

    const/4 v13, 0x7

    aput-object v1, v10, v7

    const/4 v13, 0x7

    aput-object v0, v10, v9

    const/4 v13, 0x1

    aput-object v0, v10, v8

    const/4 v13, 0x4

    invoke-virtual {v4, v2, v10}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v13, 0x3

    new-array v1, v3, [Ljava/lang/Object;

    const/4 v13, 0x3

    iget-boolean v3, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->captureVideo:Z

    const/4 v13, 0x2

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v13, 0x5

    aput-object v3, v1, v6

    const/4 v13, 0x4

    iget-boolean v3, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->captureAudio:Z

    const/4 v13, 0x7

    invoke-static {v3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v3

    const/4 v13, 0x4

    aput-object v3, v1, v7

    const/4 v13, 0x6

    iget-object v3, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->audioParam:Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    const/4 v13, 0x1

    iget-object v3, v3, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->sampleRate:Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;

    const/4 v13, 0x2

    invoke-virtual {v3}, Lim/zego/zegoexpress/constants/ZegoAudioSampleRate;->value()I

    move-result v3

    const/4 v13, 0x4

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v13, 0x0

    aput-object v3, v1, v9

    const/4 v13, 0x2

    iget-object p1, p1, Lim/zego/zegoexpress/entity/ZegoScreenCaptureConfig;->audioParam:Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;

    const/4 v13, 0x5

    iget-object p1, p1, Lim/zego/zegoexpress/entity/ZegoAudioFrameParam;->channel:Lim/zego/zegoexpress/constants/ZegoAudioChannel;

    const/4 v13, 0x1

    invoke-virtual {p1}, Lim/zego/zegoexpress/constants/ZegoAudioChannel;->value()I

    move-result p1

    const/4 v13, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v13, 0x5

    aput-object p1, v1, v8

    const/4 v13, 0x3

    invoke-virtual {v0, v5, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x6

    invoke-static {v2, v6}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->handleApiCalledResult(Ljava/lang/String;I)V
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v13, 0x3

    goto :goto_0

    :catch_0
    const/4 v13, 0x3

    const p1, 0xf9062

    invoke-static {v2, p1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->handleApiCalledResult(Ljava/lang/String;I)V

    :goto_0
    const/4 v13, 0x0

    return-void
.end method

.method public uploadDumpData()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->uploadDumpDataJni()I

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public uploadLog()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->uploadLogJni()I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public uploadLog(Lim/zego/zegoexpress/callback/IZegoUploadLogResultCallback;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "callback"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->uploadLogJni()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-class v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v4, 0x2

    const-class v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    monitor-enter v1

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sUploadLogResultHandler:Ljava/util/HashMap;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v2, v0, p1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    monitor-exit v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    throw p1
.end method

.method public useAudioDevice(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoAudioDeviceType;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "deviceID",
            "deviceType"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoAudioDeviceType;->value()I

    move-result p2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->useAudioDeviceJni(Ljava/lang/String;I)I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public useFrontCamera(Z)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "enable"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    sget-object v0, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->MAIN:Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0}, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->useFrontCamera(ZLim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public useFrontCamera(ZLim/zego/zegoexpress/constants/ZegoPublishChannel;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "enable",
            "channel"
        }
    .end annotation

    const/4 v0, 0x5

    move v1, v0

    invoke-virtual {p2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->value()I

    move-result p2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p1, p2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniAPI;->useFrontCameraJni(ZI)I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method
