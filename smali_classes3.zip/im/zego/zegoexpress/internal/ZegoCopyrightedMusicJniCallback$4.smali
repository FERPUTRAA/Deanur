.class Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$4;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback;->onSendExtendedRequestCallback(IILjava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$command:Ljava/lang/String;

.field final synthetic val$errorCode:I

.field final synthetic val$result:Ljava/lang/String;

.field final synthetic val$sendExtendedRequestCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicSendExtendedRequestCallback;


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicSendExtendedRequestCallback;ILjava/lang/String;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$sendExtendedRequestCallback",
            "val$errorCode",
            "val$command",
            "val$result"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$4;->val$sendExtendedRequestCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicSendExtendedRequestCallback;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$4;->val$errorCode:I

    const/4 v1, 0x2

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$4;->val$command:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p4, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$4;->val$result:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "K~sn~~@l~io b/@o~ 4@@ ~ @ ~/~@o@ @@sb ~@~  ~lbSc @t@~@@ ~~  ~@o-a1u~Mdi@@  foori~y~~~. @m@~ @vtf"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$4;->val$sendExtendedRequestCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicSendExtendedRequestCallback;

    const/4 v5, 0x2

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$4;->val$errorCode:I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$4;->val$command:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v3, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$4;->val$result:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-interface {v0, v1, v2, v3}, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicSendExtendedRequestCallback;->onSendExtendedRequestCallback(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void
.end method
