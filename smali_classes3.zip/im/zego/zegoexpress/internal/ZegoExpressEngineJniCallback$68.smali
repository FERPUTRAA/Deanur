.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$68;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onRoomOnlineUserCountUpdate(Ljava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$count:I

.field final synthetic val$roomID:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$roomID",
            "val$count"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$68;->val$roomID:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$68;->val$count:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "l@sii@@ @nfco@~~ b@@@ ~K @t1o~~~o@@ @Sb @~ ~~l ~~s~~~byv @  ~tu ~@@~r d@~o/@~-o /  i~of 4~@mM.a~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$68;->val$roomID:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$68;->val$count:I

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onRoomOnlineUserCountUpdate(Ljava/lang/String;I)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void
.end method
