.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$70;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onCapturedDataRecordStateUpdate(IILjava/lang/String;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$channel:I

.field final synthetic val$errorCode:I

.field final synthetic val$filePath:Ljava/lang/String;

.field final synthetic val$recordType:I

.field final synthetic val$state:I


# direct methods
.method constructor <init>(Ljava/lang/String;IIII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$filePath",
            "val$recordType",
            "val$state",
            "val$errorCode",
            "val$channel"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$70;->val$filePath:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$70;->val$recordType:I

    const/4 v1, 0x5

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$70;->val$state:I

    const/4 v0, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$70;->val$errorCode:I

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p5, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$70;->val$channel:I

    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " bs@~fK yn~~M@4~~/@ So/bo~o@@l ~~ @  ~@ ~.@ @vo~d 1s~~ @r~oi@@- t@~@~ ~i@~~ol~ @  a~mtu@c@b@ fi~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->iZegoDataRecordEventHandler:Lim/zego/zegoexpress/callback/IZegoDataRecordEventHandler;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v1, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-direct {v1}, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$70;->val$filePath:Ljava/lang/String;

    const/4 v6, 0x6

    iput-object v2, v1, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;->filePath:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$70;->val$recordType:I

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v2}, Lim/zego/zegoexpress/constants/ZegoDataRecordType;->getZegoDataRecordType(I)Lim/zego/zegoexpress/constants/ZegoDataRecordType;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    iput-object v2, v1, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;->recordType:Lim/zego/zegoexpress/constants/ZegoDataRecordType;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$70;->val$state:I

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v2}, Lim/zego/zegoexpress/constants/ZegoDataRecordState;->getZegoDataRecordState(I)Lim/zego/zegoexpress/constants/ZegoDataRecordState;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$70;->val$errorCode:I

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget v4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$70;->val$channel:I

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {v4}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->getZegoPublishChannel(I)Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v0, v2, v3, v1, v4}, Lim/zego/zegoexpress/callback/IZegoDataRecordEventHandler;->onCapturedDataRecordStateUpdate(Lim/zego/zegoexpress/constants/ZegoDataRecordState;ILim/zego/zegoexpress/entity/ZegoDataRecordConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-void
.end method
