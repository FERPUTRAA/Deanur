.class public Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;
.super Lim/zego/zegoexpress/ZegoAIVoiceChanger;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;
    }
.end annotation


# static fields
.field public static aiVoiceChangerToIndexAndHandler:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Lim/zego/zegoexpress/ZegoAIVoiceChanger;",
            "Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;",
            ">;"
        }
    .end annotation
.end field

.field public static mUIHandler:Landroid/os/Handler;


# instance fields
.field private index:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v0, Landroid/os/Handler;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    sput-object v0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->aiVoiceChangerToIndexAndHandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void
.end method

.method constructor <init>(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "index"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Lim/zego/zegoexpress/ZegoAIVoiceChanger;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->index:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public static createAIVoiceChanger()Lim/zego/zegoexpress/ZegoAIVoiceChanger;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~ ss@o ~ @~yo~@d @on~a ~-~ @/ul~rtfc@@@fi@m S@v~ @ ~ lb@b.@oi~ @t @~ i~~/K~4@~~~ @@o@~b@~1M ~~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    invoke-static {}, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniAPI;->createAIVoiceChangerJni()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    if-ltz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v1, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {v1, v0}, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;-><init>(I)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance v2, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v2, v0}, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;-><init>(I)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->aiVoiceChangerToIndexAndHandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object v0
.end method

.method public static destroyAIVoiceChanger(Lim/zego/zegoexpress/ZegoAIVoiceChanger;)V
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "aiVoiceChanger"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->aiVoiceChangerToIndexAndHandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-ne v2, p0, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    check-cast p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x5

    and-int/2addr v3, v2

    const/4 v4, 0x6

    iput-object v2, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;->eventHandler:Lim/zego/zegoexpress/callback/IZegoAIVoiceChangerEventHandler;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    check-cast p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget p0, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;->index:I

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p0}, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniAPI;->destroyAIVoiceChangerJni(I)I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method

.method public static destroyAllAIVoiceChangerInstance()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->aiVoiceChangerToIndexAndHandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput-object v3, v2, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;->eventHandler:Lim/zego/zegoexpress/callback/IZegoAIVoiceChangerEventHandler;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    check-cast v1, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget v1, v1, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;->index:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {v1}, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniAPI;->destroyAIVoiceChangerJni(I)I

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->remove()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-void
.end method


# virtual methods
.method public getIndex()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget v0, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->index:I

    const/4 v1, 0x0

    move v2, v1

    return v0
.end method

.method public getSpeakerList()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget v0, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->index:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-static {v0}, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniAPI;->getSpeakerListJni(I)I

    const/4 v2, 0x3

    return-void
.end method

.method public initEngine()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget v0, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->index:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {v0}, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniAPI;->initEngineJni(I)I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public setEventHandler(Lim/zego/zegoexpress/callback/IZegoAIVoiceChangerEventHandler;)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "handler"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->aiVoiceChangerToIndexAndHandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast v0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object p1, v0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl$IndexAndHandler;->eventHandler:Lim/zego/zegoexpress/callback/IZegoAIVoiceChangerEventHandler;

    :cond_0
    const/4 v2, 0x4

    return-void
.end method

.method public setSpeaker(I)V
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "speakerID"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->index:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniAPI;->setSpeakerJni(II)I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public update()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget v0, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerInternalImpl;->index:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {v0}, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniAPI;->updateJni(I)I

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method
