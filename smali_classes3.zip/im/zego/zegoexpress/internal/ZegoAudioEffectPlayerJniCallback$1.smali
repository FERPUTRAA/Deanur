.class Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback;->onAudioEffectPlayerPlayStateUpdate(IIII)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$audio_effect_id:I

.field final synthetic val$error_code:I

.field final synthetic val$iZegoAudioEffectPlayerEventHandler:Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerEventHandler;

.field final synthetic val$item:Ljava/util/Map$Entry;

.field final synthetic val$zegoAudioEffectPlayerState:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerEventHandler;Ljava/util/Map$Entry;ILim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$iZegoAudioEffectPlayerEventHandler",
            "val$item",
            "val$audio_effect_id",
            "val$zegoAudioEffectPlayerState",
            "val$error_code"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;->val$iZegoAudioEffectPlayerEventHandler:Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerEventHandler;

    const/4 v0, 0x4

    move v1, v0

    iput-object p2, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;->val$item:Ljava/util/Map$Entry;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;->val$audio_effect_id:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p4, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;->val$zegoAudioEffectPlayerState:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput p5, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;->val$error_code:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@@sou1 @~@ys  naivb~K@~@~~~ ~~ ~4~b@~@@~~lo @@ b.@Sf@fioM ~  @~~@d~roi-~t~   /  lc@~@  @t~o~@/m@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;->val$iZegoAudioEffectPlayerEventHandler:Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerEventHandler;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;->val$item:Ljava/util/Map$Entry;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    check-cast v1, Lim/zego/zegoexpress/ZegoAudioEffectPlayer;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;->val$audio_effect_id:I

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v3, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;->val$zegoAudioEffectPlayerState:Lim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget v4, p0, Lim/zego/zegoexpress/internal/ZegoAudioEffectPlayerJniCallback$1;->val$error_code:I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v1, v2, v3, v4}, Lim/zego/zegoexpress/callback/IZegoAudioEffectPlayerEventHandler;->onAudioEffectPlayStateUpdate(Lim/zego/zegoexpress/ZegoAudioEffectPlayer;ILim/zego/zegoexpress/constants/ZegoAudioEffectPlayState;I)V

    :cond_0
    const/4 v6, 0x6

    return-void
.end method
