.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$6;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onRoomStateUpdate(Ljava/lang/String;IILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$extendedData:Ljava/lang/String;

.field final synthetic val$roomID:Ljava/lang/String;

.field final synthetic val$state:I


# direct methods
.method constructor <init>(Ljava/lang/String;IILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$roomID",
            "val$state",
            "val$errorCode",
            "val$extendedData"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$6;->val$roomID:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$6;->val$state:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$6;->val$errorCode:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    iput-object p4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$6;->val$extendedData:Ljava/lang/String;

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~Msr~o~.~i@@ u@s~ ~ @@o l~ ~~ ~ol/d y@o~Kb i@ ~@1b@i  ~~o ftc@n@@b~@ ~~~vfSm@  -@@ @~@/ta~@4@~o~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$6;->val$roomID:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoRoomState;->values()[Lim/zego/zegoexpress/constants/ZegoRoomState;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$6;->val$state:I

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    aget-object v2, v2, v3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$6;->val$errorCode:I

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$6;->val$extendedData:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v4}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->access$000(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v2, v3, v4}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onRoomStateUpdate(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoRoomState;ILorg/json/JSONObject;)V

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    return-void
.end method
