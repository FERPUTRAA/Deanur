.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$43;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onRoomStreamExtraInfoUpdate(Ljava/lang/String;[Lim/zego/zegoexpress/entity/ZegoStream;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$roomID:Ljava/lang/String;

.field final synthetic val$streamArrayList:Ljava/util/ArrayList;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$roomID",
            "val$streamArrayList"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$43;->val$roomID:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$43;->val$streamArrayList:Ljava/util/ArrayList;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "sbs @. @ @ta/@Mr~@vd@~ i~~-@i ~K@@l~m1@@ @~~/@~c oub   yof~~4@f@ob@~i ~oo@@~~~l~  ~ ~t @~~o S~@ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v3, 0x4

    move v4, v3

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$43;->val$roomID:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$43;->val$streamArrayList:Ljava/util/ArrayList;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onRoomStreamExtraInfoUpdate(Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method
