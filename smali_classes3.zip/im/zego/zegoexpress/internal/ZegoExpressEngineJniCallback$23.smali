.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$23;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPublisherSendAudioFirstFrame(I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$zegoPublishChannel:I


# direct methods
.method constructor <init>(I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "val$zegoPublishChannel"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$23;->val$zegoPublishChannel:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " @s~ ~b@M~~f4 tl-~@~  t~  c@@~~n    ~~~@bS@o@ ~frimlv o~ io~@.~~s@y@u do/@~@@@i@ ~o1~ a~ob~@/K@@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->values()[Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$23;->val$zegoPublishChannel:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    aget-object v1, v1, v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onPublisherSendAudioFirstFrame(Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method
