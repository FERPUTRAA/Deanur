.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$31;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPlayerStateUpdate(Ljava/lang/String;IILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$extendedData:Ljava/lang/String;

.field final synthetic val$state:I

.field final synthetic val$streamID:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;IILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$streamID",
            "val$state",
            "val$errorCode",
            "val$extendedData"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$31;->val$streamID:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$31;->val$state:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$31;->val$errorCode:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$31;->val$extendedData:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "f@s~trt.~ ~K1on@/l@c@~@  4~@~~@@/  bs ~~@@b uv@o~ ~i ~~~d ~@fo~~ @ - M~mi~o~yo  @@~iSlo@~b@ a@@ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$31;->val$streamID:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoPlayerState;->values()[Lim/zego/zegoexpress/constants/ZegoPlayerState;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$31;->val$state:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    aget-object v2, v2, v3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$31;->val$errorCode:I

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$31;->val$extendedData:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v4}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->access$000(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0, v1, v2, v3, v4}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onPlayerStateUpdate(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoPlayerState;ILorg/json/JSONObject;)V

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-void
.end method
