.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$61;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onCapturedSoundLevelUpdate(F)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$soundLevel:F


# direct methods
.method constructor <init>(F)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010
        }
        names = {
            "val$soundLevel"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$61;->val$soundLevel:F

    const/4 v1, 0x0

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "oas~@1f~~@~~~f@tc@ @~i/ ~s@l@~i@~l~@@M~ - ~u   bor~@o ~~@@ @bbm@ @/~o@S t~   ~y@. i@K@~dn~4v oo~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$61;->val$soundLevel:F

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onCapturedSoundLevelUpdate(F)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method
