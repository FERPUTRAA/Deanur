.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$79;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onNetworkSpeedTestQualityUpdate(Lim/zego/zegoexpress/entity/ZegoNetworkSpeedTestQuality;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$quality:Lim/zego/zegoexpress/entity/ZegoNetworkSpeedTestQuality;

.field final synthetic val$type:I


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/entity/ZegoNetworkSpeedTestQuality;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$quality",
            "val$type"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x7

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$79;->val$quality:Lim/zego/zegoexpress/entity/ZegoNetworkSpeedTestQuality;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$79;->val$type:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " ~sd b~ ~@c@@o @~mf@~a@u / ~@ l/~1sy@t~~@@@@-ir o4n  vo~lKfMo~@ @b~o~ @~~o~~i~@~ S  .t~@@~~@ @b "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    move v5, v4

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$79;->val$quality:Lim/zego/zegoexpress/entity/ZegoNetworkSpeedTestQuality;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoNetworkSpeedTestType;->values()[Lim/zego/zegoexpress/constants/ZegoNetworkSpeedTestType;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$79;->val$type:I

    const/4 v5, 0x1

    aget-object v2, v2, v3

    const/4 v4, 0x3

    xor-int/2addr v5, v4

    invoke-virtual {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onNetworkSpeedTestQualityUpdate(Lim/zego/zegoexpress/entity/ZegoNetworkSpeedTestQuality;Lim/zego/zegoexpress/constants/ZegoNetworkSpeedTestType;)V

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-void
.end method
