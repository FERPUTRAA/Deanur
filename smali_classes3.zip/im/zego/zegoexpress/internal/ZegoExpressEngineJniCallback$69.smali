.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$69;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onMixerRelayCDNStateUpdate([Lim/zego/zegoexpress/entity/ZegoStreamRelayCDNInfo;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$infoArrayList:Ljava/util/ArrayList;

.field final synthetic val$taskID:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$taskID",
            "val$infoArrayList"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$69;->val$taskID:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$69;->val$infoArrayList:Ljava/util/ArrayList;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " os d~@@  @@@ @@@o ~n4 @ b~~@r~b~lmfa@ t@-@oibo  s/~~ @ ~S~~@~~ lM@y~.@ ~ ov~oK~i/ ~ti@c@~~1~@~u"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$69;->val$taskID:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$69;->val$infoArrayList:Ljava/util/ArrayList;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onMixerRelayCDNStateUpdate(Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    return-void
.end method
