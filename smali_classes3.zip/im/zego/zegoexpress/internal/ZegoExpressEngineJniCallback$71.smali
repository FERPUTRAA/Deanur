.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$71;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onCapturedDataRecordProgressUpdate(JJLjava/lang/String;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$channel:I

.field final synthetic val$currentFileSize:J

.field final synthetic val$duration:J

.field final synthetic val$filePath:Ljava/lang/String;

.field final synthetic val$recordType:I


# direct methods
.method constructor <init>(JJLjava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$currentFileSize",
            "val$duration",
            "val$filePath",
            "val$recordType",
            "val$channel"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-wide p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$71;->val$currentFileSize:J

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-wide p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$71;->val$duration:J

    const/4 v1, 0x1

    iput-object p5, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$71;->val$filePath:Ljava/lang/String;

    iput p6, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$71;->val$recordType:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p7, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$71;->val$channel:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "o@s~@fS @y~  ~@t~@~@@bb@u~ir~~~@@f /in~ooobdm~a4 t sl @ ic~o-~~1M@~@@~ ~ ~@@.@ @K  o~~v /l~  @~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->iZegoDataRecordEventHandler:Lim/zego/zegoexpress/callback/IZegoDataRecordEventHandler;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    new-instance v1, Lim/zego/zegoexpress/entity/ZegoDataRecordProgress;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v1}, Lim/zego/zegoexpress/entity/ZegoDataRecordProgress;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-wide v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$71;->val$currentFileSize:J

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    iput-wide v2, v1, Lim/zego/zegoexpress/entity/ZegoDataRecordProgress;->currentFileSize:J

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-wide v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$71;->val$duration:J

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-wide v2, v1, Lim/zego/zegoexpress/entity/ZegoDataRecordProgress;->duration:J

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance v2, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;

    const/4 v5, 0x6

    invoke-direct {v2}, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$71;->val$filePath:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    iput-object v3, v2, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;->filePath:Ljava/lang/String;

    const/4 v5, 0x3

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$71;->val$recordType:I

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v3}, Lim/zego/zegoexpress/constants/ZegoDataRecordType;->getZegoDataRecordType(I)Lim/zego/zegoexpress/constants/ZegoDataRecordType;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput-object v3, v2, Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;->recordType:Lim/zego/zegoexpress/constants/ZegoDataRecordType;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$71;->val$channel:I

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v3}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->getZegoPublishChannel(I)Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v2, v3}, Lim/zego/zegoexpress/callback/IZegoDataRecordEventHandler;->onCapturedDataRecordProgressUpdate(Lim/zego/zegoexpress/entity/ZegoDataRecordProgress;Lim/zego/zegoexpress/entity/ZegoDataRecordConfig;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    :cond_0
    const/4 v4, 0x2

    move v5, v4

    return-void
.end method
