.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$15;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPublisherStateUpdate(Ljava/lang/String;IILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$extendedData:Ljava/lang/String;

.field final synthetic val$state:I

.field final synthetic val$streamID:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;IILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$streamID",
            "val$state",
            "val$errorCode",
            "val$extendedData"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$15;->val$streamID:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$15;->val$state:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$15;->val$errorCode:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$15;->val$extendedData:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x1

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$15;->val$streamID:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoPublisherState;->values()[Lim/zego/zegoexpress/constants/ZegoPublisherState;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$15;->val$state:I

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    aget-object v2, v2, v3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$15;->val$errorCode:I

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$15;->val$extendedData:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v4}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->access$000(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v2, v3, v4}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onPublisherStateUpdate(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoPublisherState;ILorg/json/JSONObject;)V

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    return-void
.end method
