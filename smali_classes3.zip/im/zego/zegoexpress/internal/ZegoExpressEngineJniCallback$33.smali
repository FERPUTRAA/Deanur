.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$33;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPlayerMediaEvent(Ljava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$mediaEvent:I

.field final synthetic val$streamID:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$streamID",
            "val$mediaEvent"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$33;->val$streamID:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$33;->val$mediaEvent:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~ s ~oo@@M .~/@oS@@@dl~~@~ml @ on@~@ a/v 1 ~b~~@~ bf 4~@@ @~ob~i ~~ir o c~f@iy~@@ ~stt ~~ @@u@-K"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$33;->val$streamID:Ljava/lang/String;

    const/4 v4, 0x4

    move v5, v4

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoPlayerMediaEvent;->values()[Lim/zego/zegoexpress/constants/ZegoPlayerMediaEvent;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$33;->val$mediaEvent:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    aget-object v2, v2, v3

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onPlayerMediaEvent(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoPlayerMediaEvent;)V

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-void
.end method
