.class Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback;->onInitCallback(II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$initCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicInitCallback;


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicInitCallback;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$initCallback",
            "val$errorCode"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$3;->val$initCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicInitCallback;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$3;->val$errorCode:I

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s~~@~ft  @~ 4@  . lt~b@ua Sf@1~@@o  ~~oK@ @oib~@/d@Mn ~@~@ ~o ~vil@@/-y~o@~o ~~@~ s ~irm@c@~@b"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$3;->val$initCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicInitCallback;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$3;->val$errorCode:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-interface {v0, v1}, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicInitCallback;->onInitCallback(I)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method
