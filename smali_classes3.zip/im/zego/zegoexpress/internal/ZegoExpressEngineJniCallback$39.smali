.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$39;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPlayerVideoSizeChanged(Ljava/lang/String;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$height:I

.field final synthetic val$streamID:Ljava/lang/String;

.field final synthetic val$width:I


# direct methods
.method constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$streamID",
            "val$width",
            "val$height"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$39;->val$streamID:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$39;->val$width:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$39;->val$height:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " osoK~@~@@ ~~ t@foaSM~~ @~~ir  tn@@bu~v~4 bf@~ ~@~.-so~m1/ ~@~iic@o o@@@ ~~  l/ ~~d y@ @bl@@@~~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$39;->val$streamID:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$39;->val$width:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$39;->val$height:I

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v0, v1, v2, v3}, Lim/zego/zegoexpress/utils/ZegoCallbackHelpers;->callOnPlayerVideoSizeChangedMethod(Ljava/lang/Object;Ljava/lang/String;II)V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-void
.end method
