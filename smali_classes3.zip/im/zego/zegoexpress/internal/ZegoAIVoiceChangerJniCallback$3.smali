.class Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniCallback$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniCallback;->onGetSpeakerList(II[Lim/zego/zegoexpress/entity/ZegoAIVoiceChangerSpeakerInfo;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$eventHandler:Lim/zego/zegoexpress/callback/IZegoAIVoiceChangerEventHandler;

.field final synthetic val$item:Ljava/util/Map$Entry;

.field final synthetic val$speakers:[Lim/zego/zegoexpress/entity/ZegoAIVoiceChangerSpeakerInfo;


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/callback/IZegoAIVoiceChangerEventHandler;Ljava/util/Map$Entry;I[Lim/zego/zegoexpress/entity/ZegoAIVoiceChangerSpeakerInfo;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$eventHandler",
            "val$item",
            "val$errorCode",
            "val$speakers"
        }
    .end annotation

    const/4 v1, 0x6

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniCallback$3;->val$eventHandler:Lim/zego/zegoexpress/callback/IZegoAIVoiceChangerEventHandler;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p2, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniCallback$3;->val$item:Ljava/util/Map$Entry;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniCallback$3;->val$errorCode:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p4, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniCallback$3;->val$speakers:[Lim/zego/zegoexpress/entity/ZegoAIVoiceChangerSpeakerInfo;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "b~sm~@M@tu@io o K/y~ n  @~~ ~@1 /.~~ r~  @a~o~li d4~@v~S@@bl@~@~~@ @ ct@@@~sfb@ f@o~~~@ ~oo@- i "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniCallback$3;->val$eventHandler:Lim/zego/zegoexpress/callback/IZegoAIVoiceChangerEventHandler;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniCallback$3;->val$item:Ljava/util/Map$Entry;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    check-cast v1, Lim/zego/zegoexpress/ZegoAIVoiceChanger;

    const/4 v6, 0x2

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniCallback$3;->val$errorCode:I

    const/4 v6, 0x6

    const/4 v5, 0x7

    new-instance v3, Ljava/util/ArrayList;

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v4, p0, Lim/zego/zegoexpress/internal/ZegoAIVoiceChangerJniCallback$3;->val$speakers:[Lim/zego/zegoexpress/entity/ZegoAIVoiceChangerSpeakerInfo;

    const/4 v5, 0x3

    move v6, v5

    invoke-static {v4}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v3, v4}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0, v1, v2, v3}, Lim/zego/zegoexpress/callback/IZegoAIVoiceChangerEventHandler;->onGetSpeakerList(Lim/zego/zegoexpress/ZegoAIVoiceChanger;ILjava/util/ArrayList;)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    return-void
.end method
