.class Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$10;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback;->onGetMusicByTokenCallback(IILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$getMusicByTokenCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetMusicByTokenCallback;

.field final synthetic val$resourceID:Ljava/lang/String;


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetMusicByTokenCallback;ILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$getMusicByTokenCallback",
            "val$errorCode",
            "val$resourceID"
        }
    .end annotation

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$10;->val$getMusicByTokenCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetMusicByTokenCallback;

    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$10;->val$errorCode:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$10;->val$resourceID:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~sl@d@~ bvo ~lt@ 4S~i~@@@~  f~@M 1b@@  - ~@~ ~@~~ ts i~in@~a~o@@/my@o~.~@f@ ~~~@~ K  c~ur/oo ob"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$10;->val$getMusicByTokenCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetMusicByTokenCallback;

    const/4 v4, 0x4

    const/4 v3, 0x3

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$10;->val$errorCode:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$10;->val$resourceID:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetMusicByTokenCallback;->onGetMusicByTokenCallback(ILjava/lang/String;)V

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    return-void
.end method
