.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$77;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onTestNetworkConnectivityCallback(IILim/zego/zegoexpress/entity/ZegoTestNetworkConnectivityResult;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$result:Lim/zego/zegoexpress/entity/ZegoTestNetworkConnectivityResult;

.field final synthetic val$seq:I


# direct methods
.method constructor <init>(IILim/zego/zegoexpress/entity/ZegoTestNetworkConnectivityResult;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$seq",
            "val$errorCode",
            "val$result"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$77;->val$seq:I

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$77;->val$errorCode:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$77;->val$result:Lim/zego/zegoexpress/entity/ZegoTestNetworkConnectivityResult;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ sl~uM-@r~/ ~@@s~o~S@titK o4~m ob1@@@@  @@ ii~f@~~~ ~~@@~@bo~ @ d ~ @@fo~@~~n y~ @ av~o~b/l .~c"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sTestNetworkConnectivityHandler:Ljava/util/HashMap;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$77;->val$seq:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    check-cast v0, Lim/zego/zegoexpress/callback/IZegoTestNetworkConnectivityCallback;

    const/4 v4, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$77;->val$errorCode:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$77;->val$result:Lim/zego/zegoexpress/entity/ZegoTestNetworkConnectivityResult;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoTestNetworkConnectivityCallback;->onTestNetworkConnectivityCallback(ILim/zego/zegoexpress/entity/ZegoTestNetworkConnectivityResult;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sTestNetworkConnectivityHandler:Ljava/util/HashMap;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$77;->val$seq:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v4, 0x4

    return-void
.end method
