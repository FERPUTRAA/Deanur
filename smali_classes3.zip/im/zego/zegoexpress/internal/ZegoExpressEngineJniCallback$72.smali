.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$72;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onEncodedDataTrafficControl(IIIII)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$bitrate:I

.field final synthetic val$channel:I

.field final synthetic val$fps:I

.field final synthetic val$height:I

.field final synthetic val$width:I


# direct methods
.method constructor <init>(IIIII)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$width",
            "val$height",
            "val$fps",
            "val$bitrate",
            "val$channel"
        }
    .end annotation

    const/4 v0, 0x4

    move v1, v0

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$72;->val$width:I

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$72;->val$height:I

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$72;->val$fps:I

    const/4 v1, 0x4

    iput p4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$72;->val$bitrate:I

    const/4 v0, 0x4

    move v1, v0

    iput p5, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$72;->val$channel:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "~/s ~@~oi @~~s@c ~~u S t~@@ ~@~i o~l @ fo@@ @@~~@~ a~@y@@ fM1bo-o@ ~tm@@v/ ~ K~b. 4or~@ i~ndlb@~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x4

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->mCustomVideoCaptureHandler:Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$72;->val$width:I

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$72;->val$height:I

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$72;->val$fps:I

    const/4 v7, 0x6

    const/4 v6, 0x1

    iget v4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$72;->val$bitrate:I

    const/4 v6, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget v5, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$72;->val$channel:I

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v5}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->getZegoPublishChannel(I)Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-result-object v5

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static/range {v0 .. v5}, Lim/zego/zegoexpress/utils/ZegoCallbackHelpers;->callCustomVideoCaptureOnEncodedDataTrafficControlMethod(Ljava/lang/Object;IIIILim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v0, 0x1

    move v7, v0

    const/4 v6, 0x4

    move v7, v6

    sput-boolean v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->isCustomVideoCapturing:Z

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    return-void
.end method
