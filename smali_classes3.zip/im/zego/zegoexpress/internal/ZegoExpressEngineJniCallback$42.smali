.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$42;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPlayerVideoSuperResolutionUpdate(Ljava/lang/String;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$state:I

.field final synthetic val$streamID:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$streamID",
            "val$state",
            "val$errorCode"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$42;->val$streamID:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$42;->val$state:I

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$42;->val$errorCode:I

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@s@@o@~@~@bn Kl~@@  i~1~~@~@4 t~f~l~f@ ~@~ b iord ~i~@ M. / @/~ aSvu@~- m@c@~~os bot@  @~yo~o @"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$42;->val$streamID:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$42;->val$state:I

    invoke-static {v2}, Lim/zego/zegoexpress/constants/ZegoSuperResolutionState;->getZegoSuperResolutionState(I)Lim/zego/zegoexpress/constants/ZegoSuperResolutionState;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$42;->val$errorCode:I

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2, v3}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onPlayerVideoSuperResolutionUpdate(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoSuperResolutionState;I)V

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void
.end method
