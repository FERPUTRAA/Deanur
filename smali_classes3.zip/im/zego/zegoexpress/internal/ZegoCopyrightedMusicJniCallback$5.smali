.class Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$5;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback;->onGetLrcLyricCallback(IILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$getLrcLyricCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetLrcLyricCallback;

.field final synthetic val$lyrics:Ljava/lang/String;


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetLrcLyricCallback;ILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$getLrcLyricCallback",
            "val$errorCode",
            "val$lyrics"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$5;->val$getLrcLyricCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetLrcLyricCallback;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$5;->val$errorCode:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$5;->val$lyrics:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~~s~@s@o@@~ S@  fao~i/ o. ~i ~@r~vy ~    dc~ i@~ @~fm@1@ln~@-@bKb~M@@@ @/~oo4 l~~~ @~t~@ot@b~ @u"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$5;->val$getLrcLyricCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetLrcLyricCallback;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$5;->val$errorCode:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$5;->val$lyrics:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-interface {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetLrcLyricCallback;->onGetLrcLyricCallback(ILjava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-void
.end method
