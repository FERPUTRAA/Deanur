.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$11;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onRoomSetRoomExtraInfoResult(Ljava/lang/String;Ljava/lang/String;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$seq:I


# direct methods
.method constructor <init>(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$seq",
            "val$errorCode"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$11;->val$seq:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$11;->val$errorCode:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "Mbs@@ @~@i@@@@~-t~~@ ~~  vfoo~~bs~~@@@ ly lao~i~o4 @/ ~ @on~~c ~S @m ~u@i  @~@ K.fd1@@r~/ ~tob~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v4, 0x0

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v4, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomSetExtraInfoHandler:Ljava/util/HashMap;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$11;->val$seq:I

    const/4 v3, 0x2

    or-int/2addr v4, v3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast v1, Lim/zego/zegoexpress/callback/IZegoRoomSetRoomExtraInfoCallback;

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$11;->val$errorCode:I

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v1, v2}, Lim/zego/zegoexpress/callback/IZegoRoomSetRoomExtraInfoCallback;->onRoomSetRoomExtraInfoResult(I)V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomSetExtraInfoHandler:Ljava/util/HashMap;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$11;->val$seq:I

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void

    :catchall_0
    move-exception v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    throw v1
.end method
