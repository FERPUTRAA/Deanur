.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$16;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPublisherUpdateCdnUrlResult(Ljava/lang/String;II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$seq:I


# direct methods
.method constructor <init>(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$seq",
            "val$errorCode"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$16;->val$seq:I

    const/4 v0, 0x3

    xor-int/2addr v1, v0

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$16;->val$errorCode:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o@sotaS~b@Kd/~  ~@~~@ @~ bs@c~@yn~ l~i~~v~ ~@@oMt@l~~@/@  -io~@@ @~1oim. @o u4r@f@ b~ ~@@ ~ f ~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPublisherUpdateCDNURLHandler:Ljava/util/HashMap;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$16;->val$seq:I

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    check-cast v0, Lim/zego/zegoexpress/callback/IZegoPublisherUpdateCdnUrlCallback;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$16;->val$errorCode:I

    const/4 v2, 0x3

    and-int/2addr v3, v2

    invoke-interface {v0, v1}, Lim/zego/zegoexpress/callback/IZegoPublisherUpdateCdnUrlCallback;->onPublisherUpdateCdnUrlResult(I)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sPublisherUpdateCDNURLHandler:Ljava/util/HashMap;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$16;->val$seq:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method
