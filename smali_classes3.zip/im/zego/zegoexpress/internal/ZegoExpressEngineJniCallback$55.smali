.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$55;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onLocalDeviceExceptionOccurred(IILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$deviceId:Ljava/lang/String;

.field final synthetic val$deviceType:I

.field final synthetic val$exceptionType:I


# direct methods
.method constructor <init>(IILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$exceptionType",
            "val$deviceType",
            "val$deviceId"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$55;->val$exceptionType:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$55;->val$deviceType:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$55;->val$deviceId:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v4, 0x6

    and-int/2addr v5, v4

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;->values()[Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$55;->val$exceptionType:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    aget-object v1, v1, v2

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoDeviceType;->values()[Lim/zego/zegoexpress/constants/ZegoDeviceType;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$55;->val$deviceType:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    aget-object v2, v2, v3

    const/4 v5, 0x5

    iget-object v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$55;->val$deviceId:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2, v3}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onLocalDeviceExceptionOccurred(Lim/zego/zegoexpress/constants/ZegoDeviceExceptionType;Lim/zego/zegoexpress/constants/ZegoDeviceType;Ljava/lang/String;)V

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-void
.end method
