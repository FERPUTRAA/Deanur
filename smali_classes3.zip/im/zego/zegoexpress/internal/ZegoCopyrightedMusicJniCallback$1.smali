.class Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback;->onDownloadProgressUpdate(Ljava/lang/String;F)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$iZegoCopyrightedMusicEventHandler:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicEventHandler;

.field final synthetic val$item:Ljava/util/Map$Entry;

.field final synthetic val$progressRate:F

.field final synthetic val$resourceID:Ljava/lang/String;


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicEventHandler;Ljava/util/Map$Entry;Ljava/lang/String;F)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$iZegoCopyrightedMusicEventHandler",
            "val$item",
            "val$resourceID",
            "val$progressRate"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$1;->val$iZegoCopyrightedMusicEventHandler:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicEventHandler;

    const/4 v0, 0x0

    or-int/2addr v1, v0

    iput-object p2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$1;->val$item:Ljava/util/Map$Entry;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$1;->val$resourceID:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p4, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$1;->val$progressRate:F

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "b s~/@ ~~ v ~~o/~@@K~~@lsor -@fd @~1b@4y~u ~n~f@ ~~oc @im o ~i@t l~S@~a@b@. i~@o~@~o@@ t~@@ ~@  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$1;->val$iZegoCopyrightedMusicEventHandler:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicEventHandler;

    const/4 v5, 0x6

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$1;->val$item:Ljava/util/Map$Entry;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    check-cast v1, Lim/zego/zegoexpress/ZegoCopyrightedMusic;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$1;->val$resourceID:Ljava/lang/String;

    const/4 v4, 0x5

    or-int/2addr v5, v4

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$1;->val$progressRate:F

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicEventHandler;->onDownloadProgressUpdate(Lim/zego/zegoexpress/ZegoCopyrightedMusic;Ljava/lang/String;F)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    return-void
.end method
