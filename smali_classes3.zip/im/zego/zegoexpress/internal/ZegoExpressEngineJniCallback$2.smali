.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$2;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onDebugError(ILjava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$funcName:Ljava/lang/String;

.field final synthetic val$info:Ljava/lang/String;


# direct methods
.method constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$errorCode",
            "val$funcName",
            "val$info"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$2;->val$errorCode:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$2;->val$funcName:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x5

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$2;->val$info:Ljava/lang/String;

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@~son~~o.f@@~u@~~4o@@~ ls@y ~oMt~ ~~oi/~@ f@v~ @~~ @ ~~ iob@m@ ~K@l@/@ @b t~-cdr1~  ~i@ a b ~S @"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$2;->val$errorCode:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$2;->val$funcName:Ljava/lang/String;

    const/4 v5, 0x5

    iget-object v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$2;->val$info:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2, v3}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onDebugError(ILjava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void
.end method
