.class Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$11;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback;->onRequestResourceCallback(IILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$requestResourceCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestResourceCallback;

.field final synthetic val$resourceID:Ljava/lang/String;


# direct methods
.method constructor <init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestResourceCallback;ILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$requestResourceCallback",
            "val$errorCode",
            "val$resourceID"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$11;->val$requestResourceCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestResourceCallback;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$11;->val$errorCode:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$11;->val$resourceID:Ljava/lang/String;

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    and-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " ~s yo ~u~~~@ rt@/M  @~b/@~~@ ~~ ivl~@itK@  a@ o@~ o~o~b@n4@-Sd~o~. s@l@1~o @mi @@~b~@@ @f~c @~~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object v0, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$11;->val$requestResourceCallback:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestResourceCallback;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$11;->val$errorCode:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$11;->val$resourceID:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-interface {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestResourceCallback;->onRequestResourceCallback(ILjava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void
.end method
