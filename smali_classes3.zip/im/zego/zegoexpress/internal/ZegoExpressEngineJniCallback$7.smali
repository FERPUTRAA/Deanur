.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$7;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onRoomStateChanged(Ljava/lang/String;IILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$extendedData:Ljava/lang/String;

.field final synthetic val$reason:I

.field final synthetic val$roomID:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$extendedData",
            "val$roomID",
            "val$reason",
            "val$errorCode"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$7;->val$extendedData:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$7;->val$roomID:Ljava/lang/String;

    const/4 v1, 0x7

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$7;->val$reason:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput p4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$7;->val$errorCode:I

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "K@s@oi~~@~~ @@ @ db i cooa~y@@~o@  ~f  ~@~~b~@o /4t~~@@@./v~lr 1@~S ~tm ~ u@-o~if~ ~ M b@@~~nls@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$7;->val$extendedData:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x4

    if-eqz v2, :cond_0

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v1, "}{"

    const-string/jumbo v1, "}{"

    const/4 v6, 0x1

    const-string/jumbo v1, "}{"

    const-string/jumbo v1, "{}"

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$7;->val$roomID:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;->values()[Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget v4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$7;->val$reason:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    aget-object v3, v3, v4

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget v4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$7;->val$errorCode:I

    const/4 v6, 0x5

    invoke-static {v1}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->access$000(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0, v2, v3, v4, v1}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onRoomStateChanged(Ljava/lang/String;Lim/zego/zegoexpress/constants/ZegoRoomStateChangedReason;ILorg/json/JSONObject;)V

    :cond_1
    const/4 v5, 0x6

    move v6, v5

    return-void
.end method
