.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$48;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onIMSendBarrageMessageResult(IILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$messageID:Ljava/lang/String;

.field final synthetic val$seq:I


# direct methods
.method constructor <init>(IILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$seq",
            "val$errorCode",
            "val$messageID"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$48;->val$seq:I

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$48;->val$errorCode:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$48;->val$messageID:Ljava/lang/String;

    const/4 v0, 0x7

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "f s@~/@b@~~Kdl@~oo@~1 ~  ~@v- ~ ~@@~~@i~oiy ~@~l@~~ib4 ~fa@@o t @~@o~@M  s o @nub~@ ~ c. ~@Sm/@r"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendBarrageMessageHandler:Ljava/util/HashMap;

    const/4 v4, 0x6

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$48;->val$seq:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    check-cast v0, Lim/zego/zegoexpress/callback/IZegoIMSendBarrageMessageCallback;

    const/4 v4, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$48;->val$errorCode:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$48;->val$messageID:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoIMSendBarrageMessageCallback;->onIMSendBarrageMessageResult(ILjava/lang/String;)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sIMSendBarrageMessageHandler:Ljava/util/HashMap;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$48;->val$seq:I

    const/4 v3, 0x4

    move v4, v3

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void
.end method
