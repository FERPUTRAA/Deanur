.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$8;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onRoomLoginResult(IILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$extendedData:Ljava/lang/String;

.field final synthetic val$seq:I


# direct methods
.method constructor <init>(ILjava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$seq",
            "val$extendedData",
            "val$errorCode"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$8;->val$seq:I

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$8;->val$extendedData:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$8;->val$errorCode:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~~sd@o ~yo@br toS.@@/ii~m~ ~~@v@f~~@@f  ~-4@/@@ ~ ~ K@~ uo~c~o~~M@ ~on ~l@t@ b@l @~b1s@@a ~~  @i"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x4

    const/4 v5, 0x3

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomLoginResultHandler:Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$8;->val$seq:I

    const/4 v5, 0x6

    const/4 v4, 0x6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    check-cast v1, Lim/zego/zegoexpress/callback/IZegoRoomLoginCallback;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$8;->val$extendedData:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v3, :cond_0

    const/4 v5, 0x2

    const-string/jumbo v2, "}{"

    const-string/jumbo v2, "{}"

    const/4 v5, 0x4

    const-string/jumbo v2, "{}"

    const-string/jumbo v2, "{}"

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$8;->val$errorCode:I

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v2}, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->access$000(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {v1, v3, v2}, Lim/zego/zegoexpress/callback/IZegoRoomLoginCallback;->onRoomLoginResult(ILorg/json/JSONObject;)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sRoomLoginResultHandler:Ljava/util/HashMap;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$8;->val$seq:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    monitor-exit v0

    const/4 v5, 0x4

    return-void

    :catchall_0
    move-exception v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    throw v1
.end method
