.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$26;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPublisherVideoSizeChanged(III)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$channel:I

.field final synthetic val$height:I

.field final synthetic val$width:I


# direct methods
.method constructor <init>(III)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$width",
            "val$height",
            "val$channel"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$26;->val$width:I

    const/4 v1, 0x6

    const/4 v0, 0x0

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$26;->val$height:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$26;->val$channel:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@~sbv~ib~@f@u~4@ ~o@n@at  @-b o~do@@@  K~l~~@o~ i~i / @@rof~~ s/~@c@ ~1 ~~@  .~t@@~ ~M So~@@y l~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v6, 0x0

    const/4 v5, 0x4

    if-eqz v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$26;->val$width:I

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$26;->val$height:I

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->values()[Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget v4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$26;->val$channel:I

    const/4 v6, 0x5

    const/4 v5, 0x6

    aget-object v3, v3, v4

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v0, v1, v2, v3}, Lim/zego/zegoexpress/utils/ZegoCallbackHelpers;->callOnPublisherVideoSizeChangedMethod(Ljava/lang/Object;IILim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    return-void
.end method
