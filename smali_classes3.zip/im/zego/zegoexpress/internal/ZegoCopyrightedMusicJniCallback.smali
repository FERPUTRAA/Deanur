.class public Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public static onCurrentPitchValueUpdate(Ljava/lang/String;II)V
    .locals 11
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "resourceID",
            "currentDuration",
            "pitchValue"
        }
    .end annotation

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "b.si a ~@~y ~~ o@ K~~o~@~t  @ ~v~lMr-f s~d~@@@~oi~ olnmu~@~oti~b@@S@c1@ /@~ /~b4 ~@ @@@  @@~of @"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x2

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-eqz v1, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    move-object v4, v1

    move-object v4, v1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    check-cast v4, Ljava/util/Map$Entry;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    check-cast v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget v1, v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/4 v2, 0x1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-ne v1, v2, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x4

    check-cast v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    iget-object v3, v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->eventHandler:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicEventHandler;

    const/4 v10, 0x7

    if-nez v3, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x6

    return-void

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    new-instance v8, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$2;

    move-object v2, v8

    move-object v2, v8

    move-object v2, v8

    move-object v2, v8

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    move-object v5, p0

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    move v6, p1

    move v6, p1

    move v6, p1

    move v6, p1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    move v7, p2

    move v7, p2

    const/4 v10, 0x7

    move v7, p2

    move v7, p2

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-direct/range {v2 .. v7}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$2;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicEventHandler;Ljava/util/Map$Entry;Ljava/lang/String;II)V

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {v1, v8}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    goto :goto_0

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    return-void
.end method

.method public static onDownloadCallback(II)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "seq",
            "errorCode"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v2, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v4, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-ne v3, v4, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->downloadCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicDownloadCallback;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x6

    const/4 v5, 0x1

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->downloadCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-nez v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    return-void

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$13;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-direct {v4, v3, p1}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$13;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicDownloadCallback;I)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v6, 0x0

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    return-void

    :catchall_0
    move-exception p0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    throw p0
.end method

.method public static onDownloadProgressUpdate(Ljava/lang/String;F)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "resourceID",
            "progressRate"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x3

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz v1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x4

    const/4 v3, 0x1

    move v5, v3

    move v5, v3

    const/4 v6, 0x7

    if-ne v2, v3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->eventHandler:Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicEventHandler;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-nez v2, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    return-void

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    sget-object v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$1;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-direct {v4, v2, v1, p0, p1}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$1;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicEventHandler;Ljava/util/Map$Entry;Ljava/lang/String;F)V

    const/4 v6, 0x5

    invoke-virtual {v3, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto :goto_0

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-void
.end method

.method public static onGetKrcLyricByTokenCallback(IILjava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "seq",
            "errorCode",
            "lyrics"
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x4

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x4

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v2, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v4, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-ne v3, v4, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->getKrcLyricByTokenCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetKrcLyricByTokenCallback;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->getKrcLyricByTokenCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-nez v3, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    return-void

    :cond_1
    const/4 v5, 0x6

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$6;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {v4, v3, p1, p2}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$6;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetKrcLyricByTokenCallback;ILjava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    throw p0
.end method

.method public static onGetLrcLyricCallback(IILjava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "seq",
            "errorCode",
            "lyrics"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v2, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v5, 0x4

    move v6, v5

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v4, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-ne v3, v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->getLrcLyricCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetLrcLyricCallback;

    const/4 v6, 0x5

    const/4 v5, 0x7

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->getLrcLyricCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-nez v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    return-void

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$5;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct {v4, v3, p1, p2}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$5;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetLrcLyricCallback;ILjava/lang/String;)V

    const/4 v6, 0x2

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x7

    return-void

    :catchall_0
    move-exception p0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    throw p0
.end method

.method public static onGetMusicByTokenCallback(IILjava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "seq",
            "errorCode",
            "resourceID"
        }
    .end annotation

    const/4 v6, 0x4

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x2

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v2, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x6

    const/4 v5, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x3

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v4, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-ne v3, v4, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x2

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->getMusicByTokenCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x4

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetMusicByTokenCallback;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->getMusicByTokenCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x7

    invoke-virtual {v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x0

    if-nez v3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v6, 0x6

    return-void

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$10;

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-direct {v4, v3, p1, p2}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$10;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetMusicByTokenCallback;ILjava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x2

    monitor-exit v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-void

    :catchall_0
    move-exception p0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v6, 0x5

    throw p0
.end method

.method public static onGetSharedResourceCallback(IILjava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "seq",
            "errorCode",
            "resourceID"
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x3

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v2, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v4, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-ne v3, v4, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x6

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v5, 0x2

    move v6, v5

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->getSharedResourceCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x3

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetSharedResourceCallback;

    const/4 v5, 0x2

    xor-int/2addr v6, v5

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->getSharedResourceCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    monitor-exit v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-void

    :cond_1
    const/4 v5, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$12;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {v4, v3, p1, p2}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$12;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetSharedResourceCallback;ILjava/lang/String;)V

    const/4 v5, 0x5

    xor-int/2addr v6, v5

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    monitor-exit v0

    const/4 v5, 0x0

    and-int/2addr v6, v5

    return-void

    :catchall_0
    move-exception p0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    throw p0
.end method

.method public static onGetStandardPitchCallback(IILjava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "seq",
            "errorCode",
            "pitch"
        }
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x0

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v2, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v4, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-ne v3, v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x1

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->getStandardPitchCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x4

    xor-int/2addr v6, v5

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetStandardPitchCallback;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x1

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->getStandardPitchCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    monitor-exit v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    return-void

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$14;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {v4, v3, p1, p2}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$14;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicGetStandardPitchCallback;ILjava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v5, 0x4

    move v6, v5

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    return-void

    :catchall_0
    move-exception p0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    throw p0
.end method

.method public static onInitCallback(II)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10
        }
        names = {
            "seq",
            "errorCode"
        }
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v2, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x0

    const/4 v5, 0x0

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x7

    const/4 v4, 0x1

    const/4 v6, 0x4

    const/4 v4, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-ne v3, v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->initCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x7

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicInitCallback;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->initCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x3

    invoke-virtual {v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-nez v3, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    monitor-exit v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-void

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$3;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-direct {v4, v3, p1}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$3;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicInitCallback;I)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v5, 0x4

    move v6, v5

    return-void

    :catchall_0
    move-exception p0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    throw p0
.end method

.method public static onRequestAccompanimentCallback(IILjava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "seq",
            "errorCode",
            "resourceID"
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x2

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v2, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-ne v3, v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x3

    const/4 v5, 0x0

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->requestAccompanimentCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestAccompanimentCallback;

    const/4 v6, 0x2

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->requestAccompanimentCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-nez v3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    monitor-exit v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    return-void

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$8;

    const/4 v6, 0x1

    invoke-direct {v4, v3, p1, p2}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$8;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestAccompanimentCallback;ILjava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    monitor-exit v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-void

    :catchall_0
    move-exception p0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    throw p0
.end method

.method public static onRequestAccompanimentClipCallback(IILjava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "seq",
            "errorCode",
            "resourceID"
        }
    .end annotation

    const/4 v5, 0x2

    move v6, v5

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x6

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v5, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz v2, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x7

    const/4 v5, 0x5

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v4, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-ne v3, v4, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->requestAccompanimentClipCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestAccompanimentClipCallback;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->requestAccompanimentClipCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-nez v3, :cond_1

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-void

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$9;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v4, v3, p1, p2}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$9;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestAccompanimentClipCallback;ILjava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    throw p0
.end method

.method public static onRequestResourceCallback(IILjava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "seq",
            "errorCode",
            "resourceID"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x5

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v2, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v4, 0x1

    and-int/2addr v6, v4

    const/4 v5, 0x1

    xor-int/2addr v6, v5

    if-ne v3, v4, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x2

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->requestResourceCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestResourceCallback;

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x2

    xor-int/2addr v6, v5

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->requestResourceCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x5

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-nez v3, :cond_1

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    return-void

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$11;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v4, v3, p1, p2}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$11;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestResourceCallback;ILjava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    monitor-exit v0

    const/4 v6, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    throw p0
.end method

.method public static onRequestSongCallback(IILjava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10
        }
        names = {
            "seq",
            "errorCode",
            "resourceID"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x4

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x2

    const/4 v5, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v2, :cond_2

    const/4 v5, 0x3

    xor-int/2addr v6, v5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v5, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v4, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x1

    if-ne v3, v4, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->requestSongCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestSongCallback;

    const/4 v5, 0x4

    and-int/2addr v6, v5

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->requestSongCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    if-nez v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    monitor-exit v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    return-void

    :cond_1
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$7;

    const/4 v5, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v4, v3, p1, p2}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$7;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicRequestSongCallback;ILjava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    monitor-exit v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    return-void

    :catchall_0
    move-exception p0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    throw p0
.end method

.method public static onSendExtendedRequestCallback(IILjava/lang/String;Ljava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x10,
            0x10,
            0x10,
            0x10
        }
        names = {
            "seq",
            "errorCode",
            "command",
            "result"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x3

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const-class v0, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x7

    sget-object v1, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->copyrightedMusicToIdxAndEventhandler:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v2, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->kCopyrightedMusicIdx:I

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v4, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x2

    if-ne v3, v4, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x4

    check-cast v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x1

    const/4 v5, 0x4

    iget-object v3, v3, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->sendExtendedRequestCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v3, v4}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    check-cast v3, Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicSendExtendedRequestCallback;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    check-cast v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v2, v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl$IdxAndHandler;->sendExtendedRequestCallbackHashMap:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v2, v4}, Ljava/util/concurrent/ConcurrentHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez v3, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    monitor-exit v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    return-void

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x4

    sget-object v2, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicInternalImpl;->mUIHandler:Landroid/os/Handler;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance v4, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$4;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v4, v3, p1, p2, p3}, Lim/zego/zegoexpress/internal/ZegoCopyrightedMusicJniCallback$4;-><init>(Lim/zego/zegoexpress/callback/IZegoCopyrightedMusicSendExtendedRequestCallback;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v2, v4}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    return-void

    :catchall_0
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    throw p0
.end method
