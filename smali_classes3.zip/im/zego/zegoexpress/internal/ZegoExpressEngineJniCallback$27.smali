.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$27;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPublisherVideoEncoderChanged(III)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$channel:I

.field final synthetic val$fromCodecID:I

.field final synthetic val$toCodecID:I


# direct methods
.method constructor <init>(III)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010,
            0x1010
        }
        names = {
            "val$fromCodecID",
            "val$toCodecID",
            "val$channel"
        }
    .end annotation

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$27;->val$fromCodecID:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$27;->val$toCodecID:I

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$27;->val$channel:I

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~Ss@-tl ~~1r.d~ o~~bf//~~@@~   ~iac@n@ib~o~ly ~ @o@~4@ @ ou K Mb@ @~@~@m ~ ~v~~@tf@@@i~@o o@s~@ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eqz v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->values()[Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$27;->val$fromCodecID:I

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    aget-object v1, v1, v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->values()[Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget v3, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$27;->val$toCodecID:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    aget-object v2, v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->values()[Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget v4, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$27;->val$channel:I

    const/4 v5, 0x1

    or-int/2addr v6, v5

    aget-object v3, v3, v4

    const/4 v6, 0x4

    const/4 v5, 0x0

    invoke-static {v0, v1, v2, v3}, Lim/zego/zegoexpress/utils/ZegoCallbackHelpers;->callOnPublisherVideoEncoderChangedMethod(Ljava/lang/Object;Lim/zego/zegoexpress/constants/ZegoVideoCodecID;Lim/zego/zegoexpress/constants/ZegoVideoCodecID;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    :cond_0
    const/4 v6, 0x2

    return-void
.end method
