.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$29;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onPublisherLowFpsWarning(II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$channel:I

.field final synthetic val$codecID:I


# direct methods
.method constructor <init>(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$codecID",
            "val$channel"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$29;->val$codecID:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$29;->val$channel:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->eventHandler:Lim/zego/zegoexpress/callback/IZegoEventHandler;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$29;->val$codecID:I

    const/4 v4, 0x4

    invoke-static {v1}, Lim/zego/zegoexpress/constants/ZegoVideoCodecID;->getZegoVideoCodecID(I)Lim/zego/zegoexpress/constants/ZegoVideoCodecID;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget v2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$29;->val$channel:I

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-static {v2}, Lim/zego/zegoexpress/constants/ZegoPublishChannel;->getZegoPublishChannel(I)Lim/zego/zegoexpress/constants/ZegoPublishChannel;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lim/zego/zegoexpress/callback/IZegoEventHandler;->onPublisherLowFpsWarning(Lim/zego/zegoexpress/constants/ZegoVideoCodecID;Lim/zego/zegoexpress/constants/ZegoPublishChannel;)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method
