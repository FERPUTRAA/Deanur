.class Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$81;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback;->onUploadLogResultCallback(II)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic val$errorCode:I

.field final synthetic val$seq:I


# direct methods
.method constructor <init>(II)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x1010,
            0x1010
        }
        names = {
            "val$seq",
            "val$errorCode"
        }
    .end annotation

    const/4 v0, 0x0

    move v1, v0

    iput p1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$81;->val$seq:I

    const/4 v1, 0x7

    iput p2, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$81;->val$errorCode:I

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "l@so  n~ yd~@~@~~Mv@@  @@im@ i@.sb~it ~~r4~~@ ofSb~@~@@ ~/t~~a l@~@  ~o ~~o-  f~ c@1ub~@/o@Ko@~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sUploadLogResultHandler:Ljava/util/HashMap;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$81;->val$seq:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast v0, Lim/zego/zegoexpress/callback/IZegoUploadLogResultCallback;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$81;->val$errorCode:I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-interface {v0, v1}, Lim/zego/zegoexpress/callback/IZegoUploadLogResultCallback;->onUploadLogResult(I)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object v0, Lim/zego/zegoexpress/internal/ZegoExpressEngineInternalImpl;->sUploadLogResultHandler:Ljava/util/HashMap;

    const/4 v2, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v1, p0, Lim/zego/zegoexpress/internal/ZegoExpressEngineJniCallback$81;->val$seq:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/util/HashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method
