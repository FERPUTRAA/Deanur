.class public Lim/zego/connection/NetworkStateChangeReceiver32675;
.super Landroid/content/BroadcastReceiver;


# instance fields
.field private mContext:Landroid/content/Context;

.field private mThis:J


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method private declared-synchronized GetDnsSevers()Ljava/lang/String;
    .locals 6
    .annotation build Landroid/annotation/TargetApi;
        value = 0x1a
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@s/b ~ya~~S @~~~d~r  ~/K@ @v tMm~@@@~  io@ i@ ~btl.~ -~ @@ s@f ~@~no@@4~o @ooi@~~ u@ol ~@~@b~f1"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Lim/zego/connection/NetworkStateChangeReceiver32675;->mContext:Landroid/content/Context;

    const/4 v5, 0x5

    const/4 v4, 0x0

    if-nez v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    monitor-exit p0

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    return-object v0

    :cond_0
    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x2

    const-string/jumbo v2, "ioymstnvicen"

    const-string/jumbo v2, "tnsecyoitvin"

    const/4 v5, 0x4

    const-string v2, "cocnoiyenvtt"

    const-string v2, "connectivity"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    check-cast v1, Landroid/net/ConnectivityManager;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v1, :cond_1

    const/4 v5, 0x0

    invoke-virtual {v1}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroid/net/ConnectivityManager;->getActiveNetwork()Landroid/net/Network;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v3, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v3}, Landroid/net/ConnectivityManager;->getLinkProperties(Landroid/net/Network;)Landroid/net/LinkProperties;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    invoke-virtual {v2}, Landroid/net/NetworkInfo;->isConnected()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1}, Landroid/net/LinkProperties;->getDnsServers()Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v2, :cond_1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    check-cast v2, Ljava/net/InetAddress;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/net/InetAddress;->getHostAddress()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v2, ";"

    const-string v2, ";"

    const/4 v5, 0x7

    const-string v2, ";"

    const-string v2, ";"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    monitor-exit p0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    monitor-exit p0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    throw v0
.end method

.method private getNetTypeDetail(Landroid/net/NetworkInfo;)I
    .locals 5
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "ni"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/net/NetworkInfo;->getType()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/16 v1, 0x20

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_2

    const/4 v3, 0x4

    move v4, v3

    const/4 p1, 0x1

    shl-int/2addr v4, p1

    const/4 v3, 0x7

    or-int/2addr v4, v3

    if-eq v0, p1, :cond_1

    const/4 v4, 0x7

    const/16 v2, 0x9

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eq v0, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    move v1, p1

    move v1, p1

    const/4 v4, 0x1

    move v1, p1

    move v1, p1

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_0

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/net/NetworkInfo;->getSubtype()I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    packed-switch p1, :pswitch_data_0

    :pswitch_0
    const/4 v4, 0x1

    goto :goto_0

    :pswitch_1
    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x3

    const/4 v1, 0x6

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_0

    :pswitch_2
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v1, 0x5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_0

    :pswitch_3
    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :pswitch_4
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v1, 0x3

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    return v1

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_4
        :pswitch_4
        :pswitch_3
        :pswitch_4
        :pswitch_3
        :pswitch_3
        :pswitch_4
        :pswitch_3
        :pswitch_3
        :pswitch_3
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_3
        :pswitch_3
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_0
        :pswitch_1
    .end packed-switch
.end method

.method static native onNetTypeChanged(JILjava/lang/String;)V
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0,
            0x0
        }
        names = {
            "pThis",
            "nt",
            "ni"
        }
    .end annotation
.end method


# virtual methods
.method public checkCurrentNetType()V
    .locals 3

    const/4 v0, 0x0

    move v2, v0

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {p0, v0, v0}, Lim/zego/connection/NetworkStateChangeReceiver32675;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v2, 0x5

    return-void
.end method

.method public getDnsSeverInfo()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x2

    move v3, v2

    const/16 v1, 0x19

    const/4 v3, 0x7

    if-le v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-direct {p0}, Lim/zego/connection/NetworkStateChangeReceiver32675;->GetDnsSevers()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v0, "Cdetmbg"

    const-string/jumbo v0, "gnCmedt"

    const/4 v3, 0x5

    const-string/jumbo v0, "gsndetu"

    const-string/jumbo v0, "getdnsC"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0
.end method

.method public declared-synchronized init(Landroid/content/Context;)I
    .locals 3
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "ctx"
        }
    .end annotation

    const/4 v2, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object p1, p0, Lim/zego/connection/NetworkStateChangeReceiver32675;->mContext:Landroid/content/Context;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p1, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    return p1

    :cond_0
    :try_start_1
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance p1, Landroid/content/IntentFilter;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p1}, Landroid/content/IntentFilter;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string v0, "CiVEnoOpedEdT._.IIoAt.CNGoYHTCnrncaN"

    const-string/jumbo v0, "iaIEonnCodONInYHTCoC.._VrcEANdTetn.G"

    const/4 v2, 0x1

    const-string v0, "N.CneVoiqC_ErCGTacdEotNI.nNOHdnYn.IT"

    const-string v0, "android.net.conn.CONNECTIVITY_CHANGE"

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lim/zego/connection/NetworkStateChangeReceiver32675;->mContext:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p0, p1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 p1, 0x0

    move v2, p1

    const/4 v1, 0x6

    or-int/2addr v2, v1

    invoke-virtual {p0, p1, p1}, Lim/zego/connection/NetworkStateChangeReceiver32675;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    throw p1
.end method

.method public declared-synchronized onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0,
            0x0
        }
        names = {
            "context",
            "intent"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object p1, p0, Lim/zego/connection/NetworkStateChangeReceiver32675;->mContext:Landroid/content/Context;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    monitor-exit p0

    return-void

    :cond_0
    :try_start_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo p2, "tcsioiecnytn"

    const-string p2, "cyconbeititn"

    const-string p2, "cnvmicntoeit"

    const-string p2, "connectivity"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast p1, Landroid/net/ConnectivityManager;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string p2, ""

    const-string p2, ""

    const/4 v3, 0x3

    const-string p2, ""

    const-string p2, ""

    const/4 v3, 0x3

    if-nez p1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    goto :goto_1

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/net/NetworkInfo;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Lim/zego/connection/NetworkStateChangeReceiver32675;->getNetTypeDetail(Landroid/net/NetworkInfo;)I

    move-result p1

    :goto_1
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-wide v0, p0, Lim/zego/connection/NetworkStateChangeReceiver32675;->mThis:J

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-static {v0, v1, p1, p2}, Lim/zego/connection/NetworkStateChangeReceiver32675;->onNetTypeChanged(JILjava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    monitor-exit p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    monitor-exit p0

    const/4 v3, 0x1

    const/4 v2, 0x1

    throw p1
.end method

.method public setThis(J)V
    .locals 2
    .annotation system Ldalvik/annotation/MethodParameters;
        accessFlags = {
            0x0
        }
        names = {
            "pThis"
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-wide p1, p0, Lim/zego/connection/NetworkStateChangeReceiver32675;->mThis:J

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public declared-synchronized uninit()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lim/zego/connection/NetworkStateChangeReceiver32675;->mContext:Landroid/content/Context;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0

    :cond_0
    :try_start_1
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    move v2, v1

    iput-object v0, p0, Lim/zego/connection/NetworkStateChangeReceiver32675;->mContext:Landroid/content/Context;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    monitor-exit p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x5

    return v0

    :catchall_0
    move-exception v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    monitor-exit p0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    throw v0
.end method
