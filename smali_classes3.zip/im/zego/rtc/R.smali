.class public final Lim/zego/rtc/R;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method
