.class public Li4/a;
.super Landroid/database/CursorWrapper;

# interfaces
.implements Landroid/database/CrossProcessCursor;


# annotations
.annotation build Lf4/a;
.end annotation


# instance fields
.field private a:Landroid/database/AbstractWindowedCursor;


# direct methods
.method public constructor <init>(Landroid/database/Cursor;)V
    .locals 4
    .param p1    # Landroid/database/Cursor;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Landroid/database/CursorWrapper;-><init>(Landroid/database/Cursor;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/16 v1, 0xa

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-ge v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    instance-of v1, p1, Landroid/database/CursorWrapper;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    check-cast p1, Landroid/database/CursorWrapper;

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {p1}, Landroid/database/CursorWrapper;->getWrappedCursor()Landroid/database/Cursor;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    instance-of v0, p1, Landroid/database/AbstractWindowedCursor;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast p1, Landroid/database/AbstractWindowedCursor;

    const/4 v3, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Li4/a;->a:Landroid/database/AbstractWindowedCursor;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string/jumbo v1, "koswtUe:yn  sn"

    const-string/jumbo v1, "nestkpnw:yo  U"

    const/4 v3, 0x2

    const-string/jumbo v1, "n km n:wtUnpyo"

    const-string v1, "Unknown type: "

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    throw v0
.end method


# virtual methods
.method public a(Landroid/database/CursorWindow;)V
    .locals 3
    .param p1    # Landroid/database/CursorWindow;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Li4/a;->a:Landroid/database/AbstractWindowedCursor;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Landroid/database/AbstractWindowedCursor;->setWindow(Landroid/database/CursorWindow;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public fillWindow(ILandroid/database/CursorWindow;)V
    .locals 3
    .param p2    # Landroid/database/CursorWindow;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Li4/a;->a:Landroid/database/AbstractWindowedCursor;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2}, Landroid/database/AbstractCursor;->fillWindow(ILandroid/database/CursorWindow;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public getWindow()Landroid/database/CursorWindow;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    .annotation build Lf4/a;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Li4/a;->a:Landroid/database/AbstractWindowedCursor;

    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-virtual {v0}, Landroid/database/AbstractWindowedCursor;->getWindow()Landroid/database/CursorWindow;

    move-result-object v0

    const/4 v1, 0x5

    move v2, v1

    return-object v0
.end method

.method public final synthetic getWrappedCursor()Landroid/database/Cursor;
    .locals 3
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Li4/a;->a:Landroid/database/AbstractWindowedCursor;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public final onMove(II)Z
    .locals 3
    .annotation runtime Lcom/google/errorprone/annotations/ResultIgnorabilityUnspecified;
    .end annotation

    const/4 v2, 0x4

    iget-object v0, p0, Li4/a;->a:Landroid/database/AbstractWindowedCursor;

    const/4 v2, 0x3

    const/4 v1, 0x4

    invoke-virtual {v0, p1, p2}, Landroid/database/AbstractCursor;->onMove(II)Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return p1
.end method
