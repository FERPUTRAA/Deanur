.class public interface abstract Lg4/a;
.super Ljava/lang/Object;


# annotations
.annotation build Lf4/a;
.end annotation


# static fields
.field public static final a:Ljava/lang/String; = "com.google.android.gms.plus.action.MANAGE_APPS"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "com.google.android.gms.extras.PRESELECTED_FILTER"
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation build Lf4/a;
    .end annotation
.end field

.field public static final c:I = 0x2
    .annotation build Lf4/a;
    .end annotation
.end field
