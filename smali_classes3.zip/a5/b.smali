.class public final La5/b;
.super Ljava/lang/Object;


# instance fields
.field private a:Lcom/google/firebase/analytics/FirebaseAnalytics$a;
    .annotation build Lia/e;
    .end annotation
.end field

.field private b:Lcom/google/firebase/analytics/FirebaseAnalytics$a;
    .annotation build Lia/e;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public final a()Ljava/util/Map;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Map<",
            "Lcom/google/firebase/analytics/FirebaseAnalytics$b;",
            "Lcom/google/firebase/analytics/FirebaseAnalytics$a;",
            ">;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance v0, Ljava/util/LinkedHashMap;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/util/LinkedHashMap;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object v1, p0, La5/b;->a:Lcom/google/firebase/analytics/FirebaseAnalytics$a;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget-object v2, Lcom/google/firebase/analytics/FirebaseAnalytics$b;->a:Lcom/google/firebase/analytics/FirebaseAnalytics$b;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v1, p0, La5/b;->b:Lcom/google/firebase/analytics/FirebaseAnalytics$a;

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    sget-object v2, Lcom/google/firebase/analytics/FirebaseAnalytics$b;->b:Lcom/google/firebase/analytics/FirebaseAnalytics$b;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-interface {v0, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-object v0
.end method

.method public final b()Lcom/google/firebase/analytics/FirebaseAnalytics$a;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, La5/b;->a:Lcom/google/firebase/analytics/FirebaseAnalytics$a;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0
.end method

.method public final c()Lcom/google/firebase/analytics/FirebaseAnalytics$a;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, La5/b;->b:Lcom/google/firebase/analytics/FirebaseAnalytics$a;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public final d(Lcom/google/firebase/analytics/FirebaseAnalytics$a;)V
    .locals 2
    .param p1    # Lcom/google/firebase/analytics/FirebaseAnalytics$a;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, La5/b;->a:Lcom/google/firebase/analytics/FirebaseAnalytics$a;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public final e(Lcom/google/firebase/analytics/FirebaseAnalytics$a;)V
    .locals 2
    .param p1    # Lcom/google/firebase/analytics/FirebaseAnalytics$a;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, La5/b;->b:Lcom/google/firebase/analytics/FirebaseAnalytics$a;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method
