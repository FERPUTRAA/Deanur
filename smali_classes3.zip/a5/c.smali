.class public final La5/c;
.super Ljava/lang/Object;


# instance fields
.field private final a:Landroid/os/Bundle;
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Landroid/os/Bundle;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    iput-object v0, p0, La5/c;->a:Landroid/os/Bundle;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public final a()Landroid/os/Bundle;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@os @f~l s~t~v~o~~4-@m K@@~l~@//@i@ b@i~a d~  ~~@ @@@ @~@  @~c@tMouo~o ~ S@1.~~~i@n y~r  bf@ ~~o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, La5/c;->a:Landroid/os/Bundle;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public final b(Ljava/lang/String;D)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x1

    const-string/jumbo v0, "yek"

    const/4 v2, 0x7

    const-string/jumbo v0, "yke"

    const-string/jumbo v0, "key"

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, La5/c;->a:Landroid/os/Bundle;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2, p3}, Landroid/os/BaseBundle;->putDouble(Ljava/lang/String;D)V

    const/4 v2, 0x2

    return-void
.end method

.method public final c(Ljava/lang/String;J)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string/jumbo v0, "key"

    const-string/jumbo v0, "yek"

    const/4 v2, 0x3

    const-string/jumbo v0, "kye"

    const-string/jumbo v0, "key"

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x6

    move v2, v1

    iget-object v0, p0, La5/c;->a:Landroid/os/Bundle;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p1, p2, p3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public final d(Ljava/lang/String;Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Landroid/os/Bundle;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v1, 0x2

    move v2, v1

    const-string/jumbo v0, "eyk"

    const-string/jumbo v0, "yke"

    const/4 v2, 0x2

    const-string v0, "eky"

    const-string/jumbo v0, "key"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo v0, "vusle"

    const/4 v2, 0x1

    const-string v0, "alemu"

    const-string/jumbo v0, "value"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, La5/c;->a:Landroid/os/Bundle;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p2}, Landroid/os/Bundle;->putBundle(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void
.end method

.method public final e(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string/jumbo v0, "yek"

    const-string/jumbo v0, "yke"

    const-string/jumbo v0, "kye"

    const-string/jumbo v0, "key"

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string/jumbo v0, "vuleo"

    const-string/jumbo v0, "ulvme"

    const/4 v2, 0x3

    const-string v0, "bavul"

    const-string/jumbo v0, "value"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, La5/c;->a:Landroid/os/Bundle;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public final f(Ljava/lang/String;[Landroid/os/Bundle;)V
    .locals 3
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # [Landroid/os/Bundle;
        .annotation build Lia/d;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string/jumbo v0, "yke"

    const-string/jumbo v0, "eyk"

    const/4 v2, 0x0

    const-string/jumbo v0, "key"

    const-string/jumbo v0, "key"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string/jumbo v0, "eulva"

    const-string/jumbo v0, "value"

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, La5/c;->a:Landroid/os/Bundle;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    check-cast p2, [Landroid/os/Parcelable;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0, p1, p2}, Landroid/os/Bundle;->putParcelableArray(Ljava/lang/String;[Landroid/os/Parcelable;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method
