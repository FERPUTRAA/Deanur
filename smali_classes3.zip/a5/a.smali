.class public final La5/a;
.super Ljava/lang/Object;


# static fields
.field private static volatile a:Lcom/google/firebase/analytics/FirebaseAnalytics; = null
    .annotation build Lia/e;
    .end annotation
.end field

.field private static final b:Ljava/lang/Object;
    .annotation build Lia/d;
    .end annotation
.end field

.field public static final c:Ljava/lang/String; = "fire-analytics-ktx"
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/Object;

    const/4 v1, 0x4

    move v2, v1

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    sput-object v0, La5/a;->b:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public static final a()Lcom/google/firebase/analytics/FirebaseAnalytics;
    .locals 3
    .annotation build Lia/e;
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@dsi ~@co~bo~on~r o~f~~@ ~~~@o ~. a4@~b/~S@@@l~ /~  @f@~@ y~@il1 @~ @ @s~@m  @iM~~@  t K-o@ubvt~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, La5/a;->a:Lcom/google/firebase/analytics/FirebaseAnalytics;

    const/4 v2, 0x0

    return-object v0
.end method

.method public static final b(Lz5/b;)Lcom/google/firebase/analytics/FirebaseAnalytics;
    .locals 3
    .param p0    # Lz5/b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-string/jumbo v0, "hs>ms<"

    const-string/jumbo v0, "hss<>t"

    const/4 v2, 0x5

    const-string v0, "<h>sot"

    const-string v0, "<this>"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v1, 0x6

    sget-object p0, La5/a;->a:Lcom/google/firebase/analytics/FirebaseAnalytics;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez p0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object p0, La5/a;->b:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {}, La5/a;->a()Lcom/google/firebase/analytics/FirebaseAnalytics;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    if-nez v0, :cond_0

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object v0, Lz5/b;->a:Lz5/b;

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-static {v0}, Lz5/c;->b(Lz5/b;)Lcom/google/firebase/g;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/google/firebase/g;->n()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/google/firebase/analytics/FirebaseAnalytics;->getInstance(Landroid/content/Context;)Lcom/google/firebase/analytics/FirebaseAnalytics;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-static {v0}, La5/a;->e(Lcom/google/firebase/analytics/FirebaseAnalytics;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v1, 0x4

    move v2, v1

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v2, 0x6

    throw v0

    :cond_1
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    sget-object p0, La5/a;->a:Lcom/google/firebase/analytics/FirebaseAnalytics;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p0}, Lkotlin/jvm/internal/l0;->m(Ljava/lang/Object;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public static final c()Ljava/lang/Object;
    .locals 3
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object v0, La5/a;->b:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public static final d(Lcom/google/firebase/analytics/FirebaseAnalytics;Ljava/lang/String;Li8/l;)V
    .locals 3
    .param p0    # Lcom/google/firebase/analytics/FirebaseAnalytics;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/firebase/analytics/FirebaseAnalytics;",
            "Ljava/lang/String;",
            "Li8/l<",
            "-",
            "La5/c;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string/jumbo v0, "stm>ib"

    const-string v0, "<>imts"

    const/4 v2, 0x1

    const-string/jumbo v0, "usih>t"

    const-string v0, "<this>"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string/jumbo v0, "nema"

    const-string/jumbo v0, "nmae"

    const/4 v2, 0x7

    const-string v0, "eamn"

    const-string/jumbo v0, "name"

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string/jumbo v0, "olpko"

    const-string/jumbo v0, "lcoko"

    const/4 v2, 0x6

    const-string v0, "ckoql"

    const-string v0, "block"

    const/4 v2, 0x2

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, La5/c;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0}, La5/c;-><init>()V

    const/4 v2, 0x3

    invoke-interface {p2, v0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x5

    invoke-virtual {v0}, La5/c;->a()Landroid/os/Bundle;

    move-result-object p2

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/google/firebase/analytics/FirebaseAnalytics;->b(Ljava/lang/String;Landroid/os/Bundle;)V

    const/4 v2, 0x3

    return-void
.end method

.method public static final e(Lcom/google/firebase/analytics/FirebaseAnalytics;)V
    .locals 2
    .param p0    # Lcom/google/firebase/analytics/FirebaseAnalytics;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    sput-object p0, La5/a;->a:Lcom/google/firebase/analytics/FirebaseAnalytics;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public static final f(Lcom/google/firebase/analytics/FirebaseAnalytics;Li8/l;)V
    .locals 3
    .param p0    # Lcom/google/firebase/analytics/FirebaseAnalytics;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/firebase/analytics/FirebaseAnalytics;",
            "Li8/l<",
            "-",
            "La5/b;",
            "Lkotlin/s2;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string/jumbo v0, "t<shib"

    const-string v0, "><ithb"

    const-string v0, ">himts"

    const-string v0, "<this>"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string v0, "culko"

    const-string/jumbo v0, "ouklc"

    const/4 v2, 0x0

    const-string v0, "bcokb"

    const-string v0, "block"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    new-instance v0, La5/b;

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0}, La5/b;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {p1, v0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-virtual {v0}, La5/b;->a()Ljava/util/Map;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p1}, Lcom/google/firebase/analytics/FirebaseAnalytics;->e(Ljava/util/Map;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method
