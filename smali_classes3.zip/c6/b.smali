.class public Lc6/b;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/firebase/components/n;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public static synthetic b(Ljava/lang/String;Lcom/google/firebase/components/g;Lcom/google/firebase/components/i;)Ljava/lang/Object;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s~~~/t@ ubo~rSl@bo @   /@o@ ~~~ cis~@~b@~i~@@n.v@~f~~ omo~~@  Ka@~@~@- @i@ ~@1~tdMl o4 y f ~ @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lc6/b;->c(Ljava/lang/String;Lcom/google/firebase/components/g;Lcom/google/firebase/components/i;)Ljava/lang/Object;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method private static synthetic c(Ljava/lang/String;Lcom/google/firebase/components/g;Lcom/google/firebase/components/i;)Ljava/lang/Object;
    .locals 2

    :try_start_0
    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p0}, Lc6/c;->b(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p1}, Lcom/google/firebase/components/g;->k()Lcom/google/firebase/components/l;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-interface {p0, p2}, Lcom/google/firebase/components/l;->a(Lcom/google/firebase/components/i;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {}, Lc6/c;->a()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {}, Lc6/c;->a()V

    const/4 v0, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    throw p0
.end method


# virtual methods
.method public a(Lcom/google/firebase/components/ComponentRegistrar;)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lcom/google/firebase/components/ComponentRegistrar;",
            ")",
            "Ljava/util/List<",
            "Lcom/google/firebase/components/g<",
            "*>;>;"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x0

    const/4 v4, 0x5

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-interface {p1}, Lcom/google/firebase/components/ComponentRegistrar;->getComponents()Ljava/util/List;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz v1, :cond_1

    const/4 v5, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    check-cast v1, Lcom/google/firebase/components/g;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/google/firebase/components/g;->l()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v3, Lc6/a;

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {v3, v2, v1}, Lc6/a;-><init>(Ljava/lang/String;Lcom/google/firebase/components/g;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1, v3}, Lcom/google/firebase/components/g;->E(Lcom/google/firebase/components/l;)Lcom/google/firebase/components/g;

    move-result-object v1

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-object v0
.end method
