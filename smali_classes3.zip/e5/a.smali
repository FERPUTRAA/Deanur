.class public interface abstract Le5/a;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Ld5/a;)V
    .param p1    # Ld5/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method
