.class public interface abstract Le5/c;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Z)Lcom/google/android/gms/tasks/Task;
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(Z)",
            "Lcom/google/android/gms/tasks/Task<",
            "Ld5/a;",
            ">;"
        }
    .end annotation
.end method

.method public abstract b(Le5/a;)V
    .param p1    # Le5/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method

.method public abstract c(Le5/a;)V
    .param p1    # Le5/a;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
.end method
