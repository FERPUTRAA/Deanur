.class public final Lf5/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "fire-auth-ktx"
    .annotation build Lia/d;
    .end annotation
.end field


# direct methods
.method public static final a(Li8/l;)Lcom/google/firebase/auth/ActionCodeSettings;
    .locals 4
    .param p0    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/l<",
            "-",
            "Lcom/google/firebase/auth/ActionCodeSettings$a;",
            "Lkotlin/s2;",
            ">;)",
            "Lcom/google/firebase/auth/ActionCodeSettings;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo v0, "tnii"

    const-string/jumbo v0, "tnii"

    const/4 v3, 0x4

    const-string/jumbo v0, "niti"

    const-string/jumbo v0, "init"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/firebase/auth/ActionCodeSettings;->E2()Lcom/google/firebase/auth/ActionCodeSettings$a;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const-string/jumbo v1, "n(sdiurew)Bl..s"

    const-string v1, ").sduniwr.e(lBe"

    const/4 v3, 0x0

    const-string/jumbo v1, "i.Bmred)n.w(eul"

    const-string/jumbo v1, "newBuilder(...)"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p0, v0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/google/firebase/auth/ActionCodeSettings$a;->a()Lcom/google/firebase/auth/ActionCodeSettings;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v0, ")dm.oi..ub"

    const-string v0, ")dbm(.u.i."

    const/4 v3, 0x4

    const-string v0, ").bd(buli."

    const-string v0, "build(...)"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p0
.end method

.method public static final b(Lz5/b;Lcom/google/firebase/g;)Lcom/google/firebase/auth/FirebaseAuth;
    .locals 3
    .param p0    # Lz5/b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lcom/google/firebase/g;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-string/jumbo v0, "u<>iht"

    const-string v0, "<this>"

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    const-string/jumbo p0, "ppa"

    const-string p0, "app"

    const/4 v2, 0x1

    const-string/jumbo p0, "pap"

    const-string p0, "app"

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p1, p0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/google/firebase/auth/FirebaseAuth;->getInstance(Lcom/google/firebase/g;)Lcom/google/firebase/auth/FirebaseAuth;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo p1, "genoeaIp).t.scnt"

    const-string/jumbo p1, "t)tno.ce.aneIgs."

    const/4 v2, 0x7

    const-string p1, ".ett.(Igqe).ansn"

    const-string/jumbo p1, "getInstance(...)"

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method public static final c(Lz5/b;)Lcom/google/firebase/auth/FirebaseAuth;
    .locals 3
    .param p0    # Lz5/b;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string v0, "<is>tb"

    const-string/jumbo v0, "s<i>tb"

    const-string/jumbo v0, "s<>mit"

    const-string v0, "<this>"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    invoke-static {}, Lcom/google/firebase/auth/FirebaseAuth;->getInstance()Lcom/google/firebase/auth/FirebaseAuth;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const-string/jumbo v0, "gs.uot(t)Ice.ean"

    const-string v0, ")tc(tsu.enIenag."

    const/4 v2, 0x3

    const-string/jumbo v0, "st.Itb.genc(a)ne"

    const-string/jumbo v0, "getInstance(...)"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method public static final d(Ljava/lang/String;Li8/l;)Lcom/google/firebase/auth/AuthCredential;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Li8/l<",
            "-",
            "Lcom/google/firebase/auth/a0$b;",
            "Lkotlin/s2;",
            ">;)",
            "Lcom/google/firebase/auth/AuthCredential;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string/jumbo v0, "oeivdrupIr"

    const-string/jumbo v0, "providerId"

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x2

    move v2, v1

    const-string/jumbo v0, "itin"

    const-string/jumbo v0, "inti"

    const/4 v2, 0x5

    const-string/jumbo v0, "tnii"

    const-string/jumbo v0, "init"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/google/firebase/auth/a0;->h(Ljava/lang/String;)Lcom/google/firebase/auth/a0$b;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string/jumbo v0, "up)intdpa.iewdre.BlCrl.en"

    const-string/jumbo v0, "ri.eBlipeuwna.e)nret.lCdd"

    const/4 v2, 0x7

    const-string/jumbo v0, "lr(aieneq.win).r.eCBuetld"

    const-string/jumbo v0, "newCredentialBuilder(...)"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-interface {p1, p0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v1, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/google/firebase/auth/a0$b;->a()Lcom/google/firebase/auth/AuthCredential;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string/jumbo p1, "lisd(.b).."

    const-string p1, "build(...)"

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p0
.end method

.method public static final e(Ljava/lang/String;Lcom/google/firebase/auth/FirebaseAuth;Li8/l;)Lcom/google/firebase/auth/a0;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Lcom/google/firebase/auth/FirebaseAuth;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p2    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Lcom/google/firebase/auth/FirebaseAuth;",
            "Li8/l<",
            "-",
            "Lcom/google/firebase/auth/a0$a;",
            "Lkotlin/s2;",
            ">;)",
            "Lcom/google/firebase/auth/a0;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string/jumbo v0, "rIdpoirdqe"

    const/4 v2, 0x7

    const-string/jumbo v0, "providerId"

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string/jumbo v0, "hifmsbtraeeu"

    const-string/jumbo v0, "rasutAfihebe"

    const-string/jumbo v0, "firebaseAuth"

    const/4 v2, 0x2

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string/jumbo v0, "ntii"

    const-string/jumbo v0, "iitn"

    const/4 v2, 0x7

    const-string/jumbo v0, "init"

    const-string/jumbo v0, "init"

    const/4 v2, 0x5

    invoke-static {p2, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p0, p1}, Lcom/google/firebase/auth/a0;->g(Ljava/lang/String;Lcom/google/firebase/auth/FirebaseAuth;)Lcom/google/firebase/auth/a0$a;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string/jumbo p1, "ilBm()r.w.uen.d"

    const/4 v2, 0x0

    const-string p1, ".Bwiodu)e.er.n("

    const-string/jumbo p1, "newBuilder(...)"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {p2, p0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/google/firebase/auth/a0$a;->c()Lcom/google/firebase/auth/a0;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const-string p1, "du)olb(..."

    const-string/jumbo p1, "udb.o(l..)"

    const-string p1, "(l)..iubu."

    const-string p1, "build(...)"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p0
.end method

.method public static final f(Ljava/lang/String;Li8/l;)Lcom/google/firebase/auth/a0;
    .locals 3
    .param p0    # Ljava/lang/String;
        .annotation build Lia/d;
        .end annotation
    .end param
    .param p1    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Li8/l<",
            "-",
            "Lcom/google/firebase/auth/a0$a;",
            "Lkotlin/s2;",
            ">;)",
            "Lcom/google/firebase/auth/a0;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string v0, "dIviobpred"

    const/4 v2, 0x1

    const-string/jumbo v0, "vdierrppdo"

    const-string/jumbo v0, "providerId"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-string/jumbo v0, "init"

    const-string/jumbo v0, "iitn"

    const/4 v2, 0x2

    const-string/jumbo v0, "inti"

    const-string/jumbo v0, "init"

    const/4 v1, 0x6

    move v2, v1

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/google/firebase/auth/a0;->f(Ljava/lang/String;)Lcom/google/firebase/auth/a0$a;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string v0, "(ur)wdneqB..iel"

    const-string/jumbo v0, "newBuilder(...)"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {p1, p0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/google/firebase/auth/a0$a;->c()Lcom/google/firebase/auth/a0;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    const-string/jumbo p1, "l.suui)d.b"

    const-string p1, "dbl)..uui."

    const/4 v2, 0x7

    const-string/jumbo p1, "lbdm().i.."

    const-string p1, "build(...)"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p0, p1}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public static final g(Li8/l;)Lcom/google/firebase/auth/UserProfileChangeRequest;
    .locals 3
    .param p0    # Li8/l;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Li8/l<",
            "-",
            "Lcom/google/firebase/auth/UserProfileChangeRequest$a;",
            "Lkotlin/s2;",
            ">;)",
            "Lcom/google/firebase/auth/UserProfileChangeRequest;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string/jumbo v0, "niti"

    const-string/jumbo v0, "tiin"

    const/4 v2, 0x7

    const-string/jumbo v0, "iitn"

    const-string/jumbo v0, "init"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    new-instance v0, Lcom/google/firebase/auth/UserProfileChangeRequest$a;

    const/4 v2, 0x3

    invoke-direct {v0}, Lcom/google/firebase/auth/UserProfileChangeRequest$a;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-interface {p0, v0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/google/firebase/auth/UserProfileChangeRequest$a;->a()Lcom/google/firebase/auth/UserProfileChangeRequest;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string v0, ")i.lou(p.d"

    const-string v0, "buld..ip()"

    const/4 v2, 0x6

    const-string/jumbo v0, "ud.)ibl(.."

    const-string v0, "build(...)"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    return-object p0
.end method
