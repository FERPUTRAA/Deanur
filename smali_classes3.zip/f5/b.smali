.class public final Lf5/b;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "22.1.2"

.field public static final b:Z


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method
