.class public final Le6/b;
.super Ljava/lang/Object;


# static fields
.field private static final b:Ljava/util/logging/Logger;


# instance fields
.field private final a:Z


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-class v0, Le6/b;

    const-class v0, Le6/b;

    const/4 v2, 0x2

    const-class v0, Le6/b;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    sput-object v0, Le6/b;->b:Ljava/util/logging/Logger;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method private constructor <init>(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-boolean p1, p0, Le6/b;->a:Z

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method private a(Ljava/io/InputStream;)V
    .locals 5

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "s@s@~i@1~@l/@~@~n@     @~ ~~~~@trfd@@o@b ut~oi~@ @ /@ mv@~.~@-@y K Ml o~ ~ a~b@oi~c fS oo~4~b~@~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object v0, Le6/b;->b:Ljava/util/logging/Logger;

    const/4 v4, 0x7

    sget-object v1, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const-string/jumbo v2, "i nmoanuor)eretpsgintm rgr  (rlciEsd"

    const-string/jumbo v2, "misuEgrportegn cdrrn)l esnoi o ia(rt"

    const/4 v4, 0x0

    const-string/jumbo v2, "gtogoniri prc s r(rolrEuene iadtom)n"

    const-string v2, "Error closing input stream (ignored)"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2, p1}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method private b()Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Lcom/google/i18n/phonenumbers/j$b;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-boolean v0, p0, Le6/b;->a:Z

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x3

    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "r cenbnutmoc  Sublneo"

    const-string/jumbo v1, "uSumccranl nbetone  o"

    const/4 v3, 0x3

    const-string/jumbo v1, "oarn bueunn Sceo lctu"

    const-string v1, "Source cannot be null"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    throw v0
.end method

.method public static c()Le6/b;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    new-instance v0, Le6/b;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Le6/b;-><init>(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public static d()Le6/b;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Le6/b;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Le6/b;-><init>(Z)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0
.end method


# virtual methods
.method public e(Ljava/io/InputStream;)Ljava/util/Collection;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/io/InputStream;",
            ")",
            "Ljava/util/Collection<",
            "Lcom/google/i18n/phonenumbers/j$b;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-nez p1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {p0}, Le6/b;->b()Ljava/util/List;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    return-object p1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v1, Ljava/io/ObjectInputStream;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {v1, p1}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v5, 0x1

    move v6, v5

    new-instance v0, Lcom/google/i18n/phonenumbers/j$c;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-direct {v0}, Lcom/google/i18n/phonenumbers/j$c;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Lcom/google/i18n/phonenumbers/j$c;->readExternal(Ljava/io/ObjectInput;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/google/i18n/phonenumbers/j$c;->d()Ljava/util/List;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-interface {v2}, Ljava/util/List;->isEmpty()Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-nez v2, :cond_1

    const/4 v5, 0x2

    move v6, v5

    invoke-virtual {v0}, Lcom/google/i18n/phonenumbers/j$c;->d()Ljava/util/List;

    move-result-object p1
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {p0, v1}, Le6/b;->a(Ljava/io/InputStream;)V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    return-object p1

    :cond_1
    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string/jumbo v2, "meatEaypatd to"

    const-string/jumbo v2, "ttmaodEayemt a"

    const/4 v6, 0x6

    const-string v2, "atmtdm Eqtapae"

    const-string v2, "Empty metadata"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-direct {v0, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    throw v0
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catch_0
    move-exception v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_0

    :catchall_0
    move-exception v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto :goto_1

    :catch_1
    move-exception v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v4, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, v4

    move-object v0, v4

    move-object v0, v4

    :goto_0
    :try_start_3
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/IllegalStateException;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v3, "a sspeele bera odfaanblitaUtt"

    const-string v3, " l adbliatt nateprbe aUafsoee"

    const/4 v6, 0x7

    const-string v3, " lemUb asma  eenldetafptaitro"

    const-string v3, "Unable to parse metadata file"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {v2, v3, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    throw v2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :catchall_1
    move-exception v0

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v1, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-direct {p0, v1}, Le6/b;->a(Ljava/io/InputStream;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_2

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {p0, p1}, Le6/b;->a(Ljava/io/InputStream;)V

    :goto_2
    const/4 v5, 0x5

    const/4 v6, 0x0

    throw v0
.end method
