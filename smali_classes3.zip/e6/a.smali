.class public final Le6/a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/google/i18n/phonenumbers/d;


# static fields
.field private static final a:Ljava/util/logging/Logger;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-class v0, Le6/a;

    const-class v0, Le6/a;

    const/4 v2, 0x0

    const-class v0, Le6/a;

    const-class v0, Le6/a;

    const/4 v2, 0x3

    const/4 v1, 0x1

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/util/logging/Logger;->getLogger(Ljava/lang/String;)Ljava/util/logging/Logger;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    sput-object v0, Le6/a;->a:Ljava/util/logging/Logger;

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)Ljava/io/InputStream;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "f s@ @ bo@@s ~~ tt~v@~ @n~K~ r~l4~uai@@~c~~~ M~@ ~@@ ~@bo@~@mb// l~~~o-od1~i @ S@oy@~i@f~ .  @o "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    const-class v0, Le6/a;

    const-class v0, Le6/a;

    const/4 v6, 0x6

    const-class v0, Le6/a;

    const-class v0, Le6/a;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/Class;->getResourceAsStream(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-nez v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    sget-object v1, Le6/a;->a:Ljava/util/logging/Logger;

    const/4 v6, 0x5

    const/4 v5, 0x3

    sget-object v2, Ljava/util/logging/Level;->WARNING:Ljava/util/logging/Level;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    aput-object p1, v3, v4

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string p1, "  tmlneoof isnu%F"

    const-string p1, "File %s not found"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {p1, v3}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v1, v2, p1}, Ljava/util/logging/Logger;->log(Ljava/util/logging/Level;Ljava/lang/String;)V

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    return-object v0
.end method
