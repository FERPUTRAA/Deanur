.class public Ld4/a;
.super Ljava/lang/Object;


# static fields
.field public static final a:Ljava/lang/String; = "com.google.android.gms.actions.CREATE_ITEM_LIST"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final b:Ljava/lang/String; = "com.google.android.gms.actions.DELETE_ITEM_LIST"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final c:Ljava/lang/String; = "com.google.android.gms.actions.APPEND_ITEM_LIST"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final d:Ljava/lang/String; = "com.google.android.gms.actions.ACCEPT_ITEM"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final e:Ljava/lang/String; = "com.google.android.gms.actions.REJECT_ITEM"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final f:Ljava/lang/String; = "com.google.android.gms.actions.DELETE_ITEM"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final g:Ljava/lang/String; = "com.google.android.gms.actions.extra.LIST_NAME"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final h:Ljava/lang/String; = "com.google.android.gms.actions.extra.LIST_QUERY"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final i:Ljava/lang/String; = "com.google.android.gms.actions.extra.ITEM_NAME"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final j:Ljava/lang/String; = "com.google.android.gms.actions.extra.ITEM_NAMES"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field

.field public static final k:Ljava/lang/String; = "com.google.android.gms.actions.extra.ITEM_QUERY"
    .annotation build Landroidx/annotation/o0;
    .end annotation
.end field


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method
