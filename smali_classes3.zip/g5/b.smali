.class public interface abstract Lg5/b;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a(Lg5/a;)V
    .param p1    # Lg5/a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
.end method
