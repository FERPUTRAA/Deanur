.class public Lg5/c;
.super Ljava/lang/Object;

# interfaces
.implements Lg5/b;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Lg5/a;)V
    .locals 3
    .param p1    # Lg5/a;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s-bo@o@ v/M~@~@~~@@o~ K~/t4 r~@u@m~ ~ fl@.o ~l~in~ o@f~bb@~o~@  @ @ @ ~@1~t@i ~ i~saS@~~y  d@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Lcom/google/firebase/crashlytics/internal/f;->f()Lcom/google/firebase/crashlytics/internal/f;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "dafmenCer rbgoe onrs   clrbnarslosdmtehseivd.ett u"

    const-string/jumbo v0, "nes.tdlufcieCnmutho blr vaeegsrts rrdeo od arben s"

    const/4 v2, 0x2

    const-string v0, "Cu eotodvb agrmhrc etselnlernefrosudest . rd brina"

    const-string v0, "Could not register handler for breadcrumbs events."

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Lcom/google/firebase/crashlytics/internal/f;->b(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method
