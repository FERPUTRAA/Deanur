.class public Lh4/b;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public static A(Landroid/os/Parcel;ILandroid/util/SparseArray;Z)V
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/SparseArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Landroid/util/SparseArray<",
            "Ljava/lang/Float;",
            ">;Z)V"
        }
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x2

    move v3, v2

    if-nez p2, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz p3, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v2, 0x5

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p2}, Landroid/util/SparseArray;->size()I

    move-result p3

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-ge v0, p3, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p2, v0}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    invoke-virtual {p2, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    check-cast v1, Ljava/lang/Float;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeFloat(F)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_2
    const/4 v2, 0x0

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method public static B(Landroid/os/Parcel;ILandroid/os/IBinder;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/IBinder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    if-nez p2, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x3

    if-eqz p3, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    const/4 p2, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    const/4 v0, 0x5

    move v1, v0

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public static C(Landroid/os/Parcel;I[Landroid/os/IBinder;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Landroid/os/IBinder;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-nez p2, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    if-eqz p3, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/4 p2, 0x0

    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void

    :cond_1
    const/4 v1, 0x3

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeBinderArray([Landroid/os/IBinder;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public static D(Landroid/os/Parcel;ILjava/util/List;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Ljava/util/List<",
            "Landroid/os/IBinder;",
            ">;Z)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    if-nez p2, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-eqz p3, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p2, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void

    :cond_1
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeBinderList(Ljava/util/List;)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public static E(Landroid/os/Parcel;ILandroid/util/SparseArray;Z)V
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/SparseArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Landroid/util/SparseArray<",
            "Landroid/os/IBinder;",
            ">;Z)V"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez p2, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz p3, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p2}, Landroid/util/SparseArray;->size()I

    move-result p3

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ge v0, p3, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p2, v0}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p2, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    check-cast v1, Landroid/os/IBinder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_0

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public static F(Landroid/os/Parcel;II)V
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public static G(Landroid/os/Parcel;I[IZ)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [I
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    if-nez p2, :cond_1

    const/4 v1, 0x0

    if-eqz p3, :cond_0

    const/4 v0, 0x4

    xor-int/2addr v1, v0

    const/4 p2, 0x0

    move v1, p2

    const/4 v0, 0x3

    xor-int/2addr v1, v0

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void

    :cond_1
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeIntArray([I)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public static H(Landroid/os/Parcel;ILjava/util/List;Z)V
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Ljava/util/List<",
            "Ljava/lang/Integer;",
            ">;Z)V"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez p2, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p3, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v3, 0x4

    if-ge v0, p3, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    check-cast v1, Ljava/lang/Integer;

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :cond_2
    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method public static I(Landroid/os/Parcel;ILjava/lang/Integer;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Integer;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    if-nez p2, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-eqz p3, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/4 p2, 0x0

    const/4 v0, 0x5

    move v1, v0

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void

    :cond_1
    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    const/4 p3, 0x4

    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-static {p0, p1, p3}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public static J(Landroid/os/Parcel;ILjava/util/List;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    if-nez p2, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x0

    if-eqz p3, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 p2, 0x0

    shr-int/2addr v1, p2

    const/4 v0, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void

    :cond_1
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeList(Ljava/util/List;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public static K(Landroid/os/Parcel;IJ)V
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/16 v0, 0x8

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v2, 0x1

    invoke-virtual {p0, p2, p3}, Landroid/os/Parcel;->writeLong(J)V

    const/4 v2, 0x7

    return-void
.end method

.method public static L(Landroid/os/Parcel;I[JZ)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [J
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    if-nez p2, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    if-eqz p3, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 p2, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x5

    return-void

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeLongArray([J)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    return-void
.end method

.method public static M(Landroid/os/Parcel;ILjava/util/List;Z)V
    .locals 5
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;Z)V"
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x6

    if-nez p2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eqz p3, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-ge v0, p3, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    check-cast v1, Ljava/lang/Long;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void
.end method

.method public static N(Landroid/os/Parcel;ILjava/lang/Long;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Long;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x4

    if-nez p2, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    if-eqz p3, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 p2, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void

    :cond_1
    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/16 p3, 0x8

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p0, p1, p3}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p2}, Ljava/lang/Long;->longValue()J

    move-result-wide p1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1, p2}, Landroid/os/Parcel;->writeLong(J)V

    const/4 v0, 0x7

    move v1, v0

    return-void
.end method

.method public static O(Landroid/os/Parcel;ILandroid/os/Parcel;Z)V
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x1

    if-nez p2, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-eqz p3, :cond_0

    const/4 v1, 0x5

    move v2, v1

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void

    :cond_1
    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p2}, Landroid/os/Parcel;->dataSize()I

    move-result p3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, p2, v0, p3}, Landroid/os/Parcel;->appendFrom(Landroid/os/Parcel;II)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public static P(Landroid/os/Parcel;I[Landroid/os/Parcel;Z)V
    .locals 6
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v0, 0x0

    const/4 v5, 0x1

    if-nez p2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eqz p3, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v5, 0x7

    return-void

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    array-length p3, p2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    move v1, v0

    const/4 v5, 0x1

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-ge v1, p3, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    aget-object v2, p2, v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v2, :cond_2

    invoke-virtual {v2}, Landroid/os/Parcel;->dataSize()I

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0, v3}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v2}, Landroid/os/Parcel;->dataSize()I

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p0, v2, v0, v3}, Landroid/os/Parcel;->appendFrom(Landroid/os/Parcel;II)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_1

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto :goto_0

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-void
.end method

.method public static Q(Landroid/os/Parcel;ILjava/util/List;Z)V
    .locals 6
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Ljava/util/List<",
            "Landroid/os/Parcel;",
            ">;Z)V"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v0, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez p2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz p3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    return-void

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    move v1, v0

    move v1, v0

    const/4 v5, 0x4

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ge v1, p3, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {p2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    check-cast v2, Landroid/os/Parcel;

    const/4 v5, 0x4

    if-eqz v2, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v2}, Landroid/os/Parcel;->dataSize()I

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0, v3}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2}, Landroid/os/Parcel;->dataSize()I

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0, v2, v0, v3}, Landroid/os/Parcel;->appendFrom(Landroid/os/Parcel;II)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_0

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v4, 0x6

    const/4 v4, 0x6

    return-void
.end method

.method public static R(Landroid/os/Parcel;ILandroid/util/SparseArray;Z)V
    .locals 6
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/SparseArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Landroid/util/SparseArray<",
            "Landroid/os/Parcel;",
            ">;Z)V"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v0, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-nez p2, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz p3, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-void

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p2}, Landroid/util/SparseArray;->size()I

    move-result p3

    const/4 v4, 0x1

    shr-int/2addr v5, v4

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v5, 0x2

    if-ge v1, p3, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p2, v1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p0, v2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-virtual {p2, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    check-cast v2, Landroid/os/Parcel;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-eqz v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v2}, Landroid/os/Parcel;->dataSize()I

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0, v3}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v2}, Landroid/os/Parcel;->dataSize()I

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0, v2, v0, v3}, Landroid/os/Parcel;->appendFrom(Landroid/os/Parcel;II)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_1

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-void
.end method

.method public static S(Landroid/os/Parcel;ILandroid/os/Parcelable;IZ)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Parcelable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x4

    if-nez p2, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    if-eqz p4, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p2, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void

    :cond_1
    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x2

    invoke-interface {p2, p0, p3}, Landroid/os/Parcelable;->writeToParcel(Landroid/os/Parcel;I)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public static T(Landroid/os/Parcel;ILandroid/app/PendingIntent;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/app/PendingIntent;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    if-nez p2, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    if-eqz p3, :cond_0

    const/4 v0, 0x4

    move v1, v0

    const/4 p2, 0x0

    move v1, p2

    const/4 v0, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void

    :cond_1
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p2, p0}, Landroid/app/PendingIntent;->writePendingIntentOrNullToParcel(Landroid/app/PendingIntent;Landroid/os/Parcel;)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public static U(Landroid/os/Parcel;IS)V
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 v0, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x1

    move v2, v1

    return-void
.end method

.method public static V(Landroid/os/Parcel;ILandroid/util/SparseBooleanArray;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/SparseBooleanArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    if-nez p2, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    if-eqz p3, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    const/4 p2, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void

    :cond_1
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeSparseBooleanArray(Landroid/util/SparseBooleanArray;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static W(Landroid/os/Parcel;ILandroid/util/SparseIntArray;Z)V
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/SparseIntArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez p2, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz p3, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p2}, Landroid/util/SparseIntArray;->size()I

    move-result p3

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-ge v0, p3, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p2, v0}, Landroid/util/SparseIntArray;->keyAt(I)I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    invoke-virtual {p2, v0}, Landroid/util/SparseIntArray;->valueAt(I)I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public static X(Landroid/os/Parcel;ILandroid/util/SparseLongArray;Z)V
    .locals 5
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/SparseLongArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-nez p2, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz p3, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v3, 0x5

    move v4, v3

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p2}, Landroid/util/SparseLongArray;->size()I

    move-result p3

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-ge v0, p3, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p2, v0}, Landroid/util/SparseLongArray;->keyAt(I)I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x1

    invoke-virtual {p2, v0}, Landroid/util/SparseLongArray;->valueAt(I)J

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p0, v1, v2}, Landroid/os/Parcel;->writeLong(J)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method

.method public static Y(Landroid/os/Parcel;ILjava/lang/String;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    if-nez p2, :cond_1

    const/4 v0, 0x7

    and-int/2addr v1, v0

    if-eqz p3, :cond_0

    const/4 v0, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    const/4 p2, 0x0

    const/4 v1, 0x6

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void

    :cond_1
    const/4 v1, 0x2

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public static Z(Landroid/os/Parcel;I[Ljava/lang/String;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    if-nez p2, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    if-eqz p3, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    const/4 p2, 0x0

    const/4 v0, 0x5

    move v1, v0

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void

    :cond_1
    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeStringArray([Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Landroid/os/Parcel;)I
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/16 v0, 0x4f45

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    return p0
.end method

.method public static a0(Landroid/os/Parcel;ILjava/util/List;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    if-nez p2, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x5

    if-eqz p3, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    const/4 p2, 0x0

    const/4 v0, 0x4

    move v1, v0

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x3

    return-void

    :cond_1
    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeStringList(Ljava/util/List;)V

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public static b(Landroid/os/Parcel;I)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static b0(Landroid/os/Parcel;ILandroid/util/SparseArray;Z)V
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/SparseArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Landroid/util/SparseArray<",
            "Ljava/lang/String;",
            ">;Z)V"
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x5

    move v2, v0

    move v2, v0

    const/4 v3, 0x3

    if-nez p2, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz p3, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p2}, Landroid/util/SparseArray;->size()I

    move-result p3

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-ge v0, p3, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p2, v0}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p2, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    check-cast v1, Ljava/lang/String;

    const/4 v3, 0x2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :cond_2
    const/4 v3, 0x2

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method public static c(Landroid/os/Parcel;ILjava/math/BigDecimal;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/math/BigDecimal;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    if-nez p2, :cond_1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-eqz p3, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    const/4 p2, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x1

    return-void

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p2}, Ljava/math/BigDecimal;->unscaledValue()Ljava/math/BigInteger;

    move-result-object p3

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p3}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object p3

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeByteArray([B)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p2}, Ljava/math/BigDecimal;->scale()I

    move-result p2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v0, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-void
.end method

.method public static c0(Landroid/os/Parcel;I[Landroid/os/Parcelable;IZ)V
    .locals 5
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Landroid/os/Parcelable;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Landroid/os/Parcelable;",
            ">(",
            "Landroid/os/Parcel;",
            "I[TT;IZ)V"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x5

    if-nez p2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz p4, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    array-length p4, p2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0, p4}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-ge v1, p4, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    aget-object v2, p2, v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-nez v2, :cond_2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_1

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p0, v2, p3}, Lh4/b;->i0(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    goto :goto_0

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void
.end method

.method public static d(Landroid/os/Parcel;I[Ljava/math/BigDecimal;Z)V
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Ljava/math/BigDecimal;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    move v3, v2

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez p2, :cond_1

    const/4 v3, 0x7

    if-eqz p3, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    array-length p3, p2

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-ge v0, p3, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x2

    aget-object v1, p2, v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/math/BigDecimal;->unscaledValue()Ljava/math/BigInteger;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v1}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeByteArray([B)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    aget-object v1, p2, v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v1}, Ljava/math/BigDecimal;->scale()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x2

    goto :goto_0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public static d0(Landroid/os/Parcel;ILjava/util/List;Z)V
    .locals 5
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Landroid/os/Parcelable;",
            ">(",
            "Landroid/os/Parcel;",
            "I",
            "Ljava/util/List<",
            "TT;>;Z)V"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-nez p2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz p3, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-void

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x5

    const/4 v3, 0x4

    move v1, v0

    move v1, v0

    const/4 v4, 0x3

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-ge v1, p3, :cond_3

    const/4 v4, 0x1

    invoke-interface {p2, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    check-cast v2, Landroid/os/Parcelable;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-nez v2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_1

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p0, v2, v0}, Lh4/b;->i0(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    :goto_1
    const/4 v3, 0x4

    move v4, v3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    goto :goto_0

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void
.end method

.method public static e(Landroid/os/Parcel;ILjava/math/BigInteger;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/math/BigInteger;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-nez p2, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    if-eqz p3, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p2, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void

    :cond_1
    const/4 v1, 0x5

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p2}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object p2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeByteArray([B)V

    const/4 v1, 0x2

    const/4 v0, 0x0

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static e0(Landroid/os/Parcel;ILandroid/util/SparseArray;Z)V
    .locals 5
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/SparseArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Landroid/os/Parcelable;",
            ">(",
            "Landroid/os/Parcel;",
            "I",
            "Landroid/util/SparseArray<",
            "TT;>;Z)V"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x2

    if-nez p2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz p3, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    return-void

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p2}, Landroid/util/SparseArray;->size()I

    move-result p3

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    move v1, v0

    move v1, v0

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-ge v1, p3, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {p2, v1}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0, v2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p2, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    check-cast v2, Landroid/os/Parcelable;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-nez v2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_1

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-static {p0, v2, v0}, Lh4/b;->i0(Landroid/os/Parcel;Landroid/os/Parcelable;I)V

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_0

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method

.method public static f(Landroid/os/Parcel;I[Ljava/math/BigInteger;Z)V
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Ljava/math/BigInteger;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez p2, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz p3, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    return-void

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    array-length p3, p2

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-ge v0, p3, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    aget-object v1, p2, v0

    invoke-virtual {v1}, Ljava/math/BigInteger;->toByteArray()[B

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeByteArray([B)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method private static f0(Landroid/os/Parcel;I)I
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    const/high16 v0, -0x10000

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    or-int/2addr p1, v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p0
.end method

.method public static g(Landroid/os/Parcel;IZ)V
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x4

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v2, 0x1

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method private static g0(Landroid/os/Parcel;I)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    sub-int v1, v0, p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    add-int/lit8 p1, p1, -0x4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method public static h(Landroid/os/Parcel;I[ZZ)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Z
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-nez p2, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-eqz p3, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 p2, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeBooleanArray([Z)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x6

    return-void
.end method

.method private static h0(Landroid/os/Parcel;II)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    shl-int/lit8 p2, p2, 0x10

    const/4 v1, 0x0

    const/4 v0, 0x6

    or-int/2addr p1, p2

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public static i(Landroid/os/Parcel;ILjava/util/List;Z)V
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Ljava/util/List<",
            "Ljava/lang/Boolean;",
            ">;Z)V"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez p2, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz p3, :cond_0

    const/4 v3, 0x0

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    return-void

    :cond_1
    const/4 v3, 0x6

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-ge v0, p3, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    check-cast v1, Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method private static i0(Landroid/os/Parcel;Landroid/os/Parcelable;I)V
    .locals 4

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-interface {p1, p0, p2}, Landroid/os/Parcelable;->writeToParcel(Landroid/os/Parcel;I)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    sub-int p2, p1, v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public static j(Landroid/os/Parcel;ILjava/lang/Boolean;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Boolean;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x4

    if-nez p2, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    if-eqz p3, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 p2, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void

    :cond_1
    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p3, 0x4

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-static {p0, p1, p3}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-virtual {p2}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public static k(Landroid/os/Parcel;ILandroid/os/Bundle;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x1

    const/4 v0, 0x0

    if-nez p2, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-eqz p3, :cond_0

    const/4 v1, 0x4

    const/4 p2, 0x0

    shl-int/2addr v0, p2

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void

    :cond_1
    const/4 v1, 0x1

    const/4 v0, 0x2

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public static l(Landroid/os/Parcel;IB)V
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public static m(Landroid/os/Parcel;I[BZ)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [B
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    if-nez p2, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    if-eqz p3, :cond_0

    const/4 v1, 0x4

    const/4 p2, 0x0

    xor-int/2addr v0, p2

    const/4 v1, 0x5

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeByteArray([B)V

    const/4 v0, 0x2

    move v1, v0

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public static n(Landroid/os/Parcel;I[[BZ)V
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [[B
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez p2, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz p3, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    array-length p3, p2

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-ge v0, p3, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    aget-object v1, p2, v0

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeByteArray([B)V

    const/4 v3, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    goto :goto_0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-void
.end method

.method public static o(Landroid/os/Parcel;ILandroid/util/SparseArray;Z)V
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/SparseArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Landroid/util/SparseArray<",
            "[B>;Z)V"
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    if-nez p2, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz p3, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p2}, Landroid/util/SparseArray;->size()I

    move-result p3

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v3, 0x3

    if-ge v0, p3, :cond_2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p2, v0}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p2, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    check-cast v1, [B

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeByteArray([B)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_2
    const/4 v2, 0x7

    move v3, v2

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method public static p(Landroid/os/Parcel;IC)V
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public static q(Landroid/os/Parcel;I[CZ)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [C
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    if-nez p2, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    if-eqz p3, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    const/4 p2, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void

    :cond_1
    const/4 v1, 0x5

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeCharArray([C)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    return-void
.end method

.method public static r(Landroid/os/Parcel;ID)V
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/16 v0, 0x8

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0, p2, p3}, Landroid/os/Parcel;->writeDouble(D)V

    const/4 v2, 0x7

    return-void
.end method

.method public static s(Landroid/os/Parcel;I[DZ)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [D
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    if-nez p2, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-eqz p3, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    const/4 p2, 0x0

    const/4 v0, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void

    :cond_1
    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeDoubleArray([D)V

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public static t(Landroid/os/Parcel;ILjava/util/List;Z)V
    .locals 5
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Ljava/util/List<",
            "Ljava/lang/Double;",
            ">;Z)V"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 v0, 0x0

    if-nez p2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz p3, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-void

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v4, 0x6

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-ge v0, p3, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    check-cast v1, Ljava/lang/Double;

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0, v1, v2}, Landroid/os/Parcel;->writeDouble(D)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    goto :goto_0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void
.end method

.method public static u(Landroid/os/Parcel;ILjava/lang/Double;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Double;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    if-nez p2, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    if-eqz p3, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p2, 0x0

    const/4 v0, 0x4

    move v1, v0

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void

    :cond_1
    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    const/16 p3, 0x8

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0, p1, p3}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p2}, Ljava/lang/Double;->doubleValue()D

    move-result-wide p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0, p1, p2}, Landroid/os/Parcel;->writeDouble(D)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public static v(Landroid/os/Parcel;ILandroid/util/SparseArray;Z)V
    .locals 5
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/util/SparseArray;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Landroid/util/SparseArray<",
            "Ljava/lang/Double;",
            ">;Z)V"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-nez p2, :cond_1

    const/4 v4, 0x7

    if-eqz p3, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v4, 0x5

    return-void

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p2}, Landroid/util/SparseArray;->size()I

    move-result p3

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-ge v0, p3, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p2, v0}, Landroid/util/SparseArray;->keyAt(I)I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p2, v0}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    check-cast v1, Ljava/lang/Double;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/Double;->doubleValue()D

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0, v1, v2}, Landroid/os/Parcel;->writeDouble(D)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-void
.end method

.method public static w(Landroid/os/Parcel;IF)V
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeFloat(F)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public static x(Landroid/os/Parcel;I[FZ)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [F
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    if-nez p2, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x5

    if-eqz p3, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 p2, 0x5

    const/4 p2, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void

    :cond_1
    const/4 v0, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->writeFloatArray([F)V

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    return-void
.end method

.method public static y(Landroid/os/Parcel;ILjava/util/List;Z)V
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I",
            "Ljava/util/List<",
            "Ljava/lang/Float;",
            ">;Z)V"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez p2, :cond_1

    const/4 v3, 0x0

    if-eqz p3, :cond_0

    const/4 v3, 0x7

    invoke-static {p0, p1, v0}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p0, p1}, Lh4/b;->f0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {p2}, Ljava/util/List;->size()I

    move-result p3

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0, p3}, Landroid/os/Parcel;->writeInt(I)V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-ge v0, p3, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-interface {p2, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    check-cast v1, Ljava/lang/Float;

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/Float;->floatValue()F

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0, v1}, Landroid/os/Parcel;->writeFloat(F)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, p1}, Lh4/b;->g0(Landroid/os/Parcel;I)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method public static z(Landroid/os/Parcel;ILjava/lang/Float;Z)V
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Float;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    if-nez p2, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    if-eqz p3, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    const/4 p2, 0x0

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p0, p1, p2}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void

    :cond_1
    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/4 p3, 0x4

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-static {p0, p1, p3}, Lh4/b;->h0(Landroid/os/Parcel;II)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p2}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0, p1}, Landroid/os/Parcel;->writeFloat(F)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method
