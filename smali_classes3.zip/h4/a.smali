.class public Lh4/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lh4/a$a;
    }
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static A(Landroid/os/Parcel;I)Ljava/util/ArrayList;
    .locals 10
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Ljava/util/ArrayList<",
            "Landroid/os/Parcel;",
            ">;"
        }
    .end annotation

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    const/4 v1, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-nez p1, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    return-object v1

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    new-instance v3, Ljava/util/ArrayList;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-direct {v3}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    const/4 v4, 0x0

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x1

    if-ge v4, v2, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v5

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz v5, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v6

    const/4 v9, 0x3

    const/4 v8, 0x6

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v7

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v7, p0, v6, v5}, Landroid/os/Parcel;->appendFrom(Landroid/os/Parcel;II)V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v3, v7}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    add-int/2addr v6, v5

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p0, v6}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_1

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x4

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    goto :goto_0

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    add-int/2addr v0, p1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    return-object v3
.end method

.method public static B(Landroid/os/Parcel;I)Landroid/util/SparseArray;
    .locals 11
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Landroid/util/SparseArray<",
            "Landroid/os/Parcel;",
            ">;"
        }
    .end annotation

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    const/4 v1, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    if-nez p1, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    return-object v1

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    new-instance v3, Landroid/util/SparseArray;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-direct {v3}, Landroid/util/SparseArray;-><init>()V

    const/4 v10, 0x6

    const/4 v4, 0x1

    const/4 v10, 0x7

    const/4 v4, 0x0

    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-ge v4, v2, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v5

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v6

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-eqz v6, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v7

    const/4 v10, 0x2

    const/4 v9, 0x0

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v8

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v8, p0, v7, v6}, Landroid/os/Parcel;->appendFrom(Landroid/os/Parcel;II)V

    const/4 v9, 0x5

    move v10, v9

    invoke-virtual {v3, v5, v8}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    add-int/2addr v7, v6

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {p0, v7}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    goto :goto_1

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {v3, v5, v1}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    :goto_1
    const/4 v9, 0x3

    const/4 v10, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x5

    xor-int/2addr v10, v9

    goto :goto_0

    :cond_2
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    add-int/2addr v0, p1

    const/4 v9, 0x6

    move v10, v9

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    return-object v3
.end method

.method public static C(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/os/Parcelable;
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Parcelable$Creator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Landroid/os/Parcelable;",
            ">(",
            "Landroid/os/Parcel;",
            "I",
            "Landroid/os/Parcelable$Creator<",
            "TT;>;)TT;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 p0, 0x0

    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-interface {p2, p0}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    check-cast p2, Landroid/os/Parcelable;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    add-int/2addr v0, p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p2
.end method

.method public static D(Landroid/os/Parcel;I)Landroid/util/SparseBooleanArray;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->readSparseBooleanArray()Landroid/util/SparseBooleanArray;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    add-int/2addr v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-object v1
.end method

.method public static E(Landroid/os/Parcel;I)Landroid/util/SparseIntArray;
    .locals 8
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-nez p1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 p0, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-object p0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-instance v1, Landroid/util/SparseIntArray;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-direct {v1}, Landroid/util/SparseIntArray;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-ge v3, v2, :cond_1

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v5

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v1, v4, v5}, Landroid/util/SparseIntArray;->append(II)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x7

    move v7, v6

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    add-int/2addr v0, p1

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-object v1
.end method

.method public static F(Landroid/os/Parcel;I)Landroid/util/SparseLongArray;
    .locals 9
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-nez p1, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 p0, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    return-object p0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-instance v1, Landroid/util/SparseLongArray;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {v1}, Landroid/util/SparseLongArray;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v3, 0x0

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x4

    if-ge v3, v2, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v4

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->readLong()J

    move-result-wide v5

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v1, v4, v5, v6}, Landroid/util/SparseLongArray;->append(IJ)V

    const/4 v8, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    goto :goto_0

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    add-int/2addr v0, p1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-object v1
.end method

.method public static G(Landroid/os/Parcel;I)Ljava/lang/String;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 p0, 0x0

    move v3, p0

    const/4 v2, 0x2

    move v3, v2

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    add-int/2addr v0, p1

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v2, 0x1

    const/4 v2, 0x4

    return-object v1
.end method

.method public static H(Landroid/os/Parcel;I)[Ljava/lang/String;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->createStringArray()[Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    add-int/2addr v0, p1

    const/4 v3, 0x3

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v1
.end method

.method public static I(Landroid/os/Parcel;I)Ljava/util/ArrayList;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->createStringArrayList()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    add-int/2addr v0, p1

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object v1
.end method

.method public static J(Landroid/os/Parcel;I)Landroid/util/SparseArray;
    .locals 8
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Landroid/util/SparseArray<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-nez p1, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 p0, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    return-object p0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    new-instance v1, Landroid/util/SparseArray;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    const/4 v6, 0x4

    move v7, v6

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-ge v3, v2, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v1, v4, v5}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    goto :goto_0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    add-int/2addr v0, p1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    return-object v1
.end method

.method public static K(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)[Ljava/lang/Object;
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Parcelable$Creator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/os/Parcel;",
            "I",
            "Landroid/os/Parcelable$Creator<",
            "TT;>;)[TT;"
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->createTypedArray(Landroid/os/Parcelable$Creator;)[Ljava/lang/Object;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    add-int/2addr v0, p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object p2
.end method

.method public static L(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Ljava/util/ArrayList;
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Parcelable$Creator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/os/Parcel;",
            "I",
            "Landroid/os/Parcelable$Creator<",
            "TT;>;)",
            "Ljava/util/ArrayList<",
            "TT;>;"
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v1, 0x2

    and-int/2addr v2, v1

    const/4 p0, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, p2}, Landroid/os/Parcel;->createTypedArrayList(Landroid/os/Parcelable$Creator;)Ljava/util/ArrayList;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    add-int/2addr v0, p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v2, 0x3

    return-object p2
.end method

.method public static M(Landroid/os/Parcel;ILandroid/os/Parcelable$Creator;)Landroid/util/SparseArray;
    .locals 9
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/os/Parcelable$Creator;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Landroid/os/Parcel;",
            "I",
            "Landroid/os/Parcelable$Creator<",
            "TT;>;)",
            "Landroid/util/SparseArray<",
            "TT;>;"
        }
    .end annotation

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v1, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    if-nez p1, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x1

    return-object v1

    :cond_0
    const/4 v8, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    new-instance v3, Landroid/util/SparseArray;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-direct {v3}, Landroid/util/SparseArray;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v4, 0x0

    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-ge v4, v2, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v5

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v6

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz v6, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-interface {p2, p0}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v6

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    goto :goto_1

    :cond_1
    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    :goto_1
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v3, v5, v6}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    goto :goto_0

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    add-int/2addr v0, p1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    return-object v3
.end method

.method public static N(Landroid/os/Parcel;I)V
    .locals 5
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-ne v0, p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x7

    new-instance v0, Lh4/a$a;

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    move v4, v3

    const-string/jumbo v2, "sasvedeaizose wdrl=de lOre"

    const-string v2, "=sszaia edelrl drw eeoOedv"

    const/4 v4, 0x1

    const-string/jumbo v2, "izamwoelddldv resea=ne  Oe"

    const-string v2, "Overread allowed size end="

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v0, p1, p0}, Lh4/a$a;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    throw v0
.end method

.method public static O(I)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    int-to-char p0, p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return p0
.end method

.method public static P(Landroid/os/Parcel;I)Z
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-static {p0, p1, v0}, Lh4/a;->k0(Landroid/os/Parcel;II)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 p0, 0x1

    move v2, p0

    const/4 v1, 0x2

    move v2, v1

    return p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    return p0
.end method

.method public static Q(Landroid/os/Parcel;I)Ljava/lang/Boolean;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    move v3, v2

    invoke-static {p0, p1, v0, v1}, Lh4/a;->j0(Landroid/os/Parcel;III)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-eqz p0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 p0, 0x1

    const/4 v3, 0x7

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p0, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x1

    return-object p0
.end method

.method public static R(Landroid/os/Parcel;I)B
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x4

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p0, p1, v0}, Lh4/a;->k0(Landroid/os/Parcel;II)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    int-to-byte p0, p0

    const/4 v2, 0x7

    const/4 v1, 0x1

    return p0
.end method

.method public static S(Landroid/os/Parcel;I)C
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    or-int/2addr v2, v1

    invoke-static {p0, p1, v0}, Lh4/a;->k0(Landroid/os/Parcel;II)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    int-to-char p0, p0

    const/4 v2, 0x6

    const/4 v1, 0x0

    return p0
.end method

.method public static T(Landroid/os/Parcel;I)D
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/16 v0, 0x8

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p0, p1, v0}, Lh4/a;->k0(Landroid/os/Parcel;II)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->readDouble()D

    move-result-wide p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-wide p0
.end method

.method public static U(Landroid/os/Parcel;I)Ljava/lang/Double;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x7

    or-int/2addr v3, v2

    return-object p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/16 v1, 0x8

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p0, p1, v0, v1}, Lh4/a;->j0(Landroid/os/Parcel;III)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->readDouble()D

    move-result-wide p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    invoke-static {p0, p1}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0
.end method

.method public static V(Landroid/os/Parcel;I)F
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p0, p1, v0}, Lh4/a;->k0(Landroid/os/Parcel;II)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->readFloat()F

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return p0
.end method

.method public static W(Landroid/os/Parcel;I)Ljava/lang/Float;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v1, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p0, p1, v0, v1}, Lh4/a;->j0(Landroid/os/Parcel;III)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->readFloat()F

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p0}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object p0
.end method

.method public static X(Landroid/os/Parcel;)I
    .locals 2
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return p0
.end method

.method public static Y(Landroid/os/Parcel;I)Landroid/os/IBinder;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    add-int/2addr v0, p1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v1
.end method

.method public static Z(Landroid/os/Parcel;I)I
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x4

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, p1, v0}, Lh4/a;->k0(Landroid/os/Parcel;II)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    return p0
.end method

.method public static a(Landroid/os/Parcel;I)Ljava/math/BigDecimal;
    .locals 5
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 p0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-object p0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    add-int/2addr v0, p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    new-instance p0, Ljava/math/BigDecimal;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance p1, Ljava/math/BigInteger;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {p1, v1}, Ljava/math/BigInteger;-><init>([B)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p0, p1, v2}, Ljava/math/BigDecimal;-><init>(Ljava/math/BigInteger;I)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object p0
.end method

.method public static a0(Landroid/os/Parcel;I)Ljava/lang/Integer;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x6

    shl-int/2addr v3, v2

    const/4 p0, 0x4

    const/4 p0, 0x0

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p0, p1, v0, v1}, Lh4/a;->j0(Landroid/os/Parcel;III)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p0
.end method

.method public static b(Landroid/os/Parcel;I)[Ljava/math/BigDecimal;
    .locals 10
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-nez p1, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/4 p0, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x4

    return-object p0

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x2

    new-array v2, v1, [Ljava/math/BigDecimal;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v3, 0x2

    const/4 v3, 0x0

    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    if-ge v3, v1, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v5

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance v6, Ljava/math/BigDecimal;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    new-instance v7, Ljava/math/BigInteger;

    const/4 v9, 0x2

    invoke-direct {v7, v4}, Ljava/math/BigInteger;-><init>([B)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-direct {v6, v7, v5}, Ljava/math/BigDecimal;-><init>(Ljava/math/BigInteger;I)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    aput-object v6, v2, v3

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    goto :goto_0

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    add-int/2addr v0, p1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v9, 0x2

    const/4 v8, 0x3

    return-object v2
.end method

.method public static b0(Landroid/os/Parcel;ILjava/util/List;Ljava/lang/ClassLoader;)V
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/util/List;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/ClassLoader;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-nez p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, p2, p3}, Landroid/os/Parcel;->readList(Ljava/util/List;Ljava/lang/ClassLoader;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    add-int/2addr v0, p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public static c(Landroid/os/Parcel;I)Ljava/math/BigInteger;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    add-int/2addr v0, p1

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance p0, Ljava/math/BigInteger;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0, v1}, Ljava/math/BigInteger;-><init>([B)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object p0
.end method

.method public static c0(Landroid/os/Parcel;I)J
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/16 v0, 0x8

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0, p1, v0}, Lh4/a;->k0(Landroid/os/Parcel;II)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->readLong()J

    move-result-wide p0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-wide p0
.end method

.method public static d(Landroid/os/Parcel;I)[Ljava/math/BigInteger;
    .locals 8
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-nez p1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 p0, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    return-object p0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    new-array v2, v1, [Ljava/math/BigInteger;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-ge v3, v1, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    new-instance v4, Ljava/math/BigInteger;

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-direct {v4, v5}, Ljava/math/BigInteger;-><init>([B)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    aput-object v4, v2, v3

    const/4 v7, 0x0

    const/4 v6, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x0

    goto :goto_0

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    add-int/2addr v0, p1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    return-object v2
.end method

.method public static d0(Landroid/os/Parcel;I)Ljava/lang/Long;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/16 v1, 0x8

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p0, p1, v0, v1}, Lh4/a;->j0(Landroid/os/Parcel;III)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->readLong()J

    move-result-wide p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p0
.end method

.method public static e(Landroid/os/Parcel;I)[Z
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->createBooleanArray()[Z

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    add-int/2addr v0, p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    return-object v1
.end method

.method public static e0(Landroid/os/Parcel;I)Landroid/app/PendingIntent;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 p0, 0x0

    move v3, p0

    const/4 v2, 0x4

    move v3, v2

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p0}, Landroid/app/PendingIntent;->readPendingIntentOrNullFromParcel(Landroid/os/Parcel;)Landroid/app/PendingIntent;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    add-int/2addr v0, p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object v1
.end method

.method public static f(Landroid/os/Parcel;I)Ljava/util/ArrayList;
    .locals 8
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-nez p1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 p0, 0x0

    xor-int/2addr v7, p0

    return-object p0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    new-instance v1, Ljava/util/ArrayList;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    const/4 v3, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    move v4, v3

    move v4, v3

    const/4 v7, 0x2

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-ge v4, v2, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v5

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-eqz v5, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/4 v5, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto :goto_1

    :cond_1
    const/4 v7, 0x5

    move v5, v3

    move v5, v3

    const/4 v7, 0x2

    move v5, v3

    move v5, v3

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {v5}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v1, v5}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x1

    move v7, v6

    add-int/lit8 v4, v4, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_0

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    add-int/2addr v0, p1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    return-object v1
.end method

.method public static f0(Landroid/os/Parcel;I)S
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x4

    const/4 v2, 0x0

    invoke-static {p0, p1, v0}, Lh4/a;->k0(Landroid/os/Parcel;II)V

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x7

    int-to-short p0, p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return p0
.end method

.method public static g(Landroid/os/Parcel;I)Landroid/os/Bundle;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->readBundle()Landroid/os/Bundle;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    add-int/2addr v0, p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v1
.end method

.method public static g0(Landroid/os/Parcel;I)I
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/high16 v0, -0x10000

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    and-int v1, p1, v0

    const/4 v2, 0x0

    move v3, v2

    if-eq v1, v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    shr-int/lit8 p0, p1, 0x10

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    int-to-char p0, p0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    return p0

    :cond_0
    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x0

    return p0
.end method

.method public static h(Landroid/os/Parcel;I)[B
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    add-int/2addr v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v1
.end method

.method public static h0(Landroid/os/Parcel;I)V
    .locals 3
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    add-int/2addr v0, p1

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public static i(Landroid/os/Parcel;I)[[B
    .locals 7
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v5, 0x3

    move v6, v5

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-nez p1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 p0, 0x0

    const/4 v6, 0x7

    return-object p0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-array v2, v1, [[B

    const/4 v6, 0x3

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-ge v3, v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v4

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    aput-object v4, v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x6

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    add-int/2addr v0, p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    return-object v2
.end method

.method public static i0(Landroid/os/Parcel;)I
    .locals 7
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x3

    const/4 v5, 0x5

    invoke-static {p0}, Lh4/a;->X(Landroid/os/Parcel;)I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {p0, v0}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {v0}, Lh4/a;->O(I)I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/16 v4, 0x4f45

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-ne v2, v4, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    add-int/2addr v1, v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-lt v1, v3, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->dataSize()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-gt v1, v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    return v1

    :cond_0
    new-instance v0, Lh4/a$a;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v4, "ed eoSrt trail vamssid izin"

    const-string/jumbo v4, "st miavazadietl eS s rdirni"

    const/4 v6, 0x0

    const-string/jumbo v4, "r=stabneaiidv  eri tSais lz"

    const-string v4, "Size read is invalid start="

    const/4 v5, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    move v6, v5

    const-string/jumbo v3, "ou de"

    const-string v3, "d =eo"

    const/4 v6, 0x2

    const-string v3, "dep=n"

    const-string v3, " end="

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {v0, v1, p0}, Lh4/a$a;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    throw v0

    :cond_1
    const/4 v5, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    new-instance v1, Lh4/a$a;

    invoke-static {v0}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo v2, "o ebdGejqrdot x.ecep0Ebet haxc"

    const-string/jumbo v2, "jtpreb Ehd  edc0 .exxoctGeobea"

    const/4 v6, 0x7

    const-string/jumbo v2, "hts ceb j e0exc oGaeexdt.tdpoE"

    const-string v2, "Expected object header. Got 0x"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/String;->concat(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-direct {v1, v0, p0}, Lh4/a$a;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    throw v1
.end method

.method public static j(Landroid/os/Parcel;I)Landroid/util/SparseArray;
    .locals 8
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Landroid/util/SparseArray<",
            "[B>;"
        }
    .end annotation

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-nez p1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/4 p0, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    return-object p0

    :cond_0
    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-instance v2, Landroid/util/SparseArray;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct {v2, v1}, Landroid/util/SparseArray;-><init>(I)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    if-ge v3, v1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->createByteArray()[B

    move-result-object v5

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v2, v4, v5}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    add-int/2addr v0, p1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-object v2
.end method

.method private static j0(Landroid/os/Parcel;III)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-ne p2, p3, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    new-instance p1, Lh4/a$a;

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-static {p2}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v2, " eem sEceiputd"

    const-string v2, "cie s ueEetdxp"

    const/4 v4, 0x0

    const-string/jumbo v2, "psEeotxce ediz"

    const-string v2, "Expected size "

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const-string p3, "b tpg"

    const-string/jumbo p3, "gtp  "

    const/4 v4, 0x3

    const-string p3, " ugt "

    const-string p3, " got "

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string p2, " 0(x"

    const-string p2, " x(0"

    const/4 v4, 0x4

    const-string p2, "( 0x"

    const-string p2, " (0x"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const-string p2, ")"

    const-string p2, ")"

    const-string p2, ")"

    const-string p2, ")"

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {p1, p2, p0}, Lh4/a$a;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    const/4 v4, 0x1

    throw p1
.end method

.method public static k(Landroid/os/Parcel;I)[C
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v2, 0x0

    move v3, v2

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->createCharArray()[C

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    add-int/2addr v0, p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object v1
.end method

.method private static k0(Landroid/os/Parcel;II)V
    .locals 6

    const/4 v5, 0x7

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-ne p1, p2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance v0, Lh4/a$a;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    or-int/2addr v5, v4

    const-string v3, " eets zpciqxpE"

    const-string/jumbo v3, "tee  zdsqpxEic"

    const/4 v5, 0x4

    const-string/jumbo v3, "txde ziEq eecs"

    const-string v3, "Expected size "

    const/4 v5, 0x7

    const/4 v4, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo p2, "ots s"

    const-string p2, " ostg"

    const/4 v5, 0x7

    const-string/jumbo p2, "og m "

    const-string p2, " got "

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo p1, "x0( "

    const-string/jumbo p1, "x0( "

    const/4 v5, 0x1

    const-string p1, "(x 0"

    const-string p1, " (0x"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    shr-int/2addr v5, v4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string p1, ")"

    const-string p1, ")"

    const/4 v5, 0x0

    const-string p1, ")"

    const-string p1, ")"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v0, p1, p0}, Lh4/a$a;-><init>(Ljava/lang/String;Landroid/os/Parcel;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    throw v0
.end method

.method public static l(Landroid/os/Parcel;I)[D
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->createDoubleArray()[D

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    add-int/2addr v0, p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object v1
.end method

.method public static m(Landroid/os/Parcel;I)Ljava/util/ArrayList;
    .locals 8
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Double;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez p1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 p0, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    return-object p0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    new-instance v1, Ljava/util/ArrayList;

    const/4 v6, 0x2

    move v7, v6

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-ge v3, v2, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->readDouble()D

    move-result-wide v4

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {v4, v5}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_0

    :cond_1
    add-int/2addr v0, p1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    return-object v1
.end method

.method public static n(Landroid/os/Parcel;I)Landroid/util/SparseArray;
    .locals 9
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Landroid/util/SparseArray<",
            "Ljava/lang/Double;",
            ">;"
        }
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-nez p1, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 p0, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    return-object p0

    :cond_0
    const/4 v8, 0x7

    new-instance v1, Landroid/util/SparseArray;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    const/4 v7, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    const/4 v3, 0x0

    :goto_0
    const/4 v8, 0x2

    if-ge v3, v2, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v4

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->readDouble()D

    move-result-wide v5

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {v5, v6}, Ljava/lang/Double;->valueOf(D)Ljava/lang/Double;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v1, v4, v5}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    goto :goto_0

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x7

    add-int/2addr v0, p1

    const/4 v8, 0x1

    const/4 v7, 0x4

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    return-object v1
.end method

.method public static o(Landroid/os/Parcel;I)[F
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x1

    and-int/2addr v2, p0

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->createFloatArray()[F

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    add-int/2addr v0, p1

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v1
.end method

.method public static p(Landroid/os/Parcel;I)Ljava/util/ArrayList;
    .locals 7
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-nez p1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 p0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-object p0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v1, Ljava/util/ArrayList;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v3, 0x0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-ge v3, v2, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->readFloat()F

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v4}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x6

    move v6, v5

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    add-int/2addr v0, p1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-object v1
.end method

.method public static q(Landroid/os/Parcel;I)Landroid/util/SparseArray;
    .locals 8
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Landroid/util/SparseArray<",
            "Ljava/lang/Float;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v7, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-nez p1, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    const/4 p0, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    return-object p0

    :cond_0
    const/4 v7, 0x3

    new-instance v1, Landroid/util/SparseArray;

    const/4 v6, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-direct {v1}, Landroid/util/SparseArray;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-ge v3, v2, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->readFloat()F

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v5}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v1, v4, v5}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    add-int/2addr v0, p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    return-object v1
.end method

.method public static r(Landroid/os/Parcel;I)[Landroid/os/IBinder;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->createBinderArray()[Landroid/os/IBinder;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    add-int/2addr v0, p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v1
.end method

.method public static s(Landroid/os/Parcel;I)Ljava/util/ArrayList;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Ljava/util/ArrayList<",
            "Landroid/os/IBinder;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/os/Parcel;->createBinderArrayList()Ljava/util/ArrayList;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    add-int/2addr v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v1
.end method

.method public static t(Landroid/os/Parcel;I)Landroid/util/SparseArray;
    .locals 8
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Landroid/util/SparseArray<",
            "Landroid/os/IBinder;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-nez p1, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 p0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-object p0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance v2, Landroid/util/SparseArray;

    const/4 v6, 0x7

    or-int/2addr v7, v6

    invoke-direct {v2, v1}, Landroid/util/SparseArray;-><init>(I)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-ge v3, v1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v2, v4, v5}, Landroid/util/SparseArray;->append(ILjava/lang/Object;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x2

    move v7, v6

    goto :goto_0

    :cond_1
    const/4 v7, 0x7

    add-int/2addr v0, p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v6, 0x3

    const/4 v6, 0x6

    return-object v2
.end method

.method public static u(Landroid/os/Parcel;I)[I
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    if-nez p1, :cond_0

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object p0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->createIntArray()[I

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    add-int/2addr v0, p1

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v1
.end method

.method public static v(Landroid/os/Parcel;I)Ljava/util/ArrayList;
    .locals 7
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-nez p1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 p0, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    return-object p0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-instance v1, Ljava/util/ArrayList;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x3

    and-int/2addr v5, v3

    :goto_0
    const/4 v6, 0x1

    if-ge v3, v2, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v4

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x6

    move v6, v5

    add-int/lit8 v3, v3, 0x1

    const/4 v5, 0x1

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    add-int/2addr v0, p1

    const/4 v6, 0x6

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-object v1
.end method

.method public static w(Landroid/os/Parcel;I)[J
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->createLongArray()[J

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x6

    add-int/2addr v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v1
.end method

.method public static x(Landroid/os/Parcel;I)Ljava/util/ArrayList;
    .locals 8
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/os/Parcel;",
            "I)",
            "Ljava/util/ArrayList<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-nez p1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 p0, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-object p0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    new-instance v1, Ljava/util/ArrayList;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-ge v3, v2, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->readLong()J

    move-result-wide v4

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    goto :goto_0

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    add-int/2addr v0, p1

    const/4 v7, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-object v1
.end method

.method public static y(Landroid/os/Parcel;I)Landroid/os/Parcel;
    .locals 4
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 p0, 0x3

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v1, p0, v0, p1}, Landroid/os/Parcel;->appendFrom(Landroid/os/Parcel;II)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    add-int/2addr v0, p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v1
.end method

.method public static z(Landroid/os/Parcel;I)[Landroid/os/Parcel;
    .locals 10
    .param p0    # Landroid/os/Parcel;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/o0;
    .end annotation

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static {p0, p1}, Lh4/a;->g0(Landroid/os/Parcel;I)I

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/4 v1, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x0

    if-nez p1, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    return-object v1

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v2

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    new-array v3, v2, [Landroid/os/Parcel;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    const/4 v4, 0x0

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-ge v4, v2, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {p0}, Landroid/os/Parcel;->readInt()I

    move-result v5

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    if-eqz v5, :cond_1

    const/4 v8, 0x3

    move v9, v8

    invoke-virtual {p0}, Landroid/os/Parcel;->dataPosition()I

    move-result v6

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v7

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v7, p0, v6, v5}, Landroid/os/Parcel;->appendFrom(Landroid/os/Parcel;II)V

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    aput-object v7, v3, v4

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    add-int/2addr v6, v5

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {p0, v6}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    goto :goto_1

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    aput-object v1, v3, v4

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto :goto_0

    :cond_2
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    add-int/2addr v0, p1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p0, v0}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    return-object v3
.end method
