.class public Lh5/b;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)Lh5/a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b@soM o@fli~~@ r  ~~ i@4~~~of/@@  ntc@@ @sb1a@@@ov oi~~~@ ~lS~@oKu@~~m  y@@d~~~ ~ ~ bt@~@.-@~  /"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    invoke-static {}, Ljava/util/Collections;->emptyMap()Ljava/util/Map;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lh5/b;->b(Ljava/lang/String;Ljava/util/Map;)Lh5/a;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p1
.end method

.method public b(Ljava/lang/String;Ljava/util/Map;)Lh5/a;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Lh5/a;"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    new-instance v0, Lh5/a;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {v0, p1, p2}, Lh5/a;-><init>(Ljava/lang/String;Ljava/util/Map;)V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method
