.class public interface abstract Li5/e;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()Li5/c;
.end method

.method public abstract b()Li5/d;
.end method

.method public abstract c()J
.end method

.method public abstract d()I
.end method

.method public abstract e(J)Z
.end method

.method public abstract f()I
.end method
