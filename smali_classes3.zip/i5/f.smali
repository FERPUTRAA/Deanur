.class public Li5/f;
.super Ljava/lang/Object;

# interfaces
.implements Li5/e;


# instance fields
.field public final a:Li5/b;

.field public final b:Li5/d;

.field public final c:Li5/c;

.field public final d:J

.field public final e:I

.field public final f:I


# direct methods
.method public constructor <init>(JLi5/b;Li5/d;Li5/c;II)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-wide p1, p0, Li5/f;->d:J

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p3, p0, Li5/f;->a:Li5/b;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p4, p0, Li5/f;->b:Li5/d;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p5, p0, Li5/f;->c:Li5/c;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p6, p0, Li5/f;->e:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    iput p7, p0, Li5/f;->f:I

    const/4 v0, 0x2

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public a()Li5/c;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~bs~i@ ood~ lf t~ @i1 t cm@b~-uKa@~~ ~y~ @f 4 @i~~@M@@/~~n@  ~s~~r@@~  ~.@~ @ l@@~bovo@~S@o/@~o@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Li5/f;->c:Li5/c;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public b()Li5/d;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Li5/f;->b:Li5/d;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public c()J
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-wide v0, p0, Li5/f;->d:J

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-wide v0
.end method

.method public d()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, p0, Li5/f;->f:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public e(J)Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-wide v0, p0, Li5/f;->d:J

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    cmp-long p1, v0, p1

    const/4 v2, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-gez p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return p1
.end method

.method public f()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    iget v0, p0, Li5/f;->e:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public g()Li5/b;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Li5/f;->a:Li5/b;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method
