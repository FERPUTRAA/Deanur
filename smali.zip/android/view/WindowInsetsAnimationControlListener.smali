.class public interface abstract synthetic Landroid/view/WindowInsetsAnimationControlListener;
.super Ljava/lang/Object;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/NoClassDefFoundError;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/lang/NoClassDefFoundError;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    throw v0
.end method
