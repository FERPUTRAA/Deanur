.class public interface abstract synthetic Landroid/view/OnReceiveContentListener;
.super Ljava/lang/Object;


# direct methods
.method static synthetic constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Ljava/lang/NoClassDefFoundError;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/lang/NoClassDefFoundError;-><init>()V

    const/4 v2, 0x7

    throw v0
.end method
