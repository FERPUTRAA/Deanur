.class public final Landroid/support/v4/media/MediaMetadataCompat;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/v4/media/MediaMetadataCompat$Builder;,
        Landroid/support/v4/media/MediaMetadataCompat$RatingKey;,
        Landroid/support/v4/media/MediaMetadataCompat$BitmapKey;,
        Landroid/support/v4/media/MediaMetadataCompat$LongKey;,
        Landroid/support/v4/media/MediaMetadataCompat$TextKey;
    }
.end annotation


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Landroid/support/v4/media/MediaMetadataCompat;",
            ">;"
        }
    .end annotation
.end field

.field static final METADATA_KEYS_TYPE:Landroidx/collection/a;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroidx/collection/a<",
            "Ljava/lang/String;",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation
.end field

.field public static final METADATA_KEY_ADVERTISEMENT:Ljava/lang/String; = "android.media.metadata.ADVERTISEMENT"

.field public static final METADATA_KEY_ALBUM:Ljava/lang/String; = "android.media.metadata.ALBUM"

.field public static final METADATA_KEY_ALBUM_ART:Ljava/lang/String; = "android.media.metadata.ALBUM_ART"

.field public static final METADATA_KEY_ALBUM_ARTIST:Ljava/lang/String; = "android.media.metadata.ALBUM_ARTIST"

.field public static final METADATA_KEY_ALBUM_ART_URI:Ljava/lang/String; = "android.media.metadata.ALBUM_ART_URI"

.field public static final METADATA_KEY_ART:Ljava/lang/String; = "android.media.metadata.ART"

.field public static final METADATA_KEY_ARTIST:Ljava/lang/String; = "android.media.metadata.ARTIST"

.field public static final METADATA_KEY_ART_URI:Ljava/lang/String; = "android.media.metadata.ART_URI"

.field public static final METADATA_KEY_AUTHOR:Ljava/lang/String; = "android.media.metadata.AUTHOR"

.field public static final METADATA_KEY_BT_FOLDER_TYPE:Ljava/lang/String; = "android.media.metadata.BT_FOLDER_TYPE"

.field public static final METADATA_KEY_COMPILATION:Ljava/lang/String; = "android.media.metadata.COMPILATION"

.field public static final METADATA_KEY_COMPOSER:Ljava/lang/String; = "android.media.metadata.COMPOSER"

.field public static final METADATA_KEY_DATE:Ljava/lang/String; = "android.media.metadata.DATE"

.field public static final METADATA_KEY_DISC_NUMBER:Ljava/lang/String; = "android.media.metadata.DISC_NUMBER"

.field public static final METADATA_KEY_DISPLAY_DESCRIPTION:Ljava/lang/String; = "android.media.metadata.DISPLAY_DESCRIPTION"

.field public static final METADATA_KEY_DISPLAY_ICON:Ljava/lang/String; = "android.media.metadata.DISPLAY_ICON"

.field public static final METADATA_KEY_DISPLAY_ICON_URI:Ljava/lang/String; = "android.media.metadata.DISPLAY_ICON_URI"

.field public static final METADATA_KEY_DISPLAY_SUBTITLE:Ljava/lang/String; = "android.media.metadata.DISPLAY_SUBTITLE"

.field public static final METADATA_KEY_DISPLAY_TITLE:Ljava/lang/String; = "android.media.metadata.DISPLAY_TITLE"

.field public static final METADATA_KEY_DOWNLOAD_STATUS:Ljava/lang/String; = "android.media.metadata.DOWNLOAD_STATUS"

.field public static final METADATA_KEY_DURATION:Ljava/lang/String; = "android.media.metadata.DURATION"

.field public static final METADATA_KEY_GENRE:Ljava/lang/String; = "android.media.metadata.GENRE"

.field public static final METADATA_KEY_MEDIA_ID:Ljava/lang/String; = "android.media.metadata.MEDIA_ID"

.field public static final METADATA_KEY_MEDIA_URI:Ljava/lang/String; = "android.media.metadata.MEDIA_URI"

.field public static final METADATA_KEY_NUM_TRACKS:Ljava/lang/String; = "android.media.metadata.NUM_TRACKS"

.field public static final METADATA_KEY_RATING:Ljava/lang/String; = "android.media.metadata.RATING"

.field public static final METADATA_KEY_TITLE:Ljava/lang/String; = "android.media.metadata.TITLE"

.field public static final METADATA_KEY_TRACK_NUMBER:Ljava/lang/String; = "android.media.metadata.TRACK_NUMBER"

.field public static final METADATA_KEY_USER_RATING:Ljava/lang/String; = "android.media.metadata.USER_RATING"

.field public static final METADATA_KEY_WRITER:Ljava/lang/String; = "android.media.metadata.WRITER"

.field public static final METADATA_KEY_YEAR:Ljava/lang/String; = "android.media.metadata.YEAR"

.field static final METADATA_TYPE_BITMAP:I = 0x2

.field static final METADATA_TYPE_LONG:I = 0x0

.field static final METADATA_TYPE_RATING:I = 0x3

.field static final METADATA_TYPE_TEXT:I = 0x1

.field private static final PREFERRED_BITMAP_ORDER:[Ljava/lang/String;

.field private static final PREFERRED_DESCRIPTION_ORDER:[Ljava/lang/String;

.field private static final PREFERRED_URI_ORDER:[Ljava/lang/String;

.field private static final TAG:Ljava/lang/String; = "MediaMetadata"


# instance fields
.field final mBundle:Landroid/os/Bundle;

.field private mDescription:Landroid/support/v4/media/MediaDescriptionCompat;

.field private mMetadataObj:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Landroidx/collection/a;

    invoke-direct {v0}, Landroidx/collection/a;-><init>()V

    sput-object v0, Landroid/support/v4/media/MediaMetadataCompat;->METADATA_KEYS_TYPE:Landroidx/collection/a;

    const/4 v1, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v2, "dIsettLiansaEdr.aieo..mTmdaT"

    const-string/jumbo v2, "omsL.nTrtda.aimIaaEeddeTa.ti"

    const-string v2, "ed.miiaaLImettaTm.E.nadradoT"

    const-string v2, "android.media.metadata.TITLE"

    invoke-virtual {v0, v2, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "aTdeoeomiaAtrdmimSRaT..Inatad"

    const-string/jumbo v2, "iadmatSnaT.tmeoadirRIeaA..dTm"

    const-string v2, ".dTdSbiIa.emr.naaaAtTomeaRtdd"

    const-string v2, "android.media.metadata.ARTIST"

    invoke-virtual {v0, v2, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "dANt.OuiDRaTd.iaedmUaa.taenoorm"

    const-string v3, "dm.UoardmiaNaRDInieeTOtt.aa.odA"

    const-string v3, "aTUdon.parAiadtRe.aemNdamtDi.IO"

    const-string v3, "android.media.metadata.DURATION"

    invoke-virtual {v0, v3, v2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "eeUrimbaqa.BmaMd..itnAdodata"

    const-string/jumbo v3, "oAanabidiaB.dmteeUtdM.raa.md"

    const-string v3, "..smrLB.AaoatMientUedddamdai"

    const-string v3, "android.media.metadata.ALBUM"

    invoke-virtual {v0, v3, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "eTdmRHoauAiem.atUmr.ditndad.O"

    const-string v3, "TedRinu.aa.Aamamedtoddir.OHtU"

    const-string v3, "ATi.odmrdRUtiaa.eaa.ddnOeHoam"

    const-string v3, "android.media.metadata.AUTHOR"

    invoke-virtual {v0, v3, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "eWdemb.daiimaoTRt.dapatnrdEa."

    const-string v3, "dami.tepRTdietdnIamaaWadEo..r"

    const-string/jumbo v3, "oe.ddtu.dRRamWaEeIitm.riTndaa"

    const-string v3, "android.media.metadata.WRITER"

    invoke-virtual {v0, v3, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "O.nmdrMpmPaRECaaeSOaq..oadttdei"

    const-string v3, "Pda.MmdCqtOOeoaiierS.EtnaRm.ada"

    const-string v3, "aaaed.MOqaEPRrotmCdmtd.iiSOade."

    const-string v3, "android.media.metadata.COMPOSER"

    invoke-virtual {v0, v3, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "aMsTdam.eOiodeImnddNOiPC.aasLr.AaI"

    const-string v3, ".dsLCaaIPOn.OmIaNeaiTdo.detradMAmi"

    const-string v3, "IodmTadMiPatCtO.eaO.mmAedrIan.idLa"

    const-string v3, "android.media.metadata.COMPILATION"

    invoke-virtual {v0, v3, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v3, "mieto.mdnAdTaoEDrdaae.dimaa"

    const-string/jumbo v3, "t.Tm.ddnEaAmiedtaimedaoDaar"

    const-string v3, "ddeiib.daTDaet.A.aEmanrdaot"

    const-string v3, "android.media.metadata.DATE"

    invoke-virtual {v0, v3, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v3, "raa.edudeamYo.totAnm.Raidda"

    const-string/jumbo v3, "miaaooa.n.ddYaR.tdeAmtdaeir"

    const-string v3, "android.media.metadata.YEAR"

    invoke-virtual {v0, v3, v2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v3, "mdGadadpRrndNe...itaEEtmiaob"

    const-string v3, "Eene.baddiotdmG.maiaR.trdaNE"

    const-string/jumbo v3, "ndrtoedNqddiiaEmE.maRG.eaaat"

    const-string v3, "android.media.metadata.GENRE"

    invoke-virtual {v0, v3, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "d.sTn.diduEAMteUR_atmeioKBC.aNmaRaa"

    const-string v3, "Utd_CiuAdaeRMR.mBaEtTmed.aoKN.naadi"

    const-string v3, "atamo.mTa_UnCmiBaeKEd.dRarNd.MAeidR"

    const-string v3, "android.media.metadata.TRACK_NUMBER"

    invoke-virtual {v0, v3, v2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "_.ieorTdNAipaCade.tSaataUodRmKnd."

    const-string v3, "dNaoCR_prm.e.S.taAaTiedntKUamdiad"

    const-string/jumbo v3, "rTaNibMKt_RaSmUCAited.am.ded.daoa"

    const-string v3, "android.media.metadata.NUM_TRACKS"

    invoke-virtual {v0, v3, v2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "M.U_.RddqdeemDiaaaNtBSi.amEodnatCI"

    const-string v3, "android.media.metadata.DISC_NUMBER"

    invoke-virtual {v0, v3, v2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "am.dSau_dIedAtramTatBRoaeLT.nMsUA.d"

    const-string v3, "IasdeLoA_.StarddaRUnam.BTtaTimd.AMe"

    const-string v3, "aUeR_AMp.aTddaoA.eaLidr.BmIaStnimdT"

    const-string v3, "android.media.metadata.ALBUM_ARTIST"

    invoke-virtual {v0, v3, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x2

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const-string v4, "aanmA.ttqda.i.mreoddRiaaTe"

    const-string v4, "android.media.metadata.ART"

    invoke-virtual {v0, v4, v3}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v5, "RrsdTaaId.nUma.dtimod_.aAemRei"

    const-string v5, "Radma_.om..etrdRiUimadtendITaA"

    const-string v5, "aatmRU_.mdriieaaI.tadeddo.TnmA"

    const-string v5, "android.media.metadata.ART_URI"

    invoke-virtual {v0, v5, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v6, ".L.aoaBtd.oaMArdURanmddoTiae_iem"

    const-string v6, "ARenoatT.UidoM.adBrdda_imLetama."

    const-string v6, "iBddeb.d.aM_ataeatnRAdTU.mramLio"

    const-string v6, "android.media.metadata.ALBUM_ART"

    invoke-virtual {v0, v6, v3}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v7, "di.MRrum.mULtUnBIae.eTaddbatiAoda__R"

    const-string v7, "ai_dabTLnRareAmMtUaeaRdId..dBo.i_Umt"

    const-string v7, "ArTLn_ipdRRMtU.dtBo_aa.mm.AaeUeiadaI"

    const-string v7, "android.media.metadata.ALBUM_ART_URI"

    invoke-virtual {v0, v7, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x3

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v8

    const-string v9, "aeUdu.raqRio.madn.ImadETitRNeA_tda"

    const-string v9, "I_dnimut.dd..maatTUaNRAaeoEaridGeR"

    const-string v9, "RasE.riTNa.maae.oU_RnetatGdmidIddA"

    const-string v9, "android.media.metadata.USER_RATING"

    invoke-virtual {v0, v9, v8}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v9, ".dammdNapG.tIaioedmieA.aTndat"

    const-string/jumbo v9, "o.aeieIpdn.tmaN.aartTiAGdddma"

    const-string v9, "dGeaoi.ImAdoiRtTmeraN.an.atdd"

    const-string v9, "android.media.metadata.RATING"

    invoke-virtual {v0, v9, v8}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v8, "an..mbTYataATiPtoIDde.LLmIaeiEqd_dda"

    const-string/jumbo v8, "tLaDdinmqoateidmaaAe.PaY_L.ITIETdrd."

    const-string v8, "PTdadLu.Ytadtm.aAroImnSeID_iTLeda.Ei"

    const-string v8, "android.media.metadata.DISPLAY_TITLE"

    invoke-virtual {v0, v8, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v8, "P.dUTSdpairtEiYadsm_.mLDLIA.odeSaBItaen"

    const-string/jumbo v8, "nBsrtedISALmm.iaePTEtaLoaUT.d.YI_aiSddD"

    const-string v8, "DeLmUatEqitaiPT.mo.SaeBadA.dYITdILnar_d"

    const-string v8, "android.media.metadata.DISPLAY_SUBTITLE"

    invoke-virtual {v0, v8, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v8, "DdNmLea.CSnSPrTa.aIePIm_i.DdAOatdaERIotYmd"

    const-string/jumbo v8, "idsIdYESLmPmeSNea.r_DA.DaRPtoIdiaOdantT.aI"

    const-string v8, "android.media.metadata.DISPLAY_DESCRIPTION"

    invoke-virtual {v0, v8, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v8, "IDemIAmeiaamdiaar_St.dOL.NCPnad.oYt"

    const-string/jumbo v8, "iaDdoma_AiCeO..oaLtYdP.aarIdInteNmS"

    const-string v8, "android.media.metadata.DISPLAY_ICON"

    invoke-virtual {v0, v8, v3}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "amdbodi_adUreIDa_.aNO.RLmCPdItin.IAtSeY"

    const-string/jumbo v3, "ia.t.bPeiYan.IadCa_OdDLm_tSImreRadINAUd"

    const-string/jumbo v3, "odiIPbaeet_.LmAimD..rCOYataa_NdaddIISUn"

    const-string v3, "android.media.metadata.DISPLAY_ICON_URI"

    invoke-virtual {v0, v3, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v9, "umaAaMuIEdtmadaei.n.iDrdodtDI._"

    const-string/jumbo v9, "idDIntueIaaaMi.omdeAD_md.Etad.r"

    const-string v9, ".tdeaampDdEn..mdIdr_IoDteaAMiaa"

    const-string v9, "android.media.metadata.MEDIA_ID"

    invoke-virtual {v0, v9, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v9, "EadedFEpqD.BardoTYmdmtt.iROL.eaP_iaTa"

    const-string v9, "_aTenmEpaePdai..tdFYELmtoODidadra.RTB"

    const-string v9, "adsti.Td_oBdt.YP.FeamaDaOTnLa_EridREm"

    const-string v9, "android.media.metadata.BT_FOLDER_TYPE"

    invoke-virtual {v0, v9, v2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v9, "daUmnIitatmoiR.eeMEaadq.IdmAD.ar"

    const-string v9, "d_Aai.omqed.eatIanDiEramaRIdUMt."

    const-string v9, "doaMo.dmtii.ndEa.trAaaID_IeadeUR"

    const-string v9, "android.media.metadata.MEDIA_URI"

    invoke-virtual {v0, v9, v1}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "dar.EbTinamEVdi.dt.eeIaRtNMdSDoaEATa"

    const-string v1, "android.media.metadata.ADVERTISEMENT"

    invoke-virtual {v0, v1, v2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, ".SDsmtuieSOn_ad.maAatTLdO.WoaidDdeaTAU"

    const-string v1, "OaseaeadtaddimnADT.dLiAmt.r.oTUOSaW_SD"

    const-string/jumbo v1, "ntALma_p.tWiDSO.d.NdATTaeOUSrmeaaaiodd"

    const-string v1, "android.media.metadata.DOWNLOAD_STATUS"

    invoke-virtual {v0, v1, v2}, Landroidx/collection/m;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v9, "itd.d.aoqaITtenLa.mridEadeaT"

    const-string v9, "android.media.metadata.TITLE"

    const-string v10, "d.sieRtTSaaoreadtmTm.naIa.Add"

    const-string v10, "android.media.metadata.ARTIST"

    const-string v11, ".romemMaedmt.tiAadLaUmna.add"

    const-string/jumbo v11, "tA.mB.MeLUtddaanioarddae.amm"

    const-string v11, "Am.Uodei.matainaoaddMeBa.rdt"

    const-string v11, "android.media.metadata.ALBUM"

    const-string/jumbo v12, "tmBrMbTtAd.aodideLR_ni.TSamaeAIa.aU"

    const-string v12, "dAaSoLATeatmiT.BmrIUnRiedMdat_aad.."

    const-string/jumbo v12, "m.naLButeTrd.IdaTeAaARMdim.Ud_oiSat"

    const-string v12, "android.media.metadata.ALBUM_ARTIST"

    const-string v13, "Enmidb.adoeadRtarmRaWetTi.aId"

    const-string v13, "WteRdotpRadm..iErI.anaideTdaa"

    const-string v13, "android.media.metadata.WRITER"

    const-string v14, "detHeamAqtUa.irdamoaRaO.u.nid"

    const-string v14, "dtr.etudaOiai.aRHadeoUmdam.An"

    const-string v14, "dmsT.tdAoaHnairdaR.eamOi.dtae"

    const-string v14, "android.media.metadata.AUTHOR"

    const-string/jumbo v15, "mCempatnaiPoidOdedrE.RaOdMa..aS"

    const-string v15, "RiietOMpmaOaoadS.Ed.rdnaateCd.P"

    const-string v15, "aaiOoamoiM..edma.dnPtESdCrORdet"

    const-string v15, "android.media.metadata.COMPOSER"

    filled-new-array/range {v9 .. v15}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroid/support/v4/media/MediaMetadataCompat;->PREFERRED_DESCRIPTION_ORDER:[Ljava/lang/String;

    filled-new-array {v8, v4, v6}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroid/support/v4/media/MediaMetadataCompat;->PREFERRED_BITMAP_ORDER:[Ljava/lang/String;

    filled-new-array {v3, v5, v7}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Landroid/support/v4/media/MediaMetadataCompat;->PREFERRED_URI_ORDER:[Ljava/lang/String;

    new-instance v0, Landroid/support/v4/media/MediaMetadataCompat$1;

    invoke-direct {v0}, Landroid/support/v4/media/MediaMetadataCompat$1;-><init>()V

    sput-object v0, Landroid/support/v4/media/MediaMetadataCompat;->CREATOR:Landroid/os/Parcelable$Creator;

    return-void
.end method

.method constructor <init>(Landroid/os/Bundle;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    new-instance v0, Landroid/os/Bundle;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0, p1}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    invoke-static {v0}, Landroid/support/v4/media/session/MediaSessionCompat;->ensureClassLoader(Landroid/os/Bundle;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method constructor <init>(Landroid/os/Parcel;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-class v0, Landroid/support/v4/media/session/MediaSessionCompat;

    const-class v0, Landroid/support/v4/media/session/MediaSessionCompat;

    const/4 v2, 0x7

    const-class v0, Landroid/support/v4/media/session/MediaSessionCompat;

    const-class v0, Landroid/support/v4/media/session/MediaSessionCompat;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readBundle(Ljava/lang/ClassLoader;)Landroid/os/Bundle;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object p1, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public static fromMediaMetadata(Ljava/lang/Object;)Landroid/support/v4/media/MediaMetadataCompat;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/@K@ob ~M~ n@o~ of~ad ~4~lf@m@ @  1@r~@@c~ ~ y@~-~t.@@~~u~iS~ t~l~@~   @i~@b@@~o b~/@~  o vi@@so"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x3

    move v3, v2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p0, v0, v1}, Landroid/support/v4/media/MediaMetadataCompatApi21;->writeToParcel(Ljava/lang/Object;Landroid/os/Parcel;I)V

    const/4 v2, 0x0

    or-int/2addr v3, v2

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    sget-object v1, Landroid/support/v4/media/MediaMetadataCompat;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-interface {v1, v0}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    check-cast v1, Landroid/support/v4/media/MediaMetadataCompat;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object p0, v1, Landroid/support/v4/media/MediaMetadataCompat;->mMetadataObj:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object p0
.end method


# virtual methods
.method public containsKey(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return p1
.end method

.method public describeContents()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .locals 4

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    check-cast p1, Landroid/graphics/Bitmap;
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v0, "Mideaquadatea"

    const-string v0, "aMaeiedtqtada"

    const/4 v3, 0x2

    const-string v0, "MediaMetadata"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const-string/jumbo v1, "vriBsk.pteelFo  easp timi arytda ea"

    const-string v1, "BFsa eeaee   tervktlpda.tymaisiro i"

    const/4 v3, 0x1

    const-string/jumbo v1, "vr yea  qBiteaikoleFa  e adtrem.tip"

    const-string v1, "Failed to retrieve a key as Bitmap."

    const/4 v2, 0x5

    const/4 v2, 0x0

    invoke-static {v0, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p1
.end method

.method public getBundle()Landroid/os/Bundle;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v0, Landroid/os/Bundle;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Landroid/os/Bundle;-><init>(Landroid/os/Bundle;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0
.end method

.method public getDescription()Landroid/support/v4/media/MediaDescriptionCompat;
    .locals 12

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x5

    iget-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mDescription:Landroid/support/v4/media/MediaDescriptionCompat;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x0

    if-eqz v0, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    return-object v0

    :cond_0
    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-string/jumbo v0, "rasnmtaeEoMdadit.i.AmD.edIadDaI"

    const-string v0, "android.media.metadata.MEDIA_ID"

    const/4 v11, 0x3

    invoke-virtual {p0, v0}, Landroid/support/v4/media/MediaMetadataCompat;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    const/4 v1, 0x3

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x6

    new-array v2, v1, [Ljava/lang/CharSequence;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    const-string v3, "TDamraItmn.LYIm_aLTtdEeiSoma.dideAd."

    const-string v3, ".o.mADSidaaaLt_idePIIanTLYmmT.tdedEr"

    const/4 v11, 0x4

    const-string v3, "L.LEot_SeYaitiaaAedmdTaIdDoa..ImTPrn"

    const-string v3, "android.media.metadata.DISPLAY_TITLE"

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {p0, v3}, Landroid/support/v4/media/MediaMetadataCompat;->getText(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v3

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    const/4 v5, 0x2

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    const/4 v6, 0x1

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    const/4 v7, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x3

    if-nez v4, :cond_1

    const/4 v11, 0x6

    aput-object v3, v2, v7

    const/4 v11, 0x0

    const-string v1, "e_trobimdLDdIdUtaS.anaaE.maLI.AToTdBiSP"

    const-string v1, "EaS_oSYa.mr.iaId.amaLoTALtPUndiDTBdedtI"

    const/4 v11, 0x6

    const-string v1, "edTPDTuUeaoIBmLAEm.an.iSI.tadidSYardat_"

    const-string v1, "android.media.metadata.DISPLAY_SUBTITLE"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {p0, v1}, Landroid/support/v4/media/MediaMetadataCompat;->getText(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    aput-object v1, v2, v6

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x5

    const-string v1, "CEdSa.Dpirime.LdtPT.adS_OAoeIaaNDItPnaYbmd"

    const-string v1, ".eordbPnd_YPtaOiamSLemCIatRSIA.NdadiDEaT.D"

    const/4 v11, 0x0

    const-string v1, "dItNS.neqL.O.iaCIIPaEaPAm_mDDeYTddarStiRod"

    const-string v1, "android.media.metadata.DISPLAY_DESCRIPTION"

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p0, v1}, Landroid/support/v4/media/MediaMetadataCompat;->getText(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x2

    aput-object v1, v2, v5

    const/4 v11, 0x2

    const/4 v10, 0x5

    goto :goto_1

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    move v3, v7

    move v3, v7

    const/4 v11, 0x6

    move v3, v7

    move v3, v7

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    move v4, v3

    move v4, v3

    const/4 v11, 0x6

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    if-ge v3, v1, :cond_3

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    sget-object v8, Landroid/support/v4/media/MediaMetadataCompat;->PREFERRED_DESCRIPTION_ORDER:[Ljava/lang/String;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    array-length v9, v8

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    if-ge v4, v9, :cond_3

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    add-int/lit8 v9, v4, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    aget-object v4, v8, v4

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {p0, v4}, Landroid/support/v4/media/MediaMetadataCompat;->getText(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object v4

    const/4 v11, 0x4

    const/4 v10, 0x2

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-nez v8, :cond_2

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x2

    add-int/lit8 v8, v3, 0x1

    const/4 v10, 0x0

    shr-int/2addr v11, v10

    aput-object v4, v2, v3

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x4

    move v3, v8

    move v3, v8

    :cond_2
    const/4 v10, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    move v4, v9

    move v4, v9

    const/4 v11, 0x5

    move v4, v9

    move v4, v9

    const/4 v11, 0x1

    goto :goto_0

    :cond_3
    :goto_1
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    move v1, v7

    move v1, v7

    const/4 v11, 0x2

    move v1, v7

    move v1, v7

    :goto_2
    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    sget-object v3, Landroid/support/v4/media/MediaMetadataCompat;->PREFERRED_BITMAP_ORDER:[Ljava/lang/String;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    array-length v4, v3

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    const/4 v8, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-ge v1, v4, :cond_5

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    aget-object v3, v3, v1

    const/4 v10, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-virtual {p0, v3}, Landroid/support/v4/media/MediaMetadataCompat;->getBitmap(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x4

    if-eqz v3, :cond_4

    const/4 v11, 0x2

    goto :goto_3

    :cond_4
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    add-int/lit8 v1, v1, 0x1

    goto :goto_2

    :cond_5
    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    :goto_3
    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    move v1, v7

    move v1, v7

    const/4 v11, 0x0

    move v1, v7

    move v1, v7

    :goto_4
    const/4 v10, 0x7

    move v11, v10

    sget-object v4, Landroid/support/v4/media/MediaMetadataCompat;->PREFERRED_URI_ORDER:[Ljava/lang/String;

    const/4 v11, 0x4

    const/4 v10, 0x4

    array-length v9, v4

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-ge v1, v9, :cond_7

    const/4 v10, 0x3

    const/4 v11, 0x7

    aget-object v4, v4, v1

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {p0, v4}, Landroid/support/v4/media/MediaMetadataCompat;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-nez v9, :cond_6

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    goto :goto_5

    :cond_6
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    goto :goto_4

    :cond_7
    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    :goto_5
    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    const-string/jumbo v4, "tesdaa_tMd.RmorI.iI.auimaDUaAddn"

    const-string v4, "araiMmun.ttRae.meoAiU.DdddaI_adI"

    const-string/jumbo v4, "nI.mr.DeatAdtIdd.ed_RaMiaEmUmoia"

    const-string v4, "android.media.metadata.MEDIA_URI"

    const/4 v10, 0x7

    move v11, v10

    invoke-virtual {p0, v4}, Landroid/support/v4/media/MediaMetadataCompat;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v9

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    if-nez v9, :cond_8

    const/4 v11, 0x0

    const/4 v10, 0x0

    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v8

    :cond_8
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    new-instance v4, Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-direct {v4}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;-><init>()V

    const/4 v10, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v4, v0}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setMediaId(Ljava/lang/String;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v10, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    aget-object v0, v2, v7

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v4, v0}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    aget-object v0, v2, v6

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {v4, v0}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setSubtitle(Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    aget-object v0, v2, v5

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v4, v0}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setDescription(Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v10, 0x2

    const/4 v10, 0x1

    invoke-virtual {v4, v3}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setIconBitmap(Landroid/graphics/Bitmap;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v11, 0x6

    const/4 v10, 0x5

    invoke-virtual {v4, v1}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setIconUri(Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v11, 0x5

    invoke-virtual {v4, v8}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setMediaUri(Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v11, 0x5

    new-instance v0, Landroid/os/Bundle;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x6

    iget-object v1, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const-string v2, "aTTrdaDpOR_t_m.i.aYELnFemoPddaad.eEiB"

    const/4 v11, 0x1

    const-string v2, "eaPdoa.RT_iE.droentELmtim_addOF.TBaDa"

    const-string v2, "android.media.metadata.BT_FOLDER_TYPE"

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    if-eqz v1, :cond_9

    const/4 v10, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    const-string v1, ".eTrabqPi_tarLd_BadODmEY..oiEdTRxF"

    const-string v1, "_rEeaOdFqeEa_Ta.DddTBiioPtYrmR..Lx"

    const/4 v11, 0x7

    const-string v1, "Oi.Bx.unYa.LtDir_ddRroemd_TaTEEFae"

    const-string v1, "android.media.extra.BT_FOLDER_TYPE"

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {p0, v2}, Landroid/support/v4/media/MediaMetadataCompat;->getLong(Ljava/lang/String;)J

    move-result-wide v2

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    :cond_9
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    iget-object v1, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x3

    const-string v2, ".d.mOONpdaAe_iaSLDeU.atsaDiSATmTnWaord"

    const-string/jumbo v2, "iWsa.amrOdaNL._dTeoitan.UDOTAmeAtDSaSd"

    const/4 v11, 0x5

    const-string v2, "WaaOSaOaq.ar.UomtnedD.m_ALSTdiDiATeNdd"

    const-string v2, "android.media.metadata.DOWNLOAD_STATUS"

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v1, v2}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v1

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    if-eqz v1, :cond_a

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x0

    const-string v1, "SDsD.emnrTWodOr.OiitUa_dTLdAxmAa.ae"

    const-string/jumbo v1, "tnmmaa_daDdOdA.NTAe.rriWiSToxLDeOU."

    const/4 v11, 0x2

    const-string v1, "Om_mUSiadDxdNtnaeSdLroT...OAaeTrDWA"

    const-string v1, "android.media.extra.DOWNLOAD_STATUS"

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {p0, v2}, Landroid/support/v4/media/MediaMetadataCompat;->getLong(Ljava/lang/String;)J

    move-result-wide v2

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/BaseBundle;->putLong(Ljava/lang/String;J)V

    :cond_a
    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {v0}, Landroid/os/BaseBundle;->isEmpty()Z

    move-result v1

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    if-nez v1, :cond_b

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v4, v0}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setExtras(Landroid/os/Bundle;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    :cond_b
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v4}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->build()Landroid/support/v4/media/MediaDescriptionCompat;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x3

    iput-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mDescription:Landroid/support/v4/media/MediaDescriptionCompat;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    return-object v0
.end method

.method public getLong(Ljava/lang/String;)J
    .locals 5

    const/4 v3, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v4, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, p1, v1, v2}, Landroid/os/BaseBundle;->getLong(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-wide v0
.end method

.method public getMediaMetadata()Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mMetadataObj:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, v0, v1}, Landroid/support/v4/media/MediaMetadataCompat;->writeToParcel(Landroid/os/Parcel;I)V

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Landroid/os/Parcel;->setDataPosition(I)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v0}, Landroid/support/v4/media/MediaMetadataCompatApi21;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v1, p0, Landroid/support/v4/media/MediaMetadataCompat;->mMetadataObj:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    :cond_0
    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mMetadataObj:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public getRating(Ljava/lang/String;)Landroid/support/v4/media/RatingCompat;
    .locals 4

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p1}, Landroid/support/v4/media/RatingCompat;->fromRating(Ljava/lang/Object;)Landroid/support/v4/media/RatingCompat;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const-string v0, "aMaMoattodeia"

    const-string v0, "eeaMoaaidatMt"

    const/4 v3, 0x3

    const-string v0, "eaaaebitMMtda"

    const-string v0, "MediaMetadata"

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string v1, "airertudlatget Ray  avFseii n.eeobk"

    const-string/jumbo v1, "tFdvib.se aeRae a raiornyttlegi  ek"

    const/4 v3, 0x6

    const-string/jumbo v1, "ori ar.pdle aigFeenRi   avsttaekeyt"

    const-string v1, "Failed to retrieve a key as Rating."

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-object p1
.end method

.method public getString(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object p1

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 p1, 0x4

    const/4 p1, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    return-object p1
.end method

.method public getText(Ljava/lang/String;)Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v2, 0x5

    const/4 v1, 0x1

    invoke-virtual {v0, p1}, Landroid/os/Bundle;->getCharSequence(Ljava/lang/String;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p1
.end method

.method public keySet()Ljava/util/Set;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Landroid/os/BaseBundle;->keySet()Ljava/util/Set;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public size()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v1, 0x6

    or-int/2addr v2, v1

    invoke-virtual {v0}, Landroid/os/BaseBundle;->size()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    iget-object p2, p0, Landroid/support/v4/media/MediaMetadataCompat;->mBundle:Landroid/os/Bundle;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeBundle(Landroid/os/Bundle;)V

    const/4 v0, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method
