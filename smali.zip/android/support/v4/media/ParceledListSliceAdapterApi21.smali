.class Landroid/support/v4/media/ParceledListSliceAdapterApi21;
.super Ljava/lang/Object;


# annotations
.annotation build Landroidx/annotation/w0;
    value = 0x15
.end annotation


# static fields
.field private static sConstructor:Ljava/lang/reflect/Constructor;


# direct methods
.method static constructor <clinit>()V
    .locals 6

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string/jumbo v0, "tssalraitpsetcoddoecn.P.niLdeinerlcm"

    const-string/jumbo v0, "otscaanrlpedPdtiiicnLe.ete.dnsm.lcro"

    const/4 v5, 0x7

    const-string v0, "Sldmcnieorttnetla.isedmLip.craecondP"

    const-string v0, "android.content.pm.ParceledListSlice"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    new-array v1, v1, [Ljava/lang/Class;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-class v2, Ljava/util/List;

    const-class v2, Ljava/util/List;

    const/4 v5, 0x7

    const-class v2, Ljava/util/List;

    const-class v2, Ljava/util/List;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    aput-object v2, v1, v3

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    sput-object v0, Landroid/support/v4/media/ParceledListSliceAdapterApi21;->sConstructor:Ljava/lang/reflect/Constructor;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_1

    :catch_0
    move-exception v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :catch_1
    move-exception v0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method

.method static newInstance(Ljava/util/List;)Ljava/lang/Object;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Landroid/media/browse/MediaBrowser$MediaItem;",
            ">;)",
            "Ljava/lang/Object;"
        }
    .end annotation

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "4@ ~o @b ~~~s~t mv@o~~@@on1 tali@@~Mr oo~/o ~~@@ d . bc@@~~@- ~@~~fb /S@~~i  of@~ u@@l @~i~@ ~y@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    sget-object v0, Landroid/support/v4/media/ParceledListSliceAdapterApi21;->sConstructor:Ljava/lang/reflect/Constructor;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v2, 0x0

    aput-object p0, v1, v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    goto :goto_1

    :catch_0
    move-exception p0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :catch_1
    move-exception p0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :catch_2
    move-exception p0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 p0, 0x0

    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-object p0
.end method
