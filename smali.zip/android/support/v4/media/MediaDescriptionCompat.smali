.class public final Landroid/support/v4/media/MediaDescriptionCompat;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    }
.end annotation


# static fields
.field public static final BT_FOLDER_TYPE_ALBUMS:J = 0x2L

.field public static final BT_FOLDER_TYPE_ARTISTS:J = 0x3L

.field public static final BT_FOLDER_TYPE_GENRES:J = 0x4L

.field public static final BT_FOLDER_TYPE_MIXED:J = 0x0L

.field public static final BT_FOLDER_TYPE_PLAYLISTS:J = 0x5L

.field public static final BT_FOLDER_TYPE_TITLES:J = 0x1L

.field public static final BT_FOLDER_TYPE_YEARS:J = 0x6L

.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Landroid/support/v4/media/MediaDescriptionCompat;",
            ">;"
        }
    .end annotation
.end field

.field public static final DESCRIPTION_KEY_MEDIA_URI:Ljava/lang/String; = "android.support.v4.media.description.MEDIA_URI"
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation
.end field

.field public static final DESCRIPTION_KEY_NULL_BUNDLE_FLAG:Ljava/lang/String; = "android.support.v4.media.description.NULL_BUNDLE_FLAG"
    .annotation build Landroidx/annotation/a1;
        value = {
            .enum Landroidx/annotation/a1$a;->b:Landroidx/annotation/a1$a;
        }
    .end annotation
.end field

.field public static final EXTRA_BT_FOLDER_TYPE:Ljava/lang/String; = "android.media.extra.BT_FOLDER_TYPE"

.field public static final EXTRA_DOWNLOAD_STATUS:Ljava/lang/String; = "android.media.extra.DOWNLOAD_STATUS"

.field public static final STATUS_DOWNLOADED:J = 0x2L

.field public static final STATUS_DOWNLOADING:J = 0x1L

.field public static final STATUS_NOT_DOWNLOADED:J


# instance fields
.field private final mDescription:Ljava/lang/CharSequence;

.field private mDescriptionObj:Ljava/lang/Object;

.field private final mExtras:Landroid/os/Bundle;

.field private final mIcon:Landroid/graphics/Bitmap;

.field private final mIconUri:Landroid/net/Uri;

.field private final mMediaId:Ljava/lang/String;

.field private final mMediaUri:Landroid/net/Uri;

.field private final mSubtitle:Ljava/lang/CharSequence;

.field private final mTitle:Ljava/lang/CharSequence;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Landroid/support/v4/media/MediaDescriptionCompat$1;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {v0}, Landroid/support/v4/media/MediaDescriptionCompat$1;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    sput-object v0, Landroid/support/v4/media/MediaDescriptionCompat;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method constructor <init>(Landroid/os/Parcel;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mMediaId:Ljava/lang/String;

    const/4 v2, 0x2

    and-int/2addr v3, v2

    sget-object v0, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v3, 0x6

    invoke-interface {v0, p1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/CharSequence;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mTitle:Ljava/lang/CharSequence;

    const/4 v3, 0x7

    sget-object v0, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-interface {v0, p1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    check-cast v0, Ljava/lang/CharSequence;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mSubtitle:Ljava/lang/CharSequence;

    const/4 v3, 0x6

    const/4 v2, 0x5

    sget-object v0, Landroid/text/TextUtils;->CHAR_SEQUENCE_CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/CharSequence;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mDescription:Ljava/lang/CharSequence;

    const/4 v3, 0x4

    const-class v0, Landroid/support/v4/media/MediaDescriptionCompat;

    const-class v0, Landroid/support/v4/media/MediaDescriptionCompat;

    const/4 v3, 0x0

    const-class v0, Landroid/support/v4/media/MediaDescriptionCompat;

    const-class v0, Landroid/support/v4/media/MediaDescriptionCompat;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v1, Landroid/graphics/Bitmap;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mIcon:Landroid/graphics/Bitmap;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    check-cast v1, Landroid/net/Uri;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mIconUri:Landroid/net/Uri;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readBundle(Ljava/lang/ClassLoader;)Landroid/os/Bundle;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mExtras:Landroid/os/Bundle;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast p1, Landroid/net/Uri;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object p1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mMediaUri:Landroid/net/Uri;

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    return-void
.end method

.method constructor <init>(Ljava/lang/String;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/graphics/Bitmap;Landroid/net/Uri;Landroid/os/Bundle;Landroid/net/Uri;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mMediaId:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p2, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mTitle:Ljava/lang/CharSequence;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p3, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mSubtitle:Ljava/lang/CharSequence;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p4, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mDescription:Ljava/lang/CharSequence;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p5, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mIcon:Landroid/graphics/Bitmap;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p6, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mIconUri:Landroid/net/Uri;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p7, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mExtras:Landroid/os/Bundle;

    const/4 v1, 0x0

    const/4 v0, 0x4

    iput-object p8, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mMediaUri:Landroid/net/Uri;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public static fromMediaDescription(Ljava/lang/Object;)Landroid/support/v4/media/MediaDescriptionCompat;
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~ s - /t @u@d~1sol@4o~~ @~  o~~r@~ @nbbfo ~ic@v@f@~y~/~@~b~ ~~m~oK~ @@@.@~ @ @Si ot~~a@@~l @M@i "

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x1

    const/4 v0, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-eqz p0, :cond_4

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    new-instance v1, Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-direct {v1}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static {p0}, Landroid/support/v4/media/MediaDescriptionCompatApi21;->getMediaId(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v1, v2}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setMediaId(Ljava/lang/String;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {p0}, Landroid/support/v4/media/MediaDescriptionCompatApi21;->getTitle(Ljava/lang/Object;)Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v1, v2}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {p0}, Landroid/support/v4/media/MediaDescriptionCompatApi21;->getSubtitle(Ljava/lang/Object;)Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v1, v2}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setSubtitle(Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v9, 0x4

    invoke-static {p0}, Landroid/support/v4/media/MediaDescriptionCompatApi21;->getDescription(Ljava/lang/Object;)Ljava/lang/CharSequence;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {v1, v2}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setDescription(Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {p0}, Landroid/support/v4/media/MediaDescriptionCompatApi21;->getIconBitmap(Ljava/lang/Object;)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v1, v2}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setIconBitmap(Landroid/graphics/Bitmap;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-static {p0}, Landroid/support/v4/media/MediaDescriptionCompatApi21;->getIconUri(Ljava/lang/Object;)Landroid/net/Uri;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v1, v2}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setIconUri(Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static {p0}, Landroid/support/v4/media/MediaDescriptionCompatApi21;->getExtras(Ljava/lang/Object;)Landroid/os/Bundle;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string/jumbo v3, "tdpme.doIinasUcrpDv_iA.idasE.inm.suo4rRedptIoM"

    const-string/jumbo v3, "posRrepvr.UtaIdiaimiDco.pnn.deEido4d.sAMutIs_r"

    const/4 v9, 0x7

    const-string/jumbo v3, "otdro.oddnUarrdvuoeE4iI.epIpipc.nDisM.Am_atRi."

    const-string v3, "android.support.v4.media.description.MEDIA_URI"

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-eqz v2, :cond_0

    const/4 v8, 0x2

    shr-int/2addr v9, v8

    invoke-static {v2}, Landroid/support/v4/media/session/MediaSessionCompat;->ensureClassLoader(Landroid/os/Bundle;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v2, v3}, Landroid/os/Bundle;->getParcelable(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    check-cast v4, Landroid/net/Uri;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_0

    :cond_0
    move-object v4, v0

    move-object v4, v0

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-eqz v4, :cond_2

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string/jumbo v5, "pnd.rbanLU.aArFGpEedcLeN_.ostBiipLmd.tdrsDNm_ioU4iouL"

    const-string v5, "iEFmotdsDcLe_BGi.Npor4Li.mroa.rUAd.Nnai_petLdLuUps.dn"

    const/4 v9, 0x7

    const-string v5, "EpodN4uFiLeAUsDepmur.sLGNvoriL.dUiitd_..n._nproacBtLd"

    const-string v5, "android.support.v4.media.description.NULL_BUNDLE_FLAG"

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v2, v5}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v6

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-eqz v6, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v2}, Landroid/os/BaseBundle;->size()I

    move-result v6

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/4 v7, 0x2

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-ne v6, v7, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    goto :goto_1

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v2, v3}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v2, v5}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    :cond_2
    move-object v0, v2

    move-object v0, v2

    :goto_1
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v1, v0}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setExtras(Landroid/os/Bundle;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v9, 0x0

    if-eqz v4, :cond_3

    const/4 v8, 0x7

    move v9, v8

    invoke-virtual {v1, v4}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setMediaUri(Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    goto :goto_2

    :cond_3
    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {p0}, Landroid/support/v4/media/MediaDescriptionCompatApi23;->getMediaUri(Ljava/lang/Object;)Landroid/net/Uri;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v1, v0}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->setMediaUri(Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;

    :goto_2
    const/4 v9, 0x3

    const/4 v8, 0x1

    invoke-virtual {v1}, Landroid/support/v4/media/MediaDescriptionCompat$Builder;->build()Landroid/support/v4/media/MediaDescriptionCompat;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    iput-object p0, v0, Landroid/support/v4/media/MediaDescriptionCompat;->mDescriptionObj:Ljava/lang/Object;

    :cond_4
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    return-object v0
.end method


# virtual methods
.method public describeContents()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public getDescription()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mDescription:Ljava/lang/CharSequence;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public getExtras()Landroid/os/Bundle;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mExtras:Landroid/os/Bundle;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object v0
.end method

.method public getIconBitmap()Landroid/graphics/Bitmap;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mIcon:Landroid/graphics/Bitmap;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public getIconUri()Landroid/net/Uri;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mIconUri:Landroid/net/Uri;

    const/4 v2, 0x1

    return-object v0
.end method

.method public getMediaDescription()Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mDescriptionObj:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {}, Landroid/support/v4/media/MediaDescriptionCompatApi21$Builder;->newInstance()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mMediaId:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0, v1}, Landroid/support/v4/media/MediaDescriptionCompatApi21$Builder;->setMediaId(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mTitle:Ljava/lang/CharSequence;

    const/4 v3, 0x3

    invoke-static {v0, v1}, Landroid/support/v4/media/MediaDescriptionCompatApi21$Builder;->setTitle(Ljava/lang/Object;Ljava/lang/CharSequence;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mSubtitle:Ljava/lang/CharSequence;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0, v1}, Landroid/support/v4/media/MediaDescriptionCompatApi21$Builder;->setSubtitle(Ljava/lang/Object;Ljava/lang/CharSequence;)V

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mDescription:Ljava/lang/CharSequence;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0, v1}, Landroid/support/v4/media/MediaDescriptionCompatApi21$Builder;->setDescription(Ljava/lang/Object;Ljava/lang/CharSequence;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    iget-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mIcon:Landroid/graphics/Bitmap;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0, v1}, Landroid/support/v4/media/MediaDescriptionCompatApi21$Builder;->setIconBitmap(Ljava/lang/Object;Landroid/graphics/Bitmap;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mIconUri:Landroid/net/Uri;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v0, v1}, Landroid/support/v4/media/MediaDescriptionCompatApi21$Builder;->setIconUri(Ljava/lang/Object;Landroid/net/Uri;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mExtras:Landroid/os/Bundle;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0, v1}, Landroid/support/v4/media/MediaDescriptionCompatApi21$Builder;->setExtras(Ljava/lang/Object;Landroid/os/Bundle;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mMediaUri:Landroid/net/Uri;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0, v1}, Landroid/support/v4/media/MediaDescriptionCompatApi23$Builder;->setMediaUri(Ljava/lang/Object;Landroid/net/Uri;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0}, Landroid/support/v4/media/MediaDescriptionCompatApi21$Builder;->build(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mDescriptionObj:Ljava/lang/Object;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object v0
.end method

.method public getMediaId()Ljava/lang/String;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mMediaId:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public getMediaUri()Landroid/net/Uri;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x6

    iget-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mMediaUri:Landroid/net/Uri;

    const/4 v2, 0x4

    const/4 v1, 0x7

    return-object v0
.end method

.method public getSubtitle()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mSubtitle:Ljava/lang/CharSequence;

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public getTitle()Ljava/lang/CharSequence;
    .locals 3
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mTitle:Ljava/lang/CharSequence;

    const/4 v2, 0x2

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mTitle:Ljava/lang/CharSequence;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v1, ", "

    const-string v1, ", "

    const/4 v4, 0x4

    const-string v1, ", "

    const-string v1, ", "

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    iget-object v2, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mSubtitle:Ljava/lang/CharSequence;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v1, p0, Landroid/support/v4/media/MediaDescriptionCompat;->mDescription:Ljava/lang/CharSequence;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/support/v4/media/MediaDescriptionCompat;->getMediaDescription()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-static {v0, p1, p2}, Landroid/support/v4/media/MediaDescriptionCompatApi21;->writeToParcel(Ljava/lang/Object;Landroid/os/Parcel;I)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method
