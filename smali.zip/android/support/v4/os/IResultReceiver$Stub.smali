.class public abstract Landroid/support/v4/os/IResultReceiver$Stub;
.super Landroid/os/Binder;

# interfaces
.implements Landroid/support/v4/os/IResultReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroid/support/v4/os/IResultReceiver;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "Stub"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Landroid/support/v4/os/IResultReceiver$Stub$Proxy;
    }
.end annotation


# static fields
.field private static final DESCRIPTOR:Ljava/lang/String; = "android.support.v4.os.IResultReceiver"

.field static final TRANSACTION_send:I = 0x1


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string/jumbo v0, "vRsrssiot.viodlse4p.rc.ued.aroetpIRun"

    const-string/jumbo v0, "pnsoeiR4a.IvoRrulipdttsvr.ose.reue.cd"

    const/4 v2, 0x1

    const-string/jumbo v0, "ouvmiprenra.oReeR4stse.l.dvpdsro.Iuct"

    const-string v0, "android.support.v4.os.IResultReceiver"

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public static asInterface(Landroid/os/IBinder;)Landroid/support/v4/os/IResultReceiver;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~/ fo@@~~K~i~ lb @~~o4t@@1y@@@S  ~ ~~@ai~~or.~bu @@o  nm@~ o~~t@  ~  o~o @vc@ @~-b@@@Msf~i~~/@d "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    if-nez p0, :cond_0

    const/4 v2, 0x0

    move v3, v2

    const/4 p0, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v0, "iucs.bl4epo.ivReIorrprmnod..aRedtusvt"

    const-string/jumbo v0, "p.em4rRutrvarp..eieedotovsd.luiscRnoI"

    const/4 v3, 0x2

    const-string v0, "evoi.puu..R4lteidroosauednrvtRspsrce."

    const-string v0, "android.support.v4.os.IResultReceiver"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    instance-of v1, v0, Landroid/support/v4/os/IResultReceiver;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    check-cast v0, Landroid/support/v4/os/IResultReceiver;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v0, Landroid/support/v4/os/IResultReceiver$Stub$Proxy;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0, p0}, Landroid/support/v4/os/IResultReceiver$Stub$Proxy;-><init>(Landroid/os/IBinder;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object v0
.end method

.method public static getDefaultImpl()Landroid/support/v4/os/IResultReceiver;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-object v0, Landroid/support/v4/os/IResultReceiver$Stub$Proxy;->sDefaultImpl:Landroid/support/v4/os/IResultReceiver;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public static setDefaultImpl(Landroid/support/v4/os/IResultReceiver;)Z
    .locals 3

    sget-object v0, Landroid/support/v4/os/IResultReceiver$Stub$Proxy;->sDefaultImpl:Landroid/support/v4/os/IResultReceiver;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    sput-object p0, Landroid/support/v4/os/IResultReceiver$Stub$Proxy;->sDefaultImpl:Landroid/support/v4/os/IResultReceiver;

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 p0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return p0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x6

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string/jumbo v0, "laDcI(epeewfspltloidu tamec)l"

    const-string v0, "(aelocdaDl elui)Ietw sfptmcle"

    const/4 v2, 0x1

    const-string v0, "f)lepee qdtumtisaI(cwalcDtl l"

    const-string/jumbo v0, "setDefaultImpl() called twice"

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    throw p0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Landroid/os/RemoteException;
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x7

    const-string v1, "ResdtR..beoIsavlpeocsdtupruisin4ev.ro"

    const-string v1, "cIeaobevoiu.vr.nreRp.4ltep.sRdsuodsti"

    const/4 v4, 0x4

    const-string/jumbo v1, "veumiRucs.Iodpprsoe4.Rits.derrn.tvloe"

    const-string v1, "android.support.v4.os.IResultReceiver"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-eq p1, v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    const v2, 0x5f4e5446

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eq p1, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    return p1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    return v0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p2}, Landroid/os/Parcel;->readInt()I

    move-result p3

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz p3, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    sget-object p3, Landroid/os/Bundle;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-interface {p3, p2}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x7

    check-cast p2, Landroid/os/Bundle;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :cond_2
    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 p2, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p0, p1, p2}, Landroid/support/v4/os/IResultReceiver;->send(ILandroid/os/Bundle;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    return v0
.end method
