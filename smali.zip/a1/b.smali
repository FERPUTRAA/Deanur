.class public final La1/b;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@@s~4~ ~ln@~o@K oM@~-@ s @t@~fbu@~/o@1~Sib~ ~ ~ @ivb@~li.@~ o@~~~@t r ~  ~@~  df a/cy~m@@@o ~ o~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {p0}, Lz0/a;->d(Ljava/lang/String;)Z

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x7

    if-eqz v1, :cond_0

    const/4 v8, 0x1

    return-object v0

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string/jumbo v1, "sS1mH"

    const-string v1, "S1sHA"

    const/4 v8, 0x6

    const-string v1, "ASH-o"

    const-string v1, "SHA-1"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string v2, "bmF8T"

    const-string v2, "U8TmF"

    const/4 v8, 0x3

    const-string v2, "UuF8-"

    const-string v2, "UTF-8"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p0, v2}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v1, p0}, Ljava/security/MessageDigest;->update([B)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v2, 0x1

    const/4 v8, 0x3

    const/4 v2, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    move v3, v2

    move v3, v2

    const/4 v8, 0x1

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    array-length v4, p0

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    if-ge v3, v4, :cond_1

    const/4 v8, 0x1

    const-string/jumbo v4, "x%02"

    const-string v4, "%02x"

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    const/4 v5, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    aget-byte v6, p0, v3

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {v6}, Ljava/lang/Byte;->valueOf(B)Ljava/lang/Byte;

    move-result-object v6

    const/4 v8, 0x1

    const/4 v7, 0x0

    aput-object v6, v5, v2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    shl-int/2addr v8, v7

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_0

    :cond_1
    const/4 v8, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    return-object p0

    :catch_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    return-object v0
.end method
