.class public Lcom/tencent/android/tpns/mqtt/BufferedMessage;
.super Ljava/lang/Object;


# instance fields
.field private message:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

.field private token:Lcom/tencent/android/tpns/mqtt/MqttToken;


# direct methods
.method public constructor <init>(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/BufferedMessage;->message:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v1, 0x5

    const/4 v0, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/BufferedMessage;->token:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public getMessage()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~bs~@ -y@r  ~@@f~1~~o l~@ ~@@~~a@tnlo ~c oKt @4bo@ m@@ sf~o/  M~Sid/~ @~@@o~@~u ~~@  .~@~v@b~i@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/BufferedMessage;->message:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method public getToken()Lcom/tencent/android/tpns/mqtt/MqttToken;
    .locals 3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/BufferedMessage;->token:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method
