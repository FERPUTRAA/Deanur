.class public Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;
.super Ljava/lang/Object;


# static fields
.field public static final CLEAN_SESSION_DEFAULT:Z = true

.field public static final CONNECTION_TIMEOUT_DEFAULT:I = 0x1e

.field public static final KEEP_ALIVE_INTERVAL_DEFAULT:I = 0x3c

.field public static final MAX_INFLIGHT_DEFAULT:I = 0xa

.field public static final MQTT_VERSION_3_1:I = 0x3

.field public static final MQTT_VERSION_3_1_1:I = 0x4

.field public static final MQTT_VERSION_DEFAULT:I = 0x0

.field protected static final URI_TYPE_LOCAL:I = 0x2

.field protected static final URI_TYPE_SSL:I = 0x1

.field protected static final URI_TYPE_TCP:I = 0x0

.field protected static final URI_TYPE_WS:I = 0x3

.field protected static final URI_TYPE_WSS:I = 0x4


# instance fields
.field private MqttVersion:I

.field private automaticReconnect:Z

.field private cleanSession:Z

.field private connectionTimeout:I

.field private keepAliveInterval:I

.field private maxInflight:I

.field private password:[C

.field private serverURIs:[Ljava/lang/String;

.field private socketFactory:Ljavax/net/SocketFactory;

.field private sslClientProps:Ljava/util/Properties;

.field private sslHostnameVerifier:Ljavax/net/ssl/HostnameVerifier;

.field private userName:Ljava/lang/String;

.field private willDestination:Ljava/lang/String;

.field private willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/16 v0, 0x3c

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->keepAliveInterval:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/16 v0, 0xa

    const/4 v3, 0x1

    const/4 v2, 0x1

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->maxInflight:I

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x7

    move v2, v0

    move v2, v0

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->willDestination:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->sslClientProps:Ljava/util/Properties;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->sslHostnameVerifier:Ljavax/net/ssl/HostnameVerifier;

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->cleanSession:Z

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/16 v1, 0x1e

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput v1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->connectionTimeout:I

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->serverURIs:[Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->MqttVersion:I

    const/4 v2, 0x0

    move v3, v2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->automaticReconnect:Z

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method public static validateURI(Ljava/lang/String;)I
    .locals 5

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    new-instance v0, Ljava/net/URI;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v0, p0}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string/jumbo v1, "sw"

    const/4 v4, 0x5

    const-string/jumbo v1, "ws"

    const-string/jumbo v1, "ws"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 p0, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    return p0

    :cond_0
    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo v1, "ssw"

    const/4 v4, 0x0

    const-string/jumbo v1, "sws"

    const-string/jumbo v1, "wss"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 p0, 0x4

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    return p0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/net/URI;->getPath()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz v1, :cond_3

    const/4 v3, 0x7

    or-int/2addr v4, v3

    invoke-virtual {v0}, Ljava/net/URI;->getPath()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/String;->isEmpty()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    throw v0

    :cond_3
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v1, "ctp"

    const-string/jumbo v1, "tpc"

    const/4 v4, 0x1

    const-string/jumbo v1, "pct"

    const-string/jumbo v1, "tcp"

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v1, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 p0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    return p0

    :cond_4
    const/4 v3, 0x5

    move v4, v3

    const-string/jumbo v1, "lss"

    const-string/jumbo v1, "ssl"

    const/4 v4, 0x6

    const-string/jumbo v1, "sls"

    const-string/jumbo v1, "ssl"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v1, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 p0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    return p0

    :cond_5
    const/4 v4, 0x2

    const-string/jumbo v1, "loscs"

    const-string/jumbo v1, "lcslo"

    const/4 v4, 0x5

    const-string/jumbo v1, "oclml"

    const-string/jumbo v1, "local"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/net/URI;->getScheme()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 p0, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    return p0

    :cond_6
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    throw v0
    :try_end_0
    .catch Ljava/net/URISyntaxException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v3, 0x5

    move v4, v3

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    throw v0
.end method

.method private validateWill(Ljava/lang/String;Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    if-eqz p2, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    const/4 p2, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-static {p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttTopic;->validate(Ljava/lang/String;Z)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v0, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    throw p1
.end method


# virtual methods
.method public getConnectionTimeout()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->connectionTimeout:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public getDebug()Ljava/util/Properties;
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v0, Ljava/util/Properties;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/util/Properties;-><init>()V

    const/4 v5, 0x1

    new-instance v1, Ljava/lang/Integer;

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getMqttVersion()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {v1, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo v2, "ntorosmMVei"

    const-string/jumbo v2, "nsomerMVitt"

    const/4 v5, 0x3

    const-string v2, "eoVntbiMsqr"

    const-string v2, "MqttVersion"

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->isCleanSession()Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v2, "nCsSsaueeoio"

    const-string/jumbo v2, "nansoeoesSCi"

    const/4 v5, 0x4

    const-string/jumbo v2, "iolensspSnCe"

    const-string v2, "CleanSession"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/Integer;

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getConnectionTimeout()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {v1, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v2, "TotbeimuqC"

    const-string/jumbo v2, "mCioebotTu"

    const/4 v5, 0x4

    const-string v2, "TosmCneoit"

    const-string v2, "ConTimeout"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/Integer;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getKeepAliveInterval()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v4, 0x0

    move v5, v4

    const-string/jumbo v2, "ipAmeenvulaevItKl"

    const-string/jumbo v2, "teveIauKnleeplAiv"

    const-string/jumbo v2, "teKeonAiprIvveell"

    const-string v2, "KeepAliveInterval"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getUserName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string/jumbo v2, "null"

    const-string/jumbo v2, "lnlu"

    const/4 v5, 0x4

    const-string/jumbo v2, "llun"

    const-string/jumbo v2, "null"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v1, :cond_0

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getUserName()Ljava/lang/String;

    move-result-object v1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v3, "rpsNebma"

    const-string v3, "ersmNeap"

    const-string v3, "UserName"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v3, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getWillDestination()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-nez v1, :cond_1

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_1

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getWillDestination()Ljava/lang/String;

    move-result-object v1

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string v3, "DsWiequniaitnlo"

    const-string/jumbo v3, "litlsinDqWionae"

    const/4 v5, 0x0

    const-string v3, "WoiDelipistnnlt"

    const-string v3, "WillDestination"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0, v3, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getSocketFactory()Ljavax/net/SocketFactory;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string v3, "Sccrettoqsyak"

    const-string/jumbo v3, "koscyrFttcaSe"

    const-string v3, "aSsctcorteFky"

    const-string v3, "SocketFactory"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez v1, :cond_2

    const/4 v5, 0x6

    invoke-virtual {v0, v3, v2}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    goto :goto_2

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getSocketFactory()Ljavax/net/SocketFactory;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v3, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_2
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getSSLProperties()Ljava/util/Properties;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string/jumbo v3, "tePmmrSoLirSp"

    const-string v3, "iSemPeLrprotS"

    const/4 v5, 0x3

    const-string/jumbo v3, "oLrpoSeesitSr"

    const-string v3, "SSLProperties"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-nez v1, :cond_3

    const/4 v5, 0x5

    invoke-virtual {v0, v3, v2}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    goto :goto_3

    :cond_3
    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getSSLProperties()Ljava/util/Properties;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0, v3, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_3
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-object v0
.end method

.method public getKeepAliveInterval()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->keepAliveInterval:I

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public getMaxInflight()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->maxInflight:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public getMqttVersion()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->MqttVersion:I

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public getPassword()[C
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->password:[C

    return-object v0
.end method

.method public getSSLHostnameVerifier()Ljavax/net/ssl/HostnameVerifier;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->sslHostnameVerifier:Ljavax/net/ssl/HostnameVerifier;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public getSSLProperties()Ljava/util/Properties;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->sslClientProps:Ljava/util/Properties;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public getServerURIs()[Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->serverURIs:[Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public getSocketFactory()Ljavax/net/SocketFactory;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->socketFactory:Ljavax/net/SocketFactory;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public getUserName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->userName:Ljava/lang/String;

    const/4 v1, 0x5

    move v2, v1

    return-object v0
.end method

.method public getWillDestination()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->willDestination:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public getWillMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public isAutomaticReconnect()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->automaticReconnect:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public isCleanSession()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->cleanSession:Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public setAutomaticReconnect(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->automaticReconnect:Z

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public setCleanSession(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->cleanSession:Z

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public setConnectionTimeout(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    if-ltz p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->connectionTimeout:I

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void

    :cond_0
    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    throw p1
.end method

.method public setKeepAliveInterval(I)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    if-ltz p1, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->keepAliveInterval:I

    const/4 v0, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    throw p1
.end method

.method public setMaxInflight(I)V
    .locals 2

    const/4 v1, 0x2

    if-ltz p1, :cond_0

    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->maxInflight:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void

    :cond_0
    const/4 v1, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    throw p1
.end method

.method public setMqttVersion(I)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eq p1, v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    move v2, v1

    if-ne p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    throw p1

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->MqttVersion:I

    const/4 v1, 0x2

    move v2, v1

    return-void
.end method

.method public setPassword([C)V
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->password:[C

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public setSSLHostnameVerifier(Ljavax/net/ssl/HostnameVerifier;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->sslHostnameVerifier:Ljavax/net/ssl/HostnameVerifier;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public setSSLProperties(Ljava/util/Properties;)V
    .locals 2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->sslClientProps:Ljava/util/Properties;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public setServerURIs([Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    array-length v1, p1

    const/4 v3, 0x4

    if-ge v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    aget-object v1, p1, v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v1}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->validateURI(Ljava/lang/String;)I

    const/4 v3, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->serverURIs:[Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method

.method public setSocketFactory(Ljavax/net/SocketFactory;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->socketFactory:Ljavax/net/SocketFactory;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public setUserName(Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    throw p1

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->userName:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method

.method public setWill(Lcom/tencent/android/tpns/mqtt/MqttTopic;[BIZ)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/MqttTopic;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->validateWill(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {v0, p2}, Lcom/tencent/android/tpns/mqtt/MqttMessage;-><init>([B)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0, p1, v0, p3, p4}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->setWill(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttMessage;IZ)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method protected setWill(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttMessage;IZ)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->willDestination:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p2, p3}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setQos(I)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p1, p4}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setRetained(Z)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    const/4 p2, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setMutable(Z)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public setWill(Ljava/lang/String;[BIZ)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->validateWill(Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0, p2}, Lcom/tencent/android/tpns/mqtt/MqttMessage;-><init>([B)V

    const/4 v1, 0x6

    or-int/2addr v2, v1

    invoke-virtual {p0, p1, v0, p3, p4}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->setWill(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttMessage;IZ)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x6

    move v3, v2

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getDebug()Ljava/util/Properties;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo v1, "otetonponisCo innc"

    const/4 v3, 0x4

    const-string v1, "eoonibnp ncosinoCt"

    const-string v1, "Connection options"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/util/Debug;->dumpProperties(Ljava/util/Properties;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-object v0
.end method
