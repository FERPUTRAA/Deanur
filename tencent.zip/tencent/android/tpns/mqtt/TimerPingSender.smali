.class public Lcom/tencent/android/tpns/mqtt/TimerPingSender;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/MqttPingSender;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpns/mqtt/TimerPingSender$PingTask;
    }
.end annotation


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "TimerPingSender"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

.field private timer:Ljava/util/Timer;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo v0, "lostn.tstgpnd.riectcalcqetose...aa.sntmr.lidnnotn"

    const-string/jumbo v0, "otser.iel.tnotdn.ll.aencrcndnm.soipngtaactsntt..q"

    const/4 v3, 0x1

    const-string v0, "e.rmsapq.dstcit.nndmni.lg.lcmolnn.otratcantte.nto"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string/jumbo v1, "mriTorPenngSdei"

    const-string v1, "TimerPingSender"

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    sput-object v0, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~@@lb f@~/~ @i@@au  K~~o  @o~~~@- .m1 o~@ i~~~dt@M@~@S4l s~t~@n @ c@b i~o~yb~  vo~f@ o~r@ ~~b@/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v2, 0x2

    return-object v0
.end method

.method static synthetic access$200(Lcom/tencent/android/tpns/mqtt/TimerPingSender;)Lcom/tencent/android/tpns/mqtt/internal/ClientComms;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p0
.end method


# virtual methods
.method public init(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string/jumbo v0, "n nlmbumoa.oitmuclne Cest C"

    const-string v0, " tlmoilctmC. sn noebeuCamln"

    const/4 v2, 0x6

    const-string v0, " l.u tcptCbl lnmeisonmoCena"

    const-string v0, "ClientComms cannot be null."

    const/4 v2, 0x6

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    throw p1
.end method

.method public schedule(J)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->timer:Ljava/util/Timer;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v1, Lcom/tencent/android/tpns/mqtt/TimerPingSender$PingTask;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x1

    invoke-direct {v1, p0, v2}, Lcom/tencent/android/tpns/mqtt/TimerPingSender$PingTask;-><init>(Lcom/tencent/android/tpns/mqtt/TimerPingSender;Lcom/tencent/android/tpns/mqtt/TimerPingSender$1;)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1, p1, p2}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V

    const/4 v4, 0x2

    return-void
.end method

.method public start()V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v6, 0x4

    move v7, v6

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    sget-object v1, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v2, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v3, 0x5

    const/4 v7, 0x2

    const/4 v3, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    aput-object v0, v2, v3

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string v3, "SenPeedrqigmoTr"

    const-string/jumbo v3, "mPnSoeeTiredrng"

    const/4 v7, 0x7

    const-string v3, "TgsirnrdneiPeeS"

    const-string v3, "TimerPingSender"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string v4, "brtms"

    const-string v4, "batrs"

    const/4 v7, 0x0

    const-string v4, "atsro"

    const-string/jumbo v4, "start"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string v5, "596"

    const-string v5, "659"

    const/4 v7, 0x2

    invoke-interface {v1, v3, v4, v5, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance v1, Ljava/util/Timer;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v3, "uT:i bPQg T"

    const-string v3, "P:g MQuTT i"

    const/4 v7, 0x0

    const-string v3, " PT iguQ:Tn"

    const-string v3, "MQTT Ping: "

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {v1, v0}, Ljava/util/Timer;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->timer:Ljava/util/Timer;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    new-instance v0, Lcom/tencent/android/tpns/mqtt/TimerPingSender$PingTask;

    const/4 v6, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-direct {v0, p0, v2}, Lcom/tencent/android/tpns/mqtt/TimerPingSender$PingTask;-><init>(Lcom/tencent/android/tpns/mqtt/TimerPingSender;Lcom/tencent/android/tpns/mqtt/TimerPingSender$1;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v7, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getKeepAlive()J

    move-result-wide v2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v1, v0, v2, v3}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    return-void
.end method

.method public stop()V
    .locals 7

    const/4 v5, 0x2

    move v6, v5

    sget-object v0, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const-string v1, "616"

    const-string v1, "616"

    const/4 v6, 0x0

    const-string v1, "166"

    const-string v1, "661"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string/jumbo v3, "mdprTeepigrSnie"

    const-string v3, "PirgrdnpmeieSTe"

    const/4 v6, 0x6

    const-string/jumbo v3, "rPeirmedqennTgS"

    const-string v3, "TimerPingSender"

    const/4 v6, 0x1

    const-string/jumbo v4, "ostp"

    const-string/jumbo v4, "otsp"

    const/4 v6, 0x1

    const-string/jumbo v4, "tspo"

    const-string/jumbo v4, "stop"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-interface {v0, v3, v4, v1, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->timer:Ljava/util/Timer;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/util/Timer;->cancel()V

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-void
.end method
