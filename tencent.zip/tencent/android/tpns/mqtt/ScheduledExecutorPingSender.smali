.class public Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/MqttPingSender;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender$PingRunnable;
    }
.end annotation


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "ScheduledExecutorPingSender"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private clientid:Ljava/lang/String;

.field private comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

.field private executorService:Ljava/util/concurrent/ScheduledExecutorService;

.field private scheduledFuture:Ljava/util/concurrent/ScheduledFuture;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v0, "lasttgiot.sqsmdtc.ldcnenlneirneptta.o.t.c.m.orann"

    const/4 v3, 0x6

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v1, "PesuieuerEneetccgdhrdSlxmdo"

    const-string v1, "eodmxedentSrgPuScducleiehrE"

    const/4 v3, 0x2

    const-string v1, "SeimeSgucodPuenlnhdErxecret"

    const-string v1, "ScheduledExecutorPingSender"

    const/4 v2, 0x7

    move v3, v2

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    sput-object v0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public constructor <init>(Ljava/util/concurrent/ScheduledExecutorService;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->executorService:Ljava/util/concurrent/ScheduledExecutorService;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string v0, "bc Soreno cxinrtaloevlcteuuE.eo"

    const-string/jumbo v0, "rn.eoctecioetl  luvobu arecxnES"

    const/4 v2, 0x7

    const-string/jumbo v0, "lit Sbtncve.rooEca erlubneun xe"

    const-string v0, "ExecutorService cannot be null."

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    throw p1
.end method

.method static synthetic access$100(Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "cm@ s u~y /~@on@ M@l~u/@ br  ~ ~@i@- ~K~ i@~tSo~@o~~~@~.@o ~~bf~ @~d@o~oifa@l~t@ ~~@@@  4b 1 v@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->clientid:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$200()Lcom/tencent/android/tpns/mqtt/logging/Logger;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method

.method static synthetic access$300(Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;)Lcom/tencent/android/tpns/mqtt/internal/ClientComms;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iget-object p0, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-object p0
.end method


# virtual methods
.method public init(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-interface {p1}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->clientid:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string v0, " ncsolopmCletbuiCe. mna lbn"

    const-string v0, " oCanblCeioe ltm.ls bcunnmn"

    const-string v0, " ann.eolqeiC nt mCuolscmlnb"

    const-string v0, "ClientComms cannot be null."

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v2, 0x7

    throw p1
.end method

.method public schedule(J)V
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->executorService:Ljava/util/concurrent/ScheduledExecutorService;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v1, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender$PingRunnable;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v1, p0, v2}, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender$PingRunnable;-><init>(Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender$1;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {v0, v1, p1, p2, v2}, Ljava/util/concurrent/ScheduledExecutorService;->schedule(Ljava/lang/Runnable;JLjava/util/concurrent/TimeUnit;)Ljava/util/concurrent/ScheduledFuture;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->scheduledFuture:Ljava/util/concurrent/ScheduledFuture;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void
.end method

.method public start()V
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    sget-object v0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v2, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->clientid:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    aput-object v3, v1, v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string/jumbo v2, "ndslEextiPcucoSdrenuudSreee"

    const-string v2, "cneetluSEddPuxeiSdohrerencu"

    const/4 v6, 0x5

    const-string v2, "gremocdtePxSrnuSuheeddcnlEe"

    const-string v2, "ScheduledExecutorPingSender"

    const/4 v5, 0x4

    move v6, v5

    const-string/jumbo v3, "rspto"

    const-string/jumbo v3, "stptr"

    const/4 v6, 0x4

    const-string v3, "btstr"

    const-string/jumbo v3, "start"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v4, "695"

    const/4 v6, 0x5

    const-string v4, "569"

    const-string v4, "659"

    const/4 v5, 0x1

    move v6, v5

    invoke-interface {v0, v2, v3, v4, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getKeepAlive()J

    move-result-wide v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p0, v0, v1}, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->schedule(J)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    return-void
.end method

.method public stop()V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    sget-object v0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string v1, "616"

    const/4 v6, 0x0

    const-string v1, "661"

    const-string v1, "661"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v3, "ESqediucnurgeldxrudcoPeSten"

    const-string v3, "eEnuPelcqdruohnteeSScigddrx"

    const/4 v6, 0x5

    const-string/jumbo v3, "oEelrenpdcideSneuuPhcSrtgdx"

    const-string v3, "ScheduledExecutorPingSender"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string/jumbo v4, "sopt"

    const-string/jumbo v4, "ospt"

    const/4 v6, 0x6

    const-string/jumbo v4, "psot"

    const-string/jumbo v4, "stop"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {v0, v3, v4, v1, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->scheduledFuture:Ljava/util/concurrent/ScheduledFuture;

    const/4 v6, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 v1, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-interface {v0, v1}, Ljava/util/concurrent/Future;->cancel(Z)Z

    :cond_0
    const/4 v5, 0x0

    const/4 v6, 0x0

    return-void
.end method
