.class public Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;
.super Lcom/tencent/android/tpns/mqtt/MqttToken;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/IMqttDeliveryToken;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/MqttToken;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/MqttToken;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " vs~~-ro~ y @@@t~b@l@  @@@sb~  ~@~~n@i~~4t@~@i  .foK~~  @@@ @~m~od~@S f1ci/u~lM ob@~ ~@~a ~o/~@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method protected setMessage(Lcom/tencent/android/tpns/mqtt/MqttMessage;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->setMessage(Lcom/tencent/android/tpns/mqtt/MqttMessage;)V

    const/4 v1, 0x4

    xor-int/2addr v2, v1

    return-void
.end method
