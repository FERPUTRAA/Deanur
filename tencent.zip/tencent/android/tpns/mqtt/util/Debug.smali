.class public Lcom/tencent/android/tpns/mqtt/util/Debug;
.super Ljava/lang/Object;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "ClientComms"

.field private static final lineSep:Ljava/lang/String;

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

.field private static final separator:Ljava/lang/String; = "=============="


# instance fields
.field private clientID:Ljava/lang/String;

.field private comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v0, "ntstqtmnacnnttraridd.t.o.cnglm.tpeleonnois.a.ec.l"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string/jumbo v1, "lmCmnestCms"

    const-string v1, "essnCCltomm"

    const/4 v3, 0x4

    const-string/jumbo v1, "metCosomlni"

    const-string v1, "ClientComms"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/android/tpns/mqtt/util/Debug;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v2, 0x3

    shl-int/2addr v3, v2

    const-string v0, "arr.nblaeimeop"

    const-string/jumbo v0, "pelmaoertrna.i"

    const/4 v3, 0x6

    const-string/jumbo v0, "line.separator"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const-string/jumbo v1, "n/"

    const-string v1, "/n"

    const-string v1, "/n"

    const-string v1, "\n"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v0, v1}, Ljava/lang/System;->getProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    sput-object v0, Lcom/tencent/android/tpns/mqtt/util/Debug;->lineSep:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/util/Debug;->clientID:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/util/Debug;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    sget-object p2, Lcom/tencent/android/tpns/mqtt/util/Debug;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-interface {p2, p1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->setResourceName(Ljava/lang/String;)V

    const/4 v0, 0x7

    move v1, v0

    return-void
.end method

.method public static dumpProperties(Ljava/util/Properties;Ljava/lang/String;)Ljava/lang/String;
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "o/~bb~u@m l@@@1.@r y @a~f ~@~c @ o~~~ @~~f @~@~@ ~@ 4ioM@onbvt@ l ~@  ~i~d~~/~o otu~- @K~@S@s @~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x2

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p0}, Ljava/util/Properties;->propertyNames()Ljava/util/Enumeration;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    sget-object v3, Lcom/tencent/android/tpns/mqtt/util/Debug;->lineSep:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string v4, "=======p==o==="

    const-string v4, "====o========="

    const/4 v7, 0x2

    const-string v4, "========q====="

    const-string v4, "=============="

    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string v5, " "

    const-string v5, " "

    const/4 v7, 0x0

    const-string v5, " "

    const-string v5, " "

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x7

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-interface {v1}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz p1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-interface {v1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    check-cast p1, Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    move v7, v6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/16 v3, 0x1c

    const/4 v7, 0x7

    const/16 v4, 0x20

    const/4 v7, 0x4

    const/4 v6, 0x3

    invoke-static {p1, v3, v4}, Lcom/tencent/android/tpns/mqtt/util/Debug;->left(Ljava/lang/String;IC)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v3, " : "

    const-string v3, "  :"

    const/4 v7, 0x7

    const-string v3, "  :"

    const-string v3, ":  "

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    invoke-virtual {p0, p1}, Ljava/util/Dictionary;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    sget-object p1, Lcom/tencent/android/tpns/mqtt/util/Debug;->lineSep:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string p1, "==s==========b============================"

    const-string p1, "=====b===================================="

    const/4 v7, 0x4

    const-string p1, "===m======================================"

    const-string p1, "=========================================="

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    sget-object p1, Lcom/tencent/android/tpns/mqtt/util/Debug;->lineSep:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v7, 0x4

    return-object p0
.end method

.method public static left(Ljava/lang/String;IC)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-lt v0, p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {v0, p1}, Ljava/lang/StringBuffer;-><init>(I)V

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    sub-int/2addr p1, p0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-ltz p1, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p0
.end method


# virtual methods
.method public dumpBaseDebug()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/util/Debug;->dumpVersion()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/util/Debug;->dumpSystemProperties()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/util/Debug;->dumpMemoryTrace()V

    const/4 v0, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public dumpClientComms()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/util/Debug;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getDebug()Ljava/util/Properties;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    sget-object v1, Lcom/tencent/android/tpns/mqtt/util/Debug;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/util/Debug;->clientID:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string/jumbo v3, "im :otCls umeo"

    const-string v3, " oemntuslim :C"

    const/4 v5, 0x0

    const-string/jumbo v3, "solmtbie:nm C "

    const-string v3, " : ClientComms"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    invoke-static {v0, v2}, Lcom/tencent/android/tpns/mqtt/util/Debug;->dumpProperties(Ljava/util/Properties;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v2, "ntslimumopC"

    const-string/jumbo v2, "tinmCmopCsl"

    const/4 v5, 0x6

    const-string v2, "ClientComms"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string/jumbo v3, "lpqudmCpetoisnm"

    const-string v3, "CinoedlCqutpsmm"

    const/4 v5, 0x6

    const-string v3, "CtomdmusqiemCln"

    const-string v3, "dumpClientComms"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {v1, v2, v3, v0}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void
.end method

.method public dumpClientDebug()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/util/Debug;->dumpClientComms()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/util/Debug;->dumpConOptions()V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/util/Debug;->dumpClientState()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/util/Debug;->dumpBaseDebug()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public dumpClientState()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/util/Debug;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClientState()Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/util/Debug;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClientState()Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getDebug()Ljava/util/Properties;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget-object v1, Lcom/tencent/android/tpns/mqtt/util/Debug;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/util/Debug;->clientID:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    and-int/2addr v5, v4

    const-string/jumbo v3, "nssSta ie tle:"

    const-string v3, "Cestnai t Sl:e"

    const/4 v5, 0x3

    const-string v3, " CnmS elttti:e"

    const-string v3, " : ClientState"

    const/4 v5, 0x7

    const/4 v4, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-static {v0, v2}, Lcom/tencent/android/tpns/mqtt/util/Debug;->dumpProperties(Ljava/util/Properties;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo v2, "olenomCstmC"

    const-string/jumbo v2, "slnmotmmCCe"

    const/4 v5, 0x1

    const-string/jumbo v2, "itmsCbCeonm"

    const-string v2, "ClientComms"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string/jumbo v3, "ttpetSuCdmeiaol"

    const-string/jumbo v3, "pdnSoCtaittleem"

    const/4 v5, 0x2

    const-string/jumbo v3, "uttneeaplmCSipt"

    const-string v3, "dumpClientState"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-interface {v1, v2, v3, v0}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void
.end method

.method public dumpConOptions()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/util/Debug;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v4, 0x6

    or-int/2addr v5, v4

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getConOptions()Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getDebug()Ljava/util/Properties;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    sget-object v1, Lcom/tencent/android/tpns/mqtt/util/Debug;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/util/Debug;->clientID:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const-string/jumbo v3, "n  nboCOqcinopt :t"

    const-string/jumbo v3, "ot p botcs nniOCn:"

    const/4 v5, 0x2

    const-string v3, " nstsCiO tep: noco"

    const-string v3, " : Connect Options"

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v0, v2}, Lcom/tencent/android/tpns/mqtt/util/Debug;->dumpProperties(Ljava/util/Properties;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo v2, "lismCmeCtno"

    const-string v2, "CsltoeuCmni"

    const/4 v5, 0x5

    const-string/jumbo v2, "oitCoClnemm"

    const-string v2, "ClientComms"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo v3, "sCpopbmntpOnou"

    const-string v3, "CpotiOopnmunsp"

    const/4 v5, 0x3

    const-string v3, "OsoCouupdimntn"

    const-string v3, "dumpConOptions"

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-interface {v1, v2, v3, v0}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v5, 0x7

    return-void
.end method

.method protected dumpMemoryTrace()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/android/tpns/mqtt/util/Debug;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v2, 0x2

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->dumpTrace()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public dumpSystemProperties()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {}, Ljava/lang/System;->getProperties()Ljava/util/Properties;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    sget-object v1, Lcom/tencent/android/tpns/mqtt/util/Debug;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v2, "PtierrmppsySseto"

    const-string v2, "SystemProperties"

    const/4 v4, 0x6

    move v5, v4

    invoke-static {v0, v2}, Lcom/tencent/android/tpns/mqtt/util/Debug;->dumpProperties(Ljava/util/Properties;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo v2, "mlCiqsotqmC"

    const-string v2, "CClseoitqmm"

    const/4 v5, 0x4

    const-string/jumbo v2, "otsmmslCeni"

    const-string v2, "ClientComms"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v3, "mtempsopryieusrtesPd"

    const-string/jumbo v3, "rrsssopuymetepmdPeit"

    const/4 v5, 0x4

    const-string v3, "eioyotsmmrpdrPSpestu"

    const-string v3, "dumpSystemProperties"

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-interface {v1, v2, v3, v0}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    return-void
.end method

.method protected dumpVersion()V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    move v8, v7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    shr-int/2addr v8, v7

    sget-object v2, Lcom/tencent/android/tpns/mqtt/util/Debug;->lineSep:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v7, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string v3, "=====b===m===="

    const-string v3, "===m=========="

    const/4 v8, 0x3

    const-string v3, "======u======="

    const-string v3, "=============="

    const/4 v8, 0x7

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string v4, "IVisnonpeo r f"

    const-string v4, " Version Info "

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    move v8, v7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    or-int/2addr v8, v7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string/jumbo v3, "oqnorsV"

    const-string v3, "Visoorn"

    const/4 v8, 0x3

    const-string/jumbo v3, "siserVn"

    const-string v3, "Version"

    const/4 v8, 0x4

    const/16 v4, 0x14

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/16 v5, 0x20

    const/4 v8, 0x7

    invoke-static {v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/util/Debug;->left(Ljava/lang/String;IC)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const-string v3, "  :"

    const/4 v8, 0x4

    const-string v3, "  :"

    const-string v3, ":  "

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    sget-object v6, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->VERSION:Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string/jumbo v6, "veumilbdLBe"

    const-string v6, "dlueibBeL v"

    const/4 v8, 0x0

    const-string v6, "BvlLo eideu"

    const-string v6, "Build Level"

    const/4 v7, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {v6, v4, v5}, Lcom/tencent/android/tpns/mqtt/util/Debug;->left(Ljava/lang/String;IC)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    sget-object v3, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->BUILD_LEVEL:Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string v3, "===u=b===================================="

    const-string v3, "======u==================================="

    const/4 v8, 0x4

    const-string v3, "======u==================================="

    const-string v3, "=========================================="

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x0

    move v8, v7

    sget-object v1, Lcom/tencent/android/tpns/mqtt/util/Debug;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string/jumbo v2, "orieVsupndp"

    const-string/jumbo v2, "spoueripVdn"

    const/4 v8, 0x2

    const-string/jumbo v2, "msiuendpqoV"

    const-string v2, "dumpVersion"

    const/4 v8, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string/jumbo v3, "mnsqitlComs"

    const-string/jumbo v3, "milsnCeoqmt"

    const/4 v8, 0x0

    const-string/jumbo v3, "oCmmltminsC"

    const-string v3, "ClientComms"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-interface {v1, v3, v2, v0}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x4

    return-void
.end method
