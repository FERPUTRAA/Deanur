.class public final Lcom/tencent/android/tpns/mqtt/util/Strings;
.super Ljava/lang/Object;


# static fields
.field private static final INDEX_NOT_FOUND:I = -0x1


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public static containsAny(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "u s~~i.~ @o@~~1b@r@~~t@@@Kon@~S /t~a~ @b l4~@ ~c~ ~~v -  m@o@@d~i@ @ o ~~/of~@l @@o~~y Mfs@@b  i"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    if-nez p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    const/4 p0, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return p0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/util/Strings;->toCharArray(Ljava/lang/CharSequence;)[C

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lcom/tencent/android/tpns/mqtt/util/Strings;->containsAny(Ljava/lang/CharSequence;[C)Z

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return p0
.end method

.method public static containsAny(Ljava/lang/CharSequence;[C)Z
    .locals 13

    const/4 v12, 0x3

    const/4 v11, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpns/mqtt/util/Strings;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x2

    const/4 v1, 0x0

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x2

    if-nez v0, :cond_5

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/util/Strings;->isEmpty([C)Z

    move-result v0

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    if-eqz v0, :cond_0

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x7

    goto/16 :goto_2

    :cond_0
    const/4 v11, 0x0

    move v12, v11

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x5

    array-length v2, p1

    const/4 v11, 0x5

    move v12, v11

    add-int/lit8 v3, v0, -0x1

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x2

    add-int/lit8 v4, v2, -0x1

    const/4 v12, 0x3

    move v5, v1

    move v5, v1

    const/4 v12, 0x1

    move v5, v1

    move v5, v1

    :goto_0
    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x4

    if-ge v5, v0, :cond_5

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-interface {p0, v5}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v6

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x1

    move v7, v1

    move v7, v1

    move v7, v1

    move v7, v1

    :goto_1
    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x5

    if-ge v7, v2, :cond_4

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x6

    aget-char v8, p1, v7

    const/4 v12, 0x6

    if-ne v8, v6, :cond_3

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-static {v6}, Ljava/lang/Character;->isHighSurrogate(C)Z

    move-result v8

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    const/4 v9, 0x1

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x6

    if-eqz v8, :cond_2

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-ne v7, v4, :cond_1

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x7

    return v9

    :cond_1
    const/4 v12, 0x1

    if-ge v5, v3, :cond_3

    const/4 v11, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    add-int/lit8 v8, v7, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x1

    aget-char v8, p1, v8

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x5

    add-int/lit8 v10, v5, 0x1

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-interface {p0, v10}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v10

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x2

    if-ne v8, v10, :cond_3

    :cond_2
    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x7

    return v9

    :cond_3
    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x5

    add-int/lit8 v7, v7, 0x1

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x1

    goto :goto_1

    :cond_4
    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x1

    add-int/lit8 v5, v5, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x6

    goto :goto_0

    :cond_5
    :goto_2
    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x3

    return v1
.end method

.method public static countMatches(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)I
    .locals 5

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpns/mqtt/util/Strings;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/util/Strings;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto :goto_1

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    move v0, v1

    move v0, v1

    const/4 v4, 0x6

    move v0, v1

    move v0, v1

    :goto_0
    invoke-static {p0, p1, v1}, Lcom/tencent/android/tpns/mqtt/util/Strings;->indexOf(Ljava/lang/CharSequence;Ljava/lang/CharSequence;I)I

    move-result v1

    const/4 v3, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 v2, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eq v1, v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {p1}, Ljava/lang/CharSequence;->length()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    add-int/2addr v1, v2

    const/4 v3, 0x1

    and-int/2addr v4, v3

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v0

    :cond_2
    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    return v1
.end method

.method public static equalsAny(Ljava/lang/CharSequence;[Ljava/lang/CharSequence;)Z
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v0, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v1, 0x0

    const/4 v6, 0x1

    if-nez p0, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-nez p1, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    move v2, v0

    move v2, v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    move v2, v1

    move v2, v1

    const/4 v6, 0x4

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    if-eqz p1, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    move v3, v1

    move v3, v1

    const/4 v6, 0x4

    move v3, v1

    move v3, v1

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    array-length v4, p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-ge v3, v4, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-nez v2, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    aget-object v2, p1, v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v2, p0}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v2, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_2

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    move v2, v1

    move v2, v1

    const/4 v6, 0x7

    move v2, v1

    move v2, v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_3

    :cond_2
    :goto_2
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    move v2, v0

    move v2, v0

    const/4 v6, 0x2

    move v2, v0

    move v2, v0

    :goto_3
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_1

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x1

    return v2
.end method

.method private static indexOf(Ljava/lang/CharSequence;Ljava/lang/CharSequence;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-interface {p1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p0, p1, p2}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result p0

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p0
.end method

.method public static isEmpty(Ljava/lang/CharSequence;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    if-eqz p0, :cond_1

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    if-nez p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p0, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p0, 0x1

    :goto_1
    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return p0
.end method

.method private static isEmpty([C)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    if-eqz p0, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    array-length p0, p0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    if-nez p0, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p0, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    const/4 p0, 0x1

    :goto_1
    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return p0
.end method

.method private static toCharArray(Ljava/lang/CharSequence;)[C
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    instance-of v0, p0, Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    move v5, v4

    check-cast p0, Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-object p0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {p0}, Ljava/lang/CharSequence;->length()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-array v1, v1, [C

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    if-ge v2, v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-interface {p0, v2}, Ljava/lang/CharSequence;->charAt(I)C

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    aput-char v3, v1, v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-object v1
.end method
