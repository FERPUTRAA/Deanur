.class Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender$PingRunnable;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "PingRunnable"
.end annotation


# static fields
.field private static final methodName:Ljava/lang/String; = "PingTask.run"


# instance fields
.field final synthetic this$0:Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;


# direct methods
.method private constructor <init>(Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender$PingRunnable;->this$0:Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender$1;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender$PingRunnable;-><init>(Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;)V

    const/4 v0, 0x4

    or-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "ybs@~~Kv ~  rt@@~ ic ~o ~~@-@ /i@l~@ t@@ ~4~~ou~a~/.@@io~dbbM@   @@ o@~~ Smf n~@~f~o~~@1 @s o@l@"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x1

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const-string v3, "P:imM QT sT"

    const-string v3, "Qnsi T MT:P"

    const/4 v7, 0x6

    const-string v3, "TT noQ:iMPg"

    const-string v3, "MQTT Ping: "

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender$PingRunnable;->this$0:Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v3}, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->access$100(Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->access$200()Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v2, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance v3, Ljava/lang/Long;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v3, v4, v5}, Ljava/lang/Long;-><init>(J)V

    const/4 v6, 0x6

    xor-int/2addr v7, v6

    const/4 v4, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x2

    aput-object v3, v2, v4

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string/jumbo v3, "rineEbduSeSclhdedrmctogxeuP"

    const-string/jumbo v3, "olEmiecnnPSregcxdeSuruddthe"

    const-string v3, "PrguluunddoiexecrSEnehSeetc"

    const-string v3, "ScheduledExecutorPingSender"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string v4, ".Tkruospgnni"

    const-string v4, "gkrnoasin.uT"

    const/4 v7, 0x7

    const-string/jumbo v4, "nuPgna.sqriT"

    const-string v4, "PingTask.run"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string v5, "660"

    const-string v5, "660"

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-interface {v1, v3, v4, v5, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender$PingRunnable;->this$0:Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v1}, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;->access$300(Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;)Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->checkForActivity()Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v7, 0x5

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v7, 0x0

    return-void
.end method
