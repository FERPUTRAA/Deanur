.class public Lcom/tencent/android/tpns/mqtt/persist/MemoryPersistence;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;


# instance fields
.field private data:Ljava/util/Hashtable;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public clear()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@os~ ~d@1@@  ~.nK@y~c~@~/~@aM-~~~@ ~~i~ ll@o@ @ ~~Sro4oim   t@t@ ~@fb/b@v ~@~@  ~fi~os~~u@   o@b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MemoryPersistence;->data:Ljava/util/Hashtable;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public close()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MemoryPersistence;->data:Ljava/util/Hashtable;

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method public containsKey(Ljava/lang/String;)Z
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MemoryPersistence;->data:Ljava/util/Hashtable;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Ljava/util/Hashtable;->containsKey(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return p1
.end method

.method public get(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/MqttPersistable;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MemoryPersistence;->data:Ljava/util/Hashtable;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    check-cast p1, Lcom/tencent/android/tpns/mqtt/MqttPersistable;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p1
.end method

.method public keys()Ljava/util/Enumeration;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MemoryPersistence;->data:Ljava/util/Hashtable;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/util/Hashtable;->keys()Ljava/util/Enumeration;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public open(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v0, 0x5

    const/4 v1, 0x4

    new-instance p1, Ljava/util/Hashtable;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p1}, Ljava/util/Hashtable;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/persist/MemoryPersistence;->data:Ljava/util/Hashtable;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public put(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttPersistable;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MemoryPersistence;->data:Ljava/util/Hashtable;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0, p1, p2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-void
.end method

.method public remove(Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MemoryPersistence;->data:Ljava/util/Hashtable;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Ljava/util/Hashtable;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-void
.end method
