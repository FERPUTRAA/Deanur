.class public Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;


# static fields
.field private static FILENAME_FILTER:Ljava/io/FilenameFilter; = null

.field private static final LOCK_FILENAME:Ljava/lang/String; = ".lck"

.field private static final MESSAGE_BACKUP_FILE_EXTENSION:Ljava/lang/String; = ".bup"

.field private static final MESSAGE_FILE_EXTENSION:Ljava/lang/String; = ".msg"


# instance fields
.field private clientDir:Ljava/io/File;

.field private dataDir:Ljava/io/File;

.field private fileLock:Lcom/tencent/android/tpns/mqtt/internal/FileLock;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-string/jumbo v0, "sesriru."

    const-string v0, ".rsriues"

    const/4 v2, 0x5

    const-string v0, "dremur.i"

    const-string/jumbo v0, "user.dir"

    const/4 v2, 0x2

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->fileLock:Lcom/tencent/android/tpns/mqtt/internal/FileLock;

    const/4 v2, 0x3

    new-instance v0, Ljava/io/File;

    const/4 v2, 0x6

    invoke-direct {v0, p1}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->dataDir:Ljava/io/File;

    const/4 v2, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method private checkIsOpen()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ii@o~cv~t~-1~o ~~ l@@nt~o~ ~ ~~l i a@ soo@fob o/@@ S4~@ by @/ K~~@~m@uMb.fd@~~~~@r~   @ ~@@@~@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;-><init>()V

    const/4 v2, 0x0

    throw v0
.end method

.method private static getFilenameFilter()Ljava/io/FilenameFilter;
    .locals 4

    const/4 v3, 0x2

    sget-object v0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->FILENAME_FILTER:Ljava/io/FilenameFilter;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/android/tpns/mqtt/persist/PersistanceFileNameFilter;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v1, "smg."

    const-string/jumbo v1, "mgs."

    const/4 v3, 0x5

    const-string v1, "gms."

    const-string v1, ".msg"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/tencent/android/tpns/mqtt/persist/PersistanceFileNameFilter;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    sput-object v0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->FILENAME_FILTER:Ljava/io/FilenameFilter;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->FILENAME_FILTER:Ljava/io/FilenameFilter;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object v0
.end method

.method private getFiles()[Ljava/io/File;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->checkIsOpen()V

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->getFilenameFilter()Ljava/io/FilenameFilter;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/io/File;->listFiles(Ljava/io/FilenameFilter;)[Ljava/io/File;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    throw v0
.end method

.method private isSafeChar(C)Z
    .locals 3

    const/4 v2, 0x4

    invoke-static {p1}, Ljava/lang/Character;->isJavaIdentifierPart(C)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/16 v0, 0x2d

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-ne p1, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 p1, 0x1

    :goto_1
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return p1
.end method

.method private restoreBackups(Ljava/io/File;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    new-instance v0, Lcom/tencent/android/tpns/mqtt/persist/PersistanceFileFilter;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string v1, ".pbu"

    const-string v1, ".bup"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {v0, v1}, Lcom/tencent/android/tpns/mqtt/persist/PersistanceFileFilter;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p1, v0}, Ljava/io/File;->listFiles(Ljava/io/FileFilter;)[Ljava/io/File;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz v0, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    move v2, v1

    move v2, v1

    const/4 v7, 0x6

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    array-length v3, v0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-ge v2, v3, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    new-instance v3, Ljava/io/File;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    aget-object v4, v0, v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v4}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    aget-object v5, v0, v2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v5}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    add-int/lit8 v5, v5, -0x4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v4, v1, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {v3, p1, v4}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    aget-object v4, v0, v2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v4, v3}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-nez v4, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v3}, Ljava/io/File;->delete()Z

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    aget-object v4, v0, v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v4, v3}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    goto :goto_0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-void

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-direct {p1}, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    throw p1
.end method


# virtual methods
.method public clear()V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->checkIsOpen()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->getFiles()[Ljava/io/File;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    array-length v2, v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-ge v1, v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    aget-object v2, v0, v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v2}, Ljava/io/File;->delete()Z

    const/4 v3, 0x2

    move v4, v3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method public close()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->fileLock:Lcom/tencent/android/tpns/mqtt/internal/FileLock;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->release()V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->getFiles()[Ljava/io/File;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    array-length v0, v0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    move v2, v1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    monitor-exit p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void

    :catchall_0
    move-exception v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    throw v0
.end method

.method public containsKey(Ljava/lang/String;)Z
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->checkIsOpen()V

    const/4 v4, 0x1

    new-instance v0, Ljava/io/File;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string p1, "g.sm"

    const-string p1, "gsm."

    const/4 v4, 0x6

    const-string p1, ".smg"

    const-string p1, ".msg"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v0, v1, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    return p1
.end method

.method public get(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/MqttPersistable;
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->checkIsOpen()V

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x2

    new-instance v1, Ljava/io/File;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    shr-int/2addr v12, v11

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string v4, "g.ms"

    const/4 v12, 0x6

    const-string v4, "gsm."

    const-string v4, ".msg"

    const/4 v11, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-direct {v1, v2, v3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    new-instance v2, Ljava/io/FileInputStream;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-direct {v2, v1}, Ljava/io/FileInputStream;-><init>(Ljava/io/File;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-virtual {v2}, Ljava/io/FileInputStream;->available()I

    move-result v7

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    new-array v5, v7, [B

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x0

    if-ge v0, v7, :cond_0

    const/4 v11, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    sub-int v1, v7, v0

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {v2, v5, v0, v1}, Ljava/io/FileInputStream;->read([BII)I

    move-result v1

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    add-int/2addr v0, v1

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    goto :goto_0

    :cond_0
    const/4 v11, 0x7

    move v12, v11

    invoke-virtual {v2}, Ljava/io/FileInputStream;->close()V

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x7

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    const/4 v6, 0x0

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x7

    const/4 v8, 0x0

    const/4 v11, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x4

    const/4 v9, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x2

    const/4 v10, 0x0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v4, p1

    move-object v4, p1

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-direct/range {v3 .. v10}, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;-><init>(Ljava/lang/String;[BII[BII)V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x0

    return-object v0

    :catch_0
    move-exception p1

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    goto :goto_1

    :catch_1
    move-exception p1

    :goto_1
    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x5

    if-eqz v0, :cond_1

    :try_start_2
    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-virtual {v0}, Ljava/io/FileInputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_2

    :catch_2
    :cond_1
    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x6

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-direct {v0, p1}, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;-><init>(Ljava/lang/Throwable;)V

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x5

    throw v0
.end method

.method public keys()Ljava/util/Enumeration;
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->checkIsOpen()V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->getFiles()[Ljava/io/File;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance v1, Ljava/util/Vector;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    array-length v2, v0

    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v1, v2}, Ljava/util/Vector;-><init>(I)V

    const/4 v7, 0x4

    const/4 v2, 0x0

    const/4 v7, 0x0

    move v6, v2

    const/4 v7, 0x0

    move v3, v2

    move v3, v2

    const/4 v7, 0x3

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    array-length v4, v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    if-ge v3, v4, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    aget-object v4, v0, v3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    add-int/lit8 v5, v5, -0x4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v4, v2, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v1, v4}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    return-object v0
.end method

.method public open(Ljava/lang/String;Ljava/lang/String;)V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->dataDir:Ljava/io/File;

    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz v0, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->dataDir:Ljava/io/File;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/io/File;->isDirectory()Z

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v0, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {p1}, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    throw p1

    :cond_1
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->dataDir:Ljava/io/File;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-nez v0, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->dataDir:Ljava/io/File;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/io/File;->mkdirs()Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    if-eqz v0, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_1

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;

    const/4 v6, 0x7

    invoke-direct {p1}, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x6

    throw p1

    :cond_3
    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->dataDir:Ljava/io/File;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/io/File;->canWrite()Z

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v0, :cond_9

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    move v2, v1

    move v2, v1

    :goto_2
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-ge v2, v3, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p1, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {p0, v3}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->isSafeChar(C)Z

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v4, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    :cond_4
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto :goto_2

    :cond_5
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-string p1, "-"

    const-string p1, "-"

    const-string p1, "-"

    const-string p1, "-"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :goto_3
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-ge v1, p1, :cond_7

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/String;->charAt(I)C

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->isSafeChar(C)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz v2, :cond_6

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    :cond_6
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto :goto_3

    :cond_7
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-nez p1, :cond_8

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance p2, Ljava/io/File;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->dataDir:Ljava/io/File;

    const/4 v5, 0x7

    move v6, v5

    invoke-direct {p2, v0, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v5, 0x0

    move v6, v5

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v5, 0x6

    invoke-virtual {p2}, Ljava/io/File;->exists()Z

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-nez p1, :cond_8

    const/4 v5, 0x7

    or-int/2addr v6, v5

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/io/File;->mkdir()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :cond_8
    :try_start_1
    const/4 v6, 0x4

    new-instance p1, Lcom/tencent/android/tpns/mqtt/internal/FileLock;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v6, 0x4

    const-string v0, ".clk"

    const-string/jumbo v0, "l.ck"

    const/4 v6, 0x2

    const-string v0, "ckl."

    const-string v0, ".lck"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {p1, p2, v0}, Lcom/tencent/android/tpns/mqtt/internal/FileLock;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->fileLock:Lcom/tencent/android/tpns/mqtt/internal/FileLock;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :try_start_2
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->restoreBackups(Ljava/io/File;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    monitor-exit p0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    return-void

    :catchall_1
    move-exception p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    throw p1

    :cond_9
    const/4 v6, 0x6

    const/4 v5, 0x6

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {p1}, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;-><init>()V

    const/4 v5, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    throw p1
.end method

.method public put(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttPersistable;)V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->checkIsOpen()V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    new-instance v0, Ljava/io/File;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v3, "gms."

    const/4 v6, 0x1

    const-string/jumbo v3, "m.gs"

    const-string v3, ".msg"

    const/4 v6, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {v0, v1, v2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    new-instance v1, Ljava/io/File;

    const/4 v6, 0x0

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const-string p1, ".pub"

    const-string p1, "bp.u"

    const/4 v6, 0x2

    const-string p1, ".upb"

    const-string p1, ".bup"

    const/4 v6, 0x3

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {v1, v2, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz p1, :cond_0

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-nez p1, :cond_0

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    :cond_0
    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-instance p1, Ljava/io/FileOutputStream;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {p1, v0}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V

    const/4 v6, 0x7

    invoke-interface {p2}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getHeaderBytes()[B

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {p2}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getHeaderOffset()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-interface {p2}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getHeaderLength()I

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1, v2, v3, v4}, Ljava/io/FileOutputStream;->write([BII)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {p2}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getPayloadBytes()[B

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz v2, :cond_1

    const/4 v6, 0x4

    invoke-interface {p2}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getPayloadBytes()[B

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {p2}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getPayloadOffset()I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {p2}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getPayloadLength()I

    move-result p2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p1, v2, v3, p2}, Ljava/io/FileOutputStream;->write([BII)V

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/io/FileOutputStream;->getFD()Ljava/io/FileDescriptor;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p2}, Ljava/io/FileDescriptor;->sync()V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/io/FileOutputStream;->close()V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/io/File;->delete()Z
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz p1, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v1, v0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-nez p1, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1, v0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_0

    :catch_0
    move-exception p1

    :try_start_1
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    new-instance p2, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {p2, p1}, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;-><init>(Ljava/lang/Throwable;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    throw p2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result p2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz p2, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v1, v0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    move-result p2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-nez p2, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1, v0}, Ljava/io/File;->renameTo(Ljava/io/File;)Z

    :cond_4
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    throw p1
.end method

.method public remove(Ljava/lang/String;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->checkIsOpen()V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v0, Ljava/io/File;

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;->clientDir:Ljava/io/File;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const-string p1, "g.sm"

    const-string p1, "gm.s"

    const/4 v4, 0x4

    const-string p1, ".gsm"

    const-string p1, ".msg"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0, v1, p1}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/io/File;->exists()Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/io/File;->delete()Z

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-void
.end method
