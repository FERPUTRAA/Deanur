.class public Lcom/tencent/android/tpns/mqtt/persist/PersistanceFileNameFilter;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/FilenameFilter;


# instance fields
.field private final fileExtension:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x6

    move v1, v0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/persist/PersistanceFileNameFilter;->fileExtension:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public accept(Ljava/io/File;Ljava/lang/String;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " Kso@u@ @~~~~@~~@@@of@ @/o @  oM b@l@4v ~ia @1 ~o m~ ibb~s~@~o@l~y~~t~ni c/@~.~@@ ~ -t@Sr ~~@fd~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/persist/PersistanceFileNameFilter;->fileExtension:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p1

    const/4 v1, 0x0

    const/4 v0, 0x2

    return p1
.end method
