.class Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/IMqttActionListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "MqttReconnectActionListener"
.end annotation


# instance fields
.field final methodName:Ljava/lang/String;

.field final synthetic this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->methodName:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method private rescheduleReconnectCycle(I)V
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "K~sl~~y~u.@io@@/~~ @   -ato @l@ ~ m~ M~ @@~sv~ /b~i ~@ t f1nS@~@@o c~@ 4 ~~@bo~o~@@@if@@o@ r~bd~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->methodName:Ljava/lang/String;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string/jumbo v1, "lRsmecoytre:ehlencneduCec"

    const-string/jumbo v1, "scsdrRty:eenecenlcChueleo"

    const/4 v8, 0x2

    const-string v1, "elcloCdesReorhetc:nececyu"

    const-string v1, ":rescheduleReconnectCycle"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-string v2, "MttCcbynmltisqn"

    const-string/jumbo v2, "lncmAiyttsCtqnM"

    const/4 v8, 0x7

    const-string v2, "MqttAsyncClient"

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-string v3, "505"

    const-string v3, "055"

    const/4 v8, 0x3

    const-string v3, "505"

    const/4 v8, 0x6

    const/4 v4, 0x2

    const/4 v8, 0x3

    const/4 v4, 0x2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-object v5, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {v5}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$700(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    move v8, v7

    aput-object v5, v4, v6

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$600()I

    move-result v5

    const/4 v8, 0x1

    const/4 v7, 0x6

    invoke-static {v5}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    const/4 v6, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x1

    aput-object v5, v4, v6

    const/4 v8, 0x4

    const/4 v7, 0x6

    invoke-interface {v1, v2, v0, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$800()Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v7, 0x4

    and-int/2addr v8, v7

    invoke-static {v1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$900(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;)Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->isAutomaticReconnect()Z

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-eqz v1, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$1000(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;)Ljava/util/Timer;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-eqz v1, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {v1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$1000(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;)Ljava/util/Timer;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance v2, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$ReconnectTask;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v8, 0x0

    const/4 v4, 0x0

    const/4 v8, 0x5

    const/4 v4, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$ReconnectTask;-><init>(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$1;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    int-to-long v3, p1

    const/4 v7, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v1, v2, v3, v4}, Ljava/util/Timer;->schedule(Ljava/util/TimerTask;J)V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$602(I)I

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v8, 0x4

    const/4 v7, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$400(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;)V

    :cond_1
    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    monitor-exit v0

    const/4 v8, 0x3

    const/4 v7, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    throw p1
.end method


# virtual methods
.method public onFailure(Lcom/tencent/android/tpns/mqtt/IMqttToken;Ljava/lang/Throwable;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->methodName:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    invoke-interface {p1}, Lcom/tencent/android/tpns/mqtt/IMqttToken;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {p1}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    aput-object p1, v1, v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo p1, "sltnctuenoCMqty"

    const-string/jumbo p1, "tiqeocytCMlnnts"

    const/4 v4, 0x6

    const-string/jumbo p1, "qClsnctpMiAetny"

    const-string p1, "MqttAsyncClient"

    const/4 v3, 0x1

    move v4, v3

    const-string v2, "502"

    const-string v2, "205"

    const/4 v4, 0x3

    const-string v2, "052"

    const-string v2, "502"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {p2, p1, v0, v2, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$600()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const p2, 0x1f400

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-ge p1, p2, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$600()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    mul-int/lit8 p1, p1, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$602(I)I

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$600()I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->rescheduleReconnectCycle(I)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method

.method public onSuccess(Lcom/tencent/android/tpns/mqtt/IMqttToken;)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->methodName:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-interface {p1}, Lcom/tencent/android/tpns/mqtt/IMqttToken;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-interface {p1}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v3, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    aput-object p1, v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string/jumbo p1, "sCyttbMiqnqlenc"

    const-string/jumbo p1, "ietlnbnsyctqCtM"

    const/4 v6, 0x2

    const-string p1, "cysnAltqCMtnist"

    const-string p1, "MqttAsyncClient"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string v4, "501"

    const/4 v6, 0x5

    const-string v4, "150"

    const-string v4, "501"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-interface {v0, p1, v1, v4, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object p1, p1, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->setRestingState(Z)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectActionListener;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$500(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-void
.end method
