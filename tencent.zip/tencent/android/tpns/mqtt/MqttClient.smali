.class public Lcom/tencent/android/tpns/mqtt/MqttClient;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/IMqttClient;


# instance fields
.field protected aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

.field protected timeToWait:J


# direct methods
.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x3

    new-instance v0, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/tencent/android/tpns/mqtt/persist/MqttDefaultFilePersistence;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-direct {p0, p1, p2, v0}, Lcom/tencent/android/tpns/mqtt/MqttClient;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-wide/16 v0, -0x1

    const/4 v3, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->timeToWait:J

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-direct {v0, p1, p2, p3}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;)V

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;Ljava/util/concurrent/ScheduledExecutorService;)V
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v8, 0x7

    move v9, v8

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v8, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v9, 0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->timeToWait:J

    const/4 v8, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v8, 0x0

    shl-int/2addr v9, v8

    new-instance v6, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;

    const/4 v8, 0x1

    move v9, v8

    invoke-direct {v6, p4}, Lcom/tencent/android/tpns/mqtt/ScheduledExecutorPingSender;-><init>(Ljava/util/concurrent/ScheduledExecutorService;)V

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v7, p4

    move-object v7, p4

    move-object v7, p4

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-direct/range {v2 .. v7}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;-><init>(Ljava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;Lcom/tencent/android/tpns/mqtt/MqttPingSender;Ljava/util/concurrent/ExecutorService;)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    return-void
.end method

.method public static generateClientId()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o/sM@~1@@o/o~  io@b~iS@ @@~ @  ytf@ v.  c~~u@~fl~@ mt@od~@~@osn-~a@K~ i~ ~@ @~b~  ~lb @r~4@@~~~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->generateClientId()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public close()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->close(Z)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-void
.end method

.method public close(Z)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->close(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public connect()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttSecurityException;,
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v1, 0x2

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->connect(Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public connect(Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttSecurityException;,
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1, v1, v1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->connect(Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;Ljava/lang/Object;Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->getTimeToWait()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {p1, v0, v1}, Lcom/tencent/android/tpns/mqtt/IMqttToken;->waitForCompletion(J)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method public connectWithResult(Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;)Lcom/tencent/android/tpns/mqtt/IMqttToken;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttSecurityException;,
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p1, v1, v1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->connect(Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;Ljava/lang/Object;Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->getTimeToWait()J

    move-result-wide v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {p1, v0, v1}, Lcom/tencent/android/tpns/mqtt/IMqttToken;->waitForCompletion(J)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-object p1
.end method

.method public disconnect()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->disconnect()Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/IMqttToken;->waitForCompletion()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public disconnect(J)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x0

    shl-int/2addr v3, v1

    invoke-virtual {v0, p1, p2, v1, v1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->disconnect(JLjava/lang/Object;Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {p1}, Lcom/tencent/android/tpns/mqtt/IMqttToken;->waitForCompletion()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method public disconnectForcibly()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->disconnectForcibly()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void
.end method

.method public disconnectForcibly(J)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->disconnectForcibly(J)V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public disconnectForcibly(JJ)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p2, p3, p4}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->disconnectForcibly(JJ)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method public disconnectForcibly(JJZ)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    move-wide v1, p1

    move-wide v3, p3

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    move v5, p5

    move v5, p5

    const/4 v7, 0x1

    move v5, p5

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual/range {v0 .. v5}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->disconnectForcibly(JJZ)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-void
.end method

.method public getClientId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public getCurrentServerURI()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->getCurrentServerURI()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public getDebug()Lcom/tencent/android/tpns/mqtt/util/Debug;
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->getDebug()Lcom/tencent/android/tpns/mqtt/util/Debug;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public getPendingDeliveryTokens()[Lcom/tencent/android/tpns/mqtt/IMqttDeliveryToken;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->getPendingDeliveryTokens()[Lcom/tencent/android/tpns/mqtt/IMqttDeliveryToken;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    return-object v0
.end method

.method public getServerURI()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x4

    const/4 v1, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->getServerURI()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public getTimeToWait()J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->timeToWait:J

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-wide v0
.end method

.method public getTopic(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/MqttTopic;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->getTopic(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/MqttTopic;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object p1
.end method

.method public isConnected()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->isConnected()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public messageArrivedComplete(II)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->messageArrivedComplete(II)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public publish(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttMessage;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;,
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0, p1, p2, v1, v1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->publish(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttMessage;Ljava/lang/Object;Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)Lcom/tencent/android/tpns/mqtt/IMqttDeliveryToken;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->getTimeToWait()J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {p1, v0, v1}, Lcom/tencent/android/tpns/mqtt/IMqttToken;->waitForCompletion(J)V

    const/4 v2, 0x5

    shl-int/2addr v3, v2

    return-void
.end method

.method public publish(Ljava/lang/String;[BIZ)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;,
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0, p2}, Lcom/tencent/android/tpns/mqtt/MqttMessage;-><init>([B)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0, p3}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setQos(I)V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0, p4}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setRetained(Z)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->publish(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttMessage;)V

    const/4 v1, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public reconnect()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->reconnect()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public setCallback(Lcom/tencent/android/tpns/mqtt/MqttCallback;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->setCallback(Lcom/tencent/android/tpns/mqtt/MqttCallback;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public setManualAcks(Z)V
    .locals 3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->setManualAcks(Z)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public setTimeToWait(J)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x4

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    cmp-long v0, p1, v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-ltz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-wide p1, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->timeToWait:J

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    throw p1
.end method

.method public subscribe(Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, p1, v0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribe([Ljava/lang/String;[I)V

    const/4 v2, 0x5

    return-void
.end method

.method public subscribe(Ljava/lang/String;I)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x5

    filled-new-array {p2}, [I

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribe([Ljava/lang/String;[I)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public subscribe(Ljava/lang/String;ILcom/tencent/android/tpns/mqtt/IMqttMessageListener;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x6

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    filled-new-array {p2}, [I

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-array v0, v0, [Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    aput-object p3, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, p1, p2, v0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribe([Ljava/lang/String;[I[Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public subscribe(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v4, 0x6

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    filled-new-array {v0}, [I

    move-result-object v1

    const/4 v4, 0x4

    new-array v0, v0, [Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    aput-object p2, v0, v2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0, p1, v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribe([Ljava/lang/String;[I[Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method

.method public subscribe([Ljava/lang/String;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    array-length v0, p1

    const/4 v5, 0x0

    new-array v1, v0, [I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-ge v2, v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    aput v3, v1, v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0, p1, v1}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribe([Ljava/lang/String;[I)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void
.end method

.method public subscribe([Ljava/lang/String;[I)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x0

    and-int/2addr v4, v3

    invoke-virtual {v0, p1, p2, v1, v1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->subscribe([Ljava/lang/String;[ILjava/lang/Object;Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->getTimeToWait()J

    move-result-wide v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {p1, v0, v1}, Lcom/tencent/android/tpns/mqtt/IMqttToken;->waitForCompletion(J)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {p1}, Lcom/tencent/android/tpns/mqtt/IMqttToken;->getGrantedQos()[I

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x4

    move v1, v0

    move v1, v0

    const/4 v4, 0x5

    move v1, v0

    move v1, v0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    array-length v2, p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-ge v1, v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    aget v2, p1, v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    aput v2, p2, v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    array-length p1, p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-ne p1, v1, :cond_2

    const/4 v3, 0x5

    move v4, v3

    aget p1, p2, v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/16 p2, 0x80

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eq p1, p2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x4

    goto :goto_1

    :cond_1
    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v4, 0x7

    invoke-direct {p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    throw p1

    :cond_2
    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method

.method public subscribe([Ljava/lang/String;[I[Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0, p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribe([Ljava/lang/String;[I)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 p2, 0x0

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    array-length v0, p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-ge p2, v0, :cond_0

    const/4 v3, 0x6

    move v4, v3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v4, 0x4

    const/4 v3, 0x6

    aget-object v1, p1, p2

    aget-object v2, p3, p2

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {v0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->setMessageListener(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)V

    const/4 v4, 0x6

    add-int/lit8 p2, p2, 0x1

    const/4 v3, 0x5

    or-int/2addr v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    return-void
.end method

.method public subscribe([Ljava/lang/String;[Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v5, 0x0

    array-length v0, p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-array v1, v0, [I

    const/4 v5, 0x2

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-ge v2, v0, :cond_0

    const/4 v4, 0x2

    move v5, v4

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    aput v3, v1, v2

    const/4 v5, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0, p1, v1, p2}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribe([Ljava/lang/String;[I[Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-void
.end method

.method public subscribeWithResponse(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/IMqttToken;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    filled-new-array {v0}, [I

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0, p1, v0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribeWithResponse([Ljava/lang/String;[I)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p1
.end method

.method public subscribeWithResponse(Ljava/lang/String;I)Lcom/tencent/android/tpns/mqtt/IMqttToken;
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    filled-new-array {p2}, [I

    move-result-object p2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribeWithResponse([Ljava/lang/String;[I)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p1
.end method

.method public subscribeWithResponse(Ljava/lang/String;ILcom/tencent/android/tpns/mqtt/IMqttMessageListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    filled-new-array {p2}, [I

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-array v0, v0, [Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;

    const/4 v3, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    aput-object p3, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p0, p1, p2, v0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribeWithResponse([Ljava/lang/String;[I[Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object p1
.end method

.method public subscribeWithResponse(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    filled-new-array {v0}, [I

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    new-array v0, v0, [Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    aput-object p2, v0, v2

    const/4 v4, 0x5

    invoke-virtual {p0, p1, v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribeWithResponse([Ljava/lang/String;[I[Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-object p1
.end method

.method public subscribeWithResponse([Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/IMqttToken;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    array-length v0, p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-array v1, v0, [I

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-ge v2, v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v3, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    aput v3, v1, v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0, p1, v1}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribeWithResponse([Ljava/lang/String;[I)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-object p1
.end method

.method public subscribeWithResponse([Ljava/lang/String;[I)Lcom/tencent/android/tpns/mqtt/IMqttToken;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, p1, p2, v1, v1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->subscribe([Ljava/lang/String;[ILjava/lang/Object;Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->getTimeToWait()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {p1, v0, v1}, Lcom/tencent/android/tpns/mqtt/IMqttToken;->waitForCompletion(J)V

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p1
.end method

.method public subscribeWithResponse([Ljava/lang/String;[I[Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p0, p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribeWithResponse([Ljava/lang/String;[I)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    array-length v1, p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-ge v0, v1, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v1, v1, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    aget-object v2, p1, v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    aget-object v3, p3, v0

    const/4 v4, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1, v2, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->setMessageListener(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    return-object p2
.end method

.method public subscribeWithResponse([Ljava/lang/String;[Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    array-length v0, p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-array v1, v0, [I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    if-ge v2, v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v3, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    aput v3, v1, v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0, p1, v1, p2}, Lcom/tencent/android/tpns/mqtt/MqttClient;->subscribeWithResponse([Ljava/lang/String;[I[Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-object p1
.end method

.method public unsubscribe(Ljava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    filled-new-array {p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpns/mqtt/MqttClient;->unsubscribe([Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public unsubscribe([Ljava/lang/String;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttClient;->aClient:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v1, 0x2

    and-int/2addr v3, v1

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x2

    invoke-virtual {v0, p1, v1, v1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->unsubscribe([Ljava/lang/String;Ljava/lang/Object;Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)Lcom/tencent/android/tpns/mqtt/IMqttToken;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttClient;->getTimeToWait()J

    move-result-wide v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-interface {p1, v0, v1}, Lcom/tencent/android/tpns/mqtt/IMqttToken;->waitForCompletion(J)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method
