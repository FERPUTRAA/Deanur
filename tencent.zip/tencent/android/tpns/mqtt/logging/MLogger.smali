.class public Lcom/tencent/android/tpns/mqtt/logging/MLogger;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/logging/Logger;


# static fields
.field private static final TAG:Ljava/lang/String; = "MLogger"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method private log(Ljava/lang/String;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "f@siol~ b ~@@ ~~t@~@~S-b @~~o @~ ~~i~/@@ f@@lb @ooa @ K@4 vu @~~d/ o@ @mscy~M@o.~i  ~n~t@~1~~ @~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public config(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v1, "c-:mrusc  sgosCsnafil"

    const-string v1, " lssisr:f-cnosucoC ga"

    const/4 v3, 0x1

    const-string v1, "gacfoor o:nCscul -iss"

    const-string v1, "config - sourceClass:"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string p1, "eu:tdbeh mcoros"

    const-string p1, ", hmuc:dertoose"

    const/4 v3, 0x0

    const-string/jumbo p1, "odt Mhu:,erucos"

    const-string p1, ", sourceMethod:"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const-string/jumbo p1, "sp m,:"

    const-string p1, ", msg:"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v3, 0x3

    return-void
.end method

.method public config(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 3

    const/4 v1, 0x3

    move v2, v1

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x6

    const-string v0, "C-i cnsoqsso:ela ougf"

    const-string v0, "freuo osslons-aCcgi: "

    const/4 v2, 0x5

    const-string v0, "config - sourceClass:"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const-string/jumbo p1, "oescud :hoest,b"

    const-string p1, " d:hsbuceo,toeM"

    const-string/jumbo p1, "ts:mehdeo Mrou,"

    const-string p1, ", sourceMethod:"

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-string p1, ":um og"

    const-string/jumbo p1, "ug:ms "

    const-string p1, " :g,mb"

    const-string p1, ", msg:"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public config(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x6

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x6

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    const-string/jumbo p5, "ofCra uusec nolc-gss:"

    const-string p5, "config - sourceClass:"

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    const-string p1, " orodtppeMu:ecs"

    const-string/jumbo p1, "ooM hr:pdetscue"

    const/4 v1, 0x6

    const-string p1, " ht:r,eeqcsMoou"

    const-string p1, ", sourceMethod:"

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    const-string/jumbo p1, "qmssg "

    const-string/jumbo p1, "s qg:m"

    const-string p1, ",smmg:"

    const-string p1, ", msg:"

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public dumpTrace()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string/jumbo v1, "nro:o  sesscauCsil-"

    const-string/jumbo v1, "sns :fec-Crsiuos la"

    const/4 v3, 0x5

    const-string v1, "fine - sourceClass:"

    const/4 v2, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    or-int/2addr v3, v2

    const-string/jumbo p1, "re oobmcshtM:du"

    const-string p1, "ctrmouM s:hdoee"

    const/4 v3, 0x5

    const-string p1, "cMosuhuetrd ,:e"

    const-string p1, ", sourceMethod:"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string/jumbo p1, "op,: m"

    const-string/jumbo p1, "m:, og"

    const/4 v3, 0x5

    const-string p1, "g,q:ms"

    const-string p1, ", msg:"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method

.method public fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string v0, "cnsaio:slrf  se-Cus"

    const-string v0, "fine - sourceClass:"

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const-string p1, "b dmotcsrhuoe:,"

    const-string p1, ":cs,dbte uohoer"

    const/4 v2, 0x4

    const-string p1, ",uMooosc: eehdr"

    const-string p1, ", sourceMethod:"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string p1, ",smgub"

    const-string/jumbo p1, "usgm:,"

    const/4 v2, 0x6

    const-string/jumbo p1, "us ,:m"

    const-string p1, ", msg:"

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    const-string p5, "-ee psupcrsaf C:ils"

    const-string p5, "i ensr:plsasuC -efc"

    const/4 v1, 0x3

    const-string/jumbo p5, "iforcseCqsualn s:e-"

    const-string p5, "fine - sourceClass:"

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v0, 0x0

    or-int/2addr v1, v0

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    const-string/jumbo p1, "qus ret,cMhoods"

    const-string/jumbo p1, "orouhst,q c:dMe"

    const/4 v1, 0x5

    const-string/jumbo p1, "tremMcu she,odo"

    const-string p1, ", sourceMethod:"

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    const-string p1, ": s,os"

    const-string/jumbo p1, "m,s:s "

    const/4 v1, 0x4

    const-string p1, ",sm:gb"

    const-string p1, ", msg:"

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    const/4 v0, 0x1

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public finer(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const-string v1, "enois:uef- smucl rrs"

    const-string v1, " -omecu fisnslresr:a"

    const/4 v3, 0x3

    const-string/jumbo v1, "ileusrsp ce:o-Car nf"

    const-string v1, "finer - sourceClass:"

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo p1, "ouMoh etqd,:rcs"

    const-string/jumbo p1, "odu,oorehsM: tc"

    const/4 v3, 0x6

    const-string/jumbo p1, "u,st rsdocMheeo"

    const-string p1, ", sourceMethod:"

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string p1, ",:mmgb"

    const-string p1, " :g,mb"

    const/4 v3, 0x1

    const-string/jumbo p1, "mg so,"

    const-string p1, ", msg:"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    and-int/2addr v3, v2

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method public finer(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    const-string v0, "fieCcounessu ra-:lsr"

    const/4 v2, 0x6

    const-string v0, "feslubsc rnesrio -a:"

    const-string v0, "finer - sourceClass:"

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string p1, "e tusdueMh,:opr"

    const-string p1, ":ohestrpdo eu,M"

    const/4 v2, 0x0

    const-string p1, "cu, oorphtde:es"

    const-string p1, ", sourceMethod:"

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string/jumbo p1, "s:q qg"

    const-string p1, " sqg,:"

    const/4 v2, 0x6

    const-string p1, ", sm:s"

    const-string p1, ", msg:"

    const/4 v2, 0x2

    const/4 v1, 0x7

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public finer(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    const/4 v0, 0x7

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    const-string p5, "-s mlafs Cnuerse:oci"

    const-string/jumbo p5, "oissf neuCs ce-ra:rl"

    const-string p5, "c usorol -sesfeaCrn:"

    const-string p5, "finer - sourceClass:"

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    const-string p1, " duo:bhterMscoe"

    const-string p1, ", sourceMethod:"

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    const-string/jumbo p1, "us:mm "

    const-string/jumbo p1, "s:mmg "

    const/4 v1, 0x0

    const-string p1, ":pgs m"

    const-string p1, ", msg:"

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    return-void
.end method

.method public finest(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    move v3, v2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v1, "cuofseesqoCsr  nsla:t"

    const-string/jumbo v1, "iscfossuen:orl tCa se"

    const/4 v3, 0x2

    const-string v1, "-fsalrete:ssnui ssC c"

    const-string v1, "finest - sourceClass:"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo p1, "ohcmr,odesMbe u"

    const-string p1, "dMrhsbee,couo: "

    const/4 v3, 0x3

    const-string p1, ", :roeduooeMths"

    const-string p1, ", sourceMethod:"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo p1, "usm:, "

    const/4 v3, 0x7

    const-string/jumbo p1, "m :s,b"

    const-string p1, ", msg:"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method

.method public finest(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string v0, "cinseluts op: Crsaef-"

    const-string/jumbo v0, "stua  lpiCfes-:nscroe"

    const-string v0, " cCeslsptare-nisuo s:"

    const-string v0, "finest - sourceClass:"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    const-string p1, " :ostceqqerudMh"

    const-string p1, "eut: eohqrdcMos"

    const/4 v2, 0x4

    const-string p1, "chseude:r,tosMo"

    const-string p1, ", sourceMethod:"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string/jumbo p1, "ss:m g"

    const-string p1, "g ss,:"

    const/4 v2, 0x4

    const-string p1, ", msg:"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public finest(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    const-string p5, "cltsosfmCi:oses runae"

    const-string/jumbo p5, "nesm sso:ilfustrCeac "

    const/4 v1, 0x1

    const-string p5, "Can eb css-soflut:sre"

    const-string p5, "finest - sourceClass:"

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    const-string p1, "ceoueduMot,:ohs"

    const-string p1, "htcsodeMo,:eou "

    const/4 v1, 0x6

    const-string/jumbo p1, "reohtudps,Mco:e"

    const-string p1, ", sourceMethod:"

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    const-string p1, ",:qs g"

    const-string p1, "g :,sb"

    const/4 v1, 0x4

    const-string p1, ":gs,s "

    const-string p1, ", msg:"

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public formatMessage(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x4

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p1
.end method

.method public info(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v1, "a:fmuonCssuo i-rl s"

    const-string/jumbo v1, "lC:cr-ussoa  uiosnf"

    const/4 v3, 0x5

    const-string v1, "ac -oosssorlfeu :in"

    const-string/jumbo v1, "info - sourceClass:"

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string p1, "hr cpbuee,M:doo"

    const-string p1, " eo:u,rpeMshocd"

    const/4 v3, 0x6

    const-string p1, ": otocuer,sMude"

    const-string p1, ", sourceMethod:"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo p1, "qp: m,"

    const-string/jumbo p1, "s q,:m"

    const/4 v3, 0x0

    const-string p1, ":mqg,s"

    const-string p1, ", msg:"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void
.end method

.method public info(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const-string v0, " ossl onci:Cfssru-a"

    const-string/jumbo v0, "info - sourceClass:"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const-string/jumbo p1, "u:sm hrctsee,od"

    const-string p1, "ecshs:rMtd, oeu"

    const/4 v2, 0x0

    const-string/jumbo p1, "rse,oeo chMudt:"

    const-string p1, ", sourceMethod:"

    const/4 v2, 0x2

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const-string/jumbo p1, "msm ,b"

    const-string/jumbo p1, "s,mm :"

    const/4 v2, 0x2

    const-string/jumbo p1, "um: ,g"

    const-string p1, ", msg:"

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public info(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    const-string/jumbo p5, "ossuCi:pec-  onlraf"

    const-string p5, "cs:lorCioe  s-nofua"

    const/4 v1, 0x5

    const-string p5, "cusoirlsq afesn o:-"

    const-string/jumbo p5, "info - sourceClass:"

    const/4 v1, 0x6

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    const-string/jumbo p1, "rosdt, oscMeb:u"

    const-string/jumbo p1, "ouctdbreo:es ,M"

    const/4 v1, 0x7

    const-string p1, ", sourceMethod:"

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x4

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    const-string p1, "gs m:u"

    const-string/jumbo p1, "u gm:s"

    const/4 v1, 0x6

    const-string p1, ",ms og"

    const-string p1, ", msg:"

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method

.method public initialise(Ljava/util/ResourceBundle;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public isLoggable(I)Z
    .locals 2

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    return p1
.end method

.method public log(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    const-string/jumbo p5, "s:slcbo-ou raCpslg"

    const-string/jumbo p5, "s rg-lopasCsloc:eu"

    const/4 v1, 0x3

    const-string p5, "cos:aCuls  slg-oeu"

    const-string/jumbo p5, "log - sourceClass:"

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p1, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    const-string p2, "ed e:uhptqMosoc"

    const-string p2, "h:Moeoduqe ,sct"

    const/4 v1, 0x3

    const-string/jumbo p2, "oeo:,retqcMs hu"

    const-string p2, ", sourceMethod:"

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    const-string/jumbo p2, "sgs,: "

    const-string/jumbo p2, "s s:g,"

    const/4 v1, 0x7

    const-string p2, ":m,m s"

    const-string p2, ", msg:"

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public setResourceName(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public severe(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const-string/jumbo v1, "s smrrrslce avsC:ueoe"

    const-string/jumbo v1, "server - sourceClass:"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string p1, "cr: ootMheso,de"

    const-string/jumbo p1, "so:Mooc,t heder"

    const/4 v3, 0x0

    const-string p1, "hcroebMdu:e,t s"

    const-string p1, ", sourceMethod:"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const-string/jumbo p1, "u, mg:"

    const-string p1, ", msg:"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public severe(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo v0, "s sosCep-raevb:rc urs"

    const-string/jumbo v0, "uss abr roervsscelC-:"

    const/4 v2, 0x7

    const-string v0, " e:-scsvqrlar erseCos"

    const-string/jumbo v0, "server - sourceClass:"

    const/4 v2, 0x2

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string p1, " esootsd:uMrchu"

    const-string/jumbo p1, "soM,rcu:ehudt o"

    const/4 v2, 0x4

    const-string p1, ", Mmtdcruhsoeoe"

    const-string p1, ", sourceMethod:"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string/jumbo p1, "mps og"

    const-string p1, "gpm:s "

    const/4 v2, 0x0

    const-string p1, " :gsmb"

    const-string p1, ", msg:"

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public severe(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x2

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    const-string/jumbo p5, "v-sCscuee:ulr rqoasrs"

    const-string p5, "  sCles:q-cvsrarrsoue"

    const-string/jumbo p5, "lers e p-ouercs:Csvra"

    const-string/jumbo p5, "server - sourceClass:"

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    const-string/jumbo p1, "oue:,dc qershsM"

    const-string/jumbo p1, "r:shedMos,ueoc "

    const/4 v1, 0x4

    const-string p1, "cosstuhoee,rM: "

    const-string p1, ", sourceMethod:"

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    const-string p1, ":m,mms"

    const-string/jumbo p1, "s:gmm,"

    const/4 v1, 0x2

    const-string p1, " g,mos"

    const-string p1, ", msg:"

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public trace(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    const-string/jumbo p5, "rcouoelcsC srae:a-t "

    const/4 v1, 0x2

    const-string/jumbo p5, "trace - sourceClass:"

    const/4 v0, 0x4

    move v1, v0

    invoke-virtual {p1, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    const-string/jumbo p2, "ubceob Mhd:r,eo"

    const-string/jumbo p2, "thoMdbrceo ,:ue"

    const/4 v1, 0x3

    const-string p2, "dMu,stu rooe:eh"

    const-string p2, ", sourceMethod:"

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    const-string p2, "gp ,m:"

    const-string/jumbo p2, "u:g ,m"

    const/4 v1, 0x5

    const-string p2, ":,qgm "

    const-string p2, ", msg:"

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v1, 0x7

    return-void
.end method

.method public warning(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string/jumbo v1, "lis-sgCosa:  earwnuscp"

    const-string v1, "-l:sCaepsauigwnrocns  "

    const/4 v3, 0x0

    const-string/jumbo v1, "rnamssur:eonls gcCai w"

    const-string/jumbo v1, "warning - sourceClass:"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string p1, ",udoohcsr eo:eq"

    const-string p1, "hMdeor uq,coes:"

    const/4 v3, 0x3

    const-string/jumbo p1, "udo ob,:ectserM"

    const-string p1, ", sourceMethod:"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string/jumbo p1, "u:gss,"

    const-string p1, "g s,:s"

    const/4 v3, 0x5

    const-string p1, "gp: m,"

    const-string p1, ", msg:"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public warning(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string/jumbo v0, "r nsn- lqwa:euicrCgoam"

    const-string v0, " gsmlasucrn nC:aeo-riw"

    const/4 v2, 0x0

    const-string/jumbo v0, "nrs-rlawn: siseuaocs C"

    const-string/jumbo v0, "warning - sourceClass:"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string p1, "Moomcds:oeetu, "

    const-string p1, " u:sodch,Mtooee"

    const/4 v2, 0x1

    const-string p1, "Mdoeo,u:rteh os"

    const-string p1, ", sourceMethod:"

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const-string p1, ":msb b"

    const-string p1, "gsm: b"

    const/4 v2, 0x1

    const-string/jumbo p1, "umgs,:"

    const-string p1, ", msg:"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-void
.end method

.method public warning(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    new-instance p4, Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const-string/jumbo p5, "u:Cas eploiucrngssnwa "

    const-string p5, "ec os-uugwni :slCnrasa"

    const/4 v1, 0x3

    const-string p5, " as unenqgl:airorsCswc"

    const-string/jumbo p5, "warning - sourceClass:"

    const/4 v0, 0x5

    move v1, v0

    invoke-virtual {p4, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    const-string p1, " ctoe,spou:Merh"

    const/4 v1, 0x4

    const-string p1, "desohurM:e toc,"

    const-string p1, ", sourceMethod:"

    const/4 v1, 0x4

    const/4 v0, 0x2

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-virtual {p4, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    const-string p1, " msmg,"

    const-string p1, "gsq m,"

    const/4 v1, 0x3

    const-string p1, ", gmo:"

    const-string p1, ", msg:"

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-virtual {p4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p4, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-virtual {p4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/logging/MLogger;->log(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method
