.class public Lcom/tencent/android/tpns/mqtt/logging/SimpleLogFormatter;
.super Ljava/util/logging/Formatter;


# static fields
.field private static final LS:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const-string/jumbo v0, "snsrso.eatelip"

    const-string v0, "aeslrios.nrtpe"

    const/4 v2, 0x6

    const-string v0, "enimater.aoprl"

    const-string/jumbo v0, "line.separator"

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/lang/System;->getProperty(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    sput-object v0, Lcom/tencent/android/tpns/mqtt/logging/SimpleLogFormatter;->LS:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/util/logging/Formatter;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public static left(Ljava/lang/String;IC)Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o b~oo @  @S~@o@~@~n @ uo~4@1t@~dl@~bi t~/@obmoa~~v @l@ ~~~ @~@f~@cM ~ @i.y ~ ~~Kr/@@i~-~@ ~@  f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    if-lt v0, p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {v0, p1}, Ljava/lang/StringBuffer;-><init>(I)V

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    sub-int/2addr p1, p0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    add-int/lit8 p1, p1, -0x1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-ltz p1, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    const/4 v2, 0x6

    const/4 v1, 0x6

    goto :goto_0

    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0
.end method


# virtual methods
.method public format(Ljava/util/logging/LogRecord;)Ljava/lang/String;
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v8, 0x6

    move v9, v8

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p1}, Ljava/util/logging/LogRecord;->getLevel()Ljava/util/logging/Level;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v1}, Ljava/util/logging/Level;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const-string/jumbo v1, "t/"

    const-string v1, "/t"

    const/4 v9, 0x2

    const-string/jumbo v1, "t/"

    const-string v1, "\t"

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v3, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-array v4, v3, [Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    new-instance v5, Ljava/util/Date;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p1}, Ljava/util/logging/LogRecord;->getMillis()J

    move-result-wide v6

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-direct {v5, v6, v7}, Ljava/util/Date;-><init>(J)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/4 v6, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x7

    aput-object v5, v4, v6

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    const-string v5, " }mmytk , {0y kdSM,,-a,m-ei{ Sst0dSM:. S:emsd"

    const/4 v9, 0x1

    const-string v5, "-Se:0b0S.my, iky adS{,S sm dd{k:M-t,t}M} sm ,"

    const-string/jumbo v5, "{0, date, yy-MM-dd} {0, time, kk:mm:ss.SSSS} "

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-static {v5, v4}, Ljava/text/MessageFormat;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {p1}, Ljava/util/logging/LogRecord;->getSourceClassName()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/16 v4, 0x20

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-eqz v2, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    const/16 v7, 0x14

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-le v5, v7, :cond_0

    const/4 v8, 0x1

    move v9, v8

    invoke-virtual {p1}, Ljava/util/logging/LogRecord;->getSourceClassName()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    add-int/lit8 v5, v5, -0x13

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v2, v5}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto :goto_0

    :cond_0
    const/4 v8, 0x1

    move v9, v8

    new-array v5, v3, [C

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    aput-char v4, v5, v6

    const/4 v9, 0x4

    const/4 v8, 0x6

    new-instance v7, Ljava/lang/StringBuffer;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-direct {v7}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v7, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v8, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {v7, v5, v6, v3}, Ljava/lang/StringBuffer;->append([CII)Ljava/lang/StringBuffer;

    const/4 v9, 0x4

    const/4 v8, 0x3

    invoke-virtual {v7}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    goto :goto_0

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    const-string v2, ""

    const-string v2, ""

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    const-string v2, " "

    const-string v2, " "

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p1}, Ljava/util/logging/LogRecord;->getSourceMethodName()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/16 v3, 0x17

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/SimpleLogFormatter;->left(Ljava/lang/String;IC)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {p1}, Ljava/util/logging/LogRecord;->getThreadID()I

    move-result v2

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    const/4 v9, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x0

    const/4 v8, 0x0

    invoke-virtual {p0, p1}, Ljava/util/logging/Formatter;->formatMessage(Ljava/util/logging/LogRecord;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    sget-object v1, Lcom/tencent/android/tpns/mqtt/logging/SimpleLogFormatter;->LS:Ljava/lang/String;

    const/4 v8, 0x4

    move v9, v8

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p1}, Ljava/util/logging/LogRecord;->getThrown()Ljava/lang/Throwable;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-eqz v1, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x3

    const-string v1, "cwruTou:drohae orle "

    const-string v1, "eeorou:hl o arcrTdwb"

    const/4 v9, 0x2

    const-string v1, "b rwrrupeaelhoo cdc:"

    const-string v1, "Throwable occurred: "

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {p1}, Ljava/util/logging/LogRecord;->getThrown()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/4 v1, 0x0

    :try_start_0
    const/4 v9, 0x5

    new-instance v2, Ljava/io/StringWriter;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-direct {v2}, Ljava/io/StringWriter;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance v3, Ljava/io/PrintWriter;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-direct {v3, v2}, Ljava/io/PrintWriter;-><init>(Ljava/io/Writer;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {p1, v3}, Ljava/lang/Throwable;->printStackTrace(Ljava/io/PrintWriter;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v2}, Ljava/io/StringWriter;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v3}, Ljava/io/PrintWriter;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    goto :goto_2

    :catchall_0
    move-exception p1

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    move-object v1, v3

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    goto :goto_1

    :catchall_1
    move-exception p1

    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eqz v1, :cond_2

    :try_start_3
    const/4 v8, 0x7

    move v9, v8

    invoke-virtual {v1}, Ljava/io/PrintWriter;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :catchall_2
    :cond_2
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    throw p1

    :catchall_3
    :cond_3
    :goto_2
    const/4 v9, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    return-object p1
.end method
