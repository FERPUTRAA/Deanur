.class Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/internal/IDisconnectedBufferCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpns/mqtt/internal/ClientComms;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "ReconnectDisconnectedBufferCallback"
.end annotation


# instance fields
.field final methodName:Ljava/lang/String;

.field final synthetic this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;->methodName:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public publishBufferedMessage(Lcom/tencent/android/tpns/mqtt/BufferedMessage;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, " oss~  b~@  .1~i@oftan~~~ -c m@u~@@o@@@  ~~~Sib@ ~l f~~o~~~@ @i@v Mr~ d/@b @oK@ y@4@~l ~@/~@t~~@"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isConnected()Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string v1, "iComlssnmmt"

    const-string v1, "iCsnoteslmm"

    const/4 v7, 0x3

    const-string v1, "CnstomCiloe"

    const-string v1, "ClientComms"

    const/4 v7, 0x7

    if-eqz v0, :cond_1

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v6, 0x7

    move v7, v6

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$600(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getActualInFlight()I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v6, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$600(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getMaxInFlight()I

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v3, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    sub-int/2addr v2, v3

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-lt v0, v2, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {}, Ljava/lang/Thread;->yield()V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    goto :goto_0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;->methodName:Ljava/lang/String;

    const/4 v7, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/BufferedMessage;->getMessage()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v4}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getKey()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v5, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    aput-object v4, v3, v5

    const/4 v7, 0x0

    const/4 v6, 0x4

    const-string v4, "150"

    const-string v4, "105"

    const/4 v7, 0x7

    const-string v4, "501"

    const-string v4, "510"

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-interface {v0, v1, v2, v4, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/BufferedMessage;->getMessage()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/BufferedMessage;->getToken()Lcom/tencent/android/tpns/mqtt/MqttToken;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->internalSend(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$600(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/BufferedMessage;->getMessage()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->unPersistBufferedMessage(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-void

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;->methodName:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string v2, "820"

    const-string v2, "082"

    const/4 v7, 0x7

    const-string v2, "208"

    const-string v2, "208"

    const/4 v7, 0x6

    const/4 v6, 0x0

    invoke-interface {p1, v1, v0, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/16 p1, 0x7d68

    const/4 v7, 0x5

    const/4 v6, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    throw p1
.end method
