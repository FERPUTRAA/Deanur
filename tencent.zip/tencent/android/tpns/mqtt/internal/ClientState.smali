.class public Lcom/tencent/android/tpns/mqtt/internal/ClientState;
.super Ljava/lang/Object;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "ClientState"

.field private static final MAX_MSG_ID:I = 0xffff

.field private static final MIN_MSG_ID:I = 0x1

.field private static final PERSISTENCE_CONFIRMED_PREFIX:Ljava/lang/String; = "sc-"

.field private static final PERSISTENCE_RECEIVED_PREFIX:Ljava/lang/String; = "r-"

.field private static final PERSISTENCE_SENT_BUFFERED_PREFIX:Ljava/lang/String; = "sb-"

.field private static final PERSISTENCE_SENT_PREFIX:Ljava/lang/String; = "s-"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private actualInFlight:I

.field private callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

.field private cleanSession:Z

.field private clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

.field private connected:Z

.field private inFlightPubRels:I

.field private inUseMsgIds:Ljava/util/Hashtable;

.field private inboundQoS2:Ljava/util/Hashtable;

.field private keepAlive:J

.field private lastInboundActivity:J

.field private lastOutboundActivity:J

.field private lastPing:J

.field private maxInflight:I

.field private nextMsgId:I

.field private outboundQoS0:Ljava/util/Hashtable;

.field private outboundQoS1:Ljava/util/Hashtable;

.field private outboundQoS2:Ljava/util/Hashtable;

.field private volatile pendingFlows:Ljava/util/Vector;

.field private volatile pendingMessages:Ljava/util/Vector;

.field private persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

.field private pingCommand:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

.field private pingOutstanding:I

.field private pingOutstandingLock:Ljava/lang/Object;

.field private pingSender:Lcom/tencent/android/tpns/mqtt/MqttPingSender;

.field private queueLock:Ljava/lang/Object;

.field private quiesceLock:Ljava/lang/Object;

.field private quiescing:Z

.field private tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v0, ".esnpta.ttcss.agcoqndclrna.insdr.m..ttlolitnnntee"

    const-string v0, ".tsto.leqsrdtcocdepatn..nclnmitn.isttermln.agn.an"

    const/4 v3, 0x4

    const-string v0, "cmomtpd.a..ot.n.erslriagnlnctdntnen.ltsct.meaoiqn"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v1, "laCtotStnei"

    const-string v1, "ClientState"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method protected constructor <init>(Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/MqttPingSender;)V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v0, 0x0

    const/4 v6, 0x6

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->nextMsgId:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/4 v1, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->maxInflight:I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v6, 0x7

    const/4 v5, 0x4

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inFlightPubRels:I

    const/4 v5, 0x5

    move v6, v5

    new-instance v2, Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiesceLock:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v6, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiescing:Z

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    iput-wide v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastOutboundActivity:J

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    iput-wide v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastInboundActivity:J

    const/4 v6, 0x2

    iput-wide v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastPing:J

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    new-instance v2, Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    iput-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstandingLock:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstanding:I

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->connected:Z

    const/4 v6, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    const/4 v5, 0x0

    move v6, v5

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    const/4 v5, 0x4

    move v6, v5

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS0:Ljava/util/Hashtable;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inboundQoS2:Ljava/util/Hashtable;

    const/4 v6, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingSender:Lcom/tencent/android/tpns/mqtt/MqttPingSender;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p4}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-interface {v2}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v1, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->setResourceName(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string/jumbo v2, "in<mt>"

    const/4 v6, 0x6

    const-string v2, "<>niIb"

    const-string v2, "<Init>"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x2

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v4, "SiteCluatoe"

    const-string v4, "etltoaCtSie"

    const/4 v6, 0x1

    const-string/jumbo v4, "teSlettpaCi"

    const-string v4, "ClientState"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-interface {v1, v4, v2, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->finer(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance v1, Ljava/util/Hashtable;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {v1}, Ljava/util/Hashtable;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inUseMsgIds:Ljava/util/Hashtable;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-instance v1, Ljava/util/Vector;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {v1}, Ljava/util/Vector;-><init>()V

    const/4 v5, 0x5

    move v6, v5

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-instance v1, Ljava/util/Hashtable;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {v1}, Ljava/util/Hashtable;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-instance v1, Ljava/util/Hashtable;

    const/4 v6, 0x3

    const/4 v5, 0x0

    invoke-direct {v1}, Ljava/util/Hashtable;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v1, Ljava/util/Hashtable;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v1}, Ljava/util/Hashtable;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS0:Ljava/util/Hashtable;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    new-instance v1, Ljava/util/Hashtable;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {v1}, Ljava/util/Hashtable;-><init>()V

    const/4 v5, 0x2

    or-int/2addr v6, v5

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inboundQoS2:Ljava/util/Hashtable;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    new-instance v1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPingReq;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {v1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPingReq;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingCommand:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inFlightPubRels:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v6, 0x4

    const/4 v5, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v6, 0x2

    iput-object p3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v6, 0x7

    const/4 v5, 0x1

    iput-object p4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    iput-object p5, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingSender:Lcom/tencent/android/tpns/mqtt/MqttPingSender;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->restoreState()V

    const/4 v6, 0x1

    return-void
.end method

.method private decrementInFlight()V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~~c@4-~ qoo~~@@~ y ~b@o.~ad v @@@@~@is1@@i f ~~~~~nob/b S~@t~  ~l  r@fM@   ~K~~@omo l@@@ ~@/u~@t"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v9, 0x5

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    const/4 v2, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    sub-int/2addr v1, v2

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    iput v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    sget-object v3, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string v4, "ebsenitltSC"

    const-string v4, "CnetibteSlt"

    const/4 v9, 0x3

    const-string v4, "aeSmnlteCit"

    const-string v4, "ClientState"

    const/4 v9, 0x7

    const-string v5, "iFhnoIglruecmtete"

    const-string/jumbo v5, "tenlFeutnhieIrcmg"

    const/4 v9, 0x3

    const-string v5, "iIlerbFenhgtcnemt"

    const-string v5, "decrementInFlight"

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    const-string v6, "664"

    const-string v6, "466"

    const/4 v9, 0x0

    const-string v6, "646"

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    new-instance v7, Ljava/lang/Integer;

    const/4 v9, 0x7

    const/4 v8, 0x3

    invoke-direct {v7, v1}, Ljava/lang/Integer;-><init>(I)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/4 v1, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x4

    aput-object v7, v2, v1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-interface {v3, v4, v5, v6, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->checkQuiesceLock()Z

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x7

    if-nez v1, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    monitor-exit v0

    const/4 v9, 0x2

    const/4 v8, 0x1

    return-void

    :catchall_0
    move-exception v1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    throw v1
.end method

.method private declared-synchronized getNextMessageId()I
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->nextMsgId:I

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/4 v1, 0x0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->nextMsgId:I

    const/4 v6, 0x0

    const/4 v3, 0x7

    const/4 v6, 0x4

    const/4 v3, 0x1

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    add-int/2addr v2, v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->nextMsgId:I

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    const v4, 0xffff

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    if-le v2, v4, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    iput v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->nextMsgId:I

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->nextMsgId:I

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-ne v2, v0, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    const/4 v3, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eq v1, v3, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    goto :goto_0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/16 v0, 0x7d01

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    throw v0

    :cond_3
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inUseMsgIds:Ljava/util/Hashtable;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    new-instance v4, Ljava/lang/Integer;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-direct {v4, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v6, 0x2

    invoke-virtual {v3, v4}, Ljava/util/Hashtable;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-nez v2, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    new-instance v0, Ljava/lang/Integer;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->nextMsgId:I

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {v0, v1}, Ljava/lang/Integer;-><init>(I)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inUseMsgIds:Ljava/util/Hashtable;

    const/4 v6, 0x6

    invoke-virtual {v1, v0, v0}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->nextMsgId:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    monitor-exit p0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    return v0

    :catchall_0
    move-exception v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    monitor-exit p0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    throw v0
.end method

.method private getReceivedPersistenceKey(I)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string v1, "-r"

    const-string/jumbo v1, "r-"

    const/4 v3, 0x1

    const-string v1, "-r"

    const-string/jumbo v1, "r-"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p1
.end method

.method private getReceivedPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo v1, "r-"

    const-string v1, "-r"

    const/4 v3, 0x1

    const-string/jumbo v1, "r-"

    const-string/jumbo v1, "r-"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p1
.end method

.method private getSendBufferedPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string v1, "b-s"

    const-string v1, "bs-"

    const/4 v3, 0x4

    const-string/jumbo v1, "sb-"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object p1
.end method

.method private getSendConfirmPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v1, "c-s"

    const-string v1, "c-s"

    const/4 v3, 0x4

    const-string v1, "cs-"

    const-string/jumbo v1, "sc-"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p1
.end method

.method private getSendPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v1, "-s"

    const-string v1, "-s"

    const/4 v3, 0x7

    const-string v1, "-s"

    const-string/jumbo v1, "s-"

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-object p1
.end method

.method private insertInOrder(Ljava/util/Vector;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/util/Vector;->size()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    if-ge v1, v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    check-cast v2, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-le v2, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1, p2, v1}, Ljava/util/Vector;->insertElementAt(Ljava/lang/Object;I)V

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p1, p2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    return-void
.end method

.method private reOrder(Ljava/util/Vector;)Ljava/util/Vector;
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    new-instance v0, Ljava/util/Vector;

    const/4 v7, 0x5

    shr-int/2addr v8, v7

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p1}, Ljava/util/Vector;->size()I

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x5

    if-nez v1, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    return-object v0

    :cond_0
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/4 v1, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    move v2, v1

    move v2, v1

    const/4 v8, 0x3

    move v2, v1

    move v2, v1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x5

    move v3, v2

    move v3, v2

    const/4 v8, 0x3

    move v3, v2

    move v3, v2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x4

    move v4, v3

    move v4, v3

    const/4 v8, 0x7

    move v4, v3

    move v4, v3

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    move v5, v4

    move v5, v4

    const/4 v8, 0x5

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {p1}, Ljava/util/Vector;->size()I

    move-result v6

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-ge v2, v6, :cond_2

    const/4 v7, 0x4

    move v8, v7

    invoke-virtual {p1, v2}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v6

    const/4 v8, 0x1

    const/4 v7, 0x2

    check-cast v6, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v6}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v6

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    sub-int v3, v6, v3

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-le v3, v4, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    move v5, v2

    const/4 v8, 0x0

    move v5, v2

    move v5, v2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    move v4, v3

    move v4, v3

    const/4 v8, 0x4

    move v4, v3

    move v4, v3

    :cond_1
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    move v3, v6

    move v3, v6

    const/4 v8, 0x6

    move v3, v6

    move v3, v6

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    goto :goto_0

    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x7

    invoke-virtual {p1, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    check-cast v2, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v2

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    const v6, 0xffff

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    sub-int/2addr v6, v3

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    add-int/2addr v6, v2

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-le v6, v4, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    move v5, v1

    move v5, v1

    move v5, v1

    move v5, v1

    :cond_3
    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    move v2, v5

    move v2, v5

    move v2, v5

    move v2, v5

    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {p1}, Ljava/util/Vector;->size()I

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-ge v2, v3, :cond_4

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p1, v2}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v0, v3}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    goto :goto_1

    :cond_4
    :goto_2
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-ge v1, v5, :cond_5

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p1, v1}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v0, v2}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    goto :goto_2

    :cond_5
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    return-object v0
.end method

.method private declared-synchronized releaseMessageId(I)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inUseMsgIds:Ljava/util/Hashtable;

    const/4 v3, 0x6

    const/4 v2, 0x6

    new-instance v1, Ljava/lang/Integer;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v1, p1}, Ljava/lang/Integer;-><init>(I)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/util/Hashtable;->remove(Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    monitor-exit p0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    monitor-exit p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    throw p1
.end method

.method private restoreInflightMessages()V
    .locals 11

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    new-instance v0, Ljava/util/Vector;

    const/4 v10, 0x1

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->maxInflight:I

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-direct {v0, v1}, Ljava/util/Vector;-><init>(I)V

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    new-instance v0, Ljava/util/Vector;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-direct {v0}, Ljava/util/Vector;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v0}, Ljava/util/Hashtable;->keys()Ljava/util/Enumeration;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/4 v2, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-string v3, "efeehglpMistIonrtesssar"

    const/4 v10, 0x0

    const-string v3, "egthssuMieoeIesftsgrarl"

    const-string/jumbo v3, "restoreInflightMessages"

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    const-string/jumbo v4, "niStqltpeCe"

    const-string/jumbo v4, "tSetlentqiC"

    const/4 v10, 0x0

    const-string/jumbo v4, "tnttieSCqae"

    const-string v4, "ClientState"

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    const/4 v5, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-eqz v1, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x4

    iget-object v6, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v6, v1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    check-cast v6, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    instance-of v7, v6, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-eqz v7, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    sget-object v7, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v10, 0x1

    new-array v8, v5, [Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    aput-object v1, v8, v2

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    const-string v1, "106"

    const-string v1, "160"

    const/4 v10, 0x3

    const-string v1, "160"

    const-string v1, "610"

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-interface {v7, v4, v3, v1, v8}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v10, 0x6

    invoke-virtual {v6, v5}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->setDuplicate(Z)V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v9, 0x0

    const/4 v10, 0x3

    check-cast v6, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-direct {p0, v1, v6}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->insertInOrder(Ljava/util/Vector;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    const/4 v10, 0x5

    const/4 v9, 0x5

    goto/16 :goto_0

    :cond_1
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    instance-of v7, v6, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-eqz v7, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    sget-object v7, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    aput-object v1, v5, v2

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    const-string v1, "116"

    const-string v1, "611"

    const-string v1, "116"

    const-string v1, "611"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-interface {v7, v4, v3, v1, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    check-cast v6, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-direct {p0, v1, v6}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->insertInOrder(Ljava/util/Vector;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    goto/16 :goto_0

    :cond_2
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {v0}, Ljava/util/Hashtable;->keys()Ljava/util/Enumeration;

    move-result-object v0

    :goto_1
    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz v1, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v6, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {v6, v1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    check-cast v6, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {v6, v5}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->setDuplicate(Z)V

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    sget-object v7, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x7

    move v10, v9

    new-array v8, v5, [Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    aput-object v1, v8, v2

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    const-string v1, "126"

    const-string v1, "612"

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-interface {v7, v4, v3, v1, v8}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v9, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-direct {p0, v1, v6}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->insertInOrder(Ljava/util/Vector;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    goto :goto_1

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS0:Ljava/util/Hashtable;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {v0}, Ljava/util/Hashtable;->keys()Ljava/util/Enumeration;

    move-result-object v0

    :goto_2
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-eqz v1, :cond_4

    const/4 v10, 0x4

    const/4 v9, 0x6

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v6, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS0:Ljava/util/Hashtable;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v6, v1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    check-cast v6, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    sget-object v7, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    new-array v8, v5, [Ljava/lang/Object;

    const/4 v10, 0x0

    aput-object v1, v8, v2

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-string v1, "125"

    const-string v1, "125"

    const/4 v10, 0x6

    const-string v1, "512"

    const-string v1, "512"

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-interface {v7, v4, v3, v1, v8}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v10, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    invoke-direct {p0, v1, v6}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->insertInOrder(Ljava/util/Vector;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    const/4 v9, 0x7

    move v10, v9

    goto :goto_2

    :cond_4
    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->reOrder(Ljava/util/Vector;)Ljava/util/Vector;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v9, 0x3

    shl-int/2addr v10, v9

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->reOrder(Ljava/util/Vector;)Ljava/util/Vector;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v10, 0x0

    return-void
.end method

.method private restoreMessage(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttPersistable;)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string/jumbo v0, "ssseaesoergter"

    const-string v0, "arssMereseoteg"

    const/4 v6, 0x2

    const-string/jumbo v0, "ogtmeaersMseer"

    const-string/jumbo v0, "restoreMessage"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string/jumbo v1, "nltmateiSCe"

    const-string/jumbo v1, "nletoatiSte"

    const-string v1, "ClientState"

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {p2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->createWireMessage(Lcom/tencent/android/tpns/mqtt/MqttPersistable;)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto :goto_0

    :catchall_0
    move-exception p2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v1, v0, p2}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p2}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    instance-of v2, v2, Ljava/io/EOFException;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eqz v2, :cond_1

    const/4 v5, 0x5

    or-int/2addr v6, v5

    if-eqz p1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-interface {p2, p1}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 p2, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v3, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    aput-object p1, v3, v4

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 p1, 0x1

    const/4 v5, 0x5

    move v6, v5

    aput-object p2, v3, p1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string p1, "601"

    const-string p1, "601"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-interface {v2, v1, v0, p1, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x0

    return-object p2

    :cond_1
    const/4 v6, 0x7

    throw p2
.end method


# virtual methods
.method public checkForActivity(Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)Lcom/tencent/android/tpns/mqtt/MqttToken;
    .locals 15
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const-string v3, "eetatbCitnS"

    const-string v3, "ClientState"

    const-string/jumbo v4, "ioreokuAcvycFthi"

    const-string/jumbo v4, "ihkcoctrAcFiveoy"

    const-string v4, "checkForActivity"

    const-string v5, "616"

    const-string v5, "616"

    const-string v5, "661"

    const-string v5, "616"

    const/4 v6, 0x0

    new-array v7, v6, [Ljava/lang/Object;

    invoke-interface {v2, v3, v4, v5, v7}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v3, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiesceLock:Ljava/lang/Object;

    monitor-enter v3

    :try_start_0
    iget-boolean v4, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiescing:Z

    const/4 v5, 0x0

    if-eqz v4, :cond_0

    monitor-exit v3

    return-object v5

    :cond_0
    monitor-exit v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getKeepAlive()J

    iget-boolean v3, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->connected:Z

    if-eqz v3, :cond_a

    iget-wide v3, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->keepAlive:J

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    cmp-long v3, v3, v7

    if-lez v3, :cond_a

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    iget-object v7, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstandingLock:Ljava/lang/Object;

    monitor-enter v7

    :try_start_1
    iget v8, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstanding:I

    const/4 v13, 0x1

    const/16 v14, 0x64

    if-lez v8, :cond_2

    iget-wide v11, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastInboundActivity:J

    sub-long v11, v3, v11

    iget-wide v5, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->keepAlive:J

    int-to-long v9, v14

    add-long/2addr v9, v5

    cmp-long v9, v11, v9

    if-gez v9, :cond_1

    goto :goto_0

    :cond_1
    const-string v0, "SblteCeptai"

    const-string/jumbo v0, "itnSebelCta"

    const-string/jumbo v0, "nliteteaqCt"

    const-string v0, "ClientState"

    const-string/jumbo v8, "tcsuFAhytkciievr"

    const-string v8, "cetyicuhFiArotvk"

    const-string v8, "AthmcFctivciroek"

    const-string v8, "checkForActivity"

    const-string v9, "169"

    const-string v9, "169"

    const-string v9, "169"

    const-string v9, "619"

    const/4 v10, 0x5

    new-array v10, v10, [Ljava/lang/Object;

    new-instance v11, Ljava/lang/Long;

    invoke-direct {v11, v5, v6}, Ljava/lang/Long;-><init>(J)V

    const/4 v5, 0x0

    aput-object v11, v10, v5

    new-instance v5, Ljava/lang/Long;

    iget-wide v11, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastOutboundActivity:J

    invoke-direct {v5, v11, v12}, Ljava/lang/Long;-><init>(J)V

    aput-object v5, v10, v13

    new-instance v5, Ljava/lang/Long;

    iget-wide v11, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastInboundActivity:J

    invoke-direct {v5, v11, v12}, Ljava/lang/Long;-><init>(J)V

    const/4 v6, 0x2

    aput-object v5, v10, v6

    new-instance v5, Ljava/lang/Long;

    invoke-direct {v5, v3, v4}, Ljava/lang/Long;-><init>(J)V

    const/4 v3, 0x3

    aput-object v5, v10, v3

    new-instance v3, Ljava/lang/Long;

    iget-wide v4, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastPing:J

    invoke-direct {v3, v4, v5}, Ljava/lang/Long;-><init>(J)V

    const/4 v4, 0x4

    aput-object v3, v10, v4

    invoke-interface {v2, v0, v8, v9, v10}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->severe(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/16 v0, 0x7d00

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v0

    throw v0

    :cond_2
    :goto_0
    if-nez v8, :cond_4

    iget-wide v5, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastOutboundActivity:J

    sub-long v5, v3, v5

    iget-wide v9, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->keepAlive:J

    const-wide/16 v11, 0x2

    const-wide/16 v11, 0x2

    const-wide/16 v11, 0x2

    const-wide/16 v11, 0x2

    mul-long/2addr v11, v9

    cmp-long v5, v5, v11

    if-gez v5, :cond_3

    goto :goto_1

    :cond_3
    const-string v0, "elCeoaitptn"

    const-string v0, "eCetitnpSla"

    const-string v0, "ClientState"

    const-string v5, "ctiytbovkFercAhc"

    const-string/jumbo v5, "tAeohFycqtkvricc"

    const-string v5, "cyriAhuectiokFtv"

    const-string v5, "checkForActivity"

    const-string v6, "264"

    const-string v6, "642"

    const/4 v8, 0x5

    new-array v8, v8, [Ljava/lang/Object;

    new-instance v11, Ljava/lang/Long;

    invoke-direct {v11, v9, v10}, Ljava/lang/Long;-><init>(J)V

    const/4 v9, 0x0

    aput-object v11, v8, v9

    new-instance v9, Ljava/lang/Long;

    iget-wide v10, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastOutboundActivity:J

    invoke-direct {v9, v10, v11}, Ljava/lang/Long;-><init>(J)V

    aput-object v9, v8, v13

    new-instance v9, Ljava/lang/Long;

    iget-wide v10, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastInboundActivity:J

    invoke-direct {v9, v10, v11}, Ljava/lang/Long;-><init>(J)V

    const/4 v10, 0x2

    aput-object v9, v8, v10

    new-instance v9, Ljava/lang/Long;

    invoke-direct {v9, v3, v4}, Ljava/lang/Long;-><init>(J)V

    const/4 v3, 0x3

    aput-object v9, v8, v3

    new-instance v3, Ljava/lang/Long;

    iget-wide v9, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastPing:J

    invoke-direct {v3, v9, v10}, Ljava/lang/Long;-><init>(J)V

    const/4 v4, 0x4

    aput-object v3, v8, v4

    invoke-interface {v2, v0, v5, v6, v8}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->severe(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/16 v0, 0x7d02

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v0

    throw v0

    :cond_4
    :goto_1
    if-nez v8, :cond_5

    iget-wide v5, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastInboundActivity:J

    sub-long v5, v3, v5

    iget-wide v8, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->keepAlive:J

    int-to-long v10, v14

    sub-long/2addr v8, v10

    cmp-long v5, v5, v8

    if-gez v5, :cond_6

    :cond_5
    iget-wide v5, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastOutboundActivity:J

    sub-long v5, v3, v5

    iget-wide v8, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->keepAlive:J

    int-to-long v10, v14

    sub-long/2addr v8, v10

    cmp-long v5, v5, v8

    if-ltz v5, :cond_8

    :cond_6
    const-string v3, "elStenapsti"

    const-string v3, "etsanettSli"

    const-string/jumbo v3, "itSeCntaqte"

    const-string v3, "ClientState"

    const-string/jumbo v4, "kvsthFceimotrAic"

    const-string/jumbo v4, "vkemcAcithFrtoci"

    const-string/jumbo v4, "vkrmitcAchityoce"

    const-string v4, "checkForActivity"

    const-string v5, "026"

    const-string v5, "026"

    const-string v5, "206"

    const-string v5, "620"

    const/4 v6, 0x3

    new-array v6, v6, [Ljava/lang/Object;

    new-instance v8, Ljava/lang/Long;

    iget-wide v9, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->keepAlive:J

    invoke-direct {v8, v9, v10}, Ljava/lang/Long;-><init>(J)V

    const/4 v9, 0x0

    aput-object v8, v6, v9

    new-instance v8, Ljava/lang/Long;

    iget-wide v9, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastOutboundActivity:J

    invoke-direct {v8, v9, v10}, Ljava/lang/Long;-><init>(J)V

    aput-object v8, v6, v13

    new-instance v8, Ljava/lang/Long;

    iget-wide v9, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastInboundActivity:J

    invoke-direct {v8, v9, v10}, Ljava/lang/Long;-><init>(J)V

    const/4 v9, 0x2

    aput-object v8, v6, v9

    invoke-interface {v2, v3, v4, v5, v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    new-instance v3, Lcom/tencent/android/tpns/mqtt/MqttToken;

    iget-object v4, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    invoke-virtual {v4}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v4

    invoke-interface {v4}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v4

    invoke-direct {v3, v4}, Lcom/tencent/android/tpns/mqtt/MqttToken;-><init>(Ljava/lang/String;)V

    if-eqz v0, :cond_7

    invoke-virtual {v3, v0}, Lcom/tencent/android/tpns/mqtt/MqttToken;->setActionCallback(Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)V

    :cond_7
    iget-object v0, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    iget-object v4, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingCommand:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    invoke-virtual {v0, v3, v4}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->saveToken(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    iget-object v0, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    iget-object v4, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingCommand:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v5, 0x0

    invoke-virtual {v0, v4, v5}, Ljava/util/Vector;->insertElementAt(Ljava/lang/Object;I)V

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getKeepAlive()J

    move-result-wide v4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifyQueueLock()V

    goto :goto_2

    :cond_8
    const-string v0, "etCioanlote"

    const-string v0, "atliontCtee"

    const-string v0, "antttbeCSle"

    const-string v0, "ClientState"

    const-string/jumbo v5, "itrhyiuFcvcekctA"

    const-string/jumbo v5, "rFccebyAicvtihkt"

    const-string v5, "ccrAhiopevFckyit"

    const-string v5, "checkForActivity"

    const-string v6, "436"

    const-string v6, "364"

    const-string v6, "364"

    const-string v6, "634"

    const/4 v8, 0x0

    invoke-interface {v2, v0, v5, v6, v8}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getKeepAlive()J

    move-result-wide v5

    iget-wide v9, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastOutboundActivity:J

    sub-long/2addr v3, v9

    sub-long/2addr v5, v3

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    invoke-static {v3, v4, v5, v6}, Ljava/lang/Math;->max(JJ)J

    move-result-wide v4

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    :goto_2
    monitor-exit v7
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const-string v0, "aieteutCqlt"

    const-string v0, "altCtiueent"

    const-string/jumbo v0, "tlsteeCntSi"

    const-string v0, "ClientState"

    const-string v6, "cAvmoihctcrpitkF"

    const-string v6, "FkvohtipArccietc"

    const-string v6, "AtFyotcekhccrvio"

    const-string v6, "checkForActivity"

    const-string v7, "624"

    const-string v7, "246"

    const-string v7, "624"

    const-string v7, "624"

    new-array v8, v13, [Ljava/lang/Object;

    new-instance v9, Ljava/lang/Long;

    invoke-direct {v9, v4, v5}, Ljava/lang/Long;-><init>(J)V

    const/4 v10, 0x0

    aput-object v9, v8, v10

    invoke-interface {v2, v0, v6, v7, v8}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v0, v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingSender:Lcom/tencent/android/tpns/mqtt/MqttPingSender;

    if-eqz v0, :cond_9

    invoke-interface {v0, v4, v5}, Lcom/tencent/android/tpns/mqtt/MqttPingSender;->schedule(J)V

    :cond_9
    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    goto :goto_3

    :catchall_0
    move-exception v0

    :try_start_2
    monitor-exit v7
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    throw v0

    :cond_a
    move-object v8, v5

    move-object v8, v5

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    :goto_3
    return-object v5

    :catchall_1
    move-exception v0

    :try_start_3
    monitor-exit v3
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    throw v0
.end method

.method protected checkQuiesceLock()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->count()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiescing:Z

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->isQuiesced()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiesceLock:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiesceLock:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    return v0

    :catchall_0
    move-exception v1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    throw v1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    return v0
.end method

.method protected clearState()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v4, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v1, "Slaeebqttr"

    const-string/jumbo v1, "rtSltaeeqa"

    const/4 v5, 0x2

    const-string v1, "acrletuSet"

    const-string v1, "clearState"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v2, ">"

    const-string v2, ">"

    const/4 v5, 0x5

    const-string v2, ">"

    const-string v2, ">"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string v3, "eiltateptCs"

    const-string v3, "ansettiCetl"

    const/4 v5, 0x7

    const-string/jumbo v3, "ttleSeatqiC"

    const-string v3, "ClientState"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-interface {v0, v3, v1, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->clear()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inUseMsgIds:Ljava/util/Hashtable;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/util/Vector;->clear()V

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/util/Vector;->clear()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    const/4 v5, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS0:Ljava/util/Hashtable;

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inboundQoS2:Ljava/util/Hashtable;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->clear()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-void
.end method

.method protected close()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inUseMsgIds:Ljava/util/Hashtable;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/Vector;->clear()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/Vector;->clear()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS0:Ljava/util/Hashtable;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v1, 0x7

    or-int/2addr v2, v1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inboundQoS2:Ljava/util/Hashtable;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->clear()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inUseMsgIds:Ljava/util/Hashtable;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS0:Ljava/util/Hashtable;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inboundQoS2:Ljava/util/Hashtable;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingCommand:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public connected()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v5, 0x0

    const-string v1, "ensecdcmt"

    const-string v1, "cdnmetceo"

    const-string v1, "ecnmteodc"

    const-string v1, "connected"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v2, "613"

    const-string v2, "631"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const-string/jumbo v3, "tlteooeCSit"

    const-string/jumbo v3, "tteeotilaSC"

    const-string/jumbo v3, "titCabStene"

    const-string v3, "ClientState"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {v0, v3, v1, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x0

    move v5, v4

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->connected:Z

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingSender:Lcom/tencent/android/tpns/mqtt/MqttPingSender;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/MqttPingSender;->start()V

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-void
.end method

.method protected deliveryComplete(I)V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v1, 0x1

    const/4 v6, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    new-instance v2, Ljava/lang/Integer;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {v2, p1}, Ljava/lang/Integer;-><init>(I)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v3, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    aput-object v2, v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string v2, "SnbtCluetei"

    const-string/jumbo v2, "ntlCtbeietS"

    const-string v2, "ClientState"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v3, "reellempvouidtep"

    const-string/jumbo v3, "oeyelmuvptieedrl"

    const/4 v6, 0x7

    const-string/jumbo v3, "lretyeplqievoeCd"

    const-string v3, "deliveryComplete"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string v4, "416"

    const-string v4, "146"

    const/4 v6, 0x6

    const-string v4, "164"

    const-string v4, "641"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v0, v2, v3, v4, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getReceivedPersistenceKey(I)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-interface {v0, v1}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inboundQoS2:Ljava/util/Hashtable;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-instance v1, Ljava/lang/Integer;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-direct {v1, p1}, Ljava/lang/Integer;-><init>(I)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/util/Hashtable;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-void
.end method

.method protected deliveryComplete(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    const/4 v1, 0x1

    const/4 v6, 0x5

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-instance v2, Ljava/lang/Integer;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {v2, v3}, Ljava/lang/Integer;-><init>(I)V

    const/4 v3, 0x5

    shl-int/2addr v6, v3

    const/4 v3, 0x0

    move v6, v3

    const/4 v5, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    aput-object v2, v1, v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string v2, "elspnStitCa"

    const-string/jumbo v2, "nalitSepCet"

    const/4 v6, 0x3

    const-string v2, "eCemSlttnti"

    const-string v2, "ClientState"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string/jumbo v3, "lqvCoyreipeoemde"

    const-string/jumbo v3, "oeCmtelvqpyeedir"

    const/4 v6, 0x5

    const-string v3, "edeymbplCvloetir"

    const-string v3, "deliveryComplete"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const-string v4, "164"

    const-string v4, "164"

    const/4 v6, 0x3

    const-string v4, "416"

    const-string v4, "641"

    const/4 v5, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-interface {v0, v2, v3, v4, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getReceivedPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-interface {v0, v1}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inboundQoS2:Ljava/util/Hashtable;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-instance v1, Ljava/lang/Integer;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    invoke-direct {v1, p1}, Ljava/lang/Integer;-><init>(I)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Ljava/util/Hashtable;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-void
.end method

.method public disconnected(Lcom/tencent/android/tpns/mqtt/MqttException;)V
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string/jumbo v1, "tsielCueSna"

    const-string v1, "SCselateint"

    const/4 v7, 0x7

    const-string v1, "CttlStnpeia"

    const-string v1, "ClientState"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string/jumbo v2, "idceocsmqndt"

    const-string v2, "dcnmsiceedot"

    const/4 v7, 0x6

    const-string/jumbo v2, "onstdncceisd"

    const-string v2, "disconnected"

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-string v3, "633"

    const-string v3, "336"

    const/4 v7, 0x5

    const-string v3, "633"

    const-string v3, "633"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v4, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v5, 0x0

    const/4 v7, 0x0

    move v6, v5

    move v6, v5

    const/4 v7, 0x3

    aput-object p1, v4, v5

    const/4 v7, 0x0

    invoke-interface {v0, v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    iput-boolean v5, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->connected:Z

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->cleanSession:Z

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-eqz p1, :cond_0

    const/4 v7, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->clearState()V

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p1}, Ljava/util/Vector;->clear()V

    const/4 v6, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p1}, Ljava/util/Vector;->clear()V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstandingLock:Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    monitor-enter p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x6

    iput v5, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstanding:I

    const/4 v6, 0x4

    move v7, v6

    monitor-exit p1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v6, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    throw v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catchall_1
    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    return-void
.end method

.method protected get()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x3

    monitor-enter v0

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x3

    const/4 v1, 0x0

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :cond_0
    :goto_0
    const/4 v12, 0x6

    const/4 v11, 0x0

    if-nez v2, :cond_9

    :try_start_0
    const/4 v12, 0x5

    const/4 v11, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v11, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-virtual {v3}, Ljava/util/Vector;->isEmpty()Z

    move-result v3

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x5

    if-eqz v3, :cond_1

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x2

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-virtual {v3}, Ljava/util/Vector;->isEmpty()Z

    move-result v3

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x6

    if-nez v3, :cond_2

    :cond_1
    const/4 v11, 0x2

    move v12, v11

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-virtual {v3}, Ljava/util/Vector;->isEmpty()Z

    move-result v3

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x3

    if-eqz v3, :cond_3

    const/4 v12, 0x3

    const/4 v11, 0x7

    iget v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    iget v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->maxInflight:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x5

    if-lt v3, v4, :cond_3

    :cond_2
    :try_start_1
    const/4 v12, 0x7

    sget-object v3, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x7

    const-string/jumbo v4, "lenmCeatito"

    const-string/jumbo v4, "ltanoeCeitS"

    const/4 v12, 0x3

    const-string/jumbo v4, "teiaoeltnCS"

    const-string v4, "ClientState"

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x1

    const-string v5, "etg"

    const-string v5, "get"

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x1

    const-string v6, "464"

    const-string v6, "644"

    const/4 v12, 0x4

    const-string v6, "644"

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-interface {v3, v4, v5, v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x2

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-virtual {v4}, Ljava/lang/Object;->wait()V

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x5

    const-string v4, "enCebbSatti"

    const-string/jumbo v4, "tSteabtneCi"

    const/4 v12, 0x4

    const-string v4, "CltattunSee"

    const-string v4, "ClientState"

    const/4 v11, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x6

    const-string v5, "egt"

    const-string/jumbo v5, "tge"

    const/4 v12, 0x5

    const-string v5, "get"

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x7

    const-string v6, "746"

    const-string v6, "746"

    const/4 v12, 0x2

    const-string v6, "764"

    const-string v6, "647"

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-interface {v3, v4, v5, v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_0
    :cond_3
    :try_start_2
    const/4 v12, 0x4

    const/4 v11, 0x7

    iget-boolean v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->connected:Z

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    const/4 v4, 0x0

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-nez v3, :cond_5

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v11, 0x0

    shr-int/2addr v12, v11

    invoke-virtual {v3}, Ljava/util/Vector;->isEmpty()Z

    move-result v3

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    if-nez v3, :cond_4

    const/4 v11, 0x7

    move v12, v11

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-virtual {v3, v4}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    check-cast v3, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x4

    instance-of v3, v3, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;

    const/4 v12, 0x4

    if-nez v3, :cond_5

    :cond_4
    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x7

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    const-string/jumbo v3, "nuiClteptSa"

    const-string/jumbo v3, "tneStluCaei"

    const-string v3, "ialtntetqeS"

    const-string v3, "ClientState"

    const/4 v12, 0x0

    const-string v4, "get"

    const-string v4, "gte"

    const/4 v12, 0x1

    const-string v4, "etg"

    const-string v4, "get"

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x0

    const-string v5, "261"

    const-string v5, "621"

    const/4 v11, 0x1

    shr-int/2addr v12, v11

    invoke-interface {v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x5

    monitor-exit v0

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x2

    return-object v1

    :cond_5
    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-virtual {v3}, Ljava/util/Vector;->isEmpty()Z

    move-result v3

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/4 v5, 0x1

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x3

    if-nez v3, :cond_7

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-virtual {v2, v4}, Ljava/util/Vector;->remove(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x0

    check-cast v2, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x2

    instance-of v3, v2, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x3

    if-eqz v3, :cond_6

    const/4 v12, 0x0

    iget v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inFlightPubRels:I

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x5

    add-int/2addr v3, v5

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    iput v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inFlightPubRels:I

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x3

    sget-object v6, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v11, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string v7, "etsSatletCi"

    const-string/jumbo v7, "liteStCptae"

    const/4 v12, 0x2

    const-string v7, "eatmttiCneS"

    const-string v7, "ClientState"

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    const-string v8, "get"

    const-string/jumbo v8, "tge"

    const/4 v12, 0x4

    const-string v8, "gte"

    const-string v8, "get"

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x5

    const-string v9, "671"

    const-string v9, "176"

    const-string v9, "671"

    const-string v9, "617"

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x4

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    new-instance v10, Ljava/lang/Integer;

    const/4 v11, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-direct {v10, v3}, Ljava/lang/Integer;-><init>(I)V

    const/4 v11, 0x1

    move v12, v11

    aput-object v10, v5, v4

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-interface {v6, v7, v8, v9, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_6
    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->checkQuiesceLock()Z

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x5

    goto/16 :goto_0

    :cond_7
    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-virtual {v3}, Ljava/util/Vector;->isEmpty()Z

    move-result v3

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x0

    if-nez v3, :cond_0

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x0

    iget v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v12, 0x1

    iget v6, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->maxInflight:I

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x0

    if-ge v3, v6, :cond_8

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {v2, v4}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x1

    check-cast v2, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-virtual {v3, v4}, Ljava/util/Vector;->removeElementAt(I)V

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x4

    iget v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x2

    add-int/2addr v3, v5

    const/4 v12, 0x7

    const/4 v11, 0x3

    iput v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v11, 0x5

    const/4 v11, 0x0

    sget-object v6, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    const-string/jumbo v7, "taetoqStCin"

    const-string v7, "StCaittnqee"

    const/4 v12, 0x1

    const-string/jumbo v7, "teantblCeti"

    const-string v7, "ClientState"

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    const-string v8, "egt"

    const/4 v12, 0x7

    const-string v8, "get"

    const-string v8, "get"

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x5

    const-string v9, "326"

    const-string v9, "632"

    const-string v9, "263"

    const-string v9, "623"

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x5

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x2

    new-instance v10, Ljava/lang/Integer;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-direct {v10, v3}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x3

    aput-object v10, v5, v4

    const/4 v12, 0x1

    invoke-interface {v6, v7, v8, v9, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x4

    goto/16 :goto_0

    :cond_8
    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    sget-object v3, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x0

    const-string/jumbo v4, "naeesCultti"

    const-string v4, "elsStatineC"

    const/4 v12, 0x2

    const-string/jumbo v4, "neietltpCSa"

    const-string v4, "ClientState"

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x5

    const-string/jumbo v5, "teg"

    const-string/jumbo v5, "tge"

    const/4 v12, 0x3

    const-string v5, "egt"

    const-string v5, "get"

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    const-string v6, "226"

    const-string v6, "622"

    const/4 v12, 0x3

    const-string v6, "226"

    const-string v6, "622"

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-interface {v3, v4, v5, v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x1

    goto/16 :goto_0

    :cond_9
    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x6

    monitor-exit v0

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x5

    return-object v2

    :catchall_0
    move-exception v1

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v12, 0x1

    const/4 v11, 0x5

    throw v1
.end method

.method public getActualInFlight()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method protected getCleanSession()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->cleanSession:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public getDebug()Ljava/util/Properties;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    new-instance v0, Ljava/util/Properties;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/util/Properties;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v1, "n umsgsImdesi"

    const/4 v5, 0x2

    const-string/jumbo v1, "igumdssnqIs e"

    const-string v1, "In use msgids"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inUseMsgIds:Ljava/util/Hashtable;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v1, "nMsnspgadsgesoi"

    const-string v1, "Msesosnnpdggeai"

    const/4 v5, 0x4

    const-string v1, "engmsMgnasspdee"

    const-string/jumbo v1, "pendingMessages"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v1, "dbonoiFsnwle"

    const-string/jumbo v1, "oisFpbnwneld"

    const/4 v5, 0x7

    const-string v1, "dosnwbgnlpFi"

    const-string/jumbo v1, "pendingFlows"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/Integer;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->maxInflight:I

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {v1, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v2, "hxamgiunftI"

    const-string v2, "Ihixtnugfma"

    const-string v2, "amghixfptnI"

    const-string/jumbo v2, "maxInflight"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    new-instance v1, Ljava/lang/Integer;

    const/4 v5, 0x2

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->nextMsgId:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v2, "IxsnptDeq"

    const-string/jumbo v2, "tDnIxgeps"

    const/4 v5, 0x0

    const-string/jumbo v2, "tMsInesxg"

    const-string/jumbo v2, "nextMsgID"

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-instance v1, Ljava/lang/Integer;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v5, 0x7

    const-string v2, "iIcmngqalttauh"

    const-string/jumbo v2, "thtcaunlqgaiIl"

    const/4 v5, 0x1

    const-string v2, "IFuaoilnctlhag"

    const-string v2, "actualInFlight"

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/Integer;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inFlightPubRels:I

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {v1, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v5, 0x1

    const-string/jumbo v2, "lsltFbsgbiRhPne"

    const-string/jumbo v2, "nssltheglibFRuP"

    const/4 v5, 0x6

    const-string/jumbo v2, "llgbuPuihsRFent"

    const-string/jumbo v2, "inFlightPubRels"

    const/4 v4, 0x1

    or-int/2addr v5, v4

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiescing:Z

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string v2, "cieiguqpn"

    const-string/jumbo v2, "quiescing"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v1, Ljava/lang/Integer;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstanding:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-direct {v1, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v2, "dmastpgiqnnoitu"

    const-string/jumbo v2, "tunmgisopinagtd"

    const/4 v5, 0x4

    const-string/jumbo v2, "pisgtgnndoasuti"

    const-string/jumbo v2, "pingoutstanding"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v1, Ljava/lang/Long;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-wide v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastOutboundActivity:J

    const/4 v5, 0x4

    invoke-direct {v1, v2, v3}, Ljava/lang/Long;-><init>(J)V

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v2, "tuioodlutAtscyinavbO"

    const/4 v5, 0x2

    const-string/jumbo v2, "lastOutboundActivity"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x6

    new-instance v1, Ljava/lang/Long;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-wide v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastInboundActivity:J

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {v1, v2, v3}, Ljava/lang/Long;-><init>(J)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string/jumbo v2, "scnmbynaAtdtoutvili"

    const-string v2, "adciubtlvtAstnniyob"

    const/4 v5, 0x3

    const-string/jumbo v2, "vottonAslcnybiIiadu"

    const-string/jumbo v2, "lastInboundActivity"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v1, "duotobSuoQ2u"

    const-string v1, "StouoQudo2ub"

    const/4 v5, 0x3

    const-string v1, "2dotbouSQnuu"

    const-string/jumbo v1, "outboundQoS2"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo v1, "otuSobopudQp"

    const-string/jumbo v1, "oSbtoduponuQ"

    const-string/jumbo v1, "otdouonQqbu1"

    const-string/jumbo v1, "outboundQoS1"

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v1, "dSstqooo0uub"

    const-string v1, "bu0uotSQqodo"

    const/4 v5, 0x3

    const-string v1, "QnSm0dtoouou"

    const-string/jumbo v1, "outboundQoS0"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS0:Ljava/util/Hashtable;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string v1, "QnsooSbduno"

    const-string/jumbo v1, "uosbQoSidnn"

    const/4 v5, 0x7

    const-string v1, "db2QubooSin"

    const-string/jumbo v1, "inboundQoS2"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inboundQoS2:Ljava/util/Hashtable;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x1

    const-string/jumbo v1, "umkens"

    const-string/jumbo v1, "snemkt"

    const/4 v5, 0x6

    const-string/jumbo v1, "opsekt"

    const-string/jumbo v1, "tokens"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object v0
.end method

.method protected getKeepAlive()J
    .locals 4

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->keepAlive:J

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-wide v0
.end method

.method public getMaxInFlight()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->maxInflight:I

    const/4 v1, 0x1

    move v2, v1

    return v0
.end method

.method protected notifyComplete(Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    .locals 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v10, 0x7

    move v11, v10

    iget-object v0, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getWireMessage()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x2

    if-eqz v0, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    instance-of v1, v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x2

    if-eqz v1, :cond_2

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x4

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v10, 0x3

    shr-int/2addr v11, v10

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v11, 0x3

    new-instance v3, Ljava/lang/Integer;

    const/4 v11, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v4

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-direct {v3, v4}, Ljava/lang/Integer;-><init>(I)V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/4 v4, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    aput-object v3, v2, v4

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    const/4 v3, 0x1

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    aput-object p1, v2, v3

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 p1, 0x2

    move v11, p1

    const/4 v10, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    aput-object v0, v2, p1

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x5

    const-string/jumbo v5, "ieatetnlqtS"

    const-string v5, "ClientState"

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    const-string/jumbo v6, "ooseCnepitlyot"

    const-string v6, "Cnlooyttiepeom"

    const/4 v11, 0x4

    const-string/jumbo v6, "ltemCymotfnpie"

    const-string/jumbo v6, "notifyComplete"

    const/4 v11, 0x2

    const/4 v10, 0x0

    const-string v7, "962"

    const-string v7, "692"

    const/4 v11, 0x5

    const-string v7, "926"

    const-string v7, "629"

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-interface {v1, v5, v6, v7, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    check-cast v2, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x0

    instance-of v7, v2, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubAck;

    const/4 v11, 0x0

    const/4 v10, 0x5

    if-eqz v7, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v7

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-interface {p1, v7}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v11, 0x5

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendBufferedPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v7

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-interface {p1, v7}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    new-instance v7, Ljava/lang/Integer;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v8

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-direct {v7, v8}, Ljava/lang/Integer;-><init>(I)V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {p1, v7}, Ljava/util/Hashtable;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->decrementInFlight()V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result p1

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->releaseMessageId(I)V

    const/4 v10, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {p1, v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->removeToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    new-array p1, v3, [Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v10, 0x6

    new-instance v0, Ljava/lang/Integer;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v2

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-direct {v0, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x0

    aput-object v0, p1, v4

    const/4 v11, 0x4

    const-string v0, "650"

    const-string v0, "650"

    const/4 v11, 0x5

    const/4 v10, 0x2

    invoke-interface {v1, v5, v6, v0, p1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    goto/16 :goto_0

    :cond_0
    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x2

    instance-of v7, v2, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x5

    if-eqz v7, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x5

    iget-object v7, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-interface {v7, v8}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V

    const/4 v11, 0x1

    iget-object v7, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v10, 0x4

    move v11, v10

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendConfirmPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-interface {v7, v8}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    iget-object v7, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendBufferedPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-interface {v7, v8}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x0

    iget-object v7, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x6

    new-instance v8, Ljava/lang/Integer;

    const/4 v11, 0x2

    const/4 v10, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v9

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-direct {v8, v9}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v7, v8}, Ljava/util/Hashtable;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x4

    iget v7, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inFlightPubRels:I

    const/4 v11, 0x3

    sub-int/2addr v7, v3

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x2

    iput v7, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inFlightPubRels:I

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->decrementInFlight()V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v7

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-direct {p0, v7}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->releaseMessageId(I)V

    const/4 v10, 0x0

    const/4 v11, 0x2

    iget-object v7, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v7, v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->removeToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x7

    new-instance v0, Ljava/lang/Integer;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v2

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-direct {v0, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x7

    aput-object v0, p1, v4

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    new-instance v0, Ljava/lang/Integer;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inFlightPubRels:I

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-direct {v0, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v11, 0x2

    const/4 v10, 0x2

    aput-object v0, p1, v3

    const/4 v10, 0x3

    move v11, v10

    const-string v0, "564"

    const-string v0, "564"

    const/4 v11, 0x7

    const-string v0, "564"

    const-string v0, "645"

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-interface {v1, v5, v6, v0, p1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_1
    :goto_0
    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->checkQuiesceLock()Z

    :cond_2
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    return-void
.end method

.method public notifyQueueLock()V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x1

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v2, "tbaloineeSt"

    const-string/jumbo v2, "nSteCbaltei"

    const/4 v6, 0x1

    const-string/jumbo v2, "tleCtbenSat"

    const-string v2, "ClientState"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string/jumbo v3, "notifyQueueLock"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v4, "836"

    const-string v4, "386"

    const/4 v6, 0x3

    const-string v4, "863"

    const-string v4, "638"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    monitor-exit v0

    const/4 v6, 0x3

    return-void

    :catchall_0
    move-exception v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    throw v1
.end method

.method protected notifyReceivedAck(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;)V
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x4

    iput-wide v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastInboundActivity:J

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x1

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    const-string v1, "SCeetnuatut"

    const-string v1, "eCntatuelSt"

    const/4 v12, 0x2

    const-string/jumbo v1, "ntSatteplie"

    const-string v1, "ClientState"

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x3

    const-string v2, "eRtkvieAqyfpconec"

    const-string v2, "AvieeRcpfntdoekcy"

    const-string/jumbo v2, "iestydvfinekocReA"

    const-string/jumbo v2, "notifyReceivedAck"

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    const-string v3, "267"

    const-string v3, "762"

    const/4 v12, 0x3

    const-string v3, "762"

    const-string v3, "627"

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x0

    const/4 v4, 0x2

    const/4 v11, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x2

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v11, 0x2

    move v12, v11

    new-instance v5, Ljava/lang/Integer;

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v6

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-direct {v5, v6}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x5

    const/4 v6, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x7

    aput-object v5, v4, v6

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x0

    const/4 v5, 0x1

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x4

    aput-object p1, v4, v5

    const/4 v12, 0x1

    invoke-interface {v0, v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-virtual {v1, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->getToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    move-result-object v1

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    if-nez v1, :cond_0

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x5

    const-string/jumbo v1, "nlimaqCttSt"

    const-string v1, "CaenttliqSt"

    const/4 v12, 0x7

    const-string/jumbo v1, "telaotientC"

    const-string v1, "ClientState"

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x2

    const-string/jumbo v2, "yiokebfdsceAneict"

    const-string v2, "cksoeARiecnfediyt"

    const/4 v12, 0x6

    const-string v2, "AekenfuyoRtcvcedi"

    const-string/jumbo v2, "notifyReceivedAck"

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    const-string v3, "266"

    const-string v3, "662"

    const/4 v12, 0x3

    const-string v3, "266"

    const-string v3, "662"

    const/4 v12, 0x4

    const/4 v11, 0x7

    new-array v4, v5, [Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x6

    new-instance v5, Ljava/lang/Integer;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result p1

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-direct {v5, p1}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x4

    aput-object v5, v4, v6

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-interface {v0, v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x1

    goto/16 :goto_1

    :cond_0
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x5

    instance-of v2, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRec;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x3

    if-eqz v2, :cond_1

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string v2, "etnmtClpSai"

    const-string/jumbo v2, "ttCmatSenil"

    const/4 v12, 0x3

    const-string/jumbo v2, "neltCtSaqei"

    const-string v2, "ClientState"

    const/4 v11, 0x3

    move v12, v11

    const-string v3, "RcsocvnfitAekeeyi"

    const-string/jumbo v3, "iyevofeeRcnAcitkd"

    const/4 v12, 0x7

    const-string v3, "cvkmcAeodeiefRyin"

    const-string/jumbo v3, "notifyReceivedAck"

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x5

    const-string v4, "636"

    const-string v4, "663"

    const/4 v12, 0x7

    const-string v4, "636"

    const-string v4, "663"

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x0

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    new-instance v7, Ljava/lang/Integer;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v8

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-direct {v7, v8}, Ljava/lang/Integer;-><init>(I)V

    const/4 v11, 0x3

    move v12, v11

    aput-object v7, v5, v6

    const/4 v11, 0x0

    move v12, v11

    invoke-interface {v0, v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x2

    const/4 v11, 0x4

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;

    const/4 v12, 0x4

    const/4 v11, 0x3

    check-cast p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRec;

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-direct {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;-><init>(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRec;)V

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {p0, v0, v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->send(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x2

    goto/16 :goto_1

    :cond_1
    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x4

    instance-of v2, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubAck;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    const/4 v3, 0x0

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    if-nez v2, :cond_8

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x4

    instance-of v2, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    if-eqz v2, :cond_2

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x5

    goto/16 :goto_0

    :cond_2
    const/4 v12, 0x5

    const/4 v11, 0x0

    instance-of v2, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPingResp;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    if-eqz v2, :cond_4

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x1

    const-string v2, "etaeCblittn"

    const/4 v12, 0x6

    const-string v2, "ClientState"

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x3

    const-string v4, "eAfkocvyodietRucn"

    const-string v4, "dotckeucifRyAneve"

    const/4 v12, 0x1

    const-string v4, "eAdotbnecyikfieRc"

    const-string/jumbo v4, "notifyReceivedAck"

    const/4 v11, 0x7

    move v12, v11

    const-string v7, "646"

    const-string v7, "466"

    const/4 v12, 0x4

    const-string v7, "646"

    const-string v7, "664"

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    new-array v8, v5, [Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    new-instance v9, Ljava/lang/Integer;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v10

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-direct {v9, v10}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x6

    aput-object v9, v8, v6

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-interface {v0, v2, v4, v7, v8}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstandingLock:Ljava/lang/Object;

    const/4 v12, 0x3

    monitor-enter v2

    :try_start_0
    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstanding:I

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x5

    sub-int/2addr v0, v5

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-static {v6, v0}, Ljava/lang/Math;->max(II)I

    move-result v0

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x6

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstanding:I

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-virtual {p0, p1, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifyResult(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstanding:I

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x5

    if-nez v0, :cond_3

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->removeToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    :cond_3
    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x6

    monitor-exit v2

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x7

    goto/16 :goto_1

    :catchall_0
    move-exception p1

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x6

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x1

    const/4 v11, 0x5

    throw p1

    :cond_4
    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    instance-of v2, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x5

    if-eqz v2, :cond_7

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    const-string/jumbo v2, "tatpeSuintC"

    const-string/jumbo v2, "teiCentptSa"

    const-string v2, "SitenalpCet"

    const-string v2, "ClientState"

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    const-string/jumbo v4, "tyocceivqefAieqRk"

    const-string/jumbo v4, "tcRAvceoqfyeeniki"

    const/4 v12, 0x2

    const-string/jumbo v4, "insdeykeceoARvtif"

    const-string/jumbo v4, "notifyReceivedAck"

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x3

    const-string v7, "665"

    const-string v7, "566"

    const/4 v12, 0x2

    const-string v7, "566"

    const-string v7, "665"

    const/4 v12, 0x2

    const/4 v11, 0x5

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v11, 0x6

    new-instance v8, Ljava/lang/Integer;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v9

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-direct {v8, v9}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x5

    aput-object v8, v5, v6

    const/4 v11, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-interface {v0, v2, v4, v7, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v12, 0x3

    const/4 v11, 0x3

    check-cast v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;->getReturnCode()I

    move-result v2

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x0

    if-nez v2, :cond_6

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x2

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v11, 0x1

    const/4 v12, 0x5

    monitor-enter v4

    :try_start_1
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    iget-boolean v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->cleanSession:Z

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x2

    if-eqz v2, :cond_5

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->clearState()V

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-virtual {v2, v1, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->saveToken(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    :cond_5
    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    iput v6, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inFlightPubRels:I

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x2

    iput v6, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->restoreInflightMessages()V

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->connected()V

    const/4 v11, 0x6

    move v12, v11

    monitor-exit v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-virtual {v2, v0, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->connectComplete(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-virtual {p0, p1, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifyResult(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->removeToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v12, 0x7

    monitor-enter p1

    :try_start_2
    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x4

    monitor-exit p1

    const/4 v12, 0x2

    goto/16 :goto_1

    :catchall_1
    move-exception v0

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    monitor-exit p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x0

    throw v0

    :catchall_2
    move-exception p1

    :try_start_3
    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x2

    monitor-exit v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    const/4 v12, 0x5

    const/4 v11, 0x7

    throw p1

    :cond_6
    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-static {v2}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object p1

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    throw p1

    :cond_7
    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x3

    const-string/jumbo v2, "salmnttieeS"

    const-string/jumbo v2, "ltseaittSne"

    const/4 v12, 0x3

    const-string/jumbo v2, "ielCoteSant"

    const-string v2, "ClientState"

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x0

    const-string/jumbo v4, "nkevmbectefdocAyR"

    const-string v4, "eekmARodcitnvfeyc"

    const/4 v12, 0x6

    const-string v4, "fAiynkuveeReioctc"

    const-string/jumbo v4, "notifyReceivedAck"

    const/4 v12, 0x1

    const-string v7, "666"

    const-string v7, "666"

    const/4 v12, 0x1

    const-string v7, "666"

    const-string v7, "666"

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    new-instance v8, Ljava/lang/Integer;

    const/4 v11, 0x2

    and-int/2addr v12, v11

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v9

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-direct {v8, v9}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    aput-object v8, v5, v6

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-interface {v0, v2, v4, v7, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {p0, p1, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifyResult(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v12, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v0

    const/4 v12, 0x7

    const/4 v11, 0x5

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->releaseMessageId(I)V

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->removeToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v12, 0x0

    goto :goto_1

    :cond_8
    :goto_0
    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-virtual {p0, p1, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifyResult(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    :goto_1
    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->checkQuiesceLock()Z

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x0

    return-void
.end method

.method public notifyReceivedBytes(I)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-lez p1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastInboundActivity:J

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v1, 0x1

    const/4 v5, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    new-instance v2, Ljava/lang/Integer;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {v2, p1}, Ljava/lang/Integer;-><init>(I)V

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 p1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    aput-object v2, v1, p1

    const/4 v5, 0x3

    const-string p1, "antltoeptSC"

    const-string/jumbo p1, "tiSnolCatte"

    const/4 v5, 0x7

    const-string/jumbo p1, "itSatleeqnC"

    const-string p1, "ClientState"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v2, "ysvRdbcefBeeenyoitt"

    const/4 v5, 0x0

    const-string/jumbo v2, "sysoeitfedteivncRye"

    const-string/jumbo v2, "notifyReceivedBytes"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string v3, "063"

    const-string v3, "360"

    const/4 v5, 0x4

    const-string v3, "630"

    const-string v3, "630"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-interface {v0, p1, v2, v3, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v5, 0x6

    return-void
.end method

.method protected notifyReceivedMsg(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-string/jumbo v1, "nMcmetgunyi ict-oade:Rse oi"

    const-string v1, "ece -guon:tsciiifontaRdeM y"

    const/4 v8, 0x4

    const-string v1, "gMeooee doisicaniyf n:cRt-t"

    const-string v1, "action - notifyReceivedMsg:"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string v1, "etnlebttCSa"

    const-string v1, "ClientState"

    const/4 v8, 0x3

    const/4 v7, 0x1

    invoke-static {v1, v0}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v8, 0x3

    const/4 v7, 0x4

    iput-wide v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastInboundActivity:J

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v2, 0x2

    const/4 v8, 0x5

    const/4 v7, 0x7

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    new-instance v4, Ljava/lang/Integer;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v5

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-direct {v4, v5}, Ljava/lang/Integer;-><init>(I)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v5, 0x6

    const/4 v5, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    aput-object v4, v3, v5

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    const/4 v4, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    aput-object p1, v3, v4

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string/jumbo v5, "vcfpMnusdoiyigeet"

    const-string v5, "eyidscnpftMvegRoi"

    const-string/jumbo v5, "sycifMdpetoRvieng"

    const-string/jumbo v5, "notifyReceivedMsg"

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-string v6, "516"

    const-string v6, "651"

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-interface {v0, v1, v5, v6, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiescing:Z

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-nez v0, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/4 v1, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    if-eqz v0, :cond_2

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    check-cast v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v3}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-eqz v3, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-eq v3, v4, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    if-eq v3, v2, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    goto/16 :goto_0

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getReceivedPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-interface {v2, p1, v0}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->put(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttPersistable;)V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inboundQoS2:Ljava/util/Hashtable;

    const/4 v8, 0x6

    const/4 v7, 0x2

    new-instance v2, Ljava/lang/Integer;

    const/4 v8, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v3

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-direct {v2, v3}, Ljava/lang/Integer;-><init>(I)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p1, v2, v0}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    new-instance p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRec;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-direct {p1, v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRec;-><init>(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p0, p1, v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->send(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    goto :goto_0

    :cond_1
    const/4 v7, 0x0

    move v8, v7

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v7, 0x7

    move v8, v7

    if-eqz p1, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p1, v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageArrived(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    goto :goto_0

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eqz v0, :cond_4

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inboundQoS2:Ljava/util/Hashtable;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-instance v2, Ljava/lang/Integer;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-direct {v2, v3}, Ljava/lang/Integer;-><init>(I)V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v0, v2}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    check-cast v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v7, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eqz v0, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz p1, :cond_4

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {p1, v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageArrived(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    goto :goto_0

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x1

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;

    const/4 v7, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result p1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-direct {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;-><init>(I)V

    const/4 v8, 0x7

    invoke-virtual {p0, v0, v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->send(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    :cond_4
    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    return-void
.end method

.method protected notifyResult(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string/jumbo v0, "loyaRttqqitnfe:oisu"

    const-string/jumbo v0, "lnufoteaqoRstnt:iyi"

    const/4 v9, 0x7

    const-string/jumbo v0, "n:suRianefyoctttsli"

    const-string v0, "action:notifyResult"

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    const-string v1, "aCimttlnSse"

    const-string/jumbo v1, "tisneCtaleS"

    const/4 v9, 0x0

    const-string/jumbo v1, "nlttoSeeCit"

    const-string v1, "ClientState"

    const/4 v8, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {v1, v0}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget-object v0, p2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x2

    invoke-virtual {v0, p1, p3}, Lcom/tencent/android/tpns/mqtt/internal/Token;->markComplete(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    iget-object v0, p2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->notifyComplete()V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    const/4 v0, 0x1

    const/4 v9, 0x2

    const/4 v2, 0x0

    const/4 v9, 0x0

    xor-int/2addr v8, v2

    const/4 v9, 0x6

    const/4 v3, 0x2

    const/4 v9, 0x0

    move v8, v3

    move v8, v3

    const/4 v9, 0x1

    const-string v4, "Rttnlbeumfoi"

    const-string/jumbo v4, "iltmutRfseno"

    const/4 v9, 0x3

    const-string/jumbo v4, "lnfstyuiRteo"

    const-string/jumbo v4, "notifyResult"

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    if-eqz p1, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x5

    instance-of v5, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;

    const/4 v9, 0x1

    const/4 v8, 0x7

    if-eqz v5, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    instance-of v5, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRec;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-nez v5, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    sget-object v5, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/4 v6, 0x3

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v7, p2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v7}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x2

    const/4 v8, 0x4

    aput-object v7, v6, v2

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x3

    aput-object p1, v6, v0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    aput-object p3, v6, v3

    const/4 v9, 0x0

    const-string v7, "486"

    const-string v7, "684"

    const/4 v9, 0x1

    const-string v7, "486"

    const-string v7, "648"

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-interface {v5, v1, v4, v7, v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    iget-object v5, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v5, p2}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->asyncOperationComplete(Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-nez p1, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x6

    const/4 v8, 0x7

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v5, p2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {v5}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    aput-object v5, v3, v2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    aput-object p3, v3, v0

    const/4 v8, 0x5

    move v9, v8

    const-string p3, "946"

    const/4 v9, 0x0

    const-string p3, "469"

    const-string p3, "649"

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-interface {p1, v1, v4, p3, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v9, 0x5

    const/4 v8, 0x6

    invoke-virtual {p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->asyncOperationComplete(Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    return-void
.end method

.method protected notifySent(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string v0, "alttSenptoC"

    const-string/jumbo v0, "ttnloSeiCat"

    const/4 v9, 0x0

    const-string/jumbo v0, "tentaleCqti"

    const-string v0, "ClientState"

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-string/jumbo v1, "oysctnaSfibtin oen "

    const-string/jumbo v1, "nyf tbncat Sitoione"

    const/4 v9, 0x5

    const-string v1, "ftamic-noeSnt nyt o"

    const-string v1, "action - notifySent"

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-static {v0, v1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastOutboundActivity:J

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x0

    shl-int/2addr v9, v8

    const-string/jumbo v1, "tluCoiaetSn"

    const-string v1, "eliStnuCtat"

    const/4 v9, 0x3

    const-string v1, "ClientState"

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    const-string/jumbo v2, "tnynSboiep"

    const-string v2, "efoinnSpyt"

    const/4 v9, 0x0

    const-string v2, "enittoufyS"

    const-string/jumbo v2, "notifySent"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string v3, "562"

    const-string v3, "625"

    const/4 v9, 0x4

    const-string v3, "526"

    const-string v3, "625"

    const/4 v4, 0x0

    const/4 v4, 0x1

    const/4 v9, 0x6

    or-int/2addr v8, v4

    new-array v5, v4, [Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getKey()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    const/4 v7, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x6

    aput-object v6, v5, v7

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-interface {v0, v1, v2, v3, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->getToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v1, v0, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->notifySent()V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    instance-of v1, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPingReq;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-eqz v1, :cond_0

    const/4 v8, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstandingLock:Ljava/lang/Object;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    monitor-enter v1

    :try_start_0
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstandingLock:Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    monitor-enter p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    iput-wide v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastPing:J

    const/4 v8, 0x3

    move v9, v8

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstanding:I

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    add-int/2addr v0, v4

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingOutstanding:I

    const/4 v9, 0x0

    const/4 v8, 0x5

    monitor-exit p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    goto :goto_0

    :catchall_0
    move-exception v0

    :try_start_3
    const/4 v9, 0x7

    const/4 v8, 0x4

    monitor-exit p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x5

    throw v0

    :catchall_1
    move-exception p1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    monitor-exit v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    throw p1

    :cond_0
    const/4 v8, 0x2

    const/4 v8, 0x6

    instance-of v1, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-eqz v1, :cond_1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    check-cast v1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-nez v1, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v1, v0, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    const/4 v2, 0x0

    const/4 v9, 0x2

    invoke-virtual {v1, v2, v2}, Lcom/tencent/android/tpns/mqtt/internal/Token;->markComplete(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v9, 0x3

    invoke-virtual {v1, v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->asyncOperationComplete(Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->decrementInFlight()V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->releaseMessageId(I)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->removeToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->checkQuiesceLock()Z

    :cond_1
    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    return-void
.end method

.method public notifySentBytes(I)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-lez p1, :cond_0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v5, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->lastOutboundActivity:J

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/4 v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/Integer;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v2, p1}, Ljava/lang/Integer;-><init>(I)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/4 p1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    aput-object v2, v1, p1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string p1, "SqeCtaepltn"

    const-string p1, "SetaClntqet"

    const/4 v5, 0x5

    const-string/jumbo p1, "ttlSteeaqiC"

    const-string p1, "ClientState"

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v2, "tfsetiSnntyosyB"

    const-string/jumbo v2, "tissyytnnfoteBS"

    const/4 v5, 0x4

    const-string/jumbo v2, "nifmBytenSttosy"

    const-string/jumbo v2, "notifySentBytes"

    const/4 v5, 0x7

    const-string v3, "643"

    const-string v3, "346"

    const/4 v5, 0x0

    const-string v3, "364"

    const-string v3, "643"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-interface {v0, p1, v2, v3, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v4, 0x1

    move v5, v4

    return-void
.end method

.method public persistBufferedMessage(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V
    .locals 8

    const/4 v7, 0x3

    const-string/jumbo v0, "mrreoeueMiftfsesagBssd"

    const-string v0, "edrmetseMriaseBegfssfu"

    const/4 v7, 0x1

    const-string/jumbo v0, "uteeMbererigfpfsssaseB"

    const-string/jumbo v0, "persistBufferedMessage"

    const/4 v6, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string v1, "eaCneSutitt"

    const-string v1, "ClientState"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendBufferedPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getNextMessageId()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {p1, v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->setMessageId(I)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendBufferedPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    check-cast v4, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-interface {v3, v2, v4}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->put(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttPersistable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_0

    :catchall_0
    :try_start_2
    const/4 v7, 0x6

    const/4 v6, 0x4

    sget-object v3, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string v4, "515"

    const-string v4, "155"

    const/4 v7, 0x7

    const-string v4, "551"

    const-string v4, "515"

    const/4 v6, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-interface {v3, v1, v0, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v6, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v4}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-interface {v4}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v5, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v7, 0x6

    invoke-virtual {v5}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v5

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-interface {v5}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getServerURI()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-interface {v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->open(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    check-cast p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-interface {v3, v2, p1}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->put(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttPersistable;)V

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string v3, "135"

    const-string v3, "351"

    const/4 v7, 0x4

    const-string v3, "351"

    const-string v3, "513"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v4, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    const/4 v5, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x2

    aput-object v2, v4, v5

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-interface {p1, v1, v0, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    goto :goto_1

    :catchall_1
    move-exception p1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-static {v1, v0, p1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    return-void
.end method

.method public quiesce(J)V
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v9, 0x3

    const-wide/16 v0, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    cmp-long v0, p1, v0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-lez v0, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x7

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const-string/jumbo v1, "tCtoaeepilS"

    const-string/jumbo v1, "lCtSoneitea"

    const/4 v9, 0x3

    const-string v1, "eaeiSlttqnC"

    const-string v1, "ClientState"

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string/jumbo v2, "qescsei"

    const-string/jumbo v2, "quiesce"

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string v3, "673"

    const-string v3, "637"

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    const/4 v4, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    new-array v5, v4, [Ljava/lang/Object;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    new-instance v6, Ljava/lang/Long;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-direct {v6, p1, p2}, Ljava/lang/Long;-><init>(J)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v7, 0x0

    and-int/2addr v9, v7

    const/4 v8, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    aput-object v6, v5, v7

    const/4 v9, 0x6

    invoke-interface {v0, v1, v2, v3, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x2

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    iput-boolean v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiescing:Z

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->quiesce()V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifyQueueLock()V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiesceLock:Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    monitor-enter v1

    :try_start_1
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->count()I

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x0

    if-gtz v0, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-gtz v0, :cond_0

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->isQuiesced()Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-nez v0, :cond_1

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiesceLock:Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v0, p1, p2}, Ljava/lang/Object;->wait(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    goto :goto_1

    :catch_0
    :cond_1
    :goto_0
    :try_start_2
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    monitor-enter p1

    :try_start_3
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v8, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {p2}, Ljava/util/Vector;->clear()V

    const/4 v8, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {p2}, Ljava/util/Vector;->clear()V

    const/4 v9, 0x4

    const/4 v8, 0x5

    iput-boolean v7, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiescing:Z

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    iput v7, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    monitor-exit p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string p2, "eltmbtiCSat"

    const-string/jumbo p2, "taCSnblteit"

    const/4 v9, 0x1

    const-string/jumbo p2, "ttitoneealC"

    const-string p2, "ClientState"

    const/4 v9, 0x3

    const-string v0, "euiucbe"

    const-string v0, "cesiueu"

    const/4 v9, 0x4

    const-string/jumbo v0, "uieesqu"

    const-string/jumbo v0, "quiesce"

    const/4 v9, 0x4

    const-string v1, "460"

    const-string v1, "406"

    const/4 v9, 0x1

    const-string v1, "460"

    const-string v1, "640"

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-interface {p1, p2, v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    goto :goto_2

    :catchall_1
    move-exception p2

    :try_start_4
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    monitor-exit p1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    throw p2

    :goto_1
    :try_start_5
    const/4 v9, 0x3

    monitor-exit v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    throw p1

    :catchall_2
    move-exception p1

    :try_start_6
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    monitor-exit v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    const/4 v8, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    throw p1

    :cond_2
    :goto_2
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    return-void
.end method

.method public resolveOldTokens(Lcom/tencent/android/tpns/mqtt/MqttException;)Ljava/util/Vector;
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string v1, "elnepatptti"

    const-string v1, "eialteCpntt"

    const/4 v7, 0x3

    const-string/jumbo v1, "taSeniCtqle"

    const-string v1, "ClientState"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string v2, "eosqsseklOdrvnlT"

    const-string/jumbo v2, "rvTenoseqlOeksld"

    const/4 v7, 0x3

    const-string/jumbo v2, "oremsTlvnedlekOs"

    const-string/jumbo v2, "resolveOldTokens"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v3, "326"

    const-string v3, "632"

    const/4 v7, 0x0

    const/4 v4, 0x1

    move v6, v4

    move v6, v4

    const/4 v7, 0x6

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/4 v5, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x1

    aput-object p1, v4, v5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-interface {v0, v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez p1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/16 v0, 0x7d66

    invoke-direct {p1, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v7, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->getOutstandingTokens()Ljava/util/Vector;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object v1

    :cond_1
    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-interface {v1}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v2, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-interface {v1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    check-cast v2, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    monitor-enter v2

    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/MqttToken;->isComplete()Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-nez v3, :cond_2

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v3, v2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v3}, Lcom/tencent/android/tpns/mqtt/internal/Token;->isCompletePending()Z

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x3

    if-nez v3, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/MqttToken;->getException()Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x5

    if-nez v3, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v3, v2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v7, 0x3

    invoke-virtual {v3, p1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->setException(Lcom/tencent/android/tpns/mqtt/MqttException;)V

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    instance-of v3, v2, Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-nez v3, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v2, v2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v3, v2}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->removeToken(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    goto :goto_0

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    monitor-exit v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    throw p1

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    return-object v0
.end method

.method protected restoreState()V
    .locals 15
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->keys()Ljava/util/Enumeration;

    move-result-object v0

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->nextMsgId:I

    new-instance v2, Ljava/util/Vector;

    invoke-direct {v2}, Ljava/util/Vector;-><init>()V

    sget-object v3, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const-string v4, "006"

    const-string v4, "600"

    const-string v4, "060"

    const-string v4, "600"

    const-string/jumbo v5, "neteottSisa"

    const-string v5, "eCsttSinaet"

    const-string v5, "ClientState"

    const-string v6, "ateSebrrtsot"

    const-string/jumbo v6, "restoreState"

    invoke-interface {v3, v5, v6, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v3

    const/4 v4, 0x0

    const/4 v7, 0x1

    if-eqz v3, :cond_9

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Ljava/lang/String;

    iget-object v8, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    invoke-interface {v8, v3}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->get(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/MqttPersistable;

    move-result-object v8

    invoke-direct {p0, v3, v8}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->restoreMessage(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttPersistable;)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object v8

    if-eqz v8, :cond_0

    const-string v9, "-r"

    const-string/jumbo v9, "r-"

    const-string/jumbo v9, "r-"

    invoke-virtual {v3, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v9

    const/4 v10, 0x2

    if-eqz v9, :cond_1

    sget-object v9, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    new-array v10, v10, [Ljava/lang/Object;

    aput-object v3, v10, v4

    aput-object v8, v10, v7

    const-string v3, "640"

    const-string v3, "640"

    const-string v3, "604"

    const-string v3, "604"

    invoke-interface {v9, v5, v6, v3, v10}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inboundQoS2:Ljava/util/Hashtable;

    new-instance v4, Ljava/lang/Integer;

    invoke-virtual {v8}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v7

    invoke-direct {v4, v7}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v3, v4, v8}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_1
    const-string/jumbo v9, "s-"

    const-string/jumbo v9, "s-"

    invoke-virtual {v3, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v9

    const-string v11, "860"

    const-string v11, "608"

    const-string v12, "706"

    const-string v12, "607"

    if-eqz v9, :cond_5

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    check-cast v9, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v13

    invoke-static {v13, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    iget-object v13, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    invoke-direct {p0, v9}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendConfirmPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v14

    invoke-interface {v13, v14}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->containsKey(Ljava/lang/String;)Z

    move-result v13

    if-eqz v13, :cond_3

    iget-object v11, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    invoke-direct {p0, v9}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendConfirmPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v12

    invoke-interface {v11, v12}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->get(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/MqttPersistable;

    move-result-object v11

    invoke-direct {p0, v3, v11}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->restoreMessage(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttPersistable;)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object v11

    check-cast v11, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;

    if-eqz v11, :cond_2

    sget-object v12, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    new-array v10, v10, [Ljava/lang/Object;

    aput-object v3, v10, v4

    aput-object v8, v10, v7

    const-string v3, "056"

    const-string v3, "065"

    const-string v3, "506"

    const-string v3, "605"

    invoke-interface {v12, v5, v6, v3, v10}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    new-instance v4, Ljava/lang/Integer;

    invoke-virtual {v11}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v7

    invoke-direct {v4, v7}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v3, v4, v11}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_2
    sget-object v11, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    new-array v10, v10, [Ljava/lang/Object;

    aput-object v3, v10, v4

    aput-object v8, v10, v7

    const-string v3, "660"

    const-string v3, "606"

    const-string v3, "066"

    const-string v3, "606"

    invoke-interface {v11, v5, v6, v3, v10}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    goto :goto_1

    :cond_3
    invoke-virtual {v9, v7}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->setDuplicate(Z)V

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v13

    invoke-virtual {v13}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v13

    if-ne v13, v10, :cond_4

    sget-object v11, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    new-array v10, v10, [Ljava/lang/Object;

    aput-object v3, v10, v4

    aput-object v8, v10, v7

    invoke-interface {v11, v5, v6, v12, v10}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    new-instance v4, Ljava/lang/Integer;

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v7

    invoke-direct {v4, v7}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v3, v4, v9}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_4
    sget-object v12, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    new-array v10, v10, [Ljava/lang/Object;

    aput-object v3, v10, v4

    aput-object v8, v10, v7

    invoke-interface {v12, v5, v6, v11, v10}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    new-instance v4, Ljava/lang/Integer;

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v7

    invoke-direct {v4, v7}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v3, v4, v9}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_1
    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    invoke-virtual {v3, v9}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->restoreToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    move-result-object v3

    iget-object v3, v3, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    invoke-virtual {v4}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/tencent/android/tpns/mqtt/internal/Token;->setClient(Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;)V

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inUseMsgIds:Ljava/util/Hashtable;

    new-instance v4, Ljava/lang/Integer;

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v7

    invoke-direct {v4, v7}, Ljava/lang/Integer;-><init>(I)V

    new-instance v7, Ljava/lang/Integer;

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v8

    invoke-direct {v7, v8}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v3, v4, v7}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_0

    :cond_5
    const-string/jumbo v9, "sb-"

    const-string/jumbo v9, "s-b"

    const-string/jumbo v9, "s-b"

    const-string/jumbo v9, "sb-"

    invoke-virtual {v3, v9}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v9

    if-eqz v9, :cond_8

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    move-object v9, v8

    check-cast v9, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v13

    invoke-static {v13, v1}, Ljava/lang/Math;->max(II)I

    move-result v1

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v13

    invoke-virtual {v13}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v13

    if-ne v13, v10, :cond_6

    sget-object v11, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    new-array v10, v10, [Ljava/lang/Object;

    aput-object v3, v10, v4

    aput-object v8, v10, v7

    invoke-interface {v11, v5, v6, v12, v10}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    new-instance v4, Ljava/lang/Integer;

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v7

    invoke-direct {v4, v7}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v3, v4, v9}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    :cond_6
    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v12

    invoke-virtual {v12}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v12

    if-ne v12, v7, :cond_7

    sget-object v12, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    new-array v10, v10, [Ljava/lang/Object;

    aput-object v3, v10, v4

    aput-object v8, v10, v7

    invoke-interface {v12, v5, v6, v11, v10}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    new-instance v4, Ljava/lang/Integer;

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v7

    invoke-direct {v4, v7}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v3, v4, v9}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    :cond_7
    sget-object v11, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    new-array v10, v10, [Ljava/lang/Object;

    aput-object v3, v10, v4

    aput-object v8, v10, v7

    const-string v4, "151"

    const-string v4, "151"

    const-string v4, "511"

    const-string v4, "511"

    invoke-interface {v11, v5, v6, v4, v10}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS0:Ljava/util/Hashtable;

    new-instance v7, Ljava/lang/Integer;

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v8

    invoke-direct {v7, v8}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v4, v7, v9}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    invoke-interface {v4, v3}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V

    :goto_2
    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    invoke-virtual {v3, v9}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->restoreToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    move-result-object v3

    iget-object v3, v3, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    invoke-virtual {v4}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v4

    invoke-virtual {v3, v4}, Lcom/tencent/android/tpns/mqtt/internal/Token;->setClient(Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;)V

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->inUseMsgIds:Ljava/util/Hashtable;

    new-instance v4, Ljava/lang/Integer;

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v7

    invoke-direct {v4, v7}, Ljava/lang/Integer;-><init>(I)V

    new-instance v7, Ljava/lang/Integer;

    invoke-virtual {v9}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v8

    invoke-direct {v7, v8}, Ljava/lang/Integer;-><init>(I)V

    invoke-virtual {v3, v4, v7}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_0

    :cond_8
    const-string v4, "-cs"

    const-string/jumbo v4, "s-c"

    const-string v4, "-cs"

    const-string/jumbo v4, "sc-"

    invoke-virtual {v3, v4}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v4

    if-eqz v4, :cond_0

    check-cast v8, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    invoke-direct {p0, v8}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v7

    invoke-interface {v4, v7}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->containsKey(Ljava/lang/String;)Z

    move-result v4

    if-nez v4, :cond_0

    invoke-virtual {v2, v3}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    goto/16 :goto_0

    :cond_9
    invoke-virtual {v2}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object v0

    :goto_3
    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    if-eqz v2, :cond_a

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Ljava/lang/String;

    sget-object v3, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    new-array v8, v7, [Ljava/lang/Object;

    aput-object v2, v8, v4

    const-string v9, "096"

    const-string v9, "960"

    const-string v9, "960"

    const-string v9, "609"

    invoke-interface {v3, v5, v6, v9, v8}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    invoke-interface {v3, v2}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V

    goto :goto_3

    :cond_a
    iput v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->nextMsgId:I

    return-void
.end method

.method public send(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v12, 0x5

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->isMessageIdRequired()Z

    move-result v0

    const/4 v12, 0x6

    if-eqz v0, :cond_2

    const/4 v12, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v0

    const/4 v12, 0x4

    if-nez v0, :cond_2

    const/4 v12, 0x4

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v12, 0x5

    if-eqz v0, :cond_0

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v12, 0x6

    check-cast v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v0

    const/4 v12, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v0

    const/4 v12, 0x6

    if-eqz v0, :cond_0

    const/4 v12, 0x5

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getNextMessageId()I

    move-result v0

    const/4 v12, 0x4

    invoke-virtual {p1, v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->setMessageId(I)V

    const/4 v12, 0x6

    goto :goto_0

    :cond_0
    const/4 v12, 0x4

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubAck;

    const/4 v12, 0x1

    if-nez v0, :cond_1

    const/4 v12, 0x6

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRec;

    const/4 v12, 0x7

    if-nez v0, :cond_1

    const/4 v12, 0x6

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;

    const/4 v12, 0x3

    if-nez v0, :cond_1

    const/4 v12, 0x5

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;

    const/4 v12, 0x2

    if-nez v0, :cond_1

    const/4 v12, 0x6

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;

    const/4 v12, 0x2

    if-nez v0, :cond_1

    const/4 v12, 0x2

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSuback;

    const/4 v12, 0x0

    if-nez v0, :cond_1

    const/4 v12, 0x3

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubscribe;

    const/4 v12, 0x5

    if-nez v0, :cond_1

    const/4 v12, 0x3

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubAck;

    const/4 v12, 0x4

    if-eqz v0, :cond_2

    :cond_1
    const/4 v12, 0x6

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getNextMessageId()I

    move-result v0

    const/4 v12, 0x3

    invoke-virtual {p1, v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->setMessageId(I)V

    :cond_2
    :goto_0
    const/4 v12, 0x5

    if-eqz p2, :cond_3

    :try_start_0
    const/4 v12, 0x4

    iget-object v0, p2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v12, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v1

    const/4 v12, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->setMessageID(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x3

    goto :goto_1

    :catchall_0
    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v12, 0x3

    const/16 p2, 0x7dc9

    const/4 v12, 0x1

    invoke-direct {p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    const/4 v12, 0x2

    throw p1

    :cond_3
    :goto_1
    const/4 v12, 0x4

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v12, 0x4

    const/4 v1, 0x2

    const/4 v12, 0x6

    const/4 v2, 0x1

    const/4 v12, 0x4

    const/4 v3, 0x0

    const/4 v12, 0x4

    if-eqz v0, :cond_7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v12, 0x6

    monitor-enter v0

    :try_start_1
    const/4 v12, 0x2

    iget v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->actualInFlight:I

    const/4 v12, 0x3

    iget v5, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->maxInflight:I

    if-ge v4, v5, :cond_6

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    const/4 v12, 0x7

    check-cast v4, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v12, 0x1

    invoke-virtual {v4}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v4

    const/4 v12, 0x3

    sget-object v5, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v12, 0x3

    const-string/jumbo v6, "nteaCeutlSi"

    const-string v6, "ClientState"

    const/4 v12, 0x4

    const-string v7, "dnes"

    const-string/jumbo v7, "sden"

    const-string/jumbo v7, "ndse"

    const-string/jumbo v7, "send"

    const/4 v12, 0x5

    const-string v8, "286"

    const-string v8, "862"

    const-string v8, "628"

    const/4 v12, 0x2

    const/4 v9, 0x3

    new-array v9, v9, [Ljava/lang/Object;

    const/4 v12, 0x5

    new-instance v10, Ljava/lang/Integer;

    const/4 v12, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v11

    const/4 v12, 0x0

    invoke-direct {v10, v11}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x5

    aput-object v10, v9, v3

    const/4 v12, 0x2

    new-instance v3, Ljava/lang/Integer;

    const/4 v12, 0x0

    invoke-virtual {v4}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v10

    const/4 v12, 0x6

    invoke-direct {v3, v10}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x3

    aput-object v3, v9, v2

    const/4 v12, 0x7

    aput-object p1, v9, v1

    const/4 v12, 0x5

    invoke-interface {v5, v6, v7, v8, v9}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x2

    invoke-virtual {v4}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v3

    const/4 v12, 0x1

    if-eq v3, v2, :cond_5

    const/4 v12, 0x0

    if-eq v3, v1, :cond_4

    const/4 v12, 0x1

    goto :goto_2

    :cond_4
    const/4 v12, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    const/4 v12, 0x0

    new-instance v2, Ljava/lang/Integer;

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v3

    const/4 v12, 0x1

    invoke-direct {v2, v3}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x7

    invoke-virtual {v1, v2, p1}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v12, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v2

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v12, 0x6

    check-cast v3, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v12, 0x7

    invoke-interface {v1, v2, v3}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->put(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttPersistable;)V

    const/4 v12, 0x7

    goto :goto_2

    :cond_5
    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    const/4 v12, 0x7

    new-instance v2, Ljava/lang/Integer;

    const/4 v12, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v3

    const/4 v12, 0x4

    invoke-direct {v2, v3}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x5

    invoke-virtual {v1, v2, p1}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v12, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v2

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v12, 0x7

    check-cast v3, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v12, 0x6

    invoke-interface {v1, v2, v3}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->put(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttPersistable;)V

    :goto_2
    const/4 v12, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v12, 0x6

    invoke-virtual {v1, p2, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->saveToken(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    const/4 v12, 0x0

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v12, 0x0

    invoke-virtual {p2, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    const/4 v12, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    const/4 v12, 0x0

    monitor-exit v0

    const/4 v12, 0x6

    goto/16 :goto_4

    :cond_6
    const/4 v12, 0x0

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v12, 0x2

    const-string/jumbo p2, "nttlaCepmet"

    const-string/jumbo p2, "tltmteaCnie"

    const-string p2, "elaitteSqtC"

    const-string p2, "ClientState"

    const/4 v12, 0x6

    const-string v1, "dsen"

    const-string/jumbo v1, "snde"

    const-string v1, "esdn"

    const-string/jumbo v1, "send"

    const/4 v12, 0x3

    const-string v5, "136"

    const-string v5, "136"

    const-string v5, "163"

    const-string v5, "613"

    const/4 v12, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v12, 0x2

    new-instance v6, Ljava/lang/Integer;

    const/4 v12, 0x0

    invoke-direct {v6, v4}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x0

    aput-object v6, v2, v3

    const/4 v12, 0x7

    invoke-interface {p1, p2, v1, v5, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x1

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v12, 0x0

    const/16 p2, 0x7dca

    invoke-direct {p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    throw p1

    :catchall_1
    move-exception p1

    const/4 v12, 0x5

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    throw p1

    :cond_7
    const/4 v12, 0x3

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v12, 0x6

    const-string/jumbo v4, "itsSaltCnee"

    const-string v4, "CtnloeaSeti"

    const-string/jumbo v4, "itlmaetntSC"

    const-string v4, "ClientState"

    const-string v5, "edsn"

    const-string v5, "dens"

    const-string/jumbo v5, "sned"

    const-string/jumbo v5, "send"

    const/4 v12, 0x6

    const-string v6, "165"

    const-string v6, "561"

    const-string v6, "615"

    const-string v6, "615"

    const/4 v12, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v12, 0x6

    new-instance v7, Ljava/lang/Integer;

    const/4 v12, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v8

    const/4 v12, 0x0

    invoke-direct {v7, v8}, Ljava/lang/Integer;-><init>(I)V

    aput-object v7, v1, v3

    const/4 v12, 0x0

    aput-object p1, v1, v2

    const/4 v12, 0x2

    invoke-interface {v0, v4, v5, v6, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x4

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;

    const/4 v12, 0x0

    if-eqz v0, :cond_8

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v12, 0x4

    monitor-enter v0

    :try_start_2
    const/4 v12, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v12, 0x4

    invoke-virtual {v1, p2, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->saveToken(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    const/4 v12, 0x6

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v12, 0x5

    invoke-virtual {p2, p1, v3}, Ljava/util/Vector;->insertElementAt(Ljava/lang/Object;I)V

    const/4 v12, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v12, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    const/4 v12, 0x0

    monitor-exit v0

    const/4 v12, 0x6

    goto :goto_4

    :catchall_2
    move-exception p1

    const/4 v12, 0x0

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v12, 0x5

    throw p1

    :cond_8
    const/4 v12, 0x6

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPingReq;

    const/4 v12, 0x6

    if-eqz v0, :cond_9

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pingCommand:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v12, 0x0

    goto :goto_3

    :cond_9
    const/4 v12, 0x6

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;

    const/4 v12, 0x5

    if-eqz v0, :cond_a

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    const/4 v12, 0x2

    new-instance v1, Ljava/lang/Integer;

    const/4 v12, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v2

    const/4 v12, 0x6

    invoke-direct {v1, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x5

    invoke-virtual {v0, v1, p1}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v12, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendConfirmPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v12, 0x5

    check-cast v2, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;

    const/4 v12, 0x1

    invoke-interface {v0, v1, v2}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->put(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttPersistable;)V

    const/4 v12, 0x4

    goto :goto_3

    :cond_a
    const/4 v12, 0x1

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;

    const/4 v12, 0x5

    if-eqz v0, :cond_b

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v12, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getReceivedPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x7

    invoke-interface {v0, v1}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V

    :cond_b
    :goto_3
    const/4 v12, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v12, 0x0

    monitor-enter v0

    :try_start_3
    const/4 v12, 0x5

    instance-of v1, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;

    const/4 v12, 0x2

    if-nez v1, :cond_c

    const/4 v12, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v12, 0x0

    invoke-virtual {v1, p2, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->saveToken(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    :cond_c
    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingFlows:Ljava/util/Vector;

    const/4 v12, 0x4

    invoke-virtual {p2, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    const/4 v12, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v12, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    const/4 v12, 0x5

    monitor-exit v0

    :goto_4
    const/4 v12, 0x1

    return-void

    :catchall_3
    move-exception p1

    const/4 v12, 0x0

    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    const/4 v12, 0x3

    throw p1
.end method

.method protected setCleanSession(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->cleanSession:Z

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public setKeepAliveInterval(J)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->keepAlive:J

    const/4 v1, 0x2

    const/4 v0, 0x6

    return-void
.end method

.method protected setKeepAliveSecs(J)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x3

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    mul-long/2addr p1, v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-wide p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->keepAlive:J

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method protected setMaxInflight(I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->maxInflight:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance p1, Ljava/util/Vector;

    const/4 v1, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->maxInflight:I

    const/4 v2, 0x3

    invoke-direct {p1, v0}, Ljava/util/Vector;-><init>(I)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v2, 0x6

    return-void
.end method

.method public unPersistBufferedMessage(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string/jumbo v0, "rsusoreitfdsuebgnaeesBeM"

    const-string/jumbo v0, "tgeiebufunesrrdseMBaessf"

    const/4 v8, 0x1

    const-string v0, "eusgrbefeidBrnsfeautesMs"

    const-string/jumbo v0, "unPersistBufferedMessage"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const-string/jumbo v1, "ttneeuutaCS"

    const-string v1, "eSnttiutCea"

    const-string v1, "CtiSltapetn"

    const-string v1, "ClientState"

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const-string v3, "157"

    const-string v3, "751"

    const/4 v8, 0x5

    const-string v3, "751"

    const-string v3, "517"

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v4, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getKey()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/4 v6, 0x0

    const/4 v8, 0x3

    aput-object v5, v4, v6

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-interface {v2, v1, v0, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendBufferedPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-interface {v2, p1}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {v1, v0, p1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    return-void
.end method

.method protected undo(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->queueLock:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const-string/jumbo v2, "tSaCielnqtp"

    const-string/jumbo v2, "naSClttpeit"

    const/4 v10, 0x2

    const-string/jumbo v2, "tistlSeeanC"

    const-string v2, "ClientState"

    const/4 v10, 0x4

    const/4 v9, 0x7

    const-string v3, "duon"

    const-string v3, "doun"

    const/4 v10, 0x1

    const-string/jumbo v3, "ound"

    const-string/jumbo v3, "undo"

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string v4, "186"

    const-string v4, "618"

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/4 v5, 0x2

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    new-instance v6, Ljava/lang/Integer;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v7

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-direct {v6, v7}, Ljava/lang/Integer;-><init>(I)V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    const/4 v7, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    aput-object v6, v5, v7

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    new-instance v6, Ljava/lang/Integer;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v8

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v8}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v8

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-direct {v6, v8}, Ljava/lang/Integer;-><init>(I)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 v8, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    aput-object v6, v5, v8

    const/4 v10, 0x0

    invoke-interface {v1, v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v1

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-ne v1, v8, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS1:Ljava/util/Hashtable;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    new-instance v2, Ljava/lang/Integer;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-direct {v2, v3}, Ljava/lang/Integer;-><init>(I)V

    const/4 v10, 0x6

    invoke-virtual {v1, v2}, Ljava/util/Hashtable;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    goto :goto_0

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->outboundQoS2:Ljava/util/Hashtable;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    new-instance v2, Ljava/lang/Integer;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v3

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-direct {v2, v3}, Ljava/lang/Integer;-><init>(I)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v1, v2}, Ljava/util/Hashtable;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->pendingMessages:Ljava/util/Vector;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v1, p1}, Ljava/util/Vector;->removeElement(Ljava/lang/Object;)Z

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getSendPersistenceKey(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-interface {v1, v2}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->remove(Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {v1, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->removeToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x5

    if-lez v1, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-direct {p0, v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->releaseMessageId(I)V

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {p1, v7}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->setMessageId(I)V

    :cond_1
    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->checkQuiesceLock()Z

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    monitor-exit v0

    const/4 v9, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    return-void

    :catchall_0
    move-exception p1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    throw p1
.end method
