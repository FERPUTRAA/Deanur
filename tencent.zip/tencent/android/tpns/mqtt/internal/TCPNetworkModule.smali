.class public Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "TCPNetworkModule"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private conTimeout:I

.field private factory:Ljavax/net/SocketFactory;

.field private host:Ljava/lang/String;

.field private port:I

.field protected socket:Ljava/net/Socket;

.field protected tempsocket:Ljava/net/Socket;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const-string v0, ".lslgoqtmin.ncdsanst.ctoplet.anminetron...nsttarc"

    const-string/jumbo v0, "l.selrcl.qsndttgt..n.i.aet.nnnsampimrttotconncoda"

    const/4 v3, 0x7

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x1

    const-string v1, "PuMmortNeCkeloTw"

    const/4 v3, 0x6

    const-string v1, "TCPNetworkModule"

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public constructor <init>(Ljavax/net/SocketFactory;Ljava/lang/String;ILjava/lang/String;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    invoke-interface {v0, p4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->setResourceName(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->factory:Ljavax/net/SocketFactory;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->host:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput p3, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->port:I

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method public getInputStream()Ljava/io/InputStream;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "S @mt o- ~@ @c~i@o~K.n  o~~@@@@~ oM~~r  @i1 o ~m@  ~@@v~@~ f us~@@l~b/~~ta@fbd/~@~y@~@i ~@l ~b~4"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/net/Socket;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public getOutputStream()Ljava/io/OutputStream;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/net/Socket;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public getServerURI()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v1, "t/:cop"

    const/4 v3, 0x4

    const-string/jumbo v1, "tcp://"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->host:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v1, ":"

    const-string v1, ":"

    const/4 v3, 0x6

    const-string v1, ":"

    const-string v1, ":"

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->port:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0
.end method

.method public setConnectTimeout(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->conTimeout:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public start()V
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v8, 0x7

    const/4 v7, 0x4

    new-instance v0, Ljava/net/InetSocketAddress;

    const/4 v7, 0x4

    move v8, v7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->host:Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->port:I

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-direct {v0, v1, v2}, Ljava/net/InetSocketAddress;-><init>(Ljava/lang/String;I)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->factory:Ljavax/net/SocketFactory;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    instance-of v2, v1, Ljavax/net/ssl/SSLSocketFactory;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-eqz v2, :cond_0

    const/4 v7, 0x1

    move v8, v7

    new-instance v1, Ljava/net/Socket;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-direct {v1}, Ljava/net/Socket;-><init>()V

    const/4 v8, 0x6

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->tempsocket:Ljava/net/Socket;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->conTimeout:I

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    mul-int/lit16 v2, v2, 0x3e8

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v1, v0, v2}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V

    const/4 v7, 0x1

    move v8, v7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->factory:Ljavax/net/SocketFactory;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    check-cast v0, Ljavax/net/ssl/SSLSocketFactory;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->tempsocket:Ljava/net/Socket;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->host:Ljava/lang/String;

    const/4 v7, 0x6

    move v8, v7

    iget v3, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->port:I

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    const/4 v4, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v0, v1, v2, v3, v4}, Ljavax/net/ssl/SSLSocketFactory;->createSocket(Ljava/net/Socket;Ljava/lang/String;IZ)Ljava/net/Socket;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    goto :goto_0

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v1}, Ljavax/net/SocketFactory;->createSocket()Ljava/net/Socket;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v8, 0x1

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->conTimeout:I

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    mul-int/lit16 v2, v2, 0x3e8

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v1, v0, v2}, Ljava/net/Socket;->connect(Ljava/net/SocketAddress;I)V
    :try_end_0
    .catch Ljava/net/ConnectException; {:try_start_0 .. :try_end_0} :catch_0

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    return-void

    :catch_0
    move-exception v0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string/jumbo v2, "tNwTooerdPuelkob"

    const-string v2, "NlTudbkrtwPeoMeo"

    const/4 v8, 0x5

    const-string v2, "CuPkMbooNdTlwetr"

    const-string v2, "TCPNetworkModule"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string/jumbo v3, "rustu"

    const-string/jumbo v3, "turst"

    const/4 v8, 0x0

    const-string/jumbo v3, "rtpta"

    const-string/jumbo v3, "start"

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string v4, "052"

    const-string v4, "205"

    const/4 v8, 0x5

    const-string v4, "250"

    const-string v4, "250"

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v5, 0x3

    const/4 v5, 0x0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-interface/range {v1 .. v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V

    const/4 v7, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/16 v2, 0x7d67

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-direct {v1, v2, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(ILjava/lang/Throwable;)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    throw v1
.end method

.method public stop()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/net/Socket;->shutdownInput()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/net/Socket;->close()V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->tempsocket:Ljava/net/Socket;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/net/Socket;->shutdownInput()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->tempsocket:Ljava/net/Socket;

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {v0}, Ljava/net/Socket;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method
