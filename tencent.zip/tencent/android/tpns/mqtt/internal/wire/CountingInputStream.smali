.class public Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;
.super Ljava/io/InputStream;


# instance fields
.field private counter:I

.field private in:Ljava/io/InputStream;


# direct methods
.method public constructor <init>(Ljava/io/InputStream;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;->in:Ljava/io/InputStream;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;->counter:I

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public getCounter()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;->counter:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    return v0
.end method

.method public read()I
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;->in:Ljava/io/InputStream;

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eq v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;->counter:I

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;->counter:I

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    return v0
.end method

.method public resetCounter()V
    .locals 3

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;->counter:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    return-void
.end method
