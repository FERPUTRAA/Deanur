.class public Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;
.super Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;


# static fields
.field public static final KEY:Ljava/lang/String; = "Con"


# instance fields
.field private returnCode:I

.field private sessionPresent:Z


# direct methods
.method public constructor <init>(B[B)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 p1, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;-><init>(B)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance p1, Ljava/io/ByteArrayInputStream;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p1, p2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    new-instance p2, Ljava/io/DataInputStream;

    const/4 v2, 0x4

    invoke-direct {p2, p1}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    invoke-virtual {p2}, Ljava/io/DataInputStream;->readUnsignedByte()I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    and-int/2addr p1, v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-ne p1, v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;->sessionPresent:Z

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p2}, Ljava/io/DataInputStream;->readUnsignedByte()I

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;->returnCode:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p2}, Ljava/io/InputStream;->close()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method


# virtual methods
.method public getKey()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "c@s~~l 4@@~ @@o~ @ n i~@ @l oo~vu@ m @~f/@ rbS oMb@@@da~ to@~ @1i~i ~. o~ -~~@/~f~~y~sK~@b@ ~~~t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    const-string v0, "Con"

    const-string/jumbo v0, "oCn"

    const/4 v2, 0x7

    const-string/jumbo v0, "noC"

    const-string v0, "Con"

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public getReturnCode()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;->returnCode:I

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public getSessionPresent()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;->sessionPresent:Z

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method protected getVariableHeader()[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-array v0, v0, [B

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method public isMessageIdRequired()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-super {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo v1, "spnm ets: ssseeoi"

    const-string/jumbo v1, "sos:e si ntensesp"

    const/4 v3, 0x1

    const-string v1, "i trosoe ssnse:pn"

    const-string v1, " session present:"

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;->sessionPresent:Z

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v1, "  nmub etcerro"

    const-string v1, "ee m o unrrtdc"

    const/4 v3, 0x4

    const-string v1, "edn :tucor e r"

    const-string v1, " return code: "

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;->returnCode:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0
.end method
