.class public Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;
.super Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPersistableWireMessage;


# instance fields
.field private encodedPayload:[B

.field private message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

.field private topicName:Ljava/lang/String;


# direct methods
.method public constructor <init>(B[B)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;,
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v0, 0x3

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPersistableWireMessage;-><init>(B)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->encodedPayload:[B

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttReceivedMessage;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttReceivedMessage;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    shr-int/lit8 v2, p1, 0x1

    const/4 v4, 0x3

    and-int/2addr v0, v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setQos(I)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    and-int/lit8 v0, p1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-ne v0, v1, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setRetained(Z)V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/16 v0, 0x8

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    and-int/2addr p1, v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-ne p1, v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    check-cast p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttReceivedMessage;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1, v1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttReceivedMessage;->setDuplicate(Z)V

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance p1, Ljava/io/ByteArrayInputStream;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {p1, p2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;-><init>(Ljava/io/InputStream;)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    new-instance p1, Ljava/io/DataInputStream;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {p1, v0}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->decodeUTF8(Ljava/io/DataInputStream;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->topicName:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-lez v1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUnsignedShort()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    iput v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->msgId:I

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    array-length p2, p2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;->getCounter()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    sub-int/2addr p2, v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-array p2, p2, [B

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1, p2}, Ljava/io/DataInputStream;->readFully([B)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/io/InputStream;->close()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v4, 0x6

    invoke-virtual {p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setPayload([B)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttMessage;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPersistableWireMessage;-><init>(B)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->encodedPayload:[B

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->topicName:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method protected static encodePayload(Lcom/tencent/android/tpns/mqtt/MqttMessage;)[B
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~ s~~K@ /@@ l~@ib@r~@~ b @~@@@~Sc v ~o  y ooMao~@~@~@~~ bf d/imo~l@o@~@   @1n@t4@-u~@~f.~ts ~i~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getPayload()[B

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method


# virtual methods
.method public getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v2, 0x1

    return-object v0
.end method

.method protected getMessageInfo()B
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    shl-int/lit8 v0, v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    int-to-byte v0, v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->isRetained()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    or-int/lit8 v0, v0, 0x1

    const/4 v2, 0x4

    or-int/2addr v3, v2

    int-to-byte v0, v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->isDuplicate()Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->duplicate:Z

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v1, :cond_2

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    or-int/lit8 v0, v0, 0x8

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    int-to-byte v0, v0

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return v0
.end method

.method public getPayload()[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->encodedPayload:[B

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->encodePayload(Lcom/tencent/android/tpns/mqtt/MqttMessage;)[B

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->encodedPayload:[B

    :cond_0
    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->encodedPayload:[B

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public getPayloadLength()I
    .locals 3

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getPayload()[B

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    array-length v0, v0
    :try_end_0
    .catch Lcom/tencent/android/tpns/mqtt/MqttException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    goto :goto_0

    :catch_0
    const/4 v1, 0x6

    move v2, v1

    const/4 v0, 0x1

    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public getTopicName()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->topicName:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method

.method protected getVariableHeader()[B
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v4, 0x3

    new-instance v1, Ljava/io/DataOutputStream;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v1, v0}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->topicName:Ljava/lang/String;

    invoke-virtual {p0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->encodeUTF8(Ljava/io/DataOutputStream;Ljava/lang/String;)V

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-lez v2, :cond_0

    const/4 v3, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->msgId:I

    invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->writeShort(I)V

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/io/DataOutputStream;->flush()V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object v0

    :catch_0
    move-exception v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    throw v1
.end method

.method public isMessageIdRequired()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x6

    move v1, v0

    const/4 v2, 0x6

    return v0
.end method

.method public setMessageId(I)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-super {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->setMessageId(I)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    instance-of v1, v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttReceivedMessage;

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    check-cast v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttReceivedMessage;

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttReceivedMessage;->setMessageId(I)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getPayload()[B

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    array-length v2, v1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/16 v3, 0x14

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {v2, v3}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/4 v3, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    move v4, v3

    move v4, v3

    const/4 v9, 0x0

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-ge v4, v2, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    aget-byte v5, v1, v4

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {v5}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-ne v6, v7, :cond_0

    const/4 v8, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string v7, "0"

    const-string v7, "0"

    const/4 v9, 0x0

    const-string v7, "0"

    const-string v7, "0"

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v0, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    add-int/lit8 v4, v4, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    goto :goto_0

    :cond_1
    :try_start_0
    const/4 v9, 0x1

    const/4 v8, 0x6

    new-instance v4, Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string v5, "8FUmT"

    const-string v5, "TUs8F"

    const/4 v9, 0x6

    const-string v5, "8-FTo"

    const-string v5, "UTF-8"

    const/4 v8, 0x1

    move v9, v8

    invoke-direct {v4, v1, v3, v2, v5}, Ljava/lang/String;-><init>([BIILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    goto :goto_1

    :catchall_0
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    const-string v4, "?"

    const-string v4, "?"

    const/4 v9, 0x7

    const-string v4, "?"

    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    new-instance v2, Ljava/lang/StringBuffer;

    const/4 v8, 0x5

    move v9, v8

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v8, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-super {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string v3, "bqo s"

    const-string v3, " qoms"

    const/4 v9, 0x4

    const-string v3, ":u qo"

    const-string v3, " qos:"

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v9, 0x3

    const/4 v8, 0x3

    invoke-virtual {v3}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v3

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v3}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-lez v3, :cond_2

    const/4 v9, 0x2

    const-string/jumbo v3, "pmIs dg"

    const-string v3, "Im gods"

    const/4 v9, 0x2

    const-string v3, "gqdI :m"

    const-string v3, " msgId:"

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x1

    const/4 v8, 0x0

    iget v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->msgId:I

    const/4 v8, 0x3

    move v9, v8

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string v3, "e:sdnirae "

    const-string v3, " retained:"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v3}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->isRetained()Z

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string/jumbo v3, "u pmd"

    const-string v3, " dup:"

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-boolean v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->duplicate:Z

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string v3, " topic:\""

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->topicName:Ljava/lang/String;

    const/4 v9, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string v3, "//"

    const-string v3, "//"

    const/4 v9, 0x7

    const-string v3, "//"

    const-string v3, "\""

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string v5, "[ lxo:yabp:aoh"

    const-string/jumbo v5, "loxe bh:ayp[a:"

    const/4 v9, 0x6

    const-string v5, "de:[ bpax:lyah"

    const-string v5, " payload:[hex:"

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v2, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/StringBuffer;)Ljava/lang/StringBuffer;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string/jumbo v0, "u//f:uut"

    const-string v0, "8/u:f/ut"

    const/4 v9, 0x7

    const-string/jumbo v0, "u/:f 8/p"

    const-string v0, " utf8:\""

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v2, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x3

    const-string/jumbo v0, "q:phnegl"

    const-string/jumbo v0, "telh:ngp"

    const/4 v9, 0x5

    const-string v0, " es:hnlt"

    const-string v0, " length:"

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    array-length v0, v1

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string v0, "]"

    const-string v0, "]"

    const/4 v9, 0x5

    const-string v0, "]"

    const-string v0, "]"

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    return-object v0
.end method
