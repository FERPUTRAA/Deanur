.class public Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;
.super Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;


# static fields
.field public static final KEY:Ljava/lang/String; = "Con"


# instance fields
.field private MqttVersion:I

.field private cleanSession:Z

.field private clientId:Ljava/lang/String;

.field private keepAliveInterval:I

.field private password:[C

.field private userName:Ljava/lang/String;

.field private willDestination:Ljava/lang/String;

.field private willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;


# direct methods
.method public constructor <init>(B[B)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v0, 0x4

    move v1, v0

    const/4 p1, 0x1

    move v1, p1

    const/4 v0, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;-><init>(B)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    new-instance p1, Ljava/io/ByteArrayInputStream;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p1, p2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    new-instance p2, Ljava/io/DataInputStream;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p2, p1}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-virtual {p0, p2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->decodeUTF8(Ljava/io/DataInputStream;)Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p2}, Ljava/io/DataInputStream;->readByte()B

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-virtual {p2}, Ljava/io/DataInputStream;->readByte()B

    const/4 v1, 0x7

    invoke-virtual {p2}, Ljava/io/DataInputStream;->readUnsignedShort()I

    move-result p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->keepAliveInterval:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    invoke-virtual {p0, p2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->decodeUTF8(Ljava/io/DataInputStream;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->clientId:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-virtual {p2}, Ljava/io/InputStream;->close()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;IZILjava/lang/String;[CLcom/tencent/android/tpns/mqtt/MqttMessage;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;-><init>(B)V

    const/4 v1, 0x3

    move v2, v1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->clientId:Ljava/lang/String;

    const/4 v2, 0x1

    iput-boolean p3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->cleanSession:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p4, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->keepAliveInterval:I

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object p5, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->userName:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object p6, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->password:[C

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p7, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object p8, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->willDestination:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput p2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->MqttVersion:I

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public getKey()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "s~s~ ~ ~@@on@lb@@fc /@ ~ @o@i~@@@~m@ad@ @~o@o  - ~b~~.i@  1~t  4Sb~~ t~o@@ ~/~ri~yv~@ u@~ Kf~lMo"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    const-string/jumbo v0, "oCn"

    const-string/jumbo v0, "noC"

    const/4 v2, 0x5

    const-string/jumbo v0, "nCo"

    const-string v0, "Con"

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method protected getMessageInfo()B
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public getPayload()[B
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v5, 0x6

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance v1, Ljava/io/DataOutputStream;

    const/4 v5, 0x7

    invoke-direct {v1, v0}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->clientId:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->encodeUTF8(Ljava/io/DataOutputStream;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz v2, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->willDestination:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->encodeUTF8(Ljava/io/DataOutputStream;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getPayload()[B

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    array-length v2, v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->writeShort(I)V

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getPayload()[B

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/io/OutputStream;->write([B)V

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->userName:Ljava/lang/String;

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    if-eqz v2, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->encodeUTF8(Ljava/io/DataOutputStream;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->password:[C

    const/4 v5, 0x2

    const/4 v4, 0x2

    if-eqz v2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    new-instance v3, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {v3, v2}, Ljava/lang/String;-><init>([C)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->encodeUTF8(Ljava/io/DataOutputStream;Ljava/lang/String;)V

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/io/DataOutputStream;->flush()V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object v0

    :catch_0
    move-exception v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v5, 0x0

    invoke-direct {v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    throw v1
.end method

.method protected getVariableHeader()[B
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v6, 0x6

    new-instance v1, Ljava/io/DataOutputStream;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-direct {v1, v0}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v5, 0x0

    xor-int/2addr v6, v5

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->MqttVersion:I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v3, 0x3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-ne v2, v3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo v2, "ssdmQM"

    const-string v2, "MQssId"

    const/4 v6, 0x0

    const-string/jumbo v2, "sdpQoI"

    const-string v2, "MQIsdp"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->encodeUTF8(Ljava/io/DataOutputStream;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v4, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-ne v2, v4, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string v2, "TQMT"

    const-string v2, "MTQT"

    const/4 v6, 0x0

    const-string v2, "TTMQ"

    const-string v2, "MQTT"

    const/4 v5, 0x2

    move v6, v5

    invoke-virtual {p0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->encodeUTF8(Ljava/io/DataOutputStream;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->MqttVersion:I

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->write(I)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-boolean v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->cleanSession:Z

    const/4 v6, 0x4

    const/4 v5, 0x2

    if-eqz v2, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v2, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    int-to-byte v2, v2

    const/4 v5, 0x7

    and-int/2addr v6, v5

    goto :goto_1

    :cond_2
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v2, 0x0

    :goto_1
    const/4 v6, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v4, :cond_3

    const/4 v6, 0x2

    or-int/lit8 v2, v2, 0x4

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    int-to-byte v2, v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v4}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    shl-int/lit8 v3, v4, 0x3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    or-int/2addr v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    int-to-byte v2, v2

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->willMessage:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v3}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->isRetained()Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v3, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    or-int/lit8 v2, v2, 0x20

    const/4 v6, 0x0

    int-to-byte v2, v2

    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->userName:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v3, :cond_4

    const/4 v6, 0x4

    or-int/lit16 v2, v2, 0x80

    const/4 v6, 0x2

    const/4 v5, 0x4

    int-to-byte v2, v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->password:[C

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v3, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    or-int/lit8 v2, v2, 0x40

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    int-to-byte v2, v2

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->write(I)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->keepAliveInterval:I

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->writeShort(I)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/io/DataOutputStream;->flush()V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-object v0

    :catch_0
    move-exception v0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    throw v1
.end method

.method public isCleanSession()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->cleanSession:Z

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method public isMessageIdRequired()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-super {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string/jumbo v0, "licItben  "

    const-string v0, " clientId "

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->clientId:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const-string v0, "erenmiukvvleAel taI"

    const-string v0, "elvmi eveleak nItAr"

    const/4 v3, 0x2

    const-string/jumbo v0, "trl v ApleekvineIea"

    const-string v0, " keepAliveInterval "

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;->keepAliveInterval:I

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-object v0
.end method
