.class public Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSuback;
.super Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;


# instance fields
.field private grantedQos:[I


# direct methods
.method public constructor <init>(B[B)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/16 p1, 0x9

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;-><init>(B)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance p1, Ljava/io/ByteArrayInputStream;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p1, p2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v0, Ljava/io/DataInputStream;

    const/4 v2, 0x4

    move v3, v2

    invoke-direct {v0, p1}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/io/DataInputStream;->readUnsignedShort()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->msgId:I

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    array-length p1, p2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    add-int/lit8 p1, p1, -0x2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    new-array p1, p1, [I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSuback;->grantedQos:[I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 p2, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eq p1, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSuback;->grantedQos:[I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    aput p1, v1, p2

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    add-int/lit8 p2, p2, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public getGrantedQos()[I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s  y~~lfoi@b-.@Mo4 s@mfu1cK  ~ a @@~~r@@@~@@ @@o~ @@  @ v~o@ /~~ibo ~~ ~~@lbo/ @n~@S~@t~id~~~t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSuback;->grantedQos:[I

    const/4 v1, 0x2

    move v2, v1

    return-object v0
.end method

.method protected getVariableHeader()[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-array v0, v0, [B

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-super {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v1, "snomr gat se"

    const-string v1, "dgsrteso a n"

    const/4 v4, 0x5

    const-string v1, " granted Qos"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSuback;->grantedQos:[I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    array-length v2, v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-ge v1, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string v2, " "

    const-string v2, " "

    const/4 v4, 0x4

    const-string v2, " "

    const-string v2, " "

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSuback;->grantedQos:[I

    const/4 v4, 0x4

    aget v2, v2, v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object v0
.end method
