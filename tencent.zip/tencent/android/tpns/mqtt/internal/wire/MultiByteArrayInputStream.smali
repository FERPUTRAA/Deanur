.class public Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;
.super Ljava/io/InputStream;


# instance fields
.field private bytesA:[B

.field private bytesB:[B

.field private lengthA:I

.field private lengthB:I

.field private offsetA:I

.field private offsetB:I

.field private pos:I


# direct methods
.method public constructor <init>([BII[BII)V
    .locals 3

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->pos:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->bytesA:[B

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object p4, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->bytesB:[B

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    iput p2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->offsetA:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    iput p5, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->offsetB:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput p3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->lengthA:I

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput p6, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->lengthB:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public read()I
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->pos:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->lengthA:I

    const/4 v5, 0x6

    if-ge v0, v1, :cond_0

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->bytesA:[B

    const/4 v4, 0x0

    or-int/2addr v5, v4

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->offsetA:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    add-int/2addr v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    aget-byte v1, v1, v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->lengthB:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    add-int/2addr v2, v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-ge v0, v2, :cond_2

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->bytesB:[B

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->offsetB:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    add-int/2addr v3, v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    sub-int/2addr v3, v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    aget-byte v1, v2, v3

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-gez v1, :cond_1

    const/4 v4, 0x2

    move v5, v4

    add-int/lit16 v1, v1, 0x100

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    add-int/lit8 v0, v0, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;->pos:I

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    return v1

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v0, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    return v0
.end method
