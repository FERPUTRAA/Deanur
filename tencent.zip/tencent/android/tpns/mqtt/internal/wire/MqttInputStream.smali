.class public Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;
.super Ljava/io/InputStream;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "MqttInputStream"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private bais:Ljava/io/ByteArrayOutputStream;

.field private clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

.field private in:Ljava/io/DataInputStream;

.field private packet:[B

.field private packetLen:J

.field private remLen:J


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const-string/jumbo v0, "pgsttt..nacioeliqencadrtmaesn.m.nr..dt.scntltloon"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x5

    const-string/jumbo v1, "uIsmSrtnmMtqtpe"

    const-string v1, "IpsSuettttqmrMn"

    const/4 v3, 0x6

    const-string v1, "MqttInputStream"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>(Lcom/tencent/android/tpns/mqtt/internal/ClientState;Ljava/io/InputStream;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/io/InputStream;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v1, 0x3

    new-instance p1, Ljava/io/DataInputStream;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p1, p2}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->in:Ljava/io/DataInputStream;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    new-instance p1, Ljava/io/ByteArrayOutputStream;

    const/4 v1, 0x4

    invoke-direct {p1}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->bais:Ljava/io/ByteArrayOutputStream;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    const-wide/16 p1, -0x1

    const-wide/16 p1, -0x1

    const/4 v1, 0x0

    const-wide/16 p1, -0x1

    const-wide/16 p1, -0x1

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-wide p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->remLen:J

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-void
.end method

.method private readFully()V
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "i@ ~o.t ~~@/~ - o~d@K@iMv ~ @@~y 1fl~ ~/ @~@@S@@onoo@oa@lb@  t @ @i~~4m~~~f@~~~~sob~    @bru@~c~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->bais:Ljava/io/ByteArrayOutputStream;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->packetLen:J

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    long-to-int v3, v1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    add-int/2addr v0, v3

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    iget-wide v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->remLen:J

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    sub-long/2addr v3, v1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    long-to-int v1, v3

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-ltz v1, :cond_2

    const/4 v8, 0x1

    const/4 v2, 0x0

    const/4 v8, 0x6

    move v7, v2

    :goto_0
    const/4 v8, 0x2

    if-ge v2, v1, :cond_1

    :try_start_0
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->in:Ljava/io/DataInputStream;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->packet:[B

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    add-int v5, v0, v2

    const/4 v8, 0x2

    const/4 v7, 0x3

    sub-int v6, v1, v2

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v3, v4, v5, v6}, Ljava/io/DataInputStream;->read([BII)I

    move-result v3
    :try_end_0
    .catch Ljava/net/SocketTimeoutException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x0

    const/4 v7, 0x2

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v4, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifyReceivedBytes(I)V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-ltz v3, :cond_0

    const/4 v8, 0x0

    add-int/2addr v2, v3

    const/4 v7, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    goto :goto_0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance v0, Ljava/io/EOFException;

    const/4 v8, 0x7

    invoke-direct {v0}, Ljava/io/EOFException;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    throw v0

    :catch_0
    move-exception v0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-wide v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->packetLen:J

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x6

    int-to-long v1, v2

    const/4 v8, 0x3

    add-long/2addr v3, v1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    iput-wide v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->packetLen:J

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    throw v0

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    return-void

    :cond_2
    const/4 v7, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    new-instance v0, Ljava/lang/IndexOutOfBoundsException;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {v0}, Ljava/lang/IndexOutOfBoundsException;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x2

    throw v0
.end method


# virtual methods
.method public available()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->in:Ljava/io/DataInputStream;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/io/InputStream;->available()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public close()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->in:Ljava/io/DataInputStream;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/io/InputStream;->close()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public read()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->in:Ljava/io/DataInputStream;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public readMqttWireMessage()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;
    .locals 12
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x2

    const-string v0, "MgrWab-oramtq neetasdctie se"

    const-string v0, " eqmo-gtiersnrtWM eatcadiaes"

    const/4 v11, 0x4

    const-string v0, "eagMMiueWatr itatssceeqnr -o"

    const-string v0, "action - readMqttWireMessage"

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    const-string/jumbo v1, "tnIquteprpatomS"

    const-string v1, "SItponmtrtaqeuM"

    const/4 v11, 0x2

    const-string v1, "atrnuMqtqemtSIt"

    const-string v1, "MqttInputStream"

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-static {v1, v0}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v10, 0x4

    const/4 v11, 0x5

    iget-wide v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->remLen:J

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x5

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x0

    cmp-long v2, v2, v4

    const/4 v10, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    const/4 v3, 0x1

    if-gez v2, :cond_1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->bais:Ljava/io/ByteArrayOutputStream;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->reset()V

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->in:Ljava/io/DataInputStream;

    const/4 v11, 0x3

    const/4 v10, 0x4

    invoke-virtual {v2}, Ljava/io/DataInputStream;->readByte()B

    move-result v2

    const/4 v11, 0x6

    const/4 v10, 0x2

    iget-object v6, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v6, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifyReceivedBytes(I)V

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    ushr-int/lit8 v6, v2, 0x4

    const/4 v11, 0x3

    and-int/lit8 v6, v6, 0xf

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    int-to-byte v6, v6

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x1

    if-lt v6, v3, :cond_0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x2

    const/16 v7, 0xe

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    if-gt v6, v7, :cond_0

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x4

    iget-object v6, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->in:Ljava/io/DataInputStream;

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-static {v6}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->readMBI(Ljava/io/DataInputStream;)Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;

    move-result-object v6

    const/4 v11, 0x0

    const/4 v10, 0x5

    invoke-virtual {v6}, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;->getValue()J

    move-result-wide v6

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x2

    iput-wide v6, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->remLen:J

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x1

    iget-object v6, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->bais:Ljava/io/ByteArrayOutputStream;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v6, v2}, Ljava/io/ByteArrayOutputStream;->write(I)V

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->bais:Ljava/io/ByteArrayOutputStream;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    iget-wide v6, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->remLen:J

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-static {v6, v7}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->encodeMBI(J)[B

    move-result-object v6

    const/4 v11, 0x6

    const/4 v10, 0x4

    invoke-virtual {v2, v6}, Ljava/io/OutputStream;->write([B)V

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->bais:Ljava/io/ByteArrayOutputStream;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->size()I

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x5

    int-to-long v6, v2

    const/4 v10, 0x4

    move v11, v10

    iget-wide v8, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->remLen:J

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    add-long/2addr v6, v8

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x3

    long-to-int v2, v6

    const/4 v11, 0x4

    new-array v2, v2, [B

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x3

    iput-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->packet:[B

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    iput-wide v4, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->packetLen:J

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x7

    goto :goto_0

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    const/16 v1, 0x7d6c

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-static {v1}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v1

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    throw v1

    :cond_1
    :goto_0
    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x1

    iget-wide v6, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->remLen:J

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x6

    cmp-long v2, v6, v4

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-ltz v2, :cond_2

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->readFully()V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v11, 0x0

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v11, 0x2

    const/4 v10, 0x4

    iput-wide v4, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->remLen:J

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->bais:Ljava/io/ByteArrayOutputStream;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->packet:[B

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    array-length v5, v2

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    const/4 v6, 0x0

    const/4 v10, 0x6

    move v11, v10

    invoke-static {v2, v6, v4, v6, v5}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->packet:[B

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-static {v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->createWireMessage([B)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object v0

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const-string/jumbo v4, "tessqMgsabraeMWieed"

    const-string v4, "MtMeebiqaerersgWads"

    const/4 v11, 0x6

    const-string v4, "iWsmaeqaMMegertrtds"

    const-string/jumbo v4, "readMqttWireMessage"

    const/4 v11, 0x2

    const-string v5, "150"

    const-string v5, "510"

    const/4 v11, 0x2

    const-string v5, "501"

    const-string v5, "501"

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    aput-object v0, v3, v6

    const/4 v11, 0x6

    invoke-interface {v2, v1, v4, v5, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/net/SocketTimeoutException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    :cond_2
    const/4 v11, 0x1

    return-object v0
.end method
