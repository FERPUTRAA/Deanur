.class public Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;
.super Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;


# instance fields
.field private count:I

.field private names:[Ljava/lang/String;

.field private qos:[I


# direct methods
.method public constructor <init>(B[B)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/16 p1, 0x8

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;-><init>(B)V

    const/4 v3, 0x2

    move v4, v3

    new-instance p1, Ljava/io/ByteArrayInputStream;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p1, p2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    new-instance p2, Ljava/io/DataInputStream;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {p2, p1}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p2}, Ljava/io/DataInputStream;->readUnsignedShort()I

    move-result p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->msgId:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 p1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->count:I

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/16 v0, 0xa

    const/4 v4, 0x5

    const/4 v3, 0x7

    new-array v1, v0, [Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->names:[Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-array v0, v0, [I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->qos:[I

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    if-nez p1, :cond_0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->names:[Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->count:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0, p2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->decodeUTF8(Ljava/io/DataInputStream;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    aput-object v2, v0, v1

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->qos:[I

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->count:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    add-int/lit8 v2, v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->count:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p2}, Ljava/io/DataInputStream;->readByte()B

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    aput v2, v0, v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_0

    :catchall_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    const/4 p1, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-virtual {p2}, Ljava/io/InputStream;->close()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method

.method public constructor <init>([Ljava/lang/String;[I)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/16 v0, 0x8

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;-><init>(B)V

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->names:[Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->qos:[I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    array-length v0, p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    array-length v1, p2

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-ne v0, v1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    array-length p1, p1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->count:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 p1, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    array-length v0, p2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-ge p1, v0, :cond_0

    const/4 v3, 0x5

    aget v0, p2, p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->validateQos(I)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    add-int/lit8 p1, p1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v2, 0x3

    const/4 v2, 0x7

    throw p1
.end method


# virtual methods
.method protected getMessageInfo()B
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o@s ~tu~~fb~ af@@ @i~ @n@~@  @ ~d1o o S~~ci@l r/@y ~ vo/b@Ko~b4@@-@~ .@@tMli~@o@~ s~@  ~@~~~~~~m"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->duplicate:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/16 v0, 0x8

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    or-int/lit8 v0, v0, 0x2

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    int-to-byte v0, v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public getPayload()[B
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v6, 0x2

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v6, 0x3

    new-instance v1, Ljava/io/DataOutputStream;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {v1, v0}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->names:[Ljava/lang/String;

    const/4 v6, 0x5

    array-length v4, v3

    const/4 v6, 0x0

    if-ge v2, v4, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    aget-object v3, v3, v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->encodeUTF8(Ljava/io/DataOutputStream;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->qos:[I

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    aget v3, v3, v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v1, v3}, Ljava/io/DataOutputStream;->writeByte(I)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {v1}, Ljava/io/DataOutputStream;->flush()V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    return-object v0

    :catch_0
    move-exception v0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-direct {v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    throw v1
.end method

.method protected getVariableHeader()[B
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v1, Ljava/io/DataOutputStream;

    const/4 v3, 0x7

    move v4, v3

    invoke-direct {v1, v0}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->msgId:I

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->writeShort(I)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/io/DataOutputStream;->flush()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object v0

    :catch_0
    move-exception v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    throw v1
.end method

.method public isRetryable()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v6, 0x0

    invoke-super {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string v1, ":msmes[a"

    const-string/jumbo v1, "s[sma :e"

    const/4 v6, 0x6

    const-string v1, "[am o:en"

    const-string v1, " names:["

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    const/4 v1, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    move v2, v1

    move v2, v1

    const/4 v6, 0x7

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->count:I

    const/4 v5, 0x6

    move v6, v5

    const-string v4, ", "

    const-string v4, ", "

    const/4 v6, 0x2

    const-string v4, ", "

    const-string v4, ", "

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-ge v2, v3, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-lez v2, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v3, "//"

    const-string v3, "//"

    const/4 v6, 0x1

    const-string v3, "//"

    const-string v3, "\""

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->names:[Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    aget-object v4, v4, v2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    goto :goto_0

    :cond_1
    const/4 v6, 0x7

    const-string/jumbo v2, "o:[mqbs"

    const-string/jumbo v2, "os:mq[ "

    const/4 v6, 0x5

    const-string v2, "]: oq[u"

    const-string v2, "] qos:["

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->count:I

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-ge v1, v2, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-lez v1, :cond_2

    const/4 v6, 0x5

    invoke-virtual {v0, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_2
    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;->qos:[I

    const/4 v6, 0x5

    aget v2, v2, v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    goto :goto_1

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string v1, "]"

    const-string v1, "]"

    const/4 v6, 0x6

    const-string v1, "]"

    const-string v1, "]"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    return-object v0
.end method
