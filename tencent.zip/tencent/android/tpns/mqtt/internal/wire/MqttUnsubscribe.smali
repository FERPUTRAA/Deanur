.class public Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubscribe;
.super Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;


# instance fields
.field private count:I

.field private names:[Ljava/lang/String;


# direct methods
.method public constructor <init>(B[B)V
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/16 p1, 0xa

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;-><init>(B)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    new-instance v0, Ljava/io/ByteArrayInputStream;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v0, p2}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance p2, Ljava/io/DataInputStream;

    const/4 v4, 0x1

    invoke-direct {p2, v0}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p2}, Ljava/io/DataInputStream;->readUnsignedShort()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->msgId:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubscribe;->count:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    new-array p1, p1, [Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubscribe;->names:[Ljava/lang/String;

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez v0, :cond_0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubscribe;->names:[Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubscribe;->count:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0, p2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->decodeUTF8(Ljava/io/DataInputStream;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    aput-object v2, p1, v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :catchall_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p2}, Ljava/io/InputStream;->close()V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method

.method public constructor <init>([Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/16 v0, 0xa

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;-><init>(B)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubscribe;->names:[Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method protected getMessageInfo()B
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o@s~~~~ml al@@~~~bo @@/~f/~@.~@@o~b~u@~s@Mv  ~~o@d@t @t  -~~K~~f no@ @c 1oiy @@~@~@   i 4ib@S~ r"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->duplicate:Z

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/16 v0, 0x8

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    or-int/lit8 v0, v0, 0x2

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    int-to-byte v0, v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public getPayload()[B
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v5, 0x3

    and-int/2addr v6, v5

    new-instance v1, Ljava/io/DataOutputStream;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v1, v0}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubscribe;->names:[Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    array-length v4, v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-ge v2, v4, :cond_0

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    aget-object v3, v3, v2

    const/4 v5, 0x7

    shl-int/2addr v6, v5

    invoke-virtual {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->encodeUTF8(Ljava/io/DataOutputStream;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v1}, Ljava/io/DataOutputStream;->flush()V

    const/4 v6, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    return-object v0

    :catch_0
    move-exception v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    throw v1
.end method

.method protected getVariableHeader()[B
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v3, 0x1

    move v4, v3

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v1, Ljava/io/DataOutputStream;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v1, v0}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->msgId:I

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->writeShort(I)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/io/DataOutputStream;->flush()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v0

    :catch_0
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v4, 0x5

    throw v1
.end method

.method public isRetryable()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-super {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-string/jumbo v1, "sn[mmes "

    const-string v1, "[nssa em"

    const/4 v6, 0x7

    const-string v1, "as[no :m"

    const-string v1, " names:["

    const/4 v6, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubscribe;->count:I

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-ge v1, v2, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-lez v1, :cond_0

    const/4 v6, 0x7

    const-string v2, ", "

    const-string v2, ", "

    const/4 v6, 0x3

    const-string v2, ", "

    const-string v2, ", "

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v3, "//"

    const-string v3, "//"

    const/4 v6, 0x2

    const-string v3, "//"

    const-string v3, "\""

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubscribe;->names:[Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    aget-object v4, v4, v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const-string v1, "]"

    const-string v1, "]"

    const-string v1, "]"

    const-string v1, "]"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    return-object v0
.end method
