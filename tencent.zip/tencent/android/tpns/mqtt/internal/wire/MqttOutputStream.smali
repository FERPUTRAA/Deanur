.class public Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;
.super Ljava/io/OutputStream;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "MqttOutputStream"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

.field private out:Ljava/io/BufferedOutputStream;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string/jumbo v0, "piss.t.oceti.emancmdq..s.ltloantnnagltresodnnntrc"

    const-string v0, "etstipari.anocdt.cttnnnnclqtem.nlm.nrolgo..ase.sd"

    const/4 v3, 0x5

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v2, 0x5

    move v3, v2

    const-string/jumbo v1, "tmmmutttSOeMaqup"

    const-string/jumbo v1, "pmOmttuSuqttMear"

    const/4 v3, 0x4

    const-string v1, "SutmoeqttOutptar"

    const-string v1, "MqttOutputStream"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>(Lcom/tencent/android/tpns/mqtt/internal/ClientState;Ljava/io/OutputStream;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/io/OutputStream;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    new-instance p1, Ljava/io/BufferedOutputStream;

    const/4 v1, 0x2

    invoke-direct {p1, p2}, Ljava/io/BufferedOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->out:Ljava/io/BufferedOutputStream;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public close()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o/ ~~by.u~~~@ ~~ln K @ivS@~~~bfl @@4~@s~ oo-o~@i/~@@@@d @1 @~@ r~@m @f b@ ~bic ~@~ @to o a@~~t ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->out:Ljava/io/BufferedOutputStream;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/io/OutputStream;->close()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method

.method public flush()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->out:Ljava/io/BufferedOutputStream;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/io/BufferedOutputStream;->flush()V

    const/4 v2, 0x3

    return-void
.end method

.method public write(I)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->out:Ljava/io/BufferedOutputStream;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Ljava/io/BufferedOutputStream;->write(I)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public write(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getHeader()[B

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getPayload()[B

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->out:Ljava/io/BufferedOutputStream;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    array-length v3, v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v2, v0, v4, v3}, Ljava/io/BufferedOutputStream;->write([BII)V

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    array-length v0, v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifySentBytes(I)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    move v0, v4

    move v0, v4

    const/4 v6, 0x3

    move v0, v4

    move v0, v4

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    array-length v2, v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    if-ge v0, v2, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    array-length v2, v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    sub-int/2addr v2, v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/16 v3, 0x400

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v3, v2}, Ljava/lang/Math;->min(II)I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->out:Ljava/io/BufferedOutputStream;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v3, v1, v0, v2}, Ljava/io/BufferedOutputStream;->write([BII)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    add-int/lit16 v0, v0, 0x400

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v6, 0x0

    invoke-virtual {v3, v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifySentBytes(I)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    aput-object p1, v1, v4

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string/jumbo p1, "tOtetpuratMtuuom"

    const-string p1, "SutaoepttmOMutrt"

    const-string/jumbo p1, "ttptOetprMauumqt"

    const-string p1, "MqttOutputStream"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo v2, "wreqi"

    const-string v2, "biewr"

    const/4 v6, 0x6

    const-string/jumbo v2, "rtsiw"

    const-string/jumbo v2, "write"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string v3, "259"

    const-string v3, "529"

    const-string v3, "952"

    const-string v3, "529"

    invoke-interface {v0, p1, v2, v3, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-void
.end method

.method public write([B)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->out:Ljava/io/BufferedOutputStream;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Ljava/io/OutputStream;->write([B)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v2, 0x2

    const/4 v1, 0x3

    array-length p1, p1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifySentBytes(I)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public write([BII)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->out:Ljava/io/BufferedOutputStream;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0, p1, p2, p3}, Ljava/io/BufferedOutputStream;->write([BII)V

    const/4 v1, 0x4

    move v2, v1

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p1, p3}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifySentBytes(I)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method
