.class public abstract Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;
.super Ljava/lang/Object;


# static fields
.field public static final MESSAGE_TYPE_CONNACK:B = 0x2t

.field public static final MESSAGE_TYPE_CONNECT:B = 0x1t

.field public static final MESSAGE_TYPE_DISCONNECT:B = 0xet

.field public static final MESSAGE_TYPE_PINGREQ:B = 0xct

.field public static final MESSAGE_TYPE_PINGRESP:B = 0xdt

.field public static final MESSAGE_TYPE_PUBACK:B = 0x4t

.field public static final MESSAGE_TYPE_PUBCOMP:B = 0x7t

.field public static final MESSAGE_TYPE_PUBLISH:B = 0x3t

.field public static final MESSAGE_TYPE_PUBREC:B = 0x5t

.field public static final MESSAGE_TYPE_PUBREL:B = 0x6t

.field public static final MESSAGE_TYPE_SUBACK:B = 0x9t

.field public static final MESSAGE_TYPE_SUBSCRIBE:B = 0x8t

.field public static final MESSAGE_TYPE_UNSUBACK:B = 0xbt

.field public static final MESSAGE_TYPE_UNSUBSCRIBE:B = 0xat

.field private static final PACKET_NAMES:[Ljava/lang/String;

.field protected static final STRING_ENCODING:Ljava/lang/String; = "UTF-8"


# instance fields
.field protected duplicate:Z

.field protected msgId:I

.field private type:B


# direct methods
.method static constructor <clinit>()V
    .locals 15

    const-string v0, "ersdrevs"

    const-string v0, "desrrvee"

    const-string v0, "dermeesv"

    const-string/jumbo v0, "reserved"

    const-string v1, "CCmToEN"

    const-string v1, "CTNmOEC"

    const-string v1, "CNNTEbO"

    const-string v1, "CONNECT"

    const-string v2, "NOCoAKu"

    const-string v2, "CKONoAN"

    const-string/jumbo v2, "pCOANKN"

    const-string v2, "CONNACK"

    const-string v3, "UqBHSLb"

    const-string v3, "LUPHSbB"

    const-string v3, "IBsUHPS"

    const-string v3, "PUBLISH"

    const-string v4, "BAKmCP"

    const-string/jumbo v4, "uBACKP"

    const-string v4, "AKCPoU"

    const-string v4, "PUBACK"

    const-string v5, "EpCRUb"

    const-string v5, "UpERCB"

    const-string/jumbo v5, "uUPBCE"

    const-string v5, "PUBREC"

    const-string v6, "EpBULP"

    const-string v6, "BPqLEU"

    const-string v6, "URqEBP"

    const-string v6, "PUBREL"

    const-string v7, "PPsUMOs"

    const-string v7, "CUsMPOP"

    const-string v7, "COPmBPM"

    const-string v7, "PUBCOMP"

    const-string v8, "CEBRoBmSU"

    const-string v8, "BUEmBCISR"

    const-string v8, "BEICSbUSR"

    const-string v8, "SUBSCRIBE"

    const-string/jumbo v9, "uUBAoS"

    const-string v9, "CBSAoU"

    const-string v9, "KpUBCA"

    const-string v9, "SUBACK"

    const-string v10, "NCUSBbBUREI"

    const-string v10, "SUCBUBREqIN"

    const-string v10, "UNSUBSCRIBE"

    const-string v11, "ACsSKNUB"

    const-string v11, "UNSUBACK"

    const-string/jumbo v12, "uPEmNGI"

    const-string v12, "IQGPNEu"

    const-string v12, "REQPoGN"

    const-string v12, "PINGREQ"

    const-string v13, "SENPPbpR"

    const-string v13, "RPSNPGEp"

    const-string v13, "EPRNSGuP"

    const-string v13, "PINGRESP"

    const-string v14, "TIEqCNSpNO"

    const-string v14, "EODNISTCqN"

    const-string v14, "INDTOSCEqC"

    const-string v14, "DISCONNECT"

    filled-new-array/range {v0 .. v14}, [Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->PACKET_NAMES:[Ljava/lang/String;

    return-void
.end method

.method public constructor <init>(B)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->duplicate:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-byte p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->type:B

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->msgId:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public static createWireMessage(Lcom/tencent/android/tpns/mqtt/MqttPersistable;)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x2

    invoke-interface {p0}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getPayloadBytes()[B

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-nez v0, :cond_0

    const/4 v8, 0x5

    move v9, v8

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    new-array v0, v0, [B

    :cond_0
    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;

    const/4 v9, 0x7

    const/4 v8, 0x0

    invoke-interface {p0}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getHeaderBytes()[B

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-interface {p0}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getHeaderOffset()I

    move-result v3

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-interface {p0}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getHeaderLength()I

    move-result v4

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-interface {p0}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getPayloadOffset()I

    move-result v6

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-interface {p0}, Lcom/tencent/android/tpns/mqtt/MqttPersistable;->getPayloadLength()I

    move-result v7

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v9, 0x5

    const/4 v8, 0x1

    invoke-direct/range {v1 .. v7}, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteArrayInputStream;-><init>([BII[BII)V

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->createWireMessage(Ljava/io/InputStream;)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    return-object p0
.end method

.method private static createWireMessage(Ljava/io/InputStream;)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-direct {v0, p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;-><init>(Ljava/io/InputStream;)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    new-instance p0, Ljava/io/DataInputStream;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-direct {p0, v0}, Ljava/io/DataInputStream;-><init>(Ljava/io/InputStream;)V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {p0}, Ljava/io/DataInputStream;->readUnsignedByte()I

    move-result v1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    shr-int/lit8 v2, v1, 0x4

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    int-to-byte v2, v2

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    and-int/lit8 v1, v1, 0xf

    const/4 v9, 0x7

    shl-int/2addr v10, v9

    int-to-byte v1, v1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->readMBI(Ljava/io/DataInputStream;)Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;->getValue()J

    move-result-wide v3

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;->getCounter()I

    move-result v5

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    int-to-long v5, v5

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    add-long/2addr v5, v3

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/CountingInputStream;->getCounter()I

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    int-to-long v3, v0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    sub-long/2addr v5, v3

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 v0, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x3

    new-array v3, v0, [B

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x3

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    cmp-long v4, v5, v7

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-lez v4, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    long-to-int v3, v5

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    new-array v4, v3, [B

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {p0, v4, v0, v3}, Ljava/io/DataInputStream;->readFully([BII)V

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 p0, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-ne v2, p0, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x1

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;

    const/4 v10, 0x2

    const/4 v9, 0x1

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;-><init>(B[B)V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    goto/16 :goto_0

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    const/4 p0, 0x3

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-ne v2, p0, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;-><init>(B[B)V

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    goto/16 :goto_0

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 p0, 0x4

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-ne v2, p0, :cond_3

    const/4 v10, 0x0

    const/4 v9, 0x2

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubAck;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubAck;-><init>(B[B)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x5

    goto/16 :goto_0

    :cond_3
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    const/4 p0, 0x7

    const/4 v9, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-ne v2, p0, :cond_4

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;-><init>(B[B)V

    const/4 v9, 0x0

    shr-int/2addr v10, v9

    goto/16 :goto_0

    :cond_4
    const/4 v9, 0x5

    const/4 v10, 0x0

    const/4 p0, 0x2

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-ne v2, p0, :cond_5

    const/4 v9, 0x4

    move v10, v9

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;-><init>(B[B)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    goto/16 :goto_0

    :cond_5
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    const/16 p0, 0xc

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-ne v2, p0, :cond_6

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPingReq;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPingReq;-><init>(B[B)V

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    goto/16 :goto_0

    :cond_6
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    const/16 p0, 0xd

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    if-ne v2, p0, :cond_7

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPingResp;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPingResp;-><init>(B[B)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    goto/16 :goto_0

    :cond_7
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/16 p0, 0x8

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-ne v2, p0, :cond_8

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;

    const/4 v10, 0x5

    const/4 v9, 0x4

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSubscribe;-><init>(B[B)V

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    goto/16 :goto_0

    :cond_8
    const/4 v10, 0x3

    const/4 v9, 0x2

    const/16 p0, 0x9

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    if-ne v2, p0, :cond_9

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSuback;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSuback;-><init>(B[B)V

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    goto :goto_0

    :cond_9
    const/4 v9, 0x1

    move v10, v9

    const/16 p0, 0xa

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    if-ne v2, p0, :cond_a

    const/4 v9, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubscribe;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubscribe;-><init>(B[B)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x6

    goto :goto_0

    :cond_a
    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/16 p0, 0xb

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-ne v2, p0, :cond_b

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubAck;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttUnsubAck;-><init>(B[B)V

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto :goto_0

    :cond_b
    const/4 v9, 0x6

    move v10, v9

    const/4 p0, 0x3

    const/4 p0, 0x6

    const/4 v10, 0x0

    if-ne v2, p0, :cond_c

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x1

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;

    const/4 v10, 0x7

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRel;-><init>(B[B)V

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    goto :goto_0

    :cond_c
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    const/4 v0, 0x5

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    if-ne v2, v0, :cond_d

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRec;

    const/4 v10, 0x0

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRec;-><init>(B[B)V

    const/4 v9, 0x3

    or-int/2addr v10, v9

    goto :goto_0

    :cond_d
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/16 v0, 0xe

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-ne v2, v0, :cond_e

    const/4 v10, 0x2

    const/4 v9, 0x6

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttDisconnect;

    const/4 v10, 0x4

    invoke-direct {p0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttDisconnect;-><init>(B[B)V

    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    return-object p0

    :cond_e
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object p0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x4

    throw p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    move-exception p0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-direct {v0, p0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x4

    throw v0
.end method

.method public static createWireMessage([B)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v1, 0x4

    new-instance v0, Ljava/io/ByteArrayInputStream;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {v0, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->createWireMessage(Ljava/io/InputStream;)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object p0
.end method

.method protected static encodeMBI(J)[B
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/4 v1, 0x0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-wide/16 v2, 0x80

    const-wide/16 v2, 0x80

    const-wide/16 v2, 0x80

    const/4 v6, 0x3

    move v7, v6

    rem-long v4, p0, v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    long-to-int v4, v4

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    int-to-byte v4, v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    div-long/2addr p0, v2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    cmp-long v2, p0, v2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-lez v2, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    or-int/lit16 v3, v4, 0x80

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    int-to-byte v4, v3

    :cond_1
    const/4 v6, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0, v4}, Ljava/io/ByteArrayOutputStream;->write(I)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-lez v2, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/4 v2, 0x4

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-lt v1, v2, :cond_0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    return-object p0
.end method

.method protected static readMBI(Ljava/io/DataInputStream;)Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v9, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/4 v2, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v8, 0x0

    or-int/2addr v9, v8

    move v4, v2

    const/4 v9, 0x6

    move v4, v2

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {p0}, Ljava/io/DataInputStream;->readByte()B

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    add-int/2addr v3, v2

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    and-int/lit8 v6, v5, 0x7f

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    mul-int/2addr v6, v4

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    int-to-long v6, v6

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    add-long/2addr v0, v6

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    mul-int/lit16 v4, v4, 0x80

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    and-int/lit16 v5, v5, 0x80

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-nez v5, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    new-instance p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-direct {p0, v0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;-><init>(JI)V

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    return-object p0
.end method


# virtual methods
.method protected decodeUTF8(Ljava/io/DataInputStream;)Ljava/lang/String;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/io/DataInputStream;->readUnsignedShort()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-array v0, v0, [B

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Ljava/io/DataInputStream;->readFully([B)V

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string v1, "FTssU"

    const-string v1, "FTs8U"

    const/4 v3, 0x4

    const-string v1, "TU8m-"

    const-string v1, "UTF-8"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p1, v0, v1}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p1

    :catch_0
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v0, p1}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    throw v0
.end method

.method protected encodeMessageId()[B
    .locals 5
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance v1, Ljava/io/DataOutputStream;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v1, v0}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v4, 0x3

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->msgId:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/io/DataOutputStream;->writeShort(I)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/io/DataOutputStream;->flush()V

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v0

    :catch_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    throw v1
.end method

.method protected encodeUTF8(Ljava/io/DataOutputStream;Ljava/lang/String;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string v0, "-m8To"

    const-string v0, "U-Tm8"

    const-string v0, "b8-TF"

    const-string v0, "UTF-8"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p2, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    array-length v0, p2

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    ushr-int/lit8 v0, v0, 0x8

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    and-int/lit16 v0, v0, 0xff

    const/4 v3, 0x0

    const/4 v2, 0x2

    int-to-byte v0, v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    array-length v1, p2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    ushr-int/lit8 v1, v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    and-int/lit16 v1, v1, 0xff

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    int-to-byte v1, v1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, v0}, Ljava/io/DataOutputStream;->write(I)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1, v1}, Ljava/io/DataOutputStream;->write(I)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1, p2}, Ljava/io/OutputStream;->write([B)V
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :catch_0
    move-exception p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance p2, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p2, p1}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    throw p2

    :catch_1
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance p2, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p2, p1}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    throw p2
.end method

.method public getHeader()[B
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getType()B

    move-result v0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    and-int/lit8 v0, v0, 0xf

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    shl-int/lit8 v0, v0, 0x4

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageInfo()B

    move-result v1

    const/4 v8, 0x5

    const/4 v7, 0x2

    and-int/lit8 v1, v1, 0xf

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    xor-int/2addr v0, v1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getVariableHeader()[B

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    array-length v2, v1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getPayload()[B

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    array-length v3, v3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    add-int/2addr v2, v3

    new-instance v3, Ljava/io/ByteArrayOutputStream;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-direct {v3}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v8, 0x2

    new-instance v4, Ljava/io/DataOutputStream;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-direct {v4, v3}, Ljava/io/DataOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v4, v0}, Ljava/io/DataOutputStream;->writeByte(I)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    int-to-long v5, v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v5, v6}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->encodeMBI(J)[B

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v4, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v4, v1}, Ljava/io/OutputStream;->write([B)V

    const/4 v8, 0x7

    invoke-virtual {v4}, Ljava/io/DataOutputStream;->flush()V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v3}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    return-object v0

    :catch_0
    move-exception v0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-direct {v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    throw v1
.end method

.method public getKey()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/Integer;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Ljava/lang/Integer;-><init>(I)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0
.end method

.method public getMessageId()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->msgId:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method protected abstract getMessageInfo()B
.end method

.method public getPayload()[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v0, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-array v0, v0, [B

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public getType()B
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-byte v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->type:B

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    return v0
.end method

.method protected abstract getVariableHeader()[B
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation
.end method

.method public isMessageIdRequired()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public isRetryable()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method

.method public setDuplicate(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->duplicate:Z

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public setMessageId(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->msgId:I

    const/4 v0, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->PACKET_NAMES:[Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->type:B

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    aget-object v0, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object v0
.end method
