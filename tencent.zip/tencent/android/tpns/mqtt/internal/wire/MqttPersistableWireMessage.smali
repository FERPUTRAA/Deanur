.class public abstract Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPersistableWireMessage;
.super Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/MqttPersistable;


# direct methods
.method public constructor <init>(B)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;-><init>(B)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public getHeaderBytes()[B
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@lsrt~ ~@ ~   c~b~S@~sMa o~@l@ @ .u @oo@~@/i~dt@-i/ @~ ~@~@n~mb1fi ~ y~K@ ~ovo @~f@~~~o~@4@b@~ @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getHeader()[B

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;-><init>(Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    throw v1
.end method

.method public getHeaderLength()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPersistableWireMessage;->getHeaderBytes()[B

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    array-length v0, v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public getHeaderOffset()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method

.method public getPayloadBytes()[B
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    :try_start_0
    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getPayload()[B

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v1, v0}, Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;-><init>(Ljava/lang/Throwable;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    throw v1
.end method

.method public getPayloadLength()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public getPayloadOffset()I
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method
