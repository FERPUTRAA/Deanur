.class public Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPingResp;
.super Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;


# static fields
.field public static final KEY:Ljava/lang/String; = "Ping"


# direct methods
.method public constructor <init>(B[B)V
    .locals 2

    const/4 v1, 0x2

    const/16 p1, 0xd

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;-><init>(B)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public getKey()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const-string v0, "giPn"

    const-string v0, "Ping"

    const/4 v2, 0x6

    const-string v0, "gPin"

    const-string v0, "Ping"

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method protected getVariableHeader()[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    new-array v0, v0, [B

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public isMessageIdRequired()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method
