.class public Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;
.super Ljava/lang/Object;


# instance fields
.field private length:I

.field private value:J


# direct methods
.method public constructor <init>(J)V
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0, p1, p2, v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;-><init>(JI)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(JI)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;->value:J

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput p3, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;->length:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public getEncodedLength()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;->length:I

    const/4 v1, 0x1

    move v2, v1

    return v0
.end method

.method public getValue()J
    .locals 4

    const/4 v3, 0x3

    iget-wide v0, p0, Lcom/tencent/android/tpns/mqtt/internal/wire/MultiByteInteger;->value:J

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-wide v0
.end method
