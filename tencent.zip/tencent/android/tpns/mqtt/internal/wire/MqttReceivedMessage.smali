.class public Lcom/tencent/android/tpns/mqtt/internal/wire/MqttReceivedMessage;
.super Lcom/tencent/android/tpns/mqtt/MqttMessage;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public getMessageId()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ds~b~~tn@o~~o~@M4@~~t@1a@~@v~ @b~s@ c~~o~K @/.~~-i @ @ b@fi@lyu@/@@o    ~@f@~ ~ @m~~  Si@o or l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    invoke-super {p0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getId()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method

.method public setDuplicate(Z)V
    .locals 2

    const/4 v1, 0x4

    invoke-super {p0, p1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setDuplicate(Z)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public setMessageId(I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-super {p0, p1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setId(I)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method
