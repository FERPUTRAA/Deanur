.class public Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/MqttPersistable;


# instance fields
.field private hLength:I

.field private hOffset:I

.field private header:[B

.field private key:Ljava/lang/String;

.field private pLength:I

.field private pOffset:I

.field private payload:[B


# direct methods
.method public constructor <init>(Ljava/lang/String;[BII[BII)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->key:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->header:[B

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p3, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->hOffset:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput p4, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->hLength:I

    const/4 v1, 0x6

    iput-object p5, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->payload:[B

    const/4 v1, 0x5

    const/4 v0, 0x7

    iput p6, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->pOffset:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput p7, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->pLength:I

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public getHeaderBytes()[B
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "f@ssl@Ko @-./ l@ar~i@b o @my @@  @1t~d o @~~~~@c@u~@on@~f @~/i~~~  ~ @~o ~@oi~@M@ S @ bv4~b~~~~t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->header:[B

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public getHeaderLength()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->hLength:I

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public getHeaderOffset()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->hOffset:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    return v0
.end method

.method public getKey()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->key:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public getPayloadBytes()[B
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->payload:[B

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method public getPayloadLength()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->payload:[B

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->pLength:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public getPayloadOffset()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/MqttPersistentData;->pOffset:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return v0
.end method
