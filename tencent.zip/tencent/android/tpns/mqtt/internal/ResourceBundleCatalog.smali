.class public Lcom/tencent/android/tpns/mqtt/internal/ResourceBundleCatalog;
.super Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;


# instance fields
.field private bundle:Ljava/util/ResourceBundle;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;-><init>()V

    const/4 v2, 0x6

    const-string/jumbo v0, "ntsninds.apitttnmtcmco.oeesqnslnml..essr.s.aent.gda"

    const-string v0, "dcss.eg.cldrnemeis.tnenlstnatat.ntmomq.eainop.sstn."

    const/4 v2, 0x2

    const-string/jumbo v0, "tqnmtesanmlm..lnecp.ise.ness.tanttrdr.ta.ncmoengiso"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.messages"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0}, Ljava/util/ResourceBundle;->getBundle(Ljava/lang/String;)Ljava/util/ResourceBundle;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ResourceBundleCatalog;->bundle:Ljava/util/ResourceBundle;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method protected getLocalizedMessage(I)Ljava/lang/String;
    .locals 3

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @@oo~~ i~o@@~@~-~@m~scr~~ /Kb ty  o~ ~b1~@ @i~@on @M ~b~dv~S~4o @l~f.  f u@ @tl~ @i/~ @@@@oa@@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ResourceBundleCatalog;->bundle:Ljava/util/ResourceBundle;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p1}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/util/ResourceBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/util/MissingResourceException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p1

    :catch_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const-string/jumbo p1, "ticenbEpqotxM"

    const-string p1, "MqttException"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p1
.end method
