.class public Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "DisconnectedMessageBuffer"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private bufLock:Ljava/lang/Object;

.field private buffer:Ljava/util/ArrayList;

.field private bufferOpts:Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;

.field private callback:Lcom/tencent/android/tpns/mqtt/internal/IDisconnectedBufferCallback;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const-string v0, "gtslatt..sstro.iqadtnmn.dso.relctne.ia.nnncpmotnl"

    const-string/jumbo v0, "tlsi.o.ntopttclgtnsnrsa..daoimqtlrnnd.emc.canetn."

    const/4 v3, 0x0

    const-string v0, "as.mi.d.r..tqnldme.oocnettcinas.tttrnlcnmnenaotgp"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, "efnsofenmsuMoaccdseDBiger"

    const-string v1, "cesmgdfreteBMsnDusofcanei"

    const/4 v3, 0x2

    const-string v1, "deufnbeBeesnDirocsteMcfga"

    const-string v1, "DisconnectedMessageBuffer"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x3

    return-void
.end method

.method public constructor <init>(Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/Object;

    const/4 v1, 0x1

    move v2, v1

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->bufLock:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->bufferOpts:Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;

    const/4 v2, 0x2

    const/4 v1, 0x3

    new-instance p1, Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->buffer:Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string v1, "615"

    const-string v1, "156"

    const/4 v6, 0x5

    const-string v1, "516"

    const-string v1, "516"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v2, "csnafMuogsefcDerBudteenso"

    const-string/jumbo v2, "sfacogrDMsefescnendeeBotu"

    const/4 v6, 0x1

    const-string v2, "DisconnectedMessageBuffer"

    const/4 v6, 0x3

    const-string/jumbo v3, "urn"

    const-string/jumbo v3, "rnu"

    const/4 v6, 0x2

    const-string/jumbo v3, "rnu"

    const-string/jumbo v3, "run"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-interface {v0, v2, v3, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->getMessageCount()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-lez v0, :cond_0

    const/4 v6, 0x7

    const/4 v0, 0x4

    const/4 v6, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->getMessage(I)Lcom/tencent/android/tpns/mqtt/BufferedMessage;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->callback:Lcom/tencent/android/tpns/mqtt/internal/IDisconnectedBufferCallback;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v4, v1}, Lcom/tencent/android/tpns/mqtt/internal/IDisconnectedBufferCallback;->publishBufferedMessage(Lcom/tencent/android/tpns/mqtt/BufferedMessage;)V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->deleteMessage(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v2, v3, v0}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-void
.end method

.method public deleteMessage(I)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->bufLock:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->buffer:Ljava/util/ArrayList;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v3, 0x3

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    throw p1
.end method

.method public getMessage(I)Lcom/tencent/android/tpns/mqtt/BufferedMessage;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->bufLock:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->buffer:Ljava/util/ArrayList;

    const/4 v2, 0x6

    or-int/2addr v3, v2

    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    check-cast p1, Lcom/tencent/android/tpns/mqtt/BufferedMessage;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    throw p1
.end method

.method public getMessageCount()I
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->bufLock:Ljava/lang/Object;

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->buffer:Ljava/util/ArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    throw v1
.end method

.method public isPersistBuffer()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->bufferOpts:Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->isPersistBuffer()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    return v0
.end method

.method public putMessage(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance v0, Lcom/tencent/android/tpns/mqtt/BufferedMessage;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v0, p1, p2}, Lcom/tencent/android/tpns/mqtt/BufferedMessage;-><init>(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->bufLock:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    monitor-enter p1

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->buffer:Ljava/util/ArrayList;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->bufferOpts:Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->getBufferSize()I

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    if-ge p2, v1, :cond_0

    const/4 v2, 0x7

    and-int/2addr v3, v2

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->buffer:Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->bufferOpts:Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;

    const/4 v3, 0x4

    invoke-virtual {p2}, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->isDeleteOldestMessages()Z

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    if-ne p2, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->buffer:Ljava/util/ArrayList;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p2, v1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    const/4 v2, 0x3

    and-int/2addr v3, v2

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->buffer:Ljava/util/ArrayList;

    const/4 v3, 0x5

    invoke-virtual {p2, v0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    monitor-exit p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void

    :cond_1
    const/4 v3, 0x6

    new-instance p2, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/16 v0, 0x7dcb

    const/4 v2, 0x7

    move v3, v2

    invoke-direct {p2, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    const/4 v2, 0x3

    move v3, v2

    throw p2

    :catchall_0
    move-exception p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    throw p2
.end method

.method public setPublishCallback(Lcom/tencent/android/tpns/mqtt/internal/IDisconnectedBufferCallback;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->callback:Lcom/tencent/android/tpns/mqtt/internal/IDisconnectedBufferCallback;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method
