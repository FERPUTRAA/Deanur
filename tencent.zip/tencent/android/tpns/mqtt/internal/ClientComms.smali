.class public Lcom/tencent/android/tpns/mqtt/internal/ClientComms;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;,
        Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;,
        Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;
    }
.end annotation


# static fields
.field public static BUILD_LEVEL:Ljava/lang/String; = "L${build.level}"

.field private static final CLASS_NAME:Ljava/lang/String; = "ClientComms"

.field private static final CLOSED:B = 0x4t

.field private static final CONNECTED:B = 0x0t

.field private static final CONNECTING:B = 0x1t

.field private static final DISCONNECTED:B = 0x3t

.field private static final DISCONNECTING:B = 0x2t

.field private static final TAG:Ljava/lang/String; = "ClientComms"

.field public static VERSION:Ljava/lang/String; = "${project.version}"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

.field private client:Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

.field private clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

.field private closePending:Z

.field private conLock:Ljava/lang/Object;

.field private conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

.field private conState:B

.field private discbg:Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;

.field private disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

.field private executorService:Ljava/util/concurrent/ExecutorService;

.field private networkModuleIndex:I

.field private networkModules:[Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;

.field private persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

.field private pingSender:Lcom/tencent/android/tpns/mqtt/MqttPingSender;

.field private receiver:Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;

.field private resting:Z

.field private sender:Lcom/tencent/android/tpns/mqtt/internal/CommsSender;

.field private stoppingComms:Z

.field private tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v0, "etsn.dt..sndlaresnintgnrcct.no.mltansotimcpt.ael."

    const-string/jumbo v0, "sosltccaaden.taonliog.nc.tirnd.nlrptm.enntte..tms"

    const/4 v3, 0x4

    const-string v0, "..tmn.tn.stetnq.octliegnrlecaalmsoo..arimcnntpdnd"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v2, 0x2

    shr-int/2addr v3, v2

    const-string v1, "eimlotsmCmo"

    const-string v1, "Ctmmslioemn"

    const/4 v3, 0x1

    const-string v1, "CemCmbotlni"

    const-string v1, "ClientComms"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public constructor <init>(Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;Lcom/tencent/android/tpns/mqtt/MqttPingSender;Ljava/util/concurrent/ExecutorService;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->stoppingComms:Z

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 v1, 0x3

    const/4 v7, 0x0

    iput-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    new-instance v2, Ljava/lang/Object;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v2}, Ljava/lang/Object;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->closePending:Z

    const/4 v6, 0x7

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->resting:Z

    const/4 v7, 0x0

    const/4 v6, 0x3

    const-string/jumbo v0, "tnmlosumoie"

    const-string v0, "Cnliooestmm"

    const/4 v7, 0x5

    const-string/jumbo v0, "mCsilmtpoen"

    const-string v0, "ClientComms"

    const/4 v7, 0x1

    const/4 v6, 0x7

    const-string v2, "CiielbtCnso ntmm"

    const-string/jumbo v2, "temC mnnqiCtosil"

    const-string/jumbo v2, "init ClientComms"

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v0, v2}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    xor-int/2addr v7, v6

    iput-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->client:Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    const/4 v7, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    iput-object p3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->pingSender:Lcom/tencent/android/tpns/mqtt/MqttPingSender;

    const/4 v6, 0x7

    move v7, v6

    if-eqz p3, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-interface {p3, p0}, Lcom/tencent/android/tpns/mqtt/MqttPingSender;->init(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)V

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    iput-object p4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->executorService:Ljava/util/concurrent/ExecutorService;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    new-instance p1, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object p4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {p4}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object p4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {p1, p4}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-instance p1, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {p1, p0}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;-><init>(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)V

    const/4 v6, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-instance p1, Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v7, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v1, p2

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;-><init>(Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/MqttPingSender;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p2, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->setClientState(Lcom/tencent/android/tpns/mqtt/internal/ClientState;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object p2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-interface {p2}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-interface {p1, p2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->setResourceName(Ljava/lang/String;)V

    const/4 v7, 0x0

    return-void
.end method

.method static synthetic access$000(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Ljava/util/concurrent/ExecutorService;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~sn-b~~o ~~M@@ o ~/@ @@/@@~y@tfc o~tl s@~@K@@  o~f@a~o ldo~~4i@~~   ~@ ~@1b~  b @@~m@ii~vu @rS~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->executorService:Ljava/util/concurrent/ExecutorService;

    const/4 v1, 0x6

    const/4 v0, 0x1

    return-object p0
.end method

.method static synthetic access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v2, 0x4

    const/4 v1, 0x1

    return-object v0
.end method

.method static synthetic access$200(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic access$300(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)[Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    iget-object p0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->networkModules:[Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic access$400(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    iget p0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->networkModuleIndex:I

    return p0
.end method

.method static synthetic access$500(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->receiver:Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;

    const/4 v0, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$502(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;)Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->receiver:Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic access$600(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/ClientState;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method static synthetic access$700(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/CommsSender;
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->sender:Lcom/tencent/android/tpns/mqtt/internal/CommsSender;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic access$702(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/internal/CommsSender;)Lcom/tencent/android/tpns/mqtt/internal/CommsSender;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->sender:Lcom/tencent/android/tpns/mqtt/internal/CommsSender;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p1
.end method

.method static synthetic access$800(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-object p0
.end method

.method private handleOldTokens(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)Lcom/tencent/android/tpns/mqtt/MqttToken;
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v1, "ThamleudoOksldn"

    const-string v1, "TenOdeuhlskaldo"

    const/4 v5, 0x3

    const-string/jumbo v1, "naTdolshekeOdon"

    const-string v1, "handleOldTokens"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const-string v2, "222"

    const-string v2, "222"

    const/4 v5, 0x7

    const-string v2, "222"

    const-string v2, "222"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v3, "psoCmbntCil"

    const-string/jumbo v3, "tlmsonepiCC"

    const/4 v5, 0x3

    const-string/jumbo v3, "isClntuoemm"

    const-string v3, "ClientComms"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {v0, v3, v1, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v2, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v5, 0x0

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->getToken(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-nez v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v2, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v1, p1, v2}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->saveToken(Lcom/tencent/android/tpns/mqtt/MqttToken;Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->resolveOldTokens(Lcom/tencent/android/tpns/mqtt/MqttException;)Ljava/util/Vector;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1}, Ljava/util/Vector;->elements()Ljava/util/Enumeration;

    move-result-object p1

    :cond_1
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-interface {p1}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result p2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz p2, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-interface {p1}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    check-cast p2, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v1, p2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v2, "iDcs"

    const-string/jumbo v2, "sicD"

    const/4 v5, 0x3

    const-string v2, "csiD"

    const-string v2, "Disc"

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-nez v1, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x3

    iget-object v1, p2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v5, 0x6

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string/jumbo v2, "onC"

    const-string/jumbo v2, "onC"

    const/4 v5, 0x5

    const-string v2, "Con"

    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_1

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    move v5, v4

    invoke-virtual {v1, p2}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->asyncOperationComplete(Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto :goto_0

    :cond_3
    :goto_1
    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto :goto_0

    :catch_0
    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-object v0
.end method

.method private handleRunException(Ljava/lang/Exception;)V
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string/jumbo v1, "nCmtqempCis"

    const-string/jumbo v1, "oCntmemCqsi"

    const/4 v7, 0x1

    const-string/jumbo v1, "tomeCnCsqml"

    const-string v1, "ClientComms"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string/jumbo v2, "nnstEiRoausldneehc"

    const-string/jumbo v2, "nlstaphicdRneeuEon"

    const/4 v7, 0x0

    const-string v2, "eetmnEupoRincandlh"

    const-string v2, "handleRunException"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const-string v3, "084"

    const-string v3, "480"

    const/4 v7, 0x7

    const-string v3, "840"

    const-string v3, "804"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    const/4 v4, 0x0

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-interface/range {v0 .. v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-nez v0, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/16 v1, 0x7d6d

    invoke-direct {v0, v1, p1}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(ILjava/lang/Throwable;)V

    const/4 v7, 0x7

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    check-cast v0, Lcom/tencent/android/tpns/mqtt/MqttException;

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 p1, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p0, p1, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->shutdownConnection(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v7, 0x6

    return-void
.end method

.method private shutdownExecutorService()V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v0, "itdeoSroEueexnsvuwcohtc"

    const-string/jumbo v0, "shutdownExecutorService"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->executorService:Ljava/util/concurrent/ExecutorService;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-interface {v1}, Ljava/util/concurrent/ExecutorService;->shutdown()V

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->executorService:Ljava/util/concurrent/ExecutorService;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    sget-object v2, Ljava/util/concurrent/TimeUnit;->SECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x2

    const-wide/16 v3, 0x1

    const-wide/16 v3, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-interface {v1, v3, v4, v2}, Ljava/util/concurrent/ExecutorService;->awaitTermination(JLjava/util/concurrent/TimeUnit;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    if-nez v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->executorService:Ljava/util/concurrent/ExecutorService;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    const/4 v6, 0x5

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->executorService:Ljava/util/concurrent/ExecutorService;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {v1, v3, v4, v2}, Ljava/util/concurrent/ExecutorService;->awaitTermination(JLjava/util/concurrent/TimeUnit;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    if-nez v1, :cond_0

    const/4 v5, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x6

    const-string/jumbo v2, "meiCmbolCnm"

    const-string v2, "elmmCsominC"

    const/4 v6, 0x3

    const-string/jumbo v2, "tinClousmme"

    const-string v2, "ClientComms"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string/jumbo v3, "mdSeoeepoinuevntrrcixocae eritttd"

    const-string v3, "dmceo eic enxiaredStrovietenutotr"

    const-string v3, "enceSimrqttaxete  idernedtocir uv"

    const-string v3, "executorService did not terminate"

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v1, v2, v0, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    goto :goto_0

    :catch_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->executorService:Ljava/util/concurrent/ExecutorService;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/concurrent/ExecutorService;->shutdownNow()Ljava/util/List;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/Thread;->interrupt()V

    :cond_0
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    return-void
.end method


# virtual methods
.method public checkForActivity()Lcom/tencent/android/tpns/mqtt/MqttToken;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->checkForActivity(Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public checkForActivity(Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)Lcom/tencent/android/tpns/mqtt/MqttToken;
    .locals 3

    :try_start_0
    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->checkForActivity(Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    move-result-object p1
    :try_end_0
    .catch Lcom/tencent/android/tpns/mqtt/MqttException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    goto :goto_1

    :catch_0
    move-exception p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->handleRunException(Ljava/lang/Exception;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :catch_1
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->handleRunException(Ljava/lang/Exception;)V

    :goto_0
    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p1, 0x0

    :goto_1
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p1
.end method

.method public close(Z)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isClosed()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-nez v1, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isDisconnected()Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz p1, :cond_3

    :cond_0
    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string/jumbo v1, "mmsobetlCCn"

    const-string v1, "CmelobtCsnm"

    const/4 v5, 0x0

    const-string v1, "ClientComms"

    const/4 v5, 0x3

    const-string v2, "cusme"

    const-string v2, "cueos"

    const/4 v5, 0x7

    const-string/jumbo v2, "oslco"

    const-string v2, "close"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string v3, "224"

    const-string v3, "224"

    const/4 v5, 0x6

    const-string v3, "242"

    const-string v3, "224"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-interface {p1, v1, v2, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isConnecting()Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz p1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string p1, "eplmCboCtin"

    const-string p1, "ClCnotepmis"

    const/4 v5, 0x5

    const-string/jumbo p1, "liCmneusotm"

    const-string p1, "ClientComms"

    const/4 v5, 0x2

    const-string/jumbo v1, "ln nestpiceniwoigehoscsn C"

    const-string v1, "close when is isConnecting"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {p1, v1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isConnected()Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string/jumbo p1, "iqCmtemsqoC"

    const-string/jumbo p1, "oCCnemmiqts"

    const/4 v5, 0x1

    const-string/jumbo p1, "itssoenClCm"

    const-string p1, "ClientComms"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string/jumbo v1, "ss mneiosncoceew hC lnesd"

    const-string/jumbo v1, "snsesw cendCcoestho  ienl"

    const/4 v5, 0x7

    const-string v1, "enn oowd  heeintlisosscCc"

    const-string v1, "close when is isConnected"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p1, v1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isDisconnecting()Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz p1, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 p1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->closePending:Z

    :cond_3
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 p1, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-byte p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->shutdownExecutorService()V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->close()V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 p1, 0x0

    move v5, p1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->sender:Lcom/tencent/android/tpns/mqtt/internal/CommsSender;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->pingSender:Lcom/tencent/android/tpns/mqtt/MqttPingSender;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->receiver:Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;

    const/4 v4, 0x5

    and-int/2addr v5, v4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->networkModules:[Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;

    const/4 v4, 0x0

    or-int/2addr v5, v4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    :cond_4
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    monitor-exit v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    throw p1
.end method

.method public connect(Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    .locals 18
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    move-object/from16 v7, p0

    iget-object v8, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    monitor-enter v8

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isDisconnected()Z

    move-result v0

    const/4 v1, 0x1

    if-eqz v0, :cond_0

    iget-boolean v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->closePending:Z

    if-nez v0, :cond_0

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const-string/jumbo v2, "teommCnsmlC"

    const-string/jumbo v2, "oimmlbtnCse"

    const-string v2, "ClientComms"

    const-string v3, "econncu"

    const-string v3, "ceoconn"

    const-string/jumbo v3, "pcceotn"

    const-string v3, "connect"

    const-string v4, "412"

    const-string v4, "214"

    const-string v4, "124"

    const-string v4, "214"

    invoke-interface {v0, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    iput-byte v1, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    iput-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    new-instance v5, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;

    iget-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->client:Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v10

    iget-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getMqttVersion()I

    move-result v11

    iget-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->isCleanSession()Z

    move-result v12

    iget-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getKeepAliveInterval()I

    move-result v13

    iget-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getUserName()Ljava/lang/String;

    move-result-object v14

    iget-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getPassword()[C

    move-result-object v15

    iget-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getWillMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v16

    iget-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getWillDestination()Ljava/lang/String;

    move-result-object v17

    move-object v9, v5

    move-object v9, v5

    move-object v9, v5

    invoke-direct/range {v9 .. v17}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;-><init>(Ljava/lang/String;IZILjava/lang/String;[CLcom/tencent/android/tpns/mqtt/MqttMessage;Ljava/lang/String;)V

    iget-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    iget-object v1, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getKeepAliveInterval()I

    move-result v1

    int-to-long v1, v1

    invoke-virtual {v0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->setKeepAliveSecs(J)V

    iget-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    iget-object v1, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->isCleanSession()Z

    move-result v1

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->setCleanSession(Z)V

    iget-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    iget-object v1, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;->getMaxInflight()I

    move-result v1

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->setMaxInflight(I)V

    iget-object v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->open()V

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;

    iget-object v6, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->executorService:Ljava/util/concurrent/ExecutorService;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v3, p0

    move-object/from16 v3, p0

    move-object/from16 v3, p0

    move-object/from16 v3, p0

    move-object/from16 v4, p2

    move-object/from16 v4, p2

    move-object/from16 v4, p2

    move-object/from16 v4, p2

    invoke-direct/range {v1 .. v6}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;-><init>(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;Ljava/util/concurrent/ExecutorService;)V

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->start()V

    monitor-exit v8

    return-void

    :cond_0
    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const-string v2, "esCiboCmqtl"

    const-string/jumbo v2, "mloiebCCtsn"

    const-string/jumbo v2, "oesCmmCstln"

    const-string v2, "ClientComms"

    const-string v3, "ennmucc"

    const-string/jumbo v3, "nnccetu"

    const-string v3, "centocn"

    const-string v3, "connect"

    const-string v4, "207"

    const-string v4, "702"

    const-string v4, "702"

    const-string v4, "207"

    new-array v1, v1, [Ljava/lang/Object;

    new-instance v5, Ljava/lang/Byte;

    iget-byte v6, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    invoke-direct {v5, v6}, Ljava/lang/Byte;-><init>(B)V

    const/4 v6, 0x0

    aput-object v5, v1, v6

    invoke-interface {v0, v2, v3, v4, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    invoke-virtual/range {p0 .. p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isClosed()Z

    move-result v0

    if-nez v0, :cond_3

    iget-boolean v0, v7, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->closePending:Z

    if-nez v0, :cond_3

    invoke-virtual/range {p0 .. p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isConnecting()Z

    move-result v0

    if-nez v0, :cond_2

    invoke-virtual/range {p0 .. p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isDisconnecting()Z

    move-result v0

    if-eqz v0, :cond_1

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/16 v1, 0x7d66

    invoke-direct {v0, v1}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    throw v0

    :cond_1
    const/16 v0, 0x7d64

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v0

    throw v0

    :cond_2
    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/16 v1, 0x7d6e

    invoke-direct {v0, v1}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    throw v0

    :cond_3
    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/16 v1, 0x7d6f

    invoke-direct {v0, v1}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    throw v0

    :catchall_0
    move-exception v0

    monitor-exit v8
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    throw v0
.end method

.method public connectComplete(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;Lcom/tencent/android/tpns/mqtt/MqttException;)V
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v7, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;->getReturnCode()I

    move-result p1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    monitor-enter v0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v1, 0x0

    const/4 v8, 0x3

    if-nez p1, :cond_0

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string/jumbo p2, "ompnsbelmtC"

    const-string/jumbo p2, "snCmielptom"

    const/4 v8, 0x2

    const-string/jumbo p2, "metCoiuCnls"

    const-string p2, "ClientComms"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string v2, "eotmponpeCnlecc"

    const-string/jumbo v2, "nemoecncqCeplto"

    const-string v2, "cntlCeptqcnooem"

    const-string v2, "connectComplete"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const-string v3, "512"

    const-string v3, "215"

    const/4 v8, 0x6

    const-string v3, "512"

    const-string v3, "215"

    const/4 v8, 0x4

    invoke-interface {p1, p2, v2, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    iput-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    monitor-exit v0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    return-void

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x3

    const-string/jumbo v2, "sisnlsmomCt"

    const-string/jumbo v2, "lmsemstionC"

    const/4 v8, 0x6

    const-string/jumbo v2, "tsomeCmnClm"

    const-string v2, "ClientComms"

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-string/jumbo v3, "mlncoepoetmCcto"

    const-string/jumbo v3, "pcomeecmoCnetlt"

    const/4 v8, 0x6

    const-string v3, "etpmebtcoeCnlnc"

    const-string v3, "connectComplete"

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    const-string v4, "402"

    const-string v4, "024"

    const/4 v8, 0x3

    const-string v4, "420"

    const-string v4, "204"

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v5, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v8, 0x6

    new-instance v6, Ljava/lang/Integer;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-direct {v6, p1}, Ljava/lang/Integer;-><init>(I)V

    const/4 v8, 0x6

    const/4 v7, 0x4

    aput-object v6, v5, v1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-interface {v0, v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-nez p2, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    return-void

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    throw p2

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x7

    move v8, v7

    throw p1
.end method

.method public deleteBufferedMessage(I)V
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->deleteMessage(I)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method protected deliveryComplete(I)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->deliveryComplete(I)V

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method protected deliveryComplete(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->deliveryComplete(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V

    const/4 v2, 0x0

    return-void
.end method

.method public disconnect(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttDisconnect;JLcom/tencent/android/tpns/mqtt/MqttToken;)V
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isClosed()Z

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    if-nez v1, :cond_3

    const/4 v10, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isDisconnected()Z

    move-result v1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    if-nez v1, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isDisconnecting()Z

    move-result v1

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-nez v1, :cond_1

    const/4 v10, 0x3

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->getThread()Ljava/lang/Thread;

    move-result-object v2

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-ne v1, v2, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x1

    const-string v2, "ClntCoumism"

    const-string/jumbo v2, "smoCotilmnC"

    const/4 v10, 0x7

    const-string/jumbo v2, "tlosmmnpeCC"

    const-string v2, "ClientComms"

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    const-string v3, "dnnctcioqb"

    const-string v3, "ceintbdocn"

    const-string/jumbo v3, "tesoinsdcn"

    const-string v3, "disconnect"

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-string v4, "102"

    const-string v4, "201"

    const/4 v10, 0x5

    const-string v4, "210"

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    const-string/jumbo v2, "niumtCsCeml"

    const-string/jumbo v2, "nemlCtuCiso"

    const/4 v10, 0x1

    const-string/jumbo v2, "sieCotmmnlo"

    const-string v2, "ClientComms"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-string/jumbo v3, "isnotbpcde"

    const-string/jumbo v3, "scioedtpcn"

    const/4 v10, 0x4

    const-string v3, "cnstnoudic"

    const-string v3, "disconnect"

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-string v4, "812"

    const-string v4, "182"

    const/4 v10, 0x1

    const-string v4, "821"

    const-string v4, "218"

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    const/4 v1, 0x2

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    iput-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v10, 0x0

    new-instance v1, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-object v8, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->executorService:Ljava/util/concurrent/ExecutorService;

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-wide v5, p2

    move-object v7, p4

    move-object v7, p4

    move-object v7, p4

    move-object v7, p4

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-direct/range {v2 .. v8}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;-><init>(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttDisconnect;JLcom/tencent/android/tpns/mqtt/MqttToken;Ljava/util/concurrent/ExecutorService;)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->start()V

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    monitor-exit v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    return-void

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-string p2, "CCtsemnplmq"

    const-string p2, "eltCmsonqCm"

    const/4 v10, 0x6

    const-string/jumbo p2, "imCemCtsqlo"

    const-string p2, "ClientComms"

    const/4 v10, 0x0

    const/4 v9, 0x0

    const-string/jumbo p3, "itsncsoedn"

    const-string/jumbo p3, "tdsnenccio"

    const/4 v10, 0x7

    const-string p3, "cdimsetnon"

    const-string p3, "disconnect"

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    const-string p4, "912"

    const-string p4, "219"

    const/4 v10, 0x6

    const-string p4, "291"

    const-string p4, "219"

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-interface {p1, p2, p3, p4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/16 p1, 0x7d66

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    throw p1

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const-string/jumbo p2, "omlCoeinmmt"

    const-string/jumbo p2, "inomCmlCmet"

    const-string/jumbo p2, "ntlembCsiCm"

    const-string p2, "ClientComms"

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    const-string/jumbo p3, "niodccuote"

    const-string/jumbo p3, "oitsondcce"

    const/4 v10, 0x1

    const-string p3, "dsctcnopin"

    const-string p3, "disconnect"

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-string p4, "121"

    const-string p4, "112"

    const/4 v10, 0x5

    const-string p4, "211"

    const-string p4, "211"

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-interface {p1, p2, p3, p4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x4

    const/16 p1, 0x7d65

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    throw p1

    :cond_3
    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-string p2, "etCliCnmqbs"

    const-string/jumbo p2, "mCnetblmiCs"

    const-string/jumbo p2, "nosmtlmCise"

    const-string p2, "ClientComms"

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-string/jumbo p3, "ndcnesuoic"

    const/4 v10, 0x2

    const-string p3, "csimtondne"

    const-string p3, "disconnect"

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-string p4, "232"

    const-string p4, "232"

    const/4 v10, 0x0

    const-string p4, "322"

    const-string p4, "223"

    const/4 v10, 0x6

    const/4 v9, 0x1

    invoke-interface {p1, p2, p3, p4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    const/16 p1, 0x7d6f

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    throw p1

    :catchall_0
    move-exception p1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    throw p1
.end method

.method public disconnectForcibly(JJ)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    const/4 v5, 0x1

    move-object v0, p0

    move-wide v1, p1

    move-wide v3, p3

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual/range {v0 .. v5}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectForcibly(JJZ)V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    return-void
.end method

.method public disconnectForcibly(JJZ)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v1, 0x6

    move v2, v1

    invoke-virtual {v0, p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiesce(J)V

    :cond_0
    const/4 v1, 0x4

    const/4 v2, 0x0

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->client:Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-interface {p2}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttToken;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p2, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz p5, :cond_1

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance p5, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttDisconnect;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-direct {p5}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttDisconnect;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0, p5, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->internalSend(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1, p3, p4}, Lcom/tencent/android/tpns/mqtt/MqttToken;->waitForCompletion(J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object p3, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p3, p2, p2}, Lcom/tencent/android/tpns/mqtt/internal/Token;->markComplete(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0, p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->shutdownConnection(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public getActualInFlight()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getActualInFlight()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public getBufferedMessage(I)Lcom/tencent/android/tpns/mqtt/MqttMessage;
    .locals 3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->getMessage(I)Lcom/tencent/android/tpns/mqtt/BufferedMessage;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/BufferedMessage;->getMessage()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    check-cast p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p1
.end method

.method public getBufferedMessageCount()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->getMessageCount()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->client:Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public getClientState()Lcom/tencent/android/tpns/mqtt/internal/ClientState;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public getConOptions()Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conOptions:Lcom/tencent/android/tpns/mqtt/MqttConnectOptions;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public getDebug()Ljava/util/Properties;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    new-instance v0, Ljava/util/Properties;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/util/Properties;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/Integer;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-byte v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    invoke-direct {v1, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v2, "ncStopta"

    const-string v2, "Scetnatp"

    const/4 v4, 0x6

    const-string v2, "ctSonbte"

    const-string v2, "conState"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-interface {v1}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getServerURI()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const-string v2, "RrreIquUe"

    const-string/jumbo v2, "rsIReerUq"

    const/4 v4, 0x7

    const-string v2, "erRUIerpv"

    const-string/jumbo v2, "serverURI"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo v1, "qlbklaac"

    const-string v1, "callback"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/Boolean;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-boolean v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->stoppingComms:Z

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-direct {v1, v2}, Ljava/lang/Boolean;-><init>(Z)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const-string/jumbo v2, "mpssosmgstipo"

    const-string/jumbo v2, "osstmgppomsin"

    const-string/jumbo v2, "igCmopssntomp"

    const-string/jumbo v2, "stoppingComms"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v2, v1}, Ljava/util/Dictionary;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object v0
.end method

.method public getKeepAlive()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v3, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getKeepAlive()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-wide v0
.end method

.method public getNetworkModuleIndex()I
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->networkModuleIndex:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public getNetworkModules()[Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->networkModules:[Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public getPendingDeliveryTokens()[Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->getOutstandingDelTokens()[Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method getReceiver()Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->receiver:Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-object v0
.end method

.method protected getTopic(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/MqttTopic;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttTopic;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {v0, p1, p0}, Lcom/tencent/android/tpns/mqtt/MqttTopic;-><init>(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method internalSend(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    .locals 11
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    const-string v0, "cnliom nntSenraidota-"

    const-string v0, "annmeiln-citaSn ordt "

    const/4 v10, 0x0

    const-string v0, "cdSeib-alnin n ttrean"

    const-string v0, "action - internalSend"

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-string v1, "CCmstmunioe"

    const-string v1, "eiosomnmCCt"

    const/4 v10, 0x4

    const-string v1, "eCinstopmml"

    const-string v1, "ClientComms"

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {v1, v0}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/4 v2, 0x3

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getKey()Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x7

    const/4 v5, 0x0

    const/4 v10, 0x6

    aput-object v4, v3, v5

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    const/4 v4, 0x1

    const/4 v10, 0x5

    aput-object p1, v3, v4

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x5

    const/4 v6, 0x2

    const/4 v9, 0x6

    const/4 v9, 0x3

    aput-object p2, v3, v6

    const/4 v9, 0x4

    and-int/2addr v10, v9

    const-string/jumbo v7, "nbaSedniqtlr"

    const-string v7, "elnadbnreSit"

    const/4 v10, 0x1

    const-string/jumbo v7, "nnseiSenrlat"

    const-string/jumbo v7, "internalSend"

    const/4 v10, 0x4

    const/4 v9, 0x0

    const-string v8, "020"

    const-string v8, "002"

    const/4 v10, 0x7

    const-string v8, "020"

    const-string v8, "200"

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-interface {v0, v1, v7, v8, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x2

    shr-int/2addr v10, v9

    invoke-virtual {p2}, Lcom/tencent/android/tpns/mqtt/MqttToken;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v3

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-nez v3, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget-object v0, p2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v10, 0x3

    const/4 v9, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->setClient(Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;)V

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v10, 0x7

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {v0, p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->send(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    :try_end_0
    .catch Lcom/tencent/android/tpns/mqtt/MqttException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    goto :goto_0

    :catch_0
    move-exception p2

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v10, 0x5

    if-eqz v0, :cond_0

    const/4 v9, 0x4

    xor-int/2addr v10, v9

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    check-cast p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->undo(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    throw p2

    :cond_1
    :goto_0
    const/4 v9, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    return-void

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getKey()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    aput-object v3, v2, v5

    const/4 v9, 0x1

    move v10, v9

    aput-object p1, v2, v4

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    aput-object p2, v2, v6

    const/4 v10, 0x3

    const/4 v9, 0x3

    const-string p1, "312"

    const-string p1, "213"

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-interface {v0, v1, v7, p1, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v9, 0x0

    shl-int/2addr v10, v9

    const/16 p2, 0x7dc9

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-direct {p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    const/4 v9, 0x2

    shr-int/2addr v10, v9

    throw p1
.end method

.method public isClosed()Z
    .locals 5

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v2, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-ne v1, v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    return v1

    :catchall_0
    move-exception v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    throw v1
.end method

.method public isConnected()Z
    .locals 4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    return v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x4

    move v3, v2

    throw v1
.end method

.method public isConnecting()Z
    .locals 5

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v3, 0x7

    move v4, v3

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-ne v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    return v2

    :catchall_0
    move-exception v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    throw v1
.end method

.method public isDisconnected()Z
    .locals 5

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-ne v1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x5

    move v3, v1

    move v3, v1

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x1

    return v1

    :catchall_0
    move-exception v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    throw v1
.end method

.method public isDisconnecting()Z
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v2, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-ne v1, v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    monitor-exit v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    return v1

    :catchall_0
    move-exception v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    throw v1
.end method

.method public isResting()Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x2

    move v3, v2

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->resting:Z

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    return v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    throw v1
.end method

.method public messageArrivedComplete(II)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageArrivedComplete(II)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public notifyConnect()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string v1, "CulmsCotemi"

    const-string v1, "iCnCtsumelo"

    const/4 v5, 0x4

    const-string/jumbo v1, "msnCoolmeCt"

    const-string v1, "ClientComms"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v2, "059"

    const-string v2, "905"

    const/4 v5, 0x0

    const-string v2, "509"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string/jumbo v3, "tneypbtoinnCc"

    const-string/jumbo v3, "nontcenpCtiyo"

    const/4 v5, 0x0

    const-string/jumbo v3, "ntiyoounfeCct"

    const-string/jumbo v3, "notifyConnect"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {v0, v1, v3, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    shr-int/2addr v5, v4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v1, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v1, p0, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ReconnectDisconnectedBufferCallback;-><init>(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->setPublishCallback(Lcom/tencent/android/tpns/mqtt/internal/IDisconnectedBufferCallback;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->executorService:Ljava/util/concurrent/ExecutorService;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {v0, v1}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    :cond_0
    const/4 v4, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void
.end method

.method public removeMessageListener(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->removeMessageListener(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public sendNoWait(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isConnected()Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    const/4 v2, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string/jumbo v3, "seoWtaidqN"

    const/4 v7, 0x6

    const-string v3, "aetoiWnpds"

    const-string/jumbo v3, "sendNoWait"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string v4, "CoCmelinqst"

    const-string v4, "ClientComms"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-nez v0, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isConnected()Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-nez v0, :cond_0

    const/4 v7, 0x6

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;

    const/4 v7, 0x4

    if-nez v0, :cond_4

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isDisconnecting()Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v0, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttDisconnect;

    const/4 v7, 0x7

    if-eqz v0, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v7, 0x4

    if-eqz v0, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getKey()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    aput-object v5, v2, v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string v1, "085"

    const-string v1, "850"

    const/4 v7, 0x3

    const-string v1, "085"

    const-string v1, "508"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-interface {v0, v4, v3, v1, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->isPersistBuffer()Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v0, :cond_2

    const/4 v6, 0x3

    move v7, v6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v6, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistBufferedMessage(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0, p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->putMessage(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    goto/16 :goto_1

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x2

    move v7, v6

    const-string p2, "280"

    const-string p2, "280"

    const-string p2, "802"

    const-string p2, "208"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-interface {p1, v4, v3, p2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/16 p1, 0x7d68

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x2

    throw p1

    :cond_4
    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v7, 0x0

    const/4 v6, 0x6

    if-eqz v0, :cond_6

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->getMessageCount()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v0, :cond_6

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getKey()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    aput-object v5, v2, v1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string v1, "570"

    const/4 v7, 0x5

    const-string v1, "705"

    const-string v1, "507"

    const/4 v6, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-interface {v0, v4, v3, v1, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->isPersistBuffer()Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-eqz v0, :cond_5

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->persistBufferedMessage(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    :cond_5
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v0, p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;->putMessage(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    goto :goto_1

    :cond_6
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p0, p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->internalSend(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    return-void
.end method

.method public setCallback(Lcom/tencent/android/tpns/mqtt/MqttCallback;)V
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->setCallback(Lcom/tencent/android/tpns/mqtt/MqttCallback;)V

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method

.method public setDisconnectedMessageBuffer(Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public setManualAcks(Z)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->setManualAcks(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method

.method public setMessageListener(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v2, 0x4

    invoke-virtual {v0, p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->setMessageListener(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public setNetworkModuleIndex(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->networkModuleIndex:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public setNetworkModules([Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->networkModules:[Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public setReconnectCallback(Lcom/tencent/android/tpns/mqtt/MqttCallbackExtended;)V
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->setReconnectCallback(Lcom/tencent/android/tpns/mqtt/MqttCallbackExtended;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public setRestingState(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->resting:Z

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public shutdownConnection(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V
    .locals 10

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v9, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->stoppingComms:Z

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-nez v1, :cond_10

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->closePending:Z

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-nez v1, :cond_10

    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isClosed()Z

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    if-eqz v1, :cond_0

    const/4 v8, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    goto/16 :goto_3

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v1, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    iput-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->stoppingComms:Z

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string/jumbo v3, "mCsotssmCie"

    const-string/jumbo v3, "mostmCisCne"

    const/4 v9, 0x6

    const-string v3, "CCsmneimtml"

    const-string v3, "ClientComms"

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string v4, "etnnohmnowoduotcni"

    const-string/jumbo v4, "oohmudwntCtnenicon"

    const/4 v9, 0x3

    const-string/jumbo v4, "nnntobeonohstcCwud"

    const-string/jumbo v4, "shutdownConnection"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    const-string v5, "162"

    const-string v5, "261"

    const/4 v9, 0x3

    const-string v5, "621"

    const-string v5, "216"

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-interface {v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isConnected()Z

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v3, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-nez v2, :cond_2

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isDisconnecting()Z

    move-result v2

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-eqz v2, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    goto :goto_0

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    move v2, v3

    move v2, v3

    const/4 v9, 0x0

    move v2, v3

    move v2, v3

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    move v2, v1

    move v2, v1

    const/4 v9, 0x0

    move v2, v1

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    const/4 v4, 0x2

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    iput-byte v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_4

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-eqz p1, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/MqttToken;->isComplete()Z

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-nez v0, :cond_3

    const/4 v8, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    iget-object v0, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v0, p2}, Lcom/tencent/android/tpns/mqtt/internal/Token;->setException(Lcom/tencent/android/tpns/mqtt/MqttException;)V

    :cond_3
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-eqz v0, :cond_4

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->stop()V

    :cond_4
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->receiver:Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;

    const/4 v8, 0x2

    move v9, v8

    if-eqz v0, :cond_5

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->stop()V

    :cond_5
    :try_start_1
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->networkModules:[Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-eqz v0, :cond_6

    const/4 v9, 0x2

    iget v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->networkModuleIndex:I

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    aget-object v0, v0, v4

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-eqz v0, :cond_6

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;->stop()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :cond_6
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    new-instance v4, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    const/16 v5, 0x7d66

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-direct {v4, v5}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v0, v4}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->quiesce(Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->handleOldTokens(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    move-result-object p1

    :try_start_2
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v0, p2}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->disconnected(Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v8, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-eqz v0, :cond_7

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v8, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->getCleanSession()Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-eqz v0, :cond_7

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->removeMessageListeners()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    :catch_0
    :cond_7
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->sender:Lcom/tencent/android/tpns/mqtt/internal/CommsSender;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-eqz v0, :cond_8

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->stop()V

    :cond_8
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->pingSender:Lcom/tencent/android/tpns/mqtt/MqttPingSender;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-eqz v0, :cond_9

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/MqttPingSender;->stop()V

    :cond_9
    :try_start_3
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->disconnectedMessageBuffer:Lcom/tencent/android/tpns/mqtt/internal/DisconnectedMessageBuffer;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-nez v0, :cond_a

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->persistence:Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-eqz v0, :cond_a

    const/4 v9, 0x3

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/MqttClientPersistence;->close()V
    :try_end_3
    .catch Ljava/lang/Exception; {:try_start_3 .. :try_end_3} :catch_1

    :catch_1
    :cond_a
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    monitor-enter v4

    :try_start_4
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string/jumbo v5, "nCtmmeuoCsl"

    const-string/jumbo v5, "lesmotCmnCo"

    const/4 v9, 0x2

    const-string/jumbo v5, "inClCmspmoe"

    const-string v5, "ClientComms"

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    const-string/jumbo v6, "onondCuhqntnioebws"

    const-string/jumbo v6, "scnonbionedhntouCw"

    const/4 v9, 0x1

    const-string/jumbo v6, "ohsesontdwotnCncun"

    const-string/jumbo v6, "shutdownConnection"

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string v7, "712"

    const-string v7, "172"

    const/4 v9, 0x6

    const-string v7, "271"

    const-string v7, "217"

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-interface {v0, v5, v6, v7}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v0, 0x3

    const/4 v9, 0x2

    iput-byte v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conState:B

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    iput-boolean v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->stoppingComms:Z

    const/4 v9, 0x7

    monitor-exit v4
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eqz p1, :cond_b

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    move v0, v1

    const/4 v9, 0x2

    move v0, v1

    move v0, v1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    goto :goto_2

    :cond_b
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    move v0, v3

    move v0, v3

    :goto_2
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-eqz v4, :cond_c

    const/4 v9, 0x5

    const/4 v8, 0x2

    move v3, v1

    move v3, v1

    move v3, v1

    move v3, v1

    :cond_c
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    and-int/2addr v0, v3

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    if-eqz v0, :cond_d

    const/4 v8, 0x6

    move v9, v8

    invoke-virtual {v4, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->asyncOperationComplete(Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    :cond_d
    const/4 v8, 0x0

    move v9, v8

    if-eqz v2, :cond_e

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->callback:Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-eqz p1, :cond_e

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->connectionLost(Lcom/tencent/android/tpns/mqtt/MqttException;)V

    :cond_e
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->conLock:Ljava/lang/Object;

    const/4 v9, 0x5

    monitor-enter p1

    :try_start_5
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-boolean p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->closePending:Z
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-eqz p2, :cond_f

    :try_start_6
    const/4 v8, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->close(Z)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    :catchall_1
    :cond_f
    :try_start_7
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    monitor-exit p1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    return-void

    :catchall_2
    move-exception p2

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    monitor-exit p1
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    throw p2

    :catchall_3
    move-exception p1

    :try_start_8
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    monitor-exit v4
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    throw p1

    :cond_10
    :goto_3
    :try_start_9
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    monitor-exit v0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    return-void

    :catchall_4
    move-exception p1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    monitor-exit v0
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_4

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    throw p1
.end method
