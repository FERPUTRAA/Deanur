.class Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpns/mqtt/internal/ClientComms;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "ConnectBG"
.end annotation


# instance fields
.field clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

.field conPacket:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;

.field conToken:Lcom/tencent/android/tpns/mqtt/MqttToken;

.field final synthetic this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

.field private threadName:Ljava/lang/String;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;Ljava/util/concurrent/ExecutorService;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->conToken:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->conPacket:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;

    const/4 v0, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    const-string p3, "MnsTTsQ C:"

    const-string p3, " QsTCn:T M"

    const/4 v1, 0x6

    const-string p3, "C omM QTnT"

    const-string p3, "MQTT Con: "

    const/4 v0, 0x7

    move v1, v0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-interface {p1}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->threadName:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~o~4o  @@~@di l @~ob~@M@@f/ar@/  lmvt~  @y@bo~~ bo~ -o@@1 t~Si s~~~~ ~@. o @~in~@~@K~ @@c@ u~~f@"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x3

    const-string/jumbo v0, "tmahGbdeotrmc tC qBnt"

    const-string/jumbo v0, "nodmmrce tthCGtqeBa t"

    const/4 v9, 0x5

    const-string/jumbo v0, "mBte Gu aeqntdotcrChn"

    const-string v0, "ConnectBG mqtt thread"

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    const-string/jumbo v1, "linteoCpmmC"

    const-string/jumbo v1, "lmnooemCiCt"

    const/4 v9, 0x3

    const-string/jumbo v1, "meimnlCoqCs"

    const-string v1, "ClientComms"

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {v1, v0}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->threadName:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    const-string/jumbo v2, "nBsGncunt:cer"

    const-string/jumbo v2, "neBtrbc:Gncnu"

    const/4 v9, 0x6

    const-string/jumbo v2, "ncrmoGncneBu:"

    const-string v2, "connectBG:run"

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string v3, "022"

    const-string v3, "022"

    const/4 v9, 0x2

    const-string v3, "022"

    const-string v3, "220"

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-interface {v0, v1, v2, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$200(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->getOutstandingDelTokens()[Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    array-length v2, v0

    const/4 v8, 0x2

    move v9, v8

    const/4 v3, 0x0

    shr-int/2addr v9, v3

    const/4 v8, 0x5

    move v9, v8

    if-ge v1, v2, :cond_0

    const/4 v8, 0x3

    move v9, v8

    aget-object v2, v0, v1

    const/4 v9, 0x3

    iget-object v2, v2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v2, v3}, Lcom/tencent/android/tpns/mqtt/internal/Token;->setException(Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v9, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    goto :goto_0

    :cond_0
    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v8, 0x4

    const/4 v8, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$200(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->conToken:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->conPacket:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->saveToken(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$300(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)[Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$400(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)I

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    aget-object v0, v0, v1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;->start()V

    const/4 v8, 0x0

    const/4 v8, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    new-instance v2, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object v5, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {v5}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$600(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    move-result-object v5

    const/4 v9, 0x0

    const/4 v8, 0x3

    iget-object v6, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x7

    const/4 v8, 0x7

    invoke-static {v6}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$200(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    move-result-object v6

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;->getInputStream()Ljava/io/InputStream;

    move-result-object v7

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-direct {v2, v4, v5, v6, v7}, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;-><init>(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/internal/ClientState;Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;Ljava/io/InputStream;)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$502(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;)Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;

    const/4 v8, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$500(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-string v4, "c TQoeuRM:"

    const-string v4, "eMQT :u cR"

    const/4 v9, 0x2

    const-string v4, "TRQT:b c e"

    const-string v4, "MQTT Rec: "

    const/4 v8, 0x6

    move v9, v8

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v4}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-interface {v4}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {v4}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$000(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Ljava/util/concurrent/ExecutorService;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v1, v2, v4}, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->start(Ljava/lang/String;Ljava/util/concurrent/ExecutorService;)V

    const/4 v9, 0x3

    const/4 v8, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x1

    const/4 v8, 0x1

    new-instance v2, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x2

    iget-object v5, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {v5}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$600(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v6, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v8, 0x2

    move v9, v8

    invoke-static {v6}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$200(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    move-result-object v6

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-interface {v0}, Lcom/tencent/android/tpns/mqtt/internal/NetworkModule;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-direct {v2, v4, v5, v6, v0}, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;-><init>(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/internal/ClientState;Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;Ljava/io/OutputStream;)V

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$702(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/internal/CommsSender;)Lcom/tencent/android/tpns/mqtt/internal/CommsSender;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x1

    const/4 v8, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$700(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/CommsSender;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    const-string v2, ":n Q TuSpM"

    const-string v2, "MS:dn Tp Q"

    const/4 v9, 0x3

    const-string v2, " S dnT:pMQ"

    const-string v2, "MQTT Snd: "

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x7

    const/4 v8, 0x0

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-interface {v2}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x0

    const/4 v8, 0x5

    invoke-static {v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$000(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Ljava/util/concurrent/ExecutorService;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->start(Ljava/lang/String;Ljava/util/concurrent/ExecutorService;)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$800(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    const-string v2, "T TlqQ lqCa"

    const-string v2, "Q:TTa Clql "

    const-string v2, " MsTl TCaQ:"

    const-string v2, "MQTT Call: "

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-interface {v2}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static {v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$000(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Ljava/util/concurrent/ExecutorService;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->start(Ljava/lang/String;Ljava/util/concurrent/ExecutorService;)V

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x0

    const/4 v8, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->conPacket:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnect;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->conToken:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {v0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->internalSend(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    :try_end_0
    .catch Lcom/tencent/android/tpns/mqtt/MqttException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    goto/16 :goto_1

    :catchall_0
    move-exception v0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    const-string/jumbo v2, "minmsCCstme"

    const-string/jumbo v2, "tsseCinlmmC"

    const-string v2, "CCnloemstmo"

    const-string v2, "ClientComms"

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    const-string v3, "cncrGbo:Buten"

    const-string/jumbo v3, "ocnmrucnGeBt:"

    const/4 v9, 0x1

    const-string v3, "cnor:uuceBntn"

    const-string v3, "connectBG:run"

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    const-string v4, "920"

    const-string v4, "902"

    const/4 v9, 0x2

    const-string v4, "092"

    const-string v4, "209"

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    const/4 v5, 0x0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-interface/range {v1 .. v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(Ljava/lang/Throwable;)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    goto :goto_1

    :catch_0
    move-exception v0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-string/jumbo v2, "lstemCopnCi"

    const-string v2, "CstloCoinme"

    const/4 v9, 0x7

    const-string/jumbo v2, "iemtClCsqom"

    const-string v2, "ClientComms"

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    const-string/jumbo v3, "rnsbeonGn:ctc"

    const-string v3, "Gn:tebBoncrcn"

    const/4 v9, 0x0

    const-string/jumbo v3, "tcemrnnuo:BGn"

    const-string v3, "connectBG:run"

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    const-string v4, "221"

    const-string v4, "212"

    const/4 v9, 0x5

    const-string v4, "122"

    const-string v4, "212"

    const/4 v8, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    const/4 v5, 0x0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-interface/range {v1 .. v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-eqz v3, :cond_1

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->conToken:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->shutdownConnection(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    return-void
.end method

.method start()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$ConnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$000(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-interface {v0, p0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v1, 0x7

    move v2, v1

    return-void
.end method
