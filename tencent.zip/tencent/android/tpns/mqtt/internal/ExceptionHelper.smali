.class public Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;
.super Ljava/lang/Object;


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public static createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~so @.@ @@~@ @n/ ~t@b@1l~ ~ @bviS~l~@r~@/obo@i~~ y~-t~~@K~i~~m@@f~  u~4 s@~cM~o fad  o@o~  @  @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    const/4 v0, 0x4

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eq p0, v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x5

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-ne p0, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v2, 0x5

    invoke-direct {v0, p0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    const/4 v2, 0x2

    return-object v0

    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttSecurityException;

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/tencent/android/tpns/mqtt/MqttSecurityException;-><init>(I)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public static createMqttException(Ljava/lang/Throwable;)Lcom/tencent/android/tpns/mqtt/MqttException;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string v1, "GSemueypralEtranescvjiuortn.yctiecsa.e"

    const-string/jumbo v1, "ucse.eieteiaSansvtuErpiGyoryrlnejcc.at"

    const/4 v3, 0x6

    const-string/jumbo v1, "seitoeaaru.eay.njuvtSGientEylecrcopirc"

    const-string/jumbo v1, "java.security.GeneralSecurityException"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttSecurityException;

    invoke-direct {v0, p0}, Lcom/tencent/android/tpns/mqtt/MqttSecurityException;-><init>(Ljava/lang/Throwable;)V

    const/4 v3, 0x4

    return-object v0

    :cond_0
    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0, p0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    return-object v0
.end method

.method public static isClassAvailable(Ljava/lang/String;)Z
    .locals 2

    :try_start_0
    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 p0, 0x2

    const/4 p0, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    goto :goto_0

    :catch_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return p0
.end method
