.class public Lcom/tencent/android/tpns/mqtt/internal/CommsSender;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "CommsSender"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

.field private clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

.field private lifecycle:Ljava/lang/Object;

.field private out:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;

.field private running:Z

.field private final runningSemaphore:Ljava/util/concurrent/Semaphore;

.field private sendThread:Ljava/lang/Thread;

.field private senderFuture:Ljava/util/concurrent/Future;

.field private threadName:Ljava/lang/String;

.field private tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v0, ".assl..erdstnptlcn.aaenqgentimiocttnlt.nrn.otomc."

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v1, "esemnSCrsom"

    const-string v1, "SesnmdsreCo"

    const/4 v3, 0x0

    const-string v1, "CSeeormsomn"

    const-string v1, "CommsSender"

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x0

    return-void
.end method

.method public constructor <init>(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/internal/ClientState;Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;Ljava/io/OutputStream;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->running:Z

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->lifecycle:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->sendThread:Ljava/lang/Thread;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    new-instance v0, Ljava/util/concurrent/Semaphore;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/util/concurrent/Semaphore;-><init>(I)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v3, 0x7

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v0, p2, p4}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;-><init>(Lcom/tencent/android/tpns/mqtt/internal/ClientState;Ljava/io/OutputStream;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->out:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object p3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v3, 0x1

    sget-object p2, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {p1}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-interface {p2, p1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->setResourceName(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo p1, "mCsnobeSdrm"

    const-string p1, "edCmsnmormS"

    const/4 v3, 0x5

    const-string/jumbo p1, "serCmouSemd"

    const-string p1, "CommsSender"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo p2, "ind SomprstneioC"

    const-string/jumbo p2, "snndotS momreiCi"

    const/4 v3, 0x3

    const-string/jumbo p2, "s SneireqCtdimmo"

    const-string/jumbo p2, "init CommsSender"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p1, p2}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method private handleRunException(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Ljava/lang/Exception;)V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@~s bi@~  @~y@ ~@ tn~~@fb@  daf-@ Mt@~l~~ ~ u~l4cio ~@~@ ~@@ ~/.~ov~~~ ~@i@S1~o@K  @@@sb omor~@o"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x0

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string/jumbo v1, "senmbroCmme"

    const-string v1, "dCrembnsemo"

    const/4 v7, 0x4

    const-string v1, "CmeeomsdSro"

    const-string v1, "CommsSender"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string/jumbo v2, "xludubonnthiceEeRn"

    const-string v2, "eEltdnuhpinxRecuon"

    const/4 v7, 0x0

    const-string v2, "dclnuxuepiRenthnEa"

    const-string v2, "handleRunException"

    const/4 v7, 0x4

    const-string v3, "084"

    const-string v3, "840"

    const/4 v7, 0x6

    const-string v3, "480"

    const-string v3, "804"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/4 v4, 0x0

    move-object v5, p2

    move-object v5, p2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-interface/range {v0 .. v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    instance-of p1, p2, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-nez p1, :cond_0

    const/4 v7, 0x0

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v7, 0x6

    const/16 v0, 0x7d6d

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-direct {p1, v0, p2}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(ILjava/lang/Throwable;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    move-object p1, p2

    move-object p1, p2

    move-object p1, p2

    const/4 v7, 0x1

    const/4 v6, 0x7

    check-cast p1, Lcom/tencent/android/tpns/mqtt/MqttException;

    :goto_0
    const/4 v7, 0x5

    const/4 p2, 0x5

    const/4 v7, 0x5

    const/4 p2, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    iput-boolean p2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->running:Z

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v0, 0x0

    const/4 v7, 0x0

    invoke-virtual {p2, v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->shutdownConnection(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string/jumbo v0, "pdsnmmCpeSo"

    const-string v0, "edCoSsmpnme"

    const/4 v7, 0x0

    const-string/jumbo v0, "mCSremnoqed"

    const-string v0, "CommsSender"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string v2, " essahdNleeeee  tsd,ee ra penoRnt u:qtramhgsrrvmsso"

    const-string v2, "el dsee q,dsnsoeRaat hem: reeaersNvtme shrg t onupr"

    const-string/jumbo v2, "rdamneo o erpuh ohsenmst,t :a e astserese grNevdeml"

    const-string v2, "Run loop sender messages to the server, threadName:"

    const/4 v7, 0x3

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->threadName:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v0, v1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->sendThread:Ljava/lang/Thread;

    const/4 v7, 0x4

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->threadName:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->acquire()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_3

    const/4 v7, 0x7

    const/4 v1, 0x7

    const/4 v7, 0x1

    const/4 v1, 0x0

    :cond_0
    :goto_0
    :try_start_1
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-boolean v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->running:Z

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-eqz v2, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->out:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v2, :cond_4

    :try_start_2
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->get()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz v1, :cond_3

    const/4 v6, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string/jumbo v2, "msCoomeSrde"

    const-string/jumbo v2, "mdsroemSseC"

    const/4 v7, 0x4

    const-string v2, "SmnCrbsdmeo"

    const-string v2, "CommsSender"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo v4, "ssaemeu:"

    const-string v4, "emsm:esa"

    const/4 v7, 0x4

    const-string v4, "easgme:p"

    const-string/jumbo v4, "message:"

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v2, v3}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    instance-of v2, v1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz v2, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->out:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v2, v1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->write(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->out:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->flush()V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    goto/16 :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v2, v1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->getToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz v2, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    monitor-enter v2
    :try_end_2
    .catch Lcom/tencent/android/tpns/mqtt/MqttException; {:try_start_2 .. :try_end_2} :catch_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_1
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :try_start_3
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->out:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v3, v1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->write(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->out:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttOutputStream;->flush()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    goto :goto_1

    :catch_0
    move-exception v3

    :try_start_5
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    instance-of v4, v1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttDisconnect;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v4, :cond_2

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v3, v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifySent(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    monitor-exit v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto/16 :goto_0

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    throw v3

    :catchall_0
    move-exception v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    monitor-exit v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :try_start_6
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    throw v3

    :cond_3
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string/jumbo v3, "oomnSdseqCm"

    const-string v3, "edonomsCemS"

    const/4 v7, 0x2

    const-string v3, "CdsmSrmnoes"

    const-string v3, "CommsSender"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const-string/jumbo v4, "nru"

    const-string/jumbo v4, "urn"

    const/4 v7, 0x1

    const-string/jumbo v4, "urn"

    const-string/jumbo v4, "run"

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string v5, "830"

    const-string v5, "803"

    const/4 v7, 0x0

    const-string v5, "083"

    const-string v5, "803"

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-interface {v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->running:Z
    :try_end_6
    .catch Lcom/tencent/android/tpns/mqtt/MqttException; {:try_start_6 .. :try_end_6} :catch_2
    .catch Ljava/lang/Exception; {:try_start_6 .. :try_end_6} :catch_1
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto/16 :goto_0

    :catch_1
    move-exception v2

    :try_start_7
    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-direct {p0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->handleRunException(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Ljava/lang/Exception;)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    goto/16 :goto_0

    :catch_2
    move-exception v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-direct {p0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->handleRunException(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Ljava/lang/Exception;)V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto/16 :goto_0

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->running:Z

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/util/concurrent/Semaphore;->release()V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v1, "eSommneCmdb"

    const-string/jumbo v1, "mSmdnbreoeC"

    const/4 v7, 0x4

    const-string v1, "SrsCoemmden"

    const-string v1, "CommsSender"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v2, "rnu"

    const-string/jumbo v2, "urn"

    const/4 v7, 0x4

    const-string/jumbo v2, "urn"

    const-string/jumbo v2, "run"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string v3, "058"

    const-string v3, "805"

    const/4 v7, 0x7

    const-string v3, "850"

    const-string v3, "805"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-interface {v0, v1, v2, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    shl-int/2addr v7, v6

    return-void

    :catchall_1
    move-exception v1

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->running:Z

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/util/concurrent/Semaphore;->release()V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    throw v1

    :catch_3
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->running:Z

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    return-void
.end method

.method public start(Ljava/lang/String;Ljava/util/concurrent/ExecutorService;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->threadName:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->lifecycle:Ljava/lang/Object;

    const/4 v2, 0x6

    monitor-enter p1

    :try_start_0
    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->running:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->running:Z

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-interface {p2, p0}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->senderFuture:Ljava/util/concurrent/Future;

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    monitor-exit p1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void

    :catchall_0
    move-exception p2

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    throw p2
.end method

.method public stop()V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->lifecycle:Ljava/lang/Object;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->senderFuture:Ljava/util/concurrent/Future;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 v2, 0x1

    const/4 v6, 0x5

    invoke-interface {v1, v2}, Ljava/util/concurrent/Future;->cancel(Z)Z

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string/jumbo v2, "uesnrboCmSe"

    const-string/jumbo v2, "meormSusCne"

    const/4 v6, 0x4

    const-string/jumbo v2, "smnreCudmeo"

    const-string v2, "CommsSender"

    const/4 v5, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v3, "tpso"

    const-string/jumbo v3, "tosp"

    const-string/jumbo v3, "psot"

    const-string/jumbo v3, "stop"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v4, "800"

    const-string v4, "080"

    const/4 v6, 0x2

    const-string v4, "800"

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->running:Z

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    const/4 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    iput-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->running:Z

    const/4 v6, 0x4

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->sendThread:Ljava/lang/Thread;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v6, 0x4

    const/4 v5, 0x3

    if-nez v1, :cond_2

    :goto_0
    :try_start_1
    const/4 v6, 0x2

    const/4 v5, 0x2

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->running:Z

    const/4 v6, 0x4

    if-eqz v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifyQueueLock()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    sget-object v2, Ljava/util/concurrent/TimeUnit;->MILLISECONDS:Ljava/util/concurrent/TimeUnit;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-wide/16 v3, 0x64

    const/4 v6, 0x7

    const-wide/16 v3, 0x64

    const-wide/16 v3, 0x64

    const/4 v6, 0x7

    invoke-virtual {v1, v3, v4, v2}, Ljava/util/concurrent/Semaphore;->tryAcquire(JLjava/util/concurrent/TimeUnit;)Z
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->release()V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_2

    :catchall_0
    move-exception v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v2}, Ljava/util/concurrent/Semaphore;->release()V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    throw v1

    :catch_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto :goto_1

    :cond_2
    :goto_2
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->sendThread:Ljava/lang/Thread;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsSender;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v5, 0x1

    or-int/2addr v6, v5

    const-string/jumbo v2, "mCmsreepSod"

    const/4 v6, 0x6

    const-string v2, "CommsSender"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const-string/jumbo v3, "post"

    const-string/jumbo v3, "ptso"

    const/4 v6, 0x5

    const-string/jumbo v3, "ptos"

    const-string/jumbo v3, "stop"

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string v4, "180"

    const-string v4, "801"

    const/4 v6, 0x5

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    monitor-exit v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    return-void

    :catchall_1
    move-exception v1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    throw v1
.end method
