.class public Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "CommsReceiver"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

.field private clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

.field private in:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;

.field private lifecycle:Ljava/lang/Object;

.field private recThread:Ljava/lang/Thread;

.field private receiverFuture:Ljava/util/concurrent/Future;

.field private volatile receiving:Z

.field private running:Z

.field private final runningSemaphore:Ljava/util/concurrent/Semaphore;

.field private threadName:Ljava/lang/String;

.field private tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v0, "cnsidm.ilspncoteclnea.t..nrlgnttsar.aen.notqmts.t"

    const-string v0, "gasttmt.n.cende.sp.ai.c.ilorn.aetnstntnrmnlqcldot"

    const/4 v3, 0x7

    const-string v0, "ectmto.nmmiorpettncn.qr.ls.nlaontndnidt.actlag..e"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string/jumbo v1, "roevoimceRmsm"

    const-string v1, "eCRmmsoecivrm"

    const/4 v3, 0x5

    const-string/jumbo v1, "oveecbReimCsm"

    const-string v1, "CommsReceiver"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void
.end method

.method public constructor <init>(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/internal/ClientState;Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;Ljava/io/InputStream;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->running:Z

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->lifecycle:Ljava/lang/Object;

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x5

    and-int/2addr v2, v0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v2, 0x0

    move v3, v2

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->recThread:Ljava/lang/Thread;

    const/4 v3, 0x2

    new-instance v0, Ljava/util/concurrent/Semaphore;

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Ljava/util/concurrent/Semaphore;-><init>(I)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v0, p2, p4}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;-><init>(Lcom/tencent/android/tpns/mqtt/internal/ClientState;Ljava/io/InputStream;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->in:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v3, 0x3

    const/4 v2, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object p3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object p2, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-interface {p1}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-interface {p2, p1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->setResourceName(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo p1, "rmCiveuRmcsee"

    const-string p1, "CommsReceiver"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo p2, "ieecrtvpeRooiin mC"

    const-string/jumbo p2, "viisoi ReceermntoC"

    const/4 v3, 0x2

    const-string/jumbo p2, "init CommsReceiver"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p1, p2}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "t~c~~~ ~q@@i lS uo~@@@o@M ~~a~~~v~b io1o@ ~@~  ~@ @@@y@ o @@@milK ~ ~sf//b-@ ~o ~b4@~@ t~.nr~df "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x6

    const-string/jumbo v0, "vesiscmCemRbr"

    const-string/jumbo v0, "ieecsbRemmCrv"

    const/4 v8, 0x4

    const-string/jumbo v0, "orCmmievesecm"

    const-string v0, "CommsReceiver"

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string/jumbo v2, "mssvommgrs pruhast:t eoereeeN v aeo,nrceeRe rtou hfdo ae "

    const-string/jumbo v2, "rmoeafuorv:,ecet Rh tavrlpgraNrsessm utdseee  ohm n eeoe "

    const/4 v8, 0x5

    const-string/jumbo v2, "roNstb ecaeResvmhaeeereasfvt onme rmeip uhe  rr dltgo,o :"

    const-string v2, "Run loop to receive messages from the server, threadName:"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->threadName:Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {v0, v1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->recThread:Ljava/lang/Thread;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->threadName:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v0, 0x0

    const/4 v8, 0x1

    xor-int/2addr v7, v0

    :try_start_0
    const/4 v8, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v8, 0x5

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->acquire()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-boolean v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->running:Z

    const/4 v8, 0x3

    if-eqz v2, :cond_7

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->in:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eqz v2, :cond_7

    :try_start_1
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string/jumbo v3, "vmeeCeusoimRp"

    const-string v3, "CveemeoprismR"

    const/4 v8, 0x1

    const-string v3, "cmsReCopeevrm"

    const-string v3, "CommsReceiver"

    const/4 v8, 0x7

    const-string/jumbo v4, "unr"

    const-string/jumbo v4, "unr"

    const/4 v8, 0x2

    const-string/jumbo v4, "run"

    const-string/jumbo v4, "run"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string v5, "258"

    const/4 v8, 0x5

    const-string v5, "285"

    const-string v5, "852"

    const/4 v8, 0x6

    invoke-interface {v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->in:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->available()I

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-lez v3, :cond_0

    const/4 v7, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    const/4 v3, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    goto :goto_1

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    move v3, v0

    move v3, v0

    const/4 v8, 0x1

    move v3, v0

    :goto_1
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    iput-boolean v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->receiving:Z

    const/4 v8, 0x0

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->in:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttInputStream;->readMqttWireMessage()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->receiving:Z

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    if-eqz v3, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    const-string v4, "RseveqciqmerC"

    const-string v4, "emeovecsqiCrR"

    const/4 v8, 0x3

    const-string/jumbo v4, "rCsmisemeeovc"

    const-string v4, "CommsReceiver"

    const/4 v8, 0x6

    const/4 v7, 0x1

    invoke-virtual {v3}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {v4, v5}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    instance-of v4, v3, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    if-eqz v4, :cond_5

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->tokenStore:Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v4, v3}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->getToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-eqz v1, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    monitor-enter v1
    :try_end_1
    .catch Lcom/tencent/android/tpns/mqtt/MqttException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    check-cast v3, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v2, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifyReceivedAck(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    monitor-exit v1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    goto/16 :goto_3

    :catchall_0
    move-exception v2

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    throw v2

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    instance-of v4, v3, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubRec;

    const/4 v8, 0x1

    const/4 v7, 0x5

    if-nez v4, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    instance-of v4, v3, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-nez v4, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    instance-of v3, v3, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubAck;

    if-eqz v3, :cond_3

    const/4 v8, 0x4

    goto :goto_2

    :cond_3
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    new-instance v2, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v3, 0x6

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-direct {v2, v3}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    throw v2

    :cond_4
    :goto_2
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string/jumbo v3, "svememRiCocer"

    const-string v3, "eCscRmeoivmer"

    const/4 v8, 0x2

    const-string v3, "RrcmoiemeovCs"

    const-string v3, "CommsReceiver"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string/jumbo v4, "nur"

    const-string/jumbo v4, "urn"

    const/4 v8, 0x5

    const-string/jumbo v4, "nru"

    const-string/jumbo v4, "run"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string v5, "857"

    const-string v5, "587"

    const/4 v8, 0x5

    const-string v5, "758"

    const-string v5, "857"

    const/4 v8, 0x7

    invoke-interface {v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_3

    :cond_5
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz v3, :cond_6

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v2, v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifyReceivedMsg(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V
    :try_end_3
    .catch Lcom/tencent/android/tpns/mqtt/MqttException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto/16 :goto_3

    :catchall_1
    move-exception v1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    goto/16 :goto_4

    :catch_0
    move-exception v2

    :try_start_4
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    sget-object v3, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v4, "CosembceiRmvr"

    const-string v4, "ersmimcCReove"

    const/4 v8, 0x0

    const-string v4, "RroemeuimCesc"

    const-string v4, "CommsReceiver"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string/jumbo v5, "nur"

    const-string/jumbo v5, "nur"

    const/4 v8, 0x0

    const-string/jumbo v5, "urn"

    const-string/jumbo v5, "run"

    const/4 v8, 0x0

    const-string v6, "835"

    const-string v6, "385"

    const/4 v8, 0x4

    const-string v6, "853"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-interface {v3, v4, v5, v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->running:Z

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v3}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->isDisconnecting()Z

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-nez v3, :cond_6

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    new-instance v4, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/16 v5, 0x7d6d

    const/4 v8, 0x1

    invoke-direct {v4, v5, v2}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(ILjava/lang/Throwable;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v3, v1, v4}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->shutdownConnection(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v7, 0x3

    and-int/2addr v8, v7

    goto :goto_3

    :catch_1
    move-exception v2

    const/4 v8, 0x5

    const/4 v7, 0x5

    const-string/jumbo v3, "oesRmrcpmeCei"

    const-string v3, "eremoCcviRsem"

    const/4 v8, 0x0

    const-string v3, "eCioecrmqmves"

    const-string v3, "CommsReceiver"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const-string/jumbo v4, "rnu"

    const-string/jumbo v4, "rnu"

    const/4 v8, 0x5

    const-string/jumbo v4, "unr"

    const-string/jumbo v4, "run"

    const/4 v8, 0x2

    const/4 v7, 0x1

    invoke-static {v3, v4, v2}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->running:Z

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v3, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->shutdownConnection(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :cond_6
    :goto_3
    const/4 v8, 0x7

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->receiving:Z

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v8, 0x6

    const/4 v7, 0x3

    invoke-virtual {v2}, Ljava/util/concurrent/Semaphore;->release()V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    goto/16 :goto_0

    :goto_4
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->receiving:Z

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v0}, Ljava/util/concurrent/Semaphore;->release()V

    throw v1

    :cond_7
    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x5

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string v1, "eosemirbCecRv"

    const-string/jumbo v1, "omevebmieCrRc"

    const/4 v8, 0x5

    const-string v1, "RoemCcrsvimee"

    const-string v1, "CommsReceiver"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string/jumbo v2, "rnu"

    const-string/jumbo v2, "nur"

    const/4 v8, 0x2

    const-string/jumbo v2, "nru"

    const-string/jumbo v2, "run"

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    const-string v3, "845"

    const-string v3, "485"

    const-string v3, "458"

    const-string v3, "854"

    const/4 v8, 0x3

    const/4 v7, 0x2

    invoke-interface {v0, v1, v2, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-void

    :catch_2
    const/4 v8, 0x4

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->running:Z

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    return-void
.end method

.method public isReceiving()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->receiving:Z

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    return v0
.end method

.method public isRunning()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->running:Z

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method public start(Ljava/lang/String;Ljava/util/concurrent/ExecutorService;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->threadName:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const-string/jumbo v0, "oeCiommuevRse"

    const-string v0, "ceeCovumRiems"

    const/4 v4, 0x2

    const-string/jumbo v0, "mesocbeirmCRe"

    const-string v0, "CommsReceiver"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string/jumbo v1, "sutpr"

    const-string/jumbo v1, "rsptt"

    const/4 v4, 0x0

    const-string/jumbo v1, "trpsa"

    const-string/jumbo v1, "start"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string v2, "855"

    const-string v2, "855"

    const/4 v4, 0x7

    const-string v2, "855"

    const-string v2, "855"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {p1, v0, v1, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->lifecycle:Ljava/lang/Object;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    monitor-enter p1

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->running:Z

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->running:Z

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-interface {p2, p0}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->receiverFuture:Ljava/util/concurrent/Future;

    :cond_0
    const/4 v4, 0x4

    monitor-exit p1

    const/4 v4, 0x5

    return-void

    :catchall_0
    move-exception p2

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    throw p2
.end method

.method public stop()V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->lifecycle:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->receiverFuture:Ljava/util/concurrent/Future;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-interface {v1, v2}, Ljava/util/concurrent/Future;->cancel(Z)Z

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string v2, "ComeereRqicms"

    const-string/jumbo v2, "mRoCiemsqcere"

    const-string/jumbo v2, "rmsvoRceeeims"

    const-string v2, "CommsReceiver"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string/jumbo v3, "ptos"

    const-string/jumbo v3, "tsop"

    const/4 v6, 0x1

    const-string/jumbo v3, "tpos"

    const-string/jumbo v3, "stop"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string v4, "850"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->running:Z

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v1, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    iput-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->running:Z

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    iput-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->receiving:Z

    const/4 v6, 0x1

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->recThread:Ljava/lang/Thread;

    const/4 v5, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v1, :cond_1

    :try_start_1
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->acquire()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->release()V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto :goto_1

    :catchall_0
    move-exception v1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v2}, Ljava/util/concurrent/Semaphore;->release()V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    throw v1

    :catch_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v5, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x7

    const/4 v0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->recThread:Ljava/lang/Thread;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x1

    const-string v1, "RcsmimoevCsre"

    const-string v1, "erseCiomRcvse"

    const/4 v6, 0x5

    const-string/jumbo v1, "remeoeiomsRcC"

    const-string v1, "CommsReceiver"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string/jumbo v2, "pots"

    const-string/jumbo v2, "sopt"

    const/4 v6, 0x2

    const-string/jumbo v2, "stop"

    const-string/jumbo v2, "stop"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v3, "518"

    const-string v3, "581"

    const/4 v6, 0x3

    const-string v3, "518"

    const-string v3, "851"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v0, v1, v2, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-void

    :catchall_1
    move-exception v1

    :try_start_3
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    throw v1
.end method
