.class public Lcom/tencent/android/tpns/mqtt/internal/ClientDefaults;
.super Ljava/lang/Object;


# static fields
.field public static final MAX_MSG_SIZE:I = 0x10000000


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method
