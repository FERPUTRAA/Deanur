.class public Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;
.super Ljava/lang/Object;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "CommsTokenStore"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private closedResponse:Lcom/tencent/android/tpns/mqtt/MqttException;

.field private logContext:Ljava/lang/String;

.field private tokens:Ljava/util/Hashtable;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v0, "..sntac.aginandtq.ctdeo.onnstlelmps.tmnntei.torcr"

    const-string/jumbo v0, "nlsptmdtnsenagcm.dt.l.ccartenoinr.toetano.qi.sn.t"

    const/4 v3, 0x5

    const-string/jumbo v0, "mnamtncttrlolgsnoc.o.qttcmtee.ntdeair..n.ps.ianln"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const-string/jumbo v1, "momroSekTooCmts"

    const-string/jumbo v1, "oTemkmorteCoSsm"

    const/4 v3, 0x5

    const-string/jumbo v1, "mtmoebroskoTneC"

    const-string v1, "CommsTokenStore"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x0

    move v4, v0

    const/4 v3, 0x5

    move v4, v3

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->closedResponse:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {v0, p1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->setResourceName(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v1, Ljava/util/Hashtable;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/util/Hashtable;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->logContext:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo p1, "uIonit"

    const-string p1, "<Intoi"

    const-string/jumbo p1, "ipt>nI"

    const-string p1, "<Init>"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string v1, "830"

    const-string v1, "830"

    const/4 v4, 0x7

    const-string v1, "083"

    const-string v1, "308"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v2, "otrTmenoqsmekbo"

    const-string v2, "TtrnebsoemoCkmo"

    const/4 v4, 0x3

    const-string v2, "CeseommnkSosrto"

    const-string v2, "CommsTokenStore"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {v0, v2, p1, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public clear()V
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x6

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string/jumbo v1, "oemmsekTntrSooC"

    const-string v1, "CommsTokenStore"

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string v2, "ecrao"

    const-string/jumbo v2, "rueca"

    const-string v2, "brace"

    const-string v2, "clear"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string v3, "305"

    const-string v3, "530"

    const/4 v8, 0x2

    const-string v3, "530"

    const-string v3, "305"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v4, 0x1

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v7, 0x6

    and-int/2addr v8, v7

    new-instance v5, Ljava/lang/Integer;

    const/4 v8, 0x0

    iget-object v6, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v6}, Ljava/util/Hashtable;->size()I

    move-result v6

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-direct {v5, v6}, Ljava/lang/Integer;-><init>(I)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    const/4 v6, 0x0

    const/4 v8, 0x7

    aput-object v5, v4, v6

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-interface {v0, v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v1}, Ljava/util/Hashtable;->clear()V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    monitor-exit v0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    return-void

    :catchall_0
    move-exception v1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    throw v1
.end method

.method public count()I
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/util/Hashtable;->size()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    monitor-exit v0

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    return v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    throw v1
.end method

.method public getOutstandingDelTokens()[Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x6

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x0

    const-string v2, "ekroosepSCmmtoT"

    const-string v2, "eesmSmunTtorCok"

    const-string v2, "CommsTokenStore"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const-string/jumbo v3, "nageetOpoennDstiTuqgtld"

    const-string v3, "eTtentkgquinoDsenlOatdg"

    const/4 v6, 0x4

    const-string v3, "getOutstandingDelTokens"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string v4, "113"

    const-string v4, "131"

    const/4 v6, 0x6

    const-string v4, "113"

    const-string v4, "311"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    new-instance v1, Ljava/util/Vector;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {v1}, Ljava/util/Vector;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v2}, Ljava/util/Hashtable;->elements()Ljava/util/Enumeration;

    move-result-object v2

    :cond_0
    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-interface {v2}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz v3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {v2}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    check-cast v3, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x2

    instance-of v4, v3, Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    const/4 v5, 0x0

    move v6, v5

    if-eqz v4, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x2

    iget-object v4, v3, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v4}, Lcom/tencent/android/tpns/mqtt/internal/Token;->isNotified()Z

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-nez v4, :cond_0

    const/4 v5, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1, v3}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-array v2, v2, [Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Ljava/util/Vector;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    check-cast v1, [Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v6, 0x3

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    throw v1
.end method

.method public getOutstandingTokens()Ljava/util/Vector;
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const-string v2, "TeomsnstqrComeo"

    const-string v2, "eesorkoCnTmsotm"

    const/4 v6, 0x6

    const-string/jumbo v2, "tosomkmneToseCr"

    const-string v2, "CommsTokenStore"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string/jumbo v3, "ntnmgOmTgtaeudtsokni"

    const-string/jumbo v3, "tOimsegaontTutkndsgn"

    const-string v3, "dueOotssakonneigttgn"

    const-string v3, "getOutstandingTokens"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string v4, "213"

    const-string v4, "123"

    const/4 v6, 0x6

    const-string v4, "123"

    const-string v4, "312"

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v1, Ljava/util/Vector;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {v1}, Ljava/util/Vector;-><init>()V

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/util/Hashtable;->elements()Ljava/util/Enumeration;

    move-result-object v2

    :cond_0
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-interface {v2}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-interface {v2}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    check-cast v3, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v5, 0x1

    move v6, v5

    if-eqz v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v1, v3}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    throw v1
.end method

.method public getToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getKey()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    check-cast p1, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p1
.end method

.method public getToken(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/MqttToken;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x6

    check-cast p1, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p1
.end method

.method public open()V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v6, 0x1

    monitor-enter v0

    :try_start_0
    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string/jumbo v2, "oonCkbreetSTsmo"

    const-string/jumbo v2, "seoCookTonmrtSe"

    const/4 v6, 0x7

    const-string/jumbo v2, "meokerutoSTmsno"

    const-string v2, "CommsTokenStore"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const-string v3, "epno"

    const/4 v6, 0x0

    const-string/jumbo v3, "peon"

    const-string/jumbo v3, "open"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string v4, "031"

    const-string v4, "130"

    const/4 v6, 0x1

    const-string v4, "130"

    const-string v4, "310"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v1, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->closedResponse:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-void

    :catchall_0
    move-exception v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    throw v1
.end method

.method protected quiesce(Lcom/tencent/android/tpns/mqtt/MqttException;)V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    const-string/jumbo v2, "sonSerkpCTotmom"

    const-string v2, "CommsTokenStore"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string/jumbo v3, "qqbcuie"

    const-string v3, "eceiubq"

    const/4 v8, 0x7

    const-string v3, "cusqeis"

    const-string/jumbo v3, "quiesce"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string v4, "309"

    const-string v4, "930"

    const/4 v8, 0x3

    const-string v4, "093"

    const-string v4, "309"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x7

    const/4 v5, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x4

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/4 v6, 0x0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    aput-object p1, v5, v6

    const/4 v8, 0x5

    invoke-interface {v1, v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->closedResponse:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    monitor-exit v0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    return-void

    :catchall_0
    move-exception p1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    throw p1
.end method

.method public removeToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)Lcom/tencent/android/tpns/mqtt/MqttToken;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getKey()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->removeToken(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/MqttToken;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p1

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p1
.end method

.method public removeToken(Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/MqttToken;
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x3

    and-int/2addr v6, v5

    aput-object p1, v1, v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v2, "CrmmoSoesuemnkt"

    const-string/jumbo v2, "oCkrmTueSsontme"

    const/4 v6, 0x7

    const-string v2, "TokeonmoomCsSre"

    const-string v2, "CommsTokenStore"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string/jumbo v3, "ookmTbverep"

    const-string v3, "Tvmeerepook"

    const/4 v6, 0x1

    const-string v3, "eoremnueoTk"

    const-string/jumbo v3, "removeToken"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const-string v4, "603"

    const-string v4, "063"

    const/4 v6, 0x1

    const-string v4, "036"

    const-string v4, "306"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-interface {v0, v2, v3, v4, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x0

    if-eqz p1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v5, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Ljava/util/Hashtable;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    check-cast p1, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    return-object p1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    const/4 p1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    return-object p1
.end method

.method protected restoreToken(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;
    .locals 13

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v12, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x1

    new-instance v1, Ljava/lang/Integer;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v2

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-direct {v1, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v12, 0x0

    const/4 v11, 0x6

    invoke-virtual {v1}, Ljava/lang/Integer;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-virtual {v2, v1}, Ljava/util/Hashtable;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x6

    const/4 v3, 0x2

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v12, 0x3

    move v11, v5

    move v11, v5

    const/4 v12, 0x7

    const/4 v6, 0x3

    const/4 v12, 0x4

    shl-int/2addr v11, v6

    const/4 v12, 0x4

    if-eqz v2, :cond_0

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v2, v1}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x2

    check-cast v2, Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x1

    sget-object v7, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x5

    const-string/jumbo v8, "teqmSokpmnrsToe"

    const-string/jumbo v8, "mnoetsSTqkrCome"

    const-string v8, "eomTkmsoqCroten"

    const-string v8, "CommsTokenStore"

    const/4 v12, 0x4

    const/4 v11, 0x1

    const-string v9, "eksetoTonsse"

    const-string/jumbo v9, "okseresontTe"

    const/4 v12, 0x0

    const-string/jumbo v9, "rtomeeserTko"

    const-string/jumbo v9, "restoreToken"

    const/4 v12, 0x0

    const/4 v11, 0x0

    const-string v10, "302"

    const-string v10, "032"

    const/4 v12, 0x6

    const-string v10, "302"

    const-string v10, "302"

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x6

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x6

    aput-object v1, v6, v5

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x0

    aput-object p1, v6, v4

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    aput-object v2, v6, v3

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-interface {v7, v8, v9, v10, v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v12, 0x4

    goto :goto_0

    :cond_0
    const/4 v12, 0x4

    const/4 v11, 0x1

    new-instance v2, Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x1

    iget-object v7, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->logContext:Ljava/lang/String;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-direct {v2, v7}, Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x6

    iget-object v7, v2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {v7, v1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->setKey(Ljava/lang/String;)V

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget-object v7, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {v7, v1, v2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x5

    sget-object v7, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v11, 0x2

    move v12, v11

    const-string/jumbo v8, "reomsnCmtkomeTo"

    const/4 v12, 0x6

    const-string v8, "entrooseomCSTkm"

    const-string v8, "CommsTokenStore"

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x5

    const-string/jumbo v9, "rToetbnksoee"

    const-string/jumbo v9, "stTeooroenke"

    const/4 v12, 0x6

    const-string/jumbo v9, "serTotukeero"

    const-string/jumbo v9, "restoreToken"

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x0

    const-string v10, "033"

    const-string v10, "303"

    const/4 v12, 0x6

    const-string v10, "033"

    const-string v10, "303"

    const/4 v11, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x5

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x3

    aput-object v1, v6, v5

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x4

    aput-object p1, v6, v4

    const/4 v11, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    aput-object v2, v6, v3

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-interface {v7, v8, v9, v10, v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    :goto_0
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x0

    monitor-exit v0

    const/4 v12, 0x4

    return-object v2

    :catchall_0
    move-exception p1

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x1

    throw p1
.end method

.method protected saveToken(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;)V
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->closedResponse:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v9, 0x1

    if-nez v1, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {p2}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getKey()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string v3, "CbtmSneposoerTk"

    const-string/jumbo v3, "krStmbsCnoeToeo"

    const/4 v9, 0x2

    const-string/jumbo v3, "noomeTstqCmrSok"

    const-string v3, "CommsTokenStore"

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    const-string/jumbo v4, "ovsukesTa"

    const-string/jumbo v4, "sTeknouva"

    const/4 v9, 0x6

    const-string v4, "eaTmenvko"

    const-string/jumbo v4, "saveToken"

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string v5, "003"

    const-string v5, "003"

    const/4 v9, 0x7

    const-string v5, "030"

    const-string v5, "300"

    const/4 v8, 0x2

    or-int/2addr v9, v8

    const/4 v6, 0x2

    move v9, v6

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    const/4 v7, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    aput-object v1, v6, v7

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 v7, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    aput-object p2, v6, v7

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-interface {v2, v3, v4, v5, v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p0, p1, v1}, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->saveToken(Lcom/tencent/android/tpns/mqtt/MqttToken;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    monitor-exit v0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    return-void

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    throw v1

    :catchall_0
    move-exception p1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    throw p1
.end method

.method protected saveToken(Lcom/tencent/android/tpns/mqtt/MqttToken;Ljava/lang/String;)V
    .locals 10

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    const-string/jumbo v2, "proSoTmkmstnCee"

    const-string/jumbo v2, "oCtnemSpokrmsTe"

    const/4 v9, 0x3

    const-string v2, "ektsCboeTommrSo"

    const-string v2, "CommsTokenStore"

    const/4 v8, 0x2

    move v9, v8

    const-string v3, "eqoevauks"

    const-string/jumbo v3, "venaskeoq"

    const/4 v9, 0x3

    const-string/jumbo v3, "sekoenvpa"

    const-string/jumbo v3, "saveToken"

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string v4, "703"

    const-string v4, "037"

    const/4 v9, 0x6

    const-string v4, "073"

    const-string v4, "307"

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    const/4 v5, 0x2

    const/4 v8, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    const/4 v6, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    aput-object p2, v5, v6

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    const/4 v7, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    aput-object v6, v5, v7

    const/4 v9, 0x4

    invoke-interface {v1, v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v1, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x0

    const/4 v8, 0x5

    invoke-virtual {v1, p2}, Lcom/tencent/android/tpns/mqtt/internal/Token;->setKey(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v1, p2, p1}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    monitor-exit v0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    throw p1
.end method

.method public toString()Ljava/lang/String;
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string/jumbo v0, "ta.soralqnesep"

    const-string/jumbo v0, "saslpaetron.er"

    const/4 v8, 0x5

    const-string/jumbo v0, "iospt.aselenrr"

    const-string/jumbo v0, "line.separator"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string v1, "/n"

    const-string v1, "/n"

    const/4 v8, 0x1

    const-string v1, "/n"

    const-string v1, "\n"

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {v0, v1}, Ljava/lang/System;->getProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v7, 0x7

    move v8, v7

    monitor-enter v2

    :try_start_0
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsTokenStore;->tokens:Ljava/util/Hashtable;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v3}, Ljava/util/Hashtable;->elements()Ljava/util/Enumeration;

    move-result-object v3

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-interface {v3}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v4

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-eqz v4, :cond_0

    const/4 v8, 0x7

    invoke-interface {v3}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    check-cast v4, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v7, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string/jumbo v6, "{"

    const-string/jumbo v6, "{"

    const/4 v8, 0x3

    const-string/jumbo v6, "{"

    const-string/jumbo v6, "{"

    const/4 v8, 0x5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    iget-object v4, v4, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v8, 0x3

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const-string/jumbo v4, "}"

    const-string/jumbo v4, "}"

    const/4 v8, 0x6

    const-string/jumbo v4, "}"

    const-string/jumbo v4, "}"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    goto :goto_0

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    monitor-exit v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    monitor-exit v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    throw v0
.end method
