.class public abstract Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;
.super Ljava/lang/Object;


# static fields
.field private static INSTANCE:Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public static final getMessage(I)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/ s/~yi@~c@i ~-a1@~~ l~i@@t~ o@f@ ~f@ ~ o~r dou@v~o~~ Kbts  ~m~M@@o4b@ @.~b~ @@~ l@on~@~@ @S~~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;->INSTANCE:Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;

    const/4 v2, 0x1

    move v3, v2

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v0, "java.util.ResourceBundle"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->isClassAvailable(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-class v0, Lcom/tencent/android/tpns/mqtt/internal/ResourceBundleCatalog;

    const-class v0, Lcom/tencent/android/tpns/mqtt/internal/ResourceBundleCatalog;

    const/4 v3, 0x5

    const-class v0, Lcom/tencent/android/tpns/mqtt/internal/ResourceBundleCatalog;

    const-class v0, Lcom/tencent/android/tpns/mqtt/internal/ResourceBundleCatalog;

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    check-cast v0, Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;->INSTANCE:Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :catchall_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v0, "Matmtpslen.onDoPqiCrcitteI.sndc..rtod.ntt.maaalnng"

    const-string v0, "amstDn.eCnr.ieMn..tltaIc.ia.nntaoolgqttrpnetPscdod"

    const/4 v3, 0x2

    const-string/jumbo v0, "plCrotgsnnDcn.t..cidottrad.teennetaMm.P.qtialImoon"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.MIDPCatalog"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->isClassAvailable(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    :try_start_1
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v0, "Do.aebnlMaalctterdsIgnttpmnem.iCo.P.qco..ntinttdnm"

    const-string/jumbo v0, "t.dmtit...aDcoCrtelmn.gntaMnntopceiqlI.omnedntPaas"

    const/4 v3, 0x4

    const-string v0, "gtt.riutmmaliM.cn.n.e.aDttndelPertado.InopqsoncanC"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.MIDPCatalog"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    check-cast v0, Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;->INSTANCE:Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    goto :goto_0

    :catchall_1
    const/4 v3, 0x2

    return-object v1

    :cond_1
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;->INSTANCE:Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, p0}, Lcom/tencent/android/tpns/mqtt/internal/MessageCatalog;->getLocalizedMessage(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object p0
.end method


# virtual methods
.method protected abstract getLocalizedMessage(I)Ljava/lang/String;
.end method
