.class public Lcom/tencent/android/tpns/mqtt/internal/Token;
.super Ljava/lang/Object;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "Token"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private callback:Lcom/tencent/android/tpns/mqtt/IMqttActionListener;

.field private client:Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

.field private volatile completed:Z

.field private exception:Lcom/tencent/android/tpns/mqtt/MqttException;

.field private key:Ljava/lang/String;

.field protected message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

.field private messageID:I

.field private notified:Z

.field private pendingComplete:Z

.field private response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

.field private responseLock:Ljava/lang/Object;

.field private sent:Z

.field private sentLock:Ljava/lang/Object;

.field private topics:[Ljava/lang/String;

.field private userContext:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string v0, "dnsrtne.lt.cdomtstta.sclneo.ns.ngi.m.locqrnitaean"

    const-string/jumbo v0, "nnsemt.aealld.om.epcnc.otnnr.giadoli.tcrnsttntq.s"

    const/4 v3, 0x2

    const-string v0, "crcmets.rsmcmaa.d.i.qldptooinn.ta.ttlnonn.tetgenl"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v1, "omTko"

    const-string/jumbo v1, "oeTmk"

    const/4 v3, 0x7

    const-string v1, "bokeT"

    const-string v1, "Token"

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/Token;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 4

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->completed:Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->pendingComplete:Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->sent:Z

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v1, Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->responseLock:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance v1, Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->sentLock:Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->topics:[Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->client:Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->callback:Lcom/tencent/android/tpns/mqtt/IMqttActionListener;

    const/4 v2, 0x4

    and-int/2addr v3, v2

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->userContext:Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->messageID:I

    const/4 v3, 0x6

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->notified:Z

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/Token;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-interface {v0, p1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->setResourceName(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method


# virtual methods
.method public checkResult()Z
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~@ uiu @~/ oob~~l@~i@@tl @~o  @-v~o ~K@ ~1nS@@ ~ o@.~f s @@~4@@bt ~~ ~ ob/fdc@~my@~@a@~ @~i~M ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getException()Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    return v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getException()Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    throw v0
.end method

.method public getActionCallback()Lcom/tencent/android/tpns/mqtt/IMqttActionListener;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->callback:Lcom/tencent/android/tpns/mqtt/IMqttActionListener;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->client:Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method public getException()Lcom/tencent/android/tpns/mqtt/MqttException;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v1, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public getGrantedQos()[I
    .locals 5

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-array v0, v0, [I

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    instance-of v2, v1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSuback;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    check-cast v1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSuback;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttSuback;->getGrantedQos()[I

    move-result-object v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object v0
.end method

.method public getKey()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->key:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    return-object v0
.end method

.method public getMessageID()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->messageID:I

    const/4 v1, 0x0

    move v2, v1

    return v0
.end method

.method public getResponse()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v2, 0x6

    return-object v0
.end method

.method public getSessionPresent()Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    instance-of v1, v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttConnack;->getSessionPresent()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v0
.end method

.method public getTopics()[Ljava/lang/String;
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->topics:[Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public getUserContext()Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->userContext:Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-object v0
.end method

.method public getWireMessage()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public isComplete()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->completed:Z

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method protected isCompletePending()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->pendingComplete:Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method protected isInUse()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->isComplete()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return v0
.end method

.method public isNotified()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->notified:Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    return v0
.end method

.method protected markComplete(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttException;)V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/Token;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string/jumbo v1, "kTpoe"

    const-string v1, "Teoko"

    const-string/jumbo v1, "knoqT"

    const-string v1, "Token"

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string v2, "arsmbCopmlke"

    const-string v2, "aCeembmoplkr"

    const/4 v8, 0x2

    const-string/jumbo v2, "ltrmekCpmaeo"

    const-string/jumbo v2, "markComplete"

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    const-string v3, "404"

    const-string v3, "440"

    const/4 v8, 0x1

    const-string v3, "404"

    const-string v3, "404"

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v4, 0x3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x2

    aput-object v6, v4, v5

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    const/4 v5, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    aput-object p1, v4, v5

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/4 v6, 0x2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    aput-object p2, v4, v6

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-interface {v0, v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->responseLock:Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    instance-of v1, p1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttAck;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-eqz v1, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/4 v1, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x1

    iput-boolean v5, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->pendingComplete:Z

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    monitor-exit v0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    return-void

    :catchall_0
    move-exception p1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    throw p1
.end method

.method protected notifyComplete()V
    .locals 11

    const/4 v10, 0x1

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/Token;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    const-string v1, "ekuoo"

    const-string v1, "Tueko"

    const/4 v10, 0x2

    const-string v1, "bTkne"

    const-string v1, "Token"

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    const-string/jumbo v2, "lpyminueCftoot"

    const-string/jumbo v2, "tylmifepnCoopt"

    const/4 v10, 0x7

    const-string/jumbo v2, "toleCfppmiytne"

    const-string/jumbo v2, "notifyComplete"

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    const-string v3, "404"

    const-string v3, "440"

    const/4 v10, 0x2

    const-string v3, "440"

    const-string v3, "404"

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 v4, 0x3

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x6

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/4 v6, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    aput-object v5, v4, v6

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object v5, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x4

    const/4 v7, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    aput-object v5, v4, v7

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    const/4 v5, 0x2

    const/4 v10, 0x0

    iget-object v8, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v10, 0x1

    const/4 v9, 0x1

    aput-object v8, v4, v5

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-interface {v0, v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->responseLock:Ljava/lang/Object;

    const/4 v10, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    if-nez v1, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->pendingComplete:Z

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-eqz v1, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    iput-boolean v7, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->completed:Z

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    iput-boolean v6, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->pendingComplete:Z

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x5

    goto :goto_0

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x5

    iput-boolean v6, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->pendingComplete:Z

    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->responseLock:Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    const/4 v9, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->sentLock:Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x1

    monitor-enter v1

    :try_start_1
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    iput-boolean v7, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->sent:Z

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->sentLock:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    const/4 v10, 0x5

    const/4 v9, 0x3

    monitor-exit v1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    return-void

    :catchall_0
    move-exception v0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x6

    const/4 v9, 0x4

    throw v0

    :catchall_1
    move-exception v1

    :try_start_2
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    throw v1
.end method

.method protected notifySent()V
    .locals 10

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/Token;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    const-string v1, "Tenqk"

    const-string/jumbo v1, "knTqe"

    const/4 v9, 0x6

    const-string v1, "Token"

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string/jumbo v2, "sisfnynoSe"

    const-string/jumbo v2, "itsnySfnoe"

    const/4 v9, 0x1

    const-string/jumbo v2, "ifomntSnty"

    const-string/jumbo v2, "notifySent"

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string v3, "430"

    const-string v3, "043"

    const/4 v9, 0x0

    const-string v3, "304"

    const-string v3, "403"

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    new-array v5, v4, [Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v7, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    aput-object v6, v5, v7

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-interface {v0, v1, v2, v3, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->responseLock:Ljava/lang/Object;

    const/4 v9, 0x4

    monitor-enter v0

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x1

    const/4 v1, 0x0

    :try_start_0
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v9, 0x5

    iput-boolean v7, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->completed:Z

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->sentLock:Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    monitor-enter v1

    :try_start_1
    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    iput-boolean v4, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->sent:Z

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->sentLock:Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    monitor-exit v1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    return-void

    :catchall_0
    move-exception v0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x1

    move v9, v8

    throw v0

    :catchall_1
    move-exception v1

    :try_start_2
    const/4 v9, 0x3

    const/4 v8, 0x4

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    throw v1
.end method

.method public reset()V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->isInUse()Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-nez v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/Token;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v3, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    aput-object v2, v1, v3

    const/4 v6, 0x0

    const/4 v6, 0x6

    const-string/jumbo v2, "komTo"

    const-string/jumbo v2, "kTome"

    const/4 v7, 0x6

    const-string v2, "bonkT"

    const-string v2, "Token"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string/jumbo v4, "surte"

    const-string/jumbo v4, "reset"

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string v5, "140"

    const-string v5, "041"

    const/4 v7, 0x7

    const-string v5, "104"

    const-string v5, "410"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-interface {v0, v2, v4, v5, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->client:Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput-boolean v3, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->completed:Z

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v7, 0x0

    const/4 v6, 0x3

    iput-boolean v3, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->sent:Z

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v7, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->userContext:Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v7, 0x3

    return-void

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/16 v1, 0x7dc9

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-direct {v0, v1}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    throw v0
.end method

.method public setActionCallback(Lcom/tencent/android/tpns/mqtt/IMqttActionListener;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->callback:Lcom/tencent/android/tpns/mqtt/IMqttActionListener;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method protected setClient(Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->client:Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    const/4 v1, 0x3

    return-void
.end method

.method public setException(Lcom/tencent/android/tpns/mqtt/MqttException;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->responseLock:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    monitor-exit v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void

    :catchall_0
    move-exception p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    throw p1
.end method

.method public setKey(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->key:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public setMessage(Lcom/tencent/android/tpns/mqtt/MqttMessage;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->message:Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public setMessageID(I)V
    .locals 2

    const/4 v1, 0x4

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->messageID:I

    const/4 v1, 0x7

    return-void
.end method

.method public setNotified(Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->notified:Z

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public setTopics([Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->topics:[Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void
.end method

.method public setUserContext(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->userContext:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v3, 0x0

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v3, 0x1

    move v4, v3

    const-string v1, "ek=y"

    const-string v1, "e=yk"

    const/4 v4, 0x7

    const-string v1, "=yke"

    const-string/jumbo v1, "key="

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo v1, "t=c o,ipo"

    const-string/jumbo v1, "t,c=o oip"

    const/4 v4, 0x5

    const-string/jumbo v1, "ost=ipc q"

    const-string v1, " ,topics="

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getTopics()[Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getTopics()[Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    array-length v2, v2

    const/4 v4, 0x1

    if-ge v1, v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getTopics()[Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    aget-object v2, v2, v1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v2, ", "

    const-string v2, ", "

    const/4 v4, 0x3

    const-string v2, ", "

    const-string v2, ", "

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const-string v1, "ecsr,xts nobte"

    const-string/jumbo v1, "steocbnux e,rt"

    const/4 v4, 0x2

    const-string v1, " ,usercontext="

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getUserContext()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v1, "ieem=Cst opl,"

    const-string v1, " ,isComplete="

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->isComplete()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string/jumbo v1, "it,sooiN=fd e"

    const-string v1, " eodiiu,t=fNs"

    const/4 v4, 0x0

    const-string/jumbo v1, "ii t=bsdo,eNf"

    const-string v1, " ,isNotified="

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->isNotified()Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Z)Ljava/lang/StringBuffer;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v1, "tp niouee,x="

    const-string v1, "cee=nt,p xoi"

    const-string v1, "cxee=ptpno i"

    const-string v1, " ,exception="

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getException()Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v1, "k,qtacanqclcl= ib"

    const-string/jumbo v1, "lbac laiqkt,ccna="

    const/4 v4, 0x2

    const-string v1, " ,silcoa=aactlbnk"

    const-string v1, " ,actioncallback="

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getActionCallback()Lcom/tencent/android/tpns/mqtt/IMqttActionListener;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/Object;)Ljava/lang/StringBuffer;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    return-object v0
.end method

.method public waitForCompletion()V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {p0, v0, v1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->waitForCompletion(J)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method public waitForCompletion(J)V
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/Token;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    const/4 v1, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    aput-object v3, v1, v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    new-instance v2, Ljava/lang/Long;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {v2, p1, p2}, Ljava/lang/Long;-><init>(J)V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    aput-object v2, v1, v3

    const/4 v5, 0x1

    move v6, v5

    const/4 v2, 0x2

    const/4 v2, 0x2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    aput-object p0, v1, v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v2, "kenms"

    const-string/jumbo v2, "nosek"

    const/4 v6, 0x2

    const-string v2, "Tekoo"

    const-string v2, "Token"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string/jumbo v3, "mriCobptmenaFlitw"

    const-string/jumbo v3, "tCimamiFlpwoonret"

    const/4 v6, 0x2

    const-string/jumbo v3, "tipieoualtoornCFw"

    const-string/jumbo v3, "waitForCompletion"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const-string v4, "047"

    const-string v4, "407"

    const/4 v6, 0x4

    const-string v4, "740"

    const-string v4, "407"

    const/4 v6, 0x5

    invoke-interface {v0, v2, v3, v4, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p0, p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/Token;->waitForResponse(J)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-nez p1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->completed:Z

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz p1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string/jumbo p1, "ntoCotipet meatmFopuliooi"

    const-string/jumbo p1, "neioopimwiouomttFo latteC"

    const-string p1, "e pitoimqtwmunCFooaoltter"

    const-string/jumbo p1, "waitForCompletion timeout"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v2, p1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/16 p2, 0x7d00

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {p1, p2}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(I)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v6, 0x3

    const/4 v5, 0x6

    throw p1

    :cond_1
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->checkResult()Z

    const/4 v5, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    return-void
.end method

.method protected waitForResponse()Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x2

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0, v0, v1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->waitForResponse(J)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0
.end method

.method protected waitForResponse(J)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;
    .locals 20
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-wide/from16 v2, p1

    iget-object v4, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->responseLock:Ljava/lang/Object;

    monitor-enter v4

    :try_start_0
    sget-object v5, Lcom/tencent/android/tpns/mqtt/internal/Token;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const-string v6, "bnskT"

    const-string v6, "bTnke"

    const-string/jumbo v6, "neomT"

    const-string v6, "Token"

    const-string/jumbo v7, "rouaoiRtepsnosF"

    const-string/jumbo v7, "sisortuoeeFRapn"

    const-string v7, "etFnwbseooRpasr"

    const-string/jumbo v7, "waitForResponse"

    const-string v8, "004"

    const-string v8, "004"

    const-string v8, "004"

    const-string v8, "400"

    const/4 v0, 0x7

    new-array v9, v0, [Ljava/lang/Object;

    invoke-virtual/range {p0 .. p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    aput-object v0, v9, v11

    new-instance v0, Ljava/lang/Long;

    invoke-direct {v0, v2, v3}, Ljava/lang/Long;-><init>(J)V

    const/4 v12, 0x1

    aput-object v0, v9, v12

    new-instance v0, Ljava/lang/Boolean;

    iget-boolean v10, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->sent:Z

    invoke-direct {v0, v10}, Ljava/lang/Boolean;-><init>(Z)V

    const/4 v13, 0x2

    aput-object v0, v9, v13

    new-instance v0, Ljava/lang/Boolean;

    iget-boolean v10, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->completed:Z

    invoke-direct {v0, v10}, Ljava/lang/Boolean;-><init>(Z)V

    const/4 v10, 0x3

    aput-object v0, v9, v10

    iget-object v10, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    if-nez v10, :cond_0

    const-string v0, "aulpf"

    const-string v0, "fapsl"

    const-string v0, "aepsl"

    const-string v0, "false"

    goto :goto_0

    :cond_0
    const-string/jumbo v0, "ture"

    const-string/jumbo v0, "rute"

    const-string/jumbo v0, "uret"

    const-string/jumbo v0, "true"

    :goto_0
    const/4 v14, 0x4

    aput-object v0, v9, v14

    iget-object v0, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    const/4 v14, 0x5

    aput-object v0, v9, v14

    const/4 v0, 0x6

    aput-object v1, v9, v0

    invoke-interface/range {v5 .. v10}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V

    :cond_1
    iget-boolean v0, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->completed:Z

    if-nez v0, :cond_5

    iget-object v0, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    if-nez v0, :cond_3

    :try_start_1
    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/Token;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const-string v7, "Tkeqq"

    const-string v7, "eTnqk"

    const-string v7, "eoskn"

    const-string v7, "Token"

    const-string/jumbo v8, "ssemrweoapsionR"

    const-string v8, "Rrsnetsosiawope"

    const-string/jumbo v8, "ieFeossonopwtRr"

    const-string/jumbo v8, "waitForResponse"

    const-string v9, "048"

    const-string v9, "840"

    const-string v9, "408"

    new-array v10, v13, [Ljava/lang/Object;

    invoke-virtual/range {p0 .. p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v14

    aput-object v14, v10, v11

    new-instance v14, Ljava/lang/Long;

    invoke-direct {v14, v2, v3}, Ljava/lang/Long;-><init>(J)V

    aput-object v14, v10, v12

    invoke-interface {v0, v7, v8, v9, v10}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    cmp-long v0, v2, v5

    if-gtz v0, :cond_2

    iget-object v0, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->responseLock:Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Object;->wait()V

    goto :goto_1

    :cond_2
    iget-object v0, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->responseLock:Ljava/lang/Object;

    invoke-virtual {v0, v2, v3}, Ljava/lang/Object;->wait(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    :catch_0
    move-exception v0

    :try_start_2
    new-instance v7, Lcom/tencent/android/tpns/mqtt/MqttException;

    invoke-direct {v7, v0}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    iput-object v7, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    :cond_3
    :goto_1
    iget-boolean v0, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->completed:Z

    if-nez v0, :cond_1

    iget-object v0, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    if-nez v0, :cond_4

    cmp-long v0, v2, v5

    if-lez v0, :cond_1

    goto :goto_2

    :cond_4
    sget-object v14, Lcom/tencent/android/tpns/mqtt/internal/Token;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const-string v15, "beonT"

    const-string v15, "eoTmn"

    const-string v15, "eukno"

    const-string v15, "Token"

    const-string v16, "RntpwaopsoisrFo"

    const-string v16, "anstoFpsieRrowo"

    const-string v16, "eaisRoteqowprns"

    const-string/jumbo v16, "waitForResponse"

    const-string v17, "140"

    const-string v17, "041"

    const-string v17, "014"

    const-string v17, "401"

    const/16 v18, 0x0

    move-object/from16 v19, v0

    move-object/from16 v19, v0

    move-object/from16 v19, v0

    move-object/from16 v19, v0

    invoke-interface/range {v14 .. v19}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;Ljava/lang/Throwable;)V

    iget-object v0, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    throw v0

    :cond_5
    :goto_2
    monitor-exit v4
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/Token;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const-string v2, "eTsko"

    const-string v2, "bTkoe"

    const-string/jumbo v2, "kTomn"

    const-string v2, "Token"

    const-string/jumbo v3, "uastorseooRiewn"

    const-string/jumbo v3, "rseRiaunoewostF"

    const-string v3, "awiFsbnrReeposo"

    const-string/jumbo v3, "waitForResponse"

    const-string v4, "402"

    const-string v4, "402"

    const-string v4, "402"

    const-string v4, "402"

    new-array v5, v13, [Ljava/lang/Object;

    invoke-virtual/range {p0 .. p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v6

    aput-object v6, v5, v11

    iget-object v6, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    aput-object v6, v5, v12

    invoke-interface {v0, v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    iget-object v0, v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->response:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;

    return-object v0

    :catchall_0
    move-exception v0

    :try_start_3
    monitor-exit v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    throw v0
.end method

.method public waitUntilSent()V
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->sentLock:Ljava/lang/Object;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->responseLock:Ljava/lang/Object;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    monitor-enter v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v9, 0x3

    const/4 v8, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-nez v2, :cond_3

    const/4 v8, 0x7

    const/4 v8, 0x7

    monitor-exit v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_0
    :goto_0
    :try_start_2
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->sent:Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-nez v1, :cond_0

    :try_start_3
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/Token;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    const-string/jumbo v2, "nuekp"

    const-string/jumbo v2, "nkpTe"

    const/4 v9, 0x0

    const-string/jumbo v2, "nkpTo"

    const-string v2, "Token"

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    const-string/jumbo v3, "ntiUwaiqqtlSe"

    const-string v3, "aetitniUqStwl"

    const/4 v9, 0x6

    const-string/jumbo v3, "itsnttUalSewn"

    const-string/jumbo v3, "waitUntilSent"

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-string v4, "409"

    const-string v4, "409"

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v5, 0x1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    const/4 v7, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    aput-object v6, v5, v7

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-interface {v1, v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->sentLock:Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v1}, Ljava/lang/Object;->wait()V
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    goto :goto_0

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-nez v1, :cond_2

    :try_start_4
    const/4 v9, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/Token;->exception:Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-nez v1, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x5

    const/4 v1, 0x6

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {v1}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->createMqttException(I)Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    throw v1

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    throw v1

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v8, 0x2

    move v9, v8

    return-void

    :cond_3
    :try_start_5
    const/4 v9, 0x1

    const/4 v8, 0x2

    throw v2

    :catchall_0
    move-exception v2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    monitor-exit v1
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :try_start_6
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    throw v2

    :catchall_1
    move-exception v1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    monitor-exit v0
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    throw v1
.end method
