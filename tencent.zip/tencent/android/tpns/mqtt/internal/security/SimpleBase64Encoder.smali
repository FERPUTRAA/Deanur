.class public Lcom/tencent/android/tpns/mqtt/internal/security/SimpleBase64Encoder;
.super Ljava/lang/Object;


# static fields
.field private static final PWDCHARS_ARRAY:[C

.field private static final PWDCHARS_STRING:Ljava/lang/String; = "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string/jumbo v0, "z3scRwOZ1ToHWUYphB6Luk.lrd2A0ebFyqaG45IfDX7Ngjn/JmEQi8xs9KCPvMtS"

    const-string v0, "./0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/security/SimpleBase64Encoder;->PWDCHARS_ARRAY:[C

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static decode(Ljava/lang/String;)[B
    .locals 14

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    array-length v0, p0

    mul-int/lit8 v1, v0, 0x3

    const/4 v2, 0x4

    div-int/2addr v1, v2

    new-array v1, v1, [B

    const/4 v3, 0x0

    move v4, v3

    move v4, v3

    move v4, v3

    move v4, v3

    :goto_0
    const/16 v5, 0x8

    const-wide/16 v6, 0xff

    const-wide/16 v6, 0xff

    const/4 v8, 0x2

    if-lt v0, v2, :cond_1

    invoke-static {p0, v3, v2}, Lcom/tencent/android/tpns/mqtt/internal/security/SimpleBase64Encoder;->from64([BII)J

    move-result-wide v9

    add-int/lit8 v0, v0, -0x4

    add-int/lit8 v3, v3, 0x4

    :goto_1
    if-ltz v8, :cond_0

    add-int v11, v4, v8

    and-long v12, v9, v6

    long-to-int v12, v12

    int-to-byte v12, v12

    aput-byte v12, v1, v11

    shr-long/2addr v9, v5

    add-int/lit8 v8, v8, -0x1

    goto :goto_1

    :cond_0
    add-int/lit8 v4, v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    if-ne v0, v2, :cond_2

    invoke-static {p0, v3, v2}, Lcom/tencent/android/tpns/mqtt/internal/security/SimpleBase64Encoder;->from64([BII)J

    move-result-wide v9

    const/4 v2, 0x1

    :goto_2
    if-ltz v2, :cond_2

    add-int v11, v4, v2

    and-long v12, v9, v6

    long-to-int v12, v12

    int-to-byte v12, v12

    aput-byte v12, v1, v11

    shr-long/2addr v9, v5

    add-int/lit8 v2, v2, -0x1

    goto :goto_2

    :cond_2
    if-ne v0, v8, :cond_3

    invoke-static {p0, v3, v8}, Lcom/tencent/android/tpns/mqtt/internal/security/SimpleBase64Encoder;->from64([BII)J

    move-result-wide v2

    and-long/2addr v2, v6

    long-to-int p0, v2

    int-to-byte p0, p0

    aput-byte p0, v1, v4

    :cond_3
    return-object v1
.end method

.method public static encode([B)Ljava/lang/String;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "i~~mSu  r@@@KbMs@to ~~ @@~/~~t~l~@~l o/ -@o ~4@@m @ ~ 1~o @~d@~b~~.@@@fob  @y~ o  @i ncaf@~v@~~~"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    array-length v0, p0

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    add-int/lit8 v2, v0, 0x2

    const/4 v8, 0x1

    const/4 v3, 0x3

    const/4 v8, 0x6

    move v7, v3

    const/4 v8, 0x0

    div-int/2addr v2, v3

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 v4, 0x4

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    mul-int/2addr v2, v4

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-direct {v1, v2}, Ljava/lang/StringBuffer;-><init>(I)V

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v2, 0x0

    shl-int/2addr v8, v2

    :goto_0
    const/4 v7, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    if-lt v0, v3, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    aget-byte v5, p0, v2

    const/4 v8, 0x3

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    shl-int/lit8 v5, v5, 0x10

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    add-int/lit8 v6, v2, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    aget-byte v6, p0, v6

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    and-int/lit16 v6, v6, 0xff

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    shl-int/lit8 v6, v6, 0x8

    const/4 v8, 0x0

    or-int/2addr v5, v6

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    add-int/lit8 v6, v2, 0x2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    aget-byte v6, p0, v6

    const/4 v8, 0x3

    and-int/lit16 v6, v6, 0xff

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    or-int/2addr v5, v6

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    int-to-long v5, v5

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {v5, v6, v4}, Lcom/tencent/android/tpns/mqtt/internal/security/SimpleBase64Encoder;->to64(JI)Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v1, v5}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    add-int/lit8 v2, v2, 0x3

    const/4 v8, 0x5

    const/4 v7, 0x3

    add-int/lit8 v0, v0, -0x3

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    goto :goto_0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v4, 0x2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-ne v0, v4, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    aget-byte v5, p0, v2

    const/4 v7, 0x2

    shr-int/2addr v8, v7

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    shl-int/lit8 v5, v5, 0x8

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    add-int/lit8 v6, v2, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    aget-byte v6, p0, v6

    const/4 v8, 0x7

    and-int/lit16 v6, v6, 0xff

    const/4 v8, 0x3

    or-int/2addr v5, v6

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    int-to-long v5, v5

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v5, v6, v3}, Lcom/tencent/android/tpns/mqtt/internal/security/SimpleBase64Encoder;->to64(JI)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_1
    const/4 v3, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-ne v0, v3, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    aget-byte p0, p0, v2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    and-int/lit16 p0, p0, 0xff

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x4

    int-to-long v2, p0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/internal/security/SimpleBase64Encoder;->to64(JI)Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    return-object p0
.end method

.method private static final from64([BII)J
    .locals 12

    const/4 v11, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v11, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v11, 0x1

    const/4 v2, 0x7

    const/4 v11, 0x4

    const/4 v2, 0x0

    move-wide v3, v0

    :goto_0
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-lez p2, :cond_4

    const/4 v11, 0x3

    add-int/lit8 p2, p2, -0x1

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    add-int/lit8 v5, p1, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    aget-byte p1, p0, p1

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x4

    const/16 v6, 0x2f

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    if-ne p1, v6, :cond_0

    const/4 v10, 0x1

    move v11, v10

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v11, 0x1

    const-wide/16 v6, 0x1

    const-wide/16 v6, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x5

    goto :goto_1

    :cond_0
    move-wide v6, v0

    :goto_1
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    const/16 v8, 0x30

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    if-lt p1, v8, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x5

    const/16 v9, 0x39

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x1

    if-gt p1, v9, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    add-int/lit8 v6, p1, 0x2

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x7

    sub-int/2addr v6, v8

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    int-to-long v6, v6

    :cond_1
    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    const/16 v8, 0x41

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    if-lt p1, v8, :cond_2

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    const/16 v9, 0x5a

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-gt p1, v9, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    add-int/lit8 v6, p1, 0xc

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x4

    sub-int/2addr v6, v8

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    int-to-long v6, v6

    :cond_2
    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    const/16 v8, 0x61

    const/4 v11, 0x5

    if-lt p1, v8, :cond_3

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    const/16 v9, 0x7a

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-gt p1, v9, :cond_3

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    add-int/lit8 p1, p1, 0x26

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x1

    sub-int/2addr p1, v8

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    int-to-long v6, p1

    :cond_3
    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    shl-long/2addr v6, v2

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    add-long/2addr v3, v6

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    add-int/lit8 v2, v2, 0x6

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x5

    move p1, v5

    move p1, v5

    move p1, v5

    move p1, v5

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    goto/16 :goto_0

    :cond_4
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    return-wide v3
.end method

.method private static final to64(JI)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v5, 0x6

    invoke-direct {v0, p2}, Ljava/lang/StringBuffer;-><init>(I)V

    :goto_0
    const/4 v4, 0x7

    const/4 v5, 0x2

    if-lez p2, :cond_0

    const/4 v5, 0x5

    add-int/lit8 p2, p2, -0x1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/security/SimpleBase64Encoder;->PWDCHARS_ARRAY:[C

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-wide/16 v2, 0x3f

    const-wide/16 v2, 0x3f

    const/4 v5, 0x0

    const-wide/16 v2, 0x3f

    const-wide/16 v2, 0x3f

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    and-long/2addr v2, p0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    long-to-int v2, v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    aget-char v1, v1, v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    const/4 v5, 0x0

    const/4 v1, 0x6

    const/4 v5, 0x7

    and-int/2addr v4, v1

    const/4 v5, 0x1

    shr-long/2addr p0, v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-object p0
.end method
