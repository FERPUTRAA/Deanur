.class Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpns/mqtt/internal/ClientComms;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "DisconnectBG"
.end annotation


# instance fields
.field disconnect:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttDisconnect;

.field quiesceTimeout:J

.field final synthetic this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

.field private threadName:Ljava/lang/String;

.field token:Lcom/tencent/android/tpns/mqtt/MqttToken;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;Lcom/tencent/android/tpns/mqtt/internal/wire/MqttDisconnect;JLcom/tencent/android/tpns/mqtt/MqttToken;Ljava/util/concurrent/ExecutorService;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->disconnect:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttDisconnect;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-wide p3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->quiesceTimeout:J

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p5, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->token:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->threadName:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string v1, "221"

    const-string v1, "221"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string/jumbo v2, "onsietClmsC"

    const/4 v6, 0x2

    const-string/jumbo v2, "tmsCmeloisC"

    const-string v2, "ClientComms"

    const/4 v6, 0x6

    const-string/jumbo v3, "iotmsncrd:unGcem"

    const-string/jumbo v3, "niumrodBneGcts:c"

    const-string v3, "c:droGstneBoncin"

    const-string v3, "disconnectBG:run"

    const/4 v5, 0x2

    const/4 v5, 0x2

    invoke-interface {v0, v2, v3, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    move v6, v5

    invoke-static {v3, v3}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$600(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-wide v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->quiesceTimeout:J

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->quiesce(J)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x0

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->disconnect:Lcom/tencent/android/tpns/mqtt/internal/wire/MqttDisconnect;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->token:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v1, v2, v4}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->internalSend(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->token:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v1, v1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->waitUntilSent()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->token:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v1, v1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1, v0, v0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->markComplete(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->token:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {v1, v2, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->shutdownConnection(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v6, 0x3

    goto :goto_1

    :catchall_0
    move-exception v1

    :try_start_1
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string v4, "e: uGbufdtece-peBrnonstccoxodnir"

    const-string/jumbo v4, "udndorBu:pxno-t ncefrctGieoescne"

    const/4 v6, 0x4

    const-string v4, "Goioucuc Btr:eepnxdcfnnnsud eet-"

    const-string/jumbo v4, "unexpected for disconnectBG:run-"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v3, v1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_0

    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    return-void

    :catchall_1
    move-exception v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->token:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v2, v2, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v2, v0, v0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->markComplete(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->token:Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v6, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2, v3, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->shutdownConnection(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    throw v1
.end method

.method start()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v1, "QM c:TDpiTs"

    const-string v1, ":isTDbcQM T"

    const/4 v3, 0x5

    const-string/jumbo v1, "sMTQTD :qi "

    const-string v1, "MQTT Disc: "

    const/4 v2, 0x7

    xor-int/2addr v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-interface {v1}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->threadName:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/ClientComms$DisconnectBG;->this$0:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->access$000(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)Ljava/util/concurrent/ExecutorService;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {v0, p0}, Ljava/util/concurrent/Executor;->execute(Ljava/lang/Runnable;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method
