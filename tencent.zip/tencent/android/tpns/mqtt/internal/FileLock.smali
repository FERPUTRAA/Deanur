.class public Lcom/tencent/android/tpns/mqtt/internal/FileLock;
.super Ljava/lang/Object;


# instance fields
.field private file:Ljava/io/RandomAccessFile;

.field private fileLock:Ljava/lang/Object;

.field private lockFile:Ljava/io/File;


# direct methods
.method public constructor <init>(Ljava/io/File;Ljava/lang/String;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v5, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x2

    new-instance v0, Ljava/io/File;

    const/4 v5, 0x7

    invoke-direct {v0, p1, p2}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->lockFile:Ljava/io/File;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string/jumbo p1, "vjsackn.nc.slael.noFoeihia"

    const/4 v5, 0x1

    const-string p1, "eissva.naa.c.lhLoenicloknj"

    const-string/jumbo p1, "java.nio.channels.FileLock"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/internal/ExceptionHelper;->isClassAvailable(Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz p1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 p1, 0x0

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance p2, Ljava/io/RandomAccessFile;

    const/4 v5, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->lockFile:Ljava/io/File;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string/jumbo v1, "wr"

    const-string/jumbo v1, "rw"

    const/4 v5, 0x1

    const-string/jumbo v1, "rw"

    const-string/jumbo v1, "rw"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {p2, v0, v1}, Ljava/io/RandomAccessFile;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->file:Ljava/io/RandomAccessFile;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v0, "Chgmatelem"

    const-string v0, "hagmnleCet"

    const/4 v5, 0x2

    const-string/jumbo v0, "nhnloCeage"

    const-string v0, "getChannel"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x4

    new-array v2, v1, [Ljava/lang/Class;

    invoke-virtual {p2, v0, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->file:Ljava/io/RandomAccessFile;

    const/4 v5, 0x0

    const/4 v4, 0x6

    new-array v2, v1, [Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p2, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v2, "orLtybk"

    const-string/jumbo v2, "krtooLy"

    const/4 v5, 0x1

    const-string/jumbo v2, "kLtocyu"

    const-string/jumbo v2, "tryLock"

    const/4 v5, 0x1

    new-array v3, v1, [Ljava/lang/Class;

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v2, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0, p2, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->fileLock:Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    goto :goto_0

    :catch_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->fileLock:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :catch_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->fileLock:Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    goto :goto_0

    :catch_2
    const/4 v5, 0x2

    const/4 v4, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->fileLock:Ljava/lang/Object;

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->fileLock:Ljava/lang/Object;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz p1, :cond_0

    const/4 v5, 0x5

    goto :goto_1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->release()V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance p1, Ljava/lang/Exception;

    const/4 v4, 0x7

    shl-int/2addr v5, v4

    const-string p2, "btoogblpf lilkrinen mabPoc "

    const-string p2, "gPlkobolaib noi melrten fbc"

    const/4 v5, 0x1

    const-string p2, "fiobatn qicPgnoeml relolik "

    const-string p2, "Problem obtaining file lock"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    throw p1

    :cond_1
    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void
.end method


# virtual methods
.method public release()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~@sl@~c ~ @ ~vKa@o @mo@o ot-@b /ot~@l@~~@@f~b/~~~~@~b1us d~  @  ~@y~  .@fM~ S~@ii@~~4@ion@~@r ~ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->fileLock:Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-eqz v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v2, "eermseu"

    const-string v2, "eaeseru"

    const-string v2, "eraeoel"

    const-string/jumbo v2, "release"

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x2

    move v5, v3

    move v5, v3

    const/4 v6, 0x0

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->fileLock:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v6, 0x4

    invoke-virtual {v1, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->fileLock:Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->file:Ljava/io/RandomAccessFile;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v1, :cond_1

    :try_start_1
    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/io/RandomAccessFile;->close()V
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    const/4 v5, 0x5

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->file:Ljava/io/RandomAccessFile;

    :cond_1
    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->lockFile:Ljava/io/File;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/io/File;->exists()Z

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->lockFile:Ljava/io/File;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/io/File;->delete()Z

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/FileLock;->lockFile:Ljava/io/File;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-void
.end method
