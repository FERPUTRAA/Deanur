.class public Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "CommsCallback"

.field private static final INBOUND_QUEUE_SIZE:I = 0xa

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private callbackFuture:Ljava/util/concurrent/Future;

.field private callbackThread:Ljava/lang/Thread;

.field private callbacks:Ljava/util/Hashtable;

.field private clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

.field private clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

.field private completeQueue:Ljava/util/Vector;

.field private lifecycle:Ljava/lang/Object;

.field private manualAcks:Z

.field private messageQueue:Ljava/util/Vector;

.field private mqttCallback:Lcom/tencent/android/tpns/mqtt/MqttCallback;

.field private quiescing:Z

.field private reconnectInternalCallback:Lcom/tencent/android/tpns/mqtt/MqttCallbackExtended;

.field public running:Z

.field private final runningSemaphore:Ljava/util/concurrent/Semaphore;

.field private spaceAvailable:Ljava/lang/Object;

.field private threadName:Ljava/lang/String;

.field private workAvailable:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const-string/jumbo v0, "n.si.tein.d.ngnmtca.pamrcottt.snroesnlotd.cealtnq"

    const/4 v3, 0x6

    const-string v0, ".asitcmltenon.dto.n..npt.ndiroe.qtrcatalegmnlctns"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v1, "llamCmmcbmsko"

    const-string/jumbo v1, "lcmmsabokamlC"

    const/4 v3, 0x5

    const-string/jumbo v1, "mboaokmCsCacl"

    const-string v1, "CommsCallback"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method constructor <init>(Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v2, 0x4

    move v3, v2

    const/4 v0, 0x0

    xor-int/2addr v3, v0

    const/4 v2, 0x0

    move v3, v2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->running:Z

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->quiescing:Z

    const/4 v3, 0x5

    new-instance v1, Ljava/lang/Object;

    const/4 v3, 0x1

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->lifecycle:Ljava/lang/Object;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v1, Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->workAvailable:Ljava/lang/Object;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v1, Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v1}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->spaceAvailable:Ljava/lang/Object;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->manualAcks:Z

    const/4 v3, 0x1

    new-instance v0, Ljava/util/concurrent/Semaphore;

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x1

    invoke-direct {v0, v1}, Ljava/util/concurrent/Semaphore;-><init>(I)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v3, 0x2

    const/4 v2, 0x7

    new-instance v0, Ljava/util/Vector;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/16 v1, 0xa

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/util/Vector;-><init>(I)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageQueue:Ljava/util/Vector;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Ljava/util/Vector;

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/util/Vector;-><init>(I)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->completeQueue:Ljava/util/Vector;

    new-instance v0, Ljava/util/Hashtable;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/util/Hashtable;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbacks:Ljava/util/Hashtable;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-interface {p1}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-interface {v0, p1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->setResourceName(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method private handleActionComplete(Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "f  -@b c~ a1~ ~~ @@~/~~@r@f o~~o~~~~ b@@~b~@l o~u@d@  t@s @@@~@.io /ti@~yv~@mMo@b4in~o@~S   ~K@l"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x7

    monitor-enter p1

    :try_start_0
    const/4 v9, 0x1

    const/4 v8, 0x2

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    const-string/jumbo v1, "lCbsolmCkcaom"

    const/4 v9, 0x6

    const-string v1, "blkmsCuCoclaa"

    const-string v1, "CommsCallback"

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    const-string v2, "atChletpnbcAipooleme"

    const-string/jumbo v2, "tecolbhnnleaoACemtpi"

    const/4 v9, 0x1

    const-string v2, "handleActionComplete"

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    const-string v3, "057"

    const-string v3, "570"

    const/4 v9, 0x3

    const-string v3, "507"

    const-string v3, "705"

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    const/4 v4, 0x1

    const/4 v8, 0x6

    xor-int/2addr v9, v8

    new-array v5, v4, [Ljava/lang/Object;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object v6, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v6}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    aput-object v6, v5, v7

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-interface {v0, v1, v2, v3, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/MqttToken;->isComplete()Z

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eqz v0, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v9, 0x7

    const/4 v8, 0x5

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->notifyComplete(Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    iget-object v0, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->notifyComplete()V

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object v0, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/Token;->isNotified()Z

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-nez v0, :cond_2

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->mqttCallback:Lcom/tencent/android/tpns/mqtt/MqttCallback;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eqz v0, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-eqz v0, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/MqttToken;->isComplete()Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-eqz v0, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->mqttCallback:Lcom/tencent/android/tpns/mqtt/MqttCallback;

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v9, 0x5

    const/4 v8, 0x4

    check-cast v1, Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    const/4 v9, 0x7

    invoke-interface {v0, v1}, Lcom/tencent/android/tpns/mqtt/MqttCallback;->deliveryComplete(Lcom/tencent/android/tpns/mqtt/IMqttDeliveryToken;)V

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->fireActionEvent(Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/MqttToken;->isComplete()Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-eqz v0, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    instance-of v0, p1, Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-nez v0, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/MqttToken;->getActionCallback()Lcom/tencent/android/tpns/mqtt/IMqttActionListener;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    instance-of v0, v0, Lcom/tencent/android/tpns/mqtt/IMqttActionListener;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-eqz v0, :cond_4

    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v0, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v8, 0x5

    shr-int/2addr v9, v8

    invoke-virtual {v0, v4}, Lcom/tencent/android/tpns/mqtt/internal/Token;->setNotified(Z)V

    :cond_4
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    monitor-exit p1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    return-void

    :catchall_0
    move-exception v0

    const/4 v9, 0x6

    const/4 v8, 0x0

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    throw v0
.end method

.method private handleMessage(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V
    .locals 10
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;,
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getTopicName()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/4 v2, 0x2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    new-instance v4, Ljava/lang/Integer;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v5

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-direct {v4, v5}, Ljava/lang/Integer;-><init>(I)V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v5, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x0

    aput-object v4, v3, v5

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v4, 0x1

    const/4 v8, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    aput-object v0, v3, v4

    const/4 v8, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string v5, "amCuclosqlkba"

    const-string/jumbo v5, "mcsmalulkCoab"

    const/4 v9, 0x0

    const-string/jumbo v5, "omsabklclsmCa"

    const-string v5, "CommsCallback"

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string v6, "esnmpheMldgae"

    const-string v6, "hlaaegepMdsen"

    const/4 v9, 0x6

    const-string v6, "ehadolenMgesa"

    const-string v6, "handleMessage"

    const/4 v9, 0x4

    const-string v7, "317"

    const-string v7, "137"

    const/4 v9, 0x6

    const-string v7, "731"

    const-string v7, "713"

    const/4 v9, 0x0

    invoke-interface {v1, v5, v6, v7, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;->getMessageId()I

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {p0, v0, v1, v3}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->deliverMessage(Ljava/lang/String;ILcom/tencent/android/tpns/mqtt/MqttMessage;)Z

    const/4 v9, 0x1

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->manualAcks:Z

    const/4 v9, 0x2

    if-nez v0, :cond_1

    const/4 v9, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-ne v0, v4, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v8, 0x3

    move v9, v8

    new-instance v1, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubAck;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-direct {v1, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubAck;-><init>(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-interface {v2}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-direct {p1, v2}, Lcom/tencent/android/tpns/mqtt/MqttToken;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x2

    invoke-virtual {v0, v1, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->internalSend(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    goto :goto_0

    :cond_0
    const/4 v9, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;->getMessage()Lcom/tencent/android/tpns/mqtt/MqttMessage;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->getQos()I

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    if-ne v0, v2, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->deliveryComplete(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-direct {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;-><init>(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-interface {v2}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-direct {v1, v2}, Lcom/tencent/android/tpns/mqtt/MqttToken;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x1

    invoke-virtual {p1, v0, v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->internalSend(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    :cond_1
    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 9

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string v0, "allsbbkCamCoc"

    const-string v0, "CommsCallback"

    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    and-int/2addr v8, v7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string v2, ":uoobtcrqaaakrce  lh dpnl"

    const/4 v8, 0x2

    const-string/jumbo v2, "r carpulle:akdn cl ohaout"

    const-string/jumbo v2, "run loop callback thread:"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->threadName:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x2

    invoke-static {v0, v1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbackThread:Ljava/lang/Thread;

    const/4 v7, 0x4

    move v8, v7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->threadName:Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/Thread;->setName(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v0, 0x3

    const/4 v8, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v8, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->acquire()V
    :try_end_0
    .catch Ljava/lang/InterruptedException; {:try_start_0 .. :try_end_0} :catch_1

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->running:Z

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eqz v1, :cond_6

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/4 v1, 0x0

    :try_start_1
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->workAvailable:Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    monitor-enter v2
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget-boolean v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->running:Z

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-eqz v3, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageQueue:Ljava/util/Vector;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v3}, Ljava/util/Vector;->isEmpty()Z

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-eqz v3, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->completeQueue:Ljava/util/Vector;

    const/4 v7, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v3}, Ljava/util/Vector;->isEmpty()Z

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-eqz v3, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    sget-object v3, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string v4, "bsoamacpCCkls"

    const-string/jumbo v4, "mCsomscaaCblk"

    const/4 v8, 0x5

    const-string/jumbo v4, "lCkommscqlaab"

    const-string v4, "CommsCallback"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const-string/jumbo v5, "unr"

    const-string/jumbo v5, "nru"

    const/4 v8, 0x3

    const-string/jumbo v5, "nur"

    const-string/jumbo v5, "run"

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v6, "704"

    const-string v6, "704"

    const/4 v8, 0x3

    const-string v6, "047"

    const-string v6, "704"

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-interface {v3, v4, v5, v6}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->workAvailable:Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-virtual {v3}, Ljava/lang/Object;->wait()V

    :cond_0
    const/4 v7, 0x1

    const/4 v8, 0x5

    monitor-exit v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x0

    goto :goto_1

    :catchall_0
    move-exception v3

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const/4 v8, 0x1

    const/4 v7, 0x3

    throw v3
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :catchall_1
    move-exception v2

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    goto/16 :goto_5

    :catch_0
    :goto_1
    :try_start_4
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-boolean v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->running:Z

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    if-eqz v2, :cond_4

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->completeQueue:Ljava/util/Vector;

    const/4 v8, 0x3

    const/4 v7, 0x0

    monitor-enter v2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :try_start_5
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->completeQueue:Ljava/util/Vector;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v3}, Ljava/util/Vector;->isEmpty()Z

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-nez v3, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->completeQueue:Ljava/util/Vector;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v3, v0}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x3

    check-cast v3, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->completeQueue:Ljava/util/Vector;

    const/4 v7, 0x1

    shr-int/2addr v8, v7

    invoke-virtual {v4, v0}, Ljava/util/Vector;->removeElementAt(I)V

    const/4 v8, 0x3

    goto :goto_2

    :cond_1
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :goto_2
    const/4 v8, 0x2

    const/4 v7, 0x0

    monitor-exit v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_3

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-eqz v3, :cond_2

    :try_start_6
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {p0, v3}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->handleActionComplete(Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageQueue:Ljava/util/Vector;

    const/4 v8, 0x6

    const/4 v7, 0x2

    monitor-enter v2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    :try_start_7
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageQueue:Ljava/util/Vector;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v3}, Ljava/util/Vector;->isEmpty()Z

    move-result v3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-nez v3, :cond_3

    const/4 v7, 0x3

    const/4 v8, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageQueue:Ljava/util/Vector;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v3, v0}, Ljava/util/Vector;->elementAt(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    check-cast v3, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageQueue:Ljava/util/Vector;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v4, v0}, Ljava/util/Vector;->removeElementAt(I)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    goto :goto_3

    :cond_3
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :goto_3
    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    monitor-exit v2
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eqz v3, :cond_4

    :try_start_8
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {p0, v3}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->handleMessage(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    const/4 v8, 0x0

    const/4 v7, 0x7

    goto :goto_4

    :catchall_2
    move-exception v3

    :try_start_9
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    monitor-exit v2
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    :try_start_a
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    throw v3
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_1

    :catchall_3
    move-exception v3

    :try_start_b
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    monitor-exit v2
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_3

    :try_start_c
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    throw v3

    :cond_4
    :goto_4
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x2

    iget-boolean v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->quiescing:Z

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-eqz v2, :cond_5

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v2}, Lcom/tencent/android/tpns/mqtt/internal/ClientState;->checkQuiesceLock()Z
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_1

    :cond_5
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->release()V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->spaceAvailable:Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    monitor-enter v2

    :try_start_d
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string/jumbo v3, "klsamsbCmolca"

    const-string/jumbo v3, "kaamolCblcCms"

    const/4 v8, 0x1

    const-string v3, "CommsCallback"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string/jumbo v4, "run"

    const-string/jumbo v4, "urn"

    const/4 v8, 0x7

    const-string/jumbo v4, "nru"

    const-string/jumbo v4, "run"

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    const-string v5, "706"

    const-string v5, "706"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-interface {v1, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->spaceAvailable:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    monitor-exit v2

    const/4 v8, 0x4

    const/4 v7, 0x6

    goto/16 :goto_0

    :catchall_4
    move-exception v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    monitor-exit v2
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_4

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    throw v0

    :goto_5
    :try_start_e
    const/4 v8, 0x3

    const-string/jumbo v3, "lkomomCcaslbC"

    const/4 v8, 0x7

    const-string/jumbo v3, "mcCmllCbasmok"

    const-string v3, "CommsCallback"

    const-string/jumbo v4, "nru"

    const-string/jumbo v4, "nru"

    const/4 v8, 0x3

    const-string/jumbo v4, "nru"

    const-string/jumbo v4, "run"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v3, v4, v2}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->running:Z

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    new-instance v4, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-direct {v4, v2}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v3, v1, v4}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->shutdownConnection(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_6

    const/4 v8, 0x1

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->release()V

    const/4 v7, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->spaceAvailable:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x4

    monitor-enter v1

    :try_start_f
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string v3, "blmlooaCaskbC"

    const-string/jumbo v3, "lbaakbcmoCCsl"

    const/4 v8, 0x2

    const-string/jumbo v3, "lbCcabomamkCl"

    const-string v3, "CommsCallback"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string/jumbo v4, "rnu"

    const-string/jumbo v4, "nru"

    const/4 v8, 0x4

    const-string/jumbo v4, "run"

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    const-string v5, "076"

    const-string v5, "706"

    const/4 v8, 0x5

    const-string v5, "067"

    const-string v5, "706"

    const/4 v7, 0x2

    move v8, v7

    invoke-interface {v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->spaceAvailable:Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v2}, Ljava/lang/Object;->notifyAll()V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    monitor-exit v1

    const/4 v8, 0x0

    const/4 v7, 0x6

    goto/16 :goto_0

    :catchall_5
    move-exception v0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    monitor-exit v1
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_5

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    throw v0

    :catchall_6
    move-exception v0

    const/4 v8, 0x2

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->release()V

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->spaceAvailable:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    monitor-enter v1

    :try_start_10
    const/4 v8, 0x4

    const/4 v7, 0x3

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string v3, "bclkaauoCCusl"

    const-string/jumbo v3, "ksbcmluaaCoCl"

    const/4 v8, 0x0

    const-string v3, "ammblaspcCloC"

    const-string v3, "CommsCallback"

    const/4 v8, 0x0

    const-string/jumbo v4, "nur"

    const-string/jumbo v4, "rnu"

    const/4 v8, 0x7

    const-string/jumbo v4, "rnu"

    const-string/jumbo v4, "run"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    const-string v5, "607"

    const-string v5, "760"

    const/4 v8, 0x7

    const-string v5, "760"

    const-string v5, "706"

    const/4 v8, 0x1

    const/4 v7, 0x1

    invoke-interface {v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->spaceAvailable:Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v2}, Ljava/lang/Object;->notifyAll()V

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    monitor-exit v1
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_7

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    throw v0

    :catchall_7
    move-exception v0

    :try_start_11
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    monitor-exit v1
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_7

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    throw v0

    :cond_6
    const/4 v8, 0x6

    const/4 v7, 0x1

    return-void

    :catch_1
    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->running:Z

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x4

    return-void
.end method

.method public asyncOperationComplete(Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    .locals 9

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->running:Z

    const/4 v8, 0x2

    if-eqz v0, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->completeQueue:Ljava/util/Vector;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v0, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->workAvailable:Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string v2, "acComlmlqpask"

    const-string/jumbo v2, "olkCsalpmmcba"

    const-string/jumbo v2, "mlsamakCoCslc"

    const-string v2, "CommsCallback"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-string/jumbo v3, "tymmpOieqaenlocroantCe"

    const-string/jumbo v3, "yeteCeOoqlparmcsniotan"

    const/4 v8, 0x1

    const-string v3, "asyncOperationComplete"

    const/4 v7, 0x7

    shr-int/2addr v8, v7

    const-string v4, "157"

    const-string v4, "715"

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v5, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object p1, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/4 v6, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    aput-object p1, v5, v6

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-interface {v1, v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->workAvailable:Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->notifyAll()V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    monitor-exit v0

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    throw p1

    :cond_0
    :try_start_1
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->handleActionComplete(Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    goto :goto_0

    :catchall_1
    move-exception p1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string/jumbo v0, "smClocaokbmCl"

    const-string v0, "CommsCallback"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    const-string v1, "eyssaeCtonelpprmOaotic"

    const/4 v8, 0x5

    const-string/jumbo v1, "ieleybOCttearnnomppsac"

    const-string v1, "asyncOperationComplete"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v0, v1, p1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    new-instance v1, Lcom/tencent/android/tpns/mqtt/MqttException;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-direct {v1, p1}, Lcom/tencent/android/tpns/mqtt/MqttException;-><init>(Ljava/lang/Throwable;)V

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    const/4 p1, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v0, p1, v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->shutdownConnection(Lcom/tencent/android/tpns/mqtt/MqttToken;Lcom/tencent/android/tpns/mqtt/MqttException;)V

    :goto_0
    const/4 v8, 0x6

    return-void
.end method

.method public connectionLost(Lcom/tencent/android/tpns/mqtt/MqttException;)V
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string/jumbo v0, "snmetouocLnoin"

    const-string/jumbo v0, "onLmncionstcoe"

    const/4 v7, 0x7

    const-string/jumbo v0, "ocsoLonpntncei"

    const-string v0, "connectionLost"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string/jumbo v1, "mblakoasqClCc"

    const-string v1, "asCboackllCmo"

    const/4 v7, 0x2

    const-string v1, "cmslClaoCmbks"

    const-string v1, "CommsCallback"

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->mqttCallback:Lcom/tencent/android/tpns/mqtt/MqttCallback;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-eqz v2, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x3

    if-eqz p1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string v3, "078"

    const-string v3, "780"

    const/4 v7, 0x1

    const-string v3, "807"

    const-string v3, "708"

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v4, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v5, 0x6

    const/4 v7, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    aput-object p1, v4, v5

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-interface {v2, v1, v0, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->mqttCallback:Lcom/tencent/android/tpns/mqtt/MqttCallback;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-interface {v2, p1}, Lcom/tencent/android/tpns/mqtt/MqttCallback;->connectionLost(Ljava/lang/Throwable;)V

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->reconnectInternalCallback:Lcom/tencent/android/tpns/mqtt/MqttCallbackExtended;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz v2, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz p1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-interface {v2, p1}, Lcom/tencent/android/tpns/mqtt/MqttCallback;->connectionLost(Ljava/lang/Throwable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v1, v0, p1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    return-void
.end method

.method protected deliverMessage(Ljava/lang/String;ILcom/tencent/android/tpns/mqtt/MqttMessage;)Z
    .locals 7
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbacks:Ljava/util/Hashtable;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/util/Hashtable;->keys()Ljava/util/Enumeration;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v1, 0x0

    :cond_0
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/Enumeration;->hasMoreElements()Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/4 v3, 0x1

    if-eqz v2, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/Enumeration;->nextElement()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    check-cast v2, Ljava/lang/String;

    const/4 v6, 0x1

    invoke-static {v2, p1}, Lcom/tencent/android/tpns/mqtt/MqttTopic;->isMatched(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eqz v4, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p3, p2}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setId(I)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbacks:Ljava/util/Hashtable;

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/util/Hashtable;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    check-cast v1, Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-interface {v1, p1, p3}, Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;->messageArrived(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttMessage;)V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    move v1, v3

    move v1, v3

    const/4 v6, 0x4

    move v1, v3

    move v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->mqttCallback:Lcom/tencent/android/tpns/mqtt/MqttCallback;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v0, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x5

    if-nez v1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p3, p2}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setId(I)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->mqttCallback:Lcom/tencent/android/tpns/mqtt/MqttCallback;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-interface {p2, p1, p3}, Lcom/tencent/android/tpns/mqtt/MqttCallback;->messageArrived(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttMessage;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    move v1, v3

    move v1, v3

    const/4 v6, 0x5

    move v1, v3

    move v1, v3

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    return v1
.end method

.method public fireActionEvent(Lcom/tencent/android/tpns/mqtt/MqttToken;)V
    .locals 10

    const/4 v9, 0x0

    const/4 v8, 0x3

    if-eqz p1, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/MqttToken;->getActionCallback()Lcom/tencent/android/tpns/mqtt/IMqttActionListener;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-eqz v0, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/MqttToken;->getException()Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/4 v3, 0x1

    const/4 v9, 0x6

    const-string v4, "671"

    const-string v4, "176"

    const/4 v9, 0x1

    const-string v4, "761"

    const-string v4, "716"

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-string v5, "firmnctoEebntAi"

    const-string v5, "AnctrbiEnifovte"

    const/4 v9, 0x5

    const-string v5, "eirooAvinnEteft"

    const-string v5, "fireActionEvent"

    const/4 v9, 0x7

    const-string v6, "albasbmCuColk"

    const-string/jumbo v6, "lkmaasuloCCcb"

    const/4 v9, 0x6

    const-string/jumbo v6, "saClbmulaCcmk"

    const-string v6, "CommsCallback"

    const/4 v9, 0x6

    if-nez v1, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    iget-object v7, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v7}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    aput-object v7, v3, v2

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-interface {v1, v6, v5, v4, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x4

    invoke-interface {v0, p1}, Lcom/tencent/android/tpns/mqtt/IMqttActionListener;->onSuccess(Lcom/tencent/android/tpns/mqtt/IMqttToken;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    goto :goto_0

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v9, 0x5

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    iget-object v7, p1, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v8, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v7}, Lcom/tencent/android/tpns/mqtt/internal/Token;->getKey()Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x2

    const/4 v8, 0x1

    aput-object v7, v3, v2

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-interface {v1, v6, v5, v4, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/MqttToken;->getException()Lcom/tencent/android/tpns/mqtt/MqttException;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-interface {v0, p1, v1}, Lcom/tencent/android/tpns/mqtt/IMqttActionListener;->onFailure(Lcom/tencent/android/tpns/mqtt/IMqttToken;Ljava/lang/Throwable;)V

    :cond_1
    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    return-void
.end method

.method protected getThread()Ljava/lang/Thread;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbackThread:Ljava/lang/Thread;

    const/4 v1, 0x2

    and-int/2addr v2, v1

    return-object v0
.end method

.method public isQuiesced()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->quiescing:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->completeQueue:Ljava/util/Vector;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageQueue:Ljava/util/Vector;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {v0}, Ljava/util/Vector;->size()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x6

    return v0

    :cond_0
    const/4 v2, 0x7

    const/4 v0, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    return v0
.end method

.method public messageArrived(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;)V
    .locals 7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->mqttCallback:Lcom/tencent/android/tpns/mqtt/MqttCallback;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-nez v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbacks:Ljava/util/Hashtable;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/util/Hashtable;->size()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-lez v0, :cond_2

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->spaceAvailable:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    monitor-enter v0

    :catch_0
    :goto_0
    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->running:Z

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eqz v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->quiescing:Z

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageQueue:Ljava/util/Vector;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/util/Vector;->size()I

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/16 v2, 0xa

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-lt v1, v2, :cond_1

    :try_start_1
    const/4 v6, 0x0

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v2, "amkcblCpaoCps"

    const-string v2, "aabCcsmplkmoC"

    const/4 v6, 0x6

    const-string v2, "CamaClmbqocsl"

    const-string v2, "CommsCallback"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string/jumbo v3, "iqseemsArgvera"

    const-string v3, "eerrsgviqseamA"

    const/4 v6, 0x2

    const-string/jumbo v3, "messageArrived"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const-string v4, "970"

    const-string v4, "709"

    const/4 v6, 0x3

    const-string v4, "907"

    const-string v4, "709"

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->spaceAvailable:Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-wide/16 v2, 0xc8

    const-wide/16 v2, 0xc8

    const/4 v6, 0x1

    const-wide/16 v2, 0xc8

    const-wide/16 v2, 0xc8

    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v1, v2, v3}, Ljava/lang/Object;->wait(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v5, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_0

    :cond_1
    :try_start_2
    const/4 v6, 0x0

    const/4 v5, 0x6

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->quiescing:Z

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-nez v0, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageQueue:Ljava/util/Vector;

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/util/Vector;->addElement(Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->workAvailable:Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x2

    monitor-enter p1

    :try_start_3
    const/4 v6, 0x4

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x0

    const-string v1, "allmCocksmsbC"

    const-string/jumbo v1, "olsCasbclmkCa"

    const/4 v6, 0x2

    const-string/jumbo v1, "lmCCooabmslck"

    const-string v1, "CommsCallback"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v2, "gmAmebsrviseed"

    const-string/jumbo v2, "rmvmesgdesierA"

    const/4 v6, 0x3

    const-string/jumbo v2, "messageArrived"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v3, "107"

    const-string v3, "701"

    const/4 v6, 0x0

    const-string v3, "710"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-interface {v0, v1, v2, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->workAvailable:Ljava/lang/Object;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->notifyAll()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    monitor-exit p1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_1

    :catchall_0
    move-exception v0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    monitor-exit p1
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    throw v0

    :cond_2
    :goto_1
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-void

    :catchall_1
    move-exception p1

    :try_start_4
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    monitor-exit v0
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    throw p1
.end method

.method public messageArrivedComplete(II)V
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-ne p2, v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubAck;

    const/4 v3, 0x2

    invoke-direct {v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubAck;-><init>(I)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance p1, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {v1}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p1, v1}, Lcom/tencent/android/tpns/mqtt/MqttToken;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p2, v0, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->internalSend(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x2

    if-ne p2, v0, :cond_1

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p2, p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->deliveryComplete(I)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance p2, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p2, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPubComp;-><init>(I)V

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientComms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v2, 0x0

    move v3, v2

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {v1}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-direct {v0, v1}, Lcom/tencent/android/tpns/mqtt/MqttToken;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p1, p2, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->internalSend(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    return-void
.end method

.method public quiesce()V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v0, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->quiescing:Z

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->spaceAvailable:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const-string v2, "bkmaoCuosClca"

    const-string/jumbo v2, "mabColoCcaskm"

    const/4 v6, 0x4

    const-string v2, "albcsmkpoaCCm"

    const-string v2, "CommsCallback"

    const/4 v5, 0x5

    or-int/2addr v6, v5

    const-string/jumbo v3, "iqeqbes"

    const-string v3, "cseeibq"

    const/4 v6, 0x5

    const-string/jumbo v3, "quseesi"

    const-string/jumbo v3, "quiesce"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string v4, "711"

    const-string v4, "711"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->spaceAvailable:Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    monitor-exit v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-void

    :catchall_0
    move-exception v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    throw v1
.end method

.method public removeMessageListener(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbacks:Ljava/util/Hashtable;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0, p1}, Ljava/util/Hashtable;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public removeMessageListeners()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbacks:Ljava/util/Hashtable;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/util/Hashtable;->clear()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public setCallback(Lcom/tencent/android/tpns/mqtt/MqttCallback;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->mqttCallback:Lcom/tencent/android/tpns/mqtt/MqttCallback;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public setClientState(Lcom/tencent/android/tpns/mqtt/internal/ClientState;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->clientState:Lcom/tencent/android/tpns/mqtt/internal/ClientState;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public setManualAcks(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->manualAcks:Z

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public setMessageListener(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/IMqttMessageListener;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbacks:Ljava/util/Hashtable;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0, p1, p2}, Ljava/util/Hashtable;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public setReconnectCallback(Lcom/tencent/android/tpns/mqtt/MqttCallbackExtended;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->reconnectInternalCallback:Lcom/tencent/android/tpns/mqtt/MqttCallbackExtended;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public start(Ljava/lang/String;Ljava/util/concurrent/ExecutorService;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->threadName:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->lifecycle:Ljava/lang/Object;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    monitor-enter p1

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->running:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->messageQueue:Ljava/util/Vector;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/Vector;->clear()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->completeQueue:Ljava/util/Vector;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/util/Vector;->clear()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->running:Z

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    move v2, v1

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->quiescing:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {p2, p0}, Ljava/util/concurrent/ExecutorService;->submit(Ljava/lang/Runnable;)Ljava/util/concurrent/Future;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbackFuture:Ljava/util/concurrent/Future;

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    monitor-exit p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void

    :catchall_0
    move-exception p2

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    monitor-exit p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    throw p2
.end method

.method public stop()V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->lifecycle:Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbackFuture:Ljava/util/concurrent/Future;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v1, :cond_0

    const/4 v7, 0x4

    const/4 v2, 0x1

    const/4 v7, 0x4

    move v6, v2

    move v6, v2

    const/4 v7, 0x5

    invoke-interface {v1, v2}, Ljava/util/concurrent/Future;->cancel(Z)Z

    :cond_0
    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->running:Z

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz v1, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const-string/jumbo v2, "sabmoClkmulaC"

    const-string/jumbo v2, "oksClmuCmblaa"

    const-string v2, "CommsCallback"

    const/4 v7, 0x1

    const-string/jumbo v3, "post"

    const-string/jumbo v3, "spot"

    const/4 v7, 0x7

    const-string/jumbo v3, "stop"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string v4, "070"

    const-string v4, "700"

    const/4 v7, 0x3

    const-string v4, "007"

    const-string v4, "700"

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x4

    iput-boolean v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->running:Z

    const/4 v6, 0x2

    shr-int/2addr v7, v6

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbackThread:Ljava/lang/Thread;

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-nez v2, :cond_1

    :try_start_1
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->workAvailable:Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    monitor-enter v2
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v6, 0x5

    move v7, v6

    const-string/jumbo v3, "labCopClmcsok"

    const-string/jumbo v3, "oCCsalkpclmba"

    const/4 v7, 0x6

    const-string v3, "ClolcbkCamabs"

    const-string v3, "CommsCallback"

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string/jumbo v4, "ostp"

    const-string/jumbo v4, "ospt"

    const/4 v7, 0x2

    const-string/jumbo v4, "otsp"

    const-string/jumbo v4, "stop"

    const/4 v6, 0x0

    move v7, v6

    const-string v5, "107"

    const-string v5, "170"

    const/4 v7, 0x2

    const-string v5, "017"

    const-string v5, "701"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v1, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->workAvailable:Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/lang/Object;->notifyAll()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :try_start_3
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v6, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->acquire()V
    :try_end_3
    .catch Ljava/lang/InterruptedException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :try_start_4
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/util/concurrent/Semaphore;->release()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    goto :goto_1

    :catchall_0
    move-exception v1

    :try_start_5
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    monitor-exit v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    :try_start_6
    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    throw v1
    :try_end_6
    .catch Ljava/lang/InterruptedException; {:try_start_6 .. :try_end_6} :catch_0
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    :catchall_1
    move-exception v1

    :try_start_7
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v2}, Ljava/util/concurrent/Semaphore;->release()V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    throw v1

    :catch_0
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->runningSemaphore:Ljava/util/concurrent/Semaphore;

    const/4 v7, 0x5

    goto :goto_0

    :cond_1
    :goto_1
    const/4 v1, 0x4

    move v7, v1

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v7, 0x3

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->callbackThread:Ljava/lang/Thread;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    sget-object v1, Lcom/tencent/android/tpns/mqtt/internal/CommsCallback;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string v2, "amCkocusalblC"

    const-string v2, "CommsCallback"

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string/jumbo v3, "ptso"

    const-string/jumbo v3, "tspo"

    const/4 v7, 0x1

    const-string/jumbo v3, "tosp"

    const-string/jumbo v3, "stop"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string v4, "730"

    const-string v4, "730"

    const/4 v7, 0x5

    const-string v4, "370"

    const-string v4, "703"

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-interface {v1, v2, v3, v4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    monitor-exit v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-void

    :catchall_2
    move-exception v1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    monitor-exit v0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    throw v1
.end method
