.class public Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "WebSocketReceiver"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private input:Ljava/io/InputStream;

.field private lifecycle:Ljava/lang/Object;

.field private pipedOutputStream:Ljava/io/PipedOutputStream;

.field private receiverThread:Ljava/lang/Thread;

.field private volatile receiving:Z

.field private running:Z

.field private stopping:Z


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v0, "snsqarnm..g.oe.n.ctnp.aeanotilldotlstcti.nmcndett"

    const-string v0, "ens.dsnntloceta.nl.iiorentnt.pc.qomalndcsgmtta..t"

    const/4 v3, 0x4

    const-string/jumbo v0, "ondm.ettgntte.aema.llc..islttconpqcodtnri.a.nmrnn"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v1, "ecWcovrboeRiSmtke"

    const-string v1, "evWmoeeSRicrckbte"

    const/4 v3, 0x0

    const-string v1, "WvkteboriceRcSebe"

    const-string v1, "WebSocketReceiver"

    const/4 v2, 0x7

    and-int/2addr v3, v2

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public constructor <init>(Ljava/io/InputStream;Ljava/io/PipedInputStream;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v0, 0x0

    and-int/2addr v2, v0

    const/4 v1, 0x4

    move v2, v1

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->running:Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->stopping:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/Object;

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->lifecycle:Ljava/lang/Object;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->receiverThread:Ljava/lang/Thread;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->input:Ljava/io/InputStream;

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p1, Ljava/io/PipedOutputStream;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p1}, Ljava/io/PipedOutputStream;-><init>()V

    const/4 v1, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->pipedOutputStream:Ljava/io/PipedOutputStream;

    const/4 v2, 0x7

    invoke-virtual {p2, p1}, Ljava/io/PipedInputStream;->connect(Ljava/io/PipedOutputStream;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method private closeOutputStream()V
    .locals 3

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~~~.~u~~/~ov@ t~@@ u1~4 @~  @tl n@~~b-@di f a~bio@mo@@o~o   c~@@lfM ir/@ ~@ b o@K ~@~ @s@S@~~~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->pipedOutputStream:Ljava/io/PipedOutputStream;

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-virtual {v0}, Ljava/io/PipedOutputStream;->close()V
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->running:Z

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v0, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->input:Ljava/io/InputStream;

    const/4 v6, 0x4

    const/4 v5, 0x5

    if-eqz v0, :cond_4

    :try_start_0
    const/4 v6, 0x6

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string v1, "SRcercipbWtekeeoe"

    const-string/jumbo v1, "tereoevikRcSbceWe"

    const/4 v6, 0x3

    const-string v1, "eeeocStcqWvbrkiee"

    const-string v1, "WebSocketReceiver"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string/jumbo v2, "unr"

    const-string/jumbo v2, "unr"

    const-string/jumbo v2, "run"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string v3, "582"

    const-string v3, "852"

    const/4 v6, 0x7

    const-string v3, "528"

    const-string v3, "852"

    const/4 v6, 0x2

    const/4 v5, 0x2

    invoke-interface {v0, v1, v2, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->input:Ljava/io/InputStream;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/io/InputStream;->available()I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v6, 0x4

    if-lez v0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v0, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_1

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    move v0, v1

    move v0, v1

    const/4 v6, 0x2

    move v0, v1

    move v0, v1

    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->receiving:Z

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->input:Ljava/io/InputStream;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {v0, v2}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;-><init>(Ljava/io/InputStream;)V

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->isCloseFlag()Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-nez v2, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    move v2, v1

    move v2, v1

    :goto_2
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->getPayload()[B

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    array-length v3, v3

    const/4 v6, 0x3

    if-ge v2, v3, :cond_1

    const/4 v6, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->pipedOutputStream:Ljava/io/PipedOutputStream;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->getPayload()[B

    move-result-object v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    aget-byte v4, v4, v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Ljava/io/PipedOutputStream;->write(I)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto :goto_2

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->pipedOutputStream:Ljava/io/PipedOutputStream;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/io/PipedOutputStream;->flush()V

    const/4 v6, 0x0

    goto :goto_3

    :cond_2
    const/4 v6, 0x7

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->stopping:Z

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v0, :cond_3

    :goto_3
    const/4 v6, 0x3

    const/4 v5, 0x6

    iput-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->receiving:Z

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto/16 :goto_0

    :cond_3
    const/4 v6, 0x1

    new-instance v0, Ljava/io/IOException;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string v1, "ees pSnpSreCkc   t eSvor mwtsr tWObtio adeaheotehb"

    const-string/jumbo v1, "sS   b vemkat aCeoeeotptSOnWS oewpebtrce rhehtdr i"

    const/4 v6, 0x2

    const-string v1, "e  mweoehtatneodbivhm ct CsperSeekW O Sr tprteoa F"

    const-string v1, "Server sent a WebSocket Frame with the Stop OpCode"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {v0, v1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    throw v0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->stop()V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    goto/16 :goto_0

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    return-void
.end method

.method public isReceiving()Z
    .locals 3

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->receiving:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public isRunning()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->running:Z

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public start(Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v1, "cceSorRektieWoube"

    const-string v1, "bWeiReuetkecoSrce"

    const/4 v5, 0x6

    const-string v1, "icevrbeetSocbeRWk"

    const-string v1, "WebSocketReceiver"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-string/jumbo v2, "rutpa"

    const-string/jumbo v2, "tspra"

    const/4 v5, 0x2

    const-string/jumbo v2, "start"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string v3, "585"

    const-string v3, "855"

    const/4 v5, 0x1

    const-string v3, "855"

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {v0, v1, v2, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->lifecycle:Ljava/lang/Object;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->running:Z

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-nez v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-boolean v1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->running:Z

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    new-instance v1, Ljava/lang/Thread;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {v1, p0, p1}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->receiverThread:Ljava/lang/Thread;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    throw p1
.end method

.method public stop()V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v0, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->stopping:Z

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->lifecycle:Ljava/lang/Object;

    const/4 v6, 0x1

    or-int/2addr v7, v6

    monitor-enter v1

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    const-string v3, "RkbeWtepeececvoSi"

    const-string v3, "WebSocketReceiver"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string/jumbo v4, "psot"

    const-string/jumbo v4, "spto"

    const/4 v7, 0x7

    const-string/jumbo v4, "ostp"

    const-string/jumbo v4, "stop"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string v5, "580"

    const/4 v7, 0x0

    const-string v5, "850"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-interface {v2, v3, v4, v5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-boolean v2, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->running:Z

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz v2, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    iput-boolean v3, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->running:Z

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    iput-boolean v3, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->receiving:Z

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-direct {p0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->closeOutputStream()V

    const/4 v6, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    move v0, v3

    move v0, v3

    const/4 v7, 0x0

    move v0, v3

    move v0, v3

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    monitor-exit v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x4

    if-eqz v0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->receiverThread:Ljava/lang/Thread;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-nez v0, :cond_1

    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->receiverThread:Ljava/lang/Thread;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/lang/Thread;->join()V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0

    :catch_0
    :cond_1
    const/4 v7, 0x1

    const/4 v0, 0x1

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->receiverThread:Ljava/lang/Thread;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v1, "WciRqcbeqrtveokSe"

    const-string v1, "eRWteccvqeSriokeb"

    const/4 v7, 0x0

    const-string v1, "coscevieeSrktWeRe"

    const-string v1, "WebSocketReceiver"

    const/4 v7, 0x0

    const-string/jumbo v2, "ptos"

    const-string/jumbo v2, "stop"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-string v3, "815"

    const-string v3, "518"

    const/4 v7, 0x1

    const-string v3, "851"

    const-string v3, "851"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-interface {v0, v1, v2, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    return-void

    :catchall_0
    move-exception v0

    :try_start_2
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    monitor-exit v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    throw v0
.end method
