.class public Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;
.super Ljava/util/prefs/AbstractPreferences;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "Base64Encoder"
.end annotation


# instance fields
.field private base64String:Ljava/lang/String;

.field final synthetic this$0:Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;


# direct methods
.method public constructor <init>(Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;->this$0:Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0, v0, p1}, Ljava/util/prefs/AbstractPreferences;-><init>(Ljava/util/prefs/AbstractPreferences;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;->base64String:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method protected childSpi(Ljava/lang/String;)Ljava/util/prefs/AbstractPreferences;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "i su /@-~t~@f~il ~v@~r ~ ~@ ~s @~@ o@y@b~~@@l@~~~/@ So~o@mfc. ~@t  1~ ~KMo~ob~ @dno~ ib~@@4a@  @"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p1
.end method

.method protected childrenNamesSpi()[Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/prefs/BackingStoreException;
        }
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method protected flushSpi()V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/prefs/BackingStoreException;
        }
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public getBase64String()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;->base64String:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method protected getSpi(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p1
.end method

.method protected keysSpi()[Ljava/lang/String;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/prefs/BackingStoreException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method protected putSpi(Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;->base64String:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method protected removeNodeSpi()V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/prefs/BackingStoreException;
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method protected removeSpi(Ljava/lang/String;)V
    .locals 2

    return-void
.end method

.method protected syncSpi()V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/util/prefs/BackingStoreException;
        }
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method
