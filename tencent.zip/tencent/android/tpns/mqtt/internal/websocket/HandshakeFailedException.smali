.class public Lcom/tencent/android/tpns/mqtt/internal/websocket/HandshakeFailedException;
.super Ljava/lang/Exception;


# static fields
.field private static final serialVersionUID:J = 0x1L


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Exception;-><init>()V

    const/4 v0, 0x4

    shr-int/2addr v1, v0

    return-void
.end method
