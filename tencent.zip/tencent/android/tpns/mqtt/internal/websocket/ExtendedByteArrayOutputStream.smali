.class Lcom/tencent/android/tpns/mqtt/internal/websocket/ExtendedByteArrayOutputStream;
.super Ljava/io/ByteArrayOutputStream;


# instance fields
.field final webSocketNetworkModule:Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;

.field final webSocketSecureNetworkModule:Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketSecureNetworkModule;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    invoke-direct {p0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/ExtendedByteArrayOutputStream;->webSocketNetworkModule:Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 p1, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/ExtendedByteArrayOutputStream;->webSocketSecureNetworkModule:Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketSecureNetworkModule;

    const/4 v1, 0x4

    return-void
.end method

.method constructor <init>(Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketSecureNetworkModule;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/ExtendedByteArrayOutputStream;->webSocketNetworkModule:Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/ExtendedByteArrayOutputStream;->webSocketSecureNetworkModule:Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketSecureNetworkModule;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public flush()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " @slt@@ fa~bd. t~  @ i@o~@~l ~@o  1M @c/ ~@~4~@oi @u~~@ @@@/~ - ~~~ @~nbov~~S~rimso~@~ ~~@ybo@K@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    monitor-enter p0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v0}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->reset()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    new-instance v1, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v3, 0x2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {v1, v3, v2, v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;-><init>(BZ[B)V

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->encodeFrame()[B

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/ExtendedByteArrayOutputStream;->getSocketOutputStream()Ljava/io/OutputStream;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/io/OutputStream;->flush()V

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-void

    :catchall_0
    move-exception v0

    :try_start_1
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    throw v0
.end method

.method getSocketOutputStream()Ljava/io/OutputStream;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/ExtendedByteArrayOutputStream;->webSocketNetworkModule:Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;

    const/4 v2, 0x4

    const/4 v1, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->getSocketOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/ExtendedByteArrayOutputStream;->webSocketSecureNetworkModule:Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketSecureNetworkModule;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketSecureNetworkModule;->getSocketOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method
