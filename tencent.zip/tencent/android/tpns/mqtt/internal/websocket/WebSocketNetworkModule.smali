.class public Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;
.super Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "WebSocketNetworkModule"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private host:Ljava/lang/String;

.field private outputStream:Ljava/io/ByteArrayOutputStream;

.field private pipedInputStream:Ljava/io/PipedInputStream;

.field private port:I

.field recievedPayload:Ljava/nio/ByteBuffer;

.field private uri:Ljava/lang/String;

.field private webSocketReceiver:Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string/jumbo v0, "ntscoadt.aqsldtletioselccosntnminm....gnr.n.natep"

    const-string/jumbo v0, "nesomtdnesac.l.a.ndtnoilgea.no..cttpttisl.nqmcnrt"

    const/4 v3, 0x1

    const-string/jumbo v0, "lncmonta.ttiodcl.nan.cqraetosnmil..p.egtnetrm.dns"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string/jumbo v1, "ueMmNeeSceokwlotrWdtbk"

    const/4 v3, 0x4

    const-string/jumbo v1, "luceowdMktrbeWNooeSokt"

    const-string v1, "WebSocketNetworkModule"

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    return-void
.end method

.method public constructor <init>(Ljavax/net/SocketFactory;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0, p1, p3, p4, p5}, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;-><init>(Ljavax/net/SocketFactory;Ljava/lang/String;ILjava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    new-instance p1, Lcom/tencent/android/tpns/mqtt/internal/websocket/ExtendedByteArrayOutputStream;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p1, p0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/ExtendedByteArrayOutputStream;-><init>(Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->outputStream:Ljava/io/ByteArrayOutputStream;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->uri:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p3, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->host:Ljava/lang/String;

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput p4, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->port:I

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    new-instance p1, Ljava/io/PipedInputStream;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p1}, Ljava/io/PipedInputStream;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->pipedInputStream:Ljava/io/PipedInputStream;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x0

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v0, 0x5

    const/4 v0, 0x3

    invoke-interface {p1, p5}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->setResourceName(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public getInputStream()Ljava/io/InputStream;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~~i~@b @@n@ofoo@ is@ ~@@-~ c  ~m ~K~ @@@/r~@@od~~u@~ay@b oM@@1  ~i~~ t~~bl @/ 4fl  ~t@oSv .~~b@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->pipedInputStream:Ljava/io/PipedInputStream;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public getOutputStream()Ljava/io/OutputStream;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->outputStream:Ljava/io/ByteArrayOutputStream;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method

.method public getServerURI()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string v1, ":/wso"

    const/4 v3, 0x0

    const-string v1, ":uws/"

    const-string/jumbo v1, "ws://"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->host:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string v1, ":"

    const-string v1, ":"

    const/4 v3, 0x6

    const-string v1, ":"

    const-string v1, ":"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->port:I

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object v0
.end method

.method getSocketInputStream()Ljava/io/InputStream;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-super {p0}, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->getInputStream()Ljava/io/InputStream;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    return-object v0
.end method

.method getSocketOutputStream()Ljava/io/OutputStream;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-super {p0}, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->getOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public start()V
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v8, 0x3

    const/4 v7, 0x0

    invoke-super {p0}, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->start()V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-instance v6, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->getSocketInputStream()Ljava/io/InputStream;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->getSocketOutputStream()Ljava/io/OutputStream;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->uri:Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->host:Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget v5, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->port:I

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v5}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;-><init>(Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    invoke-virtual {v6}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->execute()V

    const/4 v8, 0x4

    const/4 v7, 0x5

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;

    const/4 v7, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->getSocketInputStream()Ljava/io/InputStream;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->pipedInputStream:Ljava/io/PipedInputStream;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {v0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;-><init>(Ljava/io/InputStream;Ljava/io/PipedInputStream;)V

    const/4 v7, 0x2

    or-int/2addr v8, v7

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->webSocketReceiver:Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;

    const/4 v8, 0x4

    const-string v1, "ebtcrbkeRewovcSee"

    const/4 v8, 0x2

    const-string/jumbo v1, "webSocketReceiver"

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->start(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    return-void
.end method

.method public stop()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v1, "0010"

    const/4 v5, 0x7

    const-string v1, "0001"

    const-string v1, "1000"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/16 v2, 0x8

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v3, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-direct {v0, v2, v3, v1}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;-><init>(BZ[B)V

    const/4 v5, 0x0

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->encodeFrame()[B

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->getSocketOutputStream()Ljava/io/OutputStream;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1, v0}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->getSocketOutputStream()Ljava/io/OutputStream;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/io/OutputStream;->flush()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketNetworkModule;->webSocketReceiver:Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketReceiver;->stop()V

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-super {p0}, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->stop()V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-void
.end method
