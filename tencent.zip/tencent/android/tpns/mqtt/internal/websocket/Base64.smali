.class public Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;
    }
.end annotation


# static fields
.field private static final ENCODER:Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;

.field private static final INSTANCE:Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;->INSTANCE:Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v1, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0}, Ljava/util/Objects;->requireNonNull(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v1, v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;-><init>(Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    sput-object v1, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;->ENCODER:Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public static encode(Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s @~@  b@o~~o4 ~t1 m@ ~.@a@n~~@~~@l~b@~fs@d@i tfKy- u@/o~~~ @@/~c~M rvb @ ~ ~ ~~oo@@ @@i  ol~S"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;->ENCODER:Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v1, "eyak"

    const-string/jumbo v1, "yaek"

    const/4 v3, 0x7

    const-string/jumbo v1, "yeka"

    const-string v1, "akey"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1, p0}, Ljava/util/prefs/Preferences;->putByteArray(Ljava/lang/String;[B)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;->getBase64String()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object p0
.end method

.method public static encodeBytes([B)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;->ENCODER:Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v1, "aKey"

    const-string v1, "Keay"

    const-string v1, "Kyea"

    const-string v1, "aKey"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p0}, Ljava/util/prefs/Preferences;->putByteArray(Ljava/lang/String;[B)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64$Base64Encoder;->getBase64String()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p0
.end method
