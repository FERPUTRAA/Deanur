.class public Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;
.super Ljava/lang/Object;


# static fields
.field public static final frameLengthOverhead:I = 0x6


# instance fields
.field private closeFlag:Z

.field private fin:Z

.field private opcode:B

.field private payload:[B


# direct methods
.method public constructor <init>(BZ[B)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->closeFlag:Z

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput-byte p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->opcode:B

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-boolean p2, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->fin:Z

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p3, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->payload:[B

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public constructor <init>(Ljava/io/InputStream;)V
    .locals 9
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/4 v0, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->closeFlag:Z

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {p1}, Ljava/io/InputStream;->read()I

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    int-to-byte v1, v1

    const/4 v8, 0x0

    invoke-direct {p0, v1}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->setFinAndOpCode(B)V

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    iget-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->opcode:B

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/4 v2, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/16 v3, 0x8

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/4 v4, 0x2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-ne v1, v4, :cond_8

    const/4 v8, 0x3

    invoke-virtual {p1}, Ljava/io/InputStream;->read()I

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    int-to-byte v1, v1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x3

    and-int/lit16 v5, v1, 0x80

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    if-eqz v5, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    move v2, v0

    move v2, v0

    const/4 v8, 0x3

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/16 v5, 0x7f

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    and-int/2addr v1, v5

    const/4 v8, 0x4

    const/4 v7, 0x6

    int-to-byte v1, v1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-ne v1, v5, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    goto :goto_1

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/16 v3, 0x7e

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-ne v1, v3, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    move v3, v4

    move v3, v4

    const/4 v8, 0x3

    move v3, v4

    move v3, v4

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x7

    goto :goto_1

    :cond_2
    const/4 v7, 0x1

    const/4 v7, 0x1

    move v3, v0

    move v3, v0

    const/4 v8, 0x4

    move v3, v0

    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-lez v3, :cond_3

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    move v1, v0

    move v1, v0

    const/4 v8, 0x2

    move v1, v0

    move v1, v0

    :cond_3
    :goto_2
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    add-int/lit8 v3, v3, -0x1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-ltz v3, :cond_4

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/io/InputStream;->read()I

    move-result v4

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    int-to-byte v4, v4

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    and-int/lit16 v4, v4, 0xff

    const/4 v8, 0x6

    mul-int/lit8 v5, v3, 0x8

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    shl-int/2addr v4, v5

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    or-int/2addr v1, v4

    const/4 v7, 0x0

    xor-int/2addr v8, v7

    goto :goto_2

    :cond_4
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    if-eqz v2, :cond_5

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/4 v3, 0x4

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    new-array v4, v3, [B

    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p1, v4, v0, v3}, Ljava/io/InputStream;->read([BII)I

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    goto :goto_3

    :cond_5
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/4 v4, 0x0

    :goto_3
    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    new-array v3, v1, [B

    const/4 v8, 0x1

    const/4 v7, 0x7

    iput-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->payload:[B

    move v3, v0

    move v3, v0

    const/4 v8, 0x5

    move v3, v0

    move v3, v0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    move v5, v1

    move v5, v1

    const/4 v8, 0x4

    move v5, v1

    move v5, v1

    :goto_4
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-eq v3, v1, :cond_6

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    iget-object v6, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->payload:[B

    const/4 v7, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {p1, v6, v3, v5}, Ljava/io/InputStream;->read([BII)I

    move-result v6

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    add-int/2addr v3, v6

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    sub-int/2addr v5, v6

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto :goto_4

    :cond_6
    const/4 v8, 0x4

    if-eqz v2, :cond_7

    :goto_5
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->payload:[B

    const/4 v8, 0x7

    array-length v1, p1

    const/4 v8, 0x6

    const/4 v7, 0x1

    if-ge v0, v1, :cond_7

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    aget-byte v1, p1, v0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    rem-int/lit8 v2, v0, 0x4

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    aget-byte v2, v4, v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    xor-int/2addr v1, v2

    const/4 v8, 0x0

    int-to-byte v1, v1

    const/4 v7, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    aput-byte v1, p1, v0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    add-int/lit8 v0, v0, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    goto :goto_5

    :cond_7
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    return-void

    :cond_8
    const/4 v7, 0x6

    move v8, v7

    if-ne v1, v3, :cond_9

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    iput-boolean v2, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->closeFlag:Z

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x6

    return-void

    :cond_9
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    new-instance p1, Ljava/io/IOException;

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string v1, "  smv:dr sOndie:cIeFala"

    const-string/jumbo v1, "mcsipvIrdeOana e::F ld "

    const/4 v8, 0x5

    const-string/jumbo v1, "oadm rO:epnd:evl I micF"

    const-string v1, "Invalid Frame: Opcode: "

    const/4 v8, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->opcode:B

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    throw p1
.end method

.method public constructor <init>([B)V
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->closeFlag:Z

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {p1}, Ljava/nio/ByteBuffer;->wrap([B)Ljava/nio/ByteBuffer;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->get()B

    move-result v1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {p0, v1}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->setFinAndOpCode(B)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->get()B

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    and-int/lit16 v2, v1, 0x80

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v2, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v2, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    goto :goto_0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    move v2, v0

    const/4 v7, 0x4

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/16 v3, 0x7f

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    and-int/2addr v1, v3

    const/4 v6, 0x1

    move v7, v6

    int-to-byte v1, v1

    const/4 v7, 0x5

    const/4 v6, 0x5

    if-ne v1, v3, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/16 v3, 0x8

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_1

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/16 v3, 0x7e

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-ne v1, v3, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    const/4 v3, 0x2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    goto :goto_1

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    move v3, v0

    move v3, v0

    const/4 v7, 0x3

    move v3, v0

    move v3, v0

    :goto_1
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    add-int/lit8 v3, v3, -0x1

    const/4 v7, 0x2

    if-lez v3, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/nio/ByteBuffer;->get()B

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    and-int/lit16 v4, v4, 0xff

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    mul-int/lit8 v5, v3, 0x8

    const/4 v7, 0x1

    const/4 v6, 0x2

    shl-int/2addr v4, v5

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    or-int/2addr v1, v4

    const/4 v6, 0x0

    move v7, v6

    goto :goto_1

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz v2, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 v3, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-array v4, v3, [B

    const/4 v6, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p1, v4, v0, v3}, Ljava/nio/ByteBuffer;->get([BII)Ljava/nio/ByteBuffer;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    goto :goto_2

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/4 v4, 0x0

    :goto_2
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    new-array v3, v1, [B

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    iput-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->payload:[B

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p1, v3, v0, v1}, Ljava/nio/ByteBuffer;->get([BII)Ljava/nio/ByteBuffer;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz v2, :cond_5

    :goto_3
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->payload:[B

    const/4 v6, 0x5

    array-length v1, p1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-ge v0, v1, :cond_5

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    aget-byte v1, p1, v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    rem-int/lit8 v2, v0, 0x4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    aget-byte v2, v4, v2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    xor-int/2addr v1, v2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    int-to-byte v1, v1

    const/4 v6, 0x6

    xor-int/2addr v7, v6

    aput-byte v1, p1, v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_3

    :cond_5
    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    return-void
.end method

.method public static appendFinAndOpCode(Ljava/nio/ByteBuffer;BZ)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@i ~o@  ~o bloofom ~@n~ r@@~i1~i/f ~~@@ Suv @~4l@~~~/@b  ~b  ~~~~  @@~y~oa~~ @dct @.@@@@Mt@-K~os"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    if-eqz p2, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    const/16 p2, 0x80

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    int-to-byte p2, p2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    const/4 p2, 0x0

    :goto_0
    const/4 v1, 0x5

    and-int/lit8 p1, p1, 0xf

    const/4 v1, 0x3

    const/4 v0, 0x2

    or-int/2addr p1, p2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    int-to-byte p1, p1

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v0, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method private static appendLength(Ljava/nio/ByteBuffer;IZ)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-ltz p1, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x0

    if-eqz p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/16 p2, -0x80

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    move p2, v0

    move p2, v0

    const/4 v3, 0x0

    move p2, v0

    move p2, v0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const v1, 0xffff

    const/4 v2, 0x4

    or-int/2addr v3, v2

    if-le p1, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    or-int/lit8 p2, p2, 0x7f

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    int-to-byte p2, p2

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0, p2}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    shr-int/lit8 p2, p1, 0x18

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    and-int/lit16 p2, p2, 0xff

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    int-to-byte p2, p2

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0, p2}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    shr-int/lit8 p2, p1, 0x10

    const/4 v3, 0x6

    and-int/lit16 p2, p2, 0xff

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    int-to-byte p2, p2

    const/4 v3, 0x7

    invoke-virtual {p0, p2}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    shr-int/lit8 p2, p1, 0x8

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    and-int/lit16 p2, p2, 0xff

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    int-to-byte p2, p2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0, p2}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    and-int/lit16 p1, p1, 0xff

    const/4 v3, 0x5

    int-to-byte p1, p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    goto :goto_1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/16 v0, 0x7e

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-lt p1, v0, :cond_2

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    or-int/2addr p2, v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    int-to-byte p2, p2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0, p2}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    shr-int/lit8 p2, p1, 0x8

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    int-to-byte p2, p2

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0, p2}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v3, 0x6

    const/4 v2, 0x6

    and-int/lit16 p1, p1, 0xff

    const/4 v2, 0x6

    move v3, v2

    int-to-byte p1, p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_1

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x4

    or-int/2addr p1, p2

    const/4 v3, 0x4

    const/4 v2, 0x4

    int-to-byte p1, p1

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    :goto_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string p1, "L hobbeanacmng enteitnegt"

    const-string/jumbo p1, "tnnmoteaheavebceg tiL nng"

    const/4 v3, 0x0

    const-string p1, "eha  nugLanot bgieceentvt"

    const-string p1, "Length cannot be negative"

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    throw p0
.end method

.method public static appendLengthAndMask(Ljava/nio/ByteBuffer;I[B)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p2, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->appendLength(Ljava/nio/ByteBuffer;IZ)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, p2}, Ljava/nio/ByteBuffer;->put([B)Ljava/nio/ByteBuffer;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 p2, 0x0

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->appendLength(Ljava/nio/ByteBuffer;IZ)V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public static generateMaskingKey()[B
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    new-instance v0, Ljava/security/SecureRandom;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-direct {v0}, Ljava/security/SecureRandom;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/16 v1, 0xff

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v3

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v1, 0x4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-array v1, v1, [B

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    int-to-byte v2, v2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    aput-byte v2, v1, v5

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v2, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    int-to-byte v3, v3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    aput-byte v3, v1, v2

    const/4 v7, 0x4

    const/4 v2, 0x2

    const/4 v7, 0x2

    xor-int/2addr v6, v2

    const/4 v7, 0x6

    int-to-byte v3, v4

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    aput-byte v3, v1, v2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v2, 0x3

    const/4 v7, 0x4

    const/4 v6, 0x2

    int-to-byte v0, v0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    aput-byte v0, v1, v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    return-object v1
.end method

.method private setFinAndOpCode(B)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    and-int/lit16 v0, p1, 0x80

    const/4 v2, 0x2

    const/4 v1, 0x2

    if-eqz v0, :cond_0

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->fin:Z

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    and-int/lit8 p1, p1, 0xf

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    int-to-byte p1, p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-byte p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->opcode:B

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method


# virtual methods
.method public encodeFrame()[B
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->payload:[B

    const/4 v6, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    array-length v1, v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    add-int/lit8 v1, v1, 0x6

    const/4 v7, 0x3

    const/4 v6, 0x7

    array-length v2, v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    const v3, 0xffff

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-le v2, v3, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    add-int/lit8 v1, v1, 0x8

    const/4 v6, 0x3

    shr-int/2addr v7, v6

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    move v7, v6

    array-length v0, v0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/16 v2, 0x7e

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-lt v0, v2, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    add-int/lit8 v1, v1, 0x2

    :cond_1
    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {v1}, Ljava/nio/ByteBuffer;->allocate(I)Ljava/nio/ByteBuffer;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-byte v1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->opcode:B

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-boolean v2, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->fin:Z

    const/4 v7, 0x3

    invoke-static {v0, v1, v2}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->appendFinAndOpCode(Ljava/nio/ByteBuffer;BZ)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->generateMaskingKey()[B

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->payload:[B

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    array-length v2, v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->appendLengthAndMask(Ljava/nio/ByteBuffer;I[B)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    const/4 v2, 0x0

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->payload:[B

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    array-length v4, v3

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-ge v2, v4, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    aget-byte v4, v3, v2

    const/4 v7, 0x3

    rem-int/lit8 v5, v2, 0x4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    aget-byte v5, v1, v5

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    xor-int/2addr v4, v5

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    int-to-byte v4, v4

    const/4 v7, 0x6

    aput-byte v4, v3, v2

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0, v4}, Ljava/nio/ByteBuffer;->put(B)Ljava/nio/ByteBuffer;

    const/4 v7, 0x3

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x7

    goto :goto_1

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->flip()Ljava/nio/Buffer;

    const/4 v7, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/nio/ByteBuffer;->array()[B

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-object v0
.end method

.method public getOpcode()B
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-byte v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->opcode:B

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public getPayload()[B
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->payload:[B

    const/4 v2, 0x0

    const/4 v1, 0x2

    return-object v0
.end method

.method public isCloseFlag()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->closeFlag:Z

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public isFin()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketFrame;->fin:Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    return v0
.end method
