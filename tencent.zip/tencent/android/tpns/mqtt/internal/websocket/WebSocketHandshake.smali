.class public Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;
.super Ljava/lang/Object;


# static fields
.field private static final ACCEPT_SALT:Ljava/lang/String; = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

.field private static final EMPTY:Ljava/lang/String; = ""

.field private static final HTTP_HEADER_CONNECTION:Ljava/lang/String; = "connection"

.field private static final HTTP_HEADER_CONNECTION_VALUE:Ljava/lang/String; = "upgrade"

.field private static final HTTP_HEADER_SEC_WEBSOCKET_ACCEPT:Ljava/lang/String; = "sec-websocket-accept"

.field private static final HTTP_HEADER_SEC_WEBSOCKET_PROTOCOL:Ljava/lang/String; = "sec-websocket-protocol"

.field private static final HTTP_HEADER_UPGRADE:Ljava/lang/String; = "upgrade"

.field private static final HTTP_HEADER_UPGRADE_WEBSOCKET:Ljava/lang/String; = "websocket"

.field private static final LINE_SEPARATOR:Ljava/lang/String; = "\r\n"

.field private static final SHA1_PROTOCOL:Ljava/lang/String; = "SHA1"


# instance fields
.field host:Ljava/lang/String;

.field input:Ljava/io/InputStream;

.field output:Ljava/io/OutputStream;

.field port:I

.field uri:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/io/InputStream;Ljava/io/OutputStream;Ljava/lang/String;Ljava/lang/String;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->input:Ljava/io/InputStream;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->output:Ljava/io/OutputStream;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->uri:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p4, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->host:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput p5, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->port:I

    const/4 v1, 0x2

    return-void
.end method

.method private getHeaders(Ljava/util/ArrayList;)Ljava/util/Map;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "i@s @ o@b@yi v/@~~f@~@  mo~- @4l o@S o@~f@Kb~ ~~  ~~@~~nt@~~@ ~~uoo s ~d @~r~i@a @.@b@1@/t~c~ lM"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v1, 0x1

    move v6, v1

    const/4 v5, 0x2

    move v2, v1

    move v2, v1

    const/4 v6, 0x2

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-ge v2, v3, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    check-cast v3, Ljava/lang/String;

    const/4 v6, 0x3

    const-string v4, ":"

    const-string v4, ":"

    const/4 v6, 0x7

    const-string v4, ":"

    const-string v4, ":"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    const/4 v4, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    aget-object v4, v3, v4

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v4}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    aget-object v3, v3, v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-interface {v0, v4, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    return-object v0
.end method

.method private receiveHandshakeResponse(Ljava/lang/String;)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-instance v0, Ljava/io/BufferedReader;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v1, Ljava/io/InputStreamReader;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->input:Ljava/io/InputStream;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const-string v3, "FsTmU"

    const-string v3, "8UsFT"

    const/4 v5, 0x0

    const-string v3, "UTF-8"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {v1, v2, v3}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-direct {v0, v1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance v1, Ljava/util/ArrayList;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz v2, :cond_5

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v2, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x5

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x5

    if-nez v3, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {p0, v1}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->getHeaders(Ljava/util/ArrayList;)Ljava/util/Map;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v1, "imccotnenn"

    const-string/jumbo v1, "incmoenntc"

    const/4 v5, 0x7

    const-string/jumbo v1, "otninbceoc"

    const-string v1, "connection"

    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    check-cast v1, Ljava/lang/String;

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    if-eqz v1, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v2, "eorugau"

    const-string v2, "gurpoea"

    const/4 v5, 0x6

    const-string/jumbo v2, "upgrade"

    const/4 v4, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez v1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-interface {v0, v2}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v1, :cond_3

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const-string/jumbo v2, "ksbeweopc"

    const-string/jumbo v2, "websocket"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    if-eqz v1, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const-string v1, "c-crbepcqkoteltsosewoo"

    const-string/jumbo v1, "pwtoebslreoo-bsktcceco"

    const/4 v5, 0x7

    const-string/jumbo v1, "oksrelspocoe-bcocstew-"

    const-string/jumbo v1, "sec-websocket-protocol"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v1, "ktomcbscpe-seewc-atc"

    const-string/jumbo v1, "sec-websocket-accept"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    if-eqz v2, :cond_1

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    check-cast v0, Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {p0, p1, v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->verifyWebSocketKey(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Lcom/tencent/android/tpns/mqtt/internal/websocket/HandshakeFailedException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void

    :catch_0
    new-instance p1, Ljava/io/IOException;

    const/4 v5, 0x2

    const-string v0, "ancooWperdc yrSec-suSeceWeRSekctrs btkKtobo:eeee o-hIn"

    const-string v0, "SR ca ueksoenK-cSksrbber ho-eeetcopWee:enI ocdtytrceSW"

    const/4 v5, 0x2

    const-string v0, "cpeecbaeckyrrWtdKrceoR eo- tsIshnSn:WeeS oebeoteeb Sc-"

    const-string v0, "WebSocket Response header: Incorrect Sec-WebSocket-Key"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    throw p1

    :catch_1
    move-exception p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    new-instance v0, Ljava/io/IOException;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    throw v0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    new-instance p1, Ljava/io/IOException;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v0, "c:oeeou-ScrseknocitpReMkssatn-tAcS b Wee eshiepcgdeebpS"

    const-string v0, "-SeeeS:peRt ehccktgiskse ecnd-ep rceoceWaM otSpbsbsoniA"

    const-string v0, "SrotkoepsRdt-acipcWhiect keescpnWSbbe ncese oeMee:g-s A"

    const-string v0, "WebSocket Response header: Missing Sec-WebSocket-Accept"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    throw p1

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance p1, Ljava/io/IOException;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v0, "eleRdcteqsbetscskr-sntop Wapeor m:et cySeoeq e-pcbwohke"

    const-string v0, "hprbeesmqsneckcelpRe:o-so-teopdty tak oeS eWwecebrsoc t"

    const/4 v5, 0x0

    const-string/jumbo v0, "spsweorst tapeesoepoh bo tbo:m-ynceocerceSeWeksk cltRde"

    const-string v0, "WebSocket Response header: empty sec-websocket-protocol"

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    throw p1

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    new-instance p1, Ljava/io/IOException;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v0, ".remhdegea eRsnpdrrocck a u:nWocIepbteot rsee"

    const-string v0, "WebSocket Response header: Incorrect upgrade."

    const/4 v4, 0x7

    move v5, v4

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    throw p1

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance p1, Ljava/io/IOException;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v0, "roenorsccep St ee:aenncorcicons eetrh RWasoonekbd ehdt"

    const-string v0, "cestcnboneeodcsenetrhenkoa  icSs dpecrrreonWRoe t:hae "

    const/4 v5, 0x4

    const-string v0, "d eaebIeseinot rn hce:ten ooohRaecstkeedonrerrpbn Wccc"

    const-string v0, "WebSocket Response header: Incorrect connection header"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    move v5, v4

    throw p1

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance p1, Ljava/io/IOException;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v0, "m,hmW  sScnnpb trsbc vdnelnakeurW erI. rver oee:fSepotSIipo oysa eeroemeosRaett dospt k"

    const/4 v5, 0x6

    const-string/jumbo v0, "vWon mue:eu.rtnrras SsepSfdeaoRr ntIbksm a,roeteetWnyb op oecSpl pIdk shcr esiv e seoot"

    const-string v0, "WebSocket Response header: Invalid response from Server, It may not support WebSockets."

    const/4 v5, 0x5

    const/4 v4, 0x0

    invoke-direct {p1, v0}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    throw p1
.end method

.method private sendHandshakeRequest(Ljava/lang/String;)V
    .locals 8
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v7, 0x7

    const-string/jumbo v0, "n//r"

    const-string/jumbo v0, "r/n/"

    const/4 v7, 0x6

    const-string v0, "\r\n"

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string/jumbo v1, "qmpto"

    const-string/jumbo v1, "tmqto"

    const/4 v7, 0x2

    const-string v1, "/mqtt"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-instance v2, Ljava/net/URI;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->uri:Ljava/lang/String;

    const/4 v7, 0x2

    invoke-direct {v2, v3}, Ljava/net/URI;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v2}, Ljava/net/URI;->getRawPath()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-eqz v3, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/net/URI;->getRawPath()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x0

    if-nez v3, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/net/URI;->getRawPath()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/net/URI;->getRawQuery()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v3, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v2}, Ljava/net/URI;->getRawQuery()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v3}, Ljava/lang/String;->isEmpty()Z

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-nez v3, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string v1, "?"

    const-string v1, "?"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v2}, Ljava/net/URI;->getRawQuery()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    new-instance v3, Ljava/io/PrintWriter;

    const/4 v7, 0x0

    const/4 v6, 0x1

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->output:Ljava/io/OutputStream;

    const/4 v7, 0x0

    const/4 v6, 0x7

    invoke-direct {v3, v4}, Ljava/io/PrintWriter;-><init>(Ljava/io/OutputStream;)V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v5, " EGT"

    const-string v5, "T GE"

    const/4 v7, 0x3

    const-string v5, "GE T"

    const-string v5, "GET "

    const/4 v7, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v1, " T1/1HPbq"

    const-string v1, "1TH1.bP/ "

    const/4 v7, 0x2

    const-string v1, "HTsT P/1."

    const-string v1, " HTTP/1.1"

    const/4 v7, 0x1

    const/4 v6, 0x6

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    or-int/2addr v7, v6

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const/4 v7, 0x5

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->port:I
    :try_end_0
    .catch Ljava/net/URISyntaxException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/16 v4, 0x50

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string/jumbo v5, "s:omHu"

    const-string/jumbo v5, "us:tHo"

    const/4 v7, 0x2

    const-string v5, "Host: "

    const/4 v7, 0x1

    const/4 v6, 0x0

    if-eq v1, v4, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    const/16 v4, 0x1bb

    const/4 v7, 0x7

    if-eq v1, v4, :cond_1

    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->host:Ljava/lang/String;

    const/4 v7, 0x7

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string v4, ":"

    const-string v4, ":"

    const/4 v7, 0x6

    const-string v4, ":"

    const-string v4, ":"

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget v4, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->port:I

    const/4 v7, 0x3

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    move v7, v6

    iget-object v4, p0, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->host:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string v1, "Uescowp/dop/rgak :nteb"

    const-string/jumbo v1, "werkg:Updrastn/pebc/o "

    const/4 v7, 0x0

    const-string v1, "Upgrade: websocket\r\n"

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v1, "ronrpbnC a:qeet/co/ngUn"

    const-string/jumbo v1, "pn/gUaorqecnn/:tne riCo"

    const/4 v7, 0x1

    const-string v1, "cgnre/uCp/onndotnr eaU:"

    const-string v1, "Connection: Upgrade\r\n"

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v3, v1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const/4 v7, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string v4, "eKs-o tScyeb:We-eck"

    const/4 v7, 0x3

    const-string/jumbo v4, "yb-o:Wcpkece-teeS S"

    const-string v4, "Sec-WebSocket-Key: "

    const/4 v7, 0x2

    const/4 v6, 0x2

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const/4 v6, 0x7

    shl-int/2addr v7, v6

    const-string p1, ":cneP-WcqcomtrSqte olSb/to-ro/kt"

    const-string/jumbo p1, "tScmrP-Wlotenqor-b/c:oetto/Sck e"

    const/4 v7, 0x4

    const-string p1, "Sestl tcnbrtooco-S/te-/PqmW:ekoc"

    const-string p1, "Sec-WebSocket-Protocol: mqtt\r\n"

    const/4 v6, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-string p1, "Wnnmetc/eiSo13-kScr/e-V:bosor"

    const-string p1, ":1ceot oWk-eS-/riSnVsre/obc3n"

    const/4 v7, 0x1

    const-string p1, "e/iWoco: /e-SeSn-orcVrktb3n1e"

    const-string p1, "Sec-WebSocket-Version: 13\r\n"

    const/4 v7, 0x5

    invoke-virtual {v3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v2}, Ljava/net/URI;->getUserInfo()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz p1, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string v2, "cr  zboiiaiot:uaBhbAn"

    const-string/jumbo v2, "zh:icban tBAtoioua ri"

    const/4 v7, 0x6

    const-string/jumbo v2, "it zoauoctiA:usni hBr"

    const-string v2, "Authorization: Basic "

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;->encode(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v3, p1}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v3, v0}, Ljava/io/PrintWriter;->print(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v3}, Ljava/io/PrintWriter;->flush()V
    :try_end_1
    .catch Ljava/net/URISyntaxException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    return-void

    :catch_0
    move-exception p1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p1}, Ljava/net/URISyntaxException;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    shl-int/2addr v7, v6

    throw v0
.end method

.method private sha1(Ljava/lang/String;)[B
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/security/NoSuchAlgorithmException;
        }
    .end annotation

    const/4 v1, 0x7

    move v2, v1

    const-string v0, "H1AS"

    const-string v0, "1HAS"

    const/4 v2, 0x3

    const-string v0, "SH1A"

    const-string v0, "SHA1"

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {v0}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/String;->getBytes()[B

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0, p1}, Ljava/security/MessageDigest;->digest([B)[B

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p1
.end method

.method private verifyWebSocketKey(Ljava/lang/String;Ljava/lang/String;)V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/security/NoSuchAlgorithmException;,
            Lcom/tencent/android/tpns/mqtt/internal/websocket/HandshakeFailedException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string p1, "DB-1E0ApA5AC9C4A1DF18-7555B-A82-EC9u"

    const-string p1, "97BDA-u542818AF1A-AD5-ECB5AC51C-490E"

    const/4 v2, 0x5

    const-string p1, "-5A85450qC5-2AFE749CD18B9BCEAD--AA15"

    const-string p1, "258EAFA5-E914-47DA-95CA-C5AB0DC85B11"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->sha1(Ljava/lang/String;)[B

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;->encodeBytes([B)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance p1, Lcom/tencent/android/tpns/mqtt/internal/websocket/HandshakeFailedException;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {p1}, Lcom/tencent/android/tpns/mqtt/internal/websocket/HandshakeFailedException;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    throw p1
.end method


# virtual methods
.method public execute()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/16 v0, 0x10

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-array v1, v0, [B

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x5

    const-string v2, ""

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/String;->getBytes()[B

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v2, v3, v1, v3, v0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v1}, Lcom/tencent/android/tpns/mqtt/internal/websocket/Base64;->encodeBytes([B)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->sendHandshakeRequest(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-direct {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/websocket/WebSocketHandshake;->receiveHandshakeResponse(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void
.end method
