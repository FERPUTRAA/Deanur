.class public Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;
.super Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;


# static fields
.field private static final CLASS_NAME:Ljava/lang/String; = "SSLNetworkModule"

.field private static final log:Lcom/tencent/android/tpns/mqtt/logging/Logger;


# instance fields
.field private enabledCiphers:[Ljava/lang/String;

.field private handshakeTimeoutSecs:I

.field private host:Ljava/lang/String;

.field private hostnameVerifier:Ljavax/net/ssl/HostnameVerifier;

.field private port:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v0, ".lscm.tpsdtg..eacnetotsnmiretlnina.adnlq.snoonrct"

    const-string v0, ".ssiarncnotcoa.ims.ne.tetmanncn.lttltdr..eqndlogp"

    const/4 v3, 0x4

    const-string v0, "dplm.enn.oeto.iceg.qnnat.cmntacrasnn.stdri.tltlom"

    const-string v0, "com.tencent.android.tpns.mqtt.internal.nls.logcat"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v1, "SluwoLdNMerktoSo"

    const-string/jumbo v1, "oNMmtkruLlSwedoS"

    const/4 v3, 0x0

    const-string/jumbo v1, "orLelbStkouMweSN"

    const-string v1, "SSLNetworkModule"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/LoggerFactory;->getLogger(Ljava/lang/String;Ljava/lang/String;)Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    sput-object v0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public constructor <init>(Ljavax/net/ssl/SSLSocketFactory;Ljava/lang/String;ILjava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;-><init>(Ljavax/net/SocketFactory;Ljava/lang/String;ILjava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->host:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p3, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->port:I

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    sget-object p1, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-interface {p1, p4}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->setResourceName(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public getEnabledCiphers()[Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "i~co~bu@@K@~~o~@@ r~v@ @ @n @oo  o~ ~ ~Slb@4~ ~/m@ldi~-~fy~ .@ @ut~@iM/@   @s~~ ~ab ~ @~~@1t~f@@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->enabledCiphers:[Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public getSSLHostnameVerifier()Ljavax/net/ssl/HostnameVerifier;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->hostnameVerifier:Ljavax/net/ssl/HostnameVerifier;

    const/4 v2, 0x0

    const/4 v1, 0x4

    return-object v0
.end method

.method public getServerURI()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    move v3, v2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo v1, "sp:osl"

    const-string/jumbo v1, "lss/o:"

    const-string v1, "//ql:s"

    const-string/jumbo v1, "ssl://"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->host:Ljava/lang/String;

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, ":"

    const-string v1, ":"

    const/4 v3, 0x2

    const-string v1, ":"

    const-string v1, ":"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget v1, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->port:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object v0
.end method

.method public setEnabledCiphers([Ljava/lang/String;)V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->enabledCiphers:[Ljava/lang/String;

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v0, :cond_3

    const/4 v5, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz p1, :cond_3

    const/4 v5, 0x0

    const/4 v6, 0x5

    sget-object v0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v1, 0x5

    const/4 v5, 0x5

    move v6, v5

    invoke-interface {v0, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->isLoggable(I)Z

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v0, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v6, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    move v2, v0

    move v2, v0

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    array-length v3, p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-ge v2, v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-lez v2, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v1, ","

    const-string v1, ","

    const/4 v6, 0x1

    const-string v1, ","

    const-string v1, ","

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    aget-object v1, p1, v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    sget-object v2, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->log:Lcom/tencent/android/tpns/mqtt/logging/Logger;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v3, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    aput-object v1, v3, v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const-string/jumbo v0, "toMLobeudlSeNwrk"

    const/4 v6, 0x1

    const-string v0, "desNoLwkuSoeSMtl"

    const-string v0, "SSLNetworkModule"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string v1, "EptmhadblreCsnsui"

    const-string/jumbo v1, "pdeblrunCEhtasise"

    const/4 v6, 0x3

    const-string/jumbo v1, "tepCoearlbhssneEi"

    const-string/jumbo v1, "setEnabledCiphers"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string v4, "620"

    const-string v4, "062"

    const/4 v6, 0x3

    const-string v4, "026"

    const-string v4, "260"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-interface {v2, v0, v1, v4, v3}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    check-cast v0, Ljavax/net/ssl/SSLSocket;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0, p1}, Ljavax/net/ssl/SSLSocket;->setEnabledCipherSuites([Ljava/lang/String;)V

    :cond_3
    const/4 v6, 0x2

    return-void
.end method

.method public setSSLHostnameVerifier(Ljavax/net/ssl/HostnameVerifier;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->hostnameVerifier:Ljavax/net/ssl/HostnameVerifier;

    const/4 v1, 0x2

    const/4 v0, 0x5

    return-void
.end method

.method public setSSLhandshakeTimeout(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-super {p0, p1}, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->setConnectTimeout(I)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->handshakeTimeoutSecs:I

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public start()V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/io/IOException;,
            Lcom/tencent/android/tpns/mqtt/MqttException;
        }
    .end annotation

    const/4 v5, 0x0

    invoke-super {p0}, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->start()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->enabledCiphers:[Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->setEnabledCiphers([Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v5, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/net/Socket;->getSoTimeout()I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget v2, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->handshakeTimeoutSecs:I

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    mul-int/lit16 v2, v2, 0x3e8

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/net/Socket;->setSoTimeout(I)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    check-cast v1, Ljavax/net/ssl/SSLSocket;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljavax/net/ssl/SSLSocket;->startHandshake()V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->hostnameVerifier:Ljavax/net/ssl/HostnameVerifier;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    check-cast v1, Ljavax/net/ssl/SSLSocket;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljavax/net/ssl/SSLSocket;->getSession()Ljavax/net/ssl/SSLSession;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->hostnameVerifier:Ljavax/net/ssl/HostnameVerifier;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpns/mqtt/internal/SSLNetworkModule;->host:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v2, v3, v1}, Ljavax/net/ssl/HostnameVerifier;->verify(Ljava/lang/String;Ljavax/net/ssl/SSLSession;)Z

    :cond_0
    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/internal/TCPNetworkModule;->socket:Ljava/net/Socket;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Ljava/net/Socket;->setSoTimeout(I)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void
.end method
