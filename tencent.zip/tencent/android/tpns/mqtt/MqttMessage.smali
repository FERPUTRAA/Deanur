.class public Lcom/tencent/android/tpns/mqtt/MqttMessage;
.super Ljava/lang/Object;


# instance fields
.field private dup:Z

.field private messageId:I

.field private mutable:Z

.field private payload:[B

.field private qos:I

.field private retained:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->mutable:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->qos:I

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->retained:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->dup:Z

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    new-array v0, v0, [B

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setPayload([B)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>([B)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->mutable:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->qos:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->retained:Z

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->dup:Z

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setPayload([B)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method public static validateQos(I)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ls~@. mdb~~ / os /o@~@@~~@  ~@@y@o~~ t n@ ~~M@ @S@@ubKfl1@~~4 i~i~o bt~f~aio@@  ro@- @@@~~v~~ c"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    if-ltz p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-gt p0, v0, :cond_0

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    throw p0
.end method


# virtual methods
.method protected checkMutable()V
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalStateException;
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->mutable:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    throw v0
.end method

.method public clearPayload()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->checkMutable()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    new-array v0, v0, [B

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->payload:[B

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public getId()I
    .locals 3

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->messageId:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public getPayload()[B
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->payload:[B

    const/4 v2, 0x3

    return-object v0
.end method

.method public getQos()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->qos:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public isDuplicate()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->dup:Z

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public isRetained()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->retained:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method protected setDuplicate(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->dup:Z

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public setId(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->messageId:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method protected setMutable(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->mutable:Z

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public setPayload([B)V
    .locals 2

    const/4 v1, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->checkMutable()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->payload:[B

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public setQos(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->checkMutable()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->validateQos(I)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->qos:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public setRetained(Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->checkMutable()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->retained:Z

    const/4 v1, 0x1

    const/4 v0, 0x2

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/MqttMessage;->payload:[B

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/lang/String;-><init>([B)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-object v0
.end method
