.class Lcom/tencent/android/tpns/mqtt/TimerPingSender$PingTask;
.super Ljava/util/TimerTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpns/mqtt/TimerPingSender;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "PingTask"
.end annotation


# static fields
.field private static final methodName:Ljava/lang/String; = "PingTask.run"


# instance fields
.field final synthetic this$0:Lcom/tencent/android/tpns/mqtt/TimerPingSender;


# direct methods
.method private constructor <init>(Lcom/tencent/android/tpns/mqtt/TimerPingSender;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/TimerPingSender$PingTask;->this$0:Lcom/tencent/android/tpns/mqtt/TimerPingSender;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/android/tpns/mqtt/TimerPingSender;Lcom/tencent/android/tpns/mqtt/TimerPingSender$1;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/TimerPingSender$PingTask;-><init>(Lcom/tencent/android/tpns/mqtt/TimerPingSender;)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "f si@@~@@1~ @@~u~~b ad4o S/ o~@~r~o~~s@m~t  nt@@~-i  ~ Ky@@l@~bv@ bo~i @o~~ ~@~~f @co@./@~M~l@  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/Long;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {v2, v3, v4}, Ljava/lang/Long;-><init>(J)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    aput-object v2, v1, v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo v2, "rinmdTeemigrSsP"

    const-string/jumbo v2, "mPseSederngTiri"

    const/4 v6, 0x6

    const-string v2, "TimerPingSender"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo v3, "uigkornPnas."

    const-string v3, "PingTask.run"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string v4, "660"

    const-string v4, "606"

    const/4 v6, 0x3

    const-string v4, "660"

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-interface {v0, v2, v3, v4, v1}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;[Ljava/lang/Object;)V

    const/4 v5, 0x6

    move v6, v5

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/TimerPingSender$PingTask;->this$0:Lcom/tencent/android/tpns/mqtt/TimerPingSender;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/TimerPingSender;->access$200(Lcom/tencent/android/tpns/mqtt/TimerPingSender;)Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->checkForActivity()Lcom/tencent/android/tpns/mqtt/MqttToken;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    return-void
.end method
