.class Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$ReconnectTask;
.super Ljava/util/TimerTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "ReconnectTask"
.end annotation


# static fields
.field private static final methodName:Ljava/lang/String; = "ReconnectTask.run"


# instance fields
.field final synthetic this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;


# direct methods
.method private constructor <init>(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$ReconnectTask;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/util/TimerTask;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$1;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$ReconnectTask;-><init>(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  s/oin@o@uit~ ir~db~@~@o@@~@v~4M o~@  ~ @~f ~o@ fc.b@~ 1@@ ~@~y~@m@s ~b ~- l~S@a@ot@ /Kl~~~ @~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$100()Lcom/tencent/android/tpns/mqtt/logging/Logger;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo v1, "ucnmTsenasRk.note"

    const-string/jumbo v1, "nns.rcToeRtaeknsu"

    const/4 v5, 0x2

    const-string v1, "cnseokanot.ecuTnr"

    const-string v1, "ReconnectTask.run"

    const/4 v4, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v2, "650"

    const-string v2, "650"

    const/4 v5, 0x3

    const-string v2, "056"

    const-string v2, "506"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v3, "AMsntbtCmnlyeqc"

    const-string/jumbo v3, "yntmlqcAsCtienM"

    const/4 v5, 0x6

    const-string v3, "AiMqtcultCnseny"

    const-string v3, "MqttAsyncClient"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-interface {v0, v3, v1, v2}, Lcom/tencent/android/tpns/mqtt/logging/Logger;->fine(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$ReconnectTask;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$200(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    return-void
.end method
