.class public Lcom/tencent/android/tpns/mqtt/MqttTopic;
.super Ljava/lang/Object;


# static fields
.field private static final MAX_TOPIC_LEN:I = 0xffff

.field private static final MIN_TOPIC_LEN:I = 0x1

.field public static final MULTI_LEVEL_WILDCARD:Ljava/lang/String; = "#"

.field public static final MULTI_LEVEL_WILDCARD_PATTERN:Ljava/lang/String; = "/#"

.field private static final NUL:C = '\u0000'

.field public static final SINGLE_LEVEL_WILDCARD:Ljava/lang/String; = "+"

.field public static final TOPIC_LEVEL_SEPARATOR:Ljava/lang/String; = "/"

.field public static final TOPIC_WILDCARDS:Ljava/lang/String; = "#+"


# instance fields
.field private comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

.field private name:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/internal/ClientComms;)V
    .locals 2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/tencent/android/tpns/mqtt/MqttTopic;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttTopic;->name:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method private createPublish(Lcom/tencent/android/tpns/mqtt/MqttMessage;)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "-tsbbi@~ ~ci/ ~o l~  @@ 4@/~~ ~@ ~@ ~o~~@@@ vi@ Ka~@~~~ ~@~r @~d@o o~ u@f.~ Mmo@o~Sl~@n@@ysf1 @b"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    new-instance v0, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttTopic;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v0, v1, p1}, Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;-><init>(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttMessage;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-object v0
.end method

.method public static isMatched(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 13
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x2

    const/4 v2, 0x1

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-static {p0, v2}, Lcom/tencent/android/tpns/mqtt/MqttTopic;->validate(Ljava/lang/String;Z)V

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x7

    const/4 v3, 0x0

    const/4 v12, 0x4

    const/4 v11, 0x1

    invoke-static {p1, v3}, Lcom/tencent/android/tpns/mqtt/MqttTopic;->validate(Ljava/lang/String;Z)V

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {p0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x6

    if-eqz v4, :cond_0

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x0

    return v2

    :cond_0
    const/4 v12, 0x1

    const/4 v11, 0x5

    move v4, v3

    const/4 v12, 0x3

    move v4, v3

    move v4, v3

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x2

    move v5, v4

    move v5, v4

    const/4 v12, 0x4

    move v5, v4

    move v5, v4

    :goto_0
    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x7

    if-ge v4, v1, :cond_5

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x3

    if-ge v5, v0, :cond_5

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-virtual {p1, v5}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v12, 0x3

    const/16 v7, 0x2f

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x6

    if-ne v6, v7, :cond_1

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    if-eq v6, v7, :cond_1

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x4

    goto :goto_2

    :cond_1
    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x1

    const/16 v8, 0x23

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x2

    const/16 v9, 0x2b

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-eq v6, v9, :cond_2

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x5

    if-eq v6, v8, :cond_2

    const/4 v11, 0x2

    const/4 v11, 0x1

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-virtual {p1, v5}, Ljava/lang/String;->charAt(I)C

    move-result v10

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x1

    if-eq v6, v10, :cond_2

    const/4 v11, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x2

    goto :goto_2

    :cond_2
    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x4

    if-ne v6, v9, :cond_3

    :goto_1
    const/4 v12, 0x4

    const/4 v11, 0x1

    add-int/lit8 v6, v5, 0x1

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x1

    if-ge v6, v0, :cond_4

    const/4 v12, 0x3

    const/4 v11, 0x7

    invoke-virtual {p1, v6}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    if-eq v6, v7, :cond_4

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x3

    add-int/lit8 v5, v5, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    goto :goto_1

    :cond_3
    const/4 v12, 0x3

    invoke-virtual {p0, v4}, Ljava/lang/String;->charAt(I)C

    move-result v6

    const/4 v12, 0x2

    const/4 v11, 0x0

    if-ne v6, v8, :cond_4

    const/4 v11, 0x7

    const/4 v12, 0x2

    add-int/lit8 v5, v0, -0x1

    :cond_4
    const/4 v12, 0x2

    add-int/lit8 v4, v4, 0x1

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x2

    add-int/2addr v5, v2

    const/4 v12, 0x1

    const/4 v11, 0x4

    goto/16 :goto_0

    :cond_5
    :goto_2
    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    if-ne v5, v0, :cond_6

    const/4 v11, 0x6

    shr-int/2addr v12, v11

    if-ne v4, v1, :cond_6

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x3

    goto :goto_3

    :cond_6
    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    :goto_3
    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x6

    return v2
.end method

.method public static validate(Ljava/lang/String;Z)V
    .locals 6
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/IllegalArgumentException;
        }
    .end annotation

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string v0, "8TUm-"

    const-string v0, "8Ts-U"

    const/4 v5, 0x7

    const-string v0, "T8FUo"

    const-string v0, "UTF-8"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    array-length v0, v0
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    const v1, 0xffff

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-lt v0, v2, :cond_5

    const/4 v4, 0x1

    or-int/2addr v5, v4

    if-gt v0, v1, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz p1, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string p1, "+"

    const-string p1, "+"

    const/4 v5, 0x6

    const-string p1, "+"

    const-string p1, "+"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v0, "#"

    const-string v0, "#"

    const/4 v5, 0x4

    const-string v0, "#"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    filled-new-array {v0, p1}, [Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p0, p1}, Lcom/tencent/android/tpns/mqtt/util/Strings;->equalsAny(Ljava/lang/CharSequence;[Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p0, v0}, Lcom/tencent/android/tpns/mqtt/util/Strings;->countMatches(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)I

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-gt p1, v2, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz p1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string p1, "/#"

    const-string p1, "#/"

    const/4 v5, 0x6

    const-string p1, "/#"

    const-string p1, "/#"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz p1, :cond_2

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpns/mqtt/MqttTopic;->validateSingleLevelWildcard(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-void

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v1, "dsno blltgm steiae  iwrc uv ptviglu-amo nl:iIlandcerdi "

    const-string v1, "atrmdilsloten  t aies  ac-nlei irliwvdumgvn:dp  cIloiug"

    const/4 v5, 0x5

    const-string v1, "  lnpeudeecirigrsto s w ucminv:fvti laa-l tdIidlla noug"

    const-string v1, "Invalid usage of multi-level wildcard in topic string: "

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    throw p1

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string p1, "#+"

    const-string p1, "#+"

    const/4 v5, 0x3

    const-string p1, "#+"

    const-string p1, "#+"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p0, p1}, Lcom/tencent/android/tpns/mqtt/util/Strings;->containsAny(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x7

    if-nez p0, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string p1, "  phMrdpomnalS(T TioccU)o#aTOrncsaiarytndNhe e nce ca+at i w"

    const-string p1, "awcho cnisetpaNMeOm+dSacnhanoid( yT rnU c  aTT rt  olca#)eir"

    const/4 v5, 0x1

    const-string/jumbo p1, "nMtas acqarec drNrOhpleyan )hTd iciaa tctUeSoT+m nc# n oi(w "

    const-string p1, "The topic name MUST NOT contain any wildcard characters (#+)"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    throw p0

    :cond_5
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 p1, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-array p1, p1, [Ljava/lang/Object;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/Integer;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {v0, v2}, Ljava/lang/Integer;-><init>(I)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    aput-object v0, p1, v3

    const/4 v5, 0x7

    new-instance v0, Ljava/lang/Integer;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {v0, v1}, Ljava/lang/Integer;-><init>(I)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    aput-object v0, p1, v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v0, "nbslg,dhdn[,uae%]! n l i  t gdscp adlnhio%eeriIto"

    const-string v0, "Invalid topic length, should be in range[%d, %d]!"

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v0, p1}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    throw p0

    :catch_0
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {p1, p0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    throw p1
.end method

.method private static validateSingleLevelWildcard(Ljava/lang/String;)V
    .locals 11

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-string v0, "+"

    const-string v0, "+"

    const/4 v10, 0x5

    const-string v0, "+"

    const-string v0, "+"

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/4 v1, 0x0

    const/4 v10, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->charAt(I)C

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string v2, "/"

    const-string v2, "/"

    const-string v2, "/"

    const-string v2, "/"

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/String;->charAt(I)C

    move-result v2

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x5

    array-length v4, v3

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    move v5, v1

    move v5, v1

    const/4 v10, 0x2

    move v5, v1

    move v5, v1

    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-ge v5, v4, :cond_5

    add-int/lit8 v6, v5, -0x1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-ltz v6, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    aget-char v6, v3, v6

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    goto :goto_1

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    move v6, v1

    move v6, v1

    :goto_1
    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    add-int/lit8 v7, v5, 0x1

    const/4 v10, 0x6

    if-ge v7, v4, :cond_1

    const/4 v9, 0x3

    shr-int/2addr v10, v9

    aget-char v8, v3, v7

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    goto :goto_2

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    move v8, v1

    move v8, v1

    move v8, v1

    move v8, v1

    :goto_2
    aget-char v5, v3, v5

    const/4 v10, 0x3

    const/4 v9, 0x7

    if-ne v5, v0, :cond_4

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    if-eq v6, v2, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-nez v6, :cond_3

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    if-eq v8, v2, :cond_4

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    if-nez v8, :cond_3

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    goto :goto_3

    :cond_3
    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/4 v2, 0x1

    const/4 v10, 0x2

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v9, 0x3

    and-int/2addr v10, v9

    aput-object p0, v2, v1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x6

    const-string p0, "/fsmeladl/gwI/illuv ip gsreinni ac e  / slnn iadiv!%dcbtegorot"

    const-string p0, "fuvntbi anlaggllwniiedp vcis t/o !idgor / ase/e%ei/crl ssd lnI"

    const/4 v10, 0x6

    const-string/jumbo p0, "uieoolidiwa/n/g/rellcecie/I -ld i  s%soggns nn tvaldftri pv sa"

    const-string p0, "Invalid usage of single-level wildcard in topic string \'%s\'!"

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {p0, v2}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x3

    const/4 v9, 0x2

    invoke-direct {v0, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    throw v0

    :cond_4
    :goto_3
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    move v5, v7

    move v5, v7

    const/4 v10, 0x3

    move v5, v7

    move v5, v7

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    goto/16 :goto_0

    :cond_5
    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    return-void
.end method


# virtual methods
.method public getName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpns/mqtt/MqttTopic;->name:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public publish(Lcom/tencent/android/tpns/mqtt/MqttMessage;)Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;
    .locals 4
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;,
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    const/4 v2, 0x2

    move v3, v2

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/MqttTopic;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->getClient()Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {v1}, Lcom/tencent/android/tpns/mqtt/IMqttAsyncClient;->getClientId()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;->setMessage(Lcom/tencent/android/tpns/mqtt/MqttMessage;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpns/mqtt/MqttTopic;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpns/mqtt/MqttTopic;->createPublish(Lcom/tencent/android/tpns/mqtt/MqttMessage;)Lcom/tencent/android/tpns/mqtt/internal/wire/MqttPublish;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v1, p1, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->sendNoWait(Lcom/tencent/android/tpns/mqtt/internal/wire/MqttWireMessage;Lcom/tencent/android/tpns/mqtt/MqttToken;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object p1, v0, Lcom/tencent/android/tpns/mqtt/MqttToken;->internalTok:Lcom/tencent/android/tpns/mqtt/internal/Token;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpns/mqtt/internal/Token;->waitUntilSent()V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object v0
.end method

.method public publish([BIZ)Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;
    .locals 3
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Lcom/tencent/android/tpns/mqtt/MqttException;,
            Lcom/tencent/android/tpns/mqtt/MqttPersistenceException;
        }
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance v0, Lcom/tencent/android/tpns/mqtt/MqttMessage;

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    invoke-direct {v0, p1}, Lcom/tencent/android/tpns/mqtt/MqttMessage;-><init>([B)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {v0, p2}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setQos(I)V

    const/4 v1, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p3}, Lcom/tencent/android/tpns/mqtt/MqttMessage;->setRetained(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpns/mqtt/MqttTopic;->publish(Lcom/tencent/android/tpns/mqtt/MqttMessage;)Lcom/tencent/android/tpns/mqtt/MqttDeliveryToken;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object p1
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpns/mqtt/MqttTopic;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method
