.class public Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;
.super Ljava/lang/Object;


# static fields
.field public static final DELETE_OLDEST_MESSAGES_DEFAULT:Z = false

.field public static final DISCONNECTED_BUFFER_ENABLED_DEFAULT:Z = false

.field public static final DISCONNECTED_BUFFER_SIZE_DEFAULT:I = 0x1388

.field public static final PERSIST_DISCONNECTED_BUFFER_DEFAULT:Z


# instance fields
.field private bufferEnabled:Z

.field private bufferSize:I

.field private deleteOldestMessages:Z

.field private persistBuffer:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    const/16 v0, 0x1388

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput v0, p0, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->bufferSize:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->bufferEnabled:Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->persistBuffer:Z

    const/4 v1, 0x0

    or-int/2addr v2, v1

    iput-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->deleteOldestMessages:Z

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public getBufferSize()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~s./ @ @l4S@~~ @ ~@boi@dmb@ ~@~ o boo @i~fo  tu-f1@~~v@ yl~ ~c ~@a~@@@ ~~~~~ ot~@r ~@niKM@/~s~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->bufferSize:I

    const/4 v2, 0x1

    return v0
.end method

.method public isBufferEnabled()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->bufferEnabled:Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    return v0
.end method

.method public isDeleteOldestMessages()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->deleteOldestMessages:Z

    const/4 v2, 0x5

    const/4 v1, 0x4

    return v0
.end method

.method public isPersistBuffer()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-boolean v0, p0, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->persistBuffer:Z

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public setBufferEnabled(Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->bufferEnabled:Z

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public setBufferSize(I)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-lt p1, v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput p1, p0, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->bufferSize:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/lang/IllegalArgumentException;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    throw p1
.end method

.method public setDeleteOldestMessages(Z)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->deleteOldestMessages:Z

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public setPersistBuffer(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/DisconnectedBufferOptions;->persistBuffer:Z

    const/4 v1, 0x1

    return-void
.end method
