.class Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectCallback;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpns/mqtt/MqttCallbackExtended;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = "MqttReconnectCallback"
.end annotation


# instance fields
.field final automaticReconnect:Z

.field final synthetic this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;Z)V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectCallback;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-boolean p2, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectCallback;->automaticReconnect:Z

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method public connectComplete(ZLjava/lang/String;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@so ~rf.don~~bt a@ @ s @@v~@  @ @ @-1 ~4 ~@l~om tlf@bi/~~o~~~@~@M@~~~ S~u@@@oy cb~~o  @i~i/K~@@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    return-void
.end method

.method public connectionLost(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-boolean p1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectCallback;->automaticReconnect:Z

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-eqz p1, :cond_0

    const/4 v1, 0x6

    move v2, v1

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectCallback;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object p1, p1, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->comms:Lcom/tencent/android/tpns/mqtt/internal/ClientComms;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1, v0}, Lcom/tencent/android/tpns/mqtt/internal/ClientComms;->setRestingState(Z)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectCallback;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$302(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;Z)Z

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient$MqttReconnectCallback;->this$0:Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;->access$400(Lcom/tencent/android/tpns/mqtt/MqttAsyncClient;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-void
.end method

.method public deliveryComplete(Lcom/tencent/android/tpns/mqtt/IMqttDeliveryToken;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public messageArrived(Ljava/lang/String;Lcom/tencent/android/tpns/mqtt/MqttMessage;)V
    .locals 2
    .annotation system Ldalvik/annotation/Throws;
        value = {
            Ljava/lang/Exception;
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method
