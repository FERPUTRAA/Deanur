.class public Lcom/tencent/android/fcm/Constants;
.super Ljava/lang/Object;


# static fields
.field public static final OTHER_PUSH_TAG:Ljava/lang/String; = "XG_fcm"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method
