.class public Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;
.super Ljava/lang/Object;


# static fields
.field private static final FCM_API_VERSION_22:I = 0x16

.field private static final FCM_API_VERSION_ERROR:I = -0x1

.field private static final FCM_API_VERSION_LOWER_22:I = 0x11

.field private static final SP_FILE:Ljava/lang/String; = "xg.otherpush.xml"

.field public static final TPUSH_FCM_TOKEN:Ljava/lang/String; = "XG_V2_FCM_APP_TOKEN"

.field private static fcmApiVersion:I = 0x0

.field public static fcmToken:Ljava/lang/String; = ""

.field private static isAvailable:I = -0x1


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic access$000(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@sS~@@v~@aK/@~m  b ob~~~@@~@M@ ~~ ~~~s~~ fr o@1~@~4~yib i  l@@~f/co.  @o@~t@@o  o~ln~  i-u@d~t "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->getOtherPushSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic access$100()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->getFCMVersion()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return v0
.end method

.method public static checkDevice(Landroid/content/Context;)Z
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget v0, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->isAvailable:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v1, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    const/4 v2, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-ne v0, v1, :cond_2

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {}, Lcom/google/android/gms/common/f;->x()Lcom/google/android/gms/common/f;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/f;->j(Landroid/content/Context;)I

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_0

    :catchall_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {}, Lcom/google/android/gms/common/g;->i()Lcom/google/android/gms/common/g;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0, p0}, Lcom/google/android/gms/common/g;->j(Landroid/content/Context;)I

    move-result p0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string v1, "co maer  ueseoGPdys  lSgeoCstcrvsilelei=e"

    const-string v1, "acs =re lyc  trliesGlsuePeCse Sgoreiodeov"

    const/4 v5, 0x3

    const-string/jumbo v1, "sgC oco iieeeuclyeGeveP vrroodselr l=s tS"

    const-string v1, " GooglePlayServices service resultCode = "

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v1, "m_mXcb"

    const-string v1, "c_fmmX"

    const/4 v5, 0x5

    const-string/jumbo v1, "ufmc_X"

    const-string v1, "XG_fcm"

    const/4 v4, 0x1

    move v5, v4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz p0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v0, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eq p0, v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    const/16 v0, 0x15

    if-ne p0, v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_1

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo p0, "oPsvt  pioda opslucoG eereoitrslpegS"

    const-string p0, "eSoeoa i gsrPspecitoyleuropsvGl  dot"

    const/4 v5, 0x6

    const-string p0, "eycolts qpeoe toosSe piadvrsgrliPuGn"

    const-string p0, " GooglePlayServices is not supported"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    sput v2, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->isAvailable:I

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_2

    :cond_1
    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string/jumbo p0, "iisid  iTvdcgeesp , srn osssluGnvr ecneve PiSeplcioyigaeeruthor"

    const-string p0, "This device is supported, GooglePlayServices service is running"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    sput v3, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->isAvailable:I

    :cond_2
    :goto_2
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget p0, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->isAvailable:I

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-ne p0, v3, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    move v2, v3

    move v2, v3

    const/4 v5, 0x3

    move v2, v3

    move v2, v3

    :cond_3
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    return v2
.end method

.method private static getFCMVersion()I
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string v0, "XmbmG_"

    const-string v0, "G_fmXb"

    const/4 v5, 0x0

    const-string v0, "XG_fcm"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    sget v1, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmApiVersion:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez v1, :cond_0

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string v1, "fnsgoFg.oeaucablgier.Mg.o.eogiemsiabnrsmgisaeee"

    const-string/jumbo v1, "rlgiMoubiasiggmasgnaagbosrse.smF.eceeienoefge.."

    const/4 v5, 0x5

    const-string v1, ".mcMsblnongioreFesibea..ssaeiggasormegfgebeas.g"

    const-string v1, "com.google.firebase.messaging.FirebaseMessaging"

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v2, "egTnekut"

    const-string v2, "getToken"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v3, 0x0

    new-array v3, v3, [Ljava/lang/Class;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v1, v2, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    const/4 v4, 0x0

    or-int/2addr v5, v4

    const-string v1, "Mvp oigpreen eC tFrvs2 "

    const-string v1, " oeeveop 2Cvnrri  FgMst"

    const/4 v5, 0x4

    const-string v1, "eC  2ooeqvr2 nrgMtFi se"

    const-string v1, "get FCM version over 22"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/16 v1, 0x16

    const/4 v5, 0x6

    const/4 v4, 0x2

    sput v1, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmApiVersion:I
    :try_end_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v4, 0x3

    goto :goto_0

    :catchall_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string v1, "iKsF MiCDSnsgqM"

    const-string v1, " CMgnFisq iMDKS"

    const/4 v5, 0x3

    const-string v1, "CMnmii Mg SsFsD"

    const-string v1, "Missing FCM SDK"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v0, -0x1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    sput v0, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmApiVersion:I

    const/4 v4, 0x1

    move v5, v4

    goto :goto_0

    :catch_0
    const/4 v5, 0x5

    const-string v1, "e rFo tes2vn2Megoloirs w"

    const-string v1, "  selor Creigo2wesnMFtv2"

    const-string/jumbo v1, "oletobsCrviwe g e MFnr 2"

    const-string v1, "get FCM version lower 22"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/16 v0, 0x11

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    sput v0, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmApiVersion:I

    :cond_0
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    sget v0, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmApiVersion:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    return v0
.end method

.method private static getOtherPushSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v0, ".uspxoumg.xmlhrh"

    const-string/jumbo v0, "s.umhlxotmhpgr.x"

    const/4 v3, 0x7

    const-string v0, "hxlo.mspxrtuhgep"

    const-string/jumbo v0, "xg.otherpush.xml"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object p0
.end method

.method public static getPushInfo()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo v0, "mcf"

    const-string v0, "cmf"

    const/4 v2, 0x6

    const-string v0, "fcm"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public static getToken(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    sget-object v1, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmToken:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v1}, Lcom/tencent/android/fcm/Util;->isNullOrEmptyString(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-nez v1, :cond_0

    const/4 v5, 0x2

    sget-object p0, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmToken:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-object p0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->getOtherPushSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v3, "OPGT_FNoq_VCAP2MEKX_"

    const-string v3, ",C2KoAPPVNFG_TMX__EO"

    const/4 v5, 0x5

    const-string v3, "CAs2OPVFMEP__KG,T__X"

    const-string v3, "XG_V2_FCM_APP_TOKEN,"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-interface {v1, v2, v0}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/tencent/android/fcm/Util;->isNullOrEmptyString(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    sput-object v1, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmToken:Ljava/lang/String;

    const/4 v5, 0x5

    invoke-static {v1}, Lcom/tencent/android/fcm/Util;->isNullOrEmptyString(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-nez v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    sget-object p0, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmToken:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x7

    return-object p0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->getFCMVersion()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v2, -0x1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-ne v1, v2, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    sget-object p0, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmToken:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object p0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->getFCMVersion()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/16 v2, 0x16

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-ne v1, v2, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {}, Lcom/google/firebase/messaging/FirebaseMessaging;->i()Lcom/google/firebase/messaging/FirebaseMessaging;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1}, Lcom/google/firebase/messaging/FirebaseMessaging;->l()Lcom/google/android/gms/tasks/Task;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance v2, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl$4;

    const/4 v5, 0x2

    const/4 v4, 0x2

    invoke-direct {v2, p0}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl$4;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_0

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {}, Lcom/google/firebase/iid/FirebaseInstanceId;->getInstance()Lcom/google/firebase/iid/FirebaseInstanceId;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1}, Lcom/google/firebase/iid/FirebaseInstanceId;->getInstanceId()Lcom/google/android/gms/tasks/Task;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v2, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl$5;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {v2, p0}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl$5;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object p0, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmToken:Ljava/lang/String;
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-object p0

    :catch_0
    :catchall_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    return-object v0
.end method

.method public static registerPush(Landroid/content/Context;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->getFCMVersion()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v1, -0x1

    or-int/2addr v3, v1

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->getFCMVersion()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/16 v1, 0x16

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-ne v0, v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {}, Lcom/google/firebase/messaging/FirebaseMessaging;->i()Lcom/google/firebase/messaging/FirebaseMessaging;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/google/firebase/messaging/FirebaseMessaging;->l()Lcom/google/android/gms/tasks/Task;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    new-instance v1, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl$1;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl$1;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {}, Lcom/google/firebase/iid/FirebaseInstanceId;->getInstance()Lcom/google/firebase/iid/FirebaseInstanceId;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/google/firebase/iid/FirebaseInstanceId;->getInstanceId()Lcom/google/android/gms/tasks/Task;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v1, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl$2;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl$2;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/google/android/gms/tasks/Task;->addOnCompleteListener(Lcom/google/android/gms/tasks/OnCompleteListener;)Lcom/google/android/gms/tasks/Task;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo v1, "irom Rer!FerM segbrt"

    const-string/jumbo v1, "rrrr bs!eCgoitRMeFe "

    const/4 v3, 0x5

    const-string v1, "FCM Register error! "

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v0, "cmX_ou"

    const-string/jumbo v0, "umcXG_"

    const/4 v3, 0x5

    const-string v0, "cGmf_b"

    const-string v0, "XG_fcm"

    const/4 v3, 0x3

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    sput-object p0, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmToken:Ljava/lang/String;

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method public static setToken(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x1

    sput-object p1, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmToken:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x0

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x6

    const/4 v2, 0x1

    sput-object p1, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmToken:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->getOtherPushSharedPreferences(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const-string v1, "K_TCE2u_N,PP_pXGVFMO"

    const-string v1, "_OA__PXpEKTFMNPC,V2G"

    const-string v1, "M2_T__PpF_POECAVXNGK"

    const-string v1, "XG_V2_FCM_APP_TOKEN,"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->fcmToken:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {p1, p0, v0}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    :cond_1
    const/4 v3, 0x3

    return-void
.end method

.method public static unregisterPush(Landroid/content/Context;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->getFCMVersion()I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, -0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ne p0, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/Thread;

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl$3;

    const/4 v3, 0x2

    invoke-direct {v0}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl$3;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/Thread;->start()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string v1, "Fr!r ugrqsre n eroMqet"

    const-string v1, " rrretF qroungi!Me res"

    const/4 v3, 0x1

    const-string v1, "! seFnrgesMio t rreurr"

    const-string v1, "FCM unregister error! "

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    move v3, v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const-string v0, "fmXmGc"

    const-string v0, "XG_fcm"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    return-void
.end method
