.class Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->unregisterPush(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    shl-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~@s~y t~ ~b~l ~@ooc ~t@~@b /M @@@~ r@o@.@b ~@~4 mo~snl/ @d a i ~@~i@fS@f~Kv1@u~~~~o  @ @~i@@o -~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    const-string/jumbo v0, "sfmmGX"

    const-string v0, "XGsm_f"

    const/4 v5, 0x0

    const-string v0, "XcfGom"

    const-string v0, "XG_fcm"

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {}, Lcom/google/firebase/g;->p()Lcom/google/firebase/g;

    move-result-object v1
    :try_end_0
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v2, "eg!m bsPCisrnFhu tMreiafl"

    const-string/jumbo v2, "saum!gtei PurMflrinFC esh"

    const/4 v5, 0x3

    const-string v2, "fPnaleuu uCir!rtMse si hF"

    const-string v2, "FCM unregisterPush fail !"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v1, :cond_2

    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {}, Lcom/google/firebase/g;->p()Lcom/google/firebase/g;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/google/firebase/g;->s()Lcom/google/firebase/s;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/otherpush/fcm/impl/OtherPushImpl;->access$100()I

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/16 v2, 0x16

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-ne v1, v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {}, Lcom/google/firebase/messaging/FirebaseMessaging;->i()Lcom/google/firebase/messaging/FirebaseMessaging;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/google/firebase/messaging/FirebaseMessaging;->e()Lcom/google/android/gms/tasks/Task;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {}, Lcom/google/firebase/iid/FirebaseInstanceId;->getInstance()Lcom/google/firebase/iid/FirebaseInstanceId;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {}, Lcom/google/firebase/g;->p()Lcom/google/firebase/g;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2}, Lcom/google/firebase/g;->s()Lcom/google/firebase/s;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/google/firebase/s;->m()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v3, "MFC"

    const-string v3, "FMC"

    const/4 v5, 0x6

    const-string v3, "CMF"

    const-string v3, "FCM"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1, v2, v3}, Lcom/google/firebase/iid/FirebaseInstanceId;->deleteToken(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v1, "oMctscPpieFhur es nuesCusr!g"

    const-string/jumbo v1, "shCFoc eu tnre euPruMcsgss!i"

    const/4 v5, 0x7

    const-string/jumbo v1, "urMFPsheqt usns!Cci euesc sg"

    const-string v1, "FCM unregisterPush success !"

    const/4 v5, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    xor-int/2addr v5, v4

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    move v5, v4

    goto :goto_0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/IllegalStateException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string v3, "eesdreIs!Cberctdlno  at IMre"

    const-string/jumbo v3, "rneIdb cd!Meeolt aetIesnrr C"

    const/4 v5, 0x3

    const-string/jumbo v3, "srdm etadee!IItcrC F nMrlnee"

    const-string v3, "FCM deleteInstanceId error! "

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :catch_0
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    return-void
.end method
