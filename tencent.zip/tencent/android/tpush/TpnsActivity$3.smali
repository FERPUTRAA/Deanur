.class Lcom/tencent/android/tpush/TpnsActivity$3;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/TpnsActivity;->c(Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/net/Uri;

.field final synthetic b:Lcom/tencent/android/tpush/TpnsActivity;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/TpnsActivity;Landroid/net/Uri;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/TpnsActivity$3;->b:Lcom/tencent/android/tpush/TpnsActivity;

    const/4 v0, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/tencent/android/tpush/TpnsActivity$3;->a:Landroid/net/Uri;

    const/4 v0, 0x4

    shr-int/2addr v1, v0

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s~m   o~~~~@sK~~~ ~r@@ l@@i @-@1~@~oo@~n@ ~b~@ o i~ibS4  @d@yto~~ @ ~@lb@/@M /v fc~ ~.f~@@oatu"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/TpnsActivity$3;->b:Lcom/tencent/android/tpush/TpnsActivity;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-lez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string v0, "iTsmtctvnsyA"

    const-string/jumbo v0, "visytnTsAtcp"

    const/4 v3, 0x6

    const-string/jumbo v0, "ticyoTviAtns"

    const-string v0, "TpnsActivity"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string v1, "apGdibCritlea eeahnfi nLlnlhbmnoDkeeil"

    const-string v1, "CihmeaGrtLlnkfoenb eeD nlaedianihltlpi"

    const/4 v3, 0x3

    const-string v1, "Goeleruttiieeniahilnn aaLllbn fkpehdCD"

    const-string/jumbo v1, "otherChannelDeepLink initGlobal failed"

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/TpnsActivity$3;->b:Lcom/tencent/android/tpush/TpnsActivity;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/TpnsActivity$3;->a:Landroid/net/Uri;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/TpnsActivity;->a(Lcom/tencent/android/tpush/TpnsActivity;Landroid/net/Uri;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method
