.class Lcom/tencent/android/tpush/XGPushBaseReceiver$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushBaseReceiver;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Landroid/content/Intent;

.field final synthetic c:Lcom/tencent/android/tpush/XGPushBaseReceiver;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGPushBaseReceiver;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->c:Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const/4 v1, 0x4

    const/4 v0, 0x6

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->a:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v0, 0x2

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->b:Landroid/content/Intent;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~ slur@~~@~fb~/@an ~o~ tt ~o@-~bov@  m@Ko  ~@@@c~4@  /~.  @~@@o M i @1fsi@@i ~b@~~~@~l~@ @d~~~oS"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    const-string v0, "ceumrPeRsXseBvGsha"

    const-string/jumbo v0, "iesBGehecuXrsPvRas"

    const/4 v6, 0x1

    const-string v0, "eePGohecrsseuBaRvi"

    const-string v0, "XGPushBaseReceiver"

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->a:Landroid/content/Context;

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    if-lez v1, :cond_0

    const/4 v5, 0x6

    or-int/2addr v6, v5

    return-void

    :cond_0
    const/4 v5, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->b:Landroid/content/Intent;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v2, ".om..bMo.ictnUESvcSEinaHgtexSoc..GtmpedAnrP_ia"

    const-string/jumbo v2, "x.pmdevH.mE.StnnicS_EM.AoaUc.arGcoedPitgi.nSot"

    const/4 v6, 0x1

    const-string/jumbo v2, "vonipSuoenim._dMioPaSacH.ttU.drcen..tEAncxG.gS"

    const-string v2, "com.tencent.android.xg.vip.action.PUSH_MESSAGE"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v2, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->b:Landroid/content/Intent;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string/jumbo v2, "peyt"

    const-string v2, "etpy"

    const/4 v6, 0x7

    const-string/jumbo v2, "ypte"

    const-string/jumbo v2, "type"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v6, 0x7

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v5, 0x6

    shr-int/2addr v6, v5

    invoke-virtual {v1, v2, v3, v4}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-wide/16 v3, 0x7

    const-wide/16 v3, 0x7

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    cmp-long v1, v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-nez v1, :cond_1

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->c:Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->a:Landroid/content/Context;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->b:Landroid/content/Intent;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->a(Lcom/tencent/android/tpush/XGPushBaseReceiver;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->c:Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->a:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->b:Landroid/content/Intent;

    const/4 v6, 0x2

    const/4 v5, 0x1

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->b(Lcom/tencent/android/tpush/XGPushBaseReceiver;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string/jumbo v2, "nEnxc.KpDBtEeAteraoaomvcnniico..gdd.iCt.op"

    const-string v2, "E.EioAit..caDamn.coCnioptgev.dK.cdBenxnort"

    const/4 v6, 0x1

    const-string v2, "c.Coo.aiqKE.n.tttio.pmrDvnFaceBicedxdAEg.n"

    const-string v2, "com.tencent.android.xg.vip.action.FEEDBACK"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v6, 0x5

    const/4 v5, 0x0

    if-eqz v2, :cond_3

    :try_start_1
    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->c:Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->a:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;->b:Landroid/content/Intent;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->c(Lcom/tencent/android/tpush/XGPushBaseReceiver;Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_0

    :catchall_0
    move-exception v1

    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v2, "kfsdaHnrreordle ebare"

    const-string v2, "eHoeab kdebfrrerdrlan"

    const/4 v6, 0x6

    const-string v2, "doem rraekadHebrflcne"

    const-string v2, "feedbackHandler error"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto :goto_0

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v3, "/2/7oeiu6tn8a7u5ua47/:6cu"

    const-string/jumbo v3, "u75n77u6/o6ec/2a/iuuta:84"

    const-string/jumbo v3, "t7oceb4/5:6u/727unia/a6u7"

    const-string/jumbo v3, "\u672a\u77e5\u7684action:"

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto :goto_0

    :catchall_1
    move-exception v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string/jumbo v2, "onReceive handle error."

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    return-void
.end method
