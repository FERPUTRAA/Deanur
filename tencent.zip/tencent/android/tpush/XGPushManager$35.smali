.class Lcom/tencent/android/tpush/XGPushManager$35;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/XGIOperateCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->unregisterPush(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onFail(Ljava/lang/Object;ILjava/lang/String;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ s ~ @-iu4o@ rf@M m@~~@~@@ty~~iibs.oa~ll ~ ~~o@ @/1 b @~dc~~vo~@@@@ @@bn@ @K@~ ~@Sfo/~~t~~ ~ o "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo v1, "osrmdPh=siietU neetsspihuaf ekhwnut  l R"

    const-string/jumbo v1, "k swt seniulRsitupeedh=ir oeastnU fhhP  "

    const/4 v3, 0x0

    const-string/jumbo v1, "nrkpoeiRehfttu=aPiuindlgho swsst  eU h  "

    const-string v1, "UnRegisterPush push failed with token = "

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string p1, "emd, berCo= r"

    const-string/jumbo p1, "orem  r=Ced ,"

    const/4 v3, 0x7

    const-string/jumbo p1, "re d,eu rC o="

    const-string p1, " , errCode = "

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string p1, "  sm, =po"

    const-string p1, "   so=m,g"

    const/4 v3, 0x4

    const-string p1, "    ,=mgq"

    const-string p1, " , msg = "

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string p2, "XGsnauPrMhbgs"

    const-string p2, "GXgenbuPrhasM"

    const/4 v3, 0x3

    const-string p2, "XGPushManager"

    const/4 v2, 0x3

    and-int/2addr v3, v2

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public onSuccess(Ljava/lang/Object;I)V
    .locals 4

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v1, "necmhsied uUecutowsep n  Ps kug=R rehtthu"

    const-string/jumbo v1, "iew h uPu hnc r skieedn=tuhcoegpsesRu Utt"

    const/4 v3, 0x6

    const-string/jumbo v1, "t w=ocPU gs kueteuihoede hnphRri  ssectsu"

    const-string v1, "UnRegisterPush push succeed with token = "

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string p1, "fpg lb= "

    const-string p1, "=lf ga p"

    const-string p1, " =g afu "

    const-string p1, " flag = "

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo p2, "uXasqrepPMhnG"

    const-string p2, "arhGnuseqXaPM"

    const/4 v3, 0x3

    const-string/jumbo p2, "nargPXuaqMGsh"

    const-string p2, "XGPushManager"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method
