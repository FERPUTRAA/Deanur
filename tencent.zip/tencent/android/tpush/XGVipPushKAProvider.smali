.class public Lcom/tencent/android/tpush/XGVipPushKAProvider;
.super Landroid/content/ContentProvider;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method private a(Landroid/net/Uri;Landroid/content/Context;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~so@@lS~ @v@n@@@df1~@@~ K~o4uo  o@oa@@i~.~ s iit~@ ~~~  ~- ~@mb~ b/M  y~r~ct b ~~~ l~@ /@~@o@@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x4

    const-string/jumbo v0, "sKhmPopVuirXPsivAre"

    const-string/jumbo v0, "oisrPPAXdiVpsruehvK"

    const/4 v3, 0x0

    const-string/jumbo v0, "upriohvKVPGorPseXid"

    const-string v0, "XGVipPushKAProvider"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz p2, :cond_1

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p2}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedTpnsChannel(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo p1, "nv cmbrTvrsa eepsnrcS rl osi,psan iuoac lsehherpenteie eab"

    const-string/jumbo p1, "n pmneeepstaraT verSlsh ruib t nhcosnvilc caae,ieep sorers"

    const/4 v3, 0x4

    const-string/jumbo p1, "p iebiuceot rarete encc ,eonhppssr avS hTravltlssneiurn es"

    const-string/jumbo p1, "prepare startService abolish, not use Tpns channel service"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v1, "revto crSeptrpaseare"

    const/4 v3, 0x6

    const-string/jumbo v1, "rcatea pirsprerepStv"

    const-string/jumbo v1, "prepare startService"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v1, Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-class p1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class p1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v3, 0x5

    const-class p1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class p1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v2, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v1, p2, p1}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p2, v1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string p2, "fdersaiiq eebrlstca ."

    const-string/jumbo p2, "v  rrbsiasti.eacedelf"

    const/4 v3, 0x3

    const-string/jumbo p2, "resas.ed ilfvt asiter"

    const-string/jumbo p2, "start service failed."

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0, p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    .locals 2
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/XGVipPushKAProvider;->a(Landroid/net/Uri;Landroid/content/Context;)V

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x7

    return p1
.end method

.method public getType(Landroid/net/Uri;)Ljava/lang/String;
    .locals 3
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {p0, p1, v0}, Lcom/tencent/android/tpush/XGVipPushKAProvider;->a(Landroid/net/Uri;Landroid/content/Context;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p1
.end method

.method public insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    .locals 2
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/ContentValues;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/XGVipPushKAProvider;->a(Landroid/net/Uri;Landroid/content/Context;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p1
.end method

.method public onCreate()Z
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v2, "ee m:nsoce C txtienrsottervturac"

    const-string v2, "eoersoueccCteatrx e  is ntrtntv:"

    const/4 v5, 0x6

    const-string/jumbo v2, "tarCococavneisetesttent:rex  o  "

    const-string/jumbo v2, "onCreate start service context: "

    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v3, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    move v3, v2

    move v3, v2

    const/4 v5, 0x2

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v3, "PhiVXbPdrpiGoprAvue"

    const-string/jumbo v3, "shiipAGpoPPvrrduVeX"

    const/4 v5, 0x4

    const-string v3, "PouAirurhGsdKVpiPvX"

    const-string v3, "XGVipPushKAProvider"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/service/b;->a(Landroid/content/Context;)V

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    return v2
.end method

.method public query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    .locals 2
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p5    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/q0;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v1, 0x5

    const/4 v0, 0x6

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/XGVipPushKAProvider;->a(Landroid/net/Uri;Landroid/content/Context;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p1
.end method

.method public update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    .locals 2
    .param p1    # Landroid/net/Uri;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Landroid/content/ContentValues;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p3    # Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param
    .param p4    # [Ljava/lang/String;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object p2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/XGVipPushKAProvider;->a(Landroid/net/Uri;Landroid/content/Context;)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    const/4 p1, 0x0

    const/4 v1, 0x2

    return p1
.end method
