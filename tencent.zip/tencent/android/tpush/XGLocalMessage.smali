.class public Lcom/tencent/android/tpush/XGLocalMessage;
.super Ljava/lang/Object;


# instance fields
.field private A:J

.field private B:I

.field private C:Ljava/lang/String;

.field private D:I

.field private E:Ljava/lang/String;

.field private F:Ljava/lang/String;

.field private G:Ljava/lang/String;

.field private H:I

.field private I:Ljava/lang/String;

.field private J:I

.field private a:I

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:I

.field private h:I

.field private i:I

.field private j:I

.field private k:I

.field private l:Ljava/lang/String;

.field private m:Ljava/lang/String;

.field private n:Ljava/lang/String;

.field public nGroupId:Ljava/lang/String;

.field private o:I

.field private p:Ljava/lang/String;

.field public pushChannel:I

.field public pushTime:J

.field private q:Ljava/lang/String;

.field private r:Ljava/lang/String;

.field private s:Ljava/lang/String;

.field public source:J

.field private t:Ljava/lang/String;

.field public targetType:J

.field public templateId:Ljava/lang/String;

.field public traceId:Ljava/lang/String;

.field private u:Ljava/lang/String;

.field private v:J

.field private w:I

.field private x:J

.field private y:J

.field private z:I


# direct methods
.method public constructor <init>()V
    .locals 11

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v10, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->pushTime:J

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/16 v2, 0x63

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    iput v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->pushChannel:I

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-string v2, ""

    const-string v2, ""

    const/4 v10, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->nGroupId:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x4

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->targetType:J

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->source:J

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->templateId:Ljava/lang/String;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->traceId:Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x7

    const/4 v3, 0x1

    const/4 v9, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    iput v3, p0, Lcom/tencent/android/tpush/XGLocalMessage;->a:I

    const/4 v10, 0x7

    const/4 v9, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->b:Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->c:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->d:Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    const-string v4, "00"

    const-string v4, "00"

    const-string v4, "00"

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x6

    iput-object v4, p0, Lcom/tencent/android/tpush/XGLocalMessage;->e:Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    iput-object v4, p0, Lcom/tencent/android/tpush/XGLocalMessage;->f:Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v9, 0x1

    iput v3, p0, Lcom/tencent/android/tpush/XGLocalMessage;->g:I

    const/4 v10, 0x0

    const/4 v9, 0x1

    iput v3, p0, Lcom/tencent/android/tpush/XGLocalMessage;->h:I

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    iput v3, p0, Lcom/tencent/android/tpush/XGLocalMessage;->i:I

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/4 v4, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    iput v4, p0, Lcom/tencent/android/tpush/XGLocalMessage;->j:I

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    iput v3, p0, Lcom/tencent/android/tpush/XGLocalMessage;->k:I

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->l:Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->m:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->n:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    iput v3, p0, Lcom/tencent/android/tpush/XGLocalMessage;->o:I

    const/4 v9, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->p:Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->q:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->r:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->s:Ljava/lang/String;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->t:Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-string/jumbo v3, "{}"

    const-string/jumbo v3, "}{"

    const/4 v10, 0x7

    const-string/jumbo v3, "}{"

    const-string/jumbo v3, "{}"

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    iput-object v3, p0, Lcom/tencent/android/tpush/XGLocalMessage;->u:Ljava/lang/String;

    const/4 v10, 0x5

    iput v4, p0, Lcom/tencent/android/tpush/XGLocalMessage;->w:I

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    const-wide/16 v7, -0x1

    const-wide/16 v7, -0x1

    const/4 v10, 0x0

    const-wide/16 v7, -0x1

    const-wide/16 v7, -0x1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    mul-long/2addr v5, v7

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    iput-wide v5, p0, Lcom/tencent/android/tpush/XGLocalMessage;->x:J

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->y:J

    const/4 v10, 0x2

    const v0, 0x278d00

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    iput v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->z:I

    const/4 v9, 0x2

    move v10, v9

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget v3, p0, Lcom/tencent/android/tpush/XGLocalMessage;->z:I

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    int-to-long v5, v3

    const/4 v10, 0x4

    const-wide/16 v7, 0x3e8

    const-wide/16 v7, 0x3e8

    const/4 v10, 0x5

    const-wide/16 v7, 0x3e8

    const-wide/16 v7, 0x3e8

    const/4 v9, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    mul-long/2addr v5, v7

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    add-long/2addr v0, v5

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->A:J

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    iput v4, p0, Lcom/tencent/android/tpush/XGLocalMessage;->B:I

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->C:Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/4 v0, 0x2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    iput v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->D:I

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->E:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->F:Ljava/lang/String;

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->G:Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/4 v0, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    iput v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->H:I

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/XGLocalMessage;->I:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    iput v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->J:I

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    return-void
.end method


# virtual methods
.method public getAction_type()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~/smli@ o@@b~@o bo~b @t@~~~@o~/@i~~S1 ff ~~@@-u@ as ~@l~~ ~~   i cr@4 .@~@@~~  @dv@~ o@@ KtM~oyn"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->o:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return v0
.end method

.method public getActivity()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->p:Ljava/lang/String;

    const/4 v1, 0x5

    move v2, v1

    return-object v0
.end method

.method public getBadgeType()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->H:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    return v0
.end method

.method public getBuilderId()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->v:J

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-wide v0
.end method

.method public getBusiMsgId()J
    .locals 4

    const/4 v2, 0x6

    move v3, v2

    iget-wide v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->y:J

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-wide v0
.end method

.method public getChannelId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->C:Ljava/lang/String;

    return-object v0
.end method

.method public getColor()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->B:I

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method public getContent()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->c:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public getCustom_content()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->u:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public getDate()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string v0, "aeomDaMltteXgsLases(G)ce"

    const-string v0, "atstXLMaecessgaeeglD)G(o"

    const-string v0, "gX.aoe)(sMoeaetLtDaGcesl"

    const-string v0, "XGLocalMessage.getDate()"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const-string v1, "eaMLsbXclaemso"

    const-string v1, "aosmsecMleXaGL"

    const/4 v7, 0x4

    const-string v1, "GsXMLcugasloea"

    const-string v1, "XGLocalMessage"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const-string v2, "Myyyodyp"

    const-string/jumbo v2, "yyyyoMdM"

    const/4 v7, 0x3

    const-string/jumbo v2, "yyyyMMdd"

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpush/XGLocalMessage;->d:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v3}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-nez v3, :cond_0

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/XGLocalMessage;->d:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    const/16 v4, 0x8

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x0

    move v7, v5

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v3, v5, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    iput-object v3, p0, Lcom/tencent/android/tpush/XGLocalMessage;->d:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {v3}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance v3, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x0

    const/4 v6, 0x6

    invoke-direct {v3, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v3, v5}, Ljava/text/DateFormat;->setLenient(Z)V

    const/4 v6, 0x4

    and-int/2addr v7, v6

    iget-object v4, p0, Lcom/tencent/android/tpush/XGLocalMessage;->d:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v3, v4}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;
    :try_end_0
    .catch Ljava/text/ParseException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x0

    goto :goto_0

    :catchall_0
    move-exception v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-direct {v0, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v1, Ljava/util/Date;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-object v0

    :catch_0
    move-exception v3

    const/4 v7, 0x6

    const/4 v6, 0x2

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-instance v0, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct {v0, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-instance v1, Ljava/util/Date;

    const/4 v6, 0x4

    move v7, v6

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    return-object v0

    :cond_0
    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->d:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v7, 0x0

    return-object v0
.end method

.method public getExpirationTimeMs()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->A:J

    const/4 v3, 0x1

    const/4 v2, 0x1

    return-wide v0
.end method

.method public getHour()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->e:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-ge v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v0, "00"

    const-string v0, "00"

    const/4 v3, 0x0

    const-string v0, "00"

    const-string v0, "00"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->e:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-lez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->e:Ljava/lang/String;

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x7

    if-ge v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, "0"

    const-string v1, "0"

    const/4 v3, 0x1

    const-string v1, "0"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->e:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0

    :cond_1
    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->e:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object v0
.end method

.method public getIcon_res()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->m:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    return-object v0
.end method

.method public getIcon_type()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->j:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public getIntent()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->r:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public getLights()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->i:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    return v0
.end method

.method public getMin()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->f:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-ge v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v0, "00"

    const-string v0, "00"

    const-string v0, "00"

    const-string v0, "00"

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->f:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-lez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->f:Ljava/lang/String;

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v3, 0x1

    if-ge v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v1, "0"

    const-string v1, "0"

    const/4 v3, 0x3

    const-string v1, "0"

    const-string v1, "0"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->f:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->f:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object v0
.end method

.method public getMsgId()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->x:J

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-wide v0
.end method

.method public getNotificationCategory()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->I:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->I:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x5

    const/4 v1, 0x4

    return-object v0
.end method

.method public getNotificationId()I
    .locals 3

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->w:I

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    return v0
.end method

.method public getNotificationImportance()I
    .locals 4

    const/4 v3, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->J:I

    const/4 v3, 0x7

    if-ltz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x5

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-gt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public getNsModel()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->D:I

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method public getPackageDownloadUrl()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->s:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object v0
.end method

.method public getPackageName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->t:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0
.end method

.method public getRing()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->g:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method public getRing_raw()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->l:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method

.method public getSmall_icon()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->n:Ljava/lang/String;

    const/4 v2, 0x6

    return-object v0
.end method

.method public getStyle_id()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->k:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public getThreadId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->F:Ljava/lang/String;

    const/4 v2, 0x0

    return-object v0
.end method

.method public getThreadSumText()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->G:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->b:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    return-object v0
.end method

.method public getTpns_media_resources()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->E:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public getTtl()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->z:I

    const/4 v2, 0x0

    return v0
.end method

.method public getType()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->a:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public getUrl()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->q:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method

.method public getVibrate()I
    .locals 3

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->h:I

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return v0
.end method

.method public setAction_type(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->o:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public setActivity(Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x5

    move v1, v0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->p:Ljava/lang/String;

    const/4 v0, 0x6

    and-int/2addr v1, v0

    return-void
.end method

.method public setBadgeType(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->H:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public setBuilderId(J)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-wide p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->v:J

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-void
.end method

.method public setBusiMsgId(J)V
    .locals 2

    const/4 v1, 0x7

    iput-wide p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->y:J

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public setChannelId(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->C:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public setColor(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->B:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public setContent(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->c:Ljava/lang/String;

    const/4 v1, 0x0

    return-void
.end method

.method public setCustomContent(Ljava/util/HashMap;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Ljava/lang/Object;",
            ">;)V"
        }
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance v0, Lorg/json/JSONObject;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/util/Map;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->u:Ljava/lang/String;

    const/4 v2, 0x7

    return-void
.end method

.method public setDate(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->d:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method public setExpirationTimeMs(J)V
    .locals 6

    const/4 v5, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    cmp-long v0, p1, v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-lez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    sub-long v0, p1, v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const/4 v5, 0x4

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    div-long/2addr v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    long-to-int v0, v0

    const/4 v5, 0x2

    iput v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->z:I

    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-gez v0, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    const v0, 0x7fffffff

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput v0, p0, Lcom/tencent/android/tpush/XGLocalMessage;->z:I

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput-wide p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->A:J

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method

.method public setHour(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->e:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public setIcon_res(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->m:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public setIcon_type(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    iput p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->j:I

    const/4 v1, 0x3

    const/4 v0, 0x3

    return-void
.end method

.method public setIntent(Ljava/lang/String;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string v0, "TbFq-"

    const-string v0, "bT-F8"

    const/4 v2, 0x2

    const-string v0, "U-s8F"

    const-string v0, "UTF-8"

    const/4 v2, 0x5

    invoke-static {p1, v0}, Ljava/net/URLEncoder;->encode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_0

    :catch_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v2, 0x3

    const-string p1, ""

    const-string p1, ""

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->r:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public setLights(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->i:I

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public setMin(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->f:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public setMsgId(J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->x:J

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public setNotificationCategory(Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->I:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    return p1
.end method

.method public setNotificationId(I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    iput p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->w:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public setNotificationImportance(I)Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-lez p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    const/4 v0, 0x5

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-le p1, v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->J:I

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const/4 p1, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    return p1

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v1, "inimpoitiamfedtt  rinotlo ifn,cucoaeaniimnrapiIocncva ntt"

    const-string/jumbo v1, "itfianurrieaanltopotcmnnfopiimodivn ncct n atoceaIoi ,tii"

    const/4 v3, 0x6

    const-string/jumbo v1, "nidio fto:t nomc ntcnio irtiIlevrintpaaonitapniioaaocc,fe"

    const-string/jumbo v1, "invalid notification importance , notificationImportance:"

    const/4 v2, 0x5

    shl-int/2addr v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v0, "asseGbeMcaXpgL"

    const-string v0, "aMLaeeopscsGgX"

    const/4 v3, 0x5

    const-string/jumbo v0, "oGaeMsuLXegcsl"

    const-string v0, "XGLocalMessage"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    return p1
.end method

.method public setNsModel(I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->D:I

    const/4 v0, 0x1

    xor-int/2addr v1, v0

    return-void
.end method

.method public setPackageDownloadUrl(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->s:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public setPackageName(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->t:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public setRing(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->g:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public setRing_raw(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->l:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public setSmall_icon(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->n:Ljava/lang/String;

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method

.method public setStyle_id(I)V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->k:I

    const/4 v1, 0x5

    const/4 v0, 0x6

    return-void
.end method

.method public setThreadId(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->F:Ljava/lang/String;

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method public setThreadSumText(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->G:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public setTitle(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->b:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public setTpns_media_resources(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->E:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public setType(I)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->a:I

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public setUrl(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->q:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public setVibrate(I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput p1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->h:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v1, "X=s pstpogya[alGMcLeq"

    const-string v1, "LeolsXc q[eMaatsp=ygG"

    const/4 v4, 0x7

    const-string v1, "c[sesyeeqGMgtaXo=plLa"

    const-string v1, "XGLocalMessage [type="

    const/4 v3, 0x0

    or-int/2addr v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->a:I

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v1, "esstitl "

    const-string/jumbo v1, "tls =tei"

    const/4 v4, 0x5

    const-string v1, "=timt,el"

    const-string v1, ", title="

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->b:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string v1, ",= monnoet"

    const-string v1, ", tmnnoec="

    const/4 v4, 0x1

    const-string v1, ",nce btton"

    const-string v1, ", content="

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->c:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v1, "to=ea u"

    const-string v1, "dt= oae"

    const/4 v4, 0x6

    const-string/jumbo v1, "p,ea= d"

    const-string v1, ", date="

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    move v4, v3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->d:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    const-string/jumbo v1, "rq,ub=h"

    const-string v1, "hro=,bu"

    const/4 v4, 0x1

    const-string/jumbo v1, "r,sh o="

    const-string v1, ", hour="

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->e:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const-string v1, ",=nmum"

    const-string/jumbo v1, "u m=,n"

    const/4 v4, 0x5

    const-string v1, " =inom"

    const-string v1, ", min="

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->f:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v1, "p, edb=Irild"

    const-string/jumbo v1, "ld ,idepruI="

    const-string/jumbo v1, "ilued,ubI=dr"

    const-string v1, ", builderId="

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    iget-wide v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->v:J

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const-string v1, "=m,si qp"

    const-string/jumbo v1, "q,i=m sg"

    const/4 v4, 0x0

    const-string/jumbo v1, "q,gs=d m"

    const-string v1, ", msgid="

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-wide v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->x:J

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v1, "sesdtlpaI te="

    const-string v1, "atsdetelI p,="

    const/4 v4, 0x6

    const-string v1, "=emmatdI, etl"

    const-string v1, ", templateId="

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->templateId:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v1, "rctIo ma,d"

    const-string v1, "d rm,Ieatc"

    const/4 v4, 0x7

    const-string v1, "=t aIb,dcr"

    const-string v1, ", traceId="

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->traceId:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string v1, " idussugMb=o"

    const-string v1, " =gbouss,iMd"

    const/4 v4, 0x4

    const-string v1, "b sIdMipus=,"

    const-string v1, ", busiMsgId="

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/XGLocalMessage;->y:J

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v1, "]"

    const/4 v4, 0x7

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-object v0
.end method
