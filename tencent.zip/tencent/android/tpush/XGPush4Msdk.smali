.class public Lcom/tencent/android/tpush/XGPush4Msdk;
.super Ljava/lang/Object;


# static fields
.field private static a:J = 0x0L

.field private static b:J = 0x0L

.field private static c:Ljava/lang/String; = ""


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic a()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ so m@@yrS-ac~@~b@~ to@@~f~o~vK~@b  ~1 @so@  @@~~Mf@ldi4~@~ ti  ~ @~lb@ ~@/u@~ @@o~~~ .~ no i~/"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-wide v0, Lcom/tencent/android/tpush/XGPush4Msdk;->b:J

    const/4 v3, 0x4

    return-wide v0
.end method

.method static synthetic a(J)J
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    sput-wide p0, Lcom/tencent/android/tpush/XGPush4Msdk;->a:J

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-wide p0
.end method

.method static synthetic a(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPush4Msdk;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method static synthetic a(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    sput-object p0, Lcom/tencent/android/tpush/XGPush4Msdk;->c:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic a(JJJ)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    invoke-static/range {p0 .. p5}, Lcom/tencent/android/tpush/XGPush4Msdk;->b(JJJ)Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return p0
.end method

.method public static addLocalNotification(Landroid/content/Context;Lcom/tencent/android/tpush/XGLocalMessage;)J
    .locals 5

    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    sget-boolean v0, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string/jumbo v1, "saomccdt:odinoil=gmaatNsi"

    const-string/jumbo v1, "mcsisnacdNli=aiL:otdgatoo"

    const/4 v4, 0x7

    const-string/jumbo v1, "ilasodaonfd=NtoitLga:iccm"

    const-string v1, "addLocalNotification:msg="

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/XGLocalMessage;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v1, "pAqm,bd=p"

    const-string/jumbo v1, "ipAm,p=dq"

    const/4 v4, 0x7

    const-string v1, "Adp=,iupq"

    const-string v1, ",qqAppid="

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    sget-wide v1, Lcom/tencent/android/tpush/XGPush4Msdk;->a:J

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    move v4, v3

    const-string v1, "geas=icp_,osc"

    const-string v1, "cdeaoc_=sig,s"

    const/4 v4, 0x6

    const-string v1, "icse_agsqc=,x"

    const-string v1, ",xg_accessid="

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string v1, "GdshMssPbXu"

    const-string v1, "MudGsbXhP4s"

    const/4 v4, 0x1

    const-string/jumbo v1, "uGsmsPXhk4M"

    const-string v1, "XGPush4Msdk"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {p0, p1, v0, v1}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Lcom/tencent/android/tpush/XGLocalMessage;J)J

    move-result-wide p0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-wide p0
.end method

.method public static addTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance v1, Lcom/tencent/android/tpush/XGPush4Msdk$11;

    const/4 v3, 0x6

    invoke-direct {v1, p1, p0, p2}, Lcom/tencent/android/tpush/XGPush4Msdk$11;-><init>(Ljava/lang/String;Landroid/content/Context;Ljava/util/Set;)V

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method static synthetic b(J)J
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    sput-wide p0, Lcom/tencent/android/tpush/XGPush4Msdk;->b:J

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-wide p0
.end method

.method static synthetic b()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/XGPush4Msdk;->c:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method private static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string p0, ":"

    const-string p0, ":"

    const/4 v2, 0x4

    const-string p0, ":"

    const-string p0, ":"

    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string p0, "BVFGoDOR_XE_ENu_IRSU"

    const-string p0, "VDNOG_uEUEFSIRRB_XE_"

    const/4 v2, 0x1

    const-string p0, "UOREGbEFBVXREISN_D_G"

    const-string p0, "XG_DEBUG_SERVER_INFO"

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p0
.end method

.method private static b(JJJ)Z
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    cmp-long p2, p0, p2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    if-ltz p2, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    cmp-long p0, p0, p4

    const/4 v1, 0x4

    const/4 v0, 0x4

    if-gez p0, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p0, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 p0, 0x0

    :goto_0
    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    return p0
.end method

.method static synthetic c()J
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-wide v0, Lcom/tencent/android/tpush/XGPush4Msdk;->a:J

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-wide v0
.end method

.method public static cleanTags(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    new-instance v1, Lcom/tencent/android/tpush/XGPush4Msdk$13;

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-direct {v1, p1, p0}, Lcom/tencent/android/tpush/XGPush4Msdk$13;-><init>(Ljava/lang/String;Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void
.end method

.method public static deleteTag(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v1, Lcom/tencent/android/tpush/XGPush4Msdk$9;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v1, p1, p0}, Lcom/tencent/android/tpush/XGPush4Msdk$9;-><init>(Ljava/lang/String;Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method public static deleteTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v1, Lcom/tencent/android/tpush/XGPush4Msdk$12;

    const/4 v3, 0x7

    invoke-direct {v1, p1, p0, p2}, Lcom/tencent/android/tpush/XGPush4Msdk$12;-><init>(Ljava/lang/String;Landroid/content/Context;Ljava/util/Set;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method public static getDebugServerInfo(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPush4Msdk;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    move v3, v2

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p0
.end method

.method public static getQQAccessId(Landroid/content/Context;)J
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    sget-wide v0, Lcom/tencent/android/tpush/XGPush4Msdk;->b:J

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    cmp-long v2, v0, v2

    const/4 v5, 0x2

    if-gtz v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v2, "QC_UDSuAHTE_SSQI_P"

    const-string v2, "TPUSH_QQ_ACCESS_ID"

    const/4 v5, 0x6

    invoke-static {p0, v2, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getLong(Landroid/content/Context;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    sput-wide v0, Lcom/tencent/android/tpush/XGPush4Msdk;->b:J

    :cond_0
    const/4 v5, 0x4

    sget-wide v0, Lcom/tencent/android/tpush/XGPush4Msdk;->b:J

    const/4 v5, 0x5

    return-wide v0
.end method

.method public static getQQAppKey(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object v0, Lcom/tencent/android/tpush/XGPush4Msdk;->c:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    sget-object p0, Lcom/tencent/android/tpush/XGPush4Msdk;->c:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-object p0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string v0, "K_S_P__pAnCTS__EeU_SCEQYQ"

    const-string v0, "__en__TPUSH_QQ_ACCESS_KEY"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    sget-object v1, Lcom/tencent/android/tpush/XGPush4Msdk;->c:Ljava/lang/String;

    const/4 v4, 0x1

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-nez v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    sput-object p0, Lcom/tencent/android/tpush/XGPush4Msdk;->c:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v0, "QEU_ApCHqTES_PS_YQK"

    const-string v0, "UCSPE_EpQTH_ASYQKS_"

    const/4 v4, 0x4

    const-string v0, "S_sCECAKPSUYQ__QHET"

    const-string v0, "TPUSH_QQ_ACCESS_KEY"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    sput-object v2, Lcom/tencent/android/tpush/XGPush4Msdk;->c:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x6

    sget-object p0, Lcom/tencent/android/tpush/XGPush4Msdk;->c:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    return-object p0
.end method

.method public static isDebugServerInfoStrategyItem(Landroid/content/Context;)Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 p0, 0x0

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPush4Msdk;->getDebugServerInfo(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v1, ","

    const-string v1, ","

    const/4 v4, 0x2

    const-string v1, ","

    const-string v1, ","

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    array-length v1, v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v2, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x5

    if-ne v1, v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    aget-object v0, v0, p0

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-le v0, v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 p0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    return p0

    :catchall_0
    move-exception v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v1, "GXhmd4uksqs"

    const-string/jumbo v1, "usds4XhkqMG"

    const/4 v4, 0x3

    const-string/jumbo v1, "skhMosXGdP4"

    const-string v1, "XGPush4Msdk"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v2, "eeIfSborIgSyevngm bDs.trtrieets"

    const-string/jumbo v2, "tSs.eegervIgb rDimttSersuofeyIn"

    const-string v2, "SbI gauIrmD.ereotSiftuerenvsteg"

    const-string v2, " .isDebugServerInfoStrategyItem"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    return p0
.end method

.method public static registerPush(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 4

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    new-instance p1, Lcom/tencent/android/tpush/XGPush4Msdk$14;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p1}, Lcom/tencent/android/tpush/XGPush4Msdk$14;-><init>()V

    :cond_0
    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v1, Lcom/tencent/android/tpush/XGPush4Msdk$2;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v1, p0, p1}, Lcom/tencent/android/tpush/XGPush4Msdk$2;-><init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method

.method public static setDebugServerInfo(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPush4Msdk;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string p1, ","

    const-string p1, ","

    const/4 v3, 0x3

    const-string p1, ","

    const-string p1, ","

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0, v0, p1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance p2, Lcom/tencent/android/tpush/XGPush4Msdk$1;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p2, p0}, Lcom/tencent/android/tpush/XGPush4Msdk$1;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :goto_0
    const/4 v2, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method public static setDefaultNotificationBuilder(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V
    .locals 4

    const/4 v2, 0x2

    move v3, v2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/XGPush4Msdk$6;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v1, p0, p1}, Lcom/tencent/android/tpush/XGPush4Msdk$6;-><init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public static setPushNotificationBuilder(Landroid/content/Context;ILcom/tencent/android/tpush/XGPushNotificationBuilder;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz p0, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/16 v0, 0x1388

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-lt p1, v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/16 v0, 0x1770

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-gt p1, v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez p2, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance v1, Lcom/tencent/android/tpush/XGPush4Msdk$5;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v1, p0, p1, p2}, Lcom/tencent/android/tpush/XGPush4Msdk$5;-><init>(Landroid/content/Context;ILcom/tencent/android/tpush/XGPushNotificationBuilder;)V

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string p1, "ecimr5/8i]d30[i5/Idou.83f80t,0tnudf7/ 0uBnu6a/cl5f0o080u6"

    const/4 v3, 0x2

    const-string p1, "0tn37/6p,./0Bl5iuuu]Iiu30/c8feo[ dc5i504drdf/noft00a8808u"

    const-string/jumbo p1, "notificationBulderId\u8d85\u8fc7\u8303\u56f4[5000, 6000]."

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    throw p0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string p1, " lexo.uticl nont"

    const/4 v3, 0x1

    const-string/jumbo p1, "nclu ltnqet.oixs"

    const-string p1, "context is null."

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    throw p0
.end method

.method public static setQQAppId(Landroid/content/Context;J)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v1, Lcom/tencent/android/tpush/XGPush4Msdk$7;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {v1, p1, p2, p0}, Lcom/tencent/android/tpush/XGPush4Msdk$7;-><init>(JLandroid/content/Context;)V

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public static setQQAppKey(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    return-void
.end method

.method public static setTag(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/XGPush4Msdk$8;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v1, p1, p0}, Lcom/tencent/android/tpush/XGPush4Msdk$8;-><init>(Ljava/lang/String;Landroid/content/Context;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-void
.end method

.method public static setTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v1, Lcom/tencent/android/tpush/XGPush4Msdk$10;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v1, p1, p0, p2}, Lcom/tencent/android/tpush/XGPush4Msdk$10;-><init>(Ljava/lang/String;Landroid/content/Context;Ljava/util/Set;)V

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method public static unregisterPush(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    new-instance p1, Lcom/tencent/android/tpush/XGPush4Msdk$3;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {p1}, Lcom/tencent/android/tpush/XGPush4Msdk$3;-><init>()V

    :cond_0
    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/XGPush4Msdk$4;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v1, p0, p1}, Lcom/tencent/android/tpush/XGPush4Msdk$4;-><init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method
