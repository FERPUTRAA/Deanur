.class Lcom/tencent/android/tpush/XGPush4Msdk$7;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPush4Msdk;->setQQAppId(Landroid/content/Context;J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Landroid/content/Context;


# direct methods
.method constructor <init>(JLandroid/content/Context;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-wide p1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->b:Landroid/content/Context;

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "risfo~  ~@ o@~/-@b~~v@b~l/~@M1c~u~@a~~~o  iKsn@@~ @@4  o@@y ~Sm~ ~@t. @l@~@~@b@~~d~f ~   i@oo  t"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x1

    iget-wide v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v10, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v10, 0x3

    const-wide/32 v4, 0x30d40

    const/4 v10, 0x0

    const-wide/32 v4, 0x30d40

    const-wide/32 v4, 0x30d40

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-static/range {v0 .. v5}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(JJJ)Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x6

    if-eqz v0, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-wide/32 v0, 0x55d4a80

    const-wide/32 v0, 0x55d4a80

    const/4 v10, 0x2

    const-wide/32 v0, 0x55d4a80

    const-wide/32 v0, 0x55d4a80

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    goto/16 :goto_1

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    iget-wide v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x6

    const-wide/32 v4, 0x5e69ec0

    const-wide/32 v4, 0x5e69ec0

    const/4 v10, 0x1

    const-wide/32 v4, 0x5e69ec0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    const-wide/32 v6, 0x5f5e100

    const-wide/32 v6, 0x5f5e100

    const/4 v10, 0x4

    const-wide/32 v6, 0x5f5e100

    const-wide/32 v6, 0x5f5e100

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static/range {v2 .. v7}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(JJJ)Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v10, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x0

    if-eqz v0, :cond_1

    :goto_0
    move-wide v0, v1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    goto/16 :goto_1

    :cond_1
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x1

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x2

    const/4 v9, 0x1

    const-wide/32 v5, 0x5f8ee40

    const-wide/32 v5, 0x5f8ee40

    const/4 v10, 0x1

    const-wide/32 v5, 0x5f8ee40

    const-wide/32 v5, 0x5f8ee40

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    const-wide/32 v7, 0x5ff08c0

    const-wide/32 v7, 0x5ff08c0

    const/4 v10, 0x0

    const-wide/32 v7, 0x5ff08c0

    const-wide/32 v7, 0x5ff08c0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static/range {v3 .. v8}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(JJJ)Z

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-eqz v0, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    const-wide/32 v0, -0x989680

    const-wide/32 v0, -0x989680

    const/4 v10, 0x0

    const-wide/32 v0, -0x989680

    const-wide/32 v0, -0x989680

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    goto/16 :goto_1

    :cond_2
    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x0

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-wide/32 v5, 0x6052340

    const/4 v10, 0x5

    const-wide/32 v5, 0x6052340

    const-wide/32 v5, 0x6052340

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-wide/32 v7, 0x60b3dc0

    const-wide/32 v7, 0x60b3dc0

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-static/range {v3 .. v8}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(JJJ)Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-eqz v0, :cond_3

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    const-wide/32 v0, -0x9eb100

    const-wide/32 v0, -0x9eb100

    const/4 v10, 0x2

    const-wide/32 v0, -0x9eb100

    const-wide/32 v0, -0x9eb100

    const/4 v10, 0x3

    const/4 v9, 0x3

    goto/16 :goto_1

    :cond_3
    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x3

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-wide/32 v5, 0x35a4e900

    const-wide/32 v5, 0x35a4e900

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    const-wide/32 v7, 0x35a66fa0

    const-wide/32 v7, 0x35a66fa0

    const/4 v10, 0x7

    const-wide/32 v7, 0x35a66fa0

    const-wide/32 v7, 0x35a66fa0

    const/4 v10, 0x6

    const/4 v9, 0x1

    invoke-static/range {v3 .. v8}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(JJJ)Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-eqz v0, :cond_4

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    const-wide/32 v0, -0x30385c40

    const-wide/32 v0, -0x30385c40

    const-wide/32 v0, -0x30385c40

    const-wide/32 v0, -0x30385c40

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    goto/16 :goto_1

    :cond_4
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-wide/32 v5, 0x3b9aca00

    const-wide/32 v5, 0x3b9aca00

    const/4 v10, 0x4

    const-wide/32 v5, 0x3b9aca00

    const-wide/32 v5, 0x3b9aca00

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-wide/32 v7, 0x3b9c50a0

    const/4 v10, 0x5

    const-wide/32 v7, 0x3b9c50a0

    const-wide/32 v7, 0x3b9c50a0

    const/4 v10, 0x4

    const/4 v9, 0x0

    invoke-static/range {v3 .. v8}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(JJJ)Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz v0, :cond_5

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-wide/32 v0, -0x362cb6a0

    const-wide/32 v0, -0x362cb6a0

    const-wide/32 v0, -0x362cb6a0

    const-wide/32 v0, -0x362cb6a0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x6

    goto/16 :goto_1

    :cond_5
    const/4 v10, 0x4

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    const-wide/32 v5, 0x419fed40

    const-wide/32 v5, 0x419fed40

    const/4 v10, 0x6

    const-wide/32 v5, 0x419fed40

    const-wide/32 v5, 0x419fed40

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-wide/32 v7, 0x41d55520

    const-wide/32 v7, 0x41d55520

    const/4 v10, 0x1

    const-wide/32 v7, 0x41d55520

    const-wide/32 v7, 0x41d55520

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static/range {v3 .. v8}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(JJJ)Z

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    if-eqz v0, :cond_6

    const/4 v10, 0x0

    const-wide/32 v0, -0x3c305340

    const-wide/32 v0, -0x3c305340

    const/4 v10, 0x1

    const-wide/32 v0, -0x3c305340

    const-wide/32 v0, -0x3c305340

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    goto/16 :goto_1

    :cond_6
    const/4 v10, 0x1

    const/4 v9, 0x3

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    const-wide/32 v5, 0x448b9b80

    const-wide/32 v5, 0x448b9b80

    const/4 v10, 0x3

    const-wide/32 v5, 0x448b9b80

    const-wide/32 v5, 0x448b9b80

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    const-wide/32 v7, 0x448d2220

    const/4 v10, 0x7

    const-wide/32 v7, 0x448d2220

    const-wide/32 v7, 0x448d2220

    const/4 v10, 0x0

    invoke-static/range {v3 .. v8}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(JJJ)Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-eqz v0, :cond_7

    const/4 v10, 0x0

    const/4 v9, 0x1

    const-wide/32 v0, -0x3ee699a0

    const-wide/32 v0, -0x3ee699a0

    const/4 v10, 0x6

    const-wide/32 v0, -0x3ee699a0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x4

    goto/16 :goto_1

    :cond_7
    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v9, 0x5

    move v10, v9

    const-wide/32 v5, 0x5ff08c0

    const-wide/32 v5, 0x5ff08c0

    const/4 v10, 0x5

    const-wide/32 v5, 0x5ff08c0

    const-wide/32 v5, 0x5ff08c0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    const-wide/32 v7, 0x6052340

    const-wide/32 v7, 0x6052340

    const-wide/32 v7, 0x6052340

    const-wide/32 v7, 0x6052340

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static/range {v3 .. v8}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(JJJ)Z

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-eqz v0, :cond_8

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    const-wide/32 v0, -0x588040

    const-wide/32 v0, -0x588040

    const/4 v10, 0x5

    const-wide/32 v0, -0x588040

    const-wide/32 v0, -0x588040

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    goto/16 :goto_1

    :cond_8
    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x7

    const-wide/32 v5, 0x41d55520

    const-wide/32 v5, 0x41d55520

    const/4 v10, 0x2

    const-wide/32 v5, 0x41d55520

    const-wide/32 v5, 0x41d55520

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    const-wide/32 v7, 0x421e9320

    const-wide/32 v7, 0x421e9320

    const/4 v10, 0x2

    const-wide/32 v7, 0x421e9320

    const-wide/32 v7, 0x421e9320

    const/4 v10, 0x1

    const/4 v9, 0x0

    invoke-static/range {v3 .. v8}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(JJJ)Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-eqz v0, :cond_9

    const/4 v9, 0x7

    xor-int/2addr v10, v9

    const-wide/32 v0, -0x3c28b220

    const-wide/32 v0, -0x3c28b220

    const/4 v10, 0x5

    const-wide/32 v0, -0x3c28b220

    const-wide/32 v0, -0x3c28b220

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    goto/16 :goto_1

    :cond_9
    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-wide/32 v5, 0x421e9320

    const-wide/32 v5, 0x421e9320

    const/4 v10, 0x2

    const-wide/32 v5, 0x421e9320

    const-wide/32 v5, 0x421e9320

    const/4 v10, 0x7

    const-wide/32 v7, 0x42b729a0

    const-wide/32 v7, 0x42b729a0

    const/4 v10, 0x3

    const-wide/32 v7, 0x42b729a0

    const-wide/32 v7, 0x42b729a0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static/range {v3 .. v8}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(JJJ)Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x4

    if-eqz v0, :cond_a

    const/4 v10, 0x6

    const-wide/32 v0, -0x3d59df20

    const-wide/32 v0, -0x3d59df20

    const/4 v10, 0x6

    const-wide/32 v0, -0x3d59df20

    const-wide/32 v0, -0x3d59df20

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    goto/16 :goto_1

    :cond_a
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x4

    const-wide/32 v5, 0x42b729a0

    const-wide/32 v5, 0x42b729a0

    const/4 v10, 0x4

    const-wide/32 v5, 0x42b729a0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-wide/32 v7, 0x42c1d800

    const-wide/32 v7, 0x42c1d800

    const/4 v10, 0x3

    const-wide/32 v7, 0x42c1d800

    const-wide/32 v7, 0x42c1d800

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static/range {v3 .. v8}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(JJJ)Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz v0, :cond_b

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x2

    const-wide/32 v0, -0x3e8b0c20

    const-wide/32 v0, -0x3e8b0c20

    const/4 v10, 0x5

    const-wide/32 v0, -0x3e8b0c20

    const-wide/32 v0, -0x3e8b0c20

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    goto :goto_1

    :cond_b
    const/4 v9, 0x3

    move v10, v9

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-string v3, "28suiuaQ7//uf/p646f4pbad"

    const-string v3, "4damf66b4i28ufpa/u71//Qu"

    const-string/jumbo v3, "\u624bQ\u7684appid\uff1a"

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x4

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    const-string v3, "7fe6of04bc445ab85d43//8u08e0 ude5b8u9570du4u6uc89fuccf/720/8/3/2k0s/uuua8u/60m4u/9/1eu3455u4ub6eu3//f/b/f1u/7//uub8//73fum4/548e3/u"

    const-string/jumbo v3, "udam37buc6e6e//4fkd1u2fb70b4448u384u5cf380//ed888uf155cuu5u0umu8c/349/bu4/eu/455/u/840//57af4s//u/fu8e943b2//0e6/b/3 77uuu0/fuu06/9"

    const/4 v10, 0x7

    const-string v3, "847u/bub6b/u88/6/4u 0d3//b/uu40uuf9uu85a77u48d51e/cuuu/uu8uc0fue54a72/b84/93/kc/073b/e06/e55584/s30f51e/c//4u9/fd534uuf4fm26f8b0e4/"

    const-string v3, " \u4e0d\u5728\u56fa\u5b9a\u7684\u8303\u56f4\uff0c\u8bf7\u8054\u7cfbmsdk\u548c\u4fe1\u9e3d\u7684\u540c\u4e8b\u89e3\u51b3\u4e4b\u3002"

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-string v3, "hXdk4suusGo"

    const-string/jumbo v3, "ss4GokhPdXu"

    const/4 v10, 0x5

    const-string/jumbo v3, "ss4duXGphMk"

    const-string v3, "XGPush4Msdk"

    const/4 v10, 0x7

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x6

    goto/16 :goto_0

    :goto_1
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-wide/32 v2, 0x7d2b7500

    const-wide/32 v2, 0x7d2b7500

    const/4 v10, 0x5

    const-wide/32 v2, 0x7d2b7500

    const-wide/32 v2, 0x7d2b7500

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    add-long/2addr v0, v2

    const/4 v10, 0x1

    iget-wide v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    add-long/2addr v0, v2

    const/4 v10, 0x0

    const/4 v9, 0x2

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(J)J

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/XGPush4Msdk;->b(J)J

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->b:Landroid/content/Context;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const-string v1, "S_PAEC_QqUD_STICQS"

    const-string v1, "TPUSH_QQ_ACCESS_ID"

    const/4 v9, 0x7

    xor-int/2addr v10, v9

    invoke-static {}, Lcom/tencent/android/tpush/XGPush4Msdk;->a()J

    move-result-wide v2

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {v0, v1, v2, v3}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putLong(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->b:Landroid/content/Context;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-string v1, "PPsTHI_UAQP__DS"

    const-string v1, "TPUSH_QQ_APP_ID"

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->remove(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-string v1, "_bSmM"

    const-string v1, "bSM_D"

    const/4 v10, 0x3

    const-string v1, "DKSMo"

    const-string v1, "MSDK_"

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    iget-wide v1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->a:J

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(Ljava/lang/String;)Ljava/lang/String;

    const/4 v10, 0x7

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->b:Landroid/content/Context;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/XGPush4Msdk;->b()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string v2, "A_QS_b_Qn_T_PCHSuEUEYK__e"

    const-string v2, "ES_S__u_TnCYEHQeQ_A_K_CPU"

    const/4 v10, 0x7

    const-string v2, "SEE_TKuU_HY_nCQQAC__SP_e_"

    const-string v2, "__en__TPUSH_QQ_ACCESS_KEY"

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {v0, v2, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$7;->b:Landroid/content/Context;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    const-string v1, "PTESQQ_pU_SAHC_ESCY"

    const-string v1, "TPUSH_QQ_ACCESS_KEY"

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->remove(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v10, 0x1

    return-void
.end method
