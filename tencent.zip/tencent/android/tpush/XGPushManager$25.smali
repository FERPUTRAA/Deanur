.class Lcom/tencent/android/tpush/XGPushManager$25;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->f(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/XGIOperateCallback;

.field final synthetic b:Z


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGIOperateCallback;Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$25;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-boolean p2, p0, Lcom/tencent/android/tpush/XGPushManager$25;->b:Z

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "@ s~~l@14@a  t ~ ~. ~~~t @S om~@@rf@~ ~M~oo~~~@  c@@f-@b@ @bou/~vy ~K~i@~dib @ n~@ls /@ ~i~~@@@o"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x2

    const-string v1, "Rklmttociace s  r bsgl"

    const-string v1, "bcslocir sa egkRe t lt"

    const/4 v11, 0x7

    const-string v1, "be aoi rRlgtoe acc skl"

    const-string v1, "Register call back to "

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x7

    const-string v1, "aMuenbaXhPmgs"

    const-string v1, "GnhmXuPgeaMsa"

    const/4 v11, 0x3

    const-string/jumbo v1, "renPGXuasuagh"

    const-string v1, "XGPushManager"

    const/4 v11, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    new-instance v9, Lcom/tencent/android/tpush/XGPushManager$a;

    const/4 v11, 0x0

    const/4 v10, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$25;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    const/4 v6, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v7, 0x5

    const/4 v7, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x5

    iget-boolean v8, p0, Lcom/tencent/android/tpush/XGPushManager$25;->b:Z

    move-object v2, v9

    move-object v2, v9

    move-object v2, v9

    move-object v2, v9

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-direct/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager$a;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;Landroid/content/Context;Landroid/content/Intent;IIZ)V

    const/4 v11, 0x5

    invoke-virtual {v0, v9}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    goto :goto_0

    :catchall_0
    move-exception p2

    const/4 v11, 0x3

    const/4 v10, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x1

    const-string v2, "errere pdso glelic nrlraoabka c"

    const-string v2, "aaiaos l rrg oeeerrdlbe cctlnrk"

    const/4 v11, 0x4

    const-string v2, "erlgraskqblocatherd  lariern ec"

    const-string/jumbo v2, "register handle callback error "

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {p2}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {v1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v11, 0x0

    const/4 v10, 0x5

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;)Z

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    return-void
.end method
