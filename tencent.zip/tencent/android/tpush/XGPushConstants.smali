.class public Lcom/tencent/android/tpush/XGPushConstants;
.super Ljava/lang/Object;


# static fields
.field public static final SDK_VERSION:Ljava/lang/String; = "1.4.3.9"

.field public static final VIP_TAG:Ljava/lang/String; = "vip"


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    or-int/2addr v1, v0

    return-void
.end method
