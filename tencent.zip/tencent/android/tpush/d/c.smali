.class public abstract Lcom/tencent/android/tpush/d/c;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public abstract a()Ljava/lang/String;
.end method

.method public abstract a(Landroid/content/Context;)V
.end method

.method public abstract b(Landroid/content/Context;)V
.end method

.method public abstract c(Landroid/content/Context;)Ljava/lang/String;
.end method

.method public abstract d(Landroid/content/Context;)Z
.end method

.method public abstract e(Landroid/content/Context;)I
.end method

.method public abstract f(Landroid/content/Context;)Ljava/lang/String;
.end method
