.class public Lcom/tencent/android/tpush/d/a;
.super Ljava/lang/Object;


# static fields
.field private static final a:[Ljava/lang/String;

.field private static b:I

.field private static c:Ljava/lang/String;

.field private static d:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v0, "n.shphhrlmuteus.pdmunelipIcnshm.othomohaOtPsps.tdi.ui.esetrr."

    const-string/jumbo v0, "rhsroeOspeunhtl..hhmutIsmmmunrh.nuhiadpttc.iooPpsep.lds..ciet"

    const/4 v3, 0x6

    const-string v0, ".eemith.honoPhplsia.c.tipmspeotmsmed.dc.uthhutsprplrIOnhu.urn"

    const-string v0, "com.tencent.android.tpush.otherpush.mipush.impl.OtherPushImpl"

    const/4 v3, 0x1

    const-string v1, ".hrtoPset.nuecdrm.fhmm.omutohsO.ehcrptmo.lpnnpluiiscIapehd"

    const-string v1, "cmum.hphrds.pcmsoOntP.cuehhnmt.eeprihslidtmIeto.apno.lruf."

    const/4 v3, 0x5

    const-string/jumbo v1, "snof.bttaio.ee.udhcm.nI.hiluhPthucnsmmpsteleOrrt.mpdhp.cor"

    const-string v1, "com.tencent.android.tpush.otherpush.fcm.impl.OtherPushImpl"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    sput-object v0, Lcom/tencent/android/tpush/d/a;->a:[Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, -0x2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    sput v0, Lcom/tencent/android/tpush/d/a;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    sput-object v0, Lcom/tencent/android/tpush/d/a;->c:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    sput v0, Lcom/tencent/android/tpush/d/a;->d:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method public static a()I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~oo.osu~-@~l@ r@o~~@@c~ o4b/l@~~~ @ft~  @ y~S d@~@n ~/M@tm ~@i baii ~@~@1@ fK~@  @~~ ~@@ ~b@ouv~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget v0, Lcom/tencent/android/tpush/d/a;->d:I

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, -0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-ne v0, v1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHuaWei()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHonor()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    sput v1, Lcom/tencent/android/tpush/d/a;->d:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    goto :goto_1

    :cond_1
    :goto_0
    :try_start_0
    const/4 v3, 0x7

    const-string/jumbo v0, "waucsHap.emh.heIniaI.mts.sndcadoo"

    const-string v0, "HdI.oIdaahmnhcsaie..estwimsnuoc.a"

    const/4 v3, 0x2

    const-string/jumbo v0, "umceicsIq.awdIithm.aoHmndne.sa.ah"

    const-string v0, "com.huawei.hms.aaid.HmsInstanceId"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    sput v0, Lcom/tencent/android/tpush/d/a;->d:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_1

    :catchall_0
    :try_start_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v0, "wtsnamSggMreimuhc.ebte.odi..daHnAas.n"

    const-string/jumbo v0, "ro.MnbtHiw.ie..s.cnmeeAgSaddahgamhunt"

    const/4 v3, 0x1

    const-string/jumbo v0, "nMHm..Ai.duamnmote.aedceaSrhsgow.tgnh"

    const-string v0, "com.huawei.android.hms.agent.HMSAgent"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    sput v0, Lcom/tencent/android/tpush/d/a;->d:I
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_1

    :catchall_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    sput v1, Lcom/tencent/android/tpush/d/a;->d:I

    :cond_2
    :goto_1
    const/4 v2, 0x0

    move v3, v2

    sget v0, Lcom/tencent/android/tpush/d/a;->d:I

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    return v0
.end method

.method private static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 7

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {p2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v0, 0x3

    const/4 v0, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    new-array v1, v0, [Ljava/lang/Class;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const-class v2, Landroid/content/Context;

    const-class v2, Landroid/content/Context;

    const/4 v6, 0x2

    const-class v2, Landroid/content/Context;

    const-class v2, Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v3, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    aput-object v2, v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-class v2, Ljava/lang/String;

    const-class v2, Ljava/lang/String;

    const/4 v6, 0x5

    const-class v2, Ljava/lang/String;

    const-class v2, Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v4, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    aput-object v2, v1, v4

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-string v2, "dpuiopAt"

    const-string v2, "Aptpisud"

    const/4 v6, 0x2

    const-string/jumbo v2, "ptpAdbes"

    const-string/jumbo v2, "setAppid"

    const/4 v5, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p2, v2, v1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v6, 0x0

    const/4 v5, 0x7

    aput-object p0, v0, v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    aput-object p1, v0, v4

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v1, p2, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const-string/jumbo p2, "podrirucosaet pAaturgk u ?smhrar,ooy p epeti hp Er"

    const-string/jumbo p2, "tcroopopodus rerkeaA uiphp r?t Esmtpygpea  ih, rar"

    const/4 v6, 0x6

    const-string p2, "   keo pgeprpasheo?prAraia,uco yp rErdtstomrueh pi"

    const-string/jumbo p2, "setAppid Error, are you import otherpush package? "

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const-string p1, "Othrhqusq"

    const-string/jumbo p1, "rhthusOPq"

    const/4 v6, 0x2

    const-string p1, "Ossthuhre"

    const-string p1, "OtherPush"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v6, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;)Z
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    sget v0, Lcom/tencent/android/tpush/d/a;->b:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v1, -0x2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/4 v3, -0x1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/4 v4, 0x1

    const/4 v7, 0x3

    if-ne v0, v1, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    move v0, v2

    move v0, v2

    const/4 v7, 0x2

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    sget-object v1, Lcom/tencent/android/tpush/d/a;->a:[Ljava/lang/String;

    const/4 v7, 0x3

    array-length v5, v1

    if-ge v0, v5, :cond_1

    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    aget-object v5, v1, v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    aget-object v5, v1, v0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {p0, v5}, Lcom/tencent/android/tpush/d/a;->a(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v5

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-eqz v5, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    sput v0, Lcom/tencent/android/tpush/d/a;->b:I

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    aget-object p0, v1, v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    sput-object p0, Lcom/tencent/android/tpush/d/a;->c:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    return v4

    :catch_0
    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    add-int/lit8 v0, v0, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    sput v3, Lcom/tencent/android/tpush/d/a;->b:I

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    sget p0, Lcom/tencent/android/tpush/d/a;->b:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-le p0, v3, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    move v2, v4

    move v2, v4

    const/4 v7, 0x6

    move v2, v4

    move v2, v4

    :cond_3
    const/4 v6, 0x3

    const/4 v6, 0x0

    return v2
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v0, "hremssOth"

    const-string v0, "eOsrPhsht"

    const/4 v6, 0x4

    const-string v0, "ethOoushP"

    const-string v0, "OtherPush"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v1, 0x0

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const-string/jumbo v3, "ieeacbcesvsapu shkceCNlhm"

    const-string v3, "hCpm lhseDsNaivcsekaeucce"

    const/4 v6, 0x4

    const-string/jumbo v3, "l CcNcuhueisaakhseepmeDvs"

    const-string v3, "checkDevice pushClassName"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {p1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v2, 0x1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-class v4, Landroid/content/Context;

    const-class v4, Landroid/content/Context;

    const/4 v6, 0x7

    const-class v4, Landroid/content/Context;

    const-class v4, Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    aput-object v4, v3, v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string v4, "Deieokcphvc"

    const-string v4, "ekDcovehiec"

    const/4 v6, 0x4

    const-string v4, "eevihDccqce"

    const-string v4, "checkDevice"

    const/4 v6, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1, v4, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    aput-object p0, v2, v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v3, p1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    check-cast p0, Ljava/lang/Boolean;

    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const-string v2, "Dksrresae vkr c,yehoocthtr epe  rorpepuhub?acia gomiE"

    const-string/jumbo v2, "oe,rabr ktkmceeaee gphs oEyc ore rrauhiuvpi? crtDph o"

    const/4 v6, 0x2

    const-string v2, "euymrvcsrpokehicaeih  r,a rgku prccmte  hope eEtoD?ar"

    const-string v2, "checkDevice Error, are you import otherpush package? "

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string v2, "erugoect ci fcevDtIorokehrcaa:inntEr rpoonvE Txie"

    const-string/jumbo v2, "pecooguccatcnfvroI nexenr:Tia rrtoEkcvteeri Dh iE"

    const/4 v6, 0x1

    const-string v2, "checkDevice Error for InvocationTargetException: "

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    return v1
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string/jumbo v0, "uhcthbIltrmon.fopoeraspunmtimeutenc.ctP.hpedhdrOlph..msip."

    const-string v0, "h.cce.ophmchp.htOrpdestnen.msl.lrmotPiemtupfihaItpruuo.nsd"

    const/4 v2, 0x1

    const-string/jumbo v0, "usIsteudp.mihhnnl...lurOcshcPttfhor.udp.hmcmepeotptmaeion."

    const-string v0, "com.tencent.android.tpush.otherpush.fcm.impl.OtherPushImpl"

    const/4 v2, 0x6

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpush/d/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method
