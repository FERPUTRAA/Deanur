.class Lcom/tencent/android/tpush/d/b$2$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/d/b$2;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Lcom/tencent/android/tpush/d/b$2;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/d/b$2;Landroid/content/Context;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/d/b$2$1;->c:Lcom/tencent/android/tpush/d/b$2;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpush/d/b$2$1;->a:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/tencent/android/tpush/d/b$2$1;->b:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "~1sc~ ob~@@S~ nli @~ o4~~@@o/@@ ~@m ~~yo@ ~~@a/rd.iM~- @b u@~~~ @itv @fo~obl@t~~K@ @~~~s @   f @"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    const-string/jumbo v1, "k amhOtdlTeocnpchlhltanbas e eUrte ksoda"

    const-string/jumbo v1, "ldsPk aehoonaO bcrUtkesthheenTpdlaatcl  "

    const/4 v7, 0x3

    const-string/jumbo v1, "tbaco acPlO   eedrlsehhknoeauankdTplhUot"

    const-string v1, "handleUpdateOtherPushToken call back to "

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/d/b$2$1;->a:Landroid/content/Context;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string v1, "CleehbtPmnstirO"

    const-string/jumbo v1, "iuCmntesrPtOlhe"

    const/4 v7, 0x1

    const-string/jumbo v1, "unPtehulCtOehsi"

    const-string v1, "OtherPushClient"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/d/b$2$1;->b:Landroid/content/Context;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    const/4 v1, 0x2

    const/4 v6, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-array v1, v1, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/d/b$2$1;->c:Lcom/tencent/android/tpush/d/b$2;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-wide v3, v3, Lcom/tencent/android/tpush/d/b$2;->a:J

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v2, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x6

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {v2}, Lcom/tencent/android/tpush/e/b/a;->a(Ljava/lang/String;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    iget-object v5, p0, Lcom/tencent/android/tpush/d/b$2$1;->c:Lcom/tencent/android/tpush/d/b$2;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v5, v5, Lcom/tencent/android/tpush/d/b$2;->b:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v5, ":"

    const-string v5, ":"

    const-string v5, ":"

    const-string v5, ":"

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    iget-object v5, p0, Lcom/tencent/android/tpush/d/b$2$1;->c:Lcom/tencent/android/tpush/d/b$2;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v5, v5, Lcom/tencent/android/tpush/d/b$2;->c:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v2, v4}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v4, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    aput-object v2, v1, v4

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpush/d/b$2$1;->c:Lcom/tencent/android/tpush/d/b$2;

    const/4 v7, 0x4

    const/4 v6, 0x4

    iget-wide v4, v4, Lcom/tencent/android/tpush/d/b$2;->a:J

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v2, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {v2}, Lcom/tencent/android/tpush/e/b/a;->b(Ljava/lang/String;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v2, v3}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v3, 0x1

    const/4 v7, 0x7

    aput-object v2, v1, v3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-void
.end method
