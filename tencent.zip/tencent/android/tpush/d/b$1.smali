.class Lcom/tencent/android/tpush/d/b$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/d/b;->a(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/d/b$1;->a:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " -sl~ oo@S@@~dbv~ b  no@~@@ ~r M~ 4~~~/uf@ o @@~mc1~b~@K@ ~a~.@  ~y~ i~t~@~@i@ol@@so  t~ f/@~@@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/d/b$1;->a:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/d/b;->b(Landroid/content/Context;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method
