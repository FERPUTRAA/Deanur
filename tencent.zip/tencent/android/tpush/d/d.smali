.class public Lcom/tencent/android/tpush/d/d;
.super Ljava/lang/Object;


# static fields
.field public static a:Ljava/lang/String; = ""

.field public static b:Ljava/lang/String; = ""

.field public static c:Ljava/lang/String; = ""

.field public static d:Ljava/lang/String; = ""

.field public static e:Ljava/lang/String; = ""

.field public static f:Ljava/lang/String; = ""

.field public static g:Ljava/lang/Boolean;

.field public static h:Ljava/lang/String;

.field private static volatile i:Lcom/tencent/android/tpush/d/d;

.field private static volatile j:Lcom/tencent/android/tpush/d/c;

.field private static volatile k:Lcom/tencent/android/tpush/d/c;

.field private static volatile l:Lcom/tencent/android/tpush/d/c;


# instance fields
.field private m:Ljava/lang/Boolean;

.field private n:Ljava/lang/Boolean;

.field private o:Ljava/lang/Boolean;

.field private p:Landroid/content/Context;

.field private q:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object v0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/android/tpush/d/d;->g:Ljava/lang/Boolean;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v1, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    sput-object v0, Lcom/tencent/android/tpush/d/d;->h:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x3

    sput-object v0, Lcom/tencent/android/tpush/d/d;->i:Lcom/tencent/android/tpush/d/d;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    sput-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v2, 0x4

    sput-object v0, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    const/4 v2, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, -0x1

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput v0, p0, Lcom/tencent/android/tpush/d/d;->q:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/common/h;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/common/h;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {v0}, Lcom/tencent/android/tpush/common/h;->a()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedFcmPush(Landroid/content/Context;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance p1, Lcom/tencent/android/tpush/d/a/a;

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p1}, Lcom/tencent/android/tpush/d/a/a;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    sput-object p1, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/d;->b(Landroid/content/Context;)Lcom/tencent/android/tpush/d/c;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    sput-object p1, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/d/d;->n()Z

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    if-eqz p1, :cond_1

    const/4 v2, 0x1

    sget-object p1, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    sput-object p1, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v2, 0x6

    goto :goto_0

    :cond_1
    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/d/d;->o()Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz p1, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object p1, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    sput-object p1, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto :goto_0

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object p1, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    sput-object p1, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "b/s ~.@~ f~s i~of@4iSn~ou@@ ~/@ i~  @@~@orvbot~~m1@l~l   K@~~  ~@ @~Mc~~-ba~~@~@d~@@o t  @@ ~y@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/d/d;->i:Lcom/tencent/android/tpush/d/d;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-class v0, Lcom/tencent/android/tpush/d/d;

    const-class v0, Lcom/tencent/android/tpush/d/d;

    const/4 v3, 0x7

    const-class v0, Lcom/tencent/android/tpush/d/d;

    const-class v0, Lcom/tencent/android/tpush/d/d;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    sget-object v1, Lcom/tencent/android/tpush/d/d;->i:Lcom/tencent/android/tpush/d/d;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v1, Lcom/tencent/android/tpush/d/d;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/d/d;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    sput-object v1, Lcom/tencent/android/tpush/d/d;->i:Lcom/tencent/android/tpush/d/d;

    :cond_0
    const/4 v2, 0x5

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget-object p0, Lcom/tencent/android/tpush/d/d;->i:Lcom/tencent/android/tpush/d/d;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object p0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x0

    sput-object p1, Lcom/tencent/android/tpush/d/d;->a:Ljava/lang/String;

    const/4 v0, 0x1

    move v1, v0

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x1

    const-string/jumbo v0, "rhpmsersorutoo_d_c_ee"

    const-string/jumbo v0, "rssorhphedo__eru_teoc"

    const/4 v6, 0x0

    const-string v0, "cr_ooeroptsoheudh_er_"

    const-string/jumbo v0, "other_push_error_code"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v6, 0x0

    const-string v1, ""

    const-string v1, ""

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {p0, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto :goto_0

    :catchall_0
    move-exception v2

    :try_start_1
    const/4 v6, 0x4

    const/4 v5, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    move v6, v5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string v4, "efraubr oprgr sr :n srodr eetm"

    const-string/jumbo v4, "read returnMsg from sp error: "

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {p1, v2}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x5

    const/4 v5, 0x7

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-nez v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {p0, v0, p2}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_1

    :catchall_1
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const-string v0, "grrMsauurn etrmsv eoer"

    const-string v0, "ersmrrrtgMsu:reoe van "

    const/4 v6, 0x1

    const-string/jumbo v0, "vsorr Mpa: e esuertrgr"

    const-string/jumbo v0, "save returnMsg error: "

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_1
    const/4 v6, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;Z)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    sput-object p0, Lcom/tencent/android/tpush/d/d;->g:Ljava/lang/Boolean;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method private b(Landroid/content/Context;)Lcom/tencent/android/tpush/d/c;
    .locals 6

    const/4 v5, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/d/d;->j()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v2}, Lcom/tencent/android/tpush/f/a;->b(Landroid/content/Context;)Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v3, "arohPsuhqMtenagr"

    const-string v3, "erMgosartehhPnau"

    const/4 v5, 0x1

    const-string v3, "OtherPushManager"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v2, :cond_0

    :try_start_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string p1, "g sUXSbsy"

    const-string p1, "Sg sybSXU"

    const/4 v5, 0x3

    const-string p1, "SUXm gSsy"

    const-string p1, "USE XgSys"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-instance p1, Lcom/tencent/android/tpush/d/a/h;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {p1, v1}, Lcom/tencent/android/tpush/d/a/h;-><init>(Landroid/content/Context;)V

    :goto_0
    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto/16 :goto_4

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandXiaoMi()Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-nez v2, :cond_a

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandBlackShark()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    goto/16 :goto_3

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHuaWei()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-nez v2, :cond_7

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHonor()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez v2, :cond_7

    const/4 v4, 0x0

    and-int/2addr v5, v4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isEmuiOrOhosVersion()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-eqz v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    goto/16 :goto_2

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandMeiZu()Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz p1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo p1, "me uoizuU"

    const-string p1, "eU mEuuzi"

    const/4 v5, 0x7

    const-string p1, "UizSubEme"

    const-string p1, "USE meizu"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance p1, Lcom/tencent/android/tpush/d/a/d;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {p1}, Lcom/tencent/android/tpush/d/a/d;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_3
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo p1, "poop"

    const-string/jumbo p1, "popo"

    const/4 v5, 0x4

    const-string/jumbo p1, "ppoo"

    const-string/jumbo p1, "oppo"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-nez p1, :cond_6

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo p1, "pnpsleu"

    const/4 v5, 0x4

    const-string/jumbo p1, "oneplus"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    if-nez p1, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo p1, "ueqalm"

    const-string p1, "amqrel"

    const/4 v5, 0x0

    const-string p1, "epmler"

    const-string/jumbo p1, "realme"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eqz p1, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_1

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo p1, "vovi"

    const/4 v5, 0x0

    const-string/jumbo p1, "vvoi"

    const-string/jumbo p1, "vivo"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz p1, :cond_5

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo p1, "qEio Svs"

    const-string/jumbo p1, "oEs ivSv"

    const/4 v5, 0x2

    const-string/jumbo p1, "vEsvoUi "

    const-string p1, "USE vivo"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance p1, Lcom/tencent/android/tpush/d/a/g;

    const/4 v5, 0x7

    invoke-direct {p1}, Lcom/tencent/android/tpush/d/a/g;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto/16 :goto_0

    :cond_5
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v2, "idpmy:evcT e"

    const/4 v5, 0x5

    const-string v2, "cTimpdv:ye e"

    const-string v2, "deviceType: "

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto/16 :goto_4

    :cond_6
    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string p1, "SUoEoppo"

    const-string/jumbo p1, "pE UoopS"

    const/4 v5, 0x1

    const-string/jumbo p1, "poUSobpE"

    const-string p1, "USE oppo"

    const/4 v4, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance p1, Lcom/tencent/android/tpush/d/a/f;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {p1}, Lcom/tencent/android/tpush/d/a/f;-><init>()V

    const/4 v4, 0x7

    or-int/2addr v5, v4

    goto/16 :goto_0

    :cond_7
    :goto_2
    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHonor()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v1, :cond_9

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string v1, " bhroUuSE"

    const-string/jumbo v1, "nrUShb Eo"

    const-string v1, "ShoonrEpU"

    const-string v1, "USE honor"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v1, Lcom/tencent/android/tpush/d/a/b;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v1}, Lcom/tencent/android/tpush/d/a/b;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v1, p1}, Lcom/tencent/android/tpush/d/c;->d(Landroid/content/Context;)Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez p1, :cond_8

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isHonorNewDevice()Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-nez p1, :cond_8

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo p1, "sa eusuuh seiesen    ,rsbfutloEr tgwfUiinoeuhrCnosS ituaa"

    const/4 v5, 0x4

    const-string/jumbo p1, "tesu snnqansoufl fiiwS    bauoiigere rEhas ,uhsuUCotteter"

    const-string p1, "USE honor isConfig return false, use huawei as substitute"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance p1, Lcom/tencent/android/tpush/d/a/c;

    const/4 v5, 0x1

    invoke-direct {p1}, Lcom/tencent/android/tpush/d/a/c;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto/16 :goto_0

    :cond_8
    move-object v0, v1

    move-object v0, v1

    move-object v0, v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    goto :goto_4

    :cond_9
    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string p1, "UwsS iheaE"

    const-string p1, "UShiEeapw "

    const/4 v5, 0x2

    const-string p1, "USE huawei"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance p1, Lcom/tencent/android/tpush/d/a/c;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {p1}, Lcom/tencent/android/tpush/d/a/c;-><init>()V

    const/4 v4, 0x5

    and-int/2addr v5, v4

    goto/16 :goto_0

    :cond_a
    :goto_3
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string p1, "iEmma oqix"

    const-string p1, "i mixUaoqE"

    const-string p1, "USE xiaomi"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    move v5, v4

    new-instance p1, Lcom/tencent/android/tpush/d/a/e;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {p1}, Lcom/tencent/android/tpush/d/a/e;-><init>()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto/16 :goto_0

    :catchall_0
    :goto_4
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-object v0
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    sput-object p1, Lcom/tencent/android/tpush/d/d;->b:Ljava/lang/String;

    const/4 v0, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    sput-object p1, Lcom/tencent/android/tpush/d/d;->c:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public static d(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    sput-object p1, Lcom/tencent/android/tpush/d/d;->d:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public static e(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    sput-object p1, Lcom/tencent/android/tpush/d/d;->e:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static f(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    sput-object p1, Lcom/tencent/android/tpush/d/d;->f:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public static j()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v2, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-object v0
.end method


# virtual methods
.method public a()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->d(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    return v0

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    return v0
.end method

.method public b()Z
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Lcom/tencent/android/tpush/d/c;->e(Landroid/content/Context;)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/16 v2, 0x8

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-ne v0, v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const-string/jumbo v0, "rhgeoartaesPsuhM"

    const-string v0, "MesgurhOsaetaPrh"

    const/4 v4, 0x1

    const-string v0, "aOePubhnsgthreaM"

    const-string v0, "OtherPushManager"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string v2, "Usei!XuDSyesecm"

    const-string/jumbo v2, "yXUmesvise!cSDe"

    const/4 v4, 0x5

    const-string v2, "geXsiSUpeyDc!se"

    const-string v2, "UseXgSysDevice!"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    return v1
.end method

.method public c()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->d(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->a(Landroid/content/Context;)V

    :cond_0
    const/4 v3, 0x4

    return-void
.end method

.method public d()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->d(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v0, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->a(Landroid/content/Context;)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method public e()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->d(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v2, 0x1

    xor-int/2addr v3, v2

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->b(Landroid/content/Context;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method public f()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->d(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object v0
.end method

.method public g()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->d(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->f(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public h()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->d(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-object v0

    :cond_0
    const/4 v2, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method public i()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->d(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x0

    move v2, v0

    move v2, v0

    const/4 v3, 0x2

    return-object v0
.end method

.method public k()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-virtual {v0}, Lcom/tencent/android/tpush/d/c;->a()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-object v0
.end method

.method public l()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->m:Ljava/lang/Boolean;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->d(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/d/d;->m:Ljava/lang/Boolean;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->m:Ljava/lang/Boolean;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    return v0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x0

    return v0
.end method

.method public m()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpush/d/d;->n()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/d/d;->o()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x5

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x1

    const/4 v0, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x1

    :goto_1
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0
.end method

.method public n()Z
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->o:Ljava/lang/Boolean;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->d(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/d/d;->o:Ljava/lang/Boolean;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->o:Ljava/lang/Boolean;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    return v0

    :catchall_0
    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    return v0
.end method

.method public o()Z
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->n:Ljava/lang/Boolean;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/c;->d(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x2

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/d/d;->n:Ljava/lang/Boolean;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->n:Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    return v0

    :catchall_0
    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    return v0
.end method

.method public p()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/d/d;->o:Ljava/lang/Boolean;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/d/d;->n:Ljava/lang/Boolean;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public q()V
    .locals 5

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/d/d;->i()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpush/d/d;->h()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    const/4 v2, 0x1

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    move v0, v2

    move v0, v2

    const/4 v4, 0x1

    move v0, v2

    move v0, v2

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    goto :goto_0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    xor-int/2addr v1, v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/d/d;->p:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushConfig;->isUseFcmFirst(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    sget-object v0, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    const/4 v4, 0x5

    sput-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    goto :goto_1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget-object v0, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v3, 0x2

    const/4 v4, 0x6

    sput-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v4, 0x2

    goto :goto_1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v0, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    sget-object v0, Lcom/tencent/android/tpush/d/d;->l:Lcom/tencent/android/tpush/d/c;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    sput-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_1

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v1, :cond_4

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    sget-object v0, Lcom/tencent/android/tpush/d/d;->k:Lcom/tencent/android/tpush/d/c;

    const/4 v4, 0x2

    sput-object v0, Lcom/tencent/android/tpush/d/d;->j:Lcom/tencent/android/tpush/d/c;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_1

    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v0, "hoanurOgqMstrPea"

    const-string v0, "aMstorhareuegOnP"

    const-string v0, "gssharanMeuOhtPe"

    const-string v0, "OtherPushManager"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string v1, "h/omvletan bted dk/ivan"

    const-string v1, "/ hk bnod/denvaivla tet"

    const/4 v4, 0x6

    const-string/jumbo v1, "ke aoan  /tndh/ldviotvo"

    const-string v1, "don\'t have valid token"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :goto_1
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method
