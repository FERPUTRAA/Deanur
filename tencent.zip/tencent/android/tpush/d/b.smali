.class public Lcom/tencent/android/tpush/d/b;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20160810"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->RECEIVERCHECK:Lcom/jg/EType;,
        .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;
    }
.end annotation


# direct methods
.method public static a(Landroid/content/Context;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s @~~t md@b~~1uvSo@~i@lo@b@f@n@alc~r~t~@ o i @@ .@@@K f~ 4~~ ~~~~o/~ @ @@~~-M@ ~o@/o  y@  bi s"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string p0, "hishOCrueettlsn"

    const/4 v3, 0x6

    const-string/jumbo p0, "stemiPhehlOrtnu"

    const-string p0, "OtherPushClient"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v0, "oel o tttreulukaoex:do cnr snnpiET"

    const-string/jumbo v0, "tdlmtiotl:e eTep usanEuro rcxnk no"

    const/4 v3, 0x2

    const-string v0, "eteoub :ndtoin tEoerarclkTx ru spn"

    const-string/jumbo v0, "updateToken Error: context is null"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void

    :cond_0
    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    move v3, v2

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpush/d/d;->m()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v1, Lcom/tencent/android/tpush/d/b$1;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/d/b$1;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void
.end method

.method static synthetic b(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/d/b;->c(Landroid/content/Context;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method private static c(Landroid/content/Context;)V
    .locals 14

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "OerhsouuCnPthel"

    const-string/jumbo v2, "uOehoenlthrCisP"

    const-string/jumbo v2, "nhthuetpOrePslC"

    const-string v2, "OtherPushClient"

    if-nez v1, :cond_0

    const-string p0, "eoTetedaqrdkesn Ng bTon iSua:po ePhetrnkts"

    const-string p0, "gsdirbeepu Ton:naerTPnhNtkto sSdetoea Tke "

    const-string/jumbo p0, "nosdsretnpaeNSekTteeerP tio h osud :agn kT"

    const-string/jumbo p0, "updateToken: TPNS Token has not registered"

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_0
    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v3

    invoke-virtual {v3}, Lcom/tencent/android/tpush/d/d;->q()V

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v3

    invoke-virtual {v3}, Lcom/tencent/android/tpush/d/d;->k()Ljava/lang/String;

    move-result-object v3

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v4

    invoke-virtual {v4}, Lcom/tencent/android/tpush/d/d;->f()Ljava/lang/String;

    move-result-object v4

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v5

    invoke-virtual {v5}, Lcom/tencent/android/tpush/d/d;->g()Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "oh mtdnutTkp eoeeas hk lepr eadu :hUnnst"

    const-string v7, "ahestpukp ntedhesUl nt h:oT ednuoo ke ar"

    const-string v7, "dpteoh loopnsate noUsehhe trdenT ui  kka"

    const-string v7, "handleUpdateToken other push token is : "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v7, "yp ptb :eusp  eort"

    const-string/jumbo v7, "yt ro  ps:pepu eth"

    const-string v7, "ho hepu: ysuet p t"

    const-string v7, " other push type: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v7, "rq es op het:ipghu n"

    const-string v7, "i: hnrepq turgs o he"

    const-string v7, "  hir:opqn e rsthuoe"

    const-string v7, " other push region: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v2, v6}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v3}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v6

    if-nez v6, :cond_4

    invoke-static {v4}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_1

    goto/16 :goto_1

    :cond_1
    :try_start_0
    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v6

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/tencent/android/tpush/e/b/a;->a(Ljava/lang/String;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v9

    invoke-static {p0, v9}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object v9

    check-cast v9, Ljava/lang/String;

    invoke-static {v9}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v10

    if-nez v10, :cond_3

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v10, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v10, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-static {v10}, Lcom/tencent/android/tpush/e/b/a;->b(Ljava/lang/String;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v10

    invoke-static {p0, v10}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object v10

    check-cast v10, Ljava/lang/Long;

    invoke-virtual {v10}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v13, ":"

    const-string v13, ":"

    const-string v13, ":"

    const-string v13, ":"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v9, v12}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v9

    if-eqz v9, :cond_2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v12

    sub-long/2addr v12, v10

    invoke-static {v12, v13}, Ljava/lang/Math;->abs(J)J

    move-result-wide v9

    const-wide/32 v11, 0x5265c00

    const-wide/32 v11, 0x5265c00

    cmp-long v9, v9, v11

    if-gez v9, :cond_2

    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v0, "thsAOoha dyue ect leIhisd=se sca wnrstdsin ekuerPcb d"

    const-string v0, "dcsroiuOhtuedAtsiwsIchns narceebtPlhy eka  ee d=sd  c"

    const-string v0, " ilmast eethcckPsn csI iobh=e ut  wdsrhedOduecdn Area"

    const-string v0, "Already bind OtherPush succeed token with accessId = "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo v0, "ok =ome   "

    const-string v0, "=nkm o   e"

    const-string/jumbo v0, "nkt eb o  "

    const-string v0, "  token = "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, " orPe u otshphey="

    const-string v0, "= s oP eeurthhopy"

    const-string/jumbo v0, "reoTtp pyh hus eP"

    const-string v0, " otherPushType = "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v0, "=nT ksoPqeou tbher"

    const-string v0, " no=TbsP oekeruh t"

    const-string v0, "eesso hu=nPtT  ork"

    const-string v0, " otherPushToken = "

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_2
    const-string/jumbo v9, "odrmetoi MoTdnhnokae uhnr en giObc ,  "

    const-string v9, "T  nctugkni  Mndhbah, nodOro rdooeeei "

    const-string v9, "  inoT,hedrhn n aOgobgeo  oe idkndctrM"

    const-string v9, "OtherToken or Mid changed , go on bind"

    invoke-static {v2, v9}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    new-instance v9, Lcom/tencent/android/tpush/d/b$2;

    invoke-direct {v9, v6, v7, v1, v4}, Lcom/tencent/android/tpush/d/b$2;-><init>(JLjava/lang/String;Ljava/lang/String;)V

    new-instance v10, Landroid/content/IntentFilter;

    const-string v11, "AdVtebni.LpORiTdp.No...Hc.EOiE.EtPUvTRtaUxDaeo.mE.nrTScgnocTnK"

    const-string v11, "LoEmgiSpcd.cTiUan.PTT.Rc.notOENVH4dxe.ta.EDiovrptE.An.ROUn.eKT"

    const-string v11, "com.tencent.android.xg.vip.action.UPDATE.OTHER.TOKEN.RESULT.V4"

    invoke-direct {v10, v11}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x4

    invoke-static {p0, v9, v10, v11}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V

    new-instance v9, Landroid/content/Intent;

    new-instance v10, Ljava/lang/StringBuilder;

    invoke-direct {v10}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v11, "nae.KtuNT_cnRmagOoPO.diE_tdevUcPxcoViptSE.n4TDEn..H.TqAUH_.i"

    const-string v11, "EdpEnoEHqogcS.cOvxadTAPPiait_ceN4.n.Uenot.Hm._TTtOK_V.R.UDni"

    const-string v11, "croo..4pdUN_UEDic.RA_..vnnHt_eETPapVoiOxKginamPed.tHSnctET.T"

    const-string v11, "com.tencent.android.xg.vip.action.UPDATE_OTHER_PUSH_TOKEN.V4"

    invoke-virtual {v10, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v10}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v10

    invoke-direct {v9, v10}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v10, "ascqI"

    const-string v10, "casIc"

    const-string v10, "accId"

    new-instance v11, Ljava/lang/StringBuilder;

    invoke-direct {v11}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v11, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v9, v10, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v6, "cysmce"

    const-string v6, "cyemac"

    const-string v6, "cKamyc"

    const-string v6, "accKey"

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v9, v6, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v0, "tknoo"

    const-string/jumbo v0, "ntkeo"

    const-string v0, "bknot"

    const-string/jumbo v0, "token"

    invoke-static {v1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v0, "ptuhteu_yprhbe_"

    const-string/jumbo v0, "ouytpbre_thp_eh"

    const-string/jumbo v0, "u_horetpyesppth"

    const-string/jumbo v0, "other_push_type"

    invoke-static {v3}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v0, "pketu_onqhseo_hr"

    const-string/jumbo v0, "other_push_token"

    invoke-static {v4}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v0, "oosneguthp_ru_ish"

    const-string/jumbo v0, "tghoerupinorsh__u"

    const-string/jumbo v0, "oupm_rgeohhrits_n"

    const-string/jumbo v0, "other_push_region"

    invoke-static {v5}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-static {p0, v9}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p0

    const-string v0, "eDEaor BeHKORTPENirUaoSco snAda_nToPCprtctO_sUT_OAN_rITHd"

    const-string v0, "aTUoErepI_tAeBRrOcTaPrHooU rPntN_TCOsKO_S D_ANEHndi Tadcs"

    const-string/jumbo v0, "rraHHb AOPtSd_rIUU_nNDOCo TTTTReo_AsaKtNPiE cercoEEBOnds_"

    const-string/jumbo v0, "sendBroadcast action ACTION_UPDATE_OTHER_PUSH_TOKEN error"

    invoke-static {v2, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    return-void

    :cond_4
    :goto_1
    const-string p0, "erhr  uapkouutrpe uoEo rTTtnnktesesT nlgqhdtoruorPhsPee il:eoh"

    const-string p0, "Pkkpll  qToounP ooduea nteontesTtirpshTthgheeeh eorsuEr :r rur"

    const-string p0, "ho gEeTpnpoaTrleophuPnti one h uPrsToe:krtk eursryter ldo tues"

    const-string/jumbo p0, "updateToken Error: get otherPushType or otherPushToken is null"

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method
