.class public Lcom/tencent/android/tpush/d/a/d;
.super Lcom/tencent/android/tpush/d/c;


# static fields
.field private static c:J


# instance fields
.field a:Ljava/lang/String;

.field b:Ljava/lang/StringBuffer;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/c;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method private a(Ljava/lang/String;)V
    .locals 8

    :try_start_0
    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "~@sc@~mSuab ~ -i1fKl t~~~ ~fo@v 4@n@b   i@o@~~@ @  @~   /.  @~@@o@ @~o~ioM~~~@~l@str~y@/o~~@~@~d"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-eqz v0, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    sget-wide v2, Lcom/tencent/android/tpush/d/a/d;->c:J

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    sub-long v2, v0, v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-wide/16 v4, 0x1388

    const-wide/16 v4, 0x1388

    const/4 v7, 0x2

    const-wide/16 v4, 0x1388

    const-wide/16 v4, 0x1388

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    cmp-long v2, v2, v4

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-lez v2, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    sput-wide v0, Lcom/tencent/android/tpush/d/a/d;->c:J

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string v1, "iC.m.cc.FmdnApBEae.KEtxsncenn..tgortivdioa"

    const-string v1, "cEsnxot..Fm.d.trepB.naniCanKc.DdoiteEAvigc"

    const/4 v7, 0x2

    const-string v1, "cC.iopgKmtB.taAoEei.xdnF.otdonEnriDvncc.ea"

    const-string v1, "com.tencent.android.xg.vip.action.FEEDBACK"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string v1, "EOmHPbRDROTEUC."

    const-string v1, "ROEmHRC.PDTEURO"

    const/4 v7, 0x7

    const-string v1, "EH.CUOuSDRRPROT"

    const-string v1, "TPUSH.ERRORCODE"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz p1, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/16 v2, 0xc8

    const/4 v7, 0x3

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 v2, -0x1

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v1, "trnuo_hepehk_oto"

    const/4 v7, 0x1

    const-string/jumbo v1, "snor_uhpeto_ehtk"

    const-string/jumbo v1, "other_push_token"

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string p1, "ADS.EHBPqUbKTE"

    const-string p1, ".PKAUbEHDBEFST"

    const/4 v7, 0x0

    const-string p1, "ATsHFBSKU.EDEP"

    const-string p1, "TPUSH.FEEDBACK"

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    const/4 v1, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v6, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string p1, "SLEm.UuNHNPH"

    const-string p1, ".HNENHuPSLUC"

    const/4 v7, 0x2

    const-string p1, "PUSH.CHANNEL"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/16 v2, 0x6a

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x7

    const-string/jumbo p1, "pPYHoHUUPH..OSTNKOREKTEE"

    const-string p1, "OESUPPEpO.UYTSHREKH.TNHK"

    const/4 v7, 0x1

    const-string p1, "TUPREbEK.HNTHUSP.THKESOO"

    const-string p1, "TPUSH.OTHERPUSH.TOKENKEY"

    const/4 v7, 0x2

    const/4 v6, 0x0

    const-string v2, "enzoekimqt_"

    const/4 v7, 0x6

    const-string v2, "e_koetuniuz"

    const-string/jumbo v2, "meizu_token"

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string p1, ".HTT.EApDUOsN.TUKNPESP"

    const-string p1, "UHsDE..TTAONNPKETU.SOP"

    const-string p1, ".UUOT.TTqKNAHNT.SEPDOE"

    const-string p1, "TPUSH.NOT.UPDATE.TOKEN"

    const/4 v6, 0x4

    move v7, v6

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->onOtherPushRegister(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    return-void
.end method

.method private g(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/d;->a:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v0, "etsmuznikem"

    const-string v0, "i_umtnmekez"

    const/4 v3, 0x0

    const-string/jumbo v0, "neemut_kmoi"

    const-string/jumbo v0, "meizu_token"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/d;->a:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/d;->a:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p1
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string/jumbo v0, "mozuo"

    const-string/jumbo v0, "umzeo"

    const-string v0, "beziu"

    const-string/jumbo v0, "meizu"

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public a(Landroid/content/Context;)V
    .locals 12

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-string v1, "_behr_urstoeoedpruoch"

    const-string v1, "huo_pboe_hrcsoertr_ed"

    const/4 v11, 0x6

    const-string v1, "_chuto_pree_sreohrpro"

    const-string/jumbo v1, "other_push_error_code"

    const/4 v11, 0x6

    const/4 v10, 0x1

    sget-object v2, Lcom/tencent/android/tpush/d/d;->c:Ljava/lang/String;

    const/4 v11, 0x6

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    const-string v3, "emuPlMhhqrItupZ"

    const-string/jumbo v3, "lethhuuOmPZpMIr"

    const/4 v11, 0x6

    const-string v3, "elsmhMhrtusOIPp"

    const-string v3, "OtherPushMZImpl"

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    if-eqz v2, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-string/jumbo p1, "rsrmt rPl zppEh ldnispguri uo freerm"

    const-string/jumbo p1, "igsuE rpftmo  prrl nrrePlh eoupsdizr"

    const/4 v11, 0x1

    const-string/jumbo p1, "l srorng reEflzoPrp tirai phudro mus"

    const-string/jumbo p1, "registerPush Error for mz null appid"

    const/4 v11, 0x0

    const/4 v10, 0x1

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    return-void

    :cond_0
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    sget-object v2, Lcom/tencent/android/tpush/d/d;->d:Ljava/lang/String;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x0

    if-eqz v2, :cond_1

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    const-string/jumbo p1, "u ePmrulqpgr p ofrnrskesehyizr zot lArE"

    const/4 v11, 0x0

    const-string/jumbo p1, "l erEbrukztrAg r mhyonf erlsem sporzupP"

    const-string/jumbo p1, "registerPush Error for mz null mzAppkey"

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    return-void

    :cond_1
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x6

    new-instance v2, Ljava/lang/StringBuffer;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/d;->b:Ljava/lang/StringBuffer;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/base/util/Util;->isMainProcess(Landroid/content/Context;)Z

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    if-eqz v2, :cond_2

    const/4 v11, 0x6

    const/4 v10, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-string v4, " !rezburutgsenspise Mh"

    const-string/jumbo v4, "risee ir uzh!tnpebgssM"

    const/4 v11, 0x2

    const-string v4, "gihzbenpug etsMrisr pe"

    const-string v4, "begin Mzpush register!"

    const/4 v11, 0x2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    sget-object v4, Lcom/tencent/android/tpush/d/d;->c:Ljava/lang/String;

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-string v4, " "

    const-string v4, " "

    const/4 v11, 0x0

    const-string v4, " "

    const-string v4, " "

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    sget-object v4, Lcom/tencent/android/tpush/d/d;->d:Ljava/lang/String;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v11, 0x6

    const-string v2, "edsdmzpsqaPhuriem.suc.gumhkaMonuco."

    const-string v2, "..Mmusiekrcco.dehausgsmhnm.dzuuoPpa"

    const/4 v11, 0x1

    const-string v2, "ehs.onkao.umu.sPMuiermddpzc.hlcussa"

    const-string v2, "com.meizu.cloud.pushsdk.PushManager"

    const/4 v11, 0x1

    const/4 v10, 0x5

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-string/jumbo v4, "rremitge"

    const-string/jumbo v4, "register"

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    const/4 v5, 0x3

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    new-array v6, v5, [Ljava/lang/Class;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x5

    const-class v7, Landroid/content/Context;

    const-class v7, Landroid/content/Context;

    const/4 v11, 0x3

    const-class v7, Landroid/content/Context;

    const-class v7, Landroid/content/Context;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v8, 0x0

    or-int/2addr v11, v8

    const/4 v10, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x7

    aput-object v7, v6, v8

    const/4 v11, 0x6

    const/4 v7, 0x1

    const/4 v11, 0x0

    move v10, v7

    move v10, v7

    const/4 v11, 0x7

    aput-object v0, v6, v7

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    const/4 v9, 0x2

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    aput-object v0, v6, v9

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v2, v4, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    new-array v4, v5, [Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    aput-object p1, v4, v8

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x4

    sget-object v5, Lcom/tencent/android/tpush/d/d;->c:Ljava/lang/String;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    aput-object v5, v4, v7

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    sget-object v5, Lcom/tencent/android/tpush/d/d;->d:Ljava/lang/String;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    aput-object v5, v4, v9

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v0, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    const-string/jumbo v0, "spe ouncea s eihccnuceos ztuahsm"

    const-string/jumbo v0, "zcc osrau puhesnsahsit  ncueceme"

    const/4 v11, 0x5

    const-string/jumbo v0, "ipsnlbcc re sha eu azstecuncehmu"

    const-string v0, "creat meizu push channle success"

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-string/jumbo v2, "srrisruPrgoEteubuemrh e z"

    const-string/jumbo v2, "toEesbiguPrez mrrruhse r "

    const/4 v11, 0x6

    const-string v2, "i u mirprPEeoergzsteursr "

    const-string/jumbo v2, "meizu registerPush Error "

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-static {v3, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/d;->b:Ljava/lang/StringBuffer;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x4

    const-string v4, "6 re:ordqr1s 1:r geM C -ue"

    const-string/jumbo v4, "rd6 -eu re  1:Me,gsr1r C:o"

    const/4 v11, 0x5

    const-string/jumbo v4, "rMsg6d:1 C:e1,r- e esro  r"

    const-string v4, "errCode : -161 , errMsg : "

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    goto/16 :goto_0

    :catch_0
    move-exception v0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    xor-int/2addr v11, v10

    const-string/jumbo v5, "orinxizp gfa oee noPctmronertTE hceristvpr:rEstIueiurog "

    const-string/jumbo v5, "reEmfaasroptnoTriinu gucnimPcoxhg i r EezreroIe:trsvt et"

    const-string/jumbo v5, "meizu registerPush Error for InvocationTargetException: "

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x0

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x2

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/d;->b:Ljava/lang/StringBuffer;

    const/4 v11, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    const-string v4, "  ero,:s0e M :o1 g- rdreC6"

    const-string v4, "  - 0: :qrCeed61r ,s Mgroe"

    const/4 v11, 0x2

    const-string v4, " 0 -eb6C:r :ese ,gd1rr r o"

    const-string v4, "errCode : -160 , errMsg : "

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v11, 0x3

    return-void
.end method

.method public b(Landroid/content/Context;)V
    .locals 12

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const-string/jumbo v1, "rcetsour_esdrrop_h_oh"

    const-string/jumbo v1, "orso_ehrprehsrctd_e_o"

    const/4 v11, 0x7

    const-string/jumbo v1, "uprchrhpotreeoo__er_s"

    const-string/jumbo v1, "other_push_error_code"

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x5

    const-string/jumbo v2, "meMurpPhqItmlsh"

    const-string v2, "hPsmItMprlmheuZ"

    const/4 v11, 0x3

    const-string/jumbo v2, "lMstheIPZpOurmh"

    const-string v2, "OtherPushMZImpl"

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/d/a/d;->b:Ljava/lang/StringBuffer;

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-nez v3, :cond_0

    const/4 v11, 0x3

    new-instance v3, Ljava/lang/StringBuffer;

    const/4 v11, 0x2

    const/4 v10, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    iput-object v3, p0, Lcom/tencent/android/tpush/d/a/d;->b:Ljava/lang/StringBuffer;

    :cond_0
    :try_start_0
    const/4 v11, 0x1

    const-string/jumbo v3, "noum.cl.zodiuemrhosa..gcsdsuemuhPak"

    const-string/jumbo v3, "uuueo.gohasko.ic.mpznmrchld.useasPd"

    const/4 v11, 0x4

    const-string/jumbo v3, "skohosuonieuaauhd.plmsMgzucd.r.P.cm"

    const-string v3, "com.meizu.cloud.pushsdk.PushManager"

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string v4, "eRstibuebn"

    const-string v4, "erustbneiR"

    const/4 v11, 0x5

    const-string/jumbo v4, "unRegister"

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    const/4 v5, 0x3

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x6

    new-array v6, v5, [Ljava/lang/Class;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-class v7, Landroid/content/Context;

    const-class v7, Landroid/content/Context;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    const/4 v8, 0x0

    const/4 v10, 0x4

    move v11, v10

    aput-object v7, v6, v8

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x7

    const/4 v7, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x4

    aput-object v0, v6, v7

    const/4 v11, 0x6

    const/4 v9, 0x2

    const/4 v11, 0x7

    shl-int/2addr v10, v9

    const/4 v11, 0x5

    aput-object v0, v6, v9

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {v3, v4, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-string v6, "Mbnztgueg i n!uehuusreri"

    const-string v6, "ee  ugu!szbsurinrMhinegt"

    const/4 v11, 0x5

    const-string/jumbo v6, "nutMp  pugbsheneierris!g"

    const-string v6, "begin Mzpush unregister!"

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    sget-object v6, Lcom/tencent/android/tpush/d/d;->c:Ljava/lang/String;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-string v6, " "

    const-string v6, " "

    const/4 v11, 0x2

    const-string v6, " "

    const-string v6, " "

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    sget-object v6, Lcom/tencent/android/tpush/d/d;->d:Ljava/lang/String;

    const/4 v11, 0x7

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-static {v2, v4}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x0

    new-array v4, v5, [Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x1

    aput-object p1, v4, v8

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    sget-object v5, Lcom/tencent/android/tpush/d/d;->c:Ljava/lang/String;

    const/4 v11, 0x3

    aput-object v5, v4, v7

    const/4 v11, 0x0

    const/4 v10, 0x1

    sget-object v5, Lcom/tencent/android/tpush/d/d;->d:Ljava/lang/String;

    const/4 v11, 0x2

    aput-object v5, v4, v9

    const/4 v11, 0x0

    const/4 v10, 0x7

    invoke-virtual {v0, v3, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x2

    const-string/jumbo v0, "urcescepqPt gunnpmrncleeesshs ihhsuai uus"

    const-string/jumbo v0, "uumaircphhesug hunepncnuset rsc  sssPeeli"

    const/4 v11, 0x6

    const-string v0, "hnsupn imaus igec ulrcesesssncreuu Phhezs"

    const-string/jumbo v0, "unregisterPush meizu push channle success"

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x6

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x1

    const-string v4, " orhutooqi uecy mgr u aupPt rie trheszsEn,aemrepaieou prkghrrs"

    const/4 v11, 0x0

    const-string/jumbo v4, "upamsuecetpre nzPauoris eu Eh?r imrur krhy hrpis orot,mggeo ae"

    const-string/jumbo v4, "meizu unregisterPush Error, are you import otherpush package? "

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/d;->b:Ljava/lang/StringBuffer;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    const-string v4, "C:ogoe6s 1   eM-dr s3er:, "

    const-string v4, " gses-d,: M ro e: e361rC r"

    const/4 v11, 0x5

    const-string v4, "errCode : -163 , errMsg : "

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v11, 0x1

    const/4 v10, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    goto/16 :goto_0

    :catch_0
    move-exception v0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v3

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x7

    const-string/jumbo v5, "zxirnbnrPiu ETgE puosnretI:oomosec gureavitfecmari torhr e"

    const-string/jumbo v5, "rirmiuc e vrPxghT :sEoftuztnorieausaoeE tonror eigmcetIpnr"

    const/4 v11, 0x7

    const-string/jumbo v5, "tgoresuPnoIrertxarhTescopivierEu itunzro:E aoie cn  murgfn"

    const-string/jumbo v5, "meizu unregisterPush Error for InvocationTargetException: "

    const/4 v11, 0x5

    const/4 v10, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {v3}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x4

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/d;->b:Ljava/lang/StringBuffer;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    const-string v4, " ersC6 p 1rd ,-:rr2 geM oe"

    const-string v4, "2er1o, r rgMd6 eo s C- e:r"

    const/4 v11, 0x6

    const-string v4, ":6:-ree q2  C 1 Mrr,oerdgs"

    const-string v4, "errCode : -162 , errMsg : "

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    return-void
.end method

.method public c(Landroid/content/Context;)Ljava/lang/String;
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string/jumbo v0, "sor_eberu_edhphtrr_oo"

    const/4 v9, 0x2

    const-string v0, "e_shprsc_erhrdouto_oe"

    const-string/jumbo v0, "other_push_error_code"

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string v1, "hsOmPuIumrlphMt"

    const-string/jumbo v1, "mhsPIhuuptlOeMr"

    const/4 v9, 0x4

    const-string v1, "OmhZoptrsPhlMeI"

    const-string v1, "OtherPushMZImpl"

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/d;->b:Ljava/lang/StringBuffer;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-nez v2, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    new-instance v2, Ljava/lang/StringBuffer;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/d;->b:Ljava/lang/StringBuffer;

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v9, 0x5

    const-string v2, ""

    const-string v2, ""

    :try_start_0
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    const-string v3, ".csP.bospaeMro.duknemhu.dusuicgmlpz"

    const-string/jumbo v3, "l.cdrPnpuuaomgk.mM.ssceua.ezphudois"

    const/4 v9, 0x1

    const-string v3, "azdsesum.anPh.l.kchMpmdogociusuru.e"

    const-string v3, "com.meizu.cloud.pushsdk.PushManager"

    const/4 v9, 0x6

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    const/4 v4, 0x1

    const/4 v9, 0x4

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-class v6, Landroid/content/Context;

    const-class v6, Landroid/content/Context;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    const/4 v7, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    aput-object v6, v5, v7

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string v6, "Pdhgeqspu"

    const-string v6, "hduPtsegq"

    const/4 v9, 0x7

    const-string v6, "eudshItPq"

    const-string v6, "getPushId"

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v3, v6, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    aput-object p1, v4, v7

    const/4 v9, 0x5

    const/4 v8, 0x2

    invoke-virtual {v5, v3, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/d;->g(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-eqz v3, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {v5}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-nez v5, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-nez v5, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    iput-object v4, p0, Lcom/tencent/android/tpush/d/a/d;->a:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-string/jumbo v4, "snsuiemektz"

    const-string v4, "etsknmuioze"

    const/4 v9, 0x5

    const-string v4, "etumznke_mo"

    const-string/jumbo v4, "meizu_token"

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {p1, v4, v5}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/d;->a:Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    goto :goto_0

    :cond_1
    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-eqz v3, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v4}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-nez v4, :cond_2

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-direct {p0, v3}, Lcom/tencent/android/tpush/d/a/d;->a(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    goto/16 :goto_1

    :catchall_0
    move-exception v3

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    const-string/jumbo v4, "rrigoorek  TzmoeEetu"

    const-string v4, "E rmigo eortkeremuzT"

    const-string v4, "Eo rrbiTeeromneg utz"

    const-string/jumbo v4, "meizu getToken Error"

    const/4 v9, 0x0

    invoke-static {v1, v4, v3}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/d;->b:Ljava/lang/StringBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    const-string v5, "eer: ou5reor s,:dr 6 -M 1 "

    const-string v5, ":s -o 6e5erg rd r e:,M1 or"

    const/4 v9, 0x2

    const-string v5, ":rr5o rp e- de sg1,e M :r6"

    const-string v5, "errCode : -165 , errMsg : "

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x7

    invoke-virtual {v3}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    goto/16 :goto_1

    :catch_0
    move-exception v3

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v3}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string/jumbo v6, "tpfvobeei tkzecotoi o oEIrx:ernetuonragagTn iErrTc m"

    const/4 v9, 0x2

    const-string/jumbo v6, "pzInTtieq efkte a cooTrxggeon: oemnittocrruaoErEv nr"

    const-string/jumbo v6, "meizu getToken Error for InvocationTargetException: "

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {v1, v4}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/d;->b:Ljava/lang/StringBuffer;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string v5, "e:so, eus1:r 64rerr - g d "

    const-string v5, " rgr su-e1 d4o :6e r :Cr,e"

    const/4 v9, 0x5

    const-string v5, ":  m- 1dr: eogMerC  e4r,rs"

    const-string v5, "errCode : -164 , errMsg : "

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v3}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x2

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_1
    const/4 v9, 0x0

    return-object v2
.end method

.method public d(Landroid/content/Context;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    sget-object v0, Lcom/tencent/android/tpush/d/d;->c:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/d/d;->d:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    if-eqz v0, :cond_1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;I)V

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/d/d;->c:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-nez v0, :cond_2

    sget-object v0, Lcom/tencent/android/tpush/d/d;->d:Ljava/lang/String;

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    if-eqz v0, :cond_3

    :cond_2
    const/4 v2, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->l(Landroid/content/Context;)V

    :cond_3
    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object p1, Lcom/tencent/android/tpush/d/d;->c:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz p1, :cond_4

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0

    :cond_4
    const/4 v1, 0x6

    move v2, v1

    sget-object p1, Lcom/tencent/android/tpush/d/d;->d:Ljava/lang/String;

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x0

    if-eqz p1, :cond_5

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return v0

    :cond_5
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 p1, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    return p1
.end method

.method public e(Landroid/content/Context;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 p1, 0x2

    and-int/2addr v1, p1

    const/4 v0, 0x5

    move v1, v0

    return p1
.end method

.method public f(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x4

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p1
.end method
