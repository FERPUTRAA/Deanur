.class Lcom/tencent/android/tpush/d/a/b$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/d/a/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/d/a/b;

.field private b:Landroid/content/Context;


# direct methods
.method public constructor <init>(Lcom/tencent/android/tpush/d/a/b;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/b$a;->a:Lcom/tencent/android/tpush/d/a/b;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/tencent/android/tpush/d/a/b$a;->b:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "K~s - @ly@@@ ~@@ So b~o~@ ~~ M~c@tb1f b@iiv@d/i~~oo~f~@r~@~ ~u t @m@  @l~~~@so4 @~~a~~~ .@o@/ n "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    if-nez p2, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 p1, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    return-object p1

    :cond_0
    const/4 v6, 0x7

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v0, "encmsocsu"

    const-string/jumbo v0, "snsouecsc"

    const/4 v6, 0x2

    const-string/jumbo v0, "sscoocnuS"

    const-string/jumbo v0, "onSuccess"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string/jumbo v0, "ortehbrup__d_heesrocm"

    const-string v0, "hsomroe_deotcupe_r_rh"

    const/4 v6, 0x3

    const-string/jumbo v0, "rrecseuhtphr_eruodoo_"

    const-string/jumbo v0, "other_push_error_code"

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string/jumbo v3, "pohrmtspPOuhIonoer"

    const-string/jumbo v3, "ltoPornrIoOhumpesh"

    const/4 v6, 0x0

    const-string/jumbo v3, "semoprtlqhHurIPnhO"

    const-string v3, "OtherPushHonorImpl"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz p1, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz p3, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    array-length p1, p3

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-lt p1, v2, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    aget-object p1, p3, v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    check-cast p1, Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p3

    const/4 v6, 0x6

    const/4 v5, 0x5

    if-nez p3, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    move v6, v5

    const-string v0, "cPsnnes:ro,set eogbshkess uuc rioRt"

    const-string/jumbo v0, "iss ubsr tg hsRcn,e :krctoeosoPeune"

    const/4 v6, 0x5

    const-string v0, "gntmnc scou sHet:oskesrruisRoPh , e"

    const-string v0, "HonorPush Register success, token: "

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v3, p3}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-nez p3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/b$a;->a:Lcom/tencent/android/tpush/d/a/b;

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/b$a;->b:Landroid/content/Context;

    const/4 v6, 0x1

    invoke-virtual {p3, v0}, Lcom/tencent/android/tpush/d/a/b;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1, p3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-nez p3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/b$a;->a:Lcom/tencent/android/tpush/d/a/b;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {p3, p1}, Lcom/tencent/android/tpush/d/a/b;->a(Lcom/tencent/android/tpush/d/a/b;Ljava/lang/String;)Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/b$a;->b:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/b$a;->a:Lcom/tencent/android/tpush/d/a/b;

    const/4 v5, 0x0

    or-int/2addr v6, v5

    invoke-static {v0}, Lcom/tencent/android/tpush/d/a/b;->a(Lcom/tencent/android/tpush/d/a/b;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string v1, "enokorouhn_"

    const-string/jumbo v1, "nketrounoh_"

    const/4 v6, 0x7

    const-string/jumbo v1, "nroknb_etoh"

    const-string v1, "honor_token"

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-static {p3, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/b$a;->a:Lcom/tencent/android/tpush/d/a/b;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {p3, p1}, Lcom/tencent/android/tpush/d/a/b;->b(Lcom/tencent/android/tpush/d/a/b;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string p1, " s:cCcep sesMe:r,s rerruog0"

    const/4 v6, 0x7

    const-string p1, "cM:se0u resdoeuCssgr e c,rr"

    const-string p1, "errCode: 0, errMsg: success"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/b$a;->b:Landroid/content/Context;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p3, v3, p1}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string p1, "finteiseq gkPhRnredlermo eyatHosuto , "

    const-string p1, "finteiseq gkPhRnredlermo eyatHosuto , "

    const/4 v6, 0x4

    const-string/jumbo p1, "tpeyeerptgotfusehR oa isliromHP, n dek"

    const-string p1, "HonorPush Register failed, empty token"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/b$a;->b:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string p3, "hf :ssreq  tRgr Mi,elaosnrtdrypongkm eP tesHeio"

    const-string p3, " tseo:arinMglRyP ne,ro rgH ssmoeks etdtei rhpfe"

    const/4 v6, 0x2

    const-string/jumbo p3, "tfse  yPeon:,ernsRadmpett Mgiguseh eil r krosro"

    const-string p3, "HonorPush Register failed, errMsg : empty token"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {p1, v0, p3}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string v4, "enimrmlou"

    const-string/jumbo v4, "reimlunoF"

    const/4 v6, 0x6

    const-string/jumbo v4, "iulFooean"

    const-string/jumbo v4, "onFailure"

    const/4 v6, 0x7

    invoke-virtual {p1, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz p1, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz p3, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    array-length p1, p3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v4, 0x2

    const/4 v6, 0x4

    const/4 v5, 0x1

    if-lt p1, v4, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    aget-object p1, p3, v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    check-cast p1, Ljava/lang/Integer;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    aget-object p3, p3, v2

    const/4 v5, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    check-cast p3, Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v2, "  hCob:dHr eaRfedtue,or rnligeisoesr"

    const-string v2, "HonorPush Register failed, errCode: "

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string v2, "ee:M ,uorr"

    const-string v2, "Mg,eorr: e"

    const/4 v6, 0x2

    const-string v2, "M rgr:,pee"

    const-string v2, ", errMeg: "

    const/4 v6, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-static {v3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/b$a;->b:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v4, " rdrbC:oq"

    const-string v4, "Cerrdbo: "

    const/4 v6, 0x1

    const-string v4, "d s:eerro"

    const-string v4, "errCode: "

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    xor-int/2addr v6, v5

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v3, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    shl-int/2addr v6, v5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v1, v0, p1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    return-object p2
.end method
