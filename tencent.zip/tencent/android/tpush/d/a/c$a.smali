.class public Lcom/tencent/android/tpush/d/a/c$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/d/a/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/d/a/c;


# direct methods
.method public constructor <init>(Lcom/tencent/android/tpush/d/a/c;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/c$a;->a:Lcom/tencent/android/tpush/d/a/c;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " os~r@c4@@~ ~ ~vo @~@@~M~@ ~i ~@~ yo@ S~@~  b1o~/s.~i @-lb~i @nt@ @o  a @umd@lK@~~@~b/f~ t@~~~f@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo p1, "tu_msoreehrhoep_drcso"

    const-string p1, "hcsrrdt_prerhseuooeo_"

    const/4 v6, 0x5

    const-string p1, "eopso_or_reorehu_trdc"

    const-string/jumbo p1, "other_push_error_code"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    const/4 v0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-nez p2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-object v0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string v2, ":vemmbk o,enthi"

    const-string/jumbo v2, "mivm,tehok:de n"

    const/4 v6, 0x2

    const-string/jumbo v2, "ok em:uh,oinvdt"

    const-string/jumbo v2, "invoke, method:"

    const/4 v6, 0x2

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string v2, "hepHItWpiOmPureoaul"

    const-string/jumbo v2, "mOpPohulueirWIhHtea"

    const/4 v6, 0x5

    const-string v2, "WhauPulHqOemrsIhpte"

    const-string v2, "OtherPushHuaWeiImpl"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string/jumbo v3, "nosctCenb"

    const-string/jumbo v3, "nncCnbteo"

    const/4 v6, 0x6

    const-string v3, "Cnomnotcn"

    const-string/jumbo v3, "onConnect"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x5

    if-eqz v1, :cond_2

    const/4 v6, 0x7

    if-eqz p3, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    array-length p2, p3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-lez p2, :cond_3

    :try_start_1
    const/4 v6, 0x7

    aget-object p2, p3, v3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    check-cast p2, Ljava/lang/Integer;

    const/4 v6, 0x0

    const/4 v5, 0x1

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string/jumbo v1, "o piontsae wder hcoh:etu nuuoecnC"

    const-string v1, "Csw enu htthui:paeur eocdnn ceooh"

    const/4 v6, 0x4

    const-string v1, "hn i bocuop:toes hCute oceaerhdwn"

    const-string/jumbo v1, "other push huawei onConnect code:"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    move v6, v5

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v2, p3}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I

    move-result p3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-nez p3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    iget-object p2, p0, Lcom/tencent/android/tpush/d/a/c$a;->a:Lcom/tencent/android/tpush/d/a/c;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p2}, Lcom/tencent/android/tpush/d/a/c;->b()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/c$a;->a:Lcom/tencent/android/tpush/d/a/c;

    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v1, p3, Lcom/tencent/android/tpush/d/a/c;->a:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x6

    iget-object p3, p3, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string v4, " r:reduC e"

    const-string v4, "errCode : "

    const/4 v6, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string/jumbo p2, "u nkw np g r:p,Mersn"

    const-string/jumbo p2, "nsnrwneproMk:g  ,u  "

    const/4 v6, 0x7

    const-string p2, " e, o wnqMrkg n nrus"

    const-string p2, " ,  errMsg : unkonwn"

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p3, p2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v1, p1, p2}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto/16 :goto_0

    :catchall_0
    move-exception p2

    :try_start_2
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/c$a;->a:Lcom/tencent/android/tpush/d/a/c;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v1, p3, Lcom/tencent/android/tpush/d/a/c;->a:Landroid/content/Context;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget-object p3, p3, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string v4, " rs:qg r4, eeCMor re-12:s"

    const-string v4, "er rs ogq12Mrr  e4, ::C-e"

    const/4 v6, 0x4

    const-string/jumbo v4, "r dm,Mee41:  esrroC2r:  g"

    const-string v4, "errCode : -124 , errMsg :"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p2}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p3, p2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v1, p1, p2}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v1, "Rusnotse"

    const-string/jumbo v1, "uRstesln"

    const/4 v6, 0x1

    const-string v1, "Rnostbel"

    const-string/jumbo v1, "onResult"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz p2, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x1

    if-eqz p3, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    array-length p2, p3
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-lez p2, :cond_3

    :try_start_3
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    aget-object p2, p3, v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    check-cast p2, Ljava/lang/Integer;

    const/4 v5, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    or-int/2addr v6, v5

    const-string v1, "e:nchduRtmtwsuso ih eheo lupaeor"

    const-string v1, " rumusht eeoco p shlaedohwR:tein"

    const/4 v6, 0x2

    const-string/jumbo v1, "utheuedp:patoehs oRn i sc uelhrw"

    const-string/jumbo v1, "other push huawei onResult code:"

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {p3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v2, p3}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {p2}, Ljava/lang/Integer;->intValue()I
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    goto/16 :goto_0

    :catchall_1
    move-exception p2

    :try_start_4
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/c$a;->a:Lcom/tencent/android/tpush/d/a/c;

    const/4 v6, 0x0

    iget-object v1, p3, Lcom/tencent/android/tpush/d/a/c;->a:Landroid/content/Context;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object p3, p3, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const-string v4, "5 e r,1oqg  rerMs::Cd-er "

    const-string v4, "errCode : -125 , errMsg :"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    move v6, v5

    invoke-virtual {p2}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p3, p2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v1, p1, p2}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto :goto_0

    :catchall_2
    move-exception p2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string/jumbo p3, "oisFantodeinnCoenc"

    const-string/jumbo p3, "onanoitnodceieFnCo"

    const/4 v6, 0x4

    const-string p3, "cnomelFaiCotionnne"

    const-string/jumbo p3, "onConnectionFailed"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v2, p3, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/c$a;->a:Lcom/tencent/android/tpush/d/a/c;

    const/4 v5, 0x6

    move v6, v5

    iget-object v1, p3, Lcom/tencent/android/tpush/d/a/c;->a:Landroid/content/Context;

    const/4 v6, 0x5

    const/4 v5, 0x0

    iget-object p3, p3, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v6, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string/jumbo v3, "oe: o6d :rrr sM b ,1-2Ceg"

    const-string v3, ":2eC b,er:- 1   6rdsMrgoe"

    const/4 v6, 0x1

    const-string v3, "ee reb6s1 :C2d  oM ,rr-:g"

    const-string v3, "errCode : -126 , errMsg :"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p2}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p3, p2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p3}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v1, p1, p2}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    return-object v0
.end method
