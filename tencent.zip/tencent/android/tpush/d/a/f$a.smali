.class public Lcom/tencent/android/tpush/d/a/f$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/d/a/f;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/d/a/f;

.field private b:Landroid/content/Context;


# direct methods
.method public constructor <init>(Lcom/tencent/android/tpush/d/a/f;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/f$a;->a:Lcom/tencent/android/tpush/d/a/f;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/tencent/android/tpush/d/a/f$a;->b:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "@~s@~4~/ b~~~o fSi~i@@ /~ @@ m@@b@@t@@ @d.~ o~ bsu~cl ~~1K@~@~in~ @- @  ~ l~ vaorty@ @o ~~o@~oMf"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x2

    if-nez p2, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 p1, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    return-object p1

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string/jumbo v0, "rRsmsoneit"

    const-string v0, "gtsreRoisn"

    const-string v0, "eornoietgR"

    const-string/jumbo v0, "onRegister"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string/jumbo v0, "kmrnnbrn:,uos   weg"

    const-string/jumbo v0, "ksomr :guwen rn,n  "

    const/4 v9, 0x6

    const-string v0, ", wM gunn rkrnse uo"

    const-string v0, " , errMsg : unknown"

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    const-string/jumbo v1, "sedpotoo_ec_h_urerrro"

    const/4 v9, 0x3

    const-string v1, "hpo_hrdpteeoue_sr_rcr"

    const-string/jumbo v1, "other_push_error_code"

    const/4 v9, 0x7

    const/4 v2, 0x0

    const/4 v9, 0x5

    xor-int/2addr v8, v2

    const/4 v9, 0x1

    const-string v3, "b e odCrq:"

    const-string v3, " o dCber:e"

    const/4 v9, 0x6

    const-string v3, "e se:rorCd"

    const-string v3, "errCode : "

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v9, 0x1

    const-string v5, "OelmIpPhrpsOhmtou"

    const-string v5, "OtherPushOppoImpl"

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    if-eqz p1, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz p3, :cond_5

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    array-length p1, p3

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    const/4 v6, 0x2

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-lt p1, v6, :cond_5

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    aget-object p1, p3, v2

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    check-cast p1, Ljava/lang/Integer;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    aget-object p3, p3, v4

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    check-cast p3, Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v8, 0x3

    if-nez p1, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const-string/jumbo v1, "p seogrste:osRehiueipsI esutrgOr,su Pd"

    const-string v1, "g:ieeeu e epgIOssoptrsrtRssc Prhusuid,"

    const-string/jumbo v1, "uusecbsi sgcRdstr, orpPeph eIOsergts:e"

    const-string v1, "OppoPush Register success, registerId:"

    const/4 v9, 0x3

    const/4 v8, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v5, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {p3}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-nez v0, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/f$a;->a:Lcom/tencent/android/tpush/d/a/f;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/f$a;->b:Landroid/content/Context;

    const/4 v9, 0x2

    const/4 v8, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/d/a/f;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-nez v0, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/f$a;->a:Lcom/tencent/android/tpush/d/a/f;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v0, p3}, Lcom/tencent/android/tpush/d/a/f;->a(Lcom/tencent/android/tpush/d/a/f;Ljava/lang/String;)Ljava/lang/String;

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/f$a;->b:Landroid/content/Context;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/f$a;->a:Lcom/tencent/android/tpush/d/a/f;

    const/4 v9, 0x4

    const/4 v8, 0x4

    invoke-static {v1}, Lcom/tencent/android/tpush/d/a/f;->a(Lcom/tencent/android/tpush/d/a/f;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string v2, "e_popoukpn"

    const-string/jumbo v2, "pno_tkppoe"

    const/4 v9, 0x5

    const-string/jumbo v2, "pot_opnpko"

    const-string/jumbo v2, "oppo_token"

    const/4 v8, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    const-string v1, "M:e cucrq rsse,ss g"

    const-string v1, " , errMsg : success"

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/f$a;->b:Landroid/content/Context;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-static {v1, v5, v0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    goto/16 :goto_0

    :cond_2
    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    const-string v6, "OppoPush Register failed, code="

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const-string/jumbo v6, "qgsm ,"

    const-string v6, "g q,ms"

    const/4 v9, 0x1

    const-string v6, " =mmg,"

    const-string v6, ", msg="

    const/4 v9, 0x6

    const/4 v8, 0x6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {v5, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/f$a;->b:Landroid/content/Context;

    const/4 v8, 0x2

    and-int/2addr v9, v8

    iget-object v6, p0, Lcom/tencent/android/tpush/d/a/f$a;->a:Lcom/tencent/android/tpush/d/a/f;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v6, v6, Lcom/tencent/android/tpush/d/a/f;->a:Ljava/lang/StringBuffer;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v7, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v6, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {v2, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string v0, "camKoi.edvcAoderistot..ECx.n.cnna.oBFnpiDg"

    const-string v0, "axsm..CFoernt..iBdcoti.denoEK.aAcnntiDvgpc"

    const/4 v9, 0x4

    const-string v0, "BxnrobaonKvd.CEtgi.t.cFo.paeDnm.ntideic.cE"

    const-string v0, "com.tencent.android.xg.vip.action.FEEDBACK"

    :try_start_0
    const/4 v8, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    new-instance v1, Landroid/content/Intent;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-direct {v1, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    const-string v0, "RHPECSu.DORROmU"

    const-string v0, "DORmUPRTCSRH.EO"

    const/4 v9, 0x7

    const-string v0, "RHOT.ESpERCPDUO"

    const-string v0, "TPUSH.ERRORCODE"

    const/4 v8, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v1, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string p1, "h_orptutqeehoksn"

    const-string/jumbo p1, "other_push_token"

    const/4 v9, 0x0

    const/4 v8, 0x1

    invoke-virtual {v1, p1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string p1, "HEsU.CBEDPAoFS"

    const-string p1, "ATUDoFHSPEC.EB"

    const/4 v9, 0x3

    const-string p1, "HTBmED.FPACESU"

    const-string p1, "TPUSH.FEEDBACK"

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v1, p1, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string p1, "NHCNoSPUA.LH"

    const-string p1, "H.PCSbUANHNL"

    const/4 v9, 0x1

    const-string p1, ".HHEAbPSCUNN"

    const-string p1, "PUSH.CHANNEL"

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    const/16 p3, 0x69

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v1, p1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/f$a;->b:Landroid/content/Context;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v8, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/f$a;->b:Landroid/content/Context;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-static {p1, v1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto/16 :goto_1

    :catchall_0
    move-exception p1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string v0, "elpP eurt acodrriek plorscug bRh sctaaOrbaos"

    const-string v0, "OppoPush Register callback broadcast error: "

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-static {v5, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x2

    goto/16 :goto_1

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    const-string/jumbo v6, "reuRtnopngis"

    const-string v6, "gnrtoiuResUn"

    const/4 v9, 0x1

    const-string/jumbo v6, "neointreqRsg"

    const-string/jumbo v6, "onUnRegister"

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {p1, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    if-eqz p1, :cond_5

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-eqz p3, :cond_5

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    array-length p1, p3

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-lt p1, v4, :cond_5

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    aget-object p1, p3, v2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    check-cast p1, Ljava/lang/Integer;

    const/4 v8, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-nez p1, :cond_4

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string p1, "cosen cigpRhsurPsspUOu spse"

    const-string/jumbo p1, "isROtpup roePpsshc ensgUcus"

    const/4 v9, 0x0

    const-string/jumbo p1, "tgumsihecUpsPnRro esp Ouses"

    const-string p1, "OppoPush UnRegister success"

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {v5, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    move v9, v8

    goto :goto_1

    :cond_4
    const/4 v9, 0x1

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    const-string v2, "gfuiod,epnOdrce as h UePeoptRil=o"

    const-string v2, "OppoPush UnRegister failed, code="

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {p3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    move v9, v8

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {v5, p3}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/f$a;->b:Landroid/content/Context;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/f$a;->a:Lcom/tencent/android/tpush/d/a/f;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-object v2, v2, Lcom/tencent/android/tpush/d/a/f;->a:Ljava/lang/StringBuffer;

    const/4 v9, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v2, p1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {p3, v1, p1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    :goto_1
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    return-object p2
.end method
