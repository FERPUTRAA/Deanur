.class public Lcom/tencent/android/tpush/d/a/b;
.super Lcom/tencent/android/tpush/d/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/d/a/b$b;,
        Lcom/tencent/android/tpush/d/a/b$a;
    }
.end annotation


# static fields
.field private static a:I = 0x6

.field private static b:I = 0x7

.field private static d:I

.field private static e:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field


# instance fields
.field private c:Ljava/lang/String;

.field private f:Ljava/lang/Object;

.field private g:Ljava/lang/Object;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/c;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/d/a/b;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/tencent/android/tpush/d/a/b;->c:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic a(Lcom/tencent/android/tpush/d/a/b;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/b;->c:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-object p1
.end method

.method private a(Ljava/lang/String;)V
    .locals 5

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v1, "EDsm.iiKtonpnBnocsoctgre..av.CndeAt..ixdEa"

    const-string v1, "EBs.teaicndnvD.dCixr.EmoiA.t.pencKacotgno."

    const/4 v4, 0x4

    const-string/jumbo v1, "oDdm.nKtcneirad.aceoi.E.noCpAt.cxFtB.nvimg"

    const-string v1, "com.tencent.android.xg.vip.action.FEEDBACK"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string v1, "RCPEoUHDmSTROE."

    const-string v1, "UE.mDSERTCROHRP"

    const/4 v4, 0x7

    const-string v1, "COTRObE.URHPSRD"

    const-string v1, "TPUSH.ERRORCODE"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v2, -0x1

    :goto_0
    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo v1, "os_uttuhnokorep_"

    const-string/jumbo v1, "tkepoeortho_n_su"

    const/4 v4, 0x6

    const-string/jumbo v1, "tnuopk_prhteso_h"

    const-string/jumbo v1, "other_push_token"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const-string p1, "ATPEHSDEqFUCB."

    const-string p1, "TPUSH.FEEDBACK"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const-string p1, "EHNHSbPCUA.L"

    const/4 v4, 0x2

    const-string p1, "HUsLCHANS.EN"

    const-string p1, "PUSH.CHANNEL"

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/16 v2, 0x6b

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string p1, "ES.mETUSPOHHKHTNEKOuPTRU"

    const-string p1, "EHSHTSuNOHPUTPEUKTYR.OEK"

    const/4 v4, 0x2

    const-string p1, "SO.KoHUKTYNEH.SEOUHRPPTE"

    const-string p1, "TPUSH.OTHERPUSH.TOKENKEY"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string v2, "eroohbontpk"

    const-string/jumbo v2, "thonronpoke"

    const/4 v4, 0x1

    const-string v2, "honor_token"

    const/4 v4, 0x4

    invoke-virtual {v0, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    const-string p1, "USKAOEuT.DPPT.qOUTNEH."

    const-string p1, "..TUKETUqPHTONEPD.OSNA"

    const/4 v4, 0x1

    const-string p1, "TPUSH.NOT.UPDATE.TOKEN"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->onOtherPushRegister(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-void
.end method

.method public static b()I
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v0, "uehmthrplposIsrPnO"

    const-string/jumbo v0, "tIslonmOerhPhpurso"

    const/4 v3, 0x7

    const-string/jumbo v0, "slpohrrtqIPOHmuone"

    const-string v0, "OtherPushHonorImpl"

    :try_start_0
    const/4 v3, 0x6

    const-string v1, "Husoh.mninhomhrotckl..hnuesorpdioPsC"

    const-string v1, "PosmmkHdpoioeChosh.hrh.tncrslunionu."

    const/4 v3, 0x5

    const-string v1, "dh.mohnrihPcnoueu.kl.iosrspsn.ohtmoH"

    const-string v1, "com.hihonor.push.sdk.HonorPushClient"

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    sput-object v1, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    sget v1, Lcom/tencent/android/tpush/d/a/b;->b:I

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    sput v1, Lcom/tencent/android/tpush/d/a/b;->d:I

    const/4 v3, 0x2

    const-string v1, "henro7ovkHcKDSo "

    const/4 v3, 0x5

    const-string v1, "e ovoS7HKoDhnkcc"

    const-string v1, "checkHonorSDK v7"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget v0, Lcom/tencent/android/tpush/d/a/b;->d:I
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v0

    :catch_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string/jumbo v1, "kordkbcoceuchen7obnfr xSdtHe  V"

    const-string v1, "c7uHSbnkonecxtp doeo ecVkrdrhf "

    const/4 v3, 0x3

    const-string/jumbo v1, "uccnndueoc rpoHfeextk  Vdrko7he"

    const-string/jumbo v1, "unexpected for checkHonorSdk V7"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v1, ".HcooknpesaoIrsdpctnIhosd.h..nomihnu"

    const-string v1, "Ipoi.Iu.Hssnodomh.n.oenrdkccnotashrh"

    const/4 v3, 0x1

    const-string v1, "..rhaIsoqspk.uodnnchohH.Iosnednicmto"

    const-string v1, "com.hihonor.push.sdk.HonorInstanceId"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v3, 0x4

    sput-object v1, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget v1, Lcom/tencent/android/tpush/d/a/b;->a:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    sput v1, Lcom/tencent/android/tpush/d/a/b;->d:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string v1, "corhvokpH6e cSDK"

    const/4 v3, 0x1

    const-string v1, "checkHonorSDK v6"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    sget v0, Lcom/tencent/android/tpush/d/a/b;->d:I
    :try_end_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v0

    :catch_1
    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v1, "rus rknechftqepVSxH oe6cnk ceod"

    const-string/jumbo v1, "ro ec6dpqceknHr tcdSxVnfoeu ekh"

    const/4 v3, 0x3

    const-string/jumbo v1, "unexpected for checkHonorSdk V6"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    or-int/2addr v3, v2

    const/4 v0, -0x1

    move v3, v0

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    sput v0, Lcom/tencent/android/tpush/d/a/b;->d:I

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v0
.end method

.method static synthetic b(Lcom/tencent/android/tpush/d/a/b;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/b;->a(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const-string/jumbo v0, "oshmo"

    const-string/jumbo v0, "onsoh"

    const/4 v2, 0x4

    const-string/jumbo v0, "onoro"

    const-string v0, "honor"

    const/4 v2, 0x4

    const/4 v1, 0x4

    return-object v0
.end method

.method public a(Landroid/content/Context;)V
    .locals 13

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    sget v0, Lcom/tencent/android/tpush/d/a/b;->d:I

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    if-nez v0, :cond_0

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/d/a/b;->b()I

    :cond_0
    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x1

    const-string v0, " rssub rgiorhsoph ehothemtern"

    const-string/jumbo v0, "punmsrotreuorhios gshhethr  e"

    const/4 v12, 0x4

    const-string v0, "i hoshuortsrpPu gsentrh ehuor"

    const-string/jumbo v0, "other push honor registerPush"

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x0

    const-string v1, "OhrloPupropmnhsoIH"

    const-string/jumbo v1, "rnIsohoulhtOHpPomr"

    const/4 v12, 0x7

    const-string v1, "OtherPushHonorImpl"

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    sget v0, Lcom/tencent/android/tpush/d/a/b;->d:I

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    sget v2, Lcom/tencent/android/tpush/d/a/b;->b:I

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x6

    const-string/jumbo v3, "kegesnuoqPTb"

    const-string/jumbo v3, "oPtesbTnekug"

    const-string v3, "esstokePTghu"

    const-string v3, "getPushToken"

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x7

    const-class v4, Landroid/content/Context;

    const-class v4, Landroid/content/Context;

    const/4 v12, 0x2

    const-class v4, Landroid/content/Context;

    const-class v4, Landroid/content/Context;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x0

    const-string/jumbo v5, "p    ru:erhtnooshgiorrueers"

    const/4 v12, 0x1

    const-string/jumbo v5, "t rmsopiegeour r hhr eonsrr"

    const-string/jumbo v5, "register honor push error: "

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x7

    const-string/jumbo v6, "ngpeoItncae"

    const-string/jumbo v6, "ncnetIeptga"

    const/4 v12, 0x7

    const-string v6, "atsgIbctene"

    const-string v6, "getInstance"

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x2

    const/4 v7, 0x1

    const/4 v12, 0x3

    const/4 v8, 0x0

    const/4 v12, 0x4

    xor-int/2addr v11, v8

    const/4 v12, 0x1

    if-ne v0, v2, :cond_2

    :try_start_0
    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x5

    sget-object v0, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v11, 0x5

    move v12, v11

    new-array v2, v8, [Ljava/lang/Class;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-virtual {v0, v6, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x2

    sget-object v2, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    new-array v6, v8, [Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {v0, v2, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    sget-object v2, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x7

    const-string/jumbo v6, "ntii"

    const-string/jumbo v6, "init"

    const/4 v11, 0x4

    and-int/2addr v12, v11

    const/4 v9, 0x2

    move v12, v9

    const/4 v11, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x1

    new-array v10, v9, [Ljava/lang/Class;

    const/4 v12, 0x1

    aput-object v4, v10, v8

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    sget-object v4, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    aput-object v4, v10, v7

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-virtual {v2, v6, v10}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x3

    new-array v4, v9, [Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x6

    aput-object p1, v4, v8

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x0

    sget-object v6, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x2

    aput-object v6, v4, v7

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-virtual {v2, v0, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x0

    const-string v2, ".ilckhuhubo.skoauCc.rnalr.osmphooHnPdq"

    const-string v2, "Ho.asbupq.nnrdsoCocrhlPa.i.coholhkhkum"

    const/4 v12, 0x5

    const-string/jumbo v2, "oss.ookpCul.ldocuHaorrp.sbhhkaihn.hPnm"

    const-string v2, "com.hihonor.push.sdk.HonorPushCallback"

    const/4 v11, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    iget-object v4, p0, Lcom/tencent/android/tpush/d/a/b;->f:Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x1

    if-nez v4, :cond_1

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    new-instance v4, Lcom/tencent/android/tpush/d/a/b$a;

    const/4 v12, 0x4

    const/4 v11, 0x5

    invoke-direct {v4, p0, p1}, Lcom/tencent/android/tpush/d/a/b$a;-><init>(Lcom/tencent/android/tpush/d/a/b;Landroid/content/Context;)V

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-virtual {v2}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object p1

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    new-array v6, v7, [Ljava/lang/Class;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    aput-object v2, v6, v8

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-static {p1, v6, v4}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/b;->f:Ljava/lang/Object;

    :cond_1
    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x7

    sget-object p1, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    new-array v4, v7, [Ljava/lang/Class;

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x5

    aput-object v2, v4, v8

    const/4 v11, 0x5

    and-int/2addr v12, v11

    invoke-virtual {p1, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v12, 0x3

    const/4 v11, 0x2

    new-array v2, v7, [Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/d/a/b;->f:Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x2

    aput-object v3, v2, v8

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-virtual {p1, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x7

    goto/16 :goto_0

    :catchall_0
    move-exception p1

    const/4 v12, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x1

    const/4 v11, 0x1

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-static {v1, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    goto/16 :goto_0

    :cond_2
    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x0

    sget v2, Lcom/tencent/android/tpush/d/a/b;->a:I

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    if-ne v0, v2, :cond_5

    :try_start_1
    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x2

    sget-object v0, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x5

    new-array v2, v7, [Ljava/lang/Class;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x7

    aput-object v4, v2, v8

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-virtual {v0, v6, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v12, 0x6

    const/4 v11, 0x5

    sget-object v2, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x7

    new-array v4, v7, [Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x4

    aput-object p1, v4, v8

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-virtual {v0, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x3

    sget-object v2, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x2

    new-array v4, v8, [Ljava/lang/Class;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-virtual {v2, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    new-array v3, v8, [Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-virtual {v2, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x4

    if-eqz v0, :cond_4

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x3

    const/4 v11, 0x3

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x2

    if-nez v2, :cond_4

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x4

    const-string v3, "Hoe :netqrsGot on"

    const-string v3, " os:enH oetrGnotk"

    const/4 v12, 0x1

    const-string/jumbo v3, "oosGentoe: k nt r"

    const-string v3, "Get Honor token: "

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    move v12, v11

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x7

    const/4 v11, 0x7

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/d/a/b;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x4

    if-nez v2, :cond_3

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/b;->c:Ljava/lang/String;

    const/4 v11, 0x7

    xor-int/2addr v12, v11

    const-string v3, "honor_token"

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-static {p1, v3, v2}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-direct {p0, v0}, Lcom/tencent/android/tpush/d/a/b;->a(Ljava/lang/String;)V

    const/4 v11, 0x7

    const-string v0, "dgsms Mem0eCeu rre: ,ccrr sos "

    const-string v0, "csMms,ce e u dsrg  Ceroer :rs0"

    const/4 v12, 0x5

    const-string/jumbo v0, "sMr o  s, rrc dos:C0 es:egereu"

    const-string v0, "errCode : 0 , errMsg : success"

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x1

    goto :goto_0

    :cond_4
    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x5

    const-string/jumbo p1, "onnerboe  ryo etm  tllonpHGuo"

    const-string/jumbo p1, "mon olnokyrunte otelHrG  o pe"

    const/4 v12, 0x2

    const-string/jumbo p1, "k n Huu lGtoortpomeennoltr y "

    const-string p1, "Get Honor token null or empty"

    const/4 v11, 0x7

    or-int/2addr v12, v11

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x4

    goto :goto_0

    :catchall_1
    move-exception p1

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x6

    const/4 v11, 0x7

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-static {v1, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    goto :goto_0

    :cond_5
    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    const-string/jumbo p1, "uisboS pKiHnhsMosDn rg"

    const-string p1, "iH SPbsn osuKMsrgDiohn"

    const/4 v12, 0x1

    const-string/jumbo p1, "rP nuoMKqs hinS gHsDio"

    const-string p1, "Missing Honor Push SDK"

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x2

    return-void
.end method

.method public b(Landroid/content/Context;)V
    .locals 13

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x3

    sget v0, Lcom/tencent/android/tpush/d/a/b;->d:I

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x4

    if-nez v0, :cond_0

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/d/a/b;->b()I

    :cond_0
    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x0

    const-string v0, "h snsuos shthuirrroetpeoPen hgr"

    const-string/jumbo v0, "roses ushnrpenthrh erihu ogPuot"

    const/4 v12, 0x0

    const-string/jumbo v0, "uunmshrehtoPhet p ogrursnrsoieh"

    const-string/jumbo v0, "other push honor unregisterPush"

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x6

    const-string/jumbo v1, "olmtoHrhrnOpIhueop"

    const-string v1, "PhtreonpOHmruplIoh"

    const/4 v12, 0x5

    const-string v1, "erlrubomonOHIshtPh"

    const-string v1, "OtherPushHonorImpl"

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    sget v0, Lcom/tencent/android/tpush/d/a/b;->d:I

    const/4 v11, 0x0

    move v12, v11

    sget v2, Lcom/tencent/android/tpush/d/a/b;->b:I

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x6

    const-string v3, "dqenoeuTtklePhs"

    const-string v3, "eoPundlTqtkhsee"

    const-string v3, "hnokelPpeTteesd"

    const-string v3, "deletePushToken"

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x0

    const-class v4, Landroid/content/Context;

    const-class v4, Landroid/content/Context;

    const/4 v12, 0x2

    const-class v4, Landroid/content/Context;

    const-class v4, Landroid/content/Context;

    const/4 v12, 0x3

    const/4 v11, 0x6

    const-string/jumbo v5, "osin nseqoh h:urprrreogs u re"

    const-string/jumbo v5, "u s:r inhrogorohsp eersrr nue"

    const/4 v12, 0x6

    const-string v5, "e srreuor rnigshurort:sp enho"

    const-string/jumbo v5, "unregister honor push error: "

    const/4 v11, 0x5

    const/4 v12, 0x0

    const-string v6, "agmmtenescn"

    const-string/jumbo v6, "ttemagsecnn"

    const/4 v12, 0x3

    const-string v6, "Inncoeteatg"

    const-string v6, "getInstance"

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x2

    const/4 v7, 0x1

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x0

    if-ne v0, v2, :cond_2

    :try_start_0
    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    sget-object v0, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x4

    new-array v2, v8, [Ljava/lang/Class;

    const/4 v11, 0x0

    move v12, v11

    invoke-virtual {v0, v6, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    sget-object v2, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x1

    new-array v6, v8, [Ljava/lang/Object;

    const/4 v12, 0x4

    invoke-virtual {v0, v2, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x2

    sget-object v2, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v12, 0x0

    const/4 v11, 0x3

    const-string/jumbo v6, "niti"

    const-string/jumbo v6, "ntii"

    const/4 v12, 0x1

    const-string/jumbo v6, "tiin"

    const-string/jumbo v6, "init"

    const/4 v12, 0x7

    const/4 v9, 0x1

    const/4 v12, 0x4

    const/4 v9, 0x2

    const/4 v12, 0x2

    new-array v10, v9, [Ljava/lang/Class;

    aput-object v4, v10, v8

    const/4 v12, 0x4

    sget-object v4, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x2

    aput-object v4, v10, v7

    const/4 v12, 0x0

    const/4 v11, 0x2

    invoke-virtual {v2, v6, v10}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    new-array v4, v9, [Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x3

    aput-object p1, v4, v8

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x6

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v12, 0x0

    aput-object p1, v4, v7

    const/4 v12, 0x4

    invoke-virtual {v2, v0, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x7

    const-string/jumbo p1, "l.olHbdraihocosPabrcsoupom..hCuokkhs.n"

    const-string/jumbo p1, "shm.onahuckkno.bHssoC.Pdaicoupl.ororlh"

    const/4 v12, 0x7

    const-string/jumbo p1, "smdu.CusporhhoahhakkoHbcrsuPl.o.ocnnl."

    const-string p1, "com.hihonor.push.sdk.HonorPushCallback"

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-static {p1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p1

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/b;->g:Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x5

    if-nez v2, :cond_1

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x7

    new-instance v2, Lcom/tencent/android/tpush/d/a/b$b;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    const/4 v4, 0x0

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-direct {v2, p0, v4}, Lcom/tencent/android/tpush/d/a/b$b;-><init>(Lcom/tencent/android/tpush/d/a/b;Lcom/tencent/android/tpush/d/a/b$1;)V

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {p1}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v4

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    new-array v6, v7, [Ljava/lang/Class;

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x4

    aput-object p1, v6, v8

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-static {v4, v6, v2}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/b;->g:Ljava/lang/Object;

    :cond_1
    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    sget-object v2, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v12, 0x1

    new-array v4, v7, [Ljava/lang/Class;

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x1

    aput-object p1, v4, v8

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {v2, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x3

    new-array v2, v7, [Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/d/a/b;->g:Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x5

    aput-object v3, v2, v8

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {p1, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x0

    goto/16 :goto_0

    :catchall_0
    move-exception p1

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x6

    xor-int/2addr v12, v11

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-static {v1, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x1

    goto/16 :goto_0

    :cond_2
    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x5

    sget v2, Lcom/tencent/android/tpush/d/a/b;->a:I

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x3

    if-ne v0, v2, :cond_3

    :try_start_1
    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x7

    sget-object v0, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    new-array v2, v7, [Ljava/lang/Class;

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x6

    aput-object v4, v2, v8

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-virtual {v0, v6, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x6

    sget-object v2, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v11, 0x2

    move v12, v11

    new-array v4, v7, [Ljava/lang/Object;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x0

    aput-object p1, v4, v8

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v0, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x5

    sget-object v0, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x2

    new-array v2, v8, [Ljava/lang/Class;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-virtual {v0, v3, v2}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    new-array v2, v8, [Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v0, p1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x4

    goto :goto_0

    :catchall_1
    move-exception p1

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x4

    const/4 v11, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x0

    goto :goto_0

    :cond_3
    const/4 v11, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x7

    const-string/jumbo p1, "rg nbs phSoisDHP nsuiK"

    const-string p1, "DssigbshoSnH PKi Mnru "

    const/4 v12, 0x4

    const-string/jumbo p1, "unPso irqsH SDnK ghois"

    const-string p1, "Missing Honor Push SDK"

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x4

    return-void
.end method

.method public c(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/b;->c:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string/jumbo v0, "ursoho_oent"

    const-string/jumbo v0, "orheooutn_k"

    const-string v0, "_tnmooehkon"

    const-string v0, "honor_token"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/b;->c:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/b;->c:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p1
.end method

.method public d(Landroid/content/Context;)Z
    .locals 11

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    sget v0, Lcom/tencent/android/tpush/d/a/b;->d:I

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    if-nez v0, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/d/a/b;->b()I

    :cond_0
    const/4 v10, 0x7

    sget v0, Lcom/tencent/android/tpush/d/a/b;->d:I

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    sget v1, Lcom/tencent/android/tpush/d/a/b;->b:I

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    const-class v2, Landroid/content/Context;

    const-class v2, Landroid/content/Context;

    const/4 v10, 0x5

    const-class v2, Landroid/content/Context;

    const-class v2, Landroid/content/Context;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    const-string/jumbo v3, "s:uoonrprhs Cnpeoigfh o o r"

    const-string/jumbo v3, "onpnsr:pfuroo sror eh gChi "

    const/4 v10, 0x5

    const-string/jumbo v3, "pn :hburieoo oCrsif ohsg rr"

    const-string/jumbo v3, "isConfig honor push error: "

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string/jumbo v4, "toehouHpqhnPOIrrsl"

    const/4 v10, 0x3

    const-string v4, "hsrruIuotnehlHopPO"

    const-string v4, "OtherPushHonorImpl"

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    const/4 v5, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/4 v6, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-ne v0, v1, :cond_2

    :try_start_0
    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    sget-object v0, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    const-string/jumbo v1, "ncgsItepnsa"

    const-string/jumbo v1, "ncsaengstIt"

    const/4 v10, 0x6

    const-string v1, "ceenastgqnI"

    const-string v1, "getInstance"

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    new-array v7, v6, [Ljava/lang/Class;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v0, v1, v7}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    sget-object v1, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    new-array v7, v6, [Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v0, v1, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    sget-object v1, Lcom/tencent/android/tpush/d/a/b;->e:Ljava/lang/Class;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    const-string/jumbo v7, "rcsoPHpchupmnSheokrts"

    const-string v7, "crPmehophrktnHusoocSp"

    const/4 v10, 0x5

    const-string/jumbo v7, "prhmcpuheSHootruoskPc"

    const-string v7, "checkSupportHonorPush"

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    new-array v8, v5, [Ljava/lang/Class;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    aput-object v2, v8, v6

    const/4 v10, 0x7

    invoke-virtual {v1, v7, v8}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x3

    new-array v2, v5, [Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    aput-object p1, v2, v6

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v1, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-eqz p1, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    check-cast p1, Ljava/lang/Boolean;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x0

    return p1

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    return v6

    :catchall_0
    move-exception p1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x6

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {v4, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    goto/16 :goto_0

    :cond_2
    const/4 v9, 0x4

    const/4 v10, 0x2

    sget v1, Lcom/tencent/android/tpush/d/a/b;->a:I

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-ne v0, v1, :cond_4

    :try_start_1
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x0

    const-string/jumbo v0, "o.imosnop.nvihylArod.cciiahuipoa.ob.trsphkHil"

    const-string v0, "com.hihonor.push.sdk.ipc.HonorApiAvailability"

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    const-string/jumbo v1, "ilaiebrsaoeocrlinvolAeMbHbsoSe"

    const-string/jumbo v1, "orAioaebvelssooieHSbMcavrielnl"

    const/4 v10, 0x7

    const-string v1, "eHrsbAuooSsbioaiMiaelcnelivevl"

    const-string/jumbo v1, "isHonorMobileServicesAvailable"

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    new-array v7, v5, [Ljava/lang/Class;

    const/4 v10, 0x3

    aput-object v2, v7, v6

    const/4 v9, 0x5

    or-int/2addr v10, v9

    invoke-virtual {v0, v1, v7}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    new-array v2, v5, [Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    aput-object p1, v2, v6

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v1, v0, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x1

    if-eqz p1, :cond_5

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    check-cast p1, Ljava/lang/Integer;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-nez p1, :cond_3

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    return v5

    :cond_3
    const/4 v10, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-string v1, "esnuorepAo l  Mbor=osa bsoghSsecenliai vhnbCoviiliHpr"

    const-string/jumbo v1, "lsciMb  Hion rshv ob=goSrnofsielalrviaCeonhbesup eioA"

    const/4 v10, 0x6

    const-string/jumbo v1, "isConfig honor push isHonorMobileServicesAvailable = "

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x6

    const-string/jumbo p1, "us!op nuq t,ot"

    const-string/jumbo p1, "s,otppu  !ntuo"

    const/4 v10, 0x2

    const-string p1, "!ustrspopo ,nt"

    const-string p1, ", not support!"

    const/4 v10, 0x0

    const/4 v9, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {v4, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    return v6

    :catchall_1
    move-exception p1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static {v4, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    goto :goto_0

    :cond_4
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    const-string p1, "i Smsp rnMnhDssoPuHiKo"

    const-string/jumbo p1, "soPhSKnpsD MigounirHs "

    const-string p1, "hiHMonPsKsSroDusi ng  "

    const-string p1, "Missing Honor Push SDK"

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-static {v4, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x2

    return v6
.end method

.method public e(Landroid/content/Context;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    const/16 p1, 0x9

    const/4 v0, 0x4

    shr-int/2addr v1, v0

    return p1
.end method

.method public f(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x2

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p1
.end method
