.class public Lcom/tencent/android/tpush/d/a/g$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/d/a/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x1
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/d/a/g;

.field private b:Landroid/content/Context;


# direct methods
.method public constructor <init>(Lcom/tencent/android/tpush/d/a/g;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/g$a;->a:Lcom/tencent/android/tpush/d/a/g;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/tencent/android/tpush/d/a/g$a;->b:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "ids~ fac ytb~l~@@ ~b~S o@@t~~~@@ ~-o~4@m@@ @ M @~ ~ ~~@~o. ~1b@~@ ~@~o @@@rl~s~on@@Kv   u//i~o i"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    if-nez p2, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 p1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    return-object p1

    :cond_0
    :try_start_0
    const/4 v5, 0x0

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v0, "eaamSntdgoeCst"

    const-string v0, "gasttnoSedCnae"

    const/4 v5, 0x1

    const-string/jumbo v0, "thedoetnaSCgao"

    const-string/jumbo v0, "onStateChanged"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string/jumbo v1, "ilusebrmvmpIhtPVh"

    const-string/jumbo v1, "oIVmthPushmvirlpe"

    const/4 v5, 0x1

    const-string v1, "OtherPushVivoImpl"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz p3, :cond_4

    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    array-length p1, p3

    const/4 v5, 0x2

    const/4 v4, 0x7

    if-lez p1, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x4

    aget-object p1, p3, v0

    const/4 v5, 0x2

    check-cast p1, Ljava/lang/Integer;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string p3, "eeC: ru rd"

    const-string p3, "Cereo: rd "

    const/4 v5, 0x6

    const-string p3, "dro Crep: "

    const-string p3, "errCode : "

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-nez p1, :cond_1

    :try_start_2
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string/jumbo v2, "iudge,Pvqeb tooRv s runheUtec  crci seiross sRsg"

    const-string v2, "RUsuRb tcoiPs=sothueeg o s neiid c,srsgc v verer"

    const/4 v5, 0x1

    const-string/jumbo v2, "tisU, euot  ishveR sunecd   viereoPorgsg=ercsRss"

    const-string/jumbo v2, "vivoPush Register or UnRegister success, code = "

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string p1, " remssrueMc: gsc ,u"

    const-string/jumbo p1, "s:s,gMus cre cs rue"

    const-string p1, ":srsogsec  sM ,u cr"

    const-string p1, " , errMsg : success"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/g$a;->b:Landroid/content/Context;

    const/4 v4, 0x0

    xor-int/2addr v5, v4

    invoke-static {p3, v1, p1}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    goto/16 :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    and-int/2addr v5, v4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v2, " eoaibsRoi tl ogvergfepsvrhed Urn it=i csPe, "

    const-string/jumbo v2, "ivrtre,p intf  sosiseroec  iu=ehlPdvUeog a Rg"

    const/4 v5, 0x4

    const-string/jumbo v2, "vivoPush Register or UnRegister fail, code = "

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/g$a;->b:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo v1, "srhopruod_eqehrre_uoc"

    const-string/jumbo v1, "rusorre_qorh_ehcepo_d"

    const/4 v5, 0x1

    const-string v1, "_sroroppreuhche_oetdr"

    const-string/jumbo v1, "other_push_error_code"

    const/4 v4, 0x0

    and-int/2addr v5, v4

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/g$a;->a:Lcom/tencent/android/tpush/d/a/g;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v2, v2, Lcom/tencent/android/tpush/d/a/g;->a:Ljava/lang/StringBuffer;

    const/4 v5, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v3, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string p1, " n:ns neqrg o,rsku "

    const-string p1, " gsunnw n roek,s :r"

    const/4 v5, 0x4

    const-string/jumbo p1, "nnsoknMurw r:  ,sg "

    const-string p1, " , errMsg : unknown"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v2, p1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto/16 :goto_0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v2, "eoumsScsm"

    const-string/jumbo v2, "onSmucess"

    const/4 v5, 0x5

    const-string v2, "csosoScue"

    const-string/jumbo v2, "onSuccess"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const-string/jumbo v2, "noitkbvo_v"

    const-string/jumbo v2, "vivo_token"

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    if-eqz p1, :cond_3

    :try_start_3
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    aget-object p1, p3, v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    check-cast p1, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string v0, " lucvru caeeStiHIodr e:eMsyPedgn sgodhinvgRu"

    const-string/jumbo v0, "vivoPush MyHandler getRegId onSuccess regid:"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v1, p3}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/g$a;->a:Lcom/tencent/android/tpush/d/a/g;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p3, p1}, Lcom/tencent/android/tpush/d/a/g;->a(Lcom/tencent/android/tpush/d/a/g;Ljava/lang/String;)Ljava/lang/String;

    const/4 v4, 0x1

    move v5, v4

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/g$a;->b:Landroid/content/Context;

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/g$a;->a:Lcom/tencent/android/tpush/d/a/g;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {p3}, Lcom/tencent/android/tpush/d/a/g;->a(Lcom/tencent/android/tpush/d/a/g;)Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {p1, v2, p3}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/g$a;->a:Lcom/tencent/android/tpush/d/a/g;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/d/a/g;->a(Lcom/tencent/android/tpush/d/a/g;)Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {p1, p3}, Lcom/tencent/android/tpush/d/a/g;->b(Lcom/tencent/android/tpush/d/a/g;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    goto/16 :goto_0

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo v3, "opolnF"

    const-string v3, "Foniol"

    const-string v3, "aFqnio"

    const-string/jumbo v3, "onFail"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz p1, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    aget-object p1, p3, v0

    check-cast p1, Ljava/lang/Integer;

    const/4 v5, 0x6

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string v0, "e sdIHl e,Pvaerhin ygdR tcvudMgb eaf=iosl"

    const-string/jumbo v0, "ldoe by=hn ddvP evf, iHagalrMi IeRecuogts"

    const/4 v5, 0x3

    const-string/jumbo v0, "vRIme  oslgetMvd oed yurc Hed=alfP,iagnih"

    const-string/jumbo v0, "vivoPush MyHandler getRegId fail, code = "

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/g$a;->a:Lcom/tencent/android/tpush/d/a/g;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string p3, ""

    const-string p3, ""

    const/4 v5, 0x0

    const-string p3, ""

    const-string p3, ""

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {p1, p3}, Lcom/tencent/android/tpush/d/a/g;->a(Lcom/tencent/android/tpush/d/a/g;Ljava/lang/String;)Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/g$a;->b:Landroid/content/Context;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object p3, p0, Lcom/tencent/android/tpush/d/a/g$a;->a:Lcom/tencent/android/tpush/d/a/g;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {p3}, Lcom/tencent/android/tpush/d/a/g;->a(Lcom/tencent/android/tpush/d/a/g;)Ljava/lang/String;

    move-result-object p3

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {p1, v2, p3}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catchall_0
    :cond_4
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-object p2
.end method
