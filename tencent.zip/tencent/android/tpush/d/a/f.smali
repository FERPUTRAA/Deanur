.class public Lcom/tencent/android/tpush/d/a/f;
.super Lcom/tencent/android/tpush/d/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/d/a/f$a;
    }
.end annotation


# instance fields
.field a:Ljava/lang/StringBuffer;

.field private b:Ljava/lang/String;

.field private c:Ljava/lang/Object;

.field private d:Ljava/lang/Object;

.field private e:Z

.field private f:I

.field private g:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field private h:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/c;-><init>()V

    const/4 v0, 0x0

    move v3, v0

    move v2, v0

    move v2, v0

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->c:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->d:Ljava/lang/Object;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iput-boolean v1, p0, Lcom/tencent/android/tpush/d/a/f;->e:Z

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput v1, p0, Lcom/tencent/android/tpush/d/a/f;->f:I

    const/4 v2, 0x6

    move v3, v2

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->h:Ljava/lang/Class;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/d/a/f;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "sms~d~ @o@. @~b@1M @o   - ~b@@~lbi~~K ia~n@~@ c ~v~@4@ ~o/~@~/f t~~~@ ut~~oS@o@@@l r@y  i@@ ~fo~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/tencent/android/tpush/d/a/f;->b:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic a(Lcom/tencent/android/tpush/d/a/f;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/f;->b:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p1
.end method

.method private b()I
    .locals 4

    :try_start_0
    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/a/f;->d()I

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    return v0

    :catchall_0
    const/4 v3, 0x3

    const-string/jumbo v0, "poomede02OkOphVc prencStSihtnsx2pc_ oedsukrfae"

    const-string v0, "eoskcepVeunoe0chdSdoreOppcO_e hnfrx2stSti akp2"

    const/4 v3, 0x0

    const-string/jumbo v0, "ueSrohpcptotS20fneoeOe_dkdoVkh eayxcre pni2psc"

    const-string/jumbo v0, "unexpected for checkOppoSdkVersion_heytapOS202"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v1, "hsmrPbImphtoeplOO"

    const-string/jumbo v1, "pPemhphrplOtsoOIm"

    const/4 v3, 0x3

    const-string v1, "hIrppluhOptOsPeou"

    const-string v1, "OtherPushOppoImpl"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/a/f;->e()I

    move-result v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    return v0

    :catchall_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v0, "ockhcp_peet0deeOun cieyOksrVd ppta2Sorpohe1oSn"

    const-string/jumbo v0, "op0roteOcpduc pskVn1SectpaneSd_keyofhrhi2eOe o"

    const/4 v3, 0x1

    const-string v0, "d p 1Sxpq0cOnpeOcoiecyouereethknasVfk_toS2ehdp"

    const-string/jumbo v0, "unexpected for checkOppoSdkVersion_heytapOS210"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_2
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/a/f;->c()I

    move-result v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v3, 0x6

    const/4 v2, 0x5

    return v0

    :catchall_2
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v0, "OpseSnenroxr uokccesftocooe_drppekO iSldhc"

    const-string/jumbo v0, "unexpected for checkOppoSdkVersion_colorOS"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->h:Ljava/lang/Class;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo v0, "oo mnbovip-ss k te:pGr e"

    const-string v0, "-tk  b  svedoirGspno:poe"

    const/4 v3, 0x1

    const-string/jumbo v0, "tov opsi dek-s G:p1neoor"

    const-string v0, "Get oppo sdk version: -1"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    return v0
.end method

.method private c()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v0, "karglbomhMs..uues.adnmroscccso"

    const-string/jumbo v0, "so.moMulocunkrrshe.gdscasmac.o"

    const/4 v3, 0x1

    const-string v0, ".ckrcguahmroma.eocPssduMlosno."

    const-string v0, "com.coloros.mcssdk.PushManager"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo v0, "okkpcabphlolclP..ram.o.caCscsdclbkluscas"

    const-string v0, "Plss.lbpa.koohabmsCukccacdlacm.clcl.rosk"

    const/4 v3, 0x6

    const-string v0, "asmk..alqClclcomokskoPloucdarsl.ahbcs.cb"

    const-string v0, "com.coloros.mcssdk.callback.PushCallback"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->h:Ljava/lang/Class;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const-string v0, "OpsoqmtpIhlrhpeOu"

    const-string/jumbo v0, "rsIpphmlqethupOoO"

    const/4 v3, 0x7

    const-string v0, "hppmmsheIutrOoPlp"

    const-string v0, "OtherPushOppoImpl"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v1, "kvieorGp:s1ess ot  nopo"

    const-string/jumbo v1, "res dvn1okio opGpes st:"

    const/4 v3, 0x6

    const-string/jumbo v1, "okedob1p pv  rGonss: te"

    const-string v1, "Get oppo sdk version: 1"

    const/4 v2, 0x4

    move v3, v2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method private d()I
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const-string/jumbo v0, "puadytu.hgcmssheocnaMr.mPsm.e"

    const-string v0, "PMnm.aaucdssorh.yphtacme.mseg"

    const/4 v3, 0x5

    const-string/jumbo v0, "y.achscp..msruasptengPkomheMd"

    const-string v0, "com.heytap.mcssdk.PushManager"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v3, 0x0

    const-string v0, ".la.bccsqoCklcksboPkmthpu..aclaaesmlday"

    const-string/jumbo v0, "kus.okaPhocCllt.a.scmsmkpbldyabaelccc.a"

    const/4 v3, 0x5

    const-string v0, "cdsmamshblcysolCp.chkaatPla.cbauk..lecs"

    const-string v0, "com.heytap.mcssdk.callback.PushCallback"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->h:Ljava/lang/Class;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-string/jumbo v0, "phpmhbtouOrIPpslO"

    const-string/jumbo v0, "pulhPbrpphImtsoOO"

    const/4 v3, 0x1

    const-string v0, "ItplouOePOspmpohh"

    const-string v0, "OtherPushOppoImpl"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v1, "oent bp kvio:2opGdssu  "

    const-string v1, ":o2  ouGneksptod  irvsp"

    const/4 v3, 0x1

    const-string v1, "ed opiunkoo: pt2G evrs "

    const-string v1, "Get oppo sdk version: 2"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    return v0
.end method

.method private e()I
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v0, "lOIhhsPpteOpppmpr"

    const-string/jumbo v0, "prOsetOppphmPIhol"

    const/4 v6, 0x1

    const-string v0, "hOIsPmOtqpepprohu"

    const-string v0, "OtherPushOppoImpl"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string v1, "h.sapsspohes.mthmnpauecPgyaraHy.tp.qM"

    const-string v1, "hptoa.smqep.styuHpha.rMemPhscaanepgy."

    const/4 v6, 0x7

    const-string/jumbo v1, "srHmut.s.eg.eaoutpshyeMaPmmap.pcphnha"

    const-string v1, "com.heytap.msp.push.HeytapPushManager"

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    iput-object v1, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v1, "is..ool.cakvca.lSmrtsyshlcupetCIcaeelmaupcblkpRa.sh"

    const-string v1, "emsreoc.sacklyhauaIRcsi.acle...peSbvtutpaslhCkmcllp"

    const/4 v6, 0x0

    const-string v1, "Sskptbliyecem.lpoIvCh..uBaeptlbukescamRl..acrhscaac"

    const-string v1, "com.heytap.msp.push.callback.ICallBackResultService"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpush/d/a/f;->h:Ljava/lang/Class;

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v6, 0x1

    const-string/jumbo v2, "oKgDNnutsmeaVSiem"

    const-string v2, "eKmmoragDneStVsNi"

    const/4 v6, 0x5

    const-string/jumbo v2, "mrDeVSipNenotegsa"

    const-string v2, "getSDKVersionName"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v3, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v6, 0x5

    const/4 v5, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    check-cast v1, Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string/jumbo v3, "ko:e etsqono dirGp vsp"

    const-string/jumbo v3, "vd :os nopsoGopiekter "

    const/4 v6, 0x0

    const-string v3, "dossGrv:p eesiok t op "

    const-string v3, "Get oppo sdk version: "

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string v2, "03.m."

    const-string v2, "3.0.0"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-gtz v0, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/16 v0, 0x12c

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    return v0

    :catchall_0
    move-exception v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string/jumbo v3, "xkhcoi:Oofere rpsSc nnduachee12tpoOb0oyepe_VkSt"

    const-string/jumbo v3, "pSoSebk tVuetoOdx n_eifsp:ccyredkheepOr21anoc0h"

    const/4 v6, 0x6

    const-string/jumbo v3, "teroeb1_e2cnxsOpVdh0dcokk:rOShcpuppSeoneif ety "

    const-string/jumbo v3, "unexpected for checkOppoSdkVersion_heytapOS210:"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/16 v0, 0xd2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    return v0
.end method

.method private g(Landroid/content/Context;)Ljava/lang/Object;
    .locals 11

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    iget v0, p0, Lcom/tencent/android/tpush/d/a/f;->f:I

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x3

    if-nez v0, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/a/f;->b()I

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    iput v0, p0, Lcom/tencent/android/tpush/d/a/f;->f:I

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x7

    iget v0, p0, Lcom/tencent/android/tpush/d/a/f;->f:I

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/4 v1, -0x1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    const/4 v2, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-string/jumbo v3, "rIppemutohushpulP"

    const-string/jumbo v3, "putPpeuhrIOhmposl"

    const-string v3, "OtherPushOppoImpl"

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-ne v0, v1, :cond_1

    const/4 v9, 0x3

    xor-int/2addr v10, v9

    const-string/jumbo p1, "ig nu dppMipos psosks"

    const-string p1, "Missing oppo push sdk"

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    return-object v2

    :cond_1
    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/f;->d:Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-nez v1, :cond_4

    const/4 v9, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/16 v1, 0xd2

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    const/4 v4, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    if-eq v0, v1, :cond_3

    const/4 v9, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    const/16 v1, 0x12c

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-ne v0, v1, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x5

    goto :goto_0

    :cond_2
    :try_start_0
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    const-string/jumbo v1, "pegtcannqsI"

    const-string/jumbo v1, "ncgtIneptsa"

    const/4 v10, 0x5

    const-string v1, "getInstance"

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v0, v1, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v0, v1, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->d:Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    goto/16 :goto_1

    :cond_3
    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v9, 0x0

    move v10, v9

    new-array v1, v4, [Ljava/lang/Class;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    new-array v1, v4, [Ljava/lang/Object;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->d:Ljava/lang/Object;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string/jumbo v1, "iitn"

    const-string/jumbo v1, "tini"

    const/4 v10, 0x3

    const-string/jumbo v1, "itin"

    const-string/jumbo v1, "init"

    const/4 v10, 0x4

    const/4 v5, 0x1

    const/4 v10, 0x1

    const/4 v5, 0x2

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x6

    new-array v6, v5, [Ljava/lang/Class;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-class v7, Landroid/content/Context;

    const-class v7, Landroid/content/Context;

    const-class v7, Landroid/content/Context;

    const-class v7, Landroid/content/Context;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    aput-object v7, v6, v4

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    sget-object v7, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/4 v8, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    aput-object v7, v6, v8

    const/4 v10, 0x4

    invoke-virtual {v0, v1, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v10, 0x0

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    aput-object p1, v5, v4

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    aput-object v4, v5, v8

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v0, v1, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :goto_1
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string/jumbo v1, "pGsi: noeaasuctpeqreMsptnhg  a"

    const-string v1, "e searaeqtpinu:Gncgsahon  tMpp"

    const/4 v10, 0x4

    const-string/jumbo v1, "ptemocisG hsaaanpno t M:rengpe"

    const-string v1, "Get oppo pushManager instance:"

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/f;->d:Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/f;->d:Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x2

    const/4 v9, 0x7

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string/jumbo v0, "ptelom rrtEsgran seInc"

    const-string v0, "EgsInsn trmrael pcrote"

    const/4 v10, 0x0

    const-string/jumbo v0, "srI lbnreEarIegtt mcpo"

    const-string v0, "getImplInstance Error "

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {v3, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    goto/16 :goto_2

    :catch_0
    move-exception v0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x3

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-string/jumbo v5, "oiImi ce Eea:tro r nInnofspctgacneeoogvttmrtpralExrTI"

    const/4 v10, 0x0

    const-string v5, "getImplInstance Error for InvocationTargetException: "

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-static {v3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    move v10, v9

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/f;->a:Ljava/lang/StringBuffer;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-string v4, "C5d:o-u, r5rgo1  Meee r :s"

    const-string v4, ",5 soCe15: rro dMe  -eg r:"

    const/4 v10, 0x0

    const-string v4, "C : soepg,e5 5  dMer1r-: r"

    const-string v4, "errCode : -155 , errMsg : "

    const/4 v9, 0x1

    move v10, v9

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    const-string/jumbo v1, "r_hrtbocrse_oruohepd_"

    const/4 v10, 0x7

    const-string v1, "cr_uedreqhooorprt__es"

    const-string/jumbo v1, "other_push_error_code"

    const/4 v9, 0x7

    move v10, v9

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_2
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/f;->d:Ljava/lang/Object;

    :cond_4
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/f;->d:Ljava/lang/Object;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x1

    return-object p1
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string/jumbo v0, "oppo"

    const-string/jumbo v0, "oopp"

    const/4 v2, 0x3

    const-string/jumbo v0, "popo"

    const-string/jumbo v0, "oppo"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public a(Landroid/content/Context;)V
    .locals 13

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x0

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v12, 0x0

    const/4 v11, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpush/d/a/f;->a:Ljava/lang/StringBuffer;

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x7

    iget-boolean v1, p0, Lcom/tencent/android/tpush/d/a/f;->e:Z

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x6

    const-string/jumbo v2, "rushrs_tecee_uoohoprr"

    const-string v2, "_eroroutu_r_eroshhcep"

    const/4 v12, 0x0

    const-string/jumbo v2, "peomhrt_rh_r_roeouedc"

    const-string/jumbo v2, "other_push_error_code"

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x0

    const/4 v3, 0x4

    const/4 v11, 0x4

    move v12, v11

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x6

    const-string/jumbo v5, "oreOolphsphuOmppt"

    const-string/jumbo v5, "oehtIOhppsulppmrO"

    const/4 v12, 0x4

    const-string v5, "OtherPushOppoImpl"

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x3

    if-nez v1, :cond_0

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x7

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    const/16 v6, 0x1a

    const/4 v12, 0x4

    const/4 v11, 0x2

    if-lt v1, v6, :cond_0

    :try_start_0
    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x0

    const-string v1, "atinfbionqoi"

    const-string/jumbo v1, "nfaiitotqnoi"

    const/4 v12, 0x4

    const-string/jumbo v1, "inoaotucifit"

    const-string/jumbo v1, "notification"

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {p1, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x3

    check-cast v1, Landroid/app/NotificationManager;

    const/4 v12, 0x7

    invoke-static {}, Landroidx/core/app/o0;->a()V

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x3

    const-string v6, "_sueaadpmefgsel"

    const-string v6, "gase_salfetmdeu"

    const-string v6, "efeumsg_qetslad"

    const-string v6, "default_message"

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x7

    const-string v7, "5ase9087u/md7ue/48ab/19u"

    const-string v7, "9eam780u/1udu84/a/ub9e75"

    const/4 v12, 0x0

    const-string v7, "18em0duau/9874//a5/uueb9"

    const-string/jumbo v7, "\u9ed8\u8ba4\u901a\u77e5"

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-static {v6, v7, v3}, Landroidx/browser/trusted/j;->a(Ljava/lang/String;Ljava/lang/CharSequence;I)Landroid/app/NotificationChannel;

    move-result-object v6

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x3

    if-eqz v1, :cond_0

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x7

    invoke-static {v1, v6}, Landroidx/browser/trusted/e;->a(Landroid/app/NotificationManager;Landroid/app/NotificationChannel;)V

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x7

    iput-boolean v4, p0, Lcom/tencent/android/tpush/d/a/f;->e:Z

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    const-string/jumbo v1, "puh o unscacoorsae tes choeeslnp"

    const-string v1, "ehupoacoesac suptensleohp srn c "

    const/4 v12, 0x6

    const-string v1, "create oppo push channle success"

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-static {v5, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x6

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x3

    const-string v6, "hleonbncabarcp:trrs  h ep er poe"

    const-string v6, "  el bep naroeprnh ep:arstoochrc"

    const/4 v12, 0x1

    const-string/jumbo v6, "rocpclueoa eep paorhrn:h tr us n"

    const-string v6, "create oppo push channle error: "

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-static {v5, v6, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v12, 0x4

    const/4 v11, 0x5

    iget-object v6, p0, Lcom/tencent/android/tpush/d/a/f;->a:Ljava/lang/StringBuffer;

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x2

    const-string v8, "0grer 1p:r,od 5er: u -C Me"

    const-string v8, "g 01C ure e e o:rr 5-r,:Md"

    const/4 v12, 0x6

    const-string v8, "gerr - :qdr1  , :0sr eMeC5"

    const-string v8, "errCode : -150 , errMsg : "

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {v1}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x0

    const/4 v11, 0x7

    invoke-virtual {v6, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-virtual {v6}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x6

    const/4 v11, 0x3

    invoke-static {p1, v2, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    sget-object v1, Lcom/tencent/android/tpush/d/d;->e:Ljava/lang/String;

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x0

    if-eqz v1, :cond_1

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x3

    const-string p1, " Ap hsep orleKPoEruiloprortgprnp  sefur"

    const/4 v12, 0x5

    const-string/jumbo p1, "registerPush Error for oppo null AppKey"

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-static {v5, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x3

    return-void

    :cond_1
    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x3

    sget-object v1, Lcom/tencent/android/tpush/d/d;->f:Ljava/lang/String;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v12, 0x0

    const/4 v11, 0x5

    if-eqz v1, :cond_2

    const/4 v12, 0x0

    const/4 v11, 0x3

    const-string p1, " esroterc hPsprlfppErolunr etgpusrr oSAe q"

    const-string p1, "etetprupqso ouEl r perfh SpPorolsArcre rng"

    const/4 v12, 0x3

    const-string p1, "hooms  epuotcSnurlsErepipoArp  Pgtrlrref r"

    const-string/jumbo p1, "registerPush Error for oppo null AppSecret"

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-static {v5, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x0

    return-void

    :cond_2
    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/f;->g(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v1

    const/4 v12, 0x0

    const/4 v11, 0x0

    if-eqz v1, :cond_4

    :try_start_1
    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x4

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x1

    const-string v7, "eo soiigg!orpese btr"

    const-string/jumbo v7, "posrieg p!teebg iosr"

    const/4 v12, 0x1

    const-string v7, "gi!ppbbree egsionr o"

    const-string v7, "begin oppo register!"

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x7

    sget-object v7, Lcom/tencent/android/tpush/d/d;->e:Ljava/lang/String;

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x0

    const-string v7, " "

    const-string v7, " "

    const/4 v12, 0x6

    const-string v7, " "

    const-string v7, " "

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    sget-object v7, Lcom/tencent/android/tpush/d/d;->f:Ljava/lang/String;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-static {v5, v6}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x3

    iget-object v6, p0, Lcom/tencent/android/tpush/d/a/f;->c:Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x4

    const/4 v7, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x6

    if-nez v6, :cond_3

    const/4 v12, 0x6

    const/4 v11, 0x7

    new-instance v6, Lcom/tencent/android/tpush/d/a/f$a;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-direct {v6, p0, p1}, Lcom/tencent/android/tpush/d/a/f$a;-><init>(Lcom/tencent/android/tpush/d/a/f;Landroid/content/Context;)V

    const/4 v12, 0x0

    iget-object v8, p0, Lcom/tencent/android/tpush/d/a/f;->h:Ljava/lang/Class;

    const/4 v12, 0x0

    const/4 v11, 0x6

    invoke-virtual {v8}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v8

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    new-array v9, v4, [Ljava/lang/Class;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    iget-object v10, p0, Lcom/tencent/android/tpush/d/a/f;->h:Ljava/lang/Class;

    const/4 v12, 0x7

    const/4 v11, 0x0

    aput-object v10, v9, v7

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-static {v8, v9, v6}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v6

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x7

    iput-object v6, p0, Lcom/tencent/android/tpush/d/a/f;->c:Ljava/lang/Object;

    :cond_3
    const/4 v12, 0x2

    const/4 v11, 0x5

    new-array v6, v3, [Ljava/lang/Class;

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x7

    const-class v8, Landroid/content/Context;

    const-class v8, Landroid/content/Context;

    const-class v8, Landroid/content/Context;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x3

    aput-object v8, v6, v7

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x1

    aput-object v0, v6, v4

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    const/4 v8, 0x2

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x1

    aput-object v0, v6, v8

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->h:Ljava/lang/Class;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    const/4 v9, 0x3

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x5

    aput-object v0, v6, v9

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x3

    const-string/jumbo v10, "iermtrug"

    const-string/jumbo v10, "tgemeirr"

    const/4 v12, 0x6

    const-string v10, "greisetp"

    const-string/jumbo v10, "register"

    const/4 v11, 0x5

    move v12, v11

    invoke-virtual {v0, v10, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x2

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x5

    aput-object p1, v3, v7

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x6

    sget-object v6, Lcom/tencent/android/tpush/d/d;->e:Ljava/lang/String;

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x2

    aput-object v6, v3, v4

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x4

    sget-object v4, Lcom/tencent/android/tpush/d/d;->f:Ljava/lang/String;

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x3

    aput-object v4, v3, v8

    const/4 v11, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x3

    iget-object v4, p0, Lcom/tencent/android/tpush/d/a/f;->c:Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x0

    aput-object v4, v3, v9

    const/4 v12, 0x6

    invoke-virtual {v0, v1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    const-string v0, "crnroc hgesuipe Pateosenusl p houspshs"

    const/4 v12, 0x0

    const-string v0, "enugplh q sssneerpsotPcucspachoeruih s"

    const-string/jumbo v0, "registerPush oppo push channel success"

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-static {v5, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x3

    iget v0, p0, Lcom/tencent/android/tpush/d/a/f;->f:I

    if-lt v0, v8, :cond_4

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x1

    sget-object v0, Lcom/tencent/android/tpush/d/d;->g:Ljava/lang/Boolean;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v12, 0x5

    const/4 v11, 0x4

    if-eqz v0, :cond_4

    const/4 v12, 0x3

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v11, 0x0

    shl-int/2addr v12, v11

    const-string/jumbo v3, "imeeibosfcPnuNnqitoaetrssioti"

    const/4 v12, 0x2

    const-string/jumbo v3, "irsanecioiuftsemreqosoniNsttP"

    const-string/jumbo v3, "requestNotificationPermission"

    const/4 v12, 0x7

    const/4 v11, 0x2

    new-array v4, v7, [Ljava/lang/Class;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-virtual {v0, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v12, 0x2

    const/4 v11, 0x3

    new-array v3, v7, [Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-virtual {v0, v1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x7

    goto :goto_1

    :catchall_1
    move-exception v0

    const/4 v12, 0x6

    const/4 v11, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x0

    const-string/jumbo v3, "orrmab T: Pwg eeusihereslt"

    const-string v3, "iPes uuwes:ar l hrgeTeobrt"

    const/4 v12, 0x6

    const-string/jumbo v3, "registerPush Throwable e: "

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x5

    const/4 v11, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-static {v5, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/f;->a:Ljava/lang/StringBuffer;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-string v4, ",rr5drMp-: es1:  eeo  Cg 1"

    const/4 v12, 0x4

    const-string v4, "1Cedo rr:rrs:-eg,M o 1e5  "

    const-string v4, "errCode : -151 , errMsg : "

    const/4 v11, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v11, 0x5

    or-int/2addr v12, v11

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-static {p1, v2, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    :goto_1
    const/4 v12, 0x6

    return-void
.end method

.method public b(Landroid/content/Context;)V
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string v0, "eOPlpbqpIoOphtrmu"

    const-string/jumbo v0, "uhrPpesOqmoppIOtl"

    const/4 v7, 0x1

    const-string v0, "OtherPushOppoImpl"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/f;->a:Ljava/lang/StringBuffer;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-nez v1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput-object v1, p0, Lcom/tencent/android/tpush/d/a/f;->a:Ljava/lang/StringBuffer;

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/f;->g(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v1, :cond_1

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string/jumbo v3, "uegnsRuert"

    const-string/jumbo v3, "nrseesRgtu"

    const/4 v7, 0x4

    const-string/jumbo v3, "rutnRespgi"

    const-string/jumbo v3, "unRegister"

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v4, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v2, v3, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    new-array v3, v4, [Ljava/lang/Object;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v2, v1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string/jumbo v1, "ussPnppeq os hcnc psehehorilume sugcantu"

    const-string/jumbo v1, "n hmetsucahspPpocgu s ueeosphelcsnuis nr"

    const-string/jumbo v1, "uns lir nhe Pcoahsehupeerss tsgounspupcs"

    const-string/jumbo v1, "unregisterPush oppo push channel success"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto/16 :goto_0

    :catchall_0
    move-exception v1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo v3, "tP mrih:geT eerbsrwh ouenuso"

    const-string v3, " oueorhitn b ahsersPerguTwe:"

    const/4 v7, 0x5

    const-string v3, "e tsouera:ro glTrwhebun hPse"

    const-string/jumbo v3, "unregisterPush Throwable e: "

    const/4 v6, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x3

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->a:Ljava/lang/StringBuffer;

    const/4 v6, 0x1

    move v7, v6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string v3, "5 d-rbor eCg 2errMs:  1: ,"

    const/4 v7, 0x3

    const-string v3, "1-ee:b5s   MCor2,r rde r: "

    const-string v3, "errCode : -152 , errMsg : "

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string v1, "cpo_truroehsed_rheuu_"

    const-string/jumbo v1, "p_uertuee_rchrhorsdo_"

    const/4 v7, 0x4

    const-string v1, "_hrtueopo_esreorrh_pd"

    const-string/jumbo v1, "other_push_error_code"

    const/4 v6, 0x3

    move v7, v6

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    return-void
.end method

.method public c(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/f;->b:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const-string/jumbo v0, "kppnetp_qo"

    const-string/jumbo v0, "otkppnop_e"

    const/4 v3, 0x1

    const-string v0, "eos_npktoo"

    const-string/jumbo v0, "oppo_token"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/f;->b:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/f;->b:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object p1
.end method

.method public d(Landroid/content/Context;)Z
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    sget-object v0, Lcom/tencent/android/tpush/d/d;->e:Ljava/lang/String;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    if-nez v0, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    sget-object v0, Lcom/tencent/android/tpush/d/d;->f:Ljava/lang/String;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-eqz v0, :cond_1

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v0, 0x6

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;I)V

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    sget-object v0, Lcom/tencent/android/tpush/d/d;->e:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string v1, "hhPmmIqsupptOrOeo"

    const-string/jumbo v1, "tOusePomqlIhrOphp"

    const/4 v8, 0x4

    const-string v1, "hOtsoheuPolppOIrp"

    const-string v1, "OtherPushOppoImpl"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/4 v2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-eqz v0, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    const-string p1, "eppspbl  tsrorainrrerEPo  gdlopirof uh"

    const-string p1, "gdsuolil pp pt  afsorrrrnhioerreE ouPp"

    const-string/jumbo p1, "po rgsuiao Elnppls ourrr opre heitdruf"

    const-string/jumbo p1, "registerPush Error for oppo null appid"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    return v2

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    sget-object v0, Lcom/tencent/android/tpush/d/d;->f:Ljava/lang/String;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-eqz v0, :cond_3

    const/4 v8, 0x2

    const/4 v7, 0x4

    const-string/jumbo p1, "r op  ipr pAoruPsongpsrlhrEteo klymuermie"

    const-string/jumbo p1, "rremi opeiAEkp rhsopuPs nre mtfryl uolorg"

    const/4 v8, 0x6

    const-string p1, "foms pr qtAousrkrypPop rliprgen heuolE er"

    const-string/jumbo p1, "registerPush Error for oppo null miAppkey"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    return v2

    :cond_3
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/f;->g(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-eqz v0, :cond_6

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x6

    iget v3, p0, Lcom/tencent/android/tpush/d/a/f;->f:I
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    const/16 v4, 0xd2

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string/jumbo v5, "iussstPoSpruh"

    const-string/jumbo v5, "uuiroPtosShps"

    const/4 v8, 0x4

    const-string/jumbo v5, "tpumirPSsspoh"

    const-string/jumbo v5, "isSupportPush"

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-ne v3, v4, :cond_4

    :try_start_1
    const/4 v8, 0x4

    const/4 v7, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v7, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p1, v5, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    new-array v3, v2, [Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p1, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    check-cast p1, Ljava/lang/Boolean;

    const/4 v7, 0x0

    move v8, v7

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    goto :goto_0

    :cond_4
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 v3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-class v6, Landroid/content/Context;

    const-class v6, Landroid/content/Context;

    const/4 v8, 0x3

    const-class v6, Landroid/content/Context;

    const-class v6, Landroid/content/Context;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    aput-object v6, v4, v2

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    iget-object v6, p0, Lcom/tencent/android/tpush/d/a/f;->g:Ljava/lang/Class;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v6, v5, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v7, 0x3

    or-int/2addr v8, v7

    aput-object p1, v3, v2

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v4, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    check-cast p1, Ljava/lang/Boolean;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-nez p1, :cond_5

    const/4 v8, 0x7

    const-string v0, "! pOoP ihpfoPrrtrstph hrhire sad tas,s)uOPnS  ostOPuOptipouepfv cbeuusn  sPe ol(u "

    const-string v0, "PPusob dotsetOe!praSpcsrsniuPhrfe tlp O u (s potP Optaoshife shriunrvP eh p) uOu ,"

    const/4 v8, 0x5

    const-string/jumbo v0, "sO sPbprusuupe SP!nspttvPp e reteu lhisOPfPpc u o dosin Ohp,ih)steoufroOr arth p( "

    const-string v0, "OPPO push api isSupportPush() returns false, the device not support for OPPO push!"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_5
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    return p1

    :catchall_0
    move-exception p1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string/jumbo v0, "roEsrCuiinr gof"

    const-string v0, " ErognufCiiorsr"

    const/4 v8, 0x3

    const-string/jumbo v0, "isConfig Error "

    const/4 v8, 0x7

    invoke-static {v1, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    goto :goto_1

    :catch_0
    move-exception p1

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string v3, "epnpgfoptcnvnag :iofrrstxTEooi ieaonoIct rri C"

    const-string/jumbo v3, "tTtenIppo g rnc:ovffoEtoornxac irrgnsar Cioiei"

    const/4 v8, 0x7

    const-string/jumbo v3, "oi:sinttqrroaIrc oe gaTgf efopnxtovocrC rEEini"

    const-string/jumbo v3, "isConfig Error for InvocationTargetException: "

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    :cond_6
    :goto_1
    const/4 v7, 0x3

    move v8, v7

    return v2
.end method

.method public e(Landroid/content/Context;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/4 p1, 0x6

    const/4 v1, 0x3

    return p1
.end method

.method public f(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x2

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-object p1
.end method
