.class Lcom/tencent/android/tpush/d/a/b$b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/reflect/InvocationHandler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/d/a/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/d/a/b;


# direct methods
.method private constructor <init>(Lcom/tencent/android/tpush/d/a/b;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/b$b;->a:Lcom/tencent/android/tpush/d/a/b;

    const/4 v1, 0x3

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/android/tpush/d/a/b;Lcom/tencent/android/tpush/d/a/b$1;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/b$b;-><init>(Lcom/tencent/android/tpush/d/a/b;)V

    const/4 v0, 0x6

    move v1, v0

    return-void
.end method


# virtual methods
.method public invoke(Ljava/lang/Object;Ljava/lang/reflect/Method;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~@s@ @@1~~~ o m~@o ~@M s @ 4Stt ~@@ bo~~fdfv@@~o~or ~@ ~- .yi~  n~luia~@@~@~ @~bc @/o@~bK~i~@/@l"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    if-nez p2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 p1, 0x0

    const/4 v4, 0x7

    return-object p1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo v0, "ucssscoSn"

    const/4 v4, 0x6

    const-string v0, "Scnmescus"

    const-string/jumbo v0, "onSuccess"

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v0, "pHlsonrhOIteuPmorh"

    const-string v0, "OtherPushHonorImpl"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz p1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string p1, "cremHosihurs UcentoesPugrs n"

    const/4 v4, 0x5

    const-string p1, "ceUsgbuhrHnsrsotoi eePcu rns"

    const-string p1, "HonorPush Unregister success"

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto/16 :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p2}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v1, "onlaoiuFu"

    const-string/jumbo v1, "naouoielF"

    const/4 v4, 0x6

    const-string v1, "iaFueorpl"

    const-string/jumbo v1, "onFailure"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz p1, :cond_2

    const/4 v4, 0x2

    if-eqz p3, :cond_2

    const/4 v3, 0x0

    move v4, v3

    array-length p1, p3

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, 0x2

    const/4 v4, 0x1

    if-lt p1, v1, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 p1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    aget-object p1, p3, p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    check-cast p1, Ljava/lang/Integer;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    aget-object p3, p3, v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    check-cast p3, Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo v2, "uoi b rnq h:sCiUldd,etsPrHeregofroaen "

    const-string v2, "Uoo ebiPserC euHgddi,a eresofnhn:tr rl"

    const/4 v4, 0x6

    const-string v2, "dhs re:PsreifC nd r ruereai,sotengHoUo"

    const-string v2, "HonorPush Unregister failed, errCode: "

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string p1, ",r me:e Mr"

    const-string p1, ", rMeeu r:"

    const/4 v4, 0x2

    const-string/jumbo p1, "re  oeMrg:"

    const-string p1, ", errMeg: "

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v4, 0x5

    return-object p2
.end method
