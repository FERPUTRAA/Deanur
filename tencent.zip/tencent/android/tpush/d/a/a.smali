.class public Lcom/tencent/android/tpush/d/a/a;
.super Lcom/tencent/android/tpush/d/c;


# instance fields
.field private a:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/c;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    return-void
.end method

.method private g(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~iss@@-o~v~@a@@u@l/@ @ ~~KS~d  y~~tml ~@i o ~M~ 4/@oofi ~o@br@~  1fo~~@@. b@~~~t@ @ @~cb~n@  ~~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/a;->a:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const-string v0, "_memntscf"

    const-string v0, "_msftecnk"

    const/4 v3, 0x5

    const-string/jumbo v0, "nmcfoetok"

    const-string v0, "fcm_token"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x4

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/a;->a:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/a;->a:Ljava/lang/String;

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    return-object p1
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo v0, "mfc"

    const-string v0, "cfm"

    const/4 v2, 0x3

    const-string v0, "fmc"

    const-string v0, "fcm"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public a(Landroid/content/Context;)V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string/jumbo v0, "uOmpcbmPIhlsehFt"

    const-string v0, "hOtmlhFceIrsmpuP"

    const/4 v7, 0x0

    const-string/jumbo v0, "tpsmmruchFleIPOu"

    const-string v0, "OtherPushFcmImpl"

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string v1, "cpstn..pdttpOl.dioahhhhPste.een.r.ouhrcmoipIuncmmslu.topfm"

    const-string/jumbo v1, "mppnorsconhetmh.r.hdsImmiusfOcht.hotlidot.etcpe.u.ePul.pan"

    const/4 v7, 0x1

    const-string v1, "ce.hs.tcqoe.htdhsn.milputdIurhilmuop.tfPerepntpcmO.shmrno."

    const-string v1, "com.tencent.android.tpush.otherpush.fcm.impl.OtherPushImpl"

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v2, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-class v4, Landroid/content/Context;

    const-class v4, Landroid/content/Context;

    const/4 v7, 0x0

    const-class v4, Landroid/content/Context;

    const-class v4, Landroid/content/Context;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x0

    move v7, v5

    const/4 v6, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    aput-object v4, v3, v5

    const/4 v7, 0x5

    const-string v4, "bPsgtsrhsere"

    const-string/jumbo v4, "irePgbrtsshe"

    const/4 v7, 0x6

    const-string v4, "Purmegsseith"

    const-string/jumbo v4, "registerPush"

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v1, v4, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    aput-object p1, v2, v5

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v3, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string v2, " ti?ohrr uchrPEg o reoeeu serMrorpuCa p t ty,ikssgaaorphmu"

    const-string/jumbo v2, "rrae uuoeur rp ?reuco,ry Mi hstEpieg tsoPaoCsgphthkrarem  "

    const/4 v7, 0x5

    const-string v2, "Pag obyprMoeu ,t aeim?rrErkrhFgotCe ipr h utupssree sahoc "

    const-string/jumbo v2, "registerPush FCM Error, are you import otherpush package? "

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v6, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string v2, "cicfhnuorvoaEETsoerprerI gMiFo:  pgttrta tnue reoxsriC"

    const-string v2, "g tMpaIpr:rceCTtErfr  srEtteForniohoeuagnnvc oisexi or"

    const/4 v7, 0x6

    const-string/jumbo v2, "sIpFanfpEveiuornre gtrorsctrC i rcxho tegotMEn:oe Piar"

    const-string/jumbo v2, "registerPush FCM Error for InvocationTargetException: "

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-void
.end method

.method public b(Landroid/content/Context;)V
    .locals 7

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v0, "iumsomItqmhhhdpirhonr.uo.sccnm.lpree.tplt.Pt.dh.sapteeufcO"

    const-string v0, "com.tencent.android.tpush.otherpush.fcm.impl.OtherPushImpl"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v1, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-array v2, v1, [Ljava/lang/Class;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-class v3, Landroid/content/Context;

    const-class v3, Landroid/content/Context;

    const/4 v6, 0x2

    const-class v3, Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    aput-object v3, v2, v4

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string/jumbo v3, "srPruhsequgeni"

    const-string/jumbo v3, "sgsurtunPsheie"

    const-string/jumbo v3, "unregisterPush"

    const/4 v6, 0x0

    invoke-virtual {v0, v3, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v5, 0x0

    move v6, v5

    aput-object p1, v1, v4

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {v2, v0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string/jumbo v1, "rEscr?yarsms,trohPgg o hC ioasatenpk urroupir Mee   heutFpre"

    const/4 v6, 0x3

    const-string/jumbo v1, "ukim ,r e r remcorpu  gFoPrrntassuCpEhuo geeiarreatphtsMh ?o"

    const-string/jumbo v1, "unregisterPush FCM Error, are you import otherpush package? "

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const-string v0, "OhueoFhtlcrPmmmI"

    const-string/jumbo v0, "plemtFchhOumPImr"

    const/4 v6, 0x0

    const-string v0, "eIOmcbruhlPFthmp"

    const-string v0, "OtherPushFcmImpl"

    const/4 v5, 0x0

    move v6, v5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    return-void
.end method

.method public c(Landroid/content/Context;)Ljava/lang/String;
    .locals 9

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string/jumbo v0, "psImuhucehlotPmO"

    const-string/jumbo v0, "uhlIomthFmOcsPep"

    const/4 v8, 0x0

    const-string v0, "OtherPushFcmImpl"

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v8, 0x4

    const-string v1, ""

    const-string v1, ""

    :try_start_0
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string v2, "i.h.iscp.n.emtmdpuhh.Iotmpoetltus.end.aprtbslurmchrpceonhO"

    const-string/jumbo v2, "tnnapb..idthOe.es.ifpcodurhlIochcpsrmtl.shthm.epoermu.untm"

    const/4 v8, 0x3

    const-string/jumbo v2, "uepdl.uiqdr.rueInlmhmmaPcop.Ochnh.hpcsteotrpstfts..thonime"

    const-string v2, "com.tencent.android.tpush.otherpush.fcm.impl.OtherPushImpl"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    const/4 v3, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-class v5, Landroid/content/Context;

    const-class v5, Landroid/content/Context;

    const/4 v8, 0x4

    const-class v5, Landroid/content/Context;

    const-class v5, Landroid/content/Context;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 v6, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    aput-object v5, v4, v6

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string/jumbo v5, "kosTeunt"

    const-string v5, "Tetonkug"

    const/4 v8, 0x2

    const-string v5, "getToken"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v2, v5, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    aput-object p1, v3, v6

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-virtual {v4, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/a;->g(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eqz v2, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static {v4}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-nez v4, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x0

    move v8, v7

    if-nez v3, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x5

    iput-object v3, p0, Lcom/tencent/android/tpush/d/a/a;->a:Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const-string/jumbo v3, "tckmpmnfe"

    const-string/jumbo v3, "kn_mcetpf"

    const/4 v8, 0x2

    const-string/jumbo v3, "kfm_oocnt"

    const-string v3, "fcm_token"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {p1, v3, v2}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    const-string v2, "edcs bMseusq,ercr reg0rs: o : "

    const-string v2, "  er  drq0Mrorus:ee:gc s,ssceC"

    const/4 v8, 0x5

    const-string/jumbo v2, "o ce ,ur0s Mrs gsers rcd:ue:Ce"

    const-string v2, "errCode : 0 , errMsg : success"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {p1, v0, v2}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const-string/jumbo v2, "rE oerkposegnt"

    const-string v2, "eEsror ekotngT"

    const-string v2, "getToken Error"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {v0, v2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string/jumbo v3, "rktonaonqgrocEeoini:rTvoc   xamTrtoEfre pIgetn"

    const-string/jumbo v3, "oEemIxrrt tgeeg:iinrtErToTeof k nonaccovaro np"

    const/4 v8, 0x6

    const-string v3, "ersonrnegrE:afex Igtcti oteoovTkEntairrpo c To"

    const-string v3, "getToken Error for InvocationTargetException: "

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    return-object v3
.end method

.method public d(Landroid/content/Context;)Z
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x0

    const-string/jumbo v1, "imamuI.rpt.pten.ehtfc.hdmsmshohno.piPm.clhOdrt.eurelusocto"

    const-string/jumbo v1, "muifoi.st.cu..hphprscholetoedhIdnPOrhslem.uttarnnemm.cpo.t"

    const/4 v4, 0x2

    const-string v1, ".mddore.osuttsuoni.phohImhh.tcePcipmnltue.pa..frernsmtlhpO"

    const-string v1, "com.tencent.android.tpush.otherpush.fcm.impl.OtherPushImpl"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p1, v1}, Lcom/tencent/android/tpush/d/a;->a(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-nez p1, :cond_0

    return v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 p1, 0x1

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    return p1

    :catchall_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v2, "iCbf bosi:"

    const-string/jumbo v2, "ioni bCsf:"

    const/4 v4, 0x5

    const-string v2, ":f Coiunsi"

    const-string/jumbo v2, "isConfig :"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string v1, "IlmpeturumhhFPOc"

    const/4 v4, 0x6

    const-string/jumbo v1, "urhhOePpmsItpFcm"

    const-string v1, "OtherPushFcmImpl"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    return v0
.end method

.method public e(Landroid/content/Context;)I
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    const/4 p1, 0x4

    const/4 v0, 0x0

    and-int/2addr v1, v0

    return p1
.end method

.method public f(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x2

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-object p1
.end method
