.class public Lcom/tencent/android/tpush/d/a/c;
.super Lcom/tencent/android/tpush/d/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/d/a/c$a;
    }
.end annotation


# instance fields
.field a:Landroid/content/Context;

.field b:Landroid/content/BroadcastReceiver;

.field c:Ljava/lang/String;

.field d:Ljava/lang/StringBuffer;

.field private e:I

.field private f:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/c;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->b:Landroid/content/BroadcastReceiver;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput v1, p0, Lcom/tencent/android/tpush/d/a/c;->e:I

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v3, 0x3

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/d/a/c;Ljava/lang/String;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " bs~~~if m f~ 4 @o~l~~@~@~~~o~ ~~@o@o~@@@@ K@ a@Sd s t@  cM~i@@~ot1@n@r~u~/i @ b@/b @y-.l@~ ~v~ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/c;->a(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method private a(Ljava/lang/String;)V
    .locals 5

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const-string/jumbo v1, "mEamicn.FnpsiCt.otoexBaKA.erEcDoigdnv..dct"

    const-string v1, "BDscid.Eo.Cotopnt.EemdAFevin..xacKtnancrig"

    const/4 v4, 0x6

    const-string/jumbo v1, "nccroenoDB.xie.CoatK..mdaignc.p.FAtiEEotvd"

    const-string v1, "com.tencent.android.xg.vip.action.FEEDBACK"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v1, "UmOCSbEEODR.HRT"

    const-string v1, "RSEmERUTRCO.DHO"

    const/4 v4, 0x5

    const-string v1, "OECDERuHSTRP.UO"

    const-string v1, "TPUSH.ERRORCODE"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v2, -0x1

    :goto_0
    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v1, "untkos_hotp_erho"

    const/4 v4, 0x7

    const-string/jumbo v1, "other_push_token"

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string p1, "KH.FbSTpEEBCPD"

    const-string p1, "DETHPbUSEB.CKF"

    const/4 v4, 0x0

    const-string p1, "KEA.EPFDqSCHBU"

    const-string p1, "TPUSH.FEEDBACK"

    const/4 v4, 0x2

    const/4 v1, 0x1

    const/4 v4, 0x7

    shl-int/2addr v3, v1

    const/4 v4, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string p1, "EAsuN.NPLSUH"

    const-string p1, "ENSNC.uHAPLU"

    const/4 v4, 0x0

    const-string p1, "SN.mEHPUNLHA"

    const-string p1, "PUSH.CHANNEL"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/16 v2, 0x66

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string p1, "OE.EoTTEUOKHYRHK.STpNPUS"

    const-string p1, "KHYPTTUpESKE.NUO.EHTPSOR"

    const/4 v4, 0x2

    const-string p1, "PUYSUbT.K.ONTEETSHPOEHKR"

    const-string p1, "TPUSH.OTHERPUSH.TOKENKEY"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string v2, "euhitku_qewo"

    const-string v2, "etekuhiaqo_w"

    const/4 v4, 0x7

    const-string v2, "_ehiuokptnea"

    const-string v2, "huawei_token"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const-string p1, "S.A.NTUNqDOETPUOT.TPHK"

    const-string p1, "TPUSH.NOT.UPDATE.TOKEN"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->onOtherPushRegister(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-void
.end method

.method private c()I
    .locals 7

    :try_start_0
    const/4 v6, 0x2

    const-string v0, ".sscacnn.smidd.esaHIhImaohm.iaset"

    const-string v0, ".isaeHsaah..mmead.IIndcitwnssohmc"

    const/4 v6, 0x4

    const-string v0, "enmmuacihds.cn.t.HswIeodIshmaa.am"

    const-string v0, "com.huawei.hms.aaid.HmsInstanceId"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v0, 0x3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    return v0

    :catchall_0
    :try_start_1
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string v0, "hhmnotaoa.AeH.uneimedas.wdn.SigMomc.r"

    const-string/jumbo v0, "inhmcSuoa.rMadnemA.h.geas.eHwntodmi.g"

    const/4 v6, 0x2

    const-string/jumbo v0, "rudwMbnigAmo.annHg.dm.hethie.acSo.tea"

    const-string v0, "com.huawei.android.hms.agent.HMSAgent"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x7

    const/4 v0, 0x2

    move v5, v0

    move v5, v0

    const/4 v6, 0x1

    return v0

    :catchall_1
    move-exception v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v1, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/c;->a:Landroid/content/Context;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v4, "e:Mrr:u o   g-e1rdC eosr ,"

    const-string v4, " Cr o, 1 rg::oMee srerd-1 "

    const/4 v6, 0x6

    const-string/jumbo v4, "o 1rC  pe1rerdr:s -:eM, g "

    const-string v4, "errCode : -121 , errMsg : "

    const/4 v5, 0x7

    shl-int/2addr v6, v5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string v2, "e__dreeoqrubtohcp_orr"

    const-string v2, "_h_usborep_dceoortrre"

    const/4 v6, 0x4

    const-string v2, "_estprhs_oeudorcr_eho"

    const-string/jumbo v2, "other_push_error_code"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v0, -0x1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    return v0
.end method

.method private h(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->b:Landroid/content/BroadcastReceiver;

    const/4 v5, 0x7

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance v0, Lcom/tencent/android/tpush/d/a/c$1;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/d/a/c$1;-><init>(Lcom/tencent/android/tpush/d/a/c;)V

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->b:Landroid/content/BroadcastReceiver;

    :try_start_0
    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance v0, Landroid/content/IntentFilter;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {v0}, Landroid/content/IntentFilter;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const-string/jumbo v1, "twdmhRi.imdhueuOoie..tNuGIrTsAToSa.n.naIncp"

    const-string v1, ".iRtncuOn.se..ihupue.tEoawhiTTraSNIdnAmGodI"

    const/4 v5, 0x1

    const-string/jumbo v1, "tnehoEn.aGo..pOricdR.oTiwsNmht.IuaASnRTdIei"

    const-string v1, "com.huawei.android.push.intent.REGISTRATION"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v1, "ht.RobEi.apuVeCi.dcwiIsEount.hd.rmepEn"

    const-string/jumbo v1, "rihni.VpEwRtuuoi.e..CdtcnIdEspmEh.noea"

    const/4 v5, 0x6

    const-string v1, ".VctIiuCs.EothaRdEduoeEmanwn..ruienip."

    const-string v1, "com.huawei.android.push.intent.RECEIVE"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v1, "AthUHwnpqSemeSncou_n.aEtP..ioiTTa.c"

    const-string v1, "SP.ucSetq_hcUmTiEoAo.aentnTHniiaw.."

    const/4 v5, 0x7

    const-string v1, "UnAT_nocqtitSSm.itE.eaewhuainHoTc.P"

    const-string v1, "com.huawei.intent.action.PUSH_STATE"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x7

    const/16 v2, 0x21

    if-lt v1, v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/c;->b:Landroid/content/BroadcastReceiver;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v2, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p1, v1, v0, v2}, Ld3/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/c;->b:Landroid/content/BroadcastReceiver;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p1, v1, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v1, "etsuiOWePlhrusmphIH"

    const-string v1, "OtherPushHuaWeiImpl"

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v2, "rvemtreRserieeergc sio"

    const-string v2, "erseeeRctirr ivoresegr"

    const/4 v5, 0x4

    const-string/jumbo v2, "registerReceiver error"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v3, ":,d o 2r9-eeme:  orM rr1s "

    const-string v3, "-rem er1  r,2d:rC :oes M9 "

    const/4 v5, 0x7

    const-string/jumbo v3, "rr, 9b e rg M 1d-:e:Ce2s o"

    const-string v3, "errCode : -129 , errMsg : "

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v1, "o_o_rsuudocoe_trehehr"

    const-string v1, "ee__ohodrhro_serucort"

    const/4 v5, 0x0

    const-string/jumbo v1, "urreeprp_ohsrd_cehoot"

    const-string/jumbo v1, "other_push_error_code"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string v0, "ehqwba"

    const-string v0, "ahuewb"

    const/4 v2, 0x1

    const-string v0, "aishwu"

    const-string v0, "huawei"

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public a(Landroid/content/Context;)V
    .locals 13

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x5

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v12, 0x4

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x1

    const-string/jumbo v1, "uprmt_r_edus_oorcehho"

    const-string/jumbo v1, "s_ocdtuo__pruherrreho"

    const/4 v12, 0x0

    const-string v1, "hrs_ooorpotrrheu_ceed"

    const-string/jumbo v1, "other_push_error_code"

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/c;->a:Landroid/content/Context;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x3

    new-instance v2, Ljava/lang/StringBuffer;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v12, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string v2, "hsieubitrt opuw saehrgpeseuhrh"

    const-string/jumbo v2, "thrpigep seiawehue rrsh tusohu"

    const/4 v12, 0x0

    const-string/jumbo v2, "w eoahueusptiuurPe hrt ihehgss"

    const-string/jumbo v2, "other push huawei registerPush"

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-string/jumbo v3, "reqOPHepIhihultumas"

    const-string/jumbo v3, "uePHIshiqelOWrathum"

    const/4 v12, 0x5

    const-string/jumbo v3, "rushlumpqPeaeOtIHhi"

    const-string v3, "OtherPushHuaWeiImpl"

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/c;->h(Landroid/content/Context;)V

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget v2, p0, Lcom/tencent/android/tpush/d/a/c;->e:I

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x1

    if-nez v2, :cond_0

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/a/c;->c()I

    move-result v2

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x2

    iput v2, p0, Lcom/tencent/android/tpush/d/a/c;->e:I

    :cond_0
    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x5

    const/4 v11, 0x0

    const-string v4, " DsSoniGe sr etv HK:"

    const-string/jumbo v4, "nosGiHSW Dt e: Kv er"

    const/4 v12, 0x7

    const-string/jumbo v4, "t smoi:D eK SvGrnWe "

    const-string v4, "Get HW SDK version: "

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x2

    iget v4, p0, Lcom/tencent/android/tpush/d/a/c;->e:I

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x6

    iget v2, p0, Lcom/tencent/android/tpush/d/a/c;->e:I

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x5

    const/4 v4, 0x3

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x0

    const/4 v5, 0x2

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x7

    const/4 v6, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x5

    const/4 v7, 0x1

    const/4 v12, 0x5

    if-ne v2, v4, :cond_3

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x1

    const-string v4, "cstIoeneatg"

    const-string v4, "getInstance"

    const/4 v12, 0x2

    new-array v8, v7, [Ljava/lang/Class;

    const-class v9, Landroid/content/Context;

    const-class v9, Landroid/content/Context;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x7

    aput-object v9, v8, v6

    const/4 v11, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x7

    invoke-virtual {v2, v4, v8}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v12, 0x0

    const/4 v11, 0x0

    iget-object v4, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    new-array v8, v7, [Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x3

    aput-object p1, v8, v6

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-virtual {v2, v4, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    iget-object v4, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string v8, "gekmToen"

    const-string v8, "Ttgonbee"

    const-string v8, "getToken"

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x0

    new-array v9, v5, [Ljava/lang/Class;

    const/4 v12, 0x2

    const/4 v11, 0x4

    aput-object v0, v9, v6

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x0

    aput-object v0, v9, v7

    const/4 v12, 0x6

    const/4 v11, 0x0

    invoke-virtual {v4, v8, v9}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/d/a/c;->g(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x0

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    shr-int/2addr v12, v11

    const-string/jumbo v9, "trfaWou dop apGImHp:  g "

    const-string v9, "dH WooprmfIpp cat  :agG "

    const/4 v12, 0x5

    const-string v9, "Get HW appId from agcp: "

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v12, 0x0

    const/4 v11, 0x5

    invoke-static {v3, v8}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    aput-object v4, v5, v6

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x0

    const-string v4, "HCM"

    const-string v4, "MHC"

    const/4 v12, 0x6

    const-string v4, "CMH"

    const-string v4, "HCM"

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x2

    aput-object v4, v5, v7

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {v0, v2, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x0

    if-eqz v0, :cond_2

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x0

    if-nez v2, :cond_2

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x3

    const-string v4, "ekHGnt p W bet"

    const-string v4, "eH GWb: nk ett"

    const/4 v12, 0x4

    const-string v4, "HGoket :q neW "

    const-string v4, "Get HW token: "

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x2

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/d/a/c;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x7

    if-nez v2, :cond_1

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x0

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/c;->c:Ljava/lang/String;

    const/4 v11, 0x1

    const/4 v12, 0x3

    const-string/jumbo v4, "n_suaeetohuw"

    const-string v4, "_ewaonuhtuie"

    const-string/jumbo v4, "owemhnua_iet"

    const-string v4, "huawei_token"

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-static {p1, v4, v2}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-direct {p0, v0}, Lcom/tencent/android/tpush/d/a/c;->a(Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x6

    const-string/jumbo v0, "rs poec,os eg0rc :urC  Mrs: de"

    const-string/jumbo v0, "rr:CgrspM , oes   :udes0 rscce"

    const/4 v12, 0x1

    const-string/jumbo v0, "ssec bdr:C0o regcesr   : Mers,"

    const-string v0, "errCode : 0 , errMsg : success"

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-static {p1, v3, v0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x4

    goto/16 :goto_0

    :cond_2
    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x4

    const-string v0, "Get HW token from HWS.getToken null or empty, get it from receiver"

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x2

    goto/16 :goto_0

    :cond_3
    const/4 v12, 0x3

    const/4 v11, 0x4

    if-ne v2, v5, :cond_4

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const-string/jumbo v2, "niit"

    const-string/jumbo v2, "tiin"

    const/4 v12, 0x6

    const-string/jumbo v2, "inti"

    const-string/jumbo v2, "init"

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    new-array v4, v7, [Ljava/lang/Class;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x4

    const-class v8, Landroid/app/Application;

    const-class v8, Landroid/app/Application;

    const/4 v12, 0x1

    const-class v8, Landroid/app/Application;

    const-class v8, Landroid/app/Application;

    const/4 v12, 0x6

    aput-object v8, v4, v6

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    new-array v4, v7, [Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v8

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x5

    aput-object v8, v4, v6

    const/4 v11, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {v0, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x5

    const-string/jumbo v0, "loremHudenqtencar.n.ccg.snm.dhum.md.heoae.rCdantahlwnniooi"

    const-string/jumbo v0, "oe.udmCoqirerdnhamodmc.ldte.n.lhsrwa.ncmoaicn.eo.enngtnHha"

    const-string/jumbo v0, "n.aierepudt.cmncmeHnlonoCietahcdhm.mo.aslaar.ddnen.wrgnooh"

    const-string v0, "com.huawei.android.hms.agent.common.handler.ConnectHandler"

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x2

    new-instance v2, Lcom/tencent/android/tpush/d/a/c$a;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-direct {v2, p0}, Lcom/tencent/android/tpush/d/a/c$a;-><init>(Lcom/tencent/android/tpush/d/a/c;)V

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget-object v4, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-virtual {v4}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v4

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    new-array v8, v7, [Ljava/lang/Class;

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x0

    aput-object v0, v8, v6

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x3

    invoke-static {v4, v8, v2}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x0

    const-string v8, "cqtecns"

    const-string/jumbo v8, "ntsecnc"

    const/4 v12, 0x0

    const-string/jumbo v8, "tnsncco"

    const-string v8, "connect"

    const/4 v12, 0x2

    const/4 v11, 0x1

    new-array v9, v5, [Ljava/lang/Class;

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x1

    const-class v10, Landroid/app/Activity;

    const-class v10, Landroid/app/Activity;

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x3

    aput-object v10, v9, v6

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x4

    aput-object v0, v9, v7

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-virtual {v4, v8, v9}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x0

    const/4 v8, 0x0

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x3

    aput-object v8, v5, v6

    const/4 v12, 0x0

    aput-object v2, v5, v7

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-virtual {v0, v4, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    goto/16 :goto_0

    :cond_4
    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x5

    const/4 v0, -0x1

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x1

    if-eq v2, v0, :cond_5

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x5

    goto/16 :goto_0

    :cond_5
    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v12, 0x2

    const-string v2, "2sem h2sirC M di-g reeS eruHK,M1r:e  mirWS gsvs conD"

    const-string v2, "M-rm  rMW,di:Cnr:Sgcrs Ke2 v2ioshiDeH r eue es  1gsS"

    const/4 v12, 0x4

    const-string v2, " geeorr  HCiSD 1iev2ru,-sWS:dncPrKesroe2 g Ms  i shM"

    const-string v2, "errCode : -122 , errMsg : Missing HWPush Service SDK"

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x3

    const/4 v11, 0x6

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string/jumbo v0, "iinKsbS S  ecvPsoiWsuerHMD"

    const-string v0, "iP soSs KeHsWiigS DMcrenvu"

    const/4 v12, 0x2

    const-string/jumbo v0, "ue PevuSinHssWD McgiK hirS"

    const-string v0, "Missing HWPush Service SDK"

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    new-instance v0, Ljava/lang/Exception;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x3

    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    move-exception v0

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x0

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-virtual {v0}, Ljava/lang/Throwable;->getCause()Ljava/lang/Throwable;

    move-result-object v4

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-static {v3, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-string v4, "g,bo:2ep 3dCr-rr rsM:1  e"

    const-string v4, "- ds1b::M,eo err r 2r3 Cg"

    const/4 v12, 0x7

    const-string v4, "-d1,:s rqe Mgoe 3 r2Cer r"

    const-string v4, "errCode : -123 , errMsg :"

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x6

    const/4 v11, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x7

    return-void
.end method

.method public b()V
    .locals 9

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string v0, "emsMeiSamstgnhwiA$hdngnaodace.Puo..hurH.ut"

    const-string/jumbo v0, "mhM.uouna.$oweHSag.naPhdsAdicrhuitmeegts.n"

    const/4 v8, 0x6

    const-string v0, "dgcmo.o.e$s.uenmhM.wttangaaPdiAheHumiSrs.n"

    const-string v0, "com.huawei.android.hms.agent.HMSAgent$Push"

    const/4 v8, 0x1

    const/4 v7, 0x3

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string v1, "aonlotGnr.otlhrhephuang.u.dw.dan.eresnTpeimhe.eik.cHaomds"

    const-string v1, ".rssor.pntlgh.cewmaieruedpdonhuk.eld.TaehnHiGaad..thenonm"

    const/4 v8, 0x6

    const-string v1, "ernGibkTemaHpinhrsago..oenadaacmh.n..twels.deehdnuhtluo.r"

    const-string v1, "com.huawei.android.hms.agent.push.handler.GetTokenHandler"

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    new-instance v2, Lcom/tencent/android/tpush/d/a/c$a;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-direct {v2, p0}, Lcom/tencent/android/tpush/d/a/c$a;-><init>(Lcom/tencent/android/tpush/d/a/c;)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/4 v4, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x4

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v6, 0x0

    const/4 v8, 0x6

    aput-object v1, v5, v6

    const/4 v7, 0x1

    or-int/2addr v8, v7

    invoke-static {v3, v5, v2}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string v3, "ekTetnuq"

    const-string/jumbo v3, "qnetkTeo"

    const/4 v8, 0x5

    const-string/jumbo v3, "tgTkneop"

    const-string v3, "getToken"

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x6

    aput-object v1, v5, v6

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v0, v3, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    new-array v3, v4, [Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    aput-object v2, v3, v6

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v1, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    const-string v1, "amsrehIptWHusPiueOh"

    const-string v1, "OuePrpIHqhauiWtemhs"

    const-string v1, "OtherPushHuaWeiImpl"

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string/jumbo v2, "oonmAg eyrrtrsnTee"

    const/4 v8, 0x3

    const-string/jumbo v2, "tosoenesAyr errTkg"

    const-string v2, "getTokenAsyn error"

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/c;->a:Landroid/content/Context;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-string v4, "Cr m,-g rdeoMr 12e7:sr :e"

    const-string v4, "errCode : -127 , errMsg :"

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string/jumbo v2, "rcutoseroh_e_edooh_pr"

    const-string/jumbo v2, "other_push_error_code"

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    return-void
.end method

.method public b(Landroid/content/Context;)V
    .locals 13

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-string p1, "horhrbtreee_opuso_odr"

    const-string p1, "erusoproeho_o__hrrtde"

    const/4 v12, 0x6

    const-string/jumbo p1, "oeresoud_hrpctreurh__"

    const-string/jumbo p1, "other_push_error_code"

    const/4 v11, 0x5

    move v12, v11

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->c:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x6

    if-eqz v0, :cond_0

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x2

    return-void

    :cond_0
    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x0

    if-nez v0, :cond_1

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x3

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v12, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    :cond_1
    const/4 v12, 0x0

    const/4 v11, 0x6

    const-string/jumbo v0, "sbhwhurpuptonPrh utiierhse eu ag"

    const-string/jumbo v0, "tioehbewsagrunus huPrr  tehehuip"

    const/4 v12, 0x2

    const-string/jumbo v0, "rhgs iahqhtrpeusn ohsueutuiwe re"

    const-string/jumbo v0, "other push huawei unregisterPush"

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    const-string/jumbo v1, "tlsahIirhHmsuePWueu"

    const-string/jumbo v1, "rhlsiWumOHuPetIuhae"

    const/4 v12, 0x1

    const-string/jumbo v1, "tuemuesPlHWahmIOhip"

    const-string v1, "OtherPushHuaWeiImpl"

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/d/a/c;->e:I

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x1

    if-nez v0, :cond_2

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x3

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/a/c;->c()I

    move-result v0

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x5

    iput v0, p0, Lcom/tencent/android/tpush/d/a/c;->e:I

    :cond_2
    :try_start_0
    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/d/a/c;->e:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x7

    const/4 v2, 0x3

    const/4 v12, 0x0

    const-string v3, "eleookepTdn"

    const-string/jumbo v3, "nkeldeopeeT"

    const/4 v12, 0x5

    const-string v3, "eontebTeedl"

    const-string v3, "deleteToken"

    const/4 v12, 0x4

    const/4 v11, 0x7

    const-class v4, Ljava/lang/String;

    const-class v4, Ljava/lang/String;

    const/4 v12, 0x3

    const-class v4, Ljava/lang/String;

    const-class v4, Ljava/lang/String;

    const/4 v12, 0x7

    const/4 v5, 0x2

    const/4 v12, 0x5

    move v11, v5

    move v11, v5

    const/4 v12, 0x0

    const/4 v6, 0x0

    move v11, v6

    move v11, v6

    const/4 v12, 0x1

    const/4 v7, 0x1

    const/4 v12, 0x2

    move v11, v7

    move v11, v7

    const/4 v12, 0x3

    if-ne v0, v2, :cond_3

    :try_start_1
    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x6

    const-string/jumbo v2, "nnseteutaqc"

    const-string v2, "eIntacneqst"

    const/4 v12, 0x6

    const-string v2, "getInstance"

    const/4 v12, 0x2

    new-array v8, v7, [Ljava/lang/Class;

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x7

    const-class v9, Landroid/content/Context;

    const-class v9, Landroid/content/Context;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x6

    aput-object v9, v8, v6

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {v0, v2, v8}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v12, 0x1

    const/4 v11, 0x7

    new-array v8, v7, [Ljava/lang/Object;

    const/4 v12, 0x5

    iget-object v9, p0, Lcom/tencent/android/tpush/d/a/c;->a:Landroid/content/Context;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x5

    aput-object v9, v8, v6

    const/4 v11, 0x4

    const/4 v11, 0x7

    invoke-virtual {v0, v2, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/c;->f:Ljava/lang/Class;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x7

    new-array v8, v5, [Ljava/lang/Class;

    const/4 v12, 0x6

    aput-object v4, v8, v6

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x4

    aput-object v4, v8, v7

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-virtual {v2, v3, v8}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x2

    new-array v3, v5, [Ljava/lang/Object;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x5

    const-string v4, "76s017719"

    const/4 v12, 0x0

    const-string v4, "1910607p7"

    const-string v4, "100167977"

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x5

    aput-object v4, v3, v6

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x0

    const-string v4, "MHC"

    const-string v4, "MCH"

    const/4 v12, 0x2

    const-string v4, "MHC"

    const-string v4, "HCM"

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x0

    aput-object v4, v3, v7

    const/4 v12, 0x2

    const/4 v11, 0x2

    invoke-virtual {v2, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x0

    goto/16 :goto_0

    :cond_3
    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x5

    if-ne v0, v5, :cond_4

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x0

    const-string v0, ".chgrAHwqnsenoSt.nidhtaa.umo$eghsi.maMe.mu"

    const-string/jumbo v0, "nhemhdsuitMasm.ennS.rmwudat.c.i.ogeoAHgah$"

    const/4 v12, 0x1

    const-string v0, "aistnMdsgP..ham.wegc.tmAhihareSeuon$usn.dH"

    const-string v0, "com.huawei.android.hms.agent.HMSAgent$Push"

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x5

    const-string v2, "du.meihdpdrHwro.autad..asoen.nlhDoaeoimnrnmglehneehT.ke.tasl"

    const-string/jumbo v2, "nordoanamhdnuDptke.oiHndeeh.Tu.mhdlserr..lanhwioeseat.aegle."

    const/4 v12, 0x5

    const-string v2, "gtoiornhunlnmled.wencledp.hsakToD.rrnaasie..ahotehm.deHeeuad"

    const-string v2, "com.huawei.android.hms.agent.push.handler.DeleteTokenHandler"

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x7

    new-instance v8, Lcom/tencent/android/tpush/d/a/c$a;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-direct {v8, p0}, Lcom/tencent/android/tpush/d/a/c$a;-><init>(Lcom/tencent/android/tpush/d/a/c;)V

    const/4 v11, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v9

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x7

    new-array v10, v7, [Ljava/lang/Class;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x5

    aput-object v2, v10, v6

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {v9, v10, v8}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v8

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x1

    new-array v9, v5, [Ljava/lang/Class;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x7

    aput-object v4, v9, v6

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x5

    aput-object v2, v9, v7

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v0, v3, v9}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x1

    new-array v3, v5, [Ljava/lang/Object;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x5

    iget-object v4, p0, Lcom/tencent/android/tpush/d/a/c;->c:Ljava/lang/String;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x7

    aput-object v4, v3, v6

    const/4 v11, 0x0

    const/4 v11, 0x3

    aput-object v8, v3, v7

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-virtual {v2, v0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v12, 0x7

    const/4 v11, 0x0

    goto/16 :goto_0

    :cond_4
    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    const/4 v2, -0x1

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    if-eq v0, v2, :cond_5

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x3

    goto/16 :goto_0

    :cond_5
    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x5

    const-string v0, "Phicib  uMKSHrsbWseegDv is"

    const-string v0, " DMWiben sKeP iuHcshirSgsv"

    const/4 v12, 0x7

    const-string v0, "SPsesWucKhMHr Dgiev inuSis"

    const-string v0, "Missing HWPush Service SDK"

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->a:Landroid/content/Context;

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const-string v3, "e r u spno,D S1HcCdMiK egi eegsS Wruse v:r:2M2ir Ps-"

    const-string/jumbo v3, "ssWeMousi S  DHCrvP:- gr See i2 u edrr:egn ,MKr12isc"

    const/4 v12, 0x5

    const-string v3, "errCode : -122 , errMsg : Missing HWPush Service SDK"

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-static {v0, p1, v2}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x0

    new-instance v0, Ljava/lang/Exception;

    const/4 v12, 0x1

    const/4 v11, 0x5

    invoke-direct {v0}, Ljava/lang/Exception;-><init>()V

    const/4 v11, 0x2

    const/4 v11, 0x4

    throw v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    move-exception v0

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x3

    const-string/jumbo v2, "rpeienh qPsrtergroru"

    const-string v2, "Pirr eepeorrusuhgrnt"

    const/4 v12, 0x6

    const-string/jumbo v2, "nrsroegehretrusrP is"

    const-string/jumbo v2, "unregisterPush error"

    const/4 v12, 0x0

    const/4 v11, 0x6

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/c;->a:Landroid/content/Context;

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v12, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x0

    const-string v4, "e1:m-rqr2Mer : ,C8 egsod "

    const-string v4, ":,deeC rq:8eorM-rg1  2 rs"

    const/4 v12, 0x0

    const-string v4, " greo Ce1rs8 o  :,rerd2-:"

    const-string v4, "errCode : -128 , errMsg :"

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x5

    const/4 v11, 0x2

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {v1, p1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x1

    return-void
.end method

.method public c(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/c;->c:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v0, "ews_ibuehtak"

    const-string v0, "etskh_weaiou"

    const/4 v3, 0x6

    const-string/jumbo v0, "uk_wetuhneia"

    const-string v0, "huawei_token"

    const/4 v3, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/c;->c:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/c;->c:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p1
.end method

.method public d(Landroid/content/Context;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    return p1
.end method

.method public e(Landroid/content/Context;)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/4 p1, 0x5

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    return p1
.end method

.method public f(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x0

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x1

    const/4 v0, 0x6

    return-object p1
.end method

.method public g(Landroid/content/Context;)Ljava/lang/String;
    .locals 9

    const/4 v8, 0x5

    iget v0, p0, Lcom/tencent/android/tpush/d/a/c;->e:I

    const/4 v8, 0x3

    if-nez v0, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/a/c;->c()I

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x7

    iput v0, p0, Lcom/tencent/android/tpush/d/a/c;->e:I

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/d/a/c;->e:I

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    const/4 v1, 0x3

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v8, 0x6

    const-string v2, ""

    const-string v2, ""

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-ne v0, v1, :cond_2

    :try_start_0
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    sget-object v0, Lcom/tencent/android/tpush/d/d;->h:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-nez v0, :cond_1

    const/4 v7, 0x6

    shl-int/2addr v8, v7

    sget-object p1, Lcom/tencent/android/tpush/d/d;->h:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    return-object p1

    :cond_1
    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string v0, "icwtcecpngoAmaCfnonoeemihafe.v.gcieGoS..grCounntsci"

    const-string v0, "cuomgithAiSnoGee.tsofniCmccaeocCn.feowev..ggnnaircn"

    const/4 v8, 0x5

    const-string v0, "eic.nagoqevcuoCnfCccrgewoGnStc.nnniA.oeghceoafm.tis"

    const-string v0, "com.huawei.agconnect.config.AGConnectServicesConfig"

    const/4 v8, 0x7

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v8, 0x5

    const-string/jumbo v1, "ofsntmooxer"

    const-string/jumbo v1, "roxmotnoeCf"

    const/4 v8, 0x7

    const-string/jumbo v1, "xoCmfrmeton"

    const-string v1, "fromContext"

    const/4 v7, 0x1

    and-int/2addr v8, v7

    const/4 v3, 0x1

    move v8, v3

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-class v5, Landroid/content/Context;

    const-class v5, Landroid/content/Context;

    const/4 v8, 0x4

    const-class v5, Landroid/content/Context;

    const-class v5, Landroid/content/Context;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    aput-object v5, v4, v6

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v0, v1, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    new-array v4, v3, [Ljava/lang/Object;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    aput-object p1, v4, v6

    const/4 v8, 0x2

    invoke-virtual {v1, v0, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-eqz p1, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string/jumbo v1, "rtigonbSt"

    const-string v1, "grSinbett"

    const/4 v8, 0x0

    const-string/jumbo v1, "regSgbtni"

    const-string v1, "getString"

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v8, 0x1

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const/4 v8, 0x3

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    aput-object v5, v4, v6

    const/4 v8, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    new-array v1, v3, [Ljava/lang/Object;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string/jumbo v3, "lndepcu_tipia"

    const-string/jumbo v3, "itecipud_lpna"

    const-string v3, "_pnc/depatilp"

    const-string v3, "client/app_id"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    aput-object v3, v1, v6

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v0, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    if-eqz p1, :cond_2

    const/4 v8, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    sput-object p1, Lcom/tencent/android/tpush/d/d;->h:Ljava/lang/String;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    goto :goto_0

    :catchall_0
    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    :catchall_1
    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string p1, "WImirphsqleeOuPuaHp"

    const-string/jumbo p1, "uhrWIPipseaelmuHOph"

    const/4 v8, 0x2

    const-string p1, "OesWhhralspIHetmiPu"

    const-string p1, "OtherPushHuaWeiImpl"

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string v0, " ofmc frnsSnvCqcnoGCoutiAeeitneod"

    const-string/jumbo v0, "ree neoSqt oncinifscfCouANdGCntov"

    const/4 v8, 0x3

    const-string/jumbo v0, "rfo oGiNvosAoi unccfCneCgeSoedntn"

    const-string v0, "Not found AGConnectServicesConfig"

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x4

    return-object v2
.end method
