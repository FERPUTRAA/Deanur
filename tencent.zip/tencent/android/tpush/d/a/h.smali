.class public Lcom/tencent/android/tpush/d/a/h;
.super Lcom/tencent/android/tpush/d/c;


# instance fields
.field private a:Ljava/lang/String;

.field private b:Ljava/lang/String;

.field private c:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/c;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/h;->a:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/h;->b:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/h;->c:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string/jumbo p1, "upsetsrlsPhOyXIShs"

    const-string/jumbo p1, "mSsOsytPeplIhurshX"

    const/4 v2, 0x7

    const-string/jumbo p1, "rlhmpuymtPOhgXIsSe"

    const-string p1, "OtherPushXgSysImpl"

    const/4 v2, 0x1

    invoke-static {p1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method private g(Landroid/content/Context;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/h;->b:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-nez v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/h;->b:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/h;->h(Landroid/content/Context;)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v2, "_pmsokgsy_"

    const-string/jumbo v2, "ks_mysp_gx"

    const/4 v4, 0x2

    const-string v2, "gs_ygbs_xp"

    const-string/jumbo v2, "xg_sys_pkg"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x5

    move v4, v3

    const-string p1, "gOPslhutrmhpeXySsu"

    const-string p1, "hlePoOmpsSXhtgsryu"

    const/4 v4, 0x5

    const-string p1, "OtherPushXgSysImpl"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v0, "ba  yiops,heptnm esys  iRupsnf npp"

    const-string/jumbo v0, "nsueobspemppuna itysy in ,  phs fR"

    const/4 v4, 0x6

    const-string/jumbo v0, "myp   enqu  yipeu,pin aftssnRposts"

    const-string v0, "Run in sys app, set pushinfo empty"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo p1, "ussupnxyhs_g_io"

    const-string/jumbo p1, "puxginuyos__shs"

    const-string p1, "gsumpyns_so_xfh"

    const-string/jumbo p1, "xg_sys_pushinfo"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1, p1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/h;->b:Ljava/lang/String;

    :cond_1
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method

.method private h(Landroid/content/Context;)Lorg/json/JSONObject;
    .locals 5

    const/4 v4, 0x1

    const-string/jumbo v0, "lmurohOIpsPsehgXtp"

    const-string/jumbo v0, "tOlssrhpShPXpmuIeg"

    const-string v0, "gpsSubPrXtymeOIlhh"

    const-string v0, "OtherPushXgSysImpl"

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string v1, ".t:utcucp.tn/ohm.tsyen/opsh.taqncstnsee"

    const-string v1, "eocuptanq.s.nssmuhn/nce/ty.tcst:thpeo.t"

    const/4 v4, 0x3

    const-string/jumbo v1, "tpnays/phhu..tmte:tes.onsec/nocsnptt.uc"

    const-string v1, "content://com.tencent.tpns.syspush.auth"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1, v1}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const-string/jumbo v2, "sosnssufqIyh"

    const-string/jumbo v2, "oPsfssnuIhsy"

    const/4 v4, 0x2

    const-string/jumbo v2, "yhssnufossPI"

    const-string/jumbo v2, "sysPushInfo:"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    new-instance v1, Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object v1

    :catchall_0
    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo p1, "tafmggbooysrshPweIttlnsm eheu"

    const-string/jumbo p1, "oeamnegelyswohstbufsPthtgI r "

    const/4 v4, 0x0

    const-string p1, "bhotogP utesetfwhaoynlssr I e"

    const-string p1, "get sysPushInfo get throwable"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 p1, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object p1
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/h;->c:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0, v0}, Lcom/tencent/android/tpush/d/a/h;->g(Landroid/content/Context;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/h;->b:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public a(Landroid/content/Context;)V
    .locals 11

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-string/jumbo v0, "ssXhgbmPtreplSuOhI"

    const-string v0, "OtherPushXgSysImpl"

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/4 v1, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpush/d/a/h;->a:Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v10, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-string/jumbo v2, "skt_eouog_sx"

    const-string/jumbo v2, "osxgos_et_nk"

    const/4 v10, 0x3

    const-string/jumbo v2, "sg_nkxopytes"

    const-string/jumbo v2, "xg_sys_token"

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {p1, v2, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-string/jumbo v1, "nse:/n.rqehmtrsgnt.nbttnos.psopuut/icctectha/y.s"

    const-string v1, "cuc/nbtsc/.:ettooheirs.esugmptsypn/a.snntt.ethrn"

    const/4 v10, 0x0

    const-string v1, "./ssphicmtuc.r/arnse/ts.eut.ogctetsnpnhey:tnenst"

    const-string v1, "content://com.tencent.tpns.syspush.auth/register"

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v4

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v5

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v5, v6}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    const/4 v5, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    const/4 v7, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v8, 0x0

    move v10, v8

    const/4 v9, 0x1

    and-int/2addr v10, v9

    invoke-virtual/range {v3 .. v8}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v1

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-eqz v1, :cond_0

    const/4 v9, 0x7

    move v10, v9

    invoke-interface {v1}, Landroid/database/Cursor;->moveToFirst()Z

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-interface {v1, v2}, Landroid/database/Cursor;->getColumnIndex(Ljava/lang/String;)I

    move-result v3

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-interface {v1, v3}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    iput-object v3, p0, Lcom/tencent/android/tpush/d/a/h;->a:Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {p1, v2, v3}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-interface {v1}, Landroid/database/Cursor;->close()V

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x3

    const-string/jumbo v1, "trPikeuhruohtgeersoseT rn te"

    const/4 v10, 0x3

    const-string v1, "he mrkTnritogerresttPe soe:h"

    const-string/jumbo v1, "registerPush ret otherToken:"

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/h;->a:Ljava/lang/String;

    const/4 v10, 0x6

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x7

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    const-string/jumbo v1, "trltosrearp: hPgweesibo"

    const-string/jumbo v1, "twerl:opsraehsubP eirgt"

    const/4 v10, 0x0

    const-string/jumbo v1, "rhe sbstPr:hwaoteibgelu"

    const-string/jumbo v1, "registerPush throwable:"

    const/4 v9, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    return-void
.end method

.method public b(Landroid/content/Context;)V
    .locals 9

    :try_start_0
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string v0, ".neeteuccsotsuntsu.s:untrh/r/op.haesmpicttqngntn/."

    const-string v0, ".yhn.rnaqeuonmcngnsetnsep/uso.t.stt/erpc/tthucits:"

    const/4 v8, 0x2

    const-string/jumbo v0, "nmetnoepseniteou.hst.sura:psncunphtt.rngts//yc/.ec"

    const-string v0, "content://com.tencent.tpns.syspush.auth/unregister"

    const/4 v7, 0x0

    move v8, v7

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {v0, v1}, Ljava/lang/Long;->toString(J)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    const/4 v3, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/4 v5, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 v6, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual/range {v1 .. v6}, Landroid/content/ContentResolver;->query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    if-eqz v0, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-interface {v0}, Landroid/database/Cursor;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x5

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string/jumbo v1, "pheOyXIuqmSgrshsts"

    const-string v1, "hlsygtSuesOrspIXhm"

    const-string v1, "XPsethsIsgrplumOSy"

    const-string v1, "OtherPushXgSysImpl"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const-string/jumbo v2, "uarmee:rbiuwglsPemrnoth s"

    const-string v2, "i:umtw aoehPnsgetlusrerrb"

    const/4 v8, 0x0

    const-string/jumbo v2, "reP:oribwahsloht uuesengt"

    const-string/jumbo v2, "unregisterPush throwable:"

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    const/4 v0, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/h;->a:Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string v0, "exk_tbsgysoo"

    const-string/jumbo v0, "sngxoe_oskyt"

    const-string/jumbo v0, "nt_gsku_xsyo"

    const-string/jumbo v0, "xg_sys_token"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v8, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    return-void
.end method

.method public c(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/h;->a:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string/jumbo v0, "txs__oepynbk"

    const-string v0, "_s_stbxkenoy"

    const/4 v3, 0x0

    const-string/jumbo v0, "ss_x_eonqygk"

    const-string/jumbo v0, "xg_sys_token"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/h;->a:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/h;->a:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    return-object p1
.end method

.method public d(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/h;->g(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/h;->b:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    xor-int/lit8 p1, p1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string v1, "gisio: usf"

    const-string v1, " is:fCuigo"

    const/4 v3, 0x7

    const-string/jumbo v1, "osfminigC "

    const-string/jumbo v1, "isConfig: "

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v1, "SeXuogpsmslrIOyPth"

    const-string/jumbo v1, "rhmSPeOpyIXutlgssp"

    const/4 v3, 0x4

    const-string v1, "XuhsmbSIytpPsehgrl"

    const-string v1, "OtherPushXgSysImpl"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return p1
.end method

.method public e(Landroid/content/Context;)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    const/16 p1, 0x8

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    return p1
.end method

.method public f(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p1
.end method
