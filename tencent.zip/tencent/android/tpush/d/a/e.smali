.class public Lcom/tencent/android/tpush/d/a/e;
.super Lcom/tencent/android/tpush/d/c;


# static fields
.field private static c:J


# instance fields
.field a:Ljava/lang/String;

.field b:Ljava/lang/StringBuffer;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/c;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method private a(Ljava/lang/String;)V
    .locals 8

    :try_start_0
    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, " ~sb~f~~~K4 @o  oi~ ~sSa -iv@do ~ o @@~~~@@@~@t@o@ ~u@~~1@ ~i@ @@.~@M~~f lno@/@@~y l t /@rcb~ b~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-eqz v0, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget-wide v2, Lcom/tencent/android/tpush/d/a/e;->c:J

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    sub-long v2, v0, v2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-wide/16 v4, 0xbb8

    const-wide/16 v4, 0xbb8

    const/4 v7, 0x4

    const-wide/16 v4, 0xbb8

    const-wide/16 v4, 0xbb8

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    cmp-long v2, v2, v4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-lez v2, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    sput-wide v0, Lcom/tencent/android/tpush/d/a/e;->c:J

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string/jumbo v1, "xepm.ncnoi.nraEtdnoeE.ociAtid.mgsKCaDFtvB."

    const-string/jumbo v1, "nCs.i.voinaFAntEnrdtdcpmceiEtgDeao.coK..xB"

    const/4 v7, 0x2

    const-string/jumbo v1, "mKo.onn.dAECooEtcadgFnvixD.ceetncr..ti.iaB"

    const-string v1, "com.tencent.android.xg.vip.action.FEEDBACK"

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    and-int/2addr v7, v6

    const-string v1, "ROSEDb.UmCOPERH"

    const-string v1, "RDOmPEURECO.SRH"

    const/4 v7, 0x5

    const-string v1, "EORCTRu.RSEDHUP"

    const-string v1, "TPUSH.ERRORCODE"

    const/4 v7, 0x2

    if-eqz p1, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v2, 0x0

    move v7, v2

    const/4 v6, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v2, -0x1

    :goto_0
    const/4 v7, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x1

    const-string v1, "enos_ptphouertho"

    const-string v1, "e_orohhetspt_onu"

    const/4 v7, 0x0

    const-string/jumbo v1, "ortehpksqtueo__n"

    const-string/jumbo v1, "other_push_token"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string p1, "ABFCEbSKDTUHP."

    const/4 v7, 0x0

    const-string p1, ".SsTKDHBEAUEPF"

    const-string p1, "TPUSH.FEEDBACK"

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v1, 0x1

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string p1, "HACmPNuUHL.N"

    const-string p1, "N.AULHuHCPSN"

    const-string p1, "CLUAoN.SHHNE"

    const-string p1, "PUSH.CHANNEL"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/16 v2, 0x67

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v0, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v6, 0x4

    move v7, v6

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const-string p1, "KPSSEb.HOP.KNTHTUROEpYHU"

    const-string p1, "YRHE.STpPU.STPOHKKOETNUH"

    const/4 v7, 0x3

    const-string p1, "TPUSH.OTHERPUSH.TOKENKEY"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string/jumbo v2, "oxmoaiuq_ine"

    const-string/jumbo v2, "ioamxneiqot_"

    const/4 v7, 0x5

    const-string/jumbo v2, "ixmni_aptoek"

    const-string/jumbo v2, "xiaomi_token"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x3

    and-int/2addr v7, v6

    const-string p1, "KHODA.PTqUNOTEUTPNT..E"

    const-string p1, "TPUSH.NOT.UPDATE.TOKEN"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->onOtherPushRegister(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    const/4 v6, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    return-void
.end method

.method private g(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/e;->a:Ljava/lang/String;

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v0, "ossxonmetai_"

    const-string/jumbo v0, "mxse_knoitoa"

    const/4 v3, 0x2

    const-string/jumbo v0, "xiaomi_token"

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/e;->a:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/e;->a:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p1
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string/jumbo v0, "immmix"

    const-string/jumbo v0, "xiimma"

    const/4 v2, 0x2

    const-string v0, "iamiox"

    const-string/jumbo v0, "xiaomi"

    const/4 v2, 0x7

    const/4 v1, 0x4

    return-object v0
.end method

.method public a(Landroid/content/Context;)V
    .locals 12

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    const-class v0, Ljava/lang/String;

    const/4 v11, 0x7

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const-string/jumbo v1, "rehoeb_ct_poo_ouershr"

    const-string/jumbo v1, "rooso_ehrederphu_c_to"

    const/4 v11, 0x3

    const-string/jumbo v1, "r_euhouhodree_rt_cpor"

    const-string/jumbo v1, "other_push_error_code"

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    sget-object v2, Lcom/tencent/android/tpush/d/d;->a:Ljava/lang/String;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-string/jumbo v3, "srpIhOuplmPihet"

    const-string v3, "OtherPushMiImpl"

    const/4 v11, 0x7

    const/4 v10, 0x7

    if-eqz v2, :cond_0

    const/4 v10, 0x1

    const/4 v11, 0x1

    const-string p1, "agplhdlfqosarrrinu siixou  mrEboePptri e"

    const-string/jumbo p1, "roepxbonuis tilrrrl muoi PerEi dhgfaps a"

    const/4 v11, 0x6

    const-string p1, " msrpsrploir rxugrselaodPueioaitinr  hf "

    const-string/jumbo p1, "registerPush Error for xiaomi null appid"

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    return-void

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x5

    sget-object v2, Lcom/tencent/android/tpush/d/d;->b:Ljava/lang/String;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    if-eqz v2, :cond_1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-string/jumbo p1, "lrumsr gyixsaEp mPrpinfru lkireoerAh ue mto"

    const-string/jumbo p1, "pirhlrurneursiti lo xygi seeErmo  ArpPfakum"

    const-string/jumbo p1, "registerPush Error for xiaomi null miAppkey"

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    return-void

    :cond_1
    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    new-instance v2, Ljava/lang/StringBuffer;

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/e;->b:Ljava/lang/StringBuffer;

    const/4 v11, 0x0

    const/4 v10, 0x3

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/base/util/Util;->isMainProcess(Landroid/content/Context;)Z

    move-result v2

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    if-eqz v2, :cond_2

    :try_start_0
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    const-string v2, "..ckoioimisxtpMehu.ad.sPlummsiipnC"

    const-string/jumbo v2, "xm.umlhpidcohikaitMems.pss.nCPuii."

    const/4 v11, 0x1

    const-string v2, "i.tmCb.dmumeisipiulcnixaohskMP..ho"

    const-string v2, "com.xiaomi.mipush.sdk.MiPushClient"

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    const/4 v4, 0x3

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v10, 0x0

    const-class v6, Landroid/content/Context;

    const-class v6, Landroid/content/Context;

    const-class v6, Landroid/content/Context;

    const-class v6, Landroid/content/Context;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x0

    const/4 v7, 0x0

    const/4 v10, 0x3

    const/4 v10, 0x7

    aput-object v6, v5, v7

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    const/4 v6, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    aput-object v0, v5, v6

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    const/4 v8, 0x2

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    aput-object v0, v5, v8

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x0

    const-string/jumbo v0, "seerPsuigtqh"

    const-string v0, "Prhgsetsqrei"

    const/4 v11, 0x4

    const-string v0, "iPgerhtprsus"

    const-string/jumbo v0, "registerPush"

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v2, v0, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x4

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x4

    const-string/jumbo v9, "p beisteq !ngireriMhus"

    const-string v9, "ebsg iset!eMghini prur"

    const/4 v11, 0x1

    const-string/jumbo v9, "nesrM!iesbgtprs  egiih"

    const-string v9, "begin Mipush register!"

    const/4 v11, 0x1

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    sget-object v9, Lcom/tencent/android/tpush/d/d;->a:Ljava/lang/String;

    const/4 v10, 0x3

    move v11, v10

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x5

    const-string v9, " "

    const-string v9, " "

    const/4 v11, 0x6

    const-string v9, " "

    const-string v9, " "

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    sget-object v9, Lcom/tencent/android/tpush/d/d;->b:Ljava/lang/String;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-static {v3, v5}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x5

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    aput-object p1, v4, v7

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x6

    sget-object v5, Lcom/tencent/android/tpush/d/d;->a:Ljava/lang/String;

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x1

    aput-object v5, v4, v6

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    sget-object v5, Lcom/tencent/android/tpush/d/d;->b:Ljava/lang/String;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    aput-object v5, v4, v8

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v0, v2, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    const-string v0, "e nmxhmhergp selsasssiucPuc sntmuhe "

    const-string v0, " scmsmlehx usn nrhrtuiessepcPehs uga"

    const/4 v11, 0x2

    const-string v0, "ehseounpsscshtx mrg cchn iesu lusPar"

    const-string/jumbo v0, "registerPush xm push channle success"

    const/4 v11, 0x2

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x5

    goto/16 :goto_0

    :catchall_0
    move-exception v0

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    const-string/jumbo v2, "rtomxbrrihs reEPgesu  "

    const-string/jumbo v2, "xm registerPush Error "

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-static {v3, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/e;->b:Ljava/lang/StringBuffer;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x4

    const-string/jumbo v4, "o1e -eurr  odM,res31C:   g"

    const-string v4, "1Moro31 dr eC,:es   e:-rg "

    const/4 v11, 0x2

    const-string v4, " 1 Crrrp3ede ::  er1g -os,"

    const-string v4, "errCode : -131 , errMsg : "

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    goto/16 :goto_0

    :catch_0
    move-exception v0

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    const-string/jumbo v5, "sus gohtqm eeirItt:axocTPfoor perrratxiovirEcn ebn Eg"

    const-string/jumbo v5, "toeanbpgxmfora:IivttrgTcrxusrr e  ni shreEoPtiErec oo"

    const-string v5, "eisEen:xegrm To iItrr c aPopsrge tanvuhErsofctixorrot"

    const-string/jumbo v5, "xm registerPush Error for InvocationTargetException: "

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x6

    const/4 v10, 0x7

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/e;->b:Ljava/lang/StringBuffer;

    const/4 v10, 0x5

    xor-int/2addr v11, v10

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    move v11, v10

    const-string v4, "-, m e1u:rg  oedreCr03M  :"

    const-string v4, " :ro-dur   0Cg3ree M1r :e,"

    const/4 v11, 0x4

    const-string v4, "::dgoreC -oMr, erse   10 3"

    const-string v4, "errCode : -130 , errMsg : "

    const/4 v10, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x6

    return-void
.end method

.method public b(Landroid/content/Context;)V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string v0, "ep__pbdeohourorrshtec"

    const-string/jumbo v0, "rrtohrep__ceesp_oduoh"

    const/4 v8, 0x2

    const-string/jumbo v0, "o__o_purhuroeedcthrse"

    const-string/jumbo v0, "other_push_error_code"

    const/4 v7, 0x1

    move v8, v7

    const-string/jumbo v1, "lepqtrhpMImuPhO"

    const-string v1, "PtieuMOhqlIrmph"

    const/4 v8, 0x6

    const-string/jumbo v1, "mtshrielqMhOIpu"

    const-string v1, "OtherPushMiImpl"

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/e;->b:Ljava/lang/StringBuffer;

    const/4 v7, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-nez v2, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    new-instance v2, Ljava/lang/StringBuffer;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/e;->b:Ljava/lang/StringBuffer;

    :cond_0
    :try_start_0
    const/4 v8, 0x6

    const-string v2, "C.sitiuesnuhloxMiihmacsdo.pmsi.m.P"

    const/4 v8, 0x6

    const-string/jumbo v2, "scsiuPmdmso.iphtia.hsCmikuoMexinl."

    const-string v2, "com.xiaomi.mipush.sdk.MiPushClient"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    const/4 v3, 0x1

    const/4 v7, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const-class v5, Landroid/content/Context;

    const-class v5, Landroid/content/Context;

    const/4 v8, 0x0

    const-class v5, Landroid/content/Context;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/4 v6, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x5

    aput-object v5, v4, v6

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    const-string v5, "ghuminsutePerm"

    const-string/jumbo v5, "shumrnPeitureg"

    const/4 v8, 0x4

    const-string v5, "iPeuohtgrssunr"

    const-string/jumbo v5, "unregisterPush"

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v2, v5, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v8, 0x0

    aput-object p1, v3, v6

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v4, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string/jumbo v2, "sPossbsncmhicuspcrsexru lgtu huehn ane"

    const-string/jumbo v2, "sn uoitrhne uesrugauslxphcmhs nce Pscs"

    const/4 v8, 0x4

    const-string/jumbo v2, "ncathrunss gi shl umsusPnpreueesucehc "

    const-string/jumbo v2, "unregisterPush xm push channle success"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    goto/16 :goto_0

    :catchall_0
    move-exception v2

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string/jumbo v4, "reursb,ceeurrermaupgkh u ooap r?iPyp e  ohnrhitogtEss at"

    const/4 v8, 0x5

    const-string v4, ",rtaanhpe  Eri rmpuek ephgros?h oeptgtyrurc s usroaoruei"

    const-string/jumbo v4, "unregisterPush Error, are you import otherpush package? "

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v1, v3}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/e;->b:Ljava/lang/StringBuffer;

    const/4 v8, 0x6

    const/4 v7, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string/jumbo v4, "s 3g eueq: erMC- r ro:,dr3"

    const-string v4, " rM:reuCsr,-e  d:3o eg3 r "

    const/4 v8, 0x3

    const-string v4, "errCode : -133 , errMsg : "

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v2}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    goto/16 :goto_0

    :catch_0
    move-exception v2

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v2}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string/jumbo v5, "iesgn efIeEenatt:r soshorr piatrEv uoriPTtcxcornoupg"

    const-string v5, "PEe uocpaorhecoEourvxei g pfnTeis ntrIina:gttorrtsrr"

    const-string/jumbo v5, "ro meocrrotxatteeInf PoeEinrsprr Evinsugag: nurichot"

    const-string/jumbo v5, "unregisterPush Error for InvocationTargetException: "

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v3}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x2

    shr-int/2addr v8, v7

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {v1, v3}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/e;->b:Ljava/lang/StringBuffer;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string v4, " 3dro-2 r :oqsgre C r:ee1M"

    const-string v4, "  o1rre3qdg2 esrC:M  r e:-"

    const/4 v8, 0x1

    const-string v4, " dM-2ber  :Ce:   rr3es,1gr"

    const-string v4, "errCode : -132 , errMsg : "

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    invoke-virtual {v2}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x6

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    return-void
.end method

.method public c(Landroid/content/Context;)Ljava/lang/String;
    .locals 10

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string/jumbo v0, "ohotshurcpees_redur_r"

    const-string/jumbo v0, "tus_hrheoserpoco_redr"

    const/4 v9, 0x7

    const-string/jumbo v0, "t__serhpcrooed_oprheu"

    const-string/jumbo v0, "other_push_error_code"

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string/jumbo v1, "rmsmhethpOIluiP"

    const/4 v9, 0x6

    const-string/jumbo v1, "mphiIuheqlPrtsM"

    const-string v1, "OtherPushMiImpl"

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/e;->b:Ljava/lang/StringBuffer;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-nez v2, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x1

    new-instance v2, Ljava/lang/StringBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/e;->b:Ljava/lang/StringBuffer;

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v9, 0x0

    const-string v2, ""

    const-string v2, ""

    :try_start_0
    const/4 v8, 0x6

    move v9, v8

    const-string v3, "Cossen.ihmkpm.ssmiiluocoht.iMdaPix"

    const-string/jumbo v3, "kp.soMmsiCcutaiu.hnso.eiiidxoPlmmh"

    const/4 v9, 0x0

    const-string v3, ".CMmlnouthked.mmumaxiissciPho.p.is"

    const-string v3, "com.xiaomi.mipush.sdk.MiPushClient"

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/4 v4, 0x1

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-class v6, Landroid/content/Context;

    const/4 v9, 0x4

    const-class v6, Landroid/content/Context;

    const-class v6, Landroid/content/Context;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    const/4 v7, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    aput-object v6, v5, v7

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-string v6, "geetobdI"

    const-string v6, "IdgRebet"

    const/4 v9, 0x3

    const-string v6, "IeedgbtR"

    const-string v6, "getRegId"

    const/4 v9, 0x2

    invoke-virtual {v3, v6, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    new-array v4, v4, [Ljava/lang/Object;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    aput-object p1, v4, v7

    const/4 v9, 0x1

    invoke-virtual {v5, v3, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/e;->g(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x6

    if-eqz v3, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static {v5}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-nez v5, :cond_1

    const/4 v9, 0x0

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-nez v5, :cond_1

    const/4 v8, 0x2

    shr-int/2addr v9, v8

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    iput-object v4, p0, Lcom/tencent/android/tpush/d/a/e;->a:Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string v4, "aun_mtuoxkoi"

    const-string/jumbo v4, "n_oemxutakio"

    const/4 v9, 0x7

    const-string/jumbo v4, "xmiota_pioen"

    const-string/jumbo v4, "xiaomi_token"

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {p1, v4, v5}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/e;->a:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    goto :goto_0

    :cond_1
    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    :goto_0
    const/4 v9, 0x7

    if-eqz v3, :cond_2

    const/4 v9, 0x1

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {v4}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-nez v4, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v3}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-direct {p0, v3}, Lcom/tencent/android/tpush/d/a/e;->a(Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    goto/16 :goto_1

    :catchall_0
    move-exception v3

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string/jumbo v4, "omErkxr qneegro T"

    const-string/jumbo v4, "rgr onkpo TeexrmE"

    const/4 v9, 0x7

    const-string/jumbo v4, "oesk Et orngrmexT"

    const-string/jumbo v4, "xm getToken Error"

    const/4 v9, 0x7

    const/4 v8, 0x4

    invoke-static {v1, v4, v3}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/e;->b:Ljava/lang/StringBuffer;

    const/4 v8, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    const-string/jumbo v5, "o:,mr  r1:g  qsr3dre Ce-M "

    const-string v5, "- d rrgeq se: 31 rMr: o,C5"

    const/4 v9, 0x5

    const-string v5, "g,:5o drM-31e  C   rroe:re"

    const-string v5, "errCode : -135 , errMsg : "

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v3}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    goto/16 :goto_1

    :catch_0
    move-exception v3

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v3}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x0

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string/jumbo v6, "ogT EboaEf sxv  ek piatrt:ntoenerrnoorgcTitxocIen"

    const-string v6, "cesoa TofEtro  tct viTaxonEo:tegi nrrrnIkeerpngox"

    const/4 v9, 0x4

    const-string/jumbo v6, "xm getToken Error for InvocationTargetException: "

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v4}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {v1, v4}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/e;->b:Ljava/lang/StringBuffer;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string v5, "e:4sm-u r eog 3M:,r   e1dC"

    const-string v5, " ermg1dMrs: -r,: oee3  C4 "

    const/4 v9, 0x2

    const-string v5, "e-C : gprd e 3r,sor: 1Me4 "

    const-string v5, "errCode : -134 , errMsg : "

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v3}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    return-object v2
.end method

.method public d(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/d/d;->a:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    sget-object v0, Lcom/tencent/android/tpush/d/d;->b:Ljava/lang/String;

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    :cond_0
    const/4 v3, 0x6

    invoke-static {p1, v1}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;I)V

    :cond_1
    sget-object v0, Lcom/tencent/android/tpush/d/d;->a:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez v0, :cond_2

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/d/d;->b:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_3

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->l(Landroid/content/Context;)V

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x7

    sget-object p1, Lcom/tencent/android/tpush/d/d;->a:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-eqz p1, :cond_4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return v0

    :cond_4
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    sget-object p1, Lcom/tencent/android/tpush/d/d;->b:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p1, :cond_5

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    return v0

    :cond_5
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return v1
.end method

.method public e(Landroid/content/Context;)I
    .locals 2

    const/4 v1, 0x6

    const/4 p1, 0x1

    const/4 v1, 0x3

    move v0, p1

    move v0, p1

    const/4 v1, 0x5

    return p1
.end method

.method public f(Landroid/content/Context;)Ljava/lang/String;
    .locals 7

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string v0, "dcpCsmPsqit.Muislehoo.uii.iakmo.hn"

    const-string v0, "esPmolixo.ii.shCho.aMmikpcusd.unti"

    const/4 v6, 0x0

    const-string/jumbo v0, "posslMcCoi.shtakiminiPu.ummx.id.se"

    const-string v0, "com.xiaomi.mipush.sdk.MiPushClient"

    const/4 v6, 0x5

    const/4 v5, 0x4

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v1, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-array v2, v1, [Ljava/lang/Class;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-class v3, Landroid/content/Context;

    const-class v3, Landroid/content/Context;

    const/4 v6, 0x1

    const-class v3, Landroid/content/Context;

    const-class v3, Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x4

    aput-object v3, v2, v4

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    const-string v3, "epgmbAnpetoi"

    const-string v3, "etnoebpgAipg"

    const/4 v6, 0x7

    const-string v3, "RpegogpientA"

    const-string v3, "getAppRegion"

    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0, v3, v2}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    aput-object p1, v1, v4

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v2, v0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz p1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-nez v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x0

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v1, "irn:ubeRgeg orreo"

    const-string v1, ":rg roureogneei R"

    const/4 v6, 0x2

    const-string v1, ":teo iuR ggroenre"

    const-string v1, "getRegion error: "

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v0, "luOPIhspepithpM"

    const-string v0, "ItOuhmipspPeMhl"

    const/4 v6, 0x4

    const-string v0, "OtherPushMiImpl"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string p1, ""

    const-string p1, ""

    const/4 v6, 0x6

    const-string p1, ""

    const-string p1, ""

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-object p1
.end method
