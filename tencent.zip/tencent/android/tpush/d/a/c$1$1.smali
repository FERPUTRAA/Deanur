.class Lcom/tencent/android/tpush/d/a/c$1$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/d/a/c$1;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Lcom/tencent/android/tpush/d/a/c$1;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/d/a/c$1;Landroid/content/Intent;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->c:Lcom/tencent/android/tpush/d/a/c$1;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->a:Landroid/content/Intent;

    const/4 v0, 0x6

    or-int/2addr v1, v0

    iput-object p3, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->b:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  s@@t M~~b/cil  ~oi~ 4@~@~aono@~~ y~@ ~  @1~o@@~f~@o@ ~-m@~Sb@~@@ v~.u~~~~r @l dt ~@K @b@/@ios "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    const-string v0, "OmWmelptHiuhuerssPh"

    const-string/jumbo v0, "uusIPHrWhleOpmihset"

    const/4 v6, 0x6

    const-string v0, "OtherPushHuaWeiImpl"

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->a:Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v1, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v2, :cond_0

    const/4 v5, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-void

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v3, "ie:oomectiavna ctrsboa ecR"

    const-string v3, "anem aReie sbtt:acoi orccv"

    const/4 v6, 0x5

    const-string/jumbo v3, "tore bnaicdiobas:R evce ca"

    const-string v3, "Receive broadcast action: "

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v2, "aaAOiiuIt.op.tNdRSnu.uIo.hiwoeTmGnh.nedrcsE"

    const-string/jumbo v2, "oeaIoAtN.eiEadI.cn.uimwGiodtRr.nsuTShh.OTpn"

    const/4 v6, 0x5

    const-string v2, "com.huawei.android.push.intent.REGISTRATION"

    const/4 v6, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    if-eqz v2, :cond_3

    const/4 v5, 0x1

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->a:Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const-string v2, "cibkedop_eev"

    const-string v2, "eecv_btodkei"

    const/4 v6, 0x4

    const-string/jumbo v2, "ketcenveqod_"

    const-string v2, "device_token"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Landroid/content/Intent;->getByteArrayExtra(Ljava/lang/String;)[B

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-nez v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-void

    :cond_1
    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v2, Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string v3, "T-su8"

    const-string v3, "-uT8U"

    const/4 v6, 0x5

    const-string v3, "TF8mU"

    const-string v3, "UTF-8"

    const/4 v6, 0x3

    const/4 v5, 0x5

    invoke-direct {v2, v1, v3}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string/jumbo v3, "sf:more Gob adnpk toe taro"

    const-string/jumbo v3, "t eGto pa rfbaondrek:s tmo"

    const/4 v6, 0x5

    const-string/jumbo v3, "oet sbmrkcr tnaobaG :dft e"

    const-string v3, "Get token from broadcast: "

    const/4 v5, 0x3

    shl-int/2addr v6, v5

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-nez v1, :cond_5

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->c:Lcom/tencent/android/tpush/d/a/c$1;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v1, v1, Lcom/tencent/android/tpush/d/a/c$1;->a:Lcom/tencent/android/tpush/d/a/c;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->b:Landroid/content/Context;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v1, v3}, Lcom/tencent/android/tpush/d/a/c;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-nez v1, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->c:Lcom/tencent/android/tpush/d/a/c$1;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object v1, v1, Lcom/tencent/android/tpush/d/a/c$1;->a:Lcom/tencent/android/tpush/d/a/c;

    const/4 v6, 0x5

    const/4 v5, 0x2

    iput-object v2, v1, Lcom/tencent/android/tpush/d/a/c;->c:Ljava/lang/String;

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->b:Landroid/content/Context;

    const/4 v6, 0x6

    const-string v3, "_keiutuowhnq"

    const-string/jumbo v3, "utek_wenqhio"

    const/4 v6, 0x5

    const-string v3, "eioaenupkw_h"

    const-string v3, "huawei_token"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v1, v3, v2}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->c:Lcom/tencent/android/tpush/d/a/c$1;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v1, v1, Lcom/tencent/android/tpush/d/a/c$1;->a:Lcom/tencent/android/tpush/d/a/c;

    const/4 v6, 0x6

    const/4 v5, 0x2

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/d/a/c;->a(Lcom/tencent/android/tpush/d/a/c;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v1, " C, cdsgqe:rr: 0 Meusosceres r"

    const-string v1, "Crs, sr :euMescceerrg0s:  o d "

    const/4 v6, 0x3

    const-string v1, "Ces eucse:crg eso rs ,r dM0r: "

    const-string v1, "errCode : 0 , errMsg : success"

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->c:Lcom/tencent/android/tpush/d/a/c$1;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v2, v2, Lcom/tencent/android/tpush/d/a/c$1;->a:Lcom/tencent/android/tpush/d/a/c;

    const/4 v5, 0x4

    shl-int/2addr v6, v5

    iget-object v2, v2, Lcom/tencent/android/tpush/d/a/c;->a:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v2, v0, v1}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto/16 :goto_0

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo v2, "uemmwVitIahnuRi.sc.d.oCai.tEEp.ndrneEh"

    const-string v2, "com.huawei.android.push.intent.RECEIVE"

    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-eqz v2, :cond_4

    const/4 v5, 0x3

    or-int/2addr v6, v5

    const-string/jumbo v1, "ntanove rhet.uinmdwpEcdRcsuEoroCrcioaeVaemiI.i.hEt. i"

    const-string/jumbo v1, "retmcdirnEc.EuVa Ca hvaRomei.h.EntInir.dtneesuwicoipo"

    const/4 v6, 0x7

    const-string/jumbo v1, "reciver action com.huawei.android.push.intent.RECEIVE"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto/16 :goto_0

    :cond_4
    const/4 v6, 0x0

    const/4 v5, 0x7

    const-string/jumbo v2, "ntPaibcoAwuaetei.ESch..m.noHtSnTU_i"

    const-string/jumbo v2, "t.c.oSoSa.utPmaitEcne._hoHTnwieUAin"

    const/4 v6, 0x5

    const-string/jumbo v2, "owcTAnuniS.UathS.eticoPinemHt.T._aE"

    const-string v2, "com.huawei.intent.action.PUSH_STATE"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eqz v1, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x5

    const-string/jumbo v1, "ncm w.bp.einiaciTirSohtSviecr.Et.e ueaToAcUEattHon_"

    const-string v1, ".eotTbhHAutiS c_vacwtiteU ..mnani.iSroeaTccnEEneori"

    const-string v1, "To  Sr.tqwcocceEPHaiEm_uT.i.neenio.iictvehtrtanASUn"

    const-string/jumbo v1, "reciver action com.huawei.intent.action.PUSH_STATEE"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x6

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    const-string v2, "eesatuwH eeueercgrsivRi"

    const-string v2, "RacHeeuierewvetgu eirrs"

    const/4 v6, 0x6

    const-string v2, "eirmeaecevsiuRtwHrer ig"

    const-string/jumbo v2, "registerHuaweiRecevier "

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->b:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/c$1$1;->c:Lcom/tencent/android/tpush/d/a/c$1;

    const/4 v6, 0x2

    iget-object v2, v2, Lcom/tencent/android/tpush/d/a/c$1;->a:Lcom/tencent/android/tpush/d/a/c;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v2, v2, Lcom/tencent/android/tpush/d/a/c;->d:Ljava/lang/StringBuffer;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const-string v4, "e r o:re1:  r0s-e, 2MpdCo "

    const-string v4, "e:r o Cp-d Mrs  02e, err1:"

    const-string v4, " dr rbC0: e: roe s e2-g1,r"

    const-string v4, "errCode : -120 , errMsg : "

    const/4 v6, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const-string v2, "_tceohuue_rporqsdr_hr"

    const-string v2, "_rh_o_shqodrteeuprcre"

    const/4 v6, 0x3

    const-string v2, "cru_osdpt_eeoh_oerrrp"

    const-string/jumbo v2, "other_push_error_code"

    const/4 v6, 0x7

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-void
.end method
