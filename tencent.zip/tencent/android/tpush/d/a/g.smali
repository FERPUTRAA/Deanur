.class public Lcom/tencent/android/tpush/d/a/g;
.super Lcom/tencent/android/tpush/d/c;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/d/a/g$a;
    }
.end annotation


# static fields
.field private static h:J


# instance fields
.field a:Ljava/lang/StringBuffer;

.field private b:Ljava/lang/Object;

.field private c:Ljava/lang/Object;

.field private d:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field private e:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field private f:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field private g:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpush/d/c;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->b:Ljava/lang/Object;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->c:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->d:Ljava/lang/Class;

    const/4 v2, 0x6

    const/4 v1, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->f:Ljava/lang/Class;

    const/4 v2, 0x3

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/d/a/g;)Ljava/lang/String;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~~s@o~y~btd s ~@ ~/ 1fv@4 oo~~@@m~@ i@Mc o~ l@f aiu @~S~ ~ / ~~o~@~bKb r~~t ~~@i@~o@@@@n.- l@ @@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    iget-object p0, p0, Lcom/tencent/android/tpush/d/a/g;->g:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic a(Lcom/tencent/android/tpush/d/a/g;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/g;->g:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p1
.end method

.method private a(Ljava/lang/String;)V
    .locals 8

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v7, 0x1

    const/4 v6, 0x0

    sget-wide v2, Lcom/tencent/android/tpush/d/a/g;->h:J

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    sub-long v2, v0, v2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-wide/16 v4, 0x1388

    const-wide/16 v4, 0x1388

    const/4 v7, 0x2

    const-wide/16 v4, 0x1388

    const-wide/16 v4, 0x1388

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    cmp-long v2, v2, v4

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-lez v2, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    sput-wide v0, Lcom/tencent/android/tpush/d/a/g;->h:J

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string v1, "aedmFaexnEr.tKnpcio.iA.sov.dC.moicnntDBEt."

    const-string/jumbo v1, "pesAc.rdmivgtoaK.EDxiatnoC.ndnEteo.Fic.B.n"

    const/4 v7, 0x1

    const-string v1, "iB.to.or.eongndEeAaFmnoipEtv.cnax.tc.cdCiK"

    const-string v1, "com.tencent.android.xg.vip.action.FEEDBACK"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "OHEOTbRPRE.DURC"

    const-string v1, "TPUSH.ERRORCODE"

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eqz p1, :cond_0

    const/4 v7, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x3

    const/4 v2, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v6, 0x3

    const/4 v2, -0x1

    move v7, v2

    :goto_0
    const/4 v6, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v1, "hro_n_uktepetush"

    const-string/jumbo v1, "other_push_token"

    const/4 v7, 0x5

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x1

    const-string p1, "HFPATESpDEmKB."

    const-string p1, "DEPm.EFAHUTBKS"

    const/4 v7, 0x1

    const-string p1, "DFUT.SPCqEKAEH"

    const-string p1, "TPUSH.FEEDBACK"

    const/4 v7, 0x5

    const/4 v1, 0x1

    const/4 v7, 0x6

    move v6, v1

    move v6, v1

    const/4 v7, 0x0

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string p1, "PosLSNHCHUNA"

    const-string p1, "HSUPoHNECNLA"

    const/4 v7, 0x7

    const-string p1, "PCEm.SHANUHL"

    const-string p1, "PUSH.CHANNEL"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/16 v2, 0x68

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x3

    or-int/2addr v7, v6

    const-string p1, "ETHRoT.UKEHYSTSNOEOPHKU."

    const-string p1, "TPUSH.OTHERPUSH.TOKENKEY"

    const/4 v6, 0x1

    move v7, v6

    const-string v2, "_oiekbvntb"

    const-string v2, "_onvkbivet"

    const-string/jumbo v2, "vivo_token"

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string p1, "TDO.UPuHTT.NAPNuTSOUEE"

    const-string p1, "D.NNOEuKPUSOAET.TPTHTU"

    const/4 v7, 0x7

    const-string p1, "NDH.ETKp.SOTUAT.TPNOEP"

    const-string p1, "TPUSH.NOT.UPDATE.TOKEN"

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v6, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->onOtherPushRegister(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    return-void
.end method

.method static synthetic b(Lcom/tencent/android/tpush/d/a/g;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/g;->a(Ljava/lang/String;)V

    const/4 v1, 0x5

    return-void
.end method

.method private g(Landroid/content/Context;)Ljava/lang/Object;
    .locals 8

    const/4 v6, 0x2

    move v7, v6

    const-string/jumbo v0, "rhteIlmiqsuvVOopp"

    const-string/jumbo v0, "lthrumippIeVOhovs"

    const/4 v7, 0x4

    const-string v0, "VesOhvshtpolmIruP"

    const-string v0, "OtherPushVivoImpl"

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string/jumbo v1, "o.umiilut.vhqsPmveopnh.C"

    const-string v1, "cmpnu.hlqetooPiihv.u.Csv"

    const/4 v7, 0x5

    const-string v1, "com.vivo.push.PushClient"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpush/d/a/g;->d:Ljava/lang/Class;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v2, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-class v4, Landroid/content/Context;

    const-class v4, Landroid/content/Context;

    const/4 v7, 0x6

    const-class v4, Landroid/content/Context;

    const-class v4, Landroid/content/Context;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v5, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    aput-object v4, v3, v5

    const/4 v6, 0x4

    and-int/2addr v7, v6

    const-string v4, "escsotgntne"

    const-string/jumbo v4, "tnstegcsean"

    const/4 v7, 0x3

    const-string v4, "csegtbntIae"

    const-string v4, "getInstance"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1, v4, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/d/a/g;->d:Ljava/lang/Class;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    aput-object p1, v2, v5

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v1, v3, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string/jumbo v1, "tmp EIusIt lrcmngaoren"

    const-string v1, "aeEmIprge nmtrIc stnlo"

    const/4 v7, 0x5

    const-string/jumbo v1, "rmerIlop gEantcItrp ns"

    const-string v1, "getImplInstance Error "

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const-string/jumbo v2, "nteIco cqtoxo irnToagrtsi:nrpceIanvoeEromlrEnegI f pt"

    const-string v2, "epTcoaaoIgrnmaEt:ooiitcpnetxEvncotrsle  rr nnfr egIIo"

    const/4 v7, 0x5

    const-string v2, " msriceronvE aE:gncentrgtoe oitonoca psxeTpIrItlatnIr"

    const-string v2, "getImplInstance Error for InvocationTargetException: "

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    const/4 p1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    return-object p1
.end method

.method private h(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->g:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const-string/jumbo v0, "io_movbenk"

    const-string/jumbo v0, "o_kivbnvoe"

    const/4 v3, 0x3

    const-string/jumbo v0, "toveovnki_"

    const-string/jumbo v0, "vivo_token"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p1, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/d/a/g;->g:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/d/a/g;->g:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-object p1
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string/jumbo v0, "vovi"

    const-string/jumbo v0, "oviv"

    const/4 v2, 0x6

    const-string/jumbo v0, "vivo"

    const-string/jumbo v0, "vivo"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public a(Landroid/content/Context;)V
    .locals 12

    const/4 v10, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    const-string/jumbo v0, "itiiablzni"

    const-string/jumbo v0, "initialize"

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-string/jumbo v1, "pmvOltuPhueihorsu"

    const-string v1, "hPoltuuhriepvOIsm"

    const/4 v11, 0x4

    const-string/jumbo v1, "vOpemhIpohVsilruP"

    const-string v1, "OtherPushVivoImpl"

    const/4 v10, 0x0

    or-int/2addr v11, v10

    new-instance v2, Ljava/lang/StringBuffer;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/g;->a:Ljava/lang/StringBuffer;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/g;->g(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x3

    if-eqz v2, :cond_3

    :try_start_0
    const/4 v11, 0x5

    const/4 v10, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/d/a/g;->d:Ljava/lang/Class;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    if-nez v3, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    const-string/jumbo v3, "vtuluCcsq.ohnpem.ioivhsP"

    const-string/jumbo v3, "tuuChvmph.ocpvsPeiiosnl."

    const/4 v11, 0x1

    const-string/jumbo v3, "o.stvvmsoilC.niu.cuhhpsP"

    const-string v3, "com.vivo.push.PushClient"

    const/4 v10, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x3

    iput-object v3, p0, Lcom/tencent/android/tpush/d/a/g;->d:Ljava/lang/Class;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :cond_0
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    const/4 v3, 0x1

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    const/4 v4, 0x0

    :try_start_1
    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    iget-object v5, p0, Lcom/tencent/android/tpush/d/a/g;->d:Ljava/lang/Class;

    const/4 v11, 0x5

    const/4 v10, 0x1

    new-array v6, v4, [Ljava/lang/Class;

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v5, v0, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    new-array v6, v4, [Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x3

    invoke-virtual {v5, v2, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    goto/16 :goto_0

    :catchall_0
    :try_start_2
    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    const-string v5, ".n$mvhogo.uolvrhpidquicufisePsm."

    const-string/jumbo v5, "luicPv.uqorgsdnC.mhhp.iooesvi$fu"

    const/4 v11, 0x6

    const-string/jumbo v5, "rCivo$.sevohm.PuciunosgBhpu.ofil"

    const-string v5, "com.vivo.push.PushConfig$Builder"

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v5

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x2

    new-array v6, v4, [Ljava/lang/Class;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v5, v6}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v6

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x1

    new-array v7, v4, [Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v6, v7}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    const-string v7, "egitrbeytvatarecSenam"

    const-string v7, "agreePrivacyStatement"

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x4

    new-array v8, v3, [Ljava/lang/Class;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    sget-object v9, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x0

    aput-object v9, v8, v4

    const/4 v10, 0x0

    move v11, v10

    invoke-virtual {v5, v7, v8}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v7

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    new-array v8, v3, [Ljava/lang/Object;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    sget-object v9, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v10, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x2

    aput-object v9, v8, v4

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v7, v6, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x6

    const/4 v10, 0x5

    const-string/jumbo v7, "ludis"

    const-string/jumbo v7, "ilsbd"

    const-string/jumbo v7, "ilpub"

    const-string v7, "build"

    const/4 v10, 0x6

    move v11, v10

    new-array v8, v4, [Ljava/lang/Class;

    const/4 v10, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v5, v7, v8}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x2

    new-array v7, v4, [Ljava/lang/Object;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-virtual {v5, v6, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    const-string/jumbo v6, "msPpco..qiui.ovhuognfChm"

    const-string/jumbo v6, "vhmmucn.uCovoiiPs.p.gofh"

    const/4 v11, 0x5

    const-string v6, "fisou.ghs.impnch.sPCovuv"

    const-string v6, "com.vivo.push.PushConfig"

    const/4 v11, 0x6

    invoke-static {v6}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v6

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x2

    iget-object v7, p0, Lcom/tencent/android/tpush/d/a/g;->d:Ljava/lang/Class;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    new-array v8, v3, [Ljava/lang/Class;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x0

    aput-object v6, v8, v4

    const/4 v11, 0x3

    invoke-virtual {v7, v0, v8}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x6

    new-array v6, v3, [Ljava/lang/Object;

    const/4 v11, 0x6

    const/4 v10, 0x7

    aput-object v5, v6, v4

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-virtual {v0, v2, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :goto_0
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->b:Ljava/lang/Object;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x1

    const-string/jumbo v5, "votmsiP.vncsehhoL.siunAetipcIouom"

    const-string/jumbo v5, "toIeocPt.Anpui.isssrvucvohhoeiLmn"

    const/4 v11, 0x2

    const-string/jumbo v5, "npcLoh..rovhiicetse.PuitAIuovmnso"

    const-string v5, "com.vivo.push.IPushActionListener"

    const/4 v10, 0x5

    or-int/2addr v11, v10

    if-nez v0, :cond_1

    :try_start_3
    const/4 v11, 0x1

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x1

    new-instance v0, Lcom/tencent/android/tpush/d/a/g$a;

    const/4 v11, 0x4

    invoke-direct {v0, p0, p1}, Lcom/tencent/android/tpush/d/a/g$a;-><init>(Lcom/tencent/android/tpush/d/a/g;Landroid/content/Context;)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    iget-object v6, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    const/4 v11, 0x6

    invoke-virtual {v6}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v6

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    new-array v7, v3, [Ljava/lang/Class;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    iget-object v8, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    aput-object v8, v7, v4

    const/4 v10, 0x6

    move v11, v10

    invoke-static {v6, v7, v0}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->b:Ljava/lang/Object;

    :cond_1
    const/4 v10, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    if-nez v0, :cond_2

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    :cond_2
    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->d:Ljava/lang/Class;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string v5, "hrPOnbstnu"

    const/4 v11, 0x5

    const-string/jumbo v5, "turnOnPush"

    const/4 v11, 0x5

    const/4 v10, 0x1

    new-array v6, v3, [Ljava/lang/Class;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    iget-object v7, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    const/4 v10, 0x5

    xor-int/2addr v11, v10

    aput-object v7, v6, v4

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v0, v5, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x0

    iget-object v5, p0, Lcom/tencent/android/tpush/d/a/g;->b:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x6

    aput-object v5, v3, v4

    const/4 v10, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v0, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-string/jumbo v0, "u ceubsissuP  esgpivscheonhh tevsrcnal"

    const-string/jumbo v0, "registerPush vivo push channel success"

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    goto/16 :goto_1

    :catchall_1
    move-exception v0

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const-string v3, "egroewuile uhr hsta :rPubT"

    const-string v3, "bstaePu iowuTrlrg r:heesh "

    const/4 v11, 0x2

    const-string v3, "bTPi:rlproshrwte esuehg  a"

    const-string/jumbo v3, "registerPush Throwable e: "

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/g;->a:Ljava/lang/StringBuffer;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    shl-int/2addr v11, v10

    const-string v3, "-1orM  sq4reeg: p, d r e0C"

    const-string v3, "Me4,rg prr:so d: 0e1C  -e "

    const/4 v11, 0x7

    const-string v3, "errCode : -140 , errMsg : "

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x5

    const/4 v10, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x4

    const-string/jumbo v1, "ohs_ucer_deoorh_rserp"

    const-string/jumbo v1, "other_push_error_code"

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_1
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    return-void
.end method

.method public b(Landroid/content/Context;)V
    .locals 11

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-string v0, "PqpmtIhvieurVlOmh"

    const-string v0, "IhtlOerVqupmhvoiP"

    const/4 v10, 0x3

    const-string v0, "PmIuohleviVOophrt"

    const-string v0, "OtherPushVivoImpl"

    const/4 v10, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/d/a/g;->a:Ljava/lang/StringBuffer;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    if-nez v1, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpush/d/a/g;->a:Ljava/lang/StringBuffer;

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/g;->g(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-eqz v1, :cond_4

    :try_start_0
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/g;->b:Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x6

    const/4 v9, 0x1

    const-string/jumbo v3, "vtsnnroesocvshut.uLopi.iecimsPhI."

    const/4 v10, 0x7

    const-string v3, ".crpAbu.sPhitvnILsue.ecsnoootvmhi"

    const-string v3, "com.vivo.push.IPushActionListener"

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    const/4 v4, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    const/4 v5, 0x1

    const/4 v10, 0x4

    if-nez v2, :cond_1

    :try_start_1
    const/4 v9, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    const/4 v9, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x2

    new-instance v2, Lcom/tencent/android/tpush/d/a/g$a;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-direct {v2, p0, p1}, Lcom/tencent/android/tpush/d/a/g$a;-><init>(Lcom/tencent/android/tpush/d/a/g;Landroid/content/Context;)V

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget-object v6, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {v6}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v6

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    new-array v7, v5, [Ljava/lang/Class;

    const/4 v9, 0x2

    move v10, v9

    iget-object v8, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    aput-object v8, v7, v4

    const/4 v9, 0x2

    move v10, v9

    invoke-static {v6, v7, v2}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v2

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/g;->b:Ljava/lang/Object;

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    const/4 v10, 0x7

    const/4 v9, 0x3

    if-nez v2, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    :cond_2
    const/4 v10, 0x4

    const/4 v9, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/g;->d:Ljava/lang/Class;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x5

    if-nez v2, :cond_3

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string v2, ".hesuvun.i.ptcomCosvPuli"

    const-string v2, "Cmemsvuots..Phvclipuin.o"

    const/4 v10, 0x2

    const-string/jumbo v2, "m.t.npoplhCeiPhciuov.sus"

    const-string v2, "com.vivo.push.PushClient"

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpush/d/a/g;->d:Ljava/lang/Class;

    :cond_3
    const/4 v10, 0x1

    const/4 v9, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/g;->d:Ljava/lang/Class;

    const/4 v9, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    const-string/jumbo v3, "sfhOunorqPf"

    const-string v3, "PnufoOrhusf"

    const/4 v10, 0x4

    const-string v3, "OnsufrPfuth"

    const-string/jumbo v3, "turnOffPush"

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x1

    new-array v6, v5, [Ljava/lang/Class;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x4

    iget-object v7, p0, Lcom/tencent/android/tpush/d/a/g;->e:Ljava/lang/Class;

    const/4 v10, 0x4

    const/4 v9, 0x0

    aput-object v7, v6, v4

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {v2, v3, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    new-array v3, v5, [Ljava/lang/Object;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    iget-object v5, p0, Lcom/tencent/android/tpush/d/a/g;->b:Ljava/lang/Object;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    aput-object v5, v3, v4

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v2, v1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v10, 0x2

    const/4 v9, 0x4

    const-string/jumbo v1, "raomiuihsu bcesscunehcve P nsesh uvnstpr"

    const-string/jumbo v1, "uur vbc eusee iscpn alonsscuhetisPvhnshr"

    const/4 v10, 0x4

    const-string v1, "hiucoo nccv tsi Pelhsuapuenre shevsnsrgu"

    const-string/jumbo v1, "unregisterPush vivo push channel success"

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    goto/16 :goto_0

    :catchall_0
    move-exception v1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x5

    const-string/jumbo v3, "srbehTurtn  uee raulePwi:osh"

    const/4 v10, 0x0

    const-string/jumbo v3, "rPrubbei:eseh nowhat sugleTr"

    const-string/jumbo v3, "unregisterPush Throwable e: "

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/d/a/g;->a:Ljava/lang/StringBuffer;

    const/4 v10, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-string v3, "ed4rreue 1-rMs  3:r  C:p ,"

    const-string v3, "e -C,4rpe:s  r dMr r1:3 ge"

    const/4 v10, 0x5

    const-string v3, " C   3rpr1s  4M:ge-eer:do,"

    const-string v3, "errCode : -143 , errMsg : "

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    invoke-virtual {v1}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const-string/jumbo v1, "or_hurdeqspqo_rrot_ch"

    const-string v1, "_ocesutoqdre_r_orhhpr"

    const/4 v10, 0x6

    const-string/jumbo v1, "ressuhpohc_rterer_d_o"

    const-string/jumbo v1, "other_push_error_code"

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    return-void
.end method

.method public c(Landroid/content/Context;)Ljava/lang/String;
    .locals 14

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x6

    const-string v0, "RIsmdgte"

    const-string v0, "eesItdRg"

    const-string v0, "eIRgodtg"

    const-string v0, "getRegId"

    const/4 v12, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x7

    const-string/jumbo v1, "oemcob_hrer_pu_orresh"

    const-string/jumbo v1, "rormhe__eoceh_supdrro"

    const/4 v13, 0x0

    const-string v1, "erhshdu_opo_eorru_rtc"

    const-string/jumbo v1, "other_push_error_code"

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x7

    const-string/jumbo v2, "lsOveuiphVItmhPoo"

    const-string/jumbo v2, "rhstooPuleIhOvVmi"

    const/4 v13, 0x6

    const-string/jumbo v2, "ilvupIOeqPoVhmhrs"

    const-string v2, "OtherPushVivoImpl"

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/d/a/g;->a:Ljava/lang/StringBuffer;

    const/4 v13, 0x4

    if-nez v3, :cond_0

    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x3

    new-instance v3, Ljava/lang/StringBuffer;

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x5

    iput-object v3, p0, Lcom/tencent/android/tpush/d/a/g;->a:Ljava/lang/StringBuffer;

    :cond_0
    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/g;->g(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object v3

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x2

    const-string v4, ""

    const-string v4, ""

    const/4 v13, 0x1

    const-string v4, ""

    const-string v4, ""

    if-eqz v3, :cond_4

    :try_start_0
    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x7

    const-string/jumbo v5, "npshu.vticio.mbulevso.hP"

    const-string/jumbo v5, "vlmohbviuep.co.nPitCs.uh"

    const/4 v13, 0x1

    const-string/jumbo v5, "uutmlsi.Cvhs.mipe.Pnovhc"

    const-string v5, "com.vivo.push.PushClient"

    const/4 v12, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x7

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v5
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x4

    const/4 v6, 0x0

    :try_start_1
    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x7

    new-array v7, v6, [Ljava/lang/Class;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x6

    invoke-virtual {v5, v0, v7}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v7

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x4

    new-array v8, v6, [Ljava/lang/Object;

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x4

    invoke-virtual {v7, v3, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x7

    goto/16 :goto_0

    :catchall_0
    :try_start_2
    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x4

    iget-object v7, p0, Lcom/tencent/android/tpush/d/a/g;->c:Ljava/lang/Object;

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x4

    const/4 v8, 0x1

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x2

    if-nez v7, :cond_2

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x2

    iget-object v7, p0, Lcom/tencent/android/tpush/d/a/g;->f:Ljava/lang/Class;

    const/4 v13, 0x0

    const/4 v12, 0x7

    if-nez v7, :cond_1

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x1

    const-string v7, "eveAons.oIssoceyenp.iPthchlr.suiQuurr.inuetLmtv"

    const-string/jumbo v7, "onmQpvuIuutnlehoLePussrcciiiiAt..er.ntrse.sevhy"

    const/4 v13, 0x5

    const-string v7, "PhucIbs.hetoneoriltL.rpeiyvQiosrnv.euetAsim.nuc"

    const-string v7, "com.vivo.push.listener.IPushQueryActionListener"

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-static {v7}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v7

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x1

    iput-object v7, p0, Lcom/tencent/android/tpush/d/a/g;->f:Ljava/lang/Class;

    :cond_1
    const/4 v12, 0x6

    const/4 v13, 0x3

    new-instance v7, Lcom/tencent/android/tpush/d/a/g$a;

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x5

    invoke-direct {v7, p0, p1}, Lcom/tencent/android/tpush/d/a/g$a;-><init>(Lcom/tencent/android/tpush/d/a/g;Landroid/content/Context;)V

    const/4 v13, 0x0

    iget-object v9, p0, Lcom/tencent/android/tpush/d/a/g;->f:Ljava/lang/Class;

    const/4 v13, 0x4

    invoke-virtual {v9}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v9

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x4

    new-array v10, v8, [Ljava/lang/Class;

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x3

    iget-object v11, p0, Lcom/tencent/android/tpush/d/a/g;->f:Ljava/lang/Class;

    const/4 v12, 0x1

    xor-int/2addr v13, v12

    aput-object v11, v10, v6

    const/4 v13, 0x7

    const/4 v12, 0x4

    invoke-static {v9, v10, v7}, Ljava/lang/reflect/Proxy;->newProxyInstance(Ljava/lang/ClassLoader;[Ljava/lang/Class;Ljava/lang/reflect/InvocationHandler;)Ljava/lang/Object;

    move-result-object v7

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x3

    iput-object v7, p0, Lcom/tencent/android/tpush/d/a/g;->c:Ljava/lang/Object;

    :cond_2
    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x2

    new-array v7, v8, [Ljava/lang/Class;

    const/4 v13, 0x5

    iget-object v9, p0, Lcom/tencent/android/tpush/d/a/g;->f:Ljava/lang/Class;

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x6

    aput-object v9, v7, v6

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x3

    invoke-virtual {v5, v0, v7}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x5

    new-array v5, v8, [Ljava/lang/Object;

    const/4 v12, 0x2

    move v13, v12

    iget-object v7, p0, Lcom/tencent/android/tpush/d/a/g;->c:Ljava/lang/Object;

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x4

    aput-object v7, v5, v6

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x0

    invoke-virtual {v0, v3, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v0, 0x0

    and-int/2addr v13, v0

    :goto_0
    const/4 v12, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/g;->h(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x5

    if-eqz v0, :cond_3

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-static {v5}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v5

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x6

    if-nez v5, :cond_3

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-virtual {v5, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x7

    if-nez v5, :cond_3

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x2

    iput-object v3, p0, Lcom/tencent/android/tpush/d/a/g;->g:Ljava/lang/String;

    const/4 v13, 0x7

    const/4 v12, 0x0

    const-string/jumbo v5, "vpeno_uvto"

    const-string/jumbo v5, "vto_kovpen"

    const/4 v13, 0x0

    const-string/jumbo v5, "vntke_ipoo"

    const-string/jumbo v5, "vivo_token"

    const/4 v13, 0x3

    invoke-static {p1, v5, v3}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/d/a/g;->g:Ljava/lang/String;

    :cond_3
    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x3

    if-eqz v0, :cond_4

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x3

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x5

    invoke-static {v3}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x2

    if-nez v3, :cond_4

    const/4 v13, 0x4

    const/4 v12, 0x2

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-direct {p0, v0}, Lcom/tencent/android/tpush/d/a/g;->a(Ljava/lang/String;)V
    :try_end_2
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_2 .. :try_end_2} :catch_0
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x7

    goto/16 :goto_1

    :catchall_1
    move-exception v0

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x0

    const-string v3, "gRdo rEeqrqtIr "

    const-string/jumbo v3, "oRdgIrtrqreE  e"

    const/4 v13, 0x7

    const-string/jumbo v3, "r srtdoEeR ggIe"

    const-string v3, "getRegId Error "

    const/4 v13, 0x1

    const/4 v12, 0x5

    invoke-static {v2, v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/g;->a:Ljava/lang/StringBuffer;

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x5

    const/4 v12, 0x3

    const-string v5, " srmeo,-r42ged : 1  MsCr:r"

    const-string/jumbo v5, "s-s ::C,eer 2r geM14  rdor"

    const-string v5, "errCode : -142 , errMsg : "

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x7

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v13, 0x5

    const/4 v12, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x4

    goto :goto_1

    :catch_0
    move-exception v0

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x4

    invoke-virtual {v0}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object v3

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x7

    const-string/jumbo v5, "oEtioEgt e grIoeRvceTorfIcttroarinpadxnerm gn "

    const-string v5, "eRImoon eirtirIErrco Ef vttTrggtpconnae exgado"

    const/4 v13, 0x5

    const-string v5, "dIni bteE:fRgnp cotgiogoTxavt eIterEcorane ror"

    const-string v5, "getRegId Error for InvocationTargetException: "

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x7

    invoke-static {v2, v5, v3}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/d/a/g;->a:Ljava/lang/StringBuffer;

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x4

    const-string/jumbo v5, "s:1e4ruor  d erg: -roCeM, "

    const-string v5, "-rd:o,:gr re1 M 1 sCoe4er "

    const/4 v13, 0x4

    const-string v5, "e4g :r p1reor Mred, s 1-: "

    const-string v5, "errCode : -141 , errMsg : "

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x4

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getLocalizedMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x1

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x5

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    :goto_1
    const/4 v13, 0x3

    return-object v4
.end method

.method public d(Landroid/content/Context;)Z
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo v0, "mOvIthPoqlpsbVihu"

    const-string v0, "evhhlbIoimOtVusPp"

    const/4 v6, 0x2

    const-string/jumbo v0, "rossPvtVlhpOeIhui"

    const-string v0, "OtherPushVivoImpl"

    const/4 v6, 0x7

    const/4 v5, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/d/a/g;->g(Landroid/content/Context;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x2

    move v6, v5

    if-eqz p1, :cond_1

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string v2, "Pivmms.lho.eutnup.Cisovc"

    const-string v2, "com.vivo.push.PushClient"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const-string/jumbo v3, "soiuopSrt"

    const-string/jumbo v3, "tosrpiuSu"

    const-string/jumbo v3, "isSupport"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-array v4, v1, [Ljava/lang/Class;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v2, v3, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    new-array v3, v1, [Ljava/lang/Object;

    const/4 v5, 0x3

    or-int/2addr v6, v5

    invoke-virtual {v2, p1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    check-cast p1, Ljava/lang/Boolean;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-nez p1, :cond_0

    const/4 v6, 0x5

    const-string/jumbo v2, "pivhs tpipelhutv iv u(oeor fo Sarnrn!fusa,pdoc upvt eiurh istesop t)vpe   sros"

    const/4 v6, 0x6

    const-string/jumbo v2, "oahepbfpptotnee r,uec) urldspiuprnu(  oo poa!ihr e  isfstotvursi stvs  vhvp iS"

    const-string/jumbo v2, "vivo push api isSupport() returns false, the device not support for vivo push!"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    return p1

    :catchall_0
    move-exception p1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string v2, " fiogruqCErons "

    const-string/jumbo v2, "os iforgqnrErC "

    const/4 v6, 0x1

    const-string v2, "fi rogrpsrCoi E"

    const-string/jumbo v2, "isConfig Error "

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {v0, v2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/lang/reflect/InvocationTargetException;->getCause()Ljava/lang/Throwable;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    move v6, v5

    const-string/jumbo v3, "nsst aCrqoofTroixnfgvagtic r :ropeIEeioEcort n"

    const-string/jumbo v3, "tIsr oiirfgcET :cC sgitnnofntrrpoEexo eaavroon"

    const/4 v6, 0x3

    const-string v3, "TasitEoooaoopInvgEnrgerifri o ifcCner ts:xt rc"

    const-string/jumbo v3, "isConfig Error for InvocationTargetException: "

    const/4 v5, 0x7

    shl-int/2addr v6, v5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_0
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    return v1
.end method

.method public e(Landroid/content/Context;)I
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    const/4 p1, 0x7

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    return p1
.end method

.method public f(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x6

    const-string p1, ""

    const-string p1, ""

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method
