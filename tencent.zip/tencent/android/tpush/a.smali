.class public Lcom/tencent/android/tpush/a;
.super Ljava/lang/Object;


# static fields
.field static final a:Ljava/lang/String;

.field private static b:Ljava/util/concurrent/locks/ReentrantLock;

.field private static c:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/XGPushProvider;->AUTH_PRIX:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    sput-object v0, Lcom/tencent/android/tpush/a;->a:Ljava/lang/String;

    const/4 v2, 0x0

    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    sput-object v0, Lcom/tencent/android/tpush/a;->b:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    sput-object v0, Lcom/tencent/android/tpush/a;->c:Ljava/util/Map;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " @s@@@ ~@i~@ ~~ bl o~m   .~@t~c~/@i @~t@ @@@bf4y~ i  ~odo~@ -r n~@vSo1@~ ~@bo/@~u@~l@s~M~a ~f~~K"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x2

    move v2, v1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    sget-object p0, Lcom/tencent/android/tpush/a;->a:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public static declared-synchronized a(Landroid/content/Context;)Ljava/util/Map;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Landroid/content/pm/ProviderInfo;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-class v0, Lcom/tencent/android/tpush/a;

    const-class v0, Lcom/tencent/android/tpush/a;

    const/4 v7, 0x5

    const-class v0, Lcom/tencent/android/tpush/a;

    const-class v0, Lcom/tencent/android/tpush/a;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance v1, Ljava/util/HashMap;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v2, 0x5

    const/4 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v3, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p0, v2, v3, v3}, Landroid/content/pm/PackageManager;->queryContentProviders(Ljava/lang/String;II)Ljava/util/List;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v2, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    check-cast v2, Landroid/content/pm/ProviderInfo;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v3, v2, Landroid/content/pm/ProviderInfo;->name:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-class v4, Lcom/tencent/android/tpush/XGPushProvider;

    const/4 v7, 0x7

    const-class v4, Lcom/tencent/android/tpush/XGPushProvider;

    const-class v4, Lcom/tencent/android/tpush/XGPushProvider;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v3, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v3, v2, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    const/4 v6, 0x7

    or-int/2addr v7, v6

    iget-object v4, v2, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    const/4 v7, 0x5

    invoke-static {v4}, Lcom/tencent/android/tpush/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v3, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v3, v2, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-interface {v1, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string v3, "iPslodvrisrUt"

    const-string v3, "ProviderUtils"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string/jumbo v5, "sAgmitpotX  lm alGp c:"

    const-string/jumbo v5, "ts mla tAlpi lX Gcp:go"

    const-string/jumbo v5, "pclloGlX:pto sA t  iea"

    const-string v5, "get local XG App list:"

    const/4 v7, 0x3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v5, v2, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v5, ","

    const-string v5, ","

    const/4 v7, 0x7

    const-string v5, ","

    const-string v5, ","

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v5, v2, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const-string v5, ","

    const-string v5, ","

    const/4 v7, 0x3

    const-string v5, ","

    const-string v5, ","

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v2, v2, Landroid/content/pm/ProviderInfo;->name:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto/16 :goto_0

    :catchall_0
    move-exception p0

    :try_start_2
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string v2, "ePtsoriUldiro"

    const/4 v7, 0x6

    const-string v2, "ProviderUtils"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string/jumbo v3, "sdacdba hgeiPr aeagnaem "

    const-string v3, "Package manager has died"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v2, v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :cond_1
    monitor-exit v0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    return-object v1

    :catchall_1
    move-exception p0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    monitor-exit v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x1

    throw p0
.end method

.method private static a(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :cond_0
    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v1, "nent/cub:o"

    const-string v1, "e:ncobntt/"

    const/4 v3, 0x6

    const-string v1, "cto/ntepn:"

    const-string v1, "content://"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->AUTH_PRIX:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v1, "/"

    const/4 v3, 0x5

    const-string v1, "/"

    const-string v1, "/"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p0, p1}, Lcom/tencent/tpns/baseapi/crosssp/ProviderMessage;->getType(Landroid/content/Context;Landroid/net/Uri;)Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo p1, "rirlidUtquseP"

    const-string/jumbo p1, "rPvisluritUde"

    const/4 v3, 0x6

    const-string/jumbo p1, "oisUversdirlt"

    const-string p1, "ProviderUtils"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v0, " temobereriperrhad rravo"

    const-string v0, "er rtrvpbirordare ePehoa"

    const/4 v3, 0x1

    const-string v0, "eeraoivrr erPtobah oedtr"

    const-string v0, "heartbeat Provider error"

    const/4 v3, 0x1

    invoke-static {p1, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p2}, Landroid/content/Intent;->toURI()Ljava/lang/String;

    move-result-object p2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    return p0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 9

    :try_start_0
    const/4 v7, 0x1

    move v8, v7

    new-instance v0, Landroid/content/ContentValues;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const/4 v8, 0x7

    const-string v1, "eyk"

    const-string v1, "eyk"

    const/4 v8, 0x4

    const-string/jumbo v1, "yek"

    const-string/jumbo v1, "key"

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v0, v1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string/jumbo v1, "qcno:b/etn"

    const-string/jumbo v1, "ntc/n/o:qe"

    const/4 v8, 0x6

    const-string v1, "/e/tt:unoc"

    const-string v1, "content://"

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    sget-object p1, Lcom/tencent/android/tpush/XGPushProvider;->AUTH_PRIX:Ljava/lang/String;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string p1, "/"

    const-string p1, "/"

    const/4 v8, 0x2

    const-string p1, "/"

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    sget-object p1, Lcom/tencent/android/tpush/TypeStr;->msg:Lcom/tencent/android/tpush/TypeStr;

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {p1}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {p0, p1, v0}, Lcom/tencent/tpns/baseapi/crosssp/ProviderMessage;->insert(Landroid/content/Context;Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/4 p0, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    return p0

    :catchall_0
    move-exception p1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string/jumbo p2, "sdlioivpPsUer"

    const-string/jumbo p2, "visPlreUsdori"

    const/4 v8, 0x5

    const-string/jumbo p2, "sodileUPqtrvi"

    const-string p2, "ProviderUtils"

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string v0, "eeskPBmMygsdgsmN"

    const-string v0, "gNgmmkeBMsydPsae"

    const/4 v8, 0x2

    const-string/jumbo v0, "sendMsgByPkgName"

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {p2, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    const/16 v2, -0x68

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const-string v0, "P omNrBs:grsdameegknM"

    const-string v0, "BMreongadsekmrgPysN: "

    const/4 v8, 0x3

    const-string/jumbo v0, "nMNmodkeggeryr:ss eBP"

    const-string/jumbo v0, "sendMsgByPkgName err:"

    const/4 v8, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/base/util/Util;->getThrowableToString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-string v6, "bebni"

    const-string v6, "binre"

    const/4 v8, 0x4

    const-string/jumbo v6, "nurne"

    const-string/jumbo v6, "inner"

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-static/range {v1 .. v6}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 p0, 0x3

    const/4 p0, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    return p0
.end method

.method public static b(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/TypeStr;->hearbeat:Lcom/tencent/android/tpush/TypeStr;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/a;->a(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x7

    move v2, v1

    return-void
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const-string/jumbo v1, "tcn/oenp:u"

    const-string v1, "enntotuc:/"

    const-string v1, "/tno/e:tqc"

    const-string v1, "content://"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object p1, Lcom/tencent/android/tpush/XGPushProvider;->AUTH_PRIX:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string p1, "/"

    const-string p1, "/"

    const/4 v3, 0x7

    const-string p1, "/"

    const-string p1, "/"

    const/4 v3, 0x5

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget-object p1, Lcom/tencent/android/tpush/TypeStr;->feedback:Lcom/tencent/android/tpush/TypeStr;

    const/4 v3, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Landroid/content/ContentValues;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v0}, Landroid/content/ContentValues;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v1, "adseekcf"

    const-string v1, "dfckeeap"

    const-string v1, "ebcmfdka"

    const-string v1, "feedback"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1, p2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 p2, 0x0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0, p1, v0, p2, p2}, Lcom/tencent/tpns/baseapi/crosssp/ProviderMessage;->update(Landroid/content/Context;Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string p1, "PireoiUltqvos"

    const-string/jumbo p1, "oUrstPliqivre"

    const/4 v3, 0x1

    const-string p1, "PotrdbUelsvri"

    const-string p1, "ProviderUtils"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string/jumbo p2, "ro seru "

    const-string/jumbo p2, "orse :r "

    const/4 v3, 0x6

    const-string/jumbo p2, "r ore:rp"

    const-string p2, "error : "

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p1, p2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public static c(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-object v0, Lcom/tencent/android/tpush/TypeStr;->hearbeat_cyclecheck:Lcom/tencent/android/tpush/TypeStr;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/a;->a(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public static d(Landroid/content/Context;)Ljava/util/Map;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/Map<",
            "Ljava/lang/Long;",
            "Lcom/tencent/android/tpush/data/RegisterEntity;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/service/cache/CacheManager;->getCurrentAppRegisterEntity(Landroid/content/Context;)Lcom/tencent/android/tpush/data/RegisterEntity;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-eqz p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->accessId:J

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {v0, v1, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object v0
.end method
