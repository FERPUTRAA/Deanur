.class Lcom/tencent/android/tpush/XGPush4Msdk$9;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPush4Msdk;->deleteTag(Landroid/content/Context;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/content/Context;


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$9;->a:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$9;->b:Landroid/content/Context;

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, " ~s@u4 l~y@/~@@~~ / ~K ~b-it@if~ ~~@~c@@f~b~@i oo1.r @ @ldn~~av  @@ S~om~@ob~@o@~@ ~Mo @ s @ ~t~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x3

    sget-boolean v0, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-eqz v0, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string v1, " eTmesgamleNtae=dg:"

    const-string v1, "Tdsagg=aeeNm l:etet"

    const/4 v10, 0x4

    const-string v1, "eaT=olge ttmN:adege"

    const-string v1, "deleteTag: tagName="

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$9;->a:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x4

    const-string v1, "=mq,pbidp"

    const-string v1, "dpimA=,qp"

    const/4 v10, 0x0

    const-string v1, "=,Apqpuqd"

    const-string v1, ",qqAppid="

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/tencent/android/tpush/XGPush4Msdk;->c()J

    move-result-wide v1

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    const-string v1, ",g=isxdpao_cs"

    const-string v1, "_a,cocixsgsd="

    const/4 v10, 0x5

    const-string v1, "aix_,sdeqcs=c"

    const-string v1, ",xg_accessid="

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$9;->b:Landroid/content/Context;

    const/4 v10, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    const-string v1, "GPsMsXsbh4d"

    const-string v1, "4hMPsbGdksX"

    const/4 v10, 0x1

    const-string v1, "XGPush4Msdk"

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$9;->b:Landroid/content/Context;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$9;->a:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v4, 0x2

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v5

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$9;->b:Landroid/content/Context;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAppKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v8, p0, Lcom/tencent/android/tpush/XGPush4Msdk$9;->a:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x5

    return-void
.end method
