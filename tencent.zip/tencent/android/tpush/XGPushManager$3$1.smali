.class Lcom/tencent/android/tpush/XGPushManager$3$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager$3;->TRun()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/XGPushManager$3;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGPushManager$3;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$3$1;->a:Lcom/tencent/android/tpush/XGPushManager$3;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, ".~s@@ /v ~~~@bs~@~@~@ni @~~ l~ Sl@t~@ 1tb@@u@~Kb@~~o~m @~ ~@d4~@o@~@ Mi  o @@f -~i of y~co /ao ~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$3$1;->a:Lcom/tencent/android/tpush/XGPushManager$3;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v1, v0, Lcom/tencent/android/tpush/XGPushManager$3;->a:Landroid/content/Context;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v2, v0, Lcom/tencent/android/tpush/XGPushManager$3;->b:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget v3, v0, Lcom/tencent/android/tpush/XGPushManager$3;->c:I

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v4, v0, Lcom/tencent/android/tpush/XGPushManager$3;->d:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v0, v0, Lcom/tencent/android/tpush/XGPushManager$3;->e:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v1, v2, v3, v4, v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-void
.end method
