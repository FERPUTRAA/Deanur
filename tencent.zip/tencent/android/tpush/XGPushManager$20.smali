.class Lcom/tencent/android/tpush/XGPushManager$20;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->setDefaultNotificationBuilder(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/XGPushNotificationBuilder;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$20;->a:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x6

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$20;->b:Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v0, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " ~s/@~~b~c@@~-i ~oS~@o~@d @@fo~o@a@@y@~n~ ~@~  vt@o~  1  t   @@f~@~/oiis~@u@ @r~l.~  4bmb~lK~M~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$20;->a:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$20;->b:Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    invoke-static {v0, v1, v2}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;ILcom/tencent/android/tpush/XGPushNotificationBuilder;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void
.end method
