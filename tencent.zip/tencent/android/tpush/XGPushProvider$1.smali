.class Lcom/tencent/android/tpush/XGPushProvider$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushProvider;->c()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/XGPushProvider;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGPushProvider;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushProvider$1;->a:Lcom/tencent/android/tpush/XGPushProvider;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~@sir@m1@i~b@ lto~n@@@@~@ ~~K/  @ay@f S/4@~b@~~i~l  u~v@~f@s-b ~t ~oo@~~o~ o @@   ~@ ~~  @d~oM.c"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/XGPushProvider;->a()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v1, "arsmetbusysvit_e_r_sr"

    const-string/jumbo v1, "vts__rybsraereuse_sti"

    const/4 v4, 0x4

    const-string/jumbo v1, "rtaeorsysbe_critu__ve"

    const-string/jumbo v1, "start_service_by_user"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {v0, v1, v2}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getBoolean(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    sget-boolean v1, Lcom/tencent/android/tpush/XGPushConfig;->autoInit:Z

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v2, "omPrvbsGiePudh"

    const-string/jumbo v2, "ordmviGshrPeuP"

    const/4 v4, 0x5

    const-string v2, "XGPushProvider"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo v0, "iotilaunob"

    const-string/jumbo v0, "iinlobalto"

    const/4 v4, 0x6

    const-string/jumbo v0, "ioliblapGt"

    const-string/jumbo v0, "initGlobal"

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/XGPushProvider;->a()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v0, "Gtaili nqosoiblbhb"

    const-string/jumbo v0, "ohtnibbi biloaGlsl"

    const/4 v4, 0x5

    const-string/jumbo v0, "iosaGibtlh llsonba"

    const-string/jumbo v0, "initGlobal abolish"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method
