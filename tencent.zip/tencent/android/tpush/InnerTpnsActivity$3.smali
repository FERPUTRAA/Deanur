.class Lcom/tencent/android/tpush/InnerTpnsActivity$3;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/InnerTpnsActivity;->c(Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/net/Uri;

.field final synthetic b:Lcom/tencent/android/tpush/InnerTpnsActivity;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/net/Uri;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$3;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$3;->a:Landroid/net/Uri;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s@M@m@~b/obof~~v~o-1~ ~ @ot @ @@/y@t@f ~@   @@~no@@.~@@~l~ ~~uiK@o r4~@S@~ ~sai~~~  l@b   idc~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$3;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-lez v0, :cond_0

    const/4 v3, 0x5

    const-string/jumbo v0, "tnsmienIpvisTnAtc"

    const-string v0, "IAstivnseicTpnrnt"

    const/4 v3, 0x4

    const-string/jumbo v0, "vnnioictTIerpstyn"

    const-string v0, "InnerTpnsActivity"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string v1, "eeleebahaiiCirenil Lbtnno dkotflpanhDl"

    const-string/jumbo v1, "otherChannelDeepLink initGlobal failed"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$3;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$3;->a:Landroid/net/Uri;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/net/Uri;)V

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method
