.class Lcom/tencent/android/tpush/XGPushManager$9;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->d(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/XGIOperateCallback;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$9;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v1, "l slso gaca cTkab"

    const-string/jumbo v1, "kbsT  lcog ac ala"

    const/4 v4, 0x6

    const-string v1, "Tag call back to "

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v1, "MPrmesXumagnG"

    const-string v1, "MhumXergGPasn"

    const/4 v4, 0x3

    const-string v1, "MPraoeaXGhusn"

    const-string v1, "XGPushManager"

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v2, Lcom/tencent/android/tpush/XGPushManager$9$1;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v2, p0, p2}, Lcom/tencent/android/tpush/XGPushManager$9$1;-><init>(Lcom/tencent/android/tpush/XGPushManager$9;Landroid/content/Intent;)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    goto :goto_0

    :catchall_0
    move-exception p2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v2, "gleahbrdontbcaanloarrc  Mkl eeaa "

    const-string v2, "aga ole  cMeanae lonarrrtdackglhb"

    const/4 v4, 0x5

    const-string v2, "eggrl uaaccarr eht lnlaoedbnMkr a"

    const-string/jumbo v2, "tagManager handle callback error "

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p2}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;)Z

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void
.end method
