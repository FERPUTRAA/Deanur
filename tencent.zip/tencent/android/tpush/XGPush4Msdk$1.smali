.class Lcom/tencent/android/tpush/XGPush4Msdk$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPush4Msdk;->setDebugServerInfo(Landroid/content/Context;Ljava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$1;->a:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@bs@.@no~i~@y@ i~ bom @~@~i@oc@~4@ r~@~ Ss/@t~ @t-@fl@~~~M  u~~ @ bova  ~@~ o~fd1K@~o~/ l~ @~ @~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$1;->a:Landroid/content/Context;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const/4 v2, 0x0

    invoke-static {v0, v1, v2}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$1;->a:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPush4Msdk;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->remove(Landroid/content/Context;Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method
