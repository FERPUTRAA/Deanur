.class public Lcom/tencent/android/tpush/XGPushManager;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20150316"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->RECEIVERCHECK:Lcom/jg/EType;,
        .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/XGPushManager$d;,
        Lcom/tencent/android/tpush/XGPushManager$a;,
        Lcom/tencent/android/tpush/XGPushManager$b;,
        Lcom/tencent/android/tpush/XGPushManager$c;,
        Lcom/tencent/android/tpush/XGPushManager$AccountType;,
        Lcom/tencent/android/tpush/XGPushManager$AccountInfo;
    }
.end annotation


# static fields
.field public static CONNECT_STATE_CONNECTED:I = 0x0

.field public static CONNECT_STATE_DEFAULT:I = 0x0

.field public static CONNECT_STATE_NOT_CONNECTED:I = 0x0

.field public static final MAX_TAG_LENGTH:I = 0x32

.field public static final MAX_TAG_SIZE:I = 0x1f4

.field public static final OPERATION_FAIL:I = 0x1

.field public static final OPERATION_REQ_REGISTER:I = 0x64

.field public static final OPERATION_REQ_UNREGISTER:I = 0x65

.field public static final OPERATION_SUCCESS:I

.field private static a:Z

.field private static b:Landroid/content/Context;

.field private static c:Ljava/lang/Long;

.field private static d:J

.field private static volatile e:Lcom/tencent/tpns/baseapi/base/util/TTask;

.field private static volatile f:Ljava/util/Queue;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Queue<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private static g:Lcom/tencent/android/tpush/XGPushNotifactionCallback;

.field private static h:Lcom/tencent/android/tpush/XGSysPushNotifactionCallback;

.field private static i:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Lcom/tencent/android/tpush/XGPushManager$b;",
            "Lcom/tencent/android/tpush/XGPushManager$c;",
            ">;"
        }
    .end annotation
.end field

.field private static final j:[C

.field public static lastSuccessRegisterMap:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v4, 0x7

    move v5, v4

    sput-object v0, Lcom/tencent/android/tpush/XGPushManager;->lastSuccessRegisterMap:Ljava/util/Map;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    sput-boolean v0, Lcom/tencent/android/tpush/XGPushManager;->a:Z

    const/4 v4, 0x0

    xor-int/2addr v5, v4

    const/4 v1, 0x0

    or-int/2addr v5, v1

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    sput-object v1, Lcom/tencent/android/tpush/XGPushManager;->b:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    sput-object v2, Lcom/tencent/android/tpush/XGPushManager;->c:Ljava/lang/Long;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-wide/16 v2, 0x7530

    const-wide/16 v2, 0x7530

    const/4 v5, 0x5

    const-wide/16 v2, 0x7530

    const-wide/16 v2, 0x7530

    const/4 v5, 0x1

    const/4 v4, 0x3

    sput-wide v2, Lcom/tencent/android/tpush/XGPushManager;->d:J

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    sput-object v1, Lcom/tencent/android/tpush/XGPushManager;->e:Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    new-instance v2, Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-direct {v2}, Ljava/util/concurrent/ConcurrentLinkedQueue;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    sput-object v2, Lcom/tencent/android/tpush/XGPushManager;->f:Ljava/util/Queue;

    const/4 v5, 0x3

    const/4 v2, 0x2

    const/4 v5, 0x6

    const/4 v2, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    sput v2, Lcom/tencent/android/tpush/XGPushManager;->CONNECT_STATE_CONNECTED:I

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    sput v0, Lcom/tencent/android/tpush/XGPushManager;->CONNECT_STATE_DEFAULT:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v0, -0x1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    sput v0, Lcom/tencent/android/tpush/XGPushManager;->CONNECT_STATE_NOT_CONNECTED:I

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    sput-object v1, Lcom/tencent/android/tpush/XGPushManager;->g:Lcom/tencent/android/tpush/XGPushNotifactionCallback;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    sput-object v1, Lcom/tencent/android/tpush/XGPushManager;->h:Lcom/tencent/android/tpush/XGSysPushNotifactionCallback;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    sput-object v0, Lcom/tencent/android/tpush/XGPushManager;->i:Ljava/util/Map;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string v0, "82sA1C7F03Es5BD4"

    const-string v0, "D8s1570AFC4E2B93"

    const/4 v5, 0x5

    const-string v0, "0123456789ABCDEF"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->toCharArray()[C

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    sput-object v0, Lcom/tencent/android/tpush/XGPushManager;->j:[C

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method static a(Landroid/content/Context;Lcom/tencent/android/tpush/XGLocalMessage;J)J
    .locals 11

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const-string/jumbo v2, "uhnmGmaresMgX"

    const-string v2, "gMrmahPeGunsX"

    const-string v2, "areaosPXGnuMh"

    const-string v2, "XGPushManager"

    if-eqz p0, :cond_3

    if-nez p1, :cond_0

    goto :goto_1

    :cond_0
    :try_start_0
    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/security/Security;->checkTpnsSecurityLibSo(Landroid/content/Context;)Z

    move-result v3

    if-nez v3, :cond_1

    return-wide v0

    :cond_1
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    new-instance v3, Lcom/tencent/android/tpush/XGPushManager$16;

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-object v4, v3

    move-wide v5, p2

    move-object v7, p0

    move-object v7, p0

    move-object v7, p0

    move-object v7, p0

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-wide v9, v0

    invoke-direct/range {v4 .. v10}, Lcom/tencent/android/tpush/XGPushManager$16;-><init>(JLandroid/content/Context;Lcom/tencent/android/tpush/XGLocalMessage;J)V

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p0

    invoke-virtual {p0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object p0

    invoke-virtual {p0}, Ljava/lang/Thread;->getId()J

    move-result-wide p0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object p2

    invoke-virtual {p2}, Ljava/lang/Thread;->getId()J

    move-result-wide p2

    cmp-long p0, p0, p2

    if-nez p0, :cond_2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p0

    invoke-virtual {p0, v3}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    goto :goto_0

    :cond_2
    invoke-virtual {v3}, Lcom/tencent/tpns/baseapi/base/util/TTask;->run()V

    :goto_0
    neg-long p0, v0

    return-wide p0

    :cond_3
    :goto_1
    const-string p0, "cl mobuulcNd l=n Lnn o==id ret alsno=clfioat otgxao"

    const-string p0, "fenoolt=c=g t loLaimdil ncuxu olon   aas=Nttrlodcn="

    const-string/jumbo p0, "tdutcmuolg=nliatat  arnoox=cNi e nli Lofu lndol==cs"

    const-string p0, "addLocalNotification context == null or msg == null"

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-wide v0

    :catchall_0
    move-exception p0

    const-string/jumbo p1, "tdtc aapfdNoaiLinicob"

    const-string p1, "i aNabLnitocfatoodcid"

    const-string/jumbo p1, "tocniNaaqf coioaddlLi"

    const-string p1, "addLocalNotification "

    invoke-static {v2, p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const-wide/16 p0, 0x0

    const-wide/16 p0, 0x0

    const-wide/16 p0, 0x0

    const-wide/16 p0, 0x0

    return-wide p0
.end method

.method static synthetic a(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;Lcom/tencent/android/tpush/XGPushManager$AccountInfo;)Landroid/content/Intent;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o~s/i~~-@4@f1l@  mooli@~@s~ b@S.~@ o@@~  @ ~t~~do~~ f@ @@~o@~ ~~@cub  ~r~@@~/  ~i@ @  Kav@tMyb~n"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;Lcom/tencent/android/tpush/XGPushManager$AccountInfo;)Landroid/content/Intent;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method

.method static a(Landroid/app/Activity;)Lcom/tencent/android/tpush/XGPushClickedResult;
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string v1, ">aemdtu>A ciriittt> ctoyiySvv=n"

    const-string/jumbo v1, "o=indtutaeyiaAvityS>>> ittccrv "

    const/4 v6, 0x4

    const-string v1, ">>> onActivityStarted activity="

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string v1, "areaosphMXngu"

    const-string v1, "grauhaepsXnMG"

    const/4 v6, 0x6

    const-string v1, "aeMGPbarshguX"

    const-string v1, "XGPushManager"

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    or-int/2addr v6, v5

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz p0, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    if-nez v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string/jumbo v2, "phtsSuuatgMG."

    const-string/jumbo v2, "tag.tpush.MSG"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string/jumbo v4, "uret"

    const-string/jumbo v4, "treu"

    const/4 v6, 0x6

    const-string/jumbo v4, "teur"

    const-string/jumbo v4, "true"

    const/4 v6, 0x1

    invoke-virtual {v4, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-nez v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    return-object v0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v3}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-lez v3, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    return-object v0

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    new-instance v0, Lcom/tencent/android/tpush/XGPushClickedResult;

    const/4 v6, 0x5

    const/4 v5, 0x4

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGPushClickedResult;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/XGPushClickedResult;->parseIntent(Landroid/content/Intent;)V

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-instance v3, Lcom/tencent/android/tpush/XGPushManager$14;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {v3, p0, v1}, Lcom/tencent/android/tpush/XGPushManager$14;-><init>(Landroid/app/Activity;Landroid/content/Intent;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v2, v3}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :cond_3
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    return-object v0
.end method

.method static synthetic a(Lcom/tencent/tpns/baseapi/base/util/TTask;)Lcom/tencent/tpns/baseapi/base/util/TTask;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    sput-object p0, Lcom/tencent/android/tpush/XGPushManager;->e:Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p0
.end method

.method static synthetic a(Ljava/lang/Long;)Ljava/lang/Long;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    sput-object p0, Lcom/tencent/android/tpush/XGPushManager;->c:Ljava/lang/Long;

    const/4 v0, 0x2

    xor-int/2addr v1, v0

    return-object p0
.end method

.method private static a(Landroid/content/Context;J)Ljava/lang/String;
    .locals 12

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    const-string v0, "gGMueqPpaaXhs"

    const-string v0, "hneaasuPqgMXG"

    const/4 v11, 0x5

    const-string v0, "aanXMuegqhrPs"

    const-string v0, "XGPushManager"

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x7

    const/4 v1, 0x0

    :try_start_0
    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush(Landroid/content/Context;)Z

    move-result v2

    const/4 v11, 0x5

    const/4 v10, 0x6

    if-eqz v2, :cond_7

    const/4 v11, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v2}, Lcom/tencent/android/tpush/d/d;->m()Z

    move-result v2

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x0

    if-eqz v2, :cond_7

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v11, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v10, 0x0

    shr-int/2addr v11, v10

    cmp-long v6, p1, v4

    const/4 v10, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-wide/16 v7, 0xfa0

    const-wide/16 v7, 0xfa0

    const/4 v11, 0x5

    const-wide/16 v7, 0xfa0

    const-wide/16 v7, 0xfa0

    const/4 v11, 0x6

    const/4 v10, 0x7

    if-ltz v6, :cond_0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    cmp-long v6, p1, v7

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    if-lez v6, :cond_1

    :cond_0
    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x1

    const-string v9, "ass  lwr mtn ansh eit:eictvhna ypsucdiileo"

    const-string v9, "  sl nist is:tvcoricadlyntean mauwieh enhp"

    const/4 v11, 0x1

    const-string v9, "heemnw aaei: onc mrlpidsuinct lthtvias yhn"

    const-string/jumbo v9, "invalid sync wait other channel push time:"

    const/4 v10, 0x3

    xor-int/2addr v11, v10

    invoke-virtual {v6, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v6, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x3

    const-string p1, " otmos e  setr"

    const-string p1, " ,rmset e ost "

    const-string p1, ",rte b  oe4 ss"

    const-string p1, ", reset to 4s "

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v6, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    move-wide p1, v7

    :cond_1
    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    long-to-int v6, p1

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    div-int/lit8 v6, v6, 0x2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v11, 0x6

    const/16 v7, 0x3e8

    const/4 v11, 0x3

    const/4 v10, 0x4

    if-eqz v6, :cond_3

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x7

    if-le v7, v6, :cond_3

    const/4 v11, 0x5

    const/16 v7, 0x14

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-le v6, v7, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    goto :goto_0

    :cond_2
    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    move v6, v7

    move v6, v7

    const/4 v11, 0x0

    move v6, v7

    move v6, v7

    :goto_0
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x6

    move v7, v6

    move v7, v6

    const/4 v11, 0x7

    move v7, v6

    move v7, v6

    :cond_3
    :try_start_1
    const/4 v11, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v6

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {v6}, Lcom/tencent/android/tpush/d/d;->h()Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-static {v6}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v8

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x0

    if-nez v8, :cond_4

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    const-string/jumbo p2, "nagoocuk h:e einTl et"

    const-string p2, "T: coao li eenkhentgs"

    const/4 v11, 0x6

    const-string p2, "caeke hpi le n:ngTt o"

    const-string p2, "get chanelToken is : "

    const/4 v10, 0x4

    xor-int/2addr v11, v10

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    move v11, v10

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object p0

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/d/d;->q()V

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    return-object v6

    :cond_4
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v6

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v6}, Lcom/tencent/android/tpush/d/d;->i()Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-static {v6}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v8

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-nez v8, :cond_5

    const/4 v11, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x3

    const-string p2, "efTgk  tqniesobm: "

    const-string p2, "T kenbot e m:fcigs"

    const-string/jumbo p2, "scsT eok ti: gf en"

    const-string p2, "get fcmToken is : "

    const/4 v11, 0x4

    const/4 v10, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object p0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/d/d;->q()V

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    return-object v6

    :cond_5
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    cmp-long v6, p1, v4

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-eqz v6, :cond_6

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    int-to-long v8, v7

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-static {v8, v9}, Ljava/lang/Thread;->sleep(J)V
    :try_end_1
    .catch Ljava/lang/InterruptedException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_6
    :try_start_2
    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v8

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    sub-long/2addr v8, v2

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    cmp-long v6, v8, p1

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-ltz v6, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    goto :goto_1

    :catchall_0
    const/4 v11, 0x4

    const/4 v10, 0x4

    const-string/jumbo p0, "n:tmrralsgTerEutoPhc !le rOh ko"

    const-string p0, "OtherPush: call getToken Error!"

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    return-object v1

    :catch_0
    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-string/jumbo p0, "o!Pnouieertpecdertoautgr lpuOnIe xhc:EsetthkTl"

    const-string/jumbo p0, "pEtp cukg rthox!heetI: tuldreaPTseturleceoninO"

    const/4 v11, 0x6

    const-string p0, "c tdlbnein aesl:rtnItTkPthEgupeoceurxrpe!he tO"

    const-string p0, "OtherPush: call getToken InterruptedException!"

    const/4 v11, 0x5

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x1

    return-object v1

    :catchall_1
    :cond_7
    :goto_1
    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x0

    const-string/jumbo p0, "kPh/rhu Cegnosotatt/e unp  "

    const-string/jumbo p0, "ro thnnpkP/g tu/he etCaso t"

    const/4 v11, 0x6

    const-string/jumbo p0, "rtP ntup/ke Cs/agthoo h een"

    const-string p0, "Can\'t get otherPush token "

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    return-object v1
.end method

.method static synthetic a(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->b(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-object p0
.end method

.method private static a(Ljava/lang/String;I)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v0, Lorg/json/JSONArray;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    new-instance v1, Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v4, 0x5

    const-string/jumbo v2, "nteaqpcuq_yc"

    const-string/jumbo v2, "ynac_tcequpt"

    const/4 v4, 0x5

    const-string v2, "acsuptectn_o"

    const-string v2, "account_type"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, v2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget-object v2, Lcom/tencent/android/tpush/XGPushManager$AccountType;->PHONE_NUMBER:Lcom/tencent/android/tpush/XGPushManager$AccountType;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGPushManager$AccountType;->getValue()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-ne p1, v2, :cond_0

    const/4 v3, 0x7

    and-int/2addr v4, v3

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/security/Security;->encryptSrvData([B)[B

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->bytesToHex([B)Ljava/lang/String;

    move-result-object p0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo p1, "tonmcuc"

    const-string p1, "account"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, p1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo p1, "usXnorgahGesP"

    const-string p1, "XasushPGrgane"

    const/4 v4, 0x3

    const-string/jumbo p1, "shXgGbearPuMa"

    const-string p1, "XGPushManager"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v0, "cnemroutAtaJoT:gSAprycysertn"

    const/4 v4, 0x4

    const-string/jumbo v0, "yytrrpugon:cstAsTtJecenSraoA"

    const-string v0, "getTypeAccountsJsonArrayStr:"

    invoke-static {p1, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 p0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-object p0
.end method

.method private static a(Ljava/util/List;)Ljava/lang/String;
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tencent/android/tpush/XGPushManager$AccountInfo;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    const-string/jumbo v0, "rgoJo|Apnog sfS eirnuttrtaIAoysnc"

    const-string/jumbo v0, "tr|ooSouAItyrcsiarJcefnngsto ng A"

    const/4 v9, 0x0

    const-string v0, "getAccountInfosJsonArrayString | "

    const/4 v8, 0x7

    shr-int/2addr v9, v8

    const-string v1, "eGbaasrgqnuMh"

    const-string/jumbo v1, "nPahabGMegurs"

    const/4 v9, 0x5

    const-string v1, "hssPMuanGgXre"

    const-string v1, "XGPushManager"

    const/4 v9, 0x3

    const/4 v8, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v9, 0x2

    const-string v2, ""

    const-string v2, ""

    const/4 v9, 0x6

    const/4 v8, 0x6

    if-eqz p0, :cond_3

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v3

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-nez v3, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    goto/16 :goto_1

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x0

    new-instance v3, Lorg/json/JSONArray;

    const/4 v9, 0x6

    invoke-direct {v3}, Lorg/json/JSONArray;-><init>()V

    :try_start_0
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-eqz v4, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    check-cast v4, Lcom/tencent/android/tpush/XGPushManager$AccountInfo;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-eqz v4, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object v5, v4, Lcom/tencent/android/tpush/XGPushManager$AccountInfo;->accountName:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x6

    invoke-static {v5}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-nez v5, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    new-instance v5, Lorg/json/JSONObject;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V

    const/4 v9, 0x3

    const-string v6, "coumcau"

    const-string/jumbo v6, "ocuacnu"

    const/4 v9, 0x2

    const-string v6, "ccauoto"

    const-string v6, "account"

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object v7, v4, Lcom/tencent/android/tpush/XGPushManager$AccountInfo;->accountName:Ljava/lang/String;

    const/4 v9, 0x3

    invoke-virtual {v5, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string v6, "cy_oubctaept"

    const-string v6, "capytucptoe_"

    const-string v6, "_etntoucuayc"

    const-string v6, "account_type"

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    iget v4, v4, Lcom/tencent/android/tpush/XGPushManager$AccountInfo;->accountType:I

    const/4 v9, 0x6

    const/4 v8, 0x1

    invoke-virtual {v5, v6, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v3, v5}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    goto :goto_0

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    move v9, v8

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v3}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v3}, Lorg/json/JSONArray;->length()I

    move-result p0

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-lez p0, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v3}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-static {v1, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_3
    :goto_1
    const/4 v8, 0x7

    move v9, v8

    return-object v2
.end method

.method private static a(Ljava/util/Map;)Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string/jumbo v1, "nGaguqrpPaseX"

    const-string/jumbo v1, "nauXaPGsqMrge"

    const/4 v8, 0x1

    const-string/jumbo v1, "rnaPXGusqhaMe"

    const-string v1, "XGPushManager"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-eqz p0, :cond_5

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-interface {p0}, Ljava/util/Map;->isEmpty()Z

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    if-eqz v2, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    goto/16 :goto_1

    :cond_0
    const/4 v8, 0x1

    invoke-interface {p0}, Ljava/util/Map;->size()I

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x6

    const/16 v3, 0x32

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-le v2, v3, :cond_1

    const/4 v7, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string/jumbo p0, "ouszstie"

    const-string/jumbo p0, "sesuzito"

    const/4 v8, 0x7

    const-string/jumbo p0, "ousmezit"

    const-string/jumbo p0, "out_size"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    return-object p0

    :cond_1
    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance v2, Lorg/json/JSONObject;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-eqz v4, :cond_4

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    check-cast v4, Ljava/util/Map$Entry;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    check-cast v5, Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {v5}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v6

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-eqz v6, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string/jumbo p0, "ymtpo"

    const-string/jumbo p0, "pmymt"

    const/4 v8, 0x6

    const-string p0, "bempt"

    const-string p0, "empty"

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    return-object p0

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v5}, Ljava/lang/String;->length()I

    move-result v6

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-le v6, v3, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    const-string/jumbo p0, "tohgoeutn_"

    const/4 v8, 0x3

    const-string p0, "httogluenu"

    const-string/jumbo p0, "out_length"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    return-object p0

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    check-cast v4, Ljava/lang/String;

    const/4 v7, 0x4

    move v8, v7

    invoke-virtual {v2, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x7

    goto :goto_0

    :cond_4
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    const-string/jumbo v2, "tegutbdpraMoteircfptexmAunetrFpob  "

    const-string/jumbo v2, "otua bFAepfxcemrtopttertM bgdureine"

    const/4 v8, 0x5

    const-string v2, "FoAiotetqMcserub mp aedrntexetprufg"

    const-string/jumbo v2, "unexpected for getAttributesFromMap"

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    return-object v0

    :cond_5
    :goto_1
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string/jumbo p0, "musAars utppttb areretg  rihnM uFlt etsubaeeiittale-ots>r"

    const-string p0, "M be ru eraarnerttpuulptaolt-i>tresstgtstiaeimehA  t u.bF"

    const/4 v8, 0x0

    const-string p0, "Atem elr ta uiheetrrisambp utualr.ttg>reM-itaeostntFms b "

    const-string p0, "getAttributesFromMap -> the parameter attributes is null."

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    return-object v0
.end method

.method private static a(Ljava/util/Set;)Ljava/lang/String;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    const/4 v0, 0x0

    const/4 v7, 0x3

    const-string v1, "aXGaorunghPpM"

    const-string/jumbo v1, "snaXGarpgMhPu"

    const/4 v7, 0x6

    const-string v1, "asMXgbunPhear"

    const-string v1, "XGPushManager"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-nez p0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string p0, " t tsauutelbeaertAtusrtmsb.lriniamSe>t erpo  te tgt-Fueri"

    const-string p0, "getAttributesFromSet -> the parameter attributes is null."

    const/4 v7, 0x7

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x2

    return-object v0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/16 v3, 0x32

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-le v2, v3, :cond_1

    const/4 v6, 0x3

    shr-int/2addr v7, v6

    const-string/jumbo p0, "tz_sieop"

    const-string/jumbo p0, "qeizst_o"

    const/4 v7, 0x5

    const-string/jumbo p0, "qzuto_es"

    const-string/jumbo p0, "out_size"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    return-object p0

    :cond_1
    :try_start_0
    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance v2, Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-direct {v2}, Lorg/json/JSONObject;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v7, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz v4, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    check-cast v4, Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-le v5, v3, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-string/jumbo p0, "tssntlg_eu"

    const-string/jumbo p0, "ltsughtn_e"

    const/4 v7, 0x6

    const-string/jumbo p0, "out_length"

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-object p0

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v5, "0"

    const-string v5, "0"

    const/4 v7, 0x1

    const-string v5, "0"

    const-string v5, "0"

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v2, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x6

    or-int/2addr v7, v6

    goto :goto_0

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string v2, "FcemtdeimnobfxgeApetSemo t rrsutetu"

    const-string/jumbo v2, "tt mtuopeurgtFbredeeetf xcSmAientos"

    const/4 v7, 0x5

    const-string v2, " rtboomsrcpSeeA oeeierutfxtFunttedg"

    const-string/jumbo v2, "unexpected for getAttributesFromSet"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    return-object v0
.end method

.method static a(Ljava/util/Set;Ljava/lang/String;)Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/lang/String;",
            ")",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string v0, "ahPgrbuMGseao"

    const-string v0, "GsenoahParMgu"

    const/4 v8, 0x4

    const-string/jumbo v0, "neXhgauPrGMua"

    const-string v0, "XGPushManager"

    if-nez p0, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string/jumbo p1, "prrgliepa-aa ems l etun t .bs>t"

    const-string p1, "-tt.ab mr snhi rls>eegp latau e"

    const/4 v8, 0x3

    const-string/jumbo p1, "nteis l-qh>mt e.gsp  ueaaa  rtr"

    const-string p1, " -> the parameter tags is null."

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 p0, 0x4

    const/4 p0, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    return-object p0

    :cond_0
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-eqz v3, :cond_5

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    check-cast v3, Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string v4, ""

    const-string v4, ""

    const/4 v8, 0x0

    const-string v4, ""

    const-string v4, ""

    const/4 v8, 0x5

    const-string v5, " "

    const-string v5, " "

    const/4 v8, 0x7

    const-string v5, " "

    const-string v5, " "

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v3, v5, v4}, Ljava/lang/String;->replaceAll(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/16 v6, 0x32

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    if-le v4, v6, :cond_1

    const/4 v7, 0x3

    move v8, v7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const-string v5, "  sueh gt>:-"

    const-string v5, "h: t gu- e>t"

    const-string v5, "ae>m  th -:g"

    const-string v5, " -> the tag:"

    const/4 v8, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    const-string v3, ",ihsoir noer0tie  lc  ptmghn asad t"

    const-string v3, " ithoslphs,5 tri r g iae0 tmnea dcn"

    const/4 v8, 0x0

    const-string/jumbo v3, "ie hnbogi t tencr5dm ta is,0 s lrah"

    const-string v3, " length is more than 50, discard it"

    const/4 v8, 0x0

    const/4 v7, 0x0

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-static {v0, v3}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x0

    goto/16 :goto_0

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/16 v4, 0x1f4

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-ge v2, v4, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    if-eqz v2, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    move v8, v7

    goto :goto_1

    :cond_3
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    sget-boolean v4, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    if-eqz v4, :cond_4

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v4, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string v5, "g i>s u-a   iqssz"

    const-string/jumbo v5, "ss > ge qia-  isz"

    const/4 v8, 0x2

    const-string v5, " ss-sitpg e   azi"

    const-string v5, " -> tags size is "

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    add-int/lit8 v5, v2, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    shr-int/2addr v8, v7

    const-string v5, "asi, d rqgstsc:o "

    const-string v5, "  s:,daoiscdrs tg"

    const/4 v8, 0x6

    const-string/jumbo v5, "srst  daicds go,a"

    const-string v5, ", so discard tag:"

    const/4 v7, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {v0, v3}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    goto/16 :goto_0

    :cond_4
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const-string/jumbo p1, "t,omams5 ozrgeci m -t esg  ards0si>s s0  hemdnt i"

    const-string/jumbo p1, "sd m a,s00is oig-r emio st5tet aamsehn>c  rsg z d"

    const/4 v8, 0x6

    const-string p1, " -> tags size is more than 500, discard some tags"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x2

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    return-object p0
.end method

.method static a(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string v0, "dmIoo"

    const-string/jumbo v0, "smIdo"

    const/4 v6, 0x7

    const-string v0, "bgIsd"

    const-string/jumbo v0, "msgId"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v6, 0x1

    const-wide/16 v1, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {p1, v0, v1, v2}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v2

    invoke-virtual {v2, p0, v0, v1}, Lcom/tencent/android/tpush/message/MessageManager;->updateCachedMsgIntentToClick(Landroid/content/Context;J)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v1, ".UPER.uU4IgC.nrt.iccdpao.o.eSn.tnLiaVevHibox_CtcnSdL.T"

    const-string v1, "dcRi.bStiPvSnLn..Vx_gcnL.Ht...aIKeUoCEUeinCdpo.Tc4taro"

    const/4 v6, 0x3

    const-string v1, "i.t4VLepSrconHgR...mKdnpUdiCSPU_nocCTe..aotxIic.ta.nEv"

    const-string v1, "com.tencent.android.xg.vip.action.PUSH_CLICK.RESULT.V4"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo v1, "qempacku"

    const-string/jumbo v1, "kecapaum"

    const/4 v6, 0x3

    const-string/jumbo v1, "kesamcpa"

    const-string/jumbo v1, "packName"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x0

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x3

    const/4 v5, 0x4

    div-long/2addr v1, v3

    const/4 v5, 0x1

    const-string/jumbo p1, "iepmlmTic"

    const-string p1, "icTemilpc"

    const/4 v6, 0x7

    const-string/jumbo p1, "ikeloccmT"

    const-string p1, "clickTime"

    const/4 v5, 0x2

    move v6, v5

    invoke-virtual {v0, p1, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/stat/ServiceStat;->appReportNotificationClicked(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-void
.end method

.method static synthetic a(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->f(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic a(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/android/tpush/XGPushManager;->c(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method private static a(Landroid/content/Context;Landroid/content/Intent;Ljava/lang/String;)V
    .locals 7

    const/4 v5, 0x1

    move v6, v5

    if-eqz p0, :cond_3

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-eqz p1, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez p2, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    goto/16 :goto_1

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-instance v0, Landroid/content/Intent;

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-direct {v0, p2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x1

    invoke-virtual {v0, p1}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string p1, "Nmkaebqa"

    const-string/jumbo p1, "qkmapaNe"

    const/4 v6, 0x1

    const-string/jumbo p1, "packName"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v0, p1, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x2

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    div-long/2addr v1, v3

    const/4 v6, 0x0

    const-string p1, "clseTiukm"

    const-string p1, "eTsimklcc"

    const/4 v6, 0x2

    const-string p1, "Teikmclpi"

    const-string p1, "clickTime"

    const/4 v5, 0x0

    shl-int/2addr v6, v5

    invoke-virtual {v0, p1, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const-string p1, "C.nonn.rqN.e.tUPiELa.4LnSgAto.map.E.RcixdtcSHdE_VmiTecLDCU"

    const-string p1, "dUEm.RaSacL_.UEnVAonT.r..x.ENtiLcDceoCiinnCHe4dpLtgtvPS.m."

    const/4 v6, 0x0

    const-string p1, "LAsn.m4nSC_.LvxEiLtUEiN.RPrgnaictpDHU..dT...dncaVScoEeoCot"

    const-string p1, "com.tencent.android.xg.vip.action.PUSH_CANCELLED.RESULT.V4"

    const/4 v6, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string/jumbo v1, "nocmit"

    const-string v1, "citnoo"

    const/4 v6, 0x1

    const-string/jumbo v1, "notaoi"

    const-string v1, "action"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz p1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    sget-object p1, Lcom/tencent/android/tpush/NotificationAction;->delete:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v6, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/stat/ServiceStat;->appReportNotificationCleared(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo p1, "tPt_EbaS.iniIc.nRrbS4.HUKoC.nci.mLVx.datdoeg.nvcL.eCop"

    const-string p1, "Cv.cSbnUmdLc.go4.nEI.dnLRx_oPit.HiaaKpUt.i.eCSe.coVrnt"

    const/4 v6, 0x5

    const-string p1, "i.Vic.u.oxcea..CaotdgiUS.nEvLnSKn_o.TdemPcpHLCrItUtR.n"

    const-string p1, "com.tencent.android.xg.vip.action.PUSH_CLICK.RESULT.V4"

    const/4 v5, 0x3

    move v6, v5

    invoke-virtual {p1, p2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz p1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    sget-object p1, Lcom/tencent/android/tpush/NotificationAction;->clicked:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/stat/ServiceStat;->appReportNotificationClicked(Landroid/content/Context;Landroid/content/Intent;)V

    :cond_2
    :goto_0
    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    :cond_3
    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-void
.end method

.method static a(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 7

    const/4 v6, 0x6

    if-nez p0, :cond_1

    const/4 v6, 0x0

    const-string/jumbo p0, "lcrt  lp tbnu eoehx!oncaea eTt etnpmur"

    const-string/jumbo p0, "utlc nu eeaenoea  tepxbhnctT lnmtr !ro"

    const-string p0, "The context parameter can not be null!"

    const/4 v6, 0x7

    if-eqz p1, :cond_0

    const/4 v6, 0x7

    sget-object p2, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_LOGIC_ILLEGAL_ARGUMENT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v6, 0x0

    invoke-virtual {p2}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p2

    const/4 v6, 0x1

    const-string p3, ""

    const-string p3, ""

    const-string p3, ""

    const/4 v6, 0x2

    invoke-interface {p1, p3, p2, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    const/4 v6, 0x5

    return-void

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x2

    invoke-direct {p1, p0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    throw p1

    :cond_1
    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/service/cache/CacheManager;->clearTokenCache()V

    const/4 v6, 0x7

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->i(Landroid/content/Context;)Z

    move-result p0

    const/4 v6, 0x3

    if-nez p0, :cond_3

    const/4 v6, 0x5

    if-eqz p1, :cond_2

    const/4 v6, 0x6

    const-string/jumbo p0, "ua/gdrirqI teetye lsrs/npe"

    const-string/jumbo p0, "lsyg/r prutdrsdInie/eeate "

    const-string p0, "It\'s already unregistered"

    const/4 v6, 0x7

    const/4 p2, 0x0

    const/4 v6, 0x2

    invoke-interface {p1, p0, p2}, Lcom/tencent/android/tpush/XGIOperateCallback;->onSuccess(Ljava/lang/Object;I)V

    :cond_2
    const/4 v6, 0x1

    return-void

    :cond_3
    const/4 p0, 0x2

    const/4 v6, 0x1

    sput p0, Lcom/tencent/android/tpush/service/util/c;->a:I

    :try_start_0
    const/4 v6, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p5

    const/4 v6, 0x5

    sget-object p0, Lcom/tencent/android/tpush/XGPushManager;->c:Ljava/lang/Long;

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v6, 0x0

    sub-long/2addr p5, v2

    const/4 v6, 0x6

    sget-object p0, Lcom/tencent/android/tpush/XGPushManager;->e:Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v6, 0x2

    if-eqz p0, :cond_4

    sget-wide v2, Lcom/tencent/android/tpush/XGPushManager;->d:J

    const/4 v6, 0x3

    cmp-long p0, p5, v2

    const/4 v6, 0x5

    if-gez p0, :cond_4

    const/4 v6, 0x5

    const-string p0, "gesnuaqhXGPMr"

    const-string p0, "MhPesganqXrGu"

    const-string p0, "ePXmasunGhgMa"

    const-string p0, "XGPushManager"

    const/4 v6, 0x4

    new-instance p5, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    invoke-direct {p5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const-string/jumbo p6, "seetoln svneumrctl nbape4 egeDRidiirsuNrc:greea,e"

    const-string/jumbo p6, "r seeelgiagsirbNcvcnn,ereDlrmeaecRte sd une4pti:u"

    const-string/jumbo p6, "unuw bnpc grDer lcnaevrsl4eaietieimeR:edrseeb,gNc"

    const-string p6, "cancel dump register, registerRunnable4NewDevice:"

    const/4 v6, 0x6

    invoke-virtual {p5, p6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    sget-object p6, Lcom/tencent/android/tpush/XGPushManager;->e:Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v6, 0x3

    invoke-virtual {p5, p6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    invoke-virtual {p5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p5

    const/4 v6, 0x2

    invoke-static {p0, p5}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p0

    const/4 v6, 0x1

    sget-object p5, Lcom/tencent/android/tpush/XGPushManager;->e:Lcom/tencent/tpns/baseapi/base/util/TTask;

    invoke-virtual {p0, p5}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->remove(Lcom/tencent/tpns/baseapi/base/util/TTask;)V

    const/4 v6, 0x1

    const/4 p0, 0x0

    const/4 v6, 0x3

    sput-object p0, Lcom/tencent/android/tpush/XGPushManager;->e:Lcom/tencent/tpns/baseapi/base/util/TTask;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v6, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_4
    :goto_0
    const/4 v6, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p0

    const/4 v6, 0x4

    new-instance p5, Lcom/tencent/android/tpush/XGPushManager$2;

    move-object v0, p5

    move-object v0, p5

    move-object v0, p5

    move-object v0, p5

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-wide v3, p2

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    const/4 v6, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/tencent/android/tpush/XGPushManager$2;-><init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;)V

    const/4 v6, 0x5

    invoke-virtual {p0, p5}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v6, 0x4

    return-void
.end method

.method static synthetic a(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static/range {p0 .. p5}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method static a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V
    .locals 8

    const/4 v7, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move v2, p2

    move v2, p2

    move v2, p2

    move v2, p2

    move-wide v3, p3

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v5, p5

    move-object v6, p6

    move-object v6, p6

    move-object v6, p6

    invoke-static/range {v0 .. v7}, Lcom/tencent/android/tpush/XGPushManager;->c(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    return-void
.end method

.method static a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v1, 0x1

    invoke-static/range {p0 .. p7}, Lcom/tencent/android/tpush/XGPushManager;->c(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    invoke-static {p0, p1, p2, p3, p4}, Lcom/tencent/android/tpush/XGPushManager;->c(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method static a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .locals 16

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    new-instance v15, Lcom/tencent/android/tpush/XGPushManager$21;

    move-object v1, v15

    move-object v1, v15

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v2, p0

    move-object/from16 v3, p4

    move-object/from16 v3, p4

    move-object/from16 v3, p4

    move-object/from16 v3, p4

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move-object/from16 v4, p1

    move/from16 v5, p2

    move/from16 v5, p2

    move/from16 v5, p2

    move/from16 v5, p2

    move-object/from16 v6, p3

    move-object/from16 v6, p3

    move-object/from16 v6, p3

    move-object/from16 v6, p3

    move-wide/from16 v7, p5

    move-object/from16 v9, p7

    move-object/from16 v9, p7

    move-object/from16 v9, p7

    move-object/from16 v10, p8

    move-object/from16 v10, p8

    move-object/from16 v10, p8

    move-object/from16 v10, p8

    move-object/from16 v11, p9

    move-object/from16 v11, p9

    move-object/from16 v11, p9

    move-object/from16 v11, p9

    move-object/from16 v12, p10

    move-object/from16 v12, p10

    move-object/from16 v12, p10

    move-object/from16 v12, p10

    move-wide/from16 v13, p11

    invoke-direct/range {v1 .. v14}, Lcom/tencent/android/tpush/XGPushManager$21;-><init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;Ljava/lang/String;ILjava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    invoke-virtual {v0, v15}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    return-void
.end method

.method static a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJ)V
    .locals 17

    sget-object v0, Lcom/tencent/android/tpush/XGPushManager;->e:Lcom/tencent/tpns/baseapi/base/util/TTask;

    if-eqz v0, :cond_0

    const-string v0, "arnmesMXGaPgh"

    const-string v0, "XGrgusuahPMne"

    const-string v0, "XGPushManager"

    const-string/jumbo v1, "nceeieip4DeRutetneavsupbeldrroNag"

    const-string v1, "DebaowRriel4iunenaNesuettdpvgerec"

    const-string/jumbo v1, "wvuretneqisauc4iNneeda erbpletgDe"

    const-string/jumbo v1, "update registerRunnable4NewDevice"

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    sget-object v1, Lcom/tencent/android/tpush/XGPushManager;->e:Lcom/tencent/tpns/baseapi/base/util/TTask;

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->remove(Lcom/tencent/tpns/baseapi/base/util/TTask;)V

    :cond_0
    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$22;

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-wide/from16 v3, p11

    move-object/from16 v5, p0

    move-object/from16 v5, p0

    move-object/from16 v5, p0

    move-object/from16 v6, p1

    move-object/from16 v6, p1

    move-object/from16 v6, p1

    move-object/from16 v6, p1

    move/from16 v7, p2

    move/from16 v7, p2

    move/from16 v7, p2

    move-object/from16 v8, p3

    move-object/from16 v8, p3

    move-object/from16 v8, p3

    move-object/from16 v8, p3

    move-wide/from16 v9, p5

    move-object/from16 v11, p7

    move-object/from16 v11, p7

    move-object/from16 v11, p7

    move-object/from16 v11, p7

    move-object/from16 v12, p8

    move-object/from16 v12, p8

    move-object/from16 v12, p8

    move-object/from16 v12, p8

    move-object/from16 v13, p9

    move-object/from16 v13, p9

    move-object/from16 v13, p9

    move-object/from16 v13, p9

    move-object/from16 v14, p10

    move-object/from16 v14, p10

    move-object/from16 v14, p10

    move-object/from16 v14, p10

    move-wide/from16 v15, p13

    invoke-direct/range {v2 .. v16}, Lcom/tencent/android/tpush/XGPushManager$22;-><init>(JLandroid/content/Context;Ljava/lang/String;ILjava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    sput-object v0, Lcom/tencent/android/tpush/XGPushManager;->e:Lcom/tencent/tpns/baseapi/base/util/TTask;

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    sget-object v1, Lcom/tencent/android/tpush/XGPushManager;->e:Lcom/tencent/tpns/baseapi/base/util/TTask;

    move-wide/from16 v2, p11

    invoke-virtual {v0, v1, v2, v3}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;J)Z

    return-void
.end method

.method static a(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 8

    const-string p4, ""

    const-string p4, ""

    const-string p4, ""

    const-string p4, ""

    const-string v0, "GenaabgsrhXuP"

    const-string v0, "XGPushManager"

    if-nez p0, :cond_1

    const-string/jumbo p0, "xrseT nntarcnntoeol!cbl eaem  epa httu"

    const-string p0, "The context parameter can not be null!"

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz p7, :cond_0

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->ERRORCODE_UNKNOWN:Lcom/tencent/android/tpush/common/ReturnCode;

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->errCodeToMsg(I)Ljava/lang/String;

    move-result-object p0

    invoke-interface {p7, p4, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_0
    return-void

    :cond_1
    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v1

    if-lez v1, :cond_3

    const-string/jumbo p0, "ufnmaaGarienMucagonlb tedialo tl"

    const-string p0, "enutliuGlearcfgModtnbaaalcnoia  "

    const-string p0, "aaadoengoicb licareGfilnlnato uM"

    const-string p0, "accountManager initGlobal failed"

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz p7, :cond_2

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->ERRORCODE_UNKNOWN:Lcom/tencent/android/tpush/common/ReturnCode;

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->errCodeToMsg(I)Ljava/lang/String;

    move-result-object p0

    invoke-interface {p7, p4, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    return-void

    :cond_3
    new-instance p4, Lcom/tencent/android/tpush/XGPushManager$11;

    move-object v0, p4

    move-object v0, p4

    move-object v0, p4

    move-object v0, p4

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-wide v2, p2

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move-object v4, p0

    move v5, p5

    move v5, p5

    move v5, p5

    move v5, p5

    move-object v6, p7

    move-object v6, p7

    move-object v6, p7

    move-object v6, p7

    move-object v7, p6

    move-object v7, p6

    move-object v7, p6

    move-object v7, p6

    invoke-direct/range {v0 .. v7}, Lcom/tencent/android/tpush/XGPushManager$11;-><init>(Ljava/lang/String;JLandroid/content/Context;ILcom/tencent/android/tpush/XGIOperateCallback;Ljava/lang/String;)V

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p0

    invoke-virtual {p0, p4}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    return-void
.end method

.method static synthetic a()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->e()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method static synthetic a(Landroid/content/Context;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;)Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x6

    return p0
.end method

.method private static a(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v2, "MngGpbearasPX"

    const-string v2, "MPaGrghpnesaX"

    const/4 v4, 0x1

    const-string/jumbo v2, "unehaXuasGMgr"

    const-string v2, "XGPushManager"

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string p0, "Aua!>M-pr!tqot g ttl esrrbn!inumre lpte"

    const-string/jumbo p0, "rnAtlpa!qtem!r gb-tF>rnoe t!ueu stlM ir"

    const/4 v4, 0x1

    const-string/jumbo p0, "u ai>uMrqne! Fpre ttttgmsrl-o tu!Anr!bl"

    const-string p0, " -> getAttributesFromMap return null!!!"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    return v1

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v0, "spsty"

    const-string/jumbo v0, "ptsye"

    const/4 v4, 0x0

    const-string/jumbo v0, "mpemy"

    const-string v0, "empty"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo p0, "yst ovrp me>aet t hms balp-area iuu mhtt!tree"

    const-string/jumbo p0, "upimr aat->etl amvspe r u!baea ttretteh yhsm "

    const/4 v4, 0x4

    const-string p0, "  eptbusahapvby tueretla  ermtth-e  ta>sarme!"

    const-string p0, " -> the parameter attributes has empty value!"

    const/4 v4, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    return v1

    :cond_1
    const/4 v4, 0x6

    const-string v0, "ht_gtnulou"

    const-string/jumbo v0, "utn_oghelt"

    const/4 v4, 0x0

    const-string v0, "htugle_pon"

    const-string/jumbo v0, "out_length"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    move v4, v3

    if-eqz v0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string p0, "  otierlqnherioetg>b i5eftlo _a-veaei tntim tmaep0umut harrubsaar_e ttl :t ut"

    const-string/jumbo p0, "u>t_-bte tiae:blh oeepoitmtneau e0meaitrguvtr_5 arr lthsmiel nubt aft  atro i"

    const/4 v4, 0x1

    const-string p0, "atsrgita hliaonte urpe_ett  ehmsrtv n taatbi tb>5 _i eeiuet eram:mo0rf -ltulo"

    const-string p0, " -> the parameter attribute_name or attribute_value length is out of limit:50"

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    return v1

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string v0, "e_imtsuz"

    const-string v0, "_tozesui"

    const/4 v4, 0x7

    const-string/jumbo v0, "uoztoei_"

    const-string/jumbo v0, "out_size"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz p1, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string/jumbo p0, "mi ehb it-str5orrlszt0tipu  tspfo e iembiaaae:ett >u"

    const-string p0, ">rozlumpsr0iotsf5 ipe  a-uet mi iesttr   thtab:iaeet"

    const/4 v4, 0x1

    const-string p0, "a-tereuit > aittimtu h a 5: sor zfeett  slperisumiob"

    const-string p0, " -> the parameter attributes size is out of limit:50"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    return v1

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const/4 p0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    return p0
.end method

.method static synthetic a(Z)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    sput-boolean p0, Lcom/tencent/android/tpush/XGPushManager;->a:Z

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p0
.end method

.method public static addLocalNotification(Landroid/content/Context;Lcom/tencent/android/tpush/XGLocalMessage;)J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x4

    const-wide/16 v0, -0x1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p0, p1, v0, v1}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Lcom/tencent/android/tpush/XGLocalMessage;J)J

    move-result-wide p0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-wide p0
.end method

.method public static addLocalNotificationList(Landroid/content/Context;Ljava/util/ArrayList;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/android/tpush/XGLocalMessage;",
            ">;)V"
        }
    .end annotation

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v0, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    check-cast v0, Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v6, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    new-instance v2, Lcom/tencent/android/tpush/XGPushManager$15;

    const/4 v5, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-direct {v2, p0, v0}, Lcom/tencent/android/tpush/XGPushManager$15;-><init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGLocalMessage;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1, v2, v3, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;J)Z

    const/4 v5, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-void
.end method

.method public static addTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->appendTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public static addTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/tencent/android/tpush/XGIOperateCallback;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/android/tpush/XGPushManager;->appendTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public static appendAccount(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/XGPushManager;->upsertAccounts(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public static appendAccount(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->upsertAccounts(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static appendAccount(Landroid/content/Context;Ljava/lang/String;ILcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x4

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/android/tpush/XGPushManager;->upsertAccounts(Landroid/content/Context;Ljava/lang/String;ILcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public static appendAccount(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->upsertAccounts(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public static appendTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string/jumbo v0, "qhXMarspGnPeu"

    const-string/jumbo v0, "rPsXhguMqGnea"

    const/4 v10, 0x2

    const-string/jumbo v0, "rXPeaguMqhnaG"

    const-string v0, "XGPushManager"

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-eqz p0, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-eqz p2, :cond_2

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-interface {p2}, Ljava/util/Set;->isEmpty()Z

    move-result v1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-eqz v1, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    goto/16 :goto_0

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    const-string v1, "adssTsa"

    const-string v1, "adssTda"

    const/4 v10, 0x6

    const-string v1, "dagmasd"

    const-string v1, "addTags"

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-static {p2, v1}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/Set;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-static {v3}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result p2

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eqz p2, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-string/jumbo p0, "tggao>e- !TdS ontsutrgal eudrm!TemFlan!s"

    const-string/jumbo p0, "tn mTltnFrgesTlardrsS>o at!audeg!u!m-g e"

    const/4 v10, 0x2

    const-string/jumbo p0, "uFg obnlue !e!aers ttg ralTm!andsSTr>tdg"

    const-string p0, "addTags -> getTagsFromSet return null!!!"

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x0

    return-void

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-string v1, "T w sguilseg atT> l-adahagdt  tssao"

    const-string v1, "h saoslstdgasTa wta  gtTil- g=a ed>"

    const-string/jumbo v1, "ts a> gp-ahlTTas wittdsga  gedla  s"

    const-string v1, "addTags -> setTags with all tags = "

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    const/4 v4, 0x5

    const/4 v9, 0x7

    move v10, v9

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-static/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x1

    return-void

    :cond_2
    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-string p0, " vretfpxq  ands abgs  mthcloantd.tsaeoera Taiierd og"

    const-string p0, "etnn bTmdsapiagr i aofse  ri  ovt. hotxddsgteaacelar"

    const/4 v10, 0x2

    const-string p0, " mst paaeitt d.cr tagaaoe dsrei votdslg as oTnefhrin"

    const-string/jumbo p0, "the parameter context or tags of addTags is invalid."

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x4

    return-void
.end method

.method public static appendTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/tencent/android/tpush/XGIOperateCallback;",
            ")V"
        }
    .end annotation

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x3

    const-string/jumbo v0, "ugamaTd"

    const-string v0, "gsaadTu"

    const/4 v10, 0x3

    const-string v0, "Tsadoad"

    const-string v0, "addTags"

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/Set;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-string v0, "ghParbXupanse"

    const-string v0, "aasMPhXpnugre"

    const/4 v10, 0x0

    const-string/jumbo v0, "rgGPaauehnuMX"

    const-string v0, "XGPushManager"

    const/4 v9, 0x0

    move v10, v9

    if-eqz p0, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-eqz p2, :cond_1

    const/4 v10, 0x6

    invoke-interface {p2}, Ljava/util/Set;->isEmpty()Z

    move-result p2

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-nez p2, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x5

    if-eqz p2, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    const-string/jumbo v1, "l a=>tipg t hg lTa g  wssstdadseTa-"

    const-string/jumbo v1, "tstwgT gqdsa lTdasha>   tgi= ael- s"

    const/4 v10, 0x6

    const-string v1, "adtsa s>qet i   =lwhltgda gTTasa s-"

    const-string v1, "addTags -> setTags with all tags = "

    const/4 v10, 0x5

    const/4 v9, 0x4

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    const/4 v3, 0x5

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    const-wide/16 v4, -0x1

    const/4 v10, 0x3

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x5

    const/4 v6, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v8, p3

    move-object v8, p3

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v10, 0x4

    return-void

    :cond_1
    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    const-string/jumbo p1, "itsetdTrtanagaedx  isao drapsgeslh.rt ncmo etfa   so"

    const-string p1, "ggsaoao.ntd tmelsrarh  te ftradipcditnexTs aso i ea "

    const/4 v10, 0x3

    const-string/jumbo p1, "the parameter context or tags of addTags is invalid."

    const/4 v9, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-eqz p0, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    if-eqz p3, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_TAG:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string p2, ""

    const-string p2, ""

    const/4 v10, 0x1

    const-string p2, ""

    const-string p2, ""

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-interface {p3, p2, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    return-void
.end method

.method private static b(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;Lcom/tencent/android/tpush/XGPushManager$AccountInfo;)Landroid/content/Intent;
    .locals 11

    const/4 v10, 0x2

    const-string p3, "armmPMagnsuGh"

    const-string p3, "GgXmransuMaPh"

    const-string/jumbo p3, "srXnoGPaueMhg"

    const-string p3, "XGPushManager"

    const/4 v10, 0x5

    if-eqz p0, :cond_a

    const/4 v10, 0x2

    if-eqz p1, :cond_a

    const/4 v10, 0x3

    if-nez p2, :cond_0

    const/4 v10, 0x0

    goto/16 :goto_4

    :cond_0
    const/4 v10, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v10, 0x2

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpush/service/protocol/m;->a(Landroid/content/Context;Landroid/content/Intent;Z)Lcom/tencent/android/tpush/service/protocol/m;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v10, 0x4

    if-eqz v1, :cond_1

    :try_start_1
    const/4 v10, 0x7

    invoke-virtual {v1, p0}, Lcom/tencent/android/tpush/service/protocol/m;->a(Landroid/content/Context;)Lorg/json/JSONObject;

    move-result-object v2
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v10, 0x2

    goto :goto_0

    :catchall_0
    move-exception v2

    :try_start_2
    const/4 v10, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const-string/jumbo v4, "oe r:bRd irqefiHeasnoheete Rpgdtrleignesacdlt"

    const-string/jumbo v4, "nardoionereplqec serdsf:ge deiRRtteli gHheeta"

    const-string v4, "e sgnguraretleiqtR sdenhee:iHtcrtlededaopR if"

    const-string v4, "handleHttpRegister registerReq encode failed:"

    const/4 v10, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x0

    invoke-static {p3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v10, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v10, 0x4

    if-eqz v1, :cond_8

    const/4 v10, 0x1

    if-eqz v2, :cond_8

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x2

    invoke-static {v3}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    const/4 v10, 0x5

    if-nez v3, :cond_7

    const/4 v10, 0x6

    invoke-virtual {v2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x5

    const/4 v3, 0x1

    const/4 v10, 0x7

    invoke-static {p0, v3, v2}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->getFinalGuidInfo(Landroid/content/Context;ZLjava/lang/String;)Lcom/tencent/tpns/baseapi/base/device/GUIDInfo;

    move-result-object v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v10, 0x0

    const-string/jumbo v4, "ivoclenpBCbdkla"

    const-string v4, "aivkCbnBllekcod"

    const-string/jumbo v4, "kievadnCqBllock"

    const-string/jumbo v4, "invokedCallBack"

    const/4 v10, 0x7

    const-string/jumbo v5, "uRsgstehdsi"

    const-string/jumbo v5, "tgsiaRusdhe"

    const-string v5, "edemRhgtiss"

    const-string v5, "hasRegisted"

    const/4 v10, 0x1

    const-string v6, ""

    const-string v6, ""

    const-string v6, ""

    const-string v6, ""

    const/4 v10, 0x4

    if-eqz v2, :cond_4

    :try_start_3
    const/4 v10, 0x7

    invoke-virtual {v2}, Lcom/tencent/tpns/baseapi/base/device/GUIDInfo;->isError()Z

    move-result v7

    const/4 v10, 0x1

    if-nez v7, :cond_4

    const/4 v10, 0x0

    iget-object v7, v2, Lcom/tencent/tpns/baseapi/base/device/GUIDInfo;->token:Ljava/lang/String;

    const/4 v10, 0x0

    iget v8, v2, Lcom/tencent/tpns/baseapi/base/device/GUIDInfo;->errCode:I

    const/4 v10, 0x5

    invoke-interface {p2, v7, v8}, Lcom/tencent/android/tpush/XGIOperateCallback;->onSuccess(Ljava/lang/Object;I)V

    const/4 v10, 0x7

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/XGApiConfig;->setRegisterSuccess(Landroid/content/Context;)V

    const/4 v10, 0x3

    iget-object p2, v2, Lcom/tencent/tpns/baseapi/base/device/GUIDInfo;->token:Ljava/lang/String;

    const/4 v10, 0x3

    invoke-static {p0, p2}, Lcom/tencent/android/tpush/service/protocol/n;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x2

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x1

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v7

    const/4 v10, 0x2

    if-nez v7, :cond_3

    const/4 v10, 0x3

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    iget-wide v8, v1, Lcom/tencent/android/tpush/service/protocol/m;->a:J

    const/4 v10, 0x6

    invoke-virtual {v7, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x7

    invoke-static {v6}, Lcom/tencent/android/tpush/e/b/a;->a(Ljava/lang/String;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v6

    const/4 v10, 0x7

    invoke-static {p0, v6}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object v6

    const/4 v10, 0x0

    check-cast v6, Ljava/lang/String;

    const/4 v10, 0x0

    if-eqz v6, :cond_2

    const/4 v10, 0x0

    iget-object v7, v1, Lcom/tencent/android/tpush/service/protocol/m;->v:Ljava/lang/String;

    const/4 v10, 0x0

    invoke-static {v6, v7}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v10, 0x2

    if-eqz v6, :cond_2

    const/4 v10, 0x4

    new-array v6, v3, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v10, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->b()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v7

    const/4 v10, 0x7

    invoke-virtual {v7, p2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object p2

    const/4 v10, 0x7

    aput-object p2, v6, v0

    const/4 v10, 0x2

    invoke-static {p0, v6}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    const/4 v10, 0x2

    goto :goto_1

    :cond_2
    new-array v6, v3, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v10, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->b()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v7

    const/4 v10, 0x0

    invoke-virtual {v7, p2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object p2

    const/4 v10, 0x1

    aput-object p2, v6, v0

    const/4 v10, 0x6

    invoke-static {p0, v6}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    :goto_1
    const/4 v10, 0x0

    iget-object p0, v1, Lcom/tencent/android/tpush/service/protocol/m;->N:Ljava/lang/String;

    const/4 v10, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/c;->a(Ljava/lang/String;)V

    :cond_3
    const/4 v10, 0x6

    const-string/jumbo p0, "tsdsopMltr5"

    const-string p0, "dlt5srsptMa"

    const-string p0, "5dsaNbtMrst"

    const-string/jumbo p0, "lastNMd5str"

    const/4 v10, 0x7

    iget-object p2, v1, Lcom/tencent/android/tpush/service/protocol/m;->N:Ljava/lang/String;

    const/4 v10, 0x2

    invoke-virtual {p1, p0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v10, 0x1

    const-string/jumbo p0, "qukoe"

    const-string/jumbo p0, "oetqk"

    const-string/jumbo p0, "okptn"

    const-string/jumbo p0, "token"

    const/4 v10, 0x1

    iget-object p2, v2, Lcom/tencent/tpns/baseapi/base/device/GUIDInfo;->token:Ljava/lang/String;

    const/4 v10, 0x6

    invoke-virtual {p1, p0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {p1, v5, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/4 v10, 0x1

    invoke-virtual {p1, v4, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    return-object p1

    :cond_4
    const/4 v10, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x5

    const-string/jumbo v7, "lsngetfHqeer,esotIi:ratoguri  nrpRd"

    const-string/jumbo v7, "tdsp itrunrgtaeir ofgReo,lInesehr:H"

    const-string v7, "aHsniIfntgoot,seddlee:  Riuertrrphg"

    const-string v7, "handleHttpRegister error, guidInfo:"

    const/4 v10, 0x4

    invoke-virtual {v1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x4

    invoke-static {p3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/common/i;->a()Lcom/tencent/android/tpush/common/i;

    move-result-object v1

    const/4 v10, 0x1

    invoke-virtual {v1}, Lcom/tencent/android/tpush/common/i;->b()Z

    move-result v1

    const/4 v10, 0x1

    if-eqz v1, :cond_6

    const/4 v10, 0x1

    if-nez v2, :cond_5

    const/4 v10, 0x5

    const-string/jumbo v1, "iuGmnIFltnlauedfoDI li U nGgi"

    const-string v1, "getFinalGuidInfo GUID is null"

    const/4 v10, 0x3

    const/4 v7, -0x5

    const/4 v10, 0x1

    invoke-interface {p2, v6, v7, v1}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    const/4 v10, 0x5

    goto :goto_2

    :cond_5
    iget v1, v2, Lcom/tencent/tpns/baseapi/base/device/GUIDInfo;->errCode:I

    const/4 v10, 0x7

    iget-object v7, v2, Lcom/tencent/tpns/baseapi/base/device/GUIDInfo;->result:Ljava/lang/String;

    const/4 v10, 0x1

    invoke-interface {p2, v6, v1, v7}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :goto_2
    const/4 v10, 0x1

    const-string/jumbo v1, "psdRotetliithgae"

    const-string v1, "httpRegistedFail"

    const/4 v10, 0x3

    invoke-virtual {p1, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    :cond_6
    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedTpnsChannel(Landroid/content/Context;)Z

    move-result p0

    const/4 v10, 0x2

    if-nez p0, :cond_9

    const/4 v10, 0x5

    iget p0, v2, Lcom/tencent/tpns/baseapi/base/device/GUIDInfo;->errCode:I

    const/4 v10, 0x7

    iget-object v1, v2, Lcom/tencent/tpns/baseapi/base/device/GUIDInfo;->result:Ljava/lang/String;

    const/4 v10, 0x0

    invoke-interface {p2, v6, p0, v1}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    const/4 v10, 0x1

    invoke-virtual {p1, v5, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/4 v10, 0x5

    invoke-virtual {p1, v4, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/4 v10, 0x0

    goto :goto_3

    :cond_7
    const/4 v10, 0x2

    const-string/jumbo p0, "jwiasbHeaed es rhRpruirmesegsrt tn gltSonttln"

    const-string/jumbo p0, "sphmat HRrn a eluor isnsjegtn ritglreseSwttde"

    const-string p0, "e R eSu ejeneiropglsssd nuwitttgrrtnl arslhtH"

    const-string p0, "handleHttpRegister  register jsonStr was null"

    const/4 v10, 0x1

    invoke-static {p3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    goto :goto_3

    :cond_8
    const/4 v10, 0x3

    const-string/jumbo p0, "titlsntpdesharlwpnons  ae ue iHreots lrgeg"

    const-string p0, "e  gotilounh pitgdtlnsHartal eeerR nrswess"

    const-string p0, "euR s wnqjHoaln nlegrhglsrstd seiptraieet "

    const-string p0, "handleHttpRegister  register json was null"

    const/4 v10, 0x7

    invoke-static {p3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_3

    :catchall_1
    move-exception p0

    const/4 v10, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const-string v0, "das Hfart:sdptigeRltlbeenh "

    const-string v0, " eaipbtRllhadn istegetHf:rd"

    const-string v0, "He msgaatRdt ieh:nepltirlef"

    const-string v0, "handleHttpRegister  failed:"

    const/4 v10, 0x7

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    invoke-virtual {p2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x4

    invoke-static {p3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_9
    :goto_3
    const/4 v10, 0x2

    return-object p1

    :cond_a
    :goto_4
    const/4 v10, 0x5

    const-string/jumbo p0, "ugato eilsrdsa eHroetrmanrrRepp"

    const-string/jumbo p0, "ptladeuHmR rprsretagsreoa nriet"

    const-string p0, "aRhHebnpegem le trrtsrdoaraitrs"

    const-string p0, "handleHttpRegister params error"

    invoke-static {p3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x3

    return-object p1
.end method

.method private static b(Ljava/lang/String;)Ljava/lang/String;
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    const/4 v2, 0x0

    const/4 v7, 0x0

    shr-int/2addr v8, v7

    move v3, v2

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-ge v3, v1, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v4

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/16 v5, 0xc

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eq v4, v5, :cond_3

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x1

    const/16 v5, 0xd

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eq v4, v5, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x3

    const/16 v5, 0x22

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/16 v6, 0x5c

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-eq v4, v5, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x7

    const/16 v5, 0x2f

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x2

    if-eq v4, v5, :cond_1

    const/4 v8, 0x4

    if-eq v4, v6, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    packed-switch v4, :pswitch_data_0

    const/4 v8, 0x2

    const/16 v5, 0x1f

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-gt v4, v5, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v5, 0x1

    xor-int/2addr v8, v5

    const/4 v7, 0x5

    move v8, v7

    new-array v5, v5, [Ljava/lang/Object;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    aput-object v4, v5, v2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string/jumbo v4, "pu40%x/"

    const/4 v8, 0x5

    const-string v4, "//%x4uu"

    const-string v4, "\\u%04x"

    const/4 v7, 0x0

    shl-int/2addr v8, v7

    invoke-static {v4, v5}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    goto/16 :goto_1

    :cond_0
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    goto :goto_1

    :pswitch_0
    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string v4, "//n"

    const-string v4, "//n"

    const/4 v8, 0x2

    const-string/jumbo v4, "n//"

    const-string v4, "\\n"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    goto :goto_1

    :pswitch_1
    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string v4, "/t/"

    const-string/jumbo v4, "t//"

    const/4 v8, 0x2

    const-string v4, "/t/"

    const-string v4, "\\t"

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    goto :goto_1

    :pswitch_2
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string v4, "/b/"

    const-string v4, "b//"

    const/4 v8, 0x2

    const-string v4, "//b"

    const-string v4, "\\b"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x5

    goto :goto_1

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    goto :goto_1

    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string v4, "/r/"

    const-string/jumbo v4, "r//"

    const-string v4, "\\r"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x4

    goto :goto_1

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string v4, "//f"

    const-string v4, "/f/"

    const/4 v8, 0x1

    const-string v4, "f//"

    const-string v4, "\\f"

    const/4 v7, 0x1

    move v8, v7

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    goto/16 :goto_0

    :cond_4
    const/4 v8, 0x1

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    return-object p0

    :pswitch_data_0
    .packed-switch 0x8
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method private static b(Ljava/util/Set;)Ljava/lang/String;
    .locals 9
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-string/jumbo v0, "nMPahsqpGraeg"

    const-string v0, "MushaGaeqrnPg"

    const/4 v8, 0x1

    const-string v0, "aaGungerqXPhM"

    const-string v0, "XGPushManager"

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v1, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-eqz p0, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-interface {p0}, Ljava/util/Set;->size()I

    move-result v2

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    if-gtz v2, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    goto/16 :goto_1

    :cond_0
    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance v2, Lorg/json/JSONArray;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-direct {v2}, Lorg/json/JSONArray;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-eqz v3, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    check-cast v3, Ljava/lang/Integer;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    new-instance v4, Lorg/json/JSONObject;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct {v4}, Lorg/json/JSONObject;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string v5, "ctsnauc"

    const-string v5, "account"

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-string v6, ""

    const-string v6, ""

    const/4 v8, 0x7

    const-string v6, ""

    const-string v6, ""

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string v5, "ecpmaocsn_yt"

    const-string/jumbo v5, "oescuncytpa_"

    const/4 v8, 0x3

    const-string v5, "ey_cotpctaou"

    const-string v5, "account_type"

    const/4 v8, 0x0

    invoke-virtual {v4, v5, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x1

    const/4 v7, 0x0

    invoke-virtual {v2, v4}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    goto :goto_0

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string/jumbo v3, "tgotnbeceTSJoAt p|cunyme"

    const-string v3, "TttmntgoncuAy eeSJeos|cp"

    const/4 v8, 0x7

    const-string/jumbo v3, "p teotuegecsAtSu cnoT|Jn"

    const-string v3, "getAccountTypeSetJson | "

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v2}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x5

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v2}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string/jumbo v2, "ntsptecpAen:oStoJTgyuc"

    const-string/jumbo v2, "uytcoscoopnAnJte:SeTgt"

    const/4 v8, 0x1

    const-string v2, "getAccountTypeSetJson:"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {v0, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_2
    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    return-object v1
.end method

.method static synthetic b(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/XGPushManager;->c(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic b(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->g(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method private static b(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V
    .locals 6

    const/4 v5, 0x2

    const-string v0, "ahGaXgrMqusnP"

    const-string v0, "XGPushManager"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->f(Landroid/content/Context;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    new-instance v1, Lcom/tencent/android/tpush/XGPushManager$b;

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v1, p0, p1, p2, p3}, Lcom/tencent/android/tpush/XGPushManager$b;-><init>(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    new-instance v2, Landroid/content/IntentFilter;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v3, ".SsgcniETrmbcCpEx_Rta.aRd.4inn.nAtTcSvtVoeiVeo.d.."

    const-string/jumbo v3, "xnrRobnm4n.o.c..eEt_..TVgapERSTVcAv.aecSiitidoCtdn"

    const/4 v5, 0x1

    const-string v3, "AiomcitdSnmEaaecd4I..re.ooSTVp.ntRgTt.C.nxiR._cEVn"

    const-string v3, "com.tencent.android.xg.vip.action.SERVICE_START.V4"

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {v2, v3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v3, 0x4

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {p0, v1, v2, v3}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    goto :goto_0

    :catchall_0
    move-exception v2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string/jumbo v3, "rRecoog oi:rvitd enes prt rrener teox eiec"

    const-string v3, "Receiver not registered exception error : "

    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v0, v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v2, Lcom/tencent/android/tpush/XGPushManager$c;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v2, p0, p1, p2, p3}, Lcom/tencent/android/tpush/XGPushManager$c;-><init>(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V

    :try_start_1
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    sget-object p0, Lcom/tencent/android/tpush/XGPushManager;->i:Ljava/util/Map;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {p0, v1, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-wide/16 p1, 0x2710

    const-wide/16 p1, 0x2710

    const/4 v5, 0x5

    const-wide/16 p1, 0x2710

    const-wide/16 p1, 0x2710

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0, v2, p1, p2}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;J)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_1

    :catchall_1
    move-exception p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string p1, "MeamrbiesapeslnrbeTmOefnRagruu"

    const-string p1, "aerofTupiaRsmeeenreaglnbOsmruM"

    const/4 v5, 0x2

    const-string/jumbo p1, "seeRfnuMalnamorrebui OeaTmeprg"

    const-string/jumbo p1, "mapTimeRunnableOfMessage error"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v0, p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_1
    const/4 v5, 0x2

    return-void
.end method

.method private static b(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eqz p0, :cond_6

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-lez v0, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    return-void

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->e()Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eqz v0, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz p5, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x2

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SDK_API_FREQUENCY_LIMIT_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string p2, ""

    const-string p2, ""

    const/4 v7, 0x4

    const-string p2, ""

    const-string p2, ""

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-interface {p5, p2, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_1
    const/4 v7, 0x3

    return-void

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x1

    const-wide/16 v2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    cmp-long v2, v0, v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-ltz v2, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    new-instance v3, Landroid/content/Intent;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    shl-int/2addr v7, v6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v5, "SV.ad.npARUttnoicnT..QoYnr.eicciedvopaG.Empg4t"

    const-string/jumbo v5, "mo.VicGpottQ.nnYea.TgUnopiadi.ctrRcSdE.A.n.e4v"

    const/4 v7, 0x2

    const-string v5, "SEGmQAe.qv.YttodtcVni.anacrniixonp.TceoR4.d.gU"

    const-string v5, "com.tencent.android.xg.vip.action.QUERYTAGS.V4"

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string v4, "dcsqc"

    const-string v4, "cacqd"

    const/4 v7, 0x7

    const-string v4, "cadmc"

    const-string v4, "accId"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v3, v4, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v7, 0x1

    const-string v0, "esccoy"

    const-string v0, "cysceK"

    const/4 v7, 0x6

    const-string v0, "ccayeb"

    const-string v0, "accKey"

    invoke-static {v2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v3, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string v1, "cmpmeauk"

    const-string v1, "amkmcape"

    const/4 v7, 0x5

    const-string v1, "aaNcpemp"

    const-string/jumbo v1, "packName"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v3, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string v0, "auoeagNrqsmeT"

    const-string/jumbo v0, "yegTouNesaarm"

    const/4 v7, 0x2

    const-string v0, "eNsuyagqTears"

    const-string/jumbo v0, "queryTagsName"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v3, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string p1, "fosftb"

    const/4 v7, 0x1

    const-string/jumbo p1, "sotmfe"

    const-string/jumbo p1, "offset"

    const/4 v6, 0x5

    const/4 v6, 0x4

    invoke-virtual {v3, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string/jumbo p1, "timuo"

    const-string/jumbo p1, "muiti"

    const/4 v7, 0x3

    const-string p1, "bimli"

    const-string/jumbo p1, "limit"

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-virtual {v3, p1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-nez p1, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string p1, "aeytppu"

    const-string/jumbo p1, "ptpTeya"

    const/4 v7, 0x2

    const-string/jumbo p1, "pyTptag"

    const-string/jumbo p1, "tagType"

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v3, p1, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz p5, :cond_4

    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    new-instance p1, Lcom/tencent/android/tpush/XGPushManager$7;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-direct {p1, p5}, Lcom/tencent/android/tpush/XGPushManager$7;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    new-instance p2, Landroid/content/IntentFilter;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string p3, ".4Tt.RELqEncogtaoce.nmrG..iYenp.AdUSvandUiRxqo.QiS.tV"

    const-string p3, "LvAdoUaUqtcQYRoV..xe.ni..geSrTESt.EmnocaniGRi..n4Tdpt"

    const/4 v7, 0x6

    const-string p3, "com.tencent.android.xg.vip.action.QUERYTAGS.RESULT.V4"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-direct {p2, p3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 p3, 0x4

    move v7, p3

    move v6, p3

    move v6, p3

    const/4 v7, 0x2

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x5

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string p3, "avsecaMerrorasgrrrgtie tng eeis eR"

    const-string/jumbo p3, "ntseRreaMteor i ega regrsecearrvig"

    const/4 v7, 0x4

    const-string/jumbo p3, "rtime rsrearenarMgeirtogevgea  Rer"

    const-string/jumbo p3, "tagManager registerReceiver error "

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string p2, "gXraoaMPehsun"

    const-string p2, "XGPushManager"

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {p0, v3}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    return-void

    :cond_5
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const-string p1, " taenb toschsedcTe !s"

    const-string p1, "The accessId not set!"

    const/4 v7, 0x7

    const/4 v6, 0x2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    throw p0

    :cond_6
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string p1, "ecemxp h T naeu!ntnr anrttme o lacbolt"

    const/4 v7, 0x7

    const-string p1, "b enrcuxe nhna t ne!artpooTe tlcamtuel"

    const-string p1, "The context parameter can not be null!"

    const/4 v6, 0x1

    move v7, v6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    throw p0
.end method

.method static synthetic b(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static/range {p0 .. p7}, Lcom/tencent/android/tpush/XGPushManager;->d(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method private static b(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 10

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-eqz p0, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    new-instance v7, Lcom/tencent/android/tpush/XGPushManager$3;

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    move v4, p2

    move v4, p2

    const/4 v9, 0x7

    move v4, p2

    move v4, p2

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-direct/range {v1 .. v6}, Lcom/tencent/android/tpush/XGPushManager$3;-><init>(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {v0, v7}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v9, 0x5

    return-void

    :cond_0
    const/4 v8, 0x6

    move v9, v8

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string p1, " oetnelpnpm  rneclo e rxahuttcaat!o eb"

    const-string p1, "emc ooronehaaneetu bttcal! p rlen nt x"

    const/4 v9, 0x0

    const-string/jumbo p1, "retacnenqoeahrlem o pecbxnut   latnt T"

    const-string p1, "The context parameter can not be null!"

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    throw p0
.end method

.method static b(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .locals 15

    sget-wide v11, Lcom/tencent/android/tpush/XGPushManager;->d:J

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move/from16 v2, p2

    move/from16 v2, p2

    move/from16 v2, p2

    move-object/from16 v3, p3

    move-object/from16 v3, p3

    move-object/from16 v3, p3

    move-object/from16 v4, p4

    move-object/from16 v4, p4

    move-object/from16 v4, p4

    move-object/from16 v4, p4

    move-wide/from16 v5, p5

    move-object/from16 v7, p7

    move-object/from16 v7, p7

    move-object/from16 v7, p7

    move-object/from16 v7, p7

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v8, p8

    move-object/from16 v9, p9

    move-object/from16 v9, p9

    move-object/from16 v9, p9

    move-object/from16 v9, p9

    move-object/from16 v10, p10

    move-object/from16 v10, p10

    move-object/from16 v10, p10

    move-object/from16 v10, p10

    move-wide/from16 v13, p11

    invoke-static/range {v0 .. v14}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJ)V

    return-void
.end method

.method private static b(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 10

    if-eqz p0, :cond_0

    new-instance v9, Lcom/tencent/android/tpush/XGPushManager$10;

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-wide v3, p2

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move v6, p5

    move v6, p5

    move v6, p5

    move v6, p5

    move-object/from16 v7, p6

    move-object/from16 v7, p6

    move-object/from16 v7, p6

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move-object/from16 v8, p7

    move-object/from16 v8, p7

    invoke-direct/range {v0 .. v8}, Lcom/tencent/android/tpush/XGPushManager$10;-><init>(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    invoke-virtual {v0, v9}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    return-void

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "a!s teuelnlo cttannTrhetoa rxe  bcm pe"

    const-string v1, "! ntebnra huT atcbmeex enpoc torlt eal"

    const-string v1, " memc tt! opan necrbeuaolre nlxe Tantt"

    const-string v1, "The context parameter can not be null!"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method static synthetic b()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget-boolean v0, Lcom/tencent/android/tpush/XGPushManager;->a:Z

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method private static b(Landroid/content/Context;)Z
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v1, 0x0

    const/4 v6, 0x5

    move v5, v1

    move v5, v1

    :try_start_0
    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    return v0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v3, Lcom/tencent/android/tpush/service/protocol/n;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v3}, Lcom/tencent/android/tpush/service/protocol/n;-><init>()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->b()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-static {p0, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    check-cast v1, Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v5, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v4

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-nez v4, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v3, v1}, Lcom/tencent/android/tpush/service/protocol/n;->a(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget-object v1, v3, Lcom/tencent/android/tpush/service/protocol/n;->b:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    return v0

    :catchall_0
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :catchall_1
    move-object v1, v2

    move-object v1, v2

    move-object v1, v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    goto :goto_0

    :catchall_2
    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :goto_0
    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :cond_2
    :try_start_3
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/XGApiConfig;->isRegistered(Landroid/content/Context;)Z

    move-result p0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz p0, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object p0, v3, Lcom/tencent/android/tpush/service/protocol/n;->b:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v2, p0}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz p0, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    const/4 p0, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    return p0

    :catchall_3
    :cond_3
    const/4 v6, 0x5

    const/4 v5, 0x0

    return v0
.end method

.method public static bindAccount(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/XGPushManager;->clearAndAppendAccount(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public static bindAccount(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->clearAndAppendAccount(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method public static bindAccount(Landroid/content/Context;Ljava/lang/String;ILcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x0

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/android/tpush/XGPushManager;->clearAndAppendAccount(Landroid/content/Context;Ljava/lang/String;ILcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public static bindAccount(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->clearAndAppendAccount(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public static bytesToHex([B)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x3

    array-length v0, p0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    mul-int/lit8 v0, v0, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    new-array v0, v0, [C

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v1, 0x0

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    array-length v2, p0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-ge v1, v2, :cond_0

    const/4 v7, 0x6

    aget-byte v2, p0, v1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    and-int/lit16 v2, v2, 0xff

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    mul-int/lit8 v3, v1, 0x2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    sget-object v4, Lcom/tencent/android/tpush/XGPushManager;->j:[C

    const/4 v7, 0x6

    ushr-int/lit8 v5, v2, 0x4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    aget-char v5, v4, v5

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    aput-char v5, v0, v3

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    add-int/lit8 v3, v3, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x5

    and-int/lit8 v2, v2, 0xf

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    aget-char v2, v4, v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    aput-char v2, v0, v3

    const/4 v6, 0x2

    move v7, v6

    add-int/lit8 v1, v1, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    goto :goto_0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    new-instance p0, Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-direct {p0, v0}, Ljava/lang/String;-><init>([C)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    return-object p0
.end method

.method static synthetic c()Lcom/tencent/tpns/baseapi/base/util/TTask;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/android/tpush/XGPushManager;->e:Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method private static c(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz p1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v1, "t.gco.maCpEcrDditoein.i.FtExKavou.o.cAennB"

    const-string v1, "iEretBunE.n.ACptcgcmn.inoDioe.F.vx.cdataKo"

    const-string/jumbo v1, "idoonbcAdEvttnnpioeDaEBcaC.K.eg.ixtr.mn.c."

    const-string v1, "com.tencent.android.xg.vip.action.FEEDBACK"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v1, "AKSECBuP.FUHED"

    const-string v1, "TPUSH.FEEDBACK"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const-string v1, "DEUO.CRpSRRPHpO"

    const-string v1, "PECEURRpO.RODHS"

    const/4 v4, 0x4

    const-string v1, "ROE.OERUqRDTHPS"

    const-string v1, "TPUSH.ERRORCODE"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method private static c(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz p2, :cond_0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$4;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, p2}, Lcom/tencent/android/tpush/XGPushManager$4;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance p2, Landroid/content/IntentFilter;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v1, "aTsiTmp..g.LcAEeRUo4.v.ntIdTic.nEd.VcS.oBotqetarixnnT"

    const-string/jumbo v1, "pAciTdnRqBERS.n.iaadnoUc..eTTn.coVL.Tmt.Eig4tIt.oexvr"

    const/4 v3, 0x3

    const-string v1, "VcgmA.RvxiE.edotc.n.4e.Ii.otaitaUE.orTcBd.RLpTSnTTmUn"

    const-string v1, "com.tencent.android.xg.vip.action.ATTRIBUTE.RESULT.V4"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {p2, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p0, v0, p2, v1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v3, 0x4

    return-void
.end method

.method private static c(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string/jumbo v0, "rnaeouXsashGM"

    const-string v0, "hMsGXsuPnraae"

    const/4 v3, 0x2

    const-string/jumbo v0, "naMGgbahrPuXs"

    const-string v0, "XGPushManager"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz p3, :cond_4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eq p3, v1, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eq p3, v1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eq p3, v1, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eq p3, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string p1, " dooepueuTeeeuyQctx reusnonppaepmr:s, Sutt"

    const-string/jumbo p1, "up,mtdp csteorxenotQorTp: eeeSpeuanutey su"

    const/4 v3, 0x4

    const-string/jumbo p1, "xsorutepaeesupo outTn:pe,pepndQyteeSrcr  t"

    const-string p1, "executeSendQuest , unsupport operatorType:"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    goto/16 :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo p3, "oab utntqeeaibosr todatstcd "

    const-string p3, " tdtossbctttooa are ndusabie"

    const/4 v3, 0x4

    const-string/jumbo p3, "tbsats tuas renodaec tbsdrot"

    const-string/jumbo p3, "send boardcast to attributes"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0, p3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    move v3, v2

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->c(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v2, 0x1

    move v3, v2

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const-string/jumbo p3, "nnomtcacd edtaa ou ssctbr"

    const-string/jumbo p3, "t dd bco csseocuantrnoata"

    const/4 v3, 0x7

    const-string p3, "d cbotrounod tass aceotan"

    const-string/jumbo p3, "send boardcast to account"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, p3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->e(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v2, 0x3

    move v3, v2

    goto :goto_0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string p3, " atg bsbedsttr canudo"

    const-string p3, " gttdeud aarastbon cs"

    const/4 v3, 0x0

    const-string p3, "asn soure tbocag atdt"

    const-string/jumbo p3, "send boardcast to tag"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v0, p3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->d(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo p3, "rnaguotpnsrpd te itsadbrces "

    const-string/jumbo p3, "sradubtp scre onnttg oiaedsr"

    const/4 v3, 0x2

    const-string p3, " en rscoqra uraesntdietgbtds"

    const-string/jumbo p3, "send boardcast to unregister"

    const/4 v3, 0x3

    invoke-static {v0, p3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->g(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    goto :goto_0

    :cond_4
    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string p3, "ersnssooir ebqrsateg td ac"

    const-string p3, "eeoetcbtqnsag r sddiaor rs"

    const/4 v3, 0x7

    const-string/jumbo p3, "irem serberdacotssod gtnta"

    const-string/jumbo p3, "send boardcast to register"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, p3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->f(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    :goto_0
    const/4 v2, 0x6

    move v3, v2

    return-void
.end method

.method private static c(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 11

    if-eqz p0, :cond_0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v9

    new-instance v10, Lcom/tencent/android/tpush/XGPushManager$8;

    move-object v0, v10

    move-object v0, v10

    move-object v0, v10

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move v3, p2

    move v3, p2

    move v3, p2

    move v3, p2

    move-wide v4, p3

    move-object/from16 v6, p5

    move-object/from16 v6, p5

    move-object/from16 v6, p5

    move-object/from16 v6, p5

    move-object/from16 v7, p6

    move-object/from16 v7, p6

    move-object/from16 v7, p6

    move-object/from16 v7, p6

    move-object/from16 v8, p7

    move-object/from16 v8, p7

    move-object/from16 v8, p7

    invoke-direct/range {v0 .. v8}, Lcom/tencent/android/tpush/XGPushManager$8;-><init>(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    invoke-virtual {v9, v10}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    return-void

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo v1, "rcT oub!at hoxnllnteeoeenr pcmtns a et"

    const-string v1, "aespoe T n tcnneattcal rh teoblexumr!n"

    const-string v1, " a rcb nexuat etcnnoeelapblhnt  eotmrT"

    const-string v1, "The context parameter can not be null!"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method private static c(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->e()Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v0, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-eqz p4, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SDK_API_FREQUENCY_LIMIT_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string p2, ""

    const-string p2, ""

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-interface {p4, p2, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    return-void

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-lez v0, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    return-void

    :cond_2
    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz p1, :cond_4

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v7, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    cmp-long v3, v0, v3

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-ltz v3, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v2}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-nez v3, :cond_3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance v3, Landroid/content/Intent;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v5, "pgr.ViuaTocm..4TR.ddBIoi.itcExnect.omn.UvnTaAn"

    const-string v5, ".igmcT.coUtneatpiRIcT4vd.xiAtd..BamEor.TVnnno."

    const/4 v7, 0x3

    const-string v5, "..eondTpt4x.Ac.aBITU.cmtigtrocVn.viopdeanRiTEn"

    const-string v5, "com.tencent.android.xg.vip.action.ATTRIBUTE.V4"

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {v3, v4}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string v4, "dccqI"

    const-string v4, "Idcco"

    const/4 v7, 0x6

    const-string v4, "Idsca"

    const-string v4, "accId"

    const/4 v7, 0x4

    invoke-virtual {v3, v4, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string v0, "cybmeK"

    const-string v0, "cKyecb"

    const/4 v7, 0x2

    const-string v0, "ceaKoc"

    const-string v0, "accKey"

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {v2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v3, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string v1, "Ncaukbpe"

    const-string/jumbo v1, "kecmpNua"

    const/4 v7, 0x4

    const-string/jumbo v1, "packName"

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v3, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string/jumbo v0, "paugliusattret"

    const-string/jumbo v0, "uagilrtpsettba"

    const/4 v7, 0x2

    const-string/jumbo v0, "sFbrautptitlag"

    const-string v0, "attributesFlag"

    const/4 v7, 0x2

    invoke-virtual {v3, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string/jumbo p2, "sqbttNtmqaeaer"

    const-string p2, "eNsbttamqeratu"

    const/4 v7, 0x1

    const-string/jumbo p2, "ttsbretasmueNi"

    const-string p2, "attributesName"

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v3, p2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string/jumbo p1, "ttsauiraeOtemeeapNrbt"

    const/4 v7, 0x7

    const-string p1, "aesmatupiOeetabNrertt"

    const-string p1, "attributesOperateName"

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v3, p1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 p1, 0x4

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {p0, v3, p4, p1}, Lcom/tencent/android/tpush/XGPushManager;->safeSendQuest(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V

    const/4 v7, 0x1

    const/4 v6, 0x0

    return-void

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v6, 0x3

    move v7, v6

    const-string/jumbo p1, "ocemsh erccsnT osIecs aeKe sdt at!"

    const/4 v7, 0x5

    const-string p1, " !tcoeyceKdcsssIohas eeoer  ncatTs"

    const-string p1, "The accessId or accessKey not set!"

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    throw p0

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string/jumbo p1, "rt eubtnime tb lh!ane actba etrTul anooep"

    const-string p1, " ueoonlltettaur pi at bTncrah em!netseb a"

    const/4 v7, 0x2

    const-string/jumbo p1, "oiahbnueT lauct!t  ttes arn eeurrbmn lpat"

    const-string p1, "The attributes parameter can not be null!"

    const/4 v6, 0x5

    shr-int/2addr v7, v6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    throw p0
.end method

.method static c(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-static/range {p0 .. p12}, Lcom/tencent/android/tpush/XGPushManager;->d(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    const/4 v1, 0x7

    return-void
.end method

.method public static cancelAllNotifaction(Landroid/content/Context;)V
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string v0, "ebaaGPrpMhsuX"

    const-string/jumbo v0, "sMurhbaeaPgXG"

    const-string/jumbo v0, "sXPraahnqugeG"

    const-string v0, "XGPushManager"

    :try_start_0
    const/4 v8, 0x2

    const/4 v7, 0x3

    const-string/jumbo v1, "onstiointiuc"

    const-string/jumbo v1, "otfiinuontci"

    const/4 v8, 0x3

    const-string/jumbo v1, "ottmcfnioani"

    const-string/jumbo v1, "notification"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x1

    check-cast v1, Landroid/app/NotificationManager;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v1}, Landroid/app/NotificationManager;->cancelAll()V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush(Landroid/content/Context;)Z

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x4

    if-eqz v1, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const-string v1, "aoipom"

    const-string/jumbo v1, "xpoaim"

    const/4 v8, 0x3

    const-string/jumbo v1, "xiaomi"

    const/4 v7, 0x4

    move v8, v7

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/d/d;->k()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz v1, :cond_0

    :try_start_1
    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string v1, ".skmib.nusmio.tPhmidMx.lspCqioicue"

    const-string/jumbo v1, "mkcmmiluqnhssMooPCextui.ii.is..hdp"

    const/4 v8, 0x6

    const-string/jumbo v1, "uiksocum.mtnd.iioheixispsC..aPlmhM"

    const-string v1, "com.xiaomi.mipush.sdk.MiPushClient"

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string/jumbo v2, "lftitcapsoiNinrce"

    const-string/jumbo v2, "lesnifiNacicrtota"

    const/4 v8, 0x0

    const-string v2, "coceitotqnilfriaN"

    const-string v2, "clearNotification"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    const/4 v3, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    const-class v5, Landroid/content/Context;

    const-class v5, Landroid/content/Context;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/4 v6, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x3

    aput-object v5, v4, v6

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v1, v2, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v8, 0x5

    const/4 v7, 0x4

    aput-object p0, v3, v6

    const/4 v7, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v2, v1, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x2

    move v8, v7

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_2
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const-string v2, "Pusmnf rrAo:tier M tahNioeraclfcionliosl"

    const-string v2, " clmirar :AonfniietloPsicohr Nfla rtuMoe"

    const/4 v8, 0x5

    const-string/jumbo v2, "to:millNcftaseuioo alAi horre nifncrPc r"

    const-string v2, "cancelAllNotification for MiPush error: "

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    goto :goto_0

    :catchall_1
    move-exception p0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string/jumbo v2, "rietocfcAnrioolloecn t aNal"

    const-string v2, "acrtoielAn rlaNfociroetc ln"

    const/4 v8, 0x6

    const-string/jumbo v2, "oartiblcrfnrcatAc lio eeNol"

    const-string v2, "cancelAllNotifaction error "

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    return-void
.end method

.method public static cancelNotifaction(Landroid/content/Context;I)V
    .locals 3

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string/jumbo v0, "itnaiouoinct"

    const-string v0, "catoibnnitio"

    const/4 v2, 0x0

    const-string/jumbo v0, "notification"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    check-cast p0, Landroid/app/NotificationManager;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, p1}, Landroid/app/NotificationManager;->cancel(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string v0, " rouenlpcniraNcocati foir"

    const-string v0, "ictlaiure n acoeNircnorof"

    const/4 v2, 0x4

    const-string/jumbo v0, "ocNct neqe tniririofaoalc"

    const-string v0, "cancelNotification error "

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string/jumbo p1, "phsgaaGPMrsnu"

    const-string p1, "aaMXrgspGnPhu"

    const/4 v2, 0x4

    const-string p1, "hgemnsPuaXrGM"

    const-string p1, "XGPushManager"

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public static cleanTags(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v0, 0x2

    move v1, v0

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/XGPushManager;->clearTags(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method public static cleanTags(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->clearTags(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public static clearAccounts(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-nez p0, :cond_0

    const/4 v2, 0x5

    const-string/jumbo p0, "qanhoGegaPMsX"

    const-string p0, "eaPaXhguqsGnM"

    const/4 v2, 0x4

    const-string/jumbo p0, "sguhMbeGnraaP"

    const-string p0, "XGPushManager"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string/jumbo v0, "rl thluctleemontAaacdtr o e. fenxn ultsseAioplu"

    const-string v0, "dlsteA ilruens nlltluefnAhmccor   otetto aaepx."

    const/4 v2, 0x5

    const-string v0, "fcostalpello hp ieuelctAtc ux nrmterAda e nton."

    const-string/jumbo v0, "the parameter context of delAllAccount is null."

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$34;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGPushManager$34;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/XGPushManager;->clearAccounts(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public static clearAccounts(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 12

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x5

    if-nez p0, :cond_1

    const/4 v11, 0x7

    const/4 v10, 0x5

    const-string v0, "hPmGsgrnqeMXa"

    const-string/jumbo v0, "rMgmnsGaaheXP"

    const/4 v11, 0x7

    const-string v0, "aasshXrgnGMeP"

    const-string v0, "XGPushManager"

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    const-string v1, "epAmlxcact oioltrndte.eues no Aueo fnhmltl cl t"

    const-string/jumbo v1, "ontoo ctreeuil natllt.acot Al cmnefxAd eep luhs"

    const/4 v11, 0x5

    const-string/jumbo v1, "the parameter context of delAllAccount is null."

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-eqz p0, :cond_0

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x7

    if-eqz p1, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x1

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ACCOUNT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const/4 v11, 0x2

    const/4 v10, 0x4

    invoke-interface {p1, v1, v0, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x7

    return-void

    :cond_1
    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x2

    const/4 v7, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x4

    const/4 v3, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x7

    const/4 v6, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x6

    const-string v8, ""

    const-string v8, ""

    const/4 v11, 0x7

    const-string v8, ""

    const-string v8, ""

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v9, p1

    move-object v9, p1

    move-object v9, p1

    move-object v9, p1

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static/range {v2 .. v9}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v10, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x5

    return-void
.end method

.method public static clearAndAppendAccount(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz p0, :cond_1

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$30;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {v0, p1}, Lcom/tencent/android/tpush/XGPushManager$30;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->clearAndAppendAccount(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-void

    :cond_1
    :goto_0
    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string p0, "eGsPonghMXaur"

    const-string p0, "XGPushManager"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string/jumbo p1, "oa edbpicuabnu n mnoto r .ierlsxct  bctenonfAt oettcahcu"

    const-string p1, "cidr bcn fupxrbou cmnliu etshoao.natoo e cn tatcAeten tl"

    const/4 v2, 0x5

    const-string/jumbo p1, "nil ndu hocottepo.nma ioexaescbA  ur on encctua tcrtlfur"

    const-string/jumbo p1, "the parameter context or account of bindAccount is null."

    const/4 v2, 0x7

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public static clearAndAppendAccount(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-eqz p0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$23;

    invoke-direct {v0, p1}, Lcom/tencent/android/tpush/XGPushManager$23;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-static {p0, p1, p2, v0}, Lcom/tencent/android/tpush/XGPushManager;->clearAndAppendAccount(Landroid/content/Context;Ljava/lang/String;ILcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void

    :cond_1
    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string/jumbo p0, "rGsnaPapuhguM"

    const-string p0, "ManXgauhrPsGu"

    const-string p0, "GreMXuaPqgnsa"

    const-string p0, "XGPushManager"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string p1, "eos.isc anfenprtpc namooonxtoud  r ubltttunrcclt e Ahaic"

    const-string/jumbo p1, "ucounniptacsm oexeeAif nlrtcc taod  na  cot ub.nhtprrtlo"

    const/4 v2, 0x3

    const-string/jumbo p1, "tptmcuiaouersfnce  cu .a tAe dnemcn  bolotxtaincroh lorn"

    const-string/jumbo p1, "the parameter context or account of bindAccount is null."

    const/4 v2, 0x2

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-void
.end method

.method public static clearAndAppendAccount(Landroid/content/Context;Ljava/lang/String;ILcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 10
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-eqz p0, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-nez p2, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-eqz p2, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x1

    goto :goto_0

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    const/4 v5, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/4 v4, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static/range {v0 .. v7}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    return-void

    :cond_1
    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string p1, "ansXoeGaPMguq"

    const-string p1, "PurgaeGMqXnas"

    const/4 v9, 0x7

    const-string p1, "hMuePbarsXnGa"

    const-string p1, "XGPushManager"

    const/4 v9, 0x3

    const/4 v8, 0x5

    const-string p2, "crsr cnadedreicsnmot.c oopntulof aap cunphllceA etx ru e tenattAnA"

    const/4 v9, 0x5

    const-string/jumbo p2, "oandrtueel  snoAt rpumntrolfeicActtp. nc apoe do x Acnlrtchaeunauc"

    const-string/jumbo p2, "the parameter context or account of clearAndAppendAccount is null."

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    if-eqz p0, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-eqz p3, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ACCOUNT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v9, 0x6

    const/4 v8, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    const-string p2, ""

    const-string p2, ""

    const/4 v9, 0x0

    const-string p2, ""

    const-string p2, ""

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-interface {p3, p2, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    return-void
.end method

.method public static clearAndAppendAccount(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 11
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v10, 0x2

    const/4 v0, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-eqz p0, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x0

    if-nez v0, :cond_1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {v2}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-eqz v0, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    goto :goto_0

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    const/4 v5, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/4 v6, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v8, p2

    move-object v8, p2

    move-object v8, p2

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    return-void

    :cond_1
    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x5

    const-string p1, "aPaMgehpmunGr"

    const-string/jumbo p1, "ruPmsagMnGahe"

    const/4 v10, 0x6

    const-string p1, "PesXharnquMga"

    const-string p1, "XGPushManager"

    const/4 v10, 0x6

    const-string/jumbo v0, "tes rn to eptnr cocbc hceotinnlauco.tonAleri tdx faom as"

    const-string/jumbo v0, "ottmoclanrent upcbxfei Astenonrnoi hc tr.od  o telcaau c"

    const/4 v10, 0x3

    const-string/jumbo v0, "nupmteosn. crfdo  ttau olt t  Aalrcaienccni beeocmxonurh"

    const-string/jumbo v0, "the parameter context or account of bindAccount is null."

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-eqz p0, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-eqz p2, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ACCOUNT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-interface {p2, v0, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    return-void
.end method

.method public static clearAndAppendAttributes(Landroid/content/Context;Ljava/lang/String;Ljava/util/Map;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/tencent/android/tpush/XGIOperateCallback;",
            ")V"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string v0, "aPnbouegMraGs"

    const-string/jumbo v0, "sGMnPbhagraeu"

    const/4 v4, 0x7

    const-string v0, "ehnagburGasMP"

    const-string v0, "XGPushManager"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz p0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz p2, :cond_2

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {p2}, Ljava/util/Map;->isEmpty()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/Map;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v1, "drnrptuapeduAtueiAtcnAbs"

    const-string v1, "bdspinurductntAepareAAet"

    const/4 v4, 0x1

    const-string/jumbo v1, "sceetpnpApeadrAritntlbuA"

    const-string v1, "clearAndAppendAttributes"

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v1, p2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v2, " npteAr qttlbut=lA ewaidtt eihnrai spblArputde"

    const-string/jumbo v2, "u airAlpwbdadtnAt ieuneeppb rtlt At lseitrt=ch"

    const/4 v4, 0x5

    const-string/jumbo v2, "rcsestdtrtrAallnhu=Ae  ua ti  enpdawtiAepbiltt"

    const-string v2, "clearAndAppendAttributes with all attribute = "

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v0, 0x2

    const/4 v4, 0x2

    const/4 v0, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p0, p2, v0, p1, p3}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void

    :cond_2
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string p1, "cepmmnlcor.eiain ltart rieitdttqe earneot vruehpi AfnpxubraAAa tstbtt odsd "

    const-string/jumbo p1, "ldeeenriqtAcptr piervbe fx doo Atted cnuptaeh ateoslu ranAtibrartittas. mni"

    const/4 v4, 0x4

    const-string/jumbo p1, "tcpuodoaden rn.Adtacfipr etAbhiaA sontrapsteelr eoliettt b mrvsiatnextuer i"

    const-string/jumbo p1, "the parameter context or attributes of clearAndAppendAttributes is invalid."

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    move v4, v3

    if-eqz p0, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz p3, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ATTRIBUTE:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string p2, ""

    const-string p2, ""

    const/4 v4, 0x6

    const-string p2, ""

    const-string p2, ""

    const/4 v4, 0x0

    invoke-interface {p3, p2, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_3
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    return-void
.end method

.method public static clearAndAppendTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    const-string v0, "XsGMrbenhgsau"

    const-string v0, "gesXGMranshua"

    const/4 v10, 0x5

    const-string/jumbo v0, "srngePuaMaXGu"

    const-string v0, "XGPushManager"

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-eqz p0, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    if-eqz p2, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-interface {p2}, Ljava/util/Set;->isEmpty()Z

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-eqz v1, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    goto/16 :goto_0

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x6

    const-string/jumbo v1, "pstsmTe"

    const-string/jumbo v1, "sTsmtge"

    const/4 v10, 0x1

    const-string/jumbo v1, "setTags"

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-static {p2, v1}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/Set;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x0

    const/4 v9, 0x0

    invoke-static {v3}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result p2

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-eqz p2, :cond_1

    const/4 v10, 0x2

    const-string p0, " r!mulroqetst gTTS- aesteenluoag >ntFrs!"

    const-string/jumbo p0, "lggroSuate!teor FTnutTa-l!rn smesest > g"

    const/4 v10, 0x4

    const-string/jumbo p0, "tgslTau!!srgtSae rnT >-r!Fstuetsee nmgo "

    const-string/jumbo p0, "setTags -> getTagsFromSet return null!!!"

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    return-void

    :cond_1
    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-string/jumbo v1, "sagme Alisgnt Tt  ac wttob=a  l>hi"

    const-string v1, "=Agw>bt sa ctotagia  t-he lTnl  si"

    const/4 v10, 0x3

    const-string/jumbo v1, "t w>ot-=  ihssgl tag aTacloAiets  "

    const-string v1, "Action -> setTags with all tags = "

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    move v10, v9

    const/4 v4, 0x6

    or-int/2addr v10, v4

    const/4 v9, 0x4

    or-int/2addr v10, v9

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x3

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-static/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x2

    return-void

    :cond_2
    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-string p0, "T  i bo asre e atevh.isdlsf mrattapxtteso rgniaoctng"

    const-string/jumbo p0, "the parameter context or tags of setTags is invalid."

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    return-void
.end method

.method public static clearAndAppendTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/tencent/android/tpush/XGIOperateCallback;",
            ")V"
        }
    .end annotation

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    const-string v0, "Tegtssu"

    const-string/jumbo v0, "tesTsgu"

    const/4 v10, 0x2

    const-string/jumbo v0, "ptTsags"

    const-string/jumbo v0, "setTags"

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/Set;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string/jumbo v0, "raPGMpghqusXn"

    const-string v0, "hanXsgPperuGM"

    const/4 v10, 0x5

    const-string v0, "XGPushManager"

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-eqz p0, :cond_1

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz p2, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-interface {p2}, Ljava/util/Set;->isEmpty()Z

    move-result p2

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-nez p2, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-eqz p2, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x4

    goto :goto_0

    :cond_0
    const/4 v9, 0x7

    move v10, v9

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string/jumbo v1, "q>s ls -t  ei t gswiaaTnhtoAagtc s"

    const-string v1, " ih  iAgq>at t-gel wasTttco  sas=n"

    const/4 v10, 0x2

    const-string v1, "Action -> setTags with all tags = "

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/4 v3, 0x6

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v10, 0x5

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    const/4 v6, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v8, p3

    move-object v8, p3

    move-object v8, p3

    move-object v8, p3

    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    return-void

    :cond_1
    :goto_0
    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-string p1, " e.mtssev ihaopi tgsan rtdattclTr  goioaa msr extsef"

    const-string p1, " xstn.ooitTp ess t ni  rosfs raagtedgmaateachrvi etl"

    const/4 v10, 0x2

    const-string/jumbo p1, "thiao.ep tcaaaxivr ogtes itgsnsre  Tmnede t lsfoor a"

    const-string/jumbo p1, "the parameter context or tags of setTags is invalid."

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x1

    if-eqz p0, :cond_2

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    if-eqz p3, :cond_2

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_TAG:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-string p2, ""

    const-string p2, ""

    const/4 v10, 0x4

    const-string p2, ""

    const-string p2, ""

    const/4 v10, 0x4

    invoke-interface {p3, p2, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x3

    return-void
.end method

.method public static clearAttributes(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string/jumbo v0, "rsehgbPnGuamX"

    const-string v0, "hMumseaXGgPrn"

    const/4 v3, 0x4

    const-string v0, "GPeugMuashnra"

    const-string v0, "XGPushManager"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez p0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo p1, "tetron pcdttthrietbotmaesol eavip niaaeAesi c fx lr"

    const-string/jumbo p1, "thotoatcodmer x ibatAepsitcallve etsinfne  reitrua "

    const/4 v3, 0x0

    const-string p1, "dtliefr qtatieachiusnmteecvsrbttlo tr  eae p xonraA"

    const-string/jumbo p1, "the parameter context of clearAttributes is invalid"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz p2, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ATTRIBUTE:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-interface {p2, v0, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void

    :cond_1
    const/4 v3, 0x0

    const-string/jumbo v1, "ttsAuars>bti ccr-t eeiolA"

    const-string v1, "cAorcbttals -e>n ritteiuA"

    const/4 v3, 0x0

    const-string v1, "- tm ebi>itcAcuerroltsAta"

    const-string v1, "Action -> clearAttributes"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo v0, "}{"

    const-string/jumbo v0, "{}"

    const/4 v3, 0x5

    const-string/jumbo v0, "{}"

    const-string/jumbo v0, "{}"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v1, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-static {p0, v0, v1, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method

.method public static clearLocalNotifications(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string p0, "PuhaoXnuaegGr"

    const-string p0, "PnuaXguahsGre"

    const/4 v3, 0x6

    const-string/jumbo p0, "rXeGubgPhsnaM"

    const-string p0, "XGPushManager"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const-string v0, "eintr usonacxeLlNap aoi=t=ltutollc.fnoc"

    const-string/jumbo v0, "utlfcc p=nlttLaao.cs=cooeNrnxnltloie ai"

    const-string/jumbo v0, "tt=sn=tpnnauoiLleioo. cariaNctll xofcec"

    const-string v0, "clearLocalNotifications  context==null."

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/XGPushManager$17;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/XGPushManager$17;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method public static clearTags(Landroid/content/Context;Ljava/lang/String;)V
    .locals 11

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x7

    const-string/jumbo v0, "rqsgaXhaqGMPe"

    const-string/jumbo v0, "sXaerPghqMGna"

    const/4 v10, 0x3

    const-string v0, "PXsegaGasrMhn"

    const-string v0, "XGPushManager"

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    if-nez p0, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    const-string p0, " tamteanlnceadsncplao sxvae iito ht fegmrsiTe"

    const-string/jumbo p0, "veseaogifala nmepsett cThelix cdtias n n aotr"

    const/4 v10, 0x6

    const-string p0, "e etoaieal aeotandngx m npi eahrtclsT cvroitf"

    const-string/jumbo p0, "the parameter context of cleanTags is invalid"

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    return-void

    :cond_0
    const/4 v9, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x1

    const-string v1, " sc-gba>cT mlAaonne"

    const-string/jumbo v1, "sngme>-Ta acAtn olc"

    const/4 v10, 0x5

    const-string v1, " -g>aou ecainTsAnlc"

    const-string v1, "Action -> cleanTags"

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const-string v3, "*"

    const-string v3, "*"

    const/4 v10, 0x6

    const-string v3, "*"

    const-string v3, "*"

    const/4 v10, 0x4

    const/16 v4, 0x8

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x1

    return-void
.end method

.method public static clearTags(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 12

    const/4 v11, 0x2

    const-string v0, "MagGrXopsPuan"

    const-string v0, "XanPoueagMrGs"

    const/4 v11, 0x3

    const-string v0, "gMXusGreqPnah"

    const-string v0, "XGPushManager"

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-nez p0, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    const-string p0, "ebsnatgm nnrh ldeao cretesel a if icpatTistvx"

    const-string p0, "eitnabetc fiogcnxnprse Ti desatotaelmvr   hal"

    const/4 v11, 0x0

    const-string/jumbo p0, "mc msaegc evttorlate  dhinaixoenntiTalspf ea "

    const-string/jumbo p0, "the parameter context of cleanTags is invalid"

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x7

    return-void

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string v1, "a noon it>cc-aegTAs"

    const-string v1, "Action -> cleanTags"

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    const-string v3, ""

    const-string v3, ""

    const/4 v11, 0x0

    const-string v3, ""

    const-string v3, ""

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x1

    const/16 v4, 0x8

    const/4 v11, 0x4

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v11, 0x2

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v11, 0x4

    const/4 v7, 0x0

    move v10, v7

    move v10, v7

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v9, p2

    move-object v9, p2

    move-object v9, p2

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-static/range {v2 .. v9}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    return-void
.end method

.method public static createNotificationChannel(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZZZLandroid/net/Uri;)V
    .locals 8

    const/4 v7, -0x1

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move v3, p3

    move v3, p3

    move v3, p3

    move v4, p4

    move v4, p4

    move v4, p4

    move v4, p4

    move v5, p5

    move v5, p5

    move v5, p5

    move v5, p5

    move-object v6, p6

    move-object v6, p6

    invoke-static/range {v0 .. v7}, Lcom/tencent/android/tpush/XGPushManager;->createNotificationChannel(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZZZLandroid/net/Uri;I)V

    return-void
.end method

.method public static createNotificationChannel(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZZZLandroid/net/Uri;I)V
    .locals 13

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move/from16 v0, p7

    move/from16 v0, p7

    move/from16 v0, p7

    move/from16 v0, p7

    const-string/jumbo v2, "neeiCbaflcent: InNtlocdunaetoanhhr ii"

    const-string v2, "fccCt uehriCla denonantelihie:nNaIton"

    const-string v2, "CnnNn ucfCli ichrtai:otIdaaenhatlenoe"

    const-string v2, "CreateNotificationChannel channelId: "

    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v4, 0x1a

    const-string v5, "hgesXMrpuaPna"

    const-string v5, "MenauXrpPhsGa"

    const-string v5, "XGPushManager"

    if-ge v3, v4, :cond_0

    const-string v0, "antroK iqeohnCNi iS26nD Ctfee<talc"

    const-string/jumbo v0, "nietaKhtqoDNC n<o6nei2SefCac rlti "

    const-string v0, "cns aK iDieetotCa<S6nN eh2atflCoir"

    const-string v0, "CreateNotificationChannel SDK < 26"

    invoke-static {v5, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_0
    :try_start_0
    const-string v3, "Nnomathr.oaiie.dalnipitcfdnspCn"

    const-string v3, "aascinafotrinteohiCdNn.ipnop.ld"

    const-string v3, "dflNoioainintchore.Cptianodaanp"

    const-string v3, "android.app.NotificationChannel"

    invoke-static {v3}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v3

    const/4 v4, 0x3

    new-array v6, v4, [Ljava/lang/Class;

    const-class v7, Ljava/lang/String;

    const-class v7, Ljava/lang/String;

    const-class v7, Ljava/lang/String;

    const-class v7, Ljava/lang/String;

    const/4 v8, 0x0

    aput-object v7, v6, v8

    const-class v7, Ljava/lang/CharSequence;

    const-class v7, Ljava/lang/CharSequence;

    const/4 v9, 0x1

    aput-object v7, v6, v9

    sget-object v7, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v10, 0x2

    aput-object v7, v6, v10

    invoke-virtual {v3, v6}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v6

    if-lez v0, :cond_1

    const/4 v7, 0x5

    if-lt v0, v7, :cond_2

    :cond_1
    const/4 v0, 0x4

    :cond_2
    new-array v4, v4, [Ljava/lang/Object;

    aput-object v1, v4, v8

    aput-object p2, v4, v9

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    aput-object v0, v4, v10

    invoke-virtual {v6, v4}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const-string/jumbo v6, "ilrombbtaVbenin"

    const-string/jumbo v6, "narmbieitVbnelo"

    const-string v6, "bbanteuelViiorn"

    const-string v6, "enableVibration"

    new-array v7, v9, [Ljava/lang/Class;

    sget-object v11, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v11, v7, v8

    invoke-virtual {v4, v6, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    new-array v6, v9, [Ljava/lang/Object;

    invoke-static/range {p3 .. p3}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    aput-object v7, v6, v8

    invoke-virtual {v4, v0, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const-string/jumbo v6, "lLbtngipesha"

    const-string v6, "enableLights"

    new-array v7, v9, [Ljava/lang/Class;

    aput-object v11, v7, v8

    invoke-virtual {v4, v6, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    new-array v6, v9, [Ljava/lang/Object;

    invoke-static/range {p4 .. p4}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v7

    aput-object v7, v6, v8

    invoke-virtual {v4, v0, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const-string v4, "de.iiub.qaitddnaoreoAuosAirtt"

    const-string v4, ".Aoroodanidebittui.iuAeddsrta"

    const-string/jumbo v4, "tusmarnrAdAui.ddb.iietietdaos"

    const-string v4, "android.media.AudioAttributes"

    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    const-string v7, "dsomntbe"

    const-string/jumbo v7, "toedsbSn"

    const-string v7, "desuotnS"

    const-string/jumbo v7, "setSound"

    new-array v11, v10, [Ljava/lang/Class;

    const-class v12, Landroid/net/Uri;

    const-class v12, Landroid/net/Uri;

    const-class v12, Landroid/net/Uri;

    const-class v12, Landroid/net/Uri;

    aput-object v12, v11, v8

    aput-object v4, v11, v9

    invoke-virtual {v6, v7, v11}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    const/4 v6, 0x0

    if-nez p5, :cond_3

    new-array v7, v10, [Ljava/lang/Object;

    aput-object v6, v7, v8

    aput-object v6, v7, v9

    invoke-virtual {v4, v0, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_3
    if-eqz p6, :cond_4

    new-array v7, v10, [Ljava/lang/Object;

    aput-object p6, v7, v8

    aput-object v6, v7, v9

    invoke-virtual {v4, v0, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_4
    :goto_0
    const-string/jumbo v4, "otifnbiinoac"

    const-string/jumbo v4, "ofcntiuaonii"

    const-string v4, "foiitnuctian"

    const-string/jumbo v4, "notification"

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    move-object v6, p0

    invoke-virtual {p0, v4}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v4

    check-cast v4, Landroid/app/NotificationManager;

    invoke-virtual {v4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    const-string v7, "enfceitplohicaonprCNteiaa"

    const-string/jumbo v7, "ncirioepeotfalNCntcanaeih"

    const-string/jumbo v7, "tiiotCnfqaocaehetrenialnN"

    const-string v7, "createNotificationChannel"

    new-array v10, v9, [Ljava/lang/Class;

    aput-object v3, v10, v8

    invoke-virtual {v6, v7, v10}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    new-array v6, v9, [Ljava/lang/Object;

    aput-object v0, v6, v8

    invoke-virtual {v3, v4, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, "scsqucse"

    const-string/jumbo v3, "que sccs"

    const-string v3, "essmusc "

    const-string v3, " success"

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v5, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v0

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, " r soEro"

    const-string/jumbo v1, "rrsEr  o"

    const-string v1, " Error: "

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v5, v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    return-void
.end method

.method static synthetic d()Ljava/util/Map;
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/android/tpush/XGPushManager;->i:Ljava/util/Map;

    const/4 v2, 0x3

    const/4 v1, 0x7

    return-object v0
.end method

.method private static d(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 4

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz p2, :cond_0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$9;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, p2}, Lcom/tencent/android/tpush/XGPushManager$9;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance p2, Landroid/content/IntentFilter;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo v1, "re.tLb.meA4cEg.tn.iVdixTmRd.oinUp.T.Sa.ccootnna"

    const-string/jumbo v1, "t..mxot.noradm4cpTcSeEiAavgRtiV.Uo.nnT.ceL.in.d"

    const/4 v3, 0x6

    const-string/jumbo v1, "r.aoi.uSE.otv4AiUigcn.tVxeGaoeTTnct..Rpm.Lcndd."

    const-string v1, "com.tencent.android.xg.vip.action.TAG.RESULT.V4"

    const/4 v3, 0x3

    invoke-direct {p2, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p0, v0, p2, v1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :catchall_0
    move-exception p2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v1, "graav epRegensceo otrMe iartgrerie"

    const-string/jumbo v1, "nraiosre RcrverMeerae tog egaegitr"

    const/4 v3, 0x1

    const-string v1, "Rertgereqaresgorc eaMgir etria evn"

    const-string/jumbo v1, "tagManager registerReceiver error "

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p2}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string/jumbo v0, "srsGPeahubnXg"

    const-string v0, "GParXbMuesngh"

    const/4 v3, 0x7

    const-string v0, "easmuXGanghPr"

    const-string v0, "XGPushManager"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-void
.end method

.method private static d(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->e()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz p7, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SDK_API_FREQUENCY_LIMIT_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string p2, ""

    const-string p2, ""

    const/4 v4, 0x3

    const-string p2, ""

    const-string p2, ""

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {p7, p2, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void

    :cond_1
    const/4 v4, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-lez v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz p1, :cond_6

    const/4 v4, 0x6

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    cmp-long v2, p3, v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-gtz v2, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide p3

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    cmp-long v0, p3, v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-ltz v0, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p5}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-eqz v0, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p5

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v0, Landroid/content/Intent;

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v2, "d..eog.tpnitnmi.a.odi4oV.euoGncr.cvtAcnx"

    const-string v2, "eiicdnu.AgnVtxiotrTc.e.nom.o4nc.vGpad..t"

    const/4 v4, 0x0

    const-string/jumbo v2, "nTvd.bGVxcr4.emid.io.tegc..onnpnto.taAac"

    const-string v2, "com.tencent.android.xg.vip.action.TAG.V4"

    const/4 v3, 0x7

    and-int/2addr v4, v3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string v1, "dcpcI"

    const/4 v4, 0x3

    const-string v1, "Iudcc"

    const-string v1, "accId"

    const/4 v4, 0x5

    invoke-virtual {v0, v1, p3, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string p3, "Kpycca"

    const-string p3, "accKey"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {p5}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, p3, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p3}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo p4, "qqckamep"

    const-string/jumbo p4, "qakeacmp"

    const/4 v4, 0x1

    const-string/jumbo p4, "kmsNacep"

    const-string/jumbo p4, "packName"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, p4, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x4

    move v4, v3

    const-string p3, "Falmsat"

    const-string/jumbo p3, "lgsFaat"

    const/4 v4, 0x5

    const-string p3, "gFlgoat"

    const-string/jumbo p3, "tagFlag"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, p3, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x0

    const-string/jumbo p2, "tgamebm"

    const-string/jumbo p2, "tgemaam"

    const/4 v4, 0x3

    const-string/jumbo p2, "megNtau"

    const-string/jumbo p2, "tagName"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, p2, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x7

    const-string/jumbo p1, "mgaorpNpeageeO"

    const-string p1, "agaNogaeeepmrO"

    const/4 v4, 0x1

    const-string/jumbo p1, "rteNaaOaqegepg"

    const-string/jumbo p1, "tagOperageName"

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, p1, p6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 p1, 0x2

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p0, v0, p7, p1}, Lcom/tencent/android/tpush/XGPushManager;->safeSendQuest(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void

    :cond_5
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo p1, "otseae  IccbsthesT! d"

    const-string p1, " I ecbeTnhste !cdtaso"

    const/4 v4, 0x4

    const-string/jumbo p1, "nscmttoeehT s !sIadce"

    const-string p1, "The accessId not set!"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    throw p0

    :cond_6
    const/4 v3, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo p1, "rlaho aoaaegncemnp e ttau!lu mnteTb e "

    const-string p1, "eea tgu aataunNemr!Tbm enclalpon   teh"

    const/4 v4, 0x6

    const-string p1, "!g trb namo lnmt eebaraalcehnpN teTa u"

    const-string p1, "The tagName parameter can not be null!"

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    throw p0
.end method

.method private static d(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .locals 15

    new-instance v14, Lcom/tencent/android/tpush/XGPushManager$24;

    move-object v0, v14

    move-object v0, v14

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object/from16 v2, p4

    move-object/from16 v2, p4

    move-object/from16 v2, p4

    move-object/from16 v2, p4

    move-wide/from16 v3, p5

    move-object/from16 v5, p7

    move-object/from16 v5, p7

    move-object/from16 v5, p7

    move-object/from16 v5, p7

    move-wide/from16 v6, p11

    move/from16 v8, p2

    move/from16 v8, p2

    move/from16 v8, p2

    move/from16 v8, p2

    move-object/from16 v9, p1

    move-object/from16 v9, p1

    move-object/from16 v9, p1

    move-object/from16 v9, p1

    move-object/from16 v10, p3

    move-object/from16 v10, p3

    move-object/from16 v10, p3

    move-object/from16 v10, p3

    move-object/from16 v11, p8

    move-object/from16 v11, p8

    move-object/from16 v11, p8

    move-object/from16 v11, p8

    move-object/from16 v12, p10

    move-object/from16 v12, p10

    move-object/from16 v12, p10

    move-object/from16 v12, p10

    move-object/from16 v13, p9

    move-object/from16 v13, p9

    invoke-direct/range {v0 .. v13}, Lcom/tencent/android/tpush/XGPushManager$24;-><init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;JILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    invoke-virtual {v0}, Landroid/os/Looper;->getThread()Ljava/lang/Thread;

    move-result-object v0

    invoke-virtual {v0}, Ljava/lang/Thread;->getId()J

    move-result-wide v0

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Thread;->getId()J

    move-result-wide v2

    cmp-long v0, v0, v2

    if-nez v0, :cond_0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    invoke-virtual {v0, v14}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    goto :goto_0

    :cond_0
    invoke-virtual {v14}, Lcom/tencent/tpns/baseapi/base/util/TTask;->run()V

    :goto_0
    return-void
.end method

.method public static delAccount(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz p0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$33;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-direct {v0, p1}, Lcom/tencent/android/tpush/XGPushManager$33;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->delAccount(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string p0, "arPhGXuegupMs"

    const-string p0, "GsuPXhrpagMae"

    const/4 v2, 0x4

    const-string p0, "gnPXauapeMrsh"

    const-string p0, "XGPushManager"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string p1, " encntlcqcuoheaxe cateordltctnoAliu. spfoatomq rn re  u"

    const-string p1, "enef  eeqnAcoutpodn a ictrrmto  tlccuheotxn acosl.al ru"

    const-string/jumbo p1, "tasncct xs  peeehnof elrmdc ut cnol i.rtaAec ttrouoonul"

    const-string/jumbo p1, "the parameter context or account of delAccount is null."

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x3

    return-void
.end method

.method public static delAccount(Landroid/content/Context;Ljava/lang/String;ILcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 10
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-eqz p0, :cond_1

    const/4 v9, 0x3

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-nez p2, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-eqz p2, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    goto :goto_0

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v5, 0x5

    const/4 v5, 0x3

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x2

    const/4 v4, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v6, p1

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static/range {v0 .. v7}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    return-void

    :cond_1
    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eqz p0, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x6

    if-eqz p3, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x6

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ACCOUNT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const-string p2, ""

    const-string p2, ""

    const/4 v9, 0x2

    const-string p2, ""

    const-string p2, ""

    const/4 v9, 0x4

    const/4 v8, 0x6

    invoke-interface {p3, p2, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    const/4 v9, 0x1

    const/4 v8, 0x1

    const-string/jumbo p0, "uXsaghMrsenGP"

    const/4 v9, 0x6

    const-string p0, "gXemPaashMGnu"

    const-string p0, "XGPushManager"

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string/jumbo p1, "nrlmdca ecoeue unfA nora cntphe.txost ametut coil  olrc"

    const/4 v9, 0x1

    const-string/jumbo p1, "prteot.o rntAtmnlt afo dtxc  lcoic coeunhu eose eauncra"

    const-string/jumbo p1, "the parameter context or account of delAccount is null."

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    return-void
.end method

.method public static delAccount(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 11
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x6

    const/4 v0, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-eqz p0, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-nez v0, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x6

    invoke-static {v2}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-eqz v0, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/4 v6, 0x3

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x3

    const-wide/16 v3, 0x0

    const/4 v10, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x7

    const/4 v5, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v8, p2

    move-object v8, p2

    move-object v8, p2

    move-object v8, p2

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x1

    return-void

    :cond_1
    :goto_0
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string p1, "guGnrbaXMhsea"

    const-string p1, "XGPushManager"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-string/jumbo v0, "o eu.tumnt  foceea olpuldtrtcernaoh rnaAs toctncxeclu  "

    const-string/jumbo v0, "the parameter context or account of delAccount is null."

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-eqz p0, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x0

    if-eqz p2, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ACCOUNT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-interface {p2, v0, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x1

    return-void
.end method

.method public static delAccounts(Landroid/content/Context;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 12
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;",
            "Lcom/tencent/android/tpush/XGIOperateCallback;",
            ")V"
        }
    .end annotation

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    const-string v0, "ahMaePrpgouXG"

    const-string/jumbo v0, "suGrohaMPaXeg"

    const/4 v11, 0x6

    const-string v0, "aurGhMasqXegP"

    const-string v0, "XGPushManager"

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    if-eqz p0, :cond_2

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    if-eqz p1, :cond_2

    const/4 v10, 0x4

    or-int/2addr v11, v10

    invoke-interface {p1}, Ljava/util/Set;->size()I

    move-result v1

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-gtz v1, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x1

    goto/16 :goto_0

    :cond_0
    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/XGPushManager;->b(Ljava/util/Set;)Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x4

    shl-int/2addr v11, v10

    invoke-static {v8}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result p1

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-eqz p1, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x0

    const-string p0, " Ssaytoipyuo|cAe e Tcdcnbt ttceplsrsu"

    const-string/jumbo p0, "nTAcobcu|s lucy etdatsrtpySc ipt eneo"

    const/4 v11, 0x5

    const-string/jumbo p0, "l emtyeptraouc  iunt|AsypsncctecmSd o"

    const-string p0, "delAccounts | accountTypeStr is empty"

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x1

    return-void

    :cond_1
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x1

    const-string v1, ":aclocnoeStudnce oTyt cA usp| t"

    const-string/jumbo v1, "tsT|t u:ucoclnyneSo ccrad Apte "

    const/4 v11, 0x2

    const-string v1, "dopStbynt lcu :cTeu|r sAactc no"

    const-string v1, "delAccounts | accountTypeStr : "

    const/4 v11, 0x7

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    const/4 v7, 0x7

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v11, 0x5

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    const/4 v6, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-object v9, p2

    move-object v9, p2

    move-object v9, p2

    move-object v9, p2

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-static/range {v2 .. v9}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    return-void

    :cond_2
    :goto_0
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x7

    const-string p1, "  txeeuntotctoduclti utfol ecan seuecoch lra.orpps  oalAcdcntsn es| Anm"

    const-string/jumbo p1, "ulnl| opxtnncetct fenp.ucaacs ttAoo tAnlchedr sa lrse uecom us ctooide "

    const/4 v11, 0x5

    const-string p1, "f lcceApu|ecucsptceo rr eanltnedmhtsn reo l cld cioa.nsto uu s otoanAtt"

    const-string p1, "delAccounts | the parameter context or accounts of delAccounts is null."

    const/4 v11, 0x7

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    if-eqz p0, :cond_3

    const/4 v11, 0x1

    if-eqz p2, :cond_3

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x1

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ACCOUNT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-interface {p2, v0, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_3
    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x2

    return-void
.end method

.method public static delAccountsByKeys(Landroid/content/Context;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/Set<",
            "Ljava/lang/Integer;",
            ">;",
            "Lcom/tencent/android/tpush/XGIOperateCallback;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->delAccounts(Landroid/content/Context;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x5

    return-void
.end method

.method public static delAllAccount(Landroid/content/Context;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->clearAccounts(Landroid/content/Context;)V

    const/4 v1, 0x7

    return-void
.end method

.method public static delAllAccount(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/XGPushManager;->clearAccounts(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public static delAttributes(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/tencent/android/tpush/XGIOperateCallback;",
            ")V"
        }
    .end annotation

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string v0, "GseanMXPqargq"

    const-string v0, "hXsnMrGaqPgae"

    const-string v0, "XGPushManager"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz p0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x6

    if-eqz p2, :cond_2

    const/4 v3, 0x3

    shr-int/2addr v4, v3

    invoke-interface {p2}, Ljava/util/Set;->isEmpty()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/Set;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v1, "esslttuAiebts"

    const-string v1, "iAsdlbtseutte"

    const/4 v4, 0x2

    const-string/jumbo v1, "stdmltreAtbiu"

    const-string v1, "delAttributes"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v1, p2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    if-nez v1, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo v2, "ubsiotmAadbiett t e  tr-r>els="

    const-string/jumbo v2, "sasm -el bttrirdeAuttte= tib >"

    const/4 v4, 0x0

    const-string/jumbo v2, "tr=-lbeeusdbtreu>  t i Atbttsi"

    const-string v2, "delAttributes -> attributes = "

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    move v4, v3

    const/4 v0, 0x3

    shl-int/2addr v4, v0

    const/4 v3, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p0, p2, v0, p1, p3}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void

    :cond_2
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string p1, "etcoedu  tldtvopertsue a o armeiAai utetosla.hsiibe nfrrtxt tbti"

    const-string p1, "dtatoixseefrsi tipsol. t truhaaAtttremuorbc i et odtvaieeebnrl  "

    const/4 v4, 0x4

    const-string p1, "eeuoie pml t naua eitbxntorao feht.trdpivsietedrt  bsAalrcrtit t"

    const-string/jumbo p1, "the parameter context or attributes of delAttributes is invalid."

    const/4 v4, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    if-eqz p0, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz p3, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ATTRIBUTE:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string p2, ""

    const-string p2, ""

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {p3, p2, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method

.method public static delTag(Landroid/content/Context;Ljava/lang/String;)V
    .locals 11
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const-string v1, "adt>g  -q lctetT i= ht eiegnAab"

    const-string/jumbo v1, "t =iab etgno  A  ct>eaideT-tghl"

    const/4 v10, 0x1

    const-string v1, "i s >aictte lTweggt=n  d to-Aea"

    const-string v1, "Action -> deleteTag with tag = "

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    const-string/jumbo v1, "suXmnGuehragM"

    const-string/jumbo v1, "nXusehuaGrMag"

    const-string v1, "gaePourMhGsXn"

    const-string v1, "XGPushManager"

    const/4 v10, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz p0, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x7

    if-eqz p1, :cond_1

    const/4 v9, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    if-nez v0, :cond_0

    const/4 v9, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x3

    goto :goto_0

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    const/4 v4, 0x2

    const/4 v9, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-wide/16 v5, -0x1

    const/4 v10, 0x4

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-static/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    return-void

    :cond_1
    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-string/jumbo p0, "ilrilbom. tigl c na  naspxntuetdNev"

    const-string/jumbo p0, "u anv ipnoacisxltNndrma el.g lt ite"

    const/4 v10, 0x3

    const-string p0, "context is null or tagName invalid."

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    return-void
.end method

.method public static delTag(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 12
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, " aenewu g= h gcqdA-> tioe ialTt"

    const-string/jumbo v1, "n>h aelgqot=Aed ti-ge w Tc iat "

    const-string/jumbo v1, "nawo ecph  >aitegtdtATl =e g-i "

    const-string v1, "Action -> deleteTag with tag = "

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    const-string v1, "esraauXgqhGsP"

    const-string v1, "assGehMruPXga"

    const/4 v11, 0x0

    const-string/jumbo v1, "rMshaseuXPgna"

    const-string v1, "XGPushManager"

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-eqz p0, :cond_1

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-eqz p1, :cond_1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-nez v0, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x7

    goto :goto_0

    :cond_0
    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    const/4 v4, 0x2

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v9, p2

    move-object v9, p2

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-static/range {v2 .. v9}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v11, 0x3

    const/4 v10, 0x7

    return-void

    :cond_1
    :goto_0
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    const-string/jumbo p1, "xdem srlt og mul ie naatimN.clnavti"

    const-string p1, " samainol tN.imtcoadietl vu xrne lg"

    const/4 v11, 0x1

    const-string p1, "anamoi xgot s dc.irvNaee tlolintl n"

    const-string p1, "context is null or tagName invalid."

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x2

    xor-int/2addr v11, v10

    if-eqz p0, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x6

    if-eqz p2, :cond_2

    const/4 v10, 0x4

    move v11, v10

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_TAG:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v11, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v11, 0x3

    const/4 v10, 0x4

    invoke-interface {p2, v0, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    return-void
.end method

.method public static delTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    const-string v0, "arXnsbMPaogGu"

    const-string/jumbo v0, "nuPsoMraeaXgG"

    const/4 v10, 0x1

    const-string/jumbo v0, "rePasnuuMaghG"

    const-string v0, "XGPushManager"

    const/4 v10, 0x6

    if-eqz p0, :cond_2

    const/4 v10, 0x4

    if-eqz p2, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-interface {p2}, Ljava/util/Set;->isEmpty()Z

    move-result v1

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    if-eqz v1, :cond_0

    const/4 v9, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    goto/16 :goto_0

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    const-string v1, "ebaelTtpds"

    const-string v1, "egTtebsald"

    const/4 v10, 0x5

    const-string/jumbo v1, "tdlseaeeqT"

    const-string v1, "deleteTags"

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {p2, v1}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/Set;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v3}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result p2

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    if-eqz p2, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    const-string p0, ">lsor lFSTlue!en ugda aermTgut!nt!ttessg -e"

    const-string/jumbo p0, "lrrSanus ol tTstFmtge >!e!gTagdunltue!e re-"

    const/4 v10, 0x3

    const-string/jumbo p0, "me-mderonltrse l u!!gtTeegar>Stgs tTnuel!a "

    const-string p0, "deleteTags -> getTagsFromSet return null!!!"

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    return-void

    :cond_1
    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-string v1, "heigolp-a ttt ll=ad sTsgge   eaTe>a tw"

    const-string v1, "  g thepge wtetaas=dalslig  eta> -slTT"

    const/4 v10, 0x5

    const-string v1, "ea s=b-s a eTsl etlagetgi ah wtsTdgl> "

    const-string v1, "deleteTags -> setTags with all tags = "

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {p2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    const/4 v4, 0x7

    const/4 v10, 0x5

    const/4 v9, 0x2

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x3

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-static/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    return-void

    :cond_2
    :goto_0
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string p0, "aofteeurertooptaeedeg tqc ltaslvmi gssne  r ianT tixh a"

    const-string/jumbo p0, "ilo ra.tq a posesigirege ltamr T ntevadttx  enescotaefh"

    const/4 v10, 0x0

    const-string/jumbo p0, "n i envpaexaapm  oethrlr redotiiaege tftgo  .Tdlatsscts"

    const-string/jumbo p0, "the parameter context or tags of deleteTags is invalid."

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    return-void
.end method

.method public static delTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/tencent/android/tpush/XGIOperateCallback;",
            ")V"
        }
    .end annotation

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x1

    const-string v0, "aTeedgltqe"

    const-string v0, "aTsgeeldte"

    const/4 v10, 0x5

    const-string v0, "etseaedglT"

    const-string v0, "deleteTags"

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/Set;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x0

    const-string v0, "MmamnXagPehsr"

    const-string v0, "garmMPaesXhGn"

    const/4 v10, 0x0

    const-string v0, "anrsogMXaPuGh"

    const-string v0, "XGPushManager"

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eqz p0, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x6

    if-eqz p2, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x4

    invoke-interface {p2}, Ljava/util/Set;->isEmpty()Z

    move-result p2

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x1

    if-nez p2, :cond_1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    if-eqz p2, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x7

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-string v1, "atasotie  a -gltde>tT  T=l sheggwleass"

    const/4 v10, 0x3

    const-string v1, "Tsa  be gdt >ah Tste=g slts aiwgl-alet"

    const-string v1, "deleteTags -> setTags with all tags = "

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v3, 0x0

    const/4 v10, 0x7

    const/4 v3, 0x7

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v10, 0x2

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v10, 0x7

    const/4 v6, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v8, p3

    move-object v8, p3

    move-object v8, p3

    move-object v8, p3

    const/4 v10, 0x0

    const/4 v9, 0x7

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v10, 0x5

    const/4 v9, 0x1

    return-void

    :cond_1
    :goto_0
    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string p1, "at ch ubla esrert amvolidrfes gnsx.eneogoaeiattpd t e T"

    const-string/jumbo p1, "og etbotefea xe ieTr rtpdn gaescleaa.rvost tash m itdln"

    const/4 v10, 0x1

    const-string/jumbo p1, "tiatld prltven riees opgaoTmtstxena ah atsice.dg  oer f"

    const-string/jumbo p1, "the parameter context or tags of deleteTags is invalid."

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    if-eqz p0, :cond_2

    const/4 v9, 0x1

    move v10, v9

    if-eqz p3, :cond_2

    const/4 v9, 0x2

    move v10, v9

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_TAG:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    const-string p2, ""

    const-string p2, ""

    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-interface {p3, p2, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    return-void
.end method

.method public static deleteKeyValueTag(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 11

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    const-string v0, "PXMarusGqhneg"

    const-string v0, "eMXgaGuPasrnh"

    const/4 v10, 0x0

    const-string/jumbo v0, "ugsGeMPrahsXn"

    const-string v0, "XGPushManager"

    const/4 v10, 0x5

    if-eqz p0, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    if-eqz p1, :cond_1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-nez v1, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    goto :goto_0

    :cond_0
    const/4 v10, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x6

    const-string p1, "::::"

    const-string p1, "::::"

    const/4 v10, 0x7

    const-string p1, "::::"

    const-string p1, "::::"

    const/4 v10, 0x1

    const/4 v9, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    const-string p2, "alemtAw et = naiyehKgT-i cp> Vt luaetdg"

    const-string p2, " ihKauVpgw tta=Teg   ie-adAne llty>cete"

    const/4 v10, 0x6

    const-string p2, "-uA>oya = totlingcVdK Tetaaeetiew  heg "

    const-string p2, "Action -> deleteKeyValueTag with tag = "

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    const/4 v4, 0x4

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, v8

    move-object v3, v8

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-static/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    return-void

    :cond_1
    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-string/jumbo p0, "inelabea Knelc tTde.teV ova iygdqerelgtyotxK"

    const-string p0, "aneeKKetq ioladltVie  redoaenTlyyet v.gguxct"

    const/4 v10, 0x7

    const-string/jumbo p0, "llytgnuivexecaoaKynerT giutt. leaedeKo tade "

    const-string p0, "deleteKeyValueTag context or tagKey invalid."

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    return-void
.end method

.method public static deleteTag(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/XGPushManager;->delTag(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public static deleteTag(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->delTag(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x5

    return-void
.end method

.method public static deleteTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->delTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public static deleteTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/tencent/android/tpush/XGIOperateCallback;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/android/tpush/XGPushManager;->delTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method private static e(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz p2, :cond_0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$13;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, p2}, Lcom/tencent/android/tpush/XGPushManager$13;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    new-instance p2, Landroid/content/IntentFilter;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo v1, "pxs..eeA.ic.nnCr.mNV.Uov.Tnid4ROdatLaUgcnicEoCtotTS"

    const/4 v3, 0x2

    const-string/jumbo v1, "xAemT.TpUt...raVoLOccaEi.NCoiRdntng.eSovCtiU4dnp..n"

    const-string v1, "com.tencent.android.xg.vip.action.ACCOUNT.RESULT.V4"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p2, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    const/4 v1, 0x4

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-static {p0, v0, p2, v1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :catchall_0
    move-exception p2

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string v1, "ene sveiqueartoergrMaccrRtrremrin agc "

    const-string v1, "Rtrm Miingrn rrveraeegeroc suaeatccroe"

    const/4 v3, 0x4

    const-string v1, "e s gavrcrcReerearriaetrsoet uenMrocng"

    const-string v1, "accountManager registerReceiver error "

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p2}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v0, "MugmrXPhosnaG"

    const-string/jumbo v0, "sarGoXgMPnuah"

    const/4 v3, 0x1

    const-string v0, "aePuoMaXnGsrg"

    const-string v0, "XGPushManager"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void
.end method

.method private static e()Z
    .locals 8

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    sget-object v2, Lcom/tencent/android/tpush/XGPushManager;->f:Ljava/util/Queue;

    const/4 v7, 0x4

    const/4 v6, 0x4

    if-nez v2, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    new-instance v2, Ljava/util/concurrent/ConcurrentLinkedQueue;

    const/4 v7, 0x0

    invoke-direct {v2}, Ljava/util/concurrent/ConcurrentLinkedQueue;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    sput-object v2, Lcom/tencent/android/tpush/XGPushManager;->f:Ljava/util/Queue;

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    sget-object v2, Lcom/tencent/android/tpush/XGPushManager;->f:Ljava/util/Queue;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-interface {v2}, Ljava/util/Collection;->size()I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/16 v3, 0xa

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-ge v2, v3, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget-object v2, Lcom/tencent/android/tpush/XGPushManager;->f:Ljava/util/Queue;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-interface {v2, v0}, Ljava/util/Queue;->offer(Ljava/lang/Object;)Z

    const/4 v6, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto/16 :goto_0

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    sget-object v2, Lcom/tencent/android/tpush/XGPushManager;->f:Ljava/util/Queue;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-interface {v2}, Ljava/util/Queue;->peek()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    check-cast v2, Ljava/lang/Long;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    sub-long v2, v0, v2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-wide/16 v4, 0x2710

    const-wide/16 v4, 0x2710

    const/4 v7, 0x3

    const-wide/16 v4, 0x2710

    const-wide/16 v4, 0x2710

    const/4 v6, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    cmp-long v2, v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    if-gez v2, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    const/4 v0, 0x1

    const/4 v6, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    return v0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    sget-object v2, Lcom/tencent/android/tpush/XGPushManager;->f:Ljava/util/Queue;

    const/4 v7, 0x3

    const/4 v6, 0x0

    invoke-interface {v2}, Ljava/util/Queue;->poll()Ljava/lang/Object;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget-object v2, Lcom/tencent/android/tpush/XGPushManager;->f:Ljava/util/Queue;

    const/4 v6, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-interface {v2, v0}, Ljava/util/Queue;->offer(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string/jumbo v2, "mpr ibertie iaaLrb:o"

    const-string/jumbo v2, "rireeb oRiia :mptLar"

    const-string v2, "RitterurraiLei p:aom"

    const-string v2, "apiRateLimit error: "

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string v1, "ePasuGXpaMunr"

    const-string v1, "MGPsuXuaenarh"

    const/4 v7, 0x0

    const-string v1, "XsenauahqGgPr"

    const-string v1, "XGPushManager"

    const/4 v7, 0x2

    const/4 v6, 0x7

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    const/4 v0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x1

    return v0
.end method

.method public static enableService(Landroid/content/Context;Z)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const-string v0, "apsuMPXGgrsen"

    const-string/jumbo v0, "sngXMuPpaGear"

    const/4 v4, 0x7

    const-string/jumbo v0, "uXrmsaMagGhnP"

    const-string v0, "XGPushManager"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-nez p1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->i(Landroid/content/Context;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v1, "ib doe.iaPNs lsT"

    const-string v1, "TPNS is disable."

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    move v4, v3

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->stopPushService(Landroid/content/Context;)V

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v2, "e=vnSbiqbcaree"

    const-string v2, "ebSavnerqeci=e"

    const/4 v4, 0x5

    const-string v2, "iaSenrubceve=e"

    const-string v2, "enableService="

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const-string v1, "e.neevapecbsri"

    const-string v1, "e.svaeSicbreen"

    const/4 v4, 0x3

    const-string/jumbo v1, "invceae.qlbeSe"

    const-string v1, ".enableService"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p0, v0, p1}, Lcom/tencent/tpns/baseapi/base/util/PushMd5Pref;->putInt(Landroid/content/Context;Ljava/lang/String;I)Z

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-void
.end method

.method private static declared-synchronized f(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 6

    const/4 v5, 0x5

    const-class v0, Lcom/tencent/android/tpush/XGPushManager;

    const-class v0, Lcom/tencent/android/tpush/XGPushManager;

    const/4 v5, 0x1

    const-class v0, Lcom/tencent/android/tpush/XGPushManager;

    const-class v0, Lcom/tencent/android/tpush/XGPushManager;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v1, "GMsgrXusmPana"

    const-string v1, "XnamrPMusgaGh"

    const/4 v5, 0x2

    const-string/jumbo v1, "unsmGraagXPhe"

    const-string v1, "XGPushManager"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v2, ">rocooteivNTtg Aos  Pseee -rRSti "

    const-string v2, "TseioetvtireAs r RNco- rPSg>e ot "

    const/4 v5, 0x4

    const-string v2, "eTinib oeASr etNos->cRt vgt  sreP"

    const-string v2, "Action -> Register to TPNS server"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-eqz p2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz p1, :cond_0

    :try_start_1
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v2, "blekkBuoCdlaacn"

    const-string v2, "alkklbeanoCBdic"

    const/4 v5, 0x2

    const-string v2, "ColkkncpaadievB"

    const-string/jumbo v2, "invokedCallBack"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1, v2, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v2, Lcom/tencent/android/tpush/XGPushManager$25;

    const/4 v5, 0x6

    invoke-direct {v2, p2, v1}, Lcom/tencent/android/tpush/XGPushManager$25;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;Z)V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance p2, Landroid/content/IntentFilter;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v1, "SE.d.nVcqte4tG..gEiLTUEnS.odc.IriRmvtnnRaxop.aue.Ric"

    const-string/jumbo v1, "oad4tcurnnGt.idRSnTESo.ecnITREv..EiiVRaxgept.c..L.Um"

    const/4 v5, 0x7

    const-string v1, "..sdvRRcSVn.4drG.ocTiSE.pnex.m.ganIniEocTtRiEUeat.oL"

    const-string v1, "com.tencent.android.xg.vip.action.REGISTER.RESULT.V4"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {p2, v1}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {p0, v2, p2, v1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :catchall_0
    move-exception p2

    :try_start_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo v1, "rhnmXspgaMuGP"

    const-string v1, "XugsManphGPra"

    const/4 v5, 0x7

    const-string v1, "XGPushManager"

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo v3, "sieioereeeosR gcreteirrretrgrv r"

    const-string/jumbo v3, "register registerReceiver error "

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p2}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-virtual {v2, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    monitor-exit v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void

    :catchall_1
    move-exception p0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    monitor-exit v0

    const/4 v4, 0x5

    and-int/2addr v5, v4

    throw p0
.end method

.method private static g(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v0, "PaXahbuesnMqg"

    const-string/jumbo v0, "usaXeMhnqgarP"

    const/4 v4, 0x4

    const-string v0, "XGeMhPuusnaga"

    const-string v0, "XGPushManager"

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const-string v1, "eP ecoeptUi sS-rot ANrn nir etvgsrT"

    const-string/jumbo v1, "ois T ite n ogev>rnscNUr-rrSeA tetP"

    const/4 v4, 0x0

    const-string/jumbo v1, "tetASP >qcUrvon tiTng riroess-eer N"

    const-string v1, "Action -> Unregister to TPNS server"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v1, Lcom/tencent/android/tpush/XGPushManager$26;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v1, p2}, Lcom/tencent/android/tpush/XGPushManager$26;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance p2, Landroid/content/IntentFilter;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v2, ".dsESonxectLtTeig.iaTE..m.n.rvU.GmRVpc4nnaNdootRcS.REi"

    const-string/jumbo v2, "xEUmnpcUntTndaRT..iicmLE.gite.v.a.r4oScGoRVRdNneS.t.Eo"

    const/4 v4, 0x3

    const-string v2, "iSdmcEdoEn..ctiTnvgReac.GoLotVU.iRra.TSe.InpNmnU.Ex4.R"

    const-string v2, "com.tencent.android.xg.vip.action.UNREGISTER.RESULT.V4"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-direct {p2, v2}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x4

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p0, v1, p2, v2}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V

    const/4 v3, 0x3

    move v4, v3

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    move v4, v3

    const-string p2, " eseoreenvrroroet euirggr irecrstR"

    const-string p2, " ergosrreeeeort etc vugerrsRriinri"

    const/4 v4, 0x6

    const-string/jumbo p2, "itre becetreeersvsge Riniu grrrorr"

    const-string/jumbo p2, "unregister registerReceiver error "

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void
.end method

.method public static getConnectState(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 8

    const/4 v7, 0x5

    const-string v0, "bsuarXuehGnMg"

    const-string v0, "PGnMebsurhagX"

    const/4 v7, 0x7

    const-string/jumbo v0, "uMrseahpgnaPX"

    const-string v0, "XGPushManager"

    const/4 v7, 0x7

    const/4 v6, 0x7

    if-nez p1, :cond_0

    const-string p0, "Xer ruaTqpll!n tOCIrneaceGmaaec a pub a tlenbklho"

    const-string p0, "a!l X umh pll er aeeTkaarbItpaeOoCenua tnnrcblGct"

    const/4 v7, 0x0

    const-string p0, "hrselaCn purGtabIoeaeeXn ln lkrTaatm !etc  cpeOba"

    const-string p0, "The XGIOperateCallback parameter can not be null!"

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x4

    return-void

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-nez p0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    sget p0, Lcom/tencent/android/tpush/XGPushManager;->CONNECT_STATE_DEFAULT:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    sget-object v0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_LOGIC_ILLEGAL_ARGUMENT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string/jumbo v1, "tcrmelaT  anl ncmhto nurae tpx epnteb!"

    const-string v1, " oenlapprbo elnnehr t muxea tt!nc ctaT"

    const/4 v7, 0x1

    const-string v1, "etrbonn  Taxunttrlen  l cchetoeemaa !o"

    const-string v1, "The context parameter can not be null!"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-interface {p1, p0, v0, v1}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-void

    :cond_1
    :try_start_0
    const/4 v6, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->e()Z

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v1, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    sget p0, Lcom/tencent/android/tpush/XGPushManager;->CONNECT_STATE_DEFAULT:I

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    sget-object v1, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SDK_API_FREQUENCY_LIMIT_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v1}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-interface {p1, p0, v2, v1}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    return-void

    :cond_2
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/NetworkUtil;->isNetworkConnected(Landroid/content/Context;)Z

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x2

    if-nez v1, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    sget p0, Lcom/tencent/android/tpush/XGPushManager;->CONNECT_STATE_DEFAULT:I

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    sget-object v1, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_UNREACHABLE:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v7, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string/jumbo v2, "rtcceba wekplansni  eok,gah!oq "

    const-string v2, "eiorgh nqaa sc,onnkl!ekp e cwat"

    const/4 v7, 0x1

    const-string/jumbo v2, "seioeouace hna nknw, arp !ekltc"

    const-string/jumbo v2, "no network, please check again!"

    const/4 v7, 0x0

    const/4 v6, 0x7

    invoke-interface {p1, p0, v1, v2}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    const/4 v7, 0x3

    return-void

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->i(Landroid/content/Context;)Z

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 v2, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-nez v1, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-string p0, "etsaafebeCgsni.tt SUeaelllsStrcnnEv etioie"

    const/4 v7, 0x3

    const-string p0, "cna evtpUrlilsettCtnnet.eeeiSsoEalSa igbce"

    const-string p0, "getConnectState Util.isEnableService false"

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    sget p0, Lcom/tencent/android/tpush/XGPushManager;->CONNECT_STATE_NOT_CONNECTED:I

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-interface {p1, p0, v2}, Lcom/tencent/android/tpush/XGIOperateCallback;->onSuccess(Ljava/lang/Object;I)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    return-void

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->c(Landroid/content/Context;)I

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->a()Z

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x0

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const-string/jumbo v5, "viatcuteqs:mrS"

    const-string v5, "acumitSrt:vess"

    const/4 v7, 0x1

    const-string v5, "ersictsta:ueSv"

    const-string/jumbo v5, "serviceStatus:"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v5, ":H,mB addoes is"

    const-string v5, " H,:oeiBsd sadi"

    const/4 v7, 0x4

    const-string v5, ", isHasBinded: "

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    move v7, v6

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v0, v4}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    const/4 v4, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-ne v1, v4, :cond_5

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v3, :cond_5

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance v1, Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    const-string v2, "SoVdebCt..xnEEccNtTE4gCTAOictK.dapnn.oi.oNTmCCn.r_a_Hei."

    const/4 v7, 0x5

    const-string/jumbo v2, "oT_4o.r.OKdCniEnvcAtNHnmtCSe.edaTcico.iV.E_EgnTCCot.p.Nx"

    const-string v2, "com.tencent.android.xg.vip.action.CHECK_CONNECT_STATE.V4"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    new-instance v2, Lcom/tencent/android/tpush/XGPushManager$1;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {v2, p1}, Lcom/tencent/android/tpush/XGPushManager$1;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    new-instance p1, Landroid/content/IntentFilter;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string v3, "cET.NbmSt.THVtC._.eNtdErCcpnxn.nuUKE.aTd.RoiiCigocv.SC4LT_AnaOE"

    const-string v3, "Ha.e.outTNVnOTitEC.oLcomESC.iAdS_ax.rpnnticcCnN.E.UR4TE.C_gvTdK"

    const/4 v7, 0x1

    const-string v3, "..doLguESm.TcUEe.nndacEcCCpCnCiO4VNraoTivt.ot.NA_Ee.TT_iKxnSt.R"

    const-string v3, "com.tencent.android.xg.vip.action.CHECK_CONNECT_STATE.RESULT.V4"

    const/4 v6, 0x3

    xor-int/2addr v7, v6

    invoke-direct {p1, v3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v3, 0x4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static {p0, v2, p1, v3}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string/jumbo p1, "taorcaopCt stnaSedptsBeteecgn"

    const-string/jumbo p1, "s tSBenpranettcanoaeogtCdcste"

    const/4 v7, 0x4

    const-string p1, "geros tdqsncdtetaotBcaCStenea"

    const-string p1, "getConnectState sendBroadcast"

    const/4 v6, 0x2

    shr-int/2addr v7, v6

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {p0, v1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_0

    :cond_5
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    sget p0, Lcom/tencent/android/tpush/XGPushManager;->CONNECT_STATE_NOT_CONNECTED:I

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-interface {p1, p0, v2}, Lcom/tencent/android/tpush/XGIOperateCallback;->onSuccess(Ljava/lang/Object;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v7, 0x4

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v6, 0x3

    const-string v1, "SqsratttroenCgee nco:te"

    const-string/jumbo v1, "t Seoenoqat g:cCetetrrn"

    const/4 v7, 0x0

    const-string v1, "an merCgS rnoetrt:tetce"

    const-string v1, "getConnectState error: "

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-void
.end method

.method public static getContext()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/XGPushManager;->b:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x4

    return-object v0
.end method

.method public static getCustomContentFromIntent(Landroid/content/Context;Landroid/content/Intent;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x4

    const/4 v3, 0x2

    const-string v1, "XahMoasrseuGg"

    const-string v1, "eusMGXarsaghn"

    const/4 v4, 0x6

    const-string v1, "PuehrbaXaMsgG"

    const-string v1, "XGPushManager"

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    instance-of p0, p0, Landroid/app/Activity;

    const/4 v4, 0x4

    if-nez p0, :cond_0

    const/4 v4, 0x0

    const-string/jumbo p0, "rrectiutFsolototuai t pe tnt eCocvoym stteuAieun taxm nndtgeIoirehttsemoe gnohh,sactnrht prnt nsctCCmomnrl ee"

    const-string p0, " xrmtuatontte tCintea roc ucee,emettIstsnAhmni cC nrtmpn reteo tutg ehosnmnhchtltonpog otiee FtrildovsCtoasyr"

    const/4 v4, 0x4

    const-string/jumbo p0, "mcstpn potntoeseilmg,td   oi xoncuotaetCtrrrec tFntilosAet aylrte iuto hpvmhtueCegr masrnnettntCtest oehnnoch"

    const-string p0, "getCustomContentFromIntent parse intent customContent error, please call this method through Activity context"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object v0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez p1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const-string/jumbo p0, "ptts eCuqi ntsntot nec tmotntpoooetro,nroClnremnrlFu trIrstn gamueeCsenntiee n"

    const-string/jumbo p0, "tgsCoFeI,eertorretomrtnt t uoanpn loctttinmsrsn tenC  npsunt tumarnoiCeoeenlen"

    const/4 v4, 0x0

    const-string p0, "getCustomContentFromIntent parse intent customContent error, parse null intent"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x3

    return-object v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo p0, "tmsobuccon_etn"

    const-string/jumbo p0, "out_tbcnmtcnoe"

    const/4 v4, 0x7

    const-string/jumbo p0, "oeommctttn_csu"

    const-string p0, "custom_content"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1, p0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x2

    if-eqz v2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz p1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo p0, "tontemucsnotC"

    const/4 v4, 0x3

    const-string/jumbo p0, "ncsuotoemntto"

    const-string p0, "customContent"

    const/4 v4, 0x2

    invoke-virtual {p1, p0}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo p1, "urntobrr agostee ttscn nmCutmntotnpeernop etoo:iFIe neCtnCrts"

    const-string/jumbo p1, "m tIonnptmCous eFneCtoCnnotttterta:mgr rupctsri oent rsnoneee"

    const/4 v4, 0x7

    const-string p1, " rnIurutrenCtemtCetFe otnttmornesn:pet nsiguConeotosratm  oct"

    const-string p1, "getCustomContentFromIntent parse intent customContent error: "

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {v1, p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-object v0
.end method

.method public static getDefaultNotificationBuilder(Landroid/content/Context;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/XGPushManager;->getNotificationBuilder(Landroid/content/Context;I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public static getNotifactionCallback()Lcom/tencent/android/tpush/XGPushNotifactionCallback;
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/android/tpush/XGPushManager;->g:Lcom/tencent/android/tpush/XGPushNotifactionCallback;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public static getNotificationBuilder(Landroid/content/Context;I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    if-nez p0, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    const-string p0, "hsaaPueprnXMG"

    const-string p0, "XGPushManager"

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    const-string/jumbo p1, "tult l= qioncBtnefineat uit d=oegrNxiol"

    const-string p1, "getNotificationBuilder  context == null"

    const/4 v1, 0x0

    const/4 v0, 0x5

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    const/4 p0, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-object p0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method

.method public static getServiceTag(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/security/Security;->checkTpnsSecurityLibSo(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo v1, "lisa_ergecbeqnxs_"

    const-string v1, "clr_ex_vqanibeges"

    const/4 v5, 0x5

    const-string/jumbo v1, "vgem_nlxeebrec_is"

    const-string/jumbo v1, "xg_service_enable"

    const/4 v5, 0x7

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    return-object v1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string p0, ","

    const-string p0, ","

    const/4 v5, 0x5

    const-string p0, ","

    const-string p0, ","

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-object p0
.end method

.method public static getSysNotifactionCallback()Lcom/tencent/android/tpush/XGSysPushNotifactionCallback;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    sget-object v0, Lcom/tencent/android/tpush/XGPushManager;->h:Lcom/tencent/android/tpush/XGSysPushNotifactionCallback;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public static initCommonComponents(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$18;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/XGPushManager$18;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method public static isNotificationOpened(Landroid/content/Context;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/c;->a(Landroid/content/Context;)Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x4

    return p0
.end method

.method public static loadOtherPushToken(Landroid/content/Context;ZJ)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string v0, "aGrXosMnhsePg"

    const-string/jumbo v0, "sgsanGhrMXeuP"

    const-string/jumbo v0, "sraeabMunhXPg"

    const-string v0, "XGPushManager"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "rcetetuasn  mhepsr ta nehrlr!gu hts"

    const-string v1, "huhm at!rtiesh slcerpe n rtrnt egas"

    const/4 v3, 0x5

    const-string/jumbo v1, "start other push channel register !"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpush/d/d;->p()V

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpush/d/d;->m()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpush/d/d;->c()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpush/d/d;->d()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-eqz p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p0, p2, p3}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush(Landroid/content/Context;)Z

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz p2, :cond_0

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportTokenFailed(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-object p1

    :catchall_0
    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object p0
.end method

.method public static logger(ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->addThirdLog(ILjava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public static msgAck(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-eqz p0, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x2

    if-eqz p1, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-string v1, "- i cmAp(g>Aotokc"

    const-string v1, "c- Aoot ms(ik>cgA"

    const/4 v9, 0x0

    const-string v1, "->gcnA (qcAotmski"

    const-string v1, "Action -> msgAck("

    const/4 v9, 0x4

    const/4 v8, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-string v2, ","

    const-string v2, ","

    const/4 v9, 0x3

    const-string v2, ","

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v3

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string v3, ")"

    const-string v3, ")"

    const/4 v8, 0x4

    move v9, v8

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string/jumbo v3, "uasXMgrsbenha"

    const-string/jumbo v3, "nMaPabXesughr"

    const/4 v9, 0x3

    const-string v3, "PhGmMaasrueng"

    const-string v3, "XGPushManager"

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v4

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    cmp-long v0, v4, v6

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-lez v0, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v5

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v0, p0, v4, v5, v6}, Lcom/tencent/android/tpush/message/MessageManager;->getMsgId(Landroid/content/Context;Ljava/lang/String;J)Lcom/tencent/android/tpush/data/MessageId;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-nez v0, :cond_0

    const/4 v8, 0x6

    const/4 v9, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    const-string p0, " douo)rre,ot n:hie "

    const-string/jumbo p0, "r th rue:on) oed ,i"

    const/4 v9, 0x0

    const-string/jumbo p0, "rdoeebi,)rn : orht "

    const-string p0, ")error, no the id: "

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide p0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v0, p0, p1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    return-void

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    new-instance v1, Landroid/content/Intent;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x6

    const/4 v8, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-string v3, "ConaAMu.nr.Ko_.VSG.doincdpvac4ptiigtxmecn..e"

    const-string v3, "dno.nSxp4mgaoctMv.oiit.rVaitdcnGA..nCcKpee._"

    const/4 v9, 0x4

    const-string/jumbo v3, "n.tr.Anpi.mvoxtdKo.V_cpSoGnMdne.t.4ccgCaeaii"

    const-string v3, "com.tencent.android.xg.vip.action.MSG_ACK.V4"

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x4

    const-string v2, "gsdqq"

    const-string v2, "gdIqs"

    const/4 v9, 0x3

    const-string/jumbo v2, "mgssd"

    const-string/jumbo v2, "msgId"

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v3

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v1, v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-string/jumbo v2, "paemsNam"

    const-string v2, "ecsNpama"

    const/4 v9, 0x1

    const-string v2, "akamoecN"

    const-string/jumbo v2, "packName"

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-string v2, "geIsabmes"

    const-string/jumbo v2, "seemgMsIa"

    const/4 v9, 0x1

    const-string v2, "esgesMuaI"

    const-string v2, "MessageId"

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string/jumbo v0, "odacin_pln"

    const-string v0, "_inhoalcdn"

    const/4 v9, 0x7

    const-string/jumbo v0, "l_naicdhqe"

    const-string v0, "channel_id"

    const/4 v8, 0x4

    move v9, v8

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getChannelId()J

    move-result-wide v2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v1, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {p0, v1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    return-void
.end method

.method public static onActivityStarted(Landroid/app/Activity;)Lcom/tencent/android/tpush/XGPushClickedResult;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string v0, "NpsubFhOC.I.Ittas"

    const-string v0, "Oh..ubNCTIastFIpt"

    const/4 v5, 0x1

    const-string v0, "IpamTIts.NuOF.Chg"

    const-string/jumbo v0, "tag.tpush.NOTIFIC"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo v2, "tiAvo >cu>t>odeS ttiay"

    const-string v2, "a i>>vu Aio>etcSytdrtt"

    const/4 v5, 0x3

    const-string v2, ">>rtabn>AStviico tdte "

    const-string v2, ">>> onActivityStarted "

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    move v5, v4

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string v2, "MnrhXpuueGaag"

    const-string/jumbo v2, "raanXgPphMeGu"

    const/4 v5, 0x0

    const-string/jumbo v2, "ranMahXpGuPsg"

    const-string v2, "XGPushManager"

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz p0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->i(Landroid/content/Context;)Z

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x0

    if-nez v3, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz p0, :cond_1

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p0, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v3, :cond_1

    const/4 v5, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Intent;->getSerializableExtra(Ljava/lang/String;)Ljava/io/Serializable;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    if-eqz v3, :cond_1

    const/4 v4, 0x3

    const/4 v4, 0x0

    instance-of v0, v3, Lcom/tencent/android/tpush/XGPushClickedResult;

    const/4 v4, 0x1

    and-int/2addr v5, v4

    if-eqz v0, :cond_1

    const/4 v5, 0x7

    check-cast v3, Lcom/tencent/android/tpush/XGPushClickedResult;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v3, p0}, Lcom/tencent/android/tpush/XGPushClickedResult;->parseIntent(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-object v3

    :catchall_0
    move-exception p0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string/jumbo v0, "yovtndSrqAicetait"

    const-string/jumbo v0, "onActivityStarted"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v2, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-object v1
.end method

.method public static onActivityStoped(Landroid/app/Activity;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static onEvent(Landroid/content/Context;Ljava/lang/String;Ljava/util/Properties;)V
    .locals 2

    const/4 v1, 0x7

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportCustomData(Landroid/content/Context;Ljava/lang/String;Ljava/util/Properties;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method public static onMessageCleared(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushTextMessage;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/XGPushTextMessage;->a()Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string/jumbo v0, "nasLt.c.vLeatD.LUxEeUH.SdipciAonCNtcn.P_ogr.d4.ESRTnoqmE.C"

    const-string v0, ".4xCngDaqc.tP.iESteEdo.oLmSiTHi.ECnU.RUctdcoNnLLnp_ev.Ara."

    const/4 v2, 0x6

    const-string v0, "EUcmgoatRt.tTiCceE.So.eimcU4LNd.nvnPi_LAd.oC.ra.xLHpDV.nnE"

    const-string v0, "com.tencent.android.xg.vip.action.PUSH_CANCELLED.RESULT.V4"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Landroid/content/Intent;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public static onMessageClicked(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushTextMessage;)V
    .locals 3

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/tencent/android/tpush/XGPushTextMessage;->a()Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, "dKsUcRnS.U.ox.PpgnmocIct4VnirCaLvL.ndTE.Haetot..ii.CS_"

    const-string v0, "SIn_o.vx.Eo.ceonerCaH.KtUcTtVL.i.ULinS..ocgPndC4apiRtm"

    const-string v0, "com.tencent.android.xg.vip.action.PUSH_CLICK.RESULT.V4"

    const/4 v2, 0x1

    const/4 v1, 0x2

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Landroid/content/Intent;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public static onOtherPushRegister(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-string v0, "arMGebXgnsumh"

    const-string v0, "GagmrXsunaMeh"

    const/4 v3, 0x4

    const-string v0, "MPrsXuugnaeah"

    const-string v0, "XGPushManager"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v1, "uthirRtpsoePrsOhgon"

    const-string/jumbo v1, "rehooPhgORertntssiu"

    const-string/jumbo v1, "nhstgothqrPseurieRe"

    const-string/jumbo v1, "onOtherPushRegister"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    shr-int/2addr v3, v2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v1, Lcom/tencent/android/tpush/XGPushManager$29;

    const/4 v3, 0x6

    invoke-direct {v1, p1, p0}, Lcom/tencent/android/tpush/XGPushManager$29;-><init>(Landroid/content/Intent;Landroid/content/Context;)V

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method public static openNotification(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->j(Landroid/content/Context;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method public static openNotificationSettings(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->k(Landroid/content/Context;)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public static queryTags(Landroid/content/Context;Ljava/lang/String;IILcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string v0, "aasurbXgGesnh"

    const-string v0, "guGXabasnrhMe"

    const-string v0, "GnrmesMaPXuah"

    const-string v0, "XGPushManager"

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz p0, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x4

    if-ltz p2, :cond_2

    const/4 v7, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    if-gtz p3, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    goto :goto_1

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-string v1, " su oouqaA>cTeyrgin"

    const-string v1, "Ti cyeu-og nuaqA>sr"

    const/4 v8, 0x4

    const-string v1, "c>aAnbtguie- Trqyso"

    const-string v1, "Action -> queryTags"

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;)Z

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-eqz v0, :cond_1

    const/4 v8, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->i(Landroid/content/Context;)Z

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz v0, :cond_1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v4, 0x0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    move v2, p2

    move v2, p2

    const/4 v8, 0x7

    move v2, p2

    move v2, p2

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    move v3, p3

    move v3, p3

    const/4 v8, 0x4

    move v3, p3

    move v3, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static/range {v0 .. v5}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto :goto_0

    :cond_1
    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance v6, Lcom/tencent/android/tpush/XGPushManager$5;

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    move v3, p2

    move v3, p2

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    move v4, p3

    move v4, p3

    const/4 v8, 0x7

    move v4, p3

    move v4, p3

    move-object v5, p4

    move-object v5, p4

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-direct/range {v0 .. v5}, Lcom/tencent/android/tpush/XGPushManager$5;-><init>(Landroid/content/Context;Ljava/lang/String;IILcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v8, 0x0

    invoke-static {p0, v6}, Lcom/tencent/android/tpush/XGPushManager;->registerPush(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    return-void

    :cond_2
    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-string v1, "hoeeciupn  e  ntgr  dtasrpgi aTa asfxeldtme.rosvetioaet"

    const-string/jumbo v1, "tdpr inpoexmsnhvagcoeifeTs .eta  tdaret i tagasleo l er"

    const/4 v8, 0x3

    const-string/jumbo v1, "the parameter context or tags of deleteTags is invalid."

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x4

    if-eqz p0, :cond_3

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-eqz p4, :cond_3

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    sget-object v0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_QUERYTAGS:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v8, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v0

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    sget-object v1, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_TAG:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v1}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v8, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-interface {p4, v2, v0, v1}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_3
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    return-void
.end method

.method public static queryTags(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 9

    const/4 v8, 0x3

    if-eqz p0, :cond_2

    const/4 v8, 0x4

    if-ltz p2, :cond_2

    const/4 v8, 0x4

    if-gtz p3, :cond_0

    const/4 v8, 0x2

    goto :goto_1

    :cond_0
    const/4 v8, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;)Z

    move-result v0

    const/4 v8, 0x3

    if-eqz v0, :cond_1

    const/4 v8, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->i(Landroid/content/Context;)Z

    move-result v0

    const/4 v8, 0x7

    if-eqz v0, :cond_1

    const/4 v8, 0x5

    invoke-static/range {p0 .. p5}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v8, 0x2

    goto :goto_0

    :cond_1
    const/4 v8, 0x5

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$6;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v8, 0x0

    move v4, p2

    move v4, p2

    const/4 v8, 0x3

    move v5, p3

    move v5, p3

    move v5, p3

    move v5, p3

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-object v6, p4

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    move-object v7, p5

    const/4 v8, 0x4

    invoke-direct/range {v1 .. v7}, Lcom/tencent/android/tpush/XGPushManager$6;-><init>(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v8, 0x6

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/XGPushManager;->registerPush(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    :goto_0
    return-void

    :cond_2
    :goto_1
    const/4 v8, 0x7

    const-string/jumbo p1, "rnXhPGgpMause"

    const-string p1, "XGPushManager"

    const/4 v8, 0x2

    const-string p2, "ddogtv  qa mioee reeTcpetso rfs anietrtsa lntaailtqghx."

    const-string/jumbo p2, "o.re traqt sarlvnet etgtei i eemdpaaln sahsTodxfgteo ic"

    const-string p2, "ces leetesvt peo  nnaartds.  tisrrtit gliTfmaxahdoa goe"

    const-string/jumbo p2, "the parameter context or tags of deleteTags is invalid."

    const/4 v8, 0x4

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x1

    if-eqz p0, :cond_3

    const/4 v8, 0x3

    if-eqz p5, :cond_3

    const/4 v8, 0x5

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_QUERYTAGS:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v8, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p0

    const/4 v8, 0x5

    sget-object p1, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_TAG:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v8, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const-string p2, ""

    const-string p2, ""

    const-string p2, ""

    const-string p2, ""

    const/4 v8, 0x1

    invoke-interface {p5, p2, p0, p1}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_3
    const/4 v8, 0x0

    return-void
.end method

.method public static registerPush(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$12;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGPushManager$12;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/XGPushManager;->registerPush(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v2, 0x4

    return-void
.end method

.method public static registerPush(Landroid/content/Context;JLcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 13

    if-eqz p3, :cond_0

    const/4 v1, 0x0

    const/4 v2, -0x1

    const/4 v3, 0x0

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    move-wide v11, p1

    invoke-static/range {v0 .. v12}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    return-void

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string v1, "  Tmeculht nmnecbrln a!e seartap llaboc"

    const-string v1, "Tus emll  acnblclrepte  nkebtcaar ah!on"

    const-string/jumbo v1, "nnb occbceh kana tl!euoe  taTaa rlpmrel"

    const-string v1, "The callback parameter can not be null!"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static registerPush(Landroid/content/Context;JLcom/tencent/android/tpush/XGPushManager$AccountInfo;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 13

    move-object/from16 v0, p3

    move-object/from16 v0, p3

    move-object/from16 v0, p3

    move-object/from16 v0, p3

    if-eqz p4, :cond_1

    if-eqz v0, :cond_0

    iget-object v1, v0, Lcom/tencent/android/tpush/XGPushManager$AccountInfo;->accountName:Ljava/lang/String;

    iget v0, v0, Lcom/tencent/android/tpush/XGPushManager$AccountInfo;->accountType:I

    move v2, v0

    move v2, v0

    move v2, v0

    move v2, v0

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    const/4 v1, -0x1

    move v2, v1

    move v2, v1

    move v2, v1

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_0
    const/4 v3, 0x0

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object/from16 v4, p4

    move-object/from16 v4, p4

    move-object/from16 v4, p4

    move-object/from16 v4, p4

    move-wide v11, p1

    invoke-static/range {v0 .. v12}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    return-void

    :cond_1
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo v1, "ue ! blcaaanratlktbm earmcc hp oTe nbll"

    const-string/jumbo v1, "kbhmaallc otu mTe c la!ntlapner  ecbrna"

    const-string/jumbo v1, "nlerlrulutT aneacca tkbl bcpmh  a!een o"

    const-string v1, "The callback parameter can not be null!"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static registerPush(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 13

    if-eqz p1, :cond_0

    const/4 v1, 0x0

    const/4 v2, -0x1

    const/4 v3, 0x0

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    const-wide/16 v11, -0x1

    const-wide/16 v11, -0x1

    const-wide/16 v11, -0x1

    const-wide/16 v11, -0x1

    move-object v0, p0

    move-object v0, p0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    invoke-static/range {v0 .. v12}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    return-void

    :cond_0
    new-instance p0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo p1, "rle nabpclnltlaa hmectorekp!ou c T na a"

    const-string p1, "abcpoaoennat lbt!ueal hlnmk a  rcTlc er"

    const-string p1, " clkracnqrmlanhl  eeabe !nutopacelab tT"

    const-string p1, "The callback parameter can not be null!"

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p0
.end method

.method public static registerPush(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 13

    if-eqz p4, :cond_0

    const/4 v1, 0x0

    const/4 v2, -0x1

    const/4 v3, 0x0

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v7, 0x0

    const-wide/16 v11, -0x1

    const-wide/16 v11, -0x1

    const-wide/16 v11, -0x1

    move-object v0, p0

    move-object v0, p0

    move-object/from16 v4, p4

    move-object/from16 v4, p4

    move-object/from16 v4, p4

    move-object/from16 v4, p4

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v9, p2

    move-object v9, p2

    move-object v9, p2

    move-object v9, p2

    move-object/from16 v10, p3

    move-object/from16 v10, p3

    move-object/from16 v10, p3

    move-object/from16 v10, p3

    invoke-static/range {v0 .. v12}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    return-void

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo v1, "kuselpalTal hno !btra mbec r ccaenblan "

    const-string v1, "ea  bb c!ehte krnlnl plol cacmTnreabuaa"

    const-string/jumbo v1, "uaemkr laeltccln amarebp! abcT neo l hn"

    const-string v1, "The callback parameter can not be null!"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static reportTpnsInfoToBugly(Landroid/content/Context;)V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v9, 0x5

    const-class v0, Ljava/lang/String;

    const-class v0, Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string v1, "PsaXueuGgnrMh"

    const/4 v9, 0x2

    const-string v1, "XeProaMuhnagG"

    const-string v1, "XGPushManager"

    :try_start_0
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string v3, "FPOIpbTNS "

    const-string v3, "ONTINS pFP"

    const/4 v9, 0x3

    const-string v3, "IPF OTuNN "

    const-string v3, "TPNS INFO "

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const-string/jumbo p0, "ucop.orpnhos.teyulyce.Lrgcntb.mrltagqB"

    const-string/jumbo p0, "tcBotgnLq.yu.aoerpsnlbruhcmoe..gycltgr"

    const/4 v9, 0x1

    const-string/jumbo p0, "stg.g.blqogeotetunmoLnyeuychBrc.rr.apl"

    const-string p0, "com.tencent.bugly.crashreport.BuglyLog"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p0

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string v3, "i"

    const-string v3, "i"

    const/4 v9, 0x6

    const-string v3, "i"

    const-string v3, "i"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    const/4 v4, 0x2

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    new-array v5, v4, [Ljava/lang/Class;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    const/4 v6, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    aput-object v0, v5, v6

    const/4 v8, 0x6

    and-int/2addr v9, v8

    const/4 v7, 0x6

    const/4 v7, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    aput-object v0, v5, v7

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p0, v3, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    new-array v3, v4, [Ljava/lang/Object;

    const/4 v8, 0x5

    xor-int/2addr v9, v8

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    aput-object v4, v3, v6

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string v4, ""

    const-string v4, ""

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    aput-object v4, v3, v7

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {v0, p0, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string v0, " psfTseoIg rp|byBel snIpngfn  sor:tu ortnolTo ryttp"

    const-string/jumbo v0, "oystpnr:uue  TyBseslnr ooTongl|f n b pg tpropIrttIf"

    const/4 v9, 0x7

    const-string/jumbo v0, "reportTpnsInfoToBugly | report tpnsInfo to bugly : "

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    goto :goto_0

    :catchall_0
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string/jumbo p0, "yIfmtonnplen dukTsfy ursopto|r Tdgogulo BnB"

    const-string/jumbo p0, "reportTpnsInfoToBugly | Bugly sdk not found"

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x3

    return-void
.end method

.method public static safeSendQuest(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->c(Landroid/content/Context;)I

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->a()Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v3, "mrtaosSueictv:"

    const-string v3, "eu:micrSvtsats"

    const/4 v5, 0x2

    const-string v3, "aetcSbsie:svtr"

    const-string/jumbo v3, "serviceStatus:"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string v3, ": ,BsduHnadsoii"

    const-string v3, " n:ao,sd isHdBi"

    const/4 v5, 0x3

    const-string v3, "iHadeB,p ns d:i"

    const-string v3, ", isHasBinded: "

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string v3, "aubshPgrqeGna"

    const-string v3, "euPXgbansGarh"

    const/4 v5, 0x2

    const-string v3, "gesGaMhrsPnuX"

    const-string v3, "XGPushManager"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x2

    if-ne v0, v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string/jumbo v1, "tp0mf seuh doye1ootreosprufd/vcfn/Terua  rifbacuacSats"

    const-string v1, "hy nesuffvdtb ortTe uu/iapfaeosecc1ra0ppo/oscudrr taSf"

    const/4 v5, 0x5

    const-string v1, "apc otbdirvay0ppoosa arfftuodeseouS/t huTerer1f/ eccnf"

    const-string/jumbo v1, "send boardcast to pushService\uff0c operatorType\uff1a"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/android/tpush/XGPushManager;->c(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo v1, "oTulebp n spaoetsyadeertpqeyd:"

    const-string v1, "epys euprstyenraeaTlodqtp:d eo"

    const/4 v5, 0x2

    const-string v1, "delay send quest operatorType:"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void
.end method

.method public static sendCommReport2Service(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 9

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v8, 0x2

    const/4 v7, 0x5

    new-instance v2, Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string v4, "dc4M_nurt.caxo.R.etdiVngP.oEOMti.paCicT.nqmRnOvo"

    const-string v4, ".gtxEinoqitvidPmcROTnC.nr.Ro.M.cOneadaMVoc_4tpe."

    const/4 v8, 0x0

    const-string v4, "M4niogtp.dec.icRtmnOv..e.c.V_iPrMEtaoOCTnpaoRxn."

    const-string v4, "com.tencent.android.xg.vip.action.COMM_REPORT.V4"

    const/4 v7, 0x1

    move v8, v7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-string v3, "epty"

    const-string v3, "epyt"

    const/4 v8, 0x5

    const-string/jumbo v3, "yept"

    const-string/jumbo v3, "type"

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v8, 0x1

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v7, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v2, v3, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x5

    const-string v4, ""

    const-string v4, ""

    const/4 v8, 0x1

    const-string v4, ""

    const-string v4, ""

    const/4 v8, 0x5

    const/4 v7, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v3, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string/jumbo v1, "qaIscdes"

    const-string v1, "cdsIasce"

    const/4 v8, 0x3

    const-string/jumbo v1, "sasIesdc"

    const-string v1, "accessId"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v2, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const-string v0, "dmmmI"

    const-string v0, "Ismmd"

    const/4 v8, 0x3

    const-string/jumbo v0, "mdIgo"

    const-string/jumbo v0, "msgId"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-wide/16 v3, 0x3e8

    const/4 v8, 0x7

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v8, 0x6

    const/4 v7, 0x6

    invoke-virtual {v2, v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x0

    const-string v0, "dcdIbbotros"

    const-string v0, "bdtaoIorscd"

    const/4 v8, 0x1

    const-string v0, "ctdroduaasb"

    const-string v0, "broadcastId"

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-wide/16 v5, 0x0

    const/4 v8, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v2, v0, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    div-long/2addr v0, v3

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    const-string v5, "Tsmmiamptepb"

    const-string/jumbo v5, "tmsigbamemTp"

    const/4 v8, 0x5

    const-string/jumbo v5, "mspaimmTqetg"

    const-string/jumbo v5, "msgTimestamp"

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v2, v5, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    div-long/2addr v0, v3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string v3, "aTslitmtmsuepei"

    const-string/jumbo v3, "pimaeluTetmntsi"

    const/4 v8, 0x2

    const-string v3, "ammmsltnTtiecpe"

    const-string v3, "clientTimestamp"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v2, v3, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    const-string/jumbo v0, "pmkeNap"

    const/4 v8, 0x7

    const-string/jumbo v0, "pNmeoga"

    const-string/jumbo v0, "pkgName"

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x3

    invoke-virtual {v2, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string/jumbo v0, "smg"

    const/4 v8, 0x7

    const-string/jumbo v0, "msg"

    const-string/jumbo v0, "msg"

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {v2, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    const-string p1, "ext"

    const-string p1, "ext"

    const/4 v8, 0x4

    const-string p1, "etx"

    const-string p1, "ext"

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {p2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v2, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-static {p0, v2}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    return-void
.end method

.method public static setContext(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/XGPushManager;->b:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/common/AppInfos;->init(Landroid/content/Context;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    sput-object p0, Lcom/tencent/android/tpush/XGPushManager;->b:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/TGlobalHelper;->setContext(Landroid/content/Context;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public static setDefaultNotificationBuilder(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-nez p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-nez p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v1, Lcom/tencent/android/tpush/XGPushManager$20;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v1, p0, p1}, Lcom/tencent/android/tpush/XGPushManager$20;-><init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public static setKeyValueTag(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 11

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x2

    const-string/jumbo v0, "ngXeGbuahqraP"

    const-string v0, "XGrnPagaqhues"

    const/4 v10, 0x2

    const-string v0, "hrnsGMuXPaeua"

    const-string v0, "XGPushManager"

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x0

    if-eqz p0, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz p1, :cond_1

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    if-eqz v1, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x5

    if-eqz p2, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    if-nez v1, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v10, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    const-string p1, "::::"

    const/4 v10, 0x1

    const-string p1, "::::"

    const-string p1, "::::"

    const/4 v9, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string/jumbo p2, "u>ygeitp e aa loiestaKhcnAVw=tT sgt "

    const-string/jumbo p2, "tisaye Awsul-i a oVganetK=>c hetTgt "

    const/4 v10, 0x4

    const-string p2, "Aa ut > qe=ihge-ynaVe atttcl wT giso"

    const-string p2, "Action -> setKeyValueTag with tag = "

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    const/4 v4, 0x3

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x2

    const-wide/16 v5, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    move-object v3, v8

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x0

    return-void

    :cond_1
    :goto_0
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-string p0, "Kgsonei tyVtaoTxge oKlu .tyeatrliarlctuaeg  s edvVamn"

    const-string p0, "crgmdyo ale  liVuv.yaKTatVnuK rgiaatltngest toxeaeo e"

    const/4 v10, 0x2

    const-string/jumbo p0, "rtemiuKoiavytereanoeVu To  .ntgs gKtlaglacd txleyVaea"

    const-string/jumbo p0, "setKeyValueTag context or tagKey or tagValue invalid."

    const/4 v10, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    return-void
.end method

.method public static setNotifactionCallback(Lcom/tencent/android/tpush/XGPushNotifactionCallback;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    sput-object p0, Lcom/tencent/android/tpush/XGPushManager;->g:Lcom/tencent/android/tpush/XGPushNotifactionCallback;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static setPushNotificationBuilder(Landroid/content/Context;ILcom/tencent/android/tpush/XGPushNotificationBuilder;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    if-eqz p0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v0, 0x1

    move v3, v0

    const/4 v2, 0x1

    move v3, v2

    if-lt p1, v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/16 v0, 0x1000

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-gt p1, v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x4

    if-nez p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/XGPushManager$19;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {v1, p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager$19;-><init>(Landroid/content/Context;ILcom/tencent/android/tpush/XGPushNotificationBuilder;)V

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string p1, "B8/aooertud/ndi/l5f04[7fd3u6316890,.u52noiuI/ tc04iue]"

    const-string p1, "//ofo3/n58doni0ur2ale91Be35t]7ut06/uu.48[ufdd6I,0i4ic "

    const-string p1, "63040btueod4ufi/,o9.//[ndd]t34u01I2ri Blu6i58fe8na75u/"

    const-string/jumbo p1, "notificationBulderId\u4e0d\u5728\u8303\u56f4[1, 4096]."

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x6

    throw p0

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v2, 0x3

    const-string/jumbo p1, "iltn. ut xeunclo"

    const-string p1, "context is null."

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    throw p0
.end method

.method public static setSysNotifactionCallback(Lcom/tencent/android/tpush/XGSysPushNotifactionCallback;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    sput-object p0, Lcom/tencent/android/tpush/XGPushManager;->h:Lcom/tencent/android/tpush/XGSysPushNotifactionCallback;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method

.method public static setTag(Landroid/content/Context;Ljava/lang/String;)V
    .locals 11
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    const-string v0, "MbsGgPupahnrX"

    const-string v0, "GPsgrbMauXnah"

    const/4 v10, 0x3

    const-string v0, "MearGgPuqhanX"

    const-string v0, "XGPushManager"

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz p0, :cond_1

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz v1, :cond_0

    const/4 v9, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x2

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    const-string/jumbo v2, "wtsac =-neu igA t  a>T hgsti"

    const-string v2, " einoAuta>s=t-g  Tgwt h ic a"

    const-string/jumbo v2, "tt=mgi ->Te ts g inachw o ta"

    const-string v2, "Action -> setTag with tag = "

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    const/4 v4, 0x1

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x1

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    return-void

    :cond_1
    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x0

    const-string p0, "el toegc ptnexhtatoar tT upas  mlgsroiNmfneaee rta "

    const-string p0, "axlmesepuarat nem   c otapafitolrreN gTt.htentegs  "

    const/4 v10, 0x6

    const-string/jumbo p0, "roro btgnexa.lnarN teo ctsemgpTl t ae tt efe uahsia"

    const-string/jumbo p0, "the parameter context or tagName of setTag is null."

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    return-void
.end method

.method public static setTag(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 12
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    const-string v0, "MrqsgauGuXnah"

    const-string/jumbo v0, "rnhGXsuaqeaMg"

    const/4 v11, 0x5

    const-string v0, "asuGgePpahrnX"

    const-string v0, "XGPushManager"

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    if-eqz p0, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v1

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x2

    if-eqz v1, :cond_0

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    goto :goto_0

    :cond_0
    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-string/jumbo v2, "wh aionaqeg-tisc  ttgAt  s= "

    const-string v2, "->siot nawstti   chg=aA tge "

    const/4 v11, 0x7

    const-string v2, "Action -> setTag with tag = "

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x5

    const/4 v10, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    const/4 v4, 0x1

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v11, 0x5

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v7, 0x6

    const/4 v7, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v9, p2

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-static/range {v2 .. v9}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    return-void

    :cond_1
    :goto_0
    const/4 v11, 0x4

    const-string p1, "Trstrt ogen giletretamacmesuane pe thaft.  xo Nlo s"

    const-string/jumbo p1, "the parameter context or tagName of setTag is null."

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-eqz p0, :cond_2

    const/4 v11, 0x6

    const/4 v10, 0x7

    if-eqz p2, :cond_2

    const/4 v10, 0x3

    and-int/2addr v11, v10

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_TAG:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v10, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v11, 0x5

    const/4 v10, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v11, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-interface {p2, v0, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    const/4 v11, 0x2

    return-void
.end method

.method public static setTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->clearAndAppendTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method public static setTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Set<",
            "Ljava/lang/String;",
            ">;",
            "Lcom/tencent/android/tpush/XGIOperateCallback;",
            ")V"
        }
    .end annotation

    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/android/tpush/XGPushManager;->clearAndAppendTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static startPushService(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->setContext(Landroid/content/Context;)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v1, "lremmhcesl ruSsctaP ivt"

    const-string v1, "heemusiccts a lvlrrPtS "

    const/4 v3, 0x5

    const-string v1, " theoerSaircsucavPtl l "

    const-string v1, "call start Push Service"

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v1, "sarGobnhgMuae"

    const-string v1, "haagoeurMGsPn"

    const/4 v3, 0x5

    const-string/jumbo v1, "srXGguueaPnah"

    const-string v1, "XGPushManager"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->g(Landroid/content/Context;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->c(Landroid/content/Context;)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->f(Landroid/content/Context;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method public static stopPushService(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz p0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v1, " ac rilpbsPShe septvcul"

    const-string/jumbo v1, "tPch bip vSeslcearus  l"

    const/4 v5, 0x4

    const-string/jumbo v1, "ipPu aotqssrhe cl  lcvS"

    const-string v1, " call stop Push Service"

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo v1, "ngsGhPXasMeuu"

    const-string v1, "XunPsruGegahM"

    const/4 v5, 0x5

    const-string v1, "gnhmGPXrauMes"

    const-string v1, "XGPushManager"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->f()Landroid/content/ServiceConnection;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v3, "ion:opCv"

    const-string/jumbo v3, "vipConn:"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0, v0}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->g()V

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0, v0}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :try_start_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/g;->f(Landroid/content/Context;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string/jumbo v2, "tnEaibLnpnaeOo.S.rgm.e4RIvtVS.icPCIEVKcxndSt...iELdCopc"

    const-string/jumbo v2, "itOSE.dpdc.pIag.t.CCLivaoEconPmtVR.eioSrLec..4InnExnVSK"

    const/4 v5, 0x2

    const-string/jumbo v2, "td..aVuCRtSoeoIcdnPr..CnccE..xELo4LniSVpReOatngE.iIimvK"

    const-string v2, "com.tencent.android.xg.vip.action.KILLSERVICEPROCESS.V4"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x1

    move v5, v4

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    :cond_1
    const/4 v5, 0x0

    return-void
.end method

.method public static unregisterPush(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-nez p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string/jumbo p0, "uGhaeqnpXargs"

    const-string p0, "eaMagGhrqsuXn"

    const/4 v2, 0x2

    const-string/jumbo p0, "unXMaesGqragh"

    const-string p0, "XGPushManager"

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-string v0, "frstlxt scu Plestuusien osn rheitgo e"

    const-string v0, "exsie oecr iesst unn lurPhutttlogn fs"

    const/4 v2, 0x7

    const-string/jumbo v0, "the context of unregisterPush is null"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$35;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGPushManager$35;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/XGPushManager;->unregisterPush(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-void
.end method

.method public static unregisterPush(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    const/4 v5, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    const/4 v6, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    const/4 v7, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static/range {v0 .. v7}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    return-void
.end method

.method public static unregisterPush(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 10

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v9, 0x0

    const/4 v8, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p4

    move-object v1, p4

    move-object v1, p4

    move-object v1, p4

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v5, p1

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static/range {v0 .. v7}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    return-void
.end method

.method public static uploadLogFile(Landroid/content/Context;Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;)V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string v0, "amnmhugPMesar"

    const-string v0, "MarmsGunPageh"

    const/4 v7, 0x7

    const-string v0, "GhrgoaaXuMnPe"

    const-string v0, "XGPushManager"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-eqz p0, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-nez p1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto/16 :goto_1

    :cond_0
    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    new-instance v1, Lcom/tencent/android/tpush/XGPushManager$27;

    const/4 v7, 0x1

    invoke-direct {v1, p1}, Lcom/tencent/android/tpush/XGPushManager$27;-><init>(Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;)V

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    new-instance v2, Landroid/content/IntentFilter;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    const-string v3, ".oc.Sb.nLe.V.UtovdncLopRSn.nUH.xedmt.igi4trFTEaao"

    const-string/jumbo v3, "torooi.naRg.4dLxn.ntt.pn.domcFT.VieSecLiEa..SUUvH"

    const/4 v7, 0x6

    const-string v3, "iUetV.unToiLddrntmSa.Li.ac.oRHctxS.gonUe..pF.vnEc"

    const-string v3, "com.tencent.android.xg.vip.action.FLUSH.RESULT.V4"

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-direct {v2, v3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/4 v3, 0x4

    const/4 v7, 0x5

    const/4 v6, 0x4

    invoke-static {p0, v1, v2, v3}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance v3, Lcom/tencent/android/tpush/XGPushManager$28;

    invoke-direct {v3, p0, p1, v1}, Lcom/tencent/android/tpush/XGPushManager$28;-><init>(Landroid/content/Context;Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;Landroid/content/BroadcastReceiver;)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/16 p1, 0x1a

    const/4 v6, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-wide/16 v4, 0xbb8

    const-wide/16 v4, 0xbb8

    const/4 v7, 0x6

    const-wide/16 v4, 0xbb8

    const-wide/16 v4, 0xbb8

    const/4 v7, 0x2

    const/4 v6, 0x4

    invoke-virtual {v2, v3, p1, v4, v5}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->executeAtTime(Lcom/tencent/tpns/baseapi/base/util/TTask;IJ)Z

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    new-instance p1, Landroid/content/Intent;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string/jumbo v2, "oan.eFgpbmVtde4iHc.c..in.cina.votdLnUpxSor"

    const-string v2, "gnoecb.LdiU.F.Sn.eVatHcrn..piot4ovcmadinx."

    const/4 v7, 0x4

    const-string/jumbo v2, "ndcctn.nqoaia..SoUexpVe.t.d.rci.FtLgim4onv"

    const-string v2, "com.tencent.android.xg.vip.action.FLUSH.V4"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x7

    invoke-direct {p1, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const-string/jumbo v1, "muscpeaN"

    const-string/jumbo v1, "kpaNemuc"

    const/4 v7, 0x2

    const-string v1, "Naemmpka"

    const-string/jumbo v1, "packName"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {v2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p1, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x5

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string v1, "eo eoolxucunrflp Loted:Fgaepd"

    const-string/jumbo v1, "nofceudpegloedalt:LueoirFxp  "

    const/4 v7, 0x7

    const-string/jumbo v1, "odac:benoplLfxeto dgipleuu Fe"

    const-string/jumbo v1, "unexpected for uploadLogFile:"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    return-void

    :cond_1
    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string p0, "at tulurc!ba lpenmro q ene"

    const-string p0, "em u npbqaln acr trlt!noee"

    const/4 v7, 0x7

    const-string/jumbo p0, "paoetlnpnleruaa en !mrb  c"

    const-string/jumbo p0, "parameter can not be null!"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    return-void
.end method

.method public static upsertAccounts(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz p0, :cond_1

    const/4 v1, 0x3

    and-int/2addr v2, v1

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$32;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0, p1}, Lcom/tencent/android/tpush/XGPushManager$32;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->upsertAccounts(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void

    :cond_1
    :goto_0
    const/4 v2, 0x3

    const-string p0, "GaPrMaXequgnh"

    const-string p0, "arshGagMneXuP"

    const/4 v2, 0x0

    const-string/jumbo p0, "susXhraPgMGae"

    const-string p0, "XGPushManager"

    const/4 v2, 0x1

    const-string/jumbo p1, "teamrnocaaalpx rooinenomn nslm pfettcchodu.   t c ttuApuce"

    const-string/jumbo p1, "seamncnooiuantftd uatocarhcpc tom ern eptA ul . ecex nptlo"

    const/4 v2, 0x2

    const-string/jumbo p1, "the parameter context or account of appendAccount is null."

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public static upsertAccounts(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 3
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz p0, :cond_1

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$31;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {v0, p1}, Lcom/tencent/android/tpush/XGPushManager$31;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p0, p1, p2, v0}, Lcom/tencent/android/tpush/XGPushManager;->upsertAccounts(Landroid/content/Context;Ljava/lang/String;ILcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void

    :cond_1
    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-string/jumbo p0, "nrGaoogMaXseP"

    const-string p0, "gnauoaGsrMePX"

    const-string p0, "gaGerbahsnXuM"

    const-string p0, "XGPushManager"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string p1, "Aoitoxuhunu c tnanblp erd  .crecpaaotretlomc ctpst  efuneo"

    const-string/jumbo p1, "thutabincu tlep cxlenecm e.nop ttrcofo opnaAnsr atdr cou e"

    const/4 v2, 0x5

    const-string p1, " n nroaptan tAxlteetccm u panocrtporco l sapie utocund.ehf"

    const-string/jumbo p1, "the parameter context or account of appendAccount is null."

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static upsertAccounts(Landroid/content/Context;Ljava/lang/String;ILcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 10
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-eqz p0, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-nez p2, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {v1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eqz p2, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    goto :goto_0

    :cond_0
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/4 v5, 0x2

    const/4 v8, 0x2

    move v9, v8

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v4, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v6, p1

    move-object v6, p1

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    move-object v7, p3

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static/range {v0 .. v7}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    return-void

    :cond_1
    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    const-string/jumbo p1, "sMaPauhgquXGn"

    const-string p1, "gaMPauuesnGhX"

    const/4 v9, 0x3

    const-string p1, "ansPhuXgrasMe"

    const-string p1, "XGPushManager"

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string/jumbo p2, "untmn  lAcouearenoei p  o odnttmxpcaf clocrepnptsrhettuc.a"

    const-string p2, " urttxap nccano eAcpouittpte lfmcodo shnanrt ur nee l.pcoe"

    const/4 v9, 0x1

    const-string/jumbo p2, "t naou oahcne  tasefucpeAitncxl tacr m o.oncuptltd neoroer"

    const-string/jumbo p2, "the parameter context or account of appendAccount is null."

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    if-eqz p0, :cond_2

    if-eqz p3, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ACCOUNT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const-string p2, ""

    const-string p2, ""

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-interface {p3, p2, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    return-void
.end method

.method public static upsertAccounts(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 11
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x6

    const/4 v0, 0x0

    const/4 v9, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/lang/String;I)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    if-eqz p0, :cond_1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-nez v0, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static {v2}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-eqz v0, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    goto :goto_0

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    const/4 v6, 0x2

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v10, 0x0

    const/4 v5, 0x5

    const/4 v10, 0x6

    const/4 v5, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v7, p1

    move-object v8, p2

    move-object v8, p2

    move-object v8, p2

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x6

    return-void

    :cond_1
    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-string p1, "aqXPabGuMerng"

    const-string/jumbo p1, "ugPaarhMqeXnG"

    const/4 v10, 0x7

    const-string/jumbo p1, "ngMhrGuePXaas"

    const-string p1, "XGPushManager"

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string/jumbo v0, "ou lstupoln  u na eacaeehrootpen Aittnoex s.afcrmpcdncpr c"

    const-string/jumbo v0, "ucscar rtonaoldranptehpxtnil.ao ops entuA ec o cecf m eutn"

    const/4 v10, 0x2

    const-string v0, " pppl amqoftcectcoaon o A .xeieracrlunuteuttceh td n asrno"

    const-string/jumbo v0, "the parameter context or account of appendAccount is null."

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-eqz p0, :cond_2

    const/4 v10, 0x7

    if-eqz p2, :cond_2

    const/4 v10, 0x3

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ACCOUNT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v10, 0x4

    const/4 v9, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v10, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v10, 0x1

    invoke-interface {p2, v0, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    const/4 v9, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x6

    return-void
.end method

.method public static upsertAccounts(Landroid/content/Context;Ljava/util/List;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 10
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Lcom/tencent/android/tpush/XGPushManager$AccountInfo;",
            ">;",
            "Lcom/tencent/android/tpush/XGIOperateCallback;",
            ")V"
        }
    .end annotation

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/List;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-eqz p0, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-eqz p1, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x0

    if-eqz p1, :cond_1

    const/4 v8, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-eqz p1, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto :goto_0

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/4 v5, 0x6

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v8, 0x6

    move v9, v8

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string v6, ""

    const-string v6, ""

    const/4 v9, 0x4

    const-string v6, ""

    move-object v0, p0

    move-object v0, p0

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-static/range {v0 .. v7}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    return-void

    :cond_1
    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x5

    const-string/jumbo p1, "shsPrmaGngXau"

    const-string p1, "huPmgsnaXrGae"

    const/4 v9, 0x6

    const-string/jumbo p1, "sGgmPuenahMXr"

    const-string p1, "XGPushManager"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    const-string v0, " ru oimlu|eserhcaoAe tlseagtcepttanr  .pil"

    const-string/jumbo v0, "upsertAccounts | the parameter is illegal."

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz p0, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-eqz p2, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ACCOUNT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v9, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-interface {p2, v0, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    return-void
.end method

.method public static upsertAttributes(Landroid/content/Context;Ljava/lang/String;Ljava/util/Map;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;",
            "Lcom/tencent/android/tpush/XGIOperateCallback;",
            ")V"
        }
    .end annotation

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo v0, "rneaGbauPhsoX"

    const-string v0, "aaeuonGhsgPrX"

    const/4 v4, 0x6

    const-string v0, "hurnMXugaPeGs"

    const-string v0, "XGPushManager"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz p0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz p2, :cond_2

    const/4 v4, 0x5

    invoke-interface {p2}, Ljava/util/Map;->isEmpty()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/Map;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v1, "eipebutptrAtsbrs"

    const-string/jumbo v1, "rpbtrbteituAesst"

    const/4 v4, 0x6

    const-string/jumbo v1, "stutrptsqeArieut"

    const-string/jumbo v1, "upsertAttributes"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {v1, p2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v2, "tisAruteirssuatbtbu   et wrpth=ueialtl"

    const-string v2, "a bstau e=ttutirAerertuiuitlltws  pb h"

    const/4 v4, 0x4

    const-string/jumbo v2, "t smlbtritrepitawutseehbuua =t  Artl t"

    const-string/jumbo v2, "upsertAttributes with all attribute = "

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {p0, p2, v0, p1, p3}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-void

    :cond_2
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string p1, "dprionuia ttepbtserisitflrtxs.o at eahrneaurstb v  Autmitep co tero"

    const-string/jumbo p1, "tis m rpuorutiaduveret  sshrenst eaoiatiplp tttcteeAtbfobrxt airn ."

    const-string/jumbo p1, "paeobbxt ie.htvnit uiaspie rurnsttr   ratbltctu eomdAtose efrtsiear"

    const-string/jumbo p1, "the parameter context or attributes of upsertAttributes is invalid."

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz p0, :cond_3

    const/4 v4, 0x5

    if-eqz p3, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ATTRIBUTE:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string p2, ""

    const-string p2, ""

    const/4 v4, 0x0

    const-string p2, ""

    const-string p2, ""

    const/4 v3, 0x7

    move v4, v3

    invoke-interface {p3, p2, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method

.method public static upsertPhoneNumber(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 5

    :try_start_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v0, "/11q94u+^//?-}],1/d["

    const-string v0, "/?{41/d9q]/[,-}1+1/^"

    const/4 v4, 0x1

    const-string v0, "/{1/1d,p[9}/+1]^?/-$"

    const-string v0, "^\\+?[1-9]\\d{1,14}$"

    const/4 v4, 0x0

    invoke-static {v0}, Ljava/util/regex/Pattern;->compile(Ljava/lang/String;)Ljava/util/regex/Pattern;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Ljava/util/regex/Pattern;->matcher(Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/util/regex/Matcher;->matches()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-eqz p2, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    sget-object v1, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ACCOUNT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p2, v0, v2, v1}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    return-void

    :catchall_0
    move-exception v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v1, "ganXrPMuqshae"

    const-string v1, "eushXMarnGgaP"

    const/4 v4, 0x3

    const-string v1, "hPsnXeaMgurGa"

    const-string v1, "XGPushManager"

    const/4 v3, 0x4

    move v4, v3

    const-string/jumbo v2, "rr maeerrmteoatpNhrm  mrepbouhn"

    const-string/jumbo v2, "oabmere pmorNhrturrteer npemah "

    const/4 v4, 0x7

    const-string v2, "a Nuop rearhne rotmpoebrertemer"

    const-string/jumbo v2, "the parameter phoneNumber error"

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    sget-object v0, Lcom/tencent/android/tpush/XGPushManager$AccountType;->PHONE_NUMBER:Lcom/tencent/android/tpush/XGPushManager$AccountType;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpush/XGPushManager$AccountType;->getValue()I

    move-result v0

    const/4 v3, 0x2

    shr-int/2addr v4, v3

    invoke-static {p0, p1, v0, p2}, Lcom/tencent/android/tpush/XGPushManager;->upsertAccounts(Landroid/content/Context;Ljava/lang/String;ILcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-void
.end method
