.class public Lcom/tencent/android/tpush/SettingsContentProvider;
.super Landroid/content/ContentProvider;


# static fields
.field public static BASE_URI:Landroid/net/Uri; = null

.field public static final BOOLEAN_TYPE:Ljava/lang/String; = "boolean"

.field public static final FLOAT_TYPE:Ljava/lang/String; = "float"

.field public static final INT_TYPE:Ljava/lang/String; = "integer"

.field public static final KEY:Ljava/lang/String; = "key"

.field public static final LONG_TYPE:Ljava/lang/String; = "long"

.field public static final PREFFERENCE_AUTHORITY:Ljava/lang/String; = "TPUSH_PROVIDER"

.field public static final STRING_TYPE:Ljava/lang/String; = "string"

.field public static final TYPE:Ljava/lang/String; = "type"

.field private static a:Landroid/content/UriMatcher;

.field private static b:Ljava/lang/String;


# instance fields
.field private c:Ljava/lang/Object;

.field private d:Landroid/content/Context;

.field private e:Landroid/content/SharedPreferences;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->c:Ljava/lang/Object;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-direct {v0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->c:Ljava/lang/Object;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->d:Landroid/content/Context;

    :cond_0
    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method private a()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "M s~fS i @~1~t@o~ f@@ ~~@~b@ool oy/bdno~ ~b~ ~-u~~@~i@/~~~@r@ ~m @ @@~ @~ i ~c@4. @~sv@l oaKt@@@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-nez v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->c:Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    const/4 v5, 0x7

    if-nez v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->d:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-nez v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->d:Landroid/content/Context;

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->d:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string v2, "gsimxpmln.i.sve.xgtt"

    const-string v2, ".xg.vip.settings.xml"

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1, v2, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    monitor-exit v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x2

    throw v1

    :cond_2
    :goto_0
    const/4 v4, 0x1

    const/4 v5, 0x0

    return-void
.end method

.method private a(Landroid/content/Context;)V
    .locals 6

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget-object v0, Lcom/tencent/android/tpush/SettingsContentProvider;->b:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v1, "."

    const-string v1, "."

    const/4 v5, 0x0

    const-string v1, "."

    const-string v1, "."

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string/jumbo v1, "sPTRoHOSEV_IUP"

    const-string v1, "_PsVHITREPSDUO"

    const/4 v5, 0x5

    const-string v1, "RHETPb_IRPUDSV"

    const-string v1, "TPUSH_PROVIDER"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    sput-object v0, Lcom/tencent/android/tpush/SettingsContentProvider;->b:Ljava/lang/String;

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object v0, Lcom/tencent/android/tpush/SettingsContentProvider;->a:Landroid/content/UriMatcher;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-nez v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance v0, Landroid/content/UriMatcher;

    const/4 v5, 0x2

    const/4 v1, -0x1

    const/4 v5, 0x3

    move v4, v1

    move v4, v1

    const/4 v5, 0x3

    invoke-direct {v0, v1}, Landroid/content/UriMatcher;-><init>(I)V

    const/4 v5, 0x4

    sput-object v0, Lcom/tencent/android/tpush/SettingsContentProvider;->a:Landroid/content/UriMatcher;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    sget-object v1, Lcom/tencent/android/tpush/SettingsContentProvider;->b:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string v2, "*/*"

    const-string v2, "*/*"

    const-string v2, "/**"

    const-string v2, "*/*"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/high16 v3, 0x10000

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object v0, Lcom/tencent/android/tpush/SettingsContentProvider;->BASE_URI:Landroid/net/Uri;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-nez v0, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo v1, "ot/mteuc/:"

    const-string/jumbo v1, "oecm/nt/t:"

    const/4 v5, 0x6

    const-string v1, "content://"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    sget-object v1, Lcom/tencent/android/tpush/SettingsContentProvider;->b:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    sput-object v0, Lcom/tencent/android/tpush/SettingsContentProvider;->BASE_URI:Landroid/net/Uri;

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->d:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void
.end method

.method public static getBooleanValue(Landroid/database/Cursor;Z)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez p0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    return p1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-interface {p0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 p1, 0x0

    move v2, p1

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {p0, p1}, Landroid/database/Cursor;->getInt(I)I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-lez v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 p1, 0x1

    :cond_1
    const/4 v1, 0x1

    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p1
.end method

.method public static final getContentUri(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/SettingsContentProvider;->BASE_URI:Landroid/net/Uri;

    const/4 v1, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    sget-object v0, Lcom/tencent/android/tpush/SettingsContentProvider;->b:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string p0, "."

    const-string p0, "."

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string p0, "PPTOIRSpVDERH_"

    const-string p0, "PRSOoEITH_RDPV"

    const/4 v2, 0x4

    const-string p0, "PHPRDUETq_VROI"

    const-string p0, "TPUSH_PROVIDER"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    sput-object p0, Lcom/tencent/android/tpush/SettingsContentProvider;->b:Ljava/lang/String;

    :cond_0
    const/4 v2, 0x4

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string v0, "/tsn:o/tcb"

    const-string v0, "/tnctb/:on"

    const/4 v2, 0x4

    const-string/jumbo v0, "t:tmenn/oc"

    const-string v0, "content://"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/SettingsContentProvider;->b:Ljava/lang/String;

    const/4 v2, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p0}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    sput-object p0, Lcom/tencent/android/tpush/SettingsContentProvider;->BASE_URI:Landroid/net/Uri;

    :cond_1
    const/4 v2, 0x0

    sget-object p0, Lcom/tencent/android/tpush/SettingsContentProvider;->BASE_URI:Landroid/net/Uri;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/net/Uri;->buildUpon()Landroid/net/Uri$Builder;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Landroid/net/Uri$Builder;->appendPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, p2}, Landroid/net/Uri$Builder;->appendPath(Ljava/lang/String;)Landroid/net/Uri$Builder;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/net/Uri$Builder;->build()Landroid/net/Uri;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-object p0
.end method

.method public static getFloatValue(Landroid/database/Cursor;F)F
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    if-nez p0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {p0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p1, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {p0, p1}, Landroid/database/Cursor;->getFloat(I)F

    move-result p1

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    return p1
.end method

.method public static getIntValue(Landroid/database/Cursor;I)I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-nez p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    return p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-interface {p0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-interface {p0, p1}, Landroid/database/Cursor;->getInt(I)I

    move-result p1

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p1
.end method

.method public static getLongValue(Landroid/database/Cursor;J)J
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez p0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-wide p1

    :cond_0
    const/4 v2, 0x1

    invoke-interface {p0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x7

    invoke-interface {p0, p1}, Landroid/database/Cursor;->getLong(I)J

    move-result-wide p1

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-wide p1
.end method

.method public static getStringValue(Landroid/database/Cursor;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    if-nez p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object p1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-interface {p0}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x5

    const/4 p1, 0x0

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-interface {p0, p1}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object p1

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {p0}, Landroid/database/Cursor;->close()V

    const/4 v2, 0x1

    const/4 v1, 0x4

    return-object p1
.end method


# virtual methods
.method public delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/android/tpush/SettingsContentProvider;->a()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    sget-object p2, Lcom/tencent/android/tpush/SettingsContentProvider;->a:Landroid/content/UriMatcher;

    const/4 v1, 0x5

    const/4 v0, 0x2

    invoke-virtual {p2, p1}, Landroid/content/UriMatcher;->match(Landroid/net/Uri;)I

    move-result p2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    const/high16 p3, 0x10000

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    if-eq p2, p3, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x1

    const-string p3, " Upoopsuutn udie"

    const-string/jumbo p3, "iodurUu entu spp"

    const-string/jumbo p3, "sripoberuunUdt p"

    const-string p3, "Unsupported uri "

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    const-string/jumbo p2, "rnveriuePttSdignptnCtso"

    const-string/jumbo p2, "oieertPprStisteCdgnnvnt"

    const/4 v1, 0x0

    const-string/jumbo p2, "neCitrrptsnvgootiedPent"

    const-string p2, "SettingsContentProvider"

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x5

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    :goto_0
    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p1
.end method

.method public getType(Landroid/net/Uri;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    const-string p1, "IRdeVPRmqdiodqrDsouHt._iaSrnv..eTnt.Pn/cmEU.rdO"

    const-string p1, "DdtEHo.eqirtm./uV.riomesIaTr.ncRUOdRinP_dS.dnPv"

    const/4 v1, 0x6

    const-string p1, "REs.UnvidvIun_VdOaTsSn...ioerPiHectRtmdrPro.Ddm"

    const-string/jumbo p1, "vnd.android.cursor.item/vnd.TPUSH_PROVIDER.item"

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-object p1
.end method

.method public insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    .locals 7
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi"
        }
    .end annotation

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpush/SettingsContentProvider;->a()V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    sget-object v0, Lcom/tencent/android/tpush/SettingsContentProvider;->a:Landroid/content/UriMatcher;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v0, p1}, Landroid/content/UriMatcher;->match(Landroid/net/Uri;)I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/high16 v1, 0x10000

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string/jumbo v2, "nrSmitvingtetdnsPoCetrs"

    const-string v2, "CtsesotritgtnPeievnSdnr"

    const/4 v6, 0x0

    const-string/jumbo v2, "isetongentoSCtnrodrtPev"

    const-string v2, "SettingsContentProvider"

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-eq v0, v1, :cond_0

    const/4 v5, 0x7

    move v6, v5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    shr-int/2addr v6, v5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string/jumbo v0, "strnubuepi dU mp"

    const-string/jumbo v0, "u rmtnpdi Uepsur"

    const/4 v6, 0x3

    const-string/jumbo v0, "rodineuptpr usUu"

    const-string v0, "Unsupported uri "

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    goto/16 :goto_1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-interface {v0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {p2}, Landroid/content/ContentValues;->valueSet()Ljava/util/Set;

    move-result-object p2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-interface {p2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p2

    :goto_0
    const/4 v6, 0x1

    invoke-interface {p2}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v1, :cond_7

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-interface {p2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    check-cast v1, Ljava/util/Map$Entry;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-interface {v1}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    check-cast v1, Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v1}, Lcom/tencent/tpns/baseapi/base/util/Util;->getKey(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x5

    instance-of v4, v3, Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v4, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    check-cast v3, Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto :goto_0

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    instance-of v4, v3, Ljava/lang/Boolean;

    const/4 v5, 0x0

    or-int/2addr v6, v5

    if-eqz v4, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    check-cast v3, Ljava/lang/Boolean;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    goto :goto_0

    :cond_3
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    instance-of v4, v3, Ljava/lang/Long;

    const/4 v6, 0x0

    const/4 v5, 0x2

    if-eqz v4, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    check-cast v3, Ljava/lang/Long;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v0, v1, v3, v4}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto/16 :goto_0

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    instance-of v4, v3, Ljava/lang/Integer;

    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-eqz v4, :cond_5

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    check-cast v3, Ljava/lang/Integer;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto/16 :goto_0

    :cond_5
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x1

    instance-of v4, v3, Ljava/lang/Float;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v4, :cond_6

    const/4 v6, 0x1

    check-cast v3, Ljava/lang/Float;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/Float;->floatValue()F

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v0, v1, v3}, Landroid/content/SharedPreferences$Editor;->putFloat(Ljava/lang/String;F)Landroid/content/SharedPreferences$Editor;

    const/4 v5, 0x7

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_6
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v3, "pytup rpUe eposdt"

    const-string v3, " tepoUodr uytespp"

    const/4 v6, 0x3

    const-string v3, "Uodserpnqeut ptp "

    const-string v3, "Unsupported type "

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    goto/16 :goto_0

    :cond_7
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->apply()V

    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    const/4 p1, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    return-object p1
.end method

.method public onCreate()Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v0, "gtstCSnoeeovdiePntbnrrs"

    const-string v0, "PnrribgonenetttvodCisSe"

    const/4 v3, 0x5

    const-string/jumbo v0, "otemtreCvintPrniesongtd"

    const-string v0, "SettingsContentProvider"

    const/4 v3, 0x3

    const-string/jumbo v1, "tnueoCancor-o ia "

    const-string/jumbo v1, "rie-Coucnatone  a"

    const/4 v3, 0x6

    const-string v1, "e a obiCntnocat-r"

    const-string v1, "action - onCreate"

    const/4 v3, 0x6

    const/4 v2, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Lcom/tencent/android/tpush/SettingsContentProvider;->a(Landroid/content/Context;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return v0
.end method

.method public query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpush/SettingsContentProvider;->a()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget-object p2, Lcom/tencent/android/tpush/SettingsContentProvider;->a:Landroid/content/UriMatcher;

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Landroid/content/UriMatcher;->match(Landroid/net/Uri;)I

    move-result p2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/high16 p3, 0x10000

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string p4, "iSvnsouCegeeitnntrdPtot"

    const-string p4, "SettingsContentProvider"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 p5, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eq p2, p3, :cond_0

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string p3, "Utnoe ppi urprds"

    const-string/jumbo p3, "on putipreUrd su"

    const/4 v5, 0x3

    const-string/jumbo p3, "se riuopq tpnrUd"

    const-string p3, "Unsupported uri "

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p4, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    goto/16 :goto_2

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/net/Uri;->getPathSegments()Ljava/util/List;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    const/4 p3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-interface {p2, p3}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    check-cast p2, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {p2}, Lcom/tencent/tpns/baseapi/base/util/Util;->getKey(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p1}, Landroid/net/Uri;->getPathSegments()Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v1, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v0, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    check-cast v0, Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v1, Landroid/database/MatrixCursor;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    filled-new-array {p2}, [Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v1, v2}, Landroid/database/MatrixCursor;-><init>([Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {v2, p2}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-nez v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-object v1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v1}, Landroid/database/MatrixCursor;->newRow()Landroid/database/MatrixCursor$RowBuilder;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v3, "issrgq"

    const-string/jumbo v3, "nrqgis"

    const/4 v5, 0x7

    const-string/jumbo v3, "srgmin"

    const-string/jumbo v3, "string"

    const/4 v5, 0x4

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    if-eqz v3, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-interface {p1, p2, p5}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_2
    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo p5, "lansoeo"

    const-string/jumbo p5, "nasloeo"

    const/4 v5, 0x6

    const-string/jumbo p5, "nelabbo"

    const-string p5, "boolean"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p5

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz p5, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-interface {p1, p2, p3}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    goto/16 :goto_0

    :cond_3
    const/4 v5, 0x7

    const-string p5, "glon"

    const-string/jumbo p5, "lngo"

    const/4 v5, 0x6

    const-string/jumbo p5, "ongl"

    const-string/jumbo p5, "long"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p5

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz p5, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-wide/16 p3, 0x0

    const-wide/16 p3, 0x0

    const/4 v5, 0x4

    const-wide/16 p3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-interface {p1, p2, p3, p4}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_0

    :cond_4
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string p5, "gnemtiu"

    const-string p5, "eiemgtn"

    const/4 v5, 0x6

    const-string/jumbo p5, "pteenri"

    const-string/jumbo p5, "integer"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p5, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p5

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-eqz p5, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-interface {p1, p2, p3}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    goto :goto_0

    :cond_5
    const/4 v4, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo p3, "tolqf"

    const-string/jumbo p3, "oltfo"

    const/4 v5, 0x3

    const-string p3, "fosal"

    const-string p3, "float"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p3

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-eqz p3, :cond_6

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpush/SettingsContentProvider;->e:Landroid/content/SharedPreferences;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 p3, 0x0

    const/4 v5, 0x5

    invoke-interface {p1, p2, p3}, Landroid/content/SharedPreferences;->getFloat(Ljava/lang/String;F)F

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v2, p1}, Landroid/database/MatrixCursor$RowBuilder;->add(Ljava/lang/Object;)Landroid/database/MatrixCursor$RowBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_1

    :cond_6
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo p3, "yUpotbput epndrse"

    const/4 v5, 0x0

    const-string/jumbo p3, "nurmtppse podt ey"

    const-string p3, "Unsupported type "

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x0

    invoke-static {p4, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    move-object p5, v1

    move-object p5, v1

    move-object p5, v1

    move-object p5, v1

    :goto_2
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-object p5
.end method

.method public update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpush/SettingsContentProvider;->a()V

    const/4 v1, 0x5

    const/4 v0, 0x0

    const-string/jumbo p1, "ignvouiSnttsenCtortoPed"

    const-string p1, "PCtSosueeiveodtnttngnri"

    const/4 v1, 0x4

    const-string p1, "enCiebsorSvtoPrttnedngi"

    const-string p1, "SettingsContentProvider"

    const/4 v1, 0x1

    const/4 v0, 0x1

    const-string p2, ":epdOuutpdroUeroupp n!itspaat"

    const-string/jumbo p2, "ttpupr puaUpre:oOtpiedno!ansd"

    const/4 v1, 0x2

    const-string p2, "edopipupden!tr:oUtpruOnat esa"

    const-string p2, "UnsupportedOperation: update!"

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    const/4 p1, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return p1
.end method
