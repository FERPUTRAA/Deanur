.class public final enum Lcom/tencent/android/tpush/NotificationAction;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/tencent/android/tpush/NotificationAction;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/tencent/android/tpush/NotificationAction;

.field public static final enum action_package:Lcom/tencent/android/tpush/NotificationAction;

.field public static final enum activity:Lcom/tencent/android/tpush/NotificationAction;

.field public static final enum clicked:Lcom/tencent/android/tpush/NotificationAction;

.field public static final enum delete:Lcom/tencent/android/tpush/NotificationAction;

.field public static final enum download:Lcom/tencent/android/tpush/NotificationAction;

.field public static final enum download_cancel:Lcom/tencent/android/tpush/NotificationAction;

.field public static final enum intent:Lcom/tencent/android/tpush/NotificationAction;

.field public static final enum intent_with_action:Lcom/tencent/android/tpush/NotificationAction;

.field public static final enum open:Lcom/tencent/android/tpush/NotificationAction;

.field public static final enum open_cancel:Lcom/tencent/android/tpush/NotificationAction;

.field public static final enum url:Lcom/tencent/android/tpush/NotificationAction;


# instance fields
.field private type:I


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Lcom/tencent/android/tpush/NotificationAction;

    const-string/jumbo v1, "lcsekds"

    const-string/jumbo v1, "lescdkc"

    const-string v1, "ekimlcd"

    const-string v1, "clicked"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2, v2}, Lcom/tencent/android/tpush/NotificationAction;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/tencent/android/tpush/NotificationAction;->clicked:Lcom/tencent/android/tpush/NotificationAction;

    new-instance v1, Lcom/tencent/android/tpush/NotificationAction;

    const-string v3, "amivoyit"

    const-string/jumbo v3, "iytmiatv"

    const-string/jumbo v3, "yttcibav"

    const-string v3, "activity"

    const/4 v4, 0x1

    invoke-direct {v1, v3, v4, v4}, Lcom/tencent/android/tpush/NotificationAction;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    new-instance v3, Lcom/tencent/android/tpush/NotificationAction;

    const-string/jumbo v5, "rul"

    const-string/jumbo v5, "lur"

    const-string/jumbo v5, "rul"

    const-string/jumbo v5, "url"

    const/4 v6, 0x2

    invoke-direct {v3, v5, v6, v6}, Lcom/tencent/android/tpush/NotificationAction;-><init>(Ljava/lang/String;II)V

    sput-object v3, Lcom/tencent/android/tpush/NotificationAction;->url:Lcom/tencent/android/tpush/NotificationAction;

    new-instance v5, Lcom/tencent/android/tpush/NotificationAction;

    const-string/jumbo v7, "utetni"

    const-string/jumbo v7, "nittoe"

    const-string v7, "eptntn"

    const-string/jumbo v7, "intent"

    const/4 v8, 0x3

    invoke-direct {v5, v7, v8, v8}, Lcom/tencent/android/tpush/NotificationAction;-><init>(Ljava/lang/String;II)V

    sput-object v5, Lcom/tencent/android/tpush/NotificationAction;->intent:Lcom/tencent/android/tpush/NotificationAction;

    new-instance v7, Lcom/tencent/android/tpush/NotificationAction;

    const-string v9, "_acpocaaqtngbi"

    const-string v9, "gkitabo_npacac"

    const-string v9, "aosgkitcnp_ace"

    const-string v9, "action_package"

    const/4 v10, 0x4

    invoke-direct {v7, v9, v10, v10}, Lcom/tencent/android/tpush/NotificationAction;-><init>(Ljava/lang/String;II)V

    sput-object v7, Lcom/tencent/android/tpush/NotificationAction;->action_package:Lcom/tencent/android/tpush/NotificationAction;

    new-instance v9, Lcom/tencent/android/tpush/NotificationAction;

    const-string v11, "ahtmn_oc_ttnteuini"

    const-string v11, "_itninuohntaeci_tt"

    const-string v11, "citaoiitttnwho_enn"

    const-string/jumbo v11, "intent_with_action"

    const/4 v12, 0x5

    invoke-direct {v9, v11, v12, v12}, Lcom/tencent/android/tpush/NotificationAction;-><init>(Ljava/lang/String;II)V

    sput-object v9, Lcom/tencent/android/tpush/NotificationAction;->intent_with_action:Lcom/tencent/android/tpush/NotificationAction;

    new-instance v11, Lcom/tencent/android/tpush/NotificationAction;

    const-string/jumbo v13, "pedeeb"

    const-string/jumbo v13, "lpedee"

    const-string/jumbo v13, "ueeled"

    const-string v13, "delete"

    const/4 v14, 0x6

    invoke-direct {v11, v13, v14, v6}, Lcom/tencent/android/tpush/NotificationAction;-><init>(Ljava/lang/String;II)V

    sput-object v11, Lcom/tencent/android/tpush/NotificationAction;->delete:Lcom/tencent/android/tpush/NotificationAction;

    new-instance v13, Lcom/tencent/android/tpush/NotificationAction;

    const-string/jumbo v15, "pnoe"

    const-string/jumbo v15, "onpe"

    const-string v15, "eopn"

    const-string/jumbo v15, "open"

    const/4 v6, 0x7

    invoke-direct {v13, v15, v6, v8}, Lcom/tencent/android/tpush/NotificationAction;-><init>(Ljava/lang/String;II)V

    sput-object v13, Lcom/tencent/android/tpush/NotificationAction;->open:Lcom/tencent/android/tpush/NotificationAction;

    new-instance v15, Lcom/tencent/android/tpush/NotificationAction;

    const-string/jumbo v6, "lea_necpcoq"

    const-string/jumbo v6, "lepocen_qca"

    const-string v6, "ep_olcenqnc"

    const-string/jumbo v6, "open_cancel"

    const/16 v8, 0x8

    invoke-direct {v15, v6, v8, v10}, Lcom/tencent/android/tpush/NotificationAction;-><init>(Ljava/lang/String;II)V

    sput-object v15, Lcom/tencent/android/tpush/NotificationAction;->open_cancel:Lcom/tencent/android/tpush/NotificationAction;

    new-instance v6, Lcom/tencent/android/tpush/NotificationAction;

    const-string v8, "download"

    const/16 v10, 0x9

    invoke-direct {v6, v8, v10, v12}, Lcom/tencent/android/tpush/NotificationAction;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lcom/tencent/android/tpush/NotificationAction;->download:Lcom/tencent/android/tpush/NotificationAction;

    new-instance v8, Lcom/tencent/android/tpush/NotificationAction;

    const-string v10, "coseacddnnwlol_"

    const-string v10, "cnscadndeolwol_"

    const-string/jumbo v10, "we_mnnaoacllddc"

    const-string v10, "download_cancel"

    const/16 v12, 0xa

    invoke-direct {v8, v10, v12, v14}, Lcom/tencent/android/tpush/NotificationAction;-><init>(Ljava/lang/String;II)V

    sput-object v8, Lcom/tencent/android/tpush/NotificationAction;->download_cancel:Lcom/tencent/android/tpush/NotificationAction;

    const/16 v10, 0xb

    new-array v10, v10, [Lcom/tencent/android/tpush/NotificationAction;

    aput-object v0, v10, v2

    aput-object v1, v10, v4

    const/4 v0, 0x2

    aput-object v3, v10, v0

    const/4 v0, 0x3

    aput-object v5, v10, v0

    const/4 v0, 0x4

    aput-object v7, v10, v0

    const/4 v0, 0x5

    aput-object v9, v10, v0

    aput-object v11, v10, v14

    const/4 v0, 0x7

    aput-object v13, v10, v0

    const/16 v0, 0x8

    aput-object v15, v10, v0

    const/16 v0, 0x9

    aput-object v6, v10, v0

    aput-object v8, v10, v12

    sput-object v10, Lcom/tencent/android/tpush/NotificationAction;->$VALUES:[Lcom/tencent/android/tpush/NotificationAction;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p3, p0, Lcom/tencent/android/tpush/NotificationAction;->type:I

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method public static getNotificationAction(I)Lcom/tencent/android/tpush/NotificationAction;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~t~~o~~~ b@/~y~ Sntf@~o  .~M@@f@1b~@iv~b@~- o~~@ ~ ~ uK m@@/@@r@l@si @@ @d~c   l@4o  a~o~oi @~~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    if-eqz p0, :cond_5

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    shl-int/2addr v2, v1

    if-eq p0, v0, :cond_4

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eq p0, v0, :cond_3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eq p0, v0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/4 v0, 0x4

    const/4 v2, 0x7

    const/4 v1, 0x5

    if-eq p0, v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, 0x5

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-eq p0, v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x5

    sget-object p0, Lcom/tencent/android/tpush/NotificationAction;->intent_with_action:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object p0

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object p0, Lcom/tencent/android/tpush/NotificationAction;->action_package:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x2

    const/4 v1, 0x5

    return-object p0

    :cond_2
    const/4 v1, 0x4

    const/4 v2, 0x4

    sget-object p0, Lcom/tencent/android/tpush/NotificationAction;->intent:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v1, 0x7

    move v2, v1

    return-object p0

    :cond_3
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object p0, Lcom/tencent/android/tpush/NotificationAction;->url:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x6

    return-object p0

    :cond_4
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object p0, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0

    :cond_5
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object p0, Lcom/tencent/android/tpush/NotificationAction;->clicked:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/tencent/android/tpush/NotificationAction;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-class v0, Lcom/tencent/android/tpush/NotificationAction;

    const-class v0, Lcom/tencent/android/tpush/NotificationAction;

    const-class v0, Lcom/tencent/android/tpush/NotificationAction;

    const-class v0, Lcom/tencent/android/tpush/NotificationAction;

    const/4 v1, 0x3

    move v2, v1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    check-cast p0, Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lcom/tencent/android/tpush/NotificationAction;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->$VALUES:[Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0}, [Lcom/tencent/android/tpush/NotificationAction;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    check-cast v0, [Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public getType()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/android/tpush/NotificationAction;->type:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    return v0
.end method
