.class Lcom/tencent/android/tpush/XGPushManager$1$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager$1;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Lcom/tencent/android/tpush/XGPushManager$1;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGPushManager$1;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$1$1;->b:Lcom/tencent/android/tpush/XGPushManager$1;

    const/4 v1, 0x1

    const/4 v0, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$1$1;->a:Landroid/content/Intent;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@@s~o 4io  oirb ao@o @@.sob@~@~ @Mi/d~~@~~~@@Kff@~~y~n1@bc @  ~Sl~ @  ~~~v@t ~/@@t~@l-~u~ @m ~~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$1$1;->a:Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string/jumbo v1, "ttsctonScnea"

    const/4 v4, 0x3

    const-string/jumbo v1, "ntSmcteaneoc"

    const-string v1, "connectState"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$1$1;->b:Lcom/tencent/android/tpush/XGPushManager$1;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, v0, Lcom/tencent/android/tpush/XGPushManager$1;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    sget v1, Lcom/tencent/android/tpush/XGPushManager;->CONNECT_STATE_CONNECTED:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {v0, v1, v2}, Lcom/tencent/android/tpush/XGIOperateCallback;->onSuccess(Ljava/lang/Object;I)V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$1$1;->b:Lcom/tencent/android/tpush/XGPushManager$1;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/tencent/android/tpush/XGPushManager$1;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    sget v1, Lcom/tencent/android/tpush/XGPushManager;->CONNECT_STATE_NOT_CONNECTED:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-interface {v0, v1, v2}, Lcom/tencent/android/tpush/XGIOperateCallback;->onSuccess(Ljava/lang/Object;I)V

    :goto_0
    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-void
.end method
