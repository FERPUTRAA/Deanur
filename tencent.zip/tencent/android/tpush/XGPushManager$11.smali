.class Lcom/tencent/android/tpush/XGPushManager$11;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:J

.field final synthetic c:Landroid/content/Context;

.field final synthetic d:I

.field final synthetic e:Lcom/tencent/android/tpush/XGIOperateCallback;

.field final synthetic f:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;JLandroid/content/Context;ILcom/tencent/android/tpush/XGIOperateCallback;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$11;->a:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-wide p2, p0, Lcom/tencent/android/tpush/XGPushManager$11;->b:J

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p4, p0, Lcom/tencent/android/tpush/XGPushManager$11;->c:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput p5, p0, Lcom/tencent/android/tpush/XGPushManager$11;->d:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p6, p0, Lcom/tencent/android/tpush/XGPushManager$11;->e:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x6

    iput-object p7, p0, Lcom/tencent/android/tpush/XGPushManager$11;->f:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 10

    :try_start_0
    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "@.s~~aflc@f  ~1v@oM~@y @~ oo @ n@~i@~~~@@ @ mi~@ o 4b~@o~  ~ but~ K@~s bd l~//~ @~@-i~o@@~St~@~@"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$11;->a:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x6

    if-nez v0, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    const-string v0, ""

    const-string v0, ""

    :cond_0
    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-wide v0, p0, Lcom/tencent/android/tpush/XGPushManager$11;->b:J

    const/4 v8, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v9, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v8, 0x4

    move v9, v8

    cmp-long v5, v0, v3

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-gtz v5, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$11;->c:Landroid/content/Context;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v0

    :cond_1
    move-wide v5, v0

    const/4 v9, 0x1

    const/4 v8, 0x1

    cmp-long v0, v5, v3

    const/4 v9, 0x7

    if-ltz v0, :cond_3

    const/4 v8, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$11;->c:Landroid/content/Context;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedHttpAccountOperate(Landroid/content/Context;)Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x4

    if-eqz v0, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$11;->c:Landroid/content/Context;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/XGPushManager$11;->d:I

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v7, p0, Lcom/tencent/android/tpush/XGPushManager$11;->e:Lcom/tencent/android/tpush/XGIOperateCallback;

    move-wide v3, v5

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    move v5, v0

    move v5, v0

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-static/range {v1 .. v6}, Lcom/tencent/android/tpush/common/a;->a(Landroid/content/Context;Ljava/lang/String;JILcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto/16 :goto_0

    :cond_2
    const/4 v8, 0x6

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$11;->c:Landroid/content/Context;

    const/4 v8, 0x1

    move v9, v8

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    new-instance v1, Landroid/content/Intent;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$11;->c:Landroid/content/Context;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string/jumbo v3, "topmeam.nN.OUsoC4oeCnt.Vic..a.ticgncvA.dxiTd"

    const-string/jumbo v3, "rosnUnVcd.om4Ate.Ttacx..iadneC.c..ivOCNpoigt"

    const/4 v9, 0x5

    const-string v3, "ed.roC4.o.niTUCVi.nAdgvccOe.nttNaxcn.ai.motp"

    const-string v3, "com.tencent.android.xg.vip.action.ACCOUNT.V4"

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string v2, "bcImc"

    const-string v2, "Iccma"

    const/4 v9, 0x1

    const-string v2, "cuIac"

    const-string v2, "accId"

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v1, v2, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-string v2, "cpyoca"

    const-string/jumbo v2, "ycecoa"

    const-string v2, "aeqccK"

    const-string v2, "accKey"

    const/4 v9, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string/jumbo v0, "opsrbaepeyt"

    const-string v0, "aepTpbyoert"

    const/4 v9, 0x5

    const-string/jumbo v0, "oaemteeyTrp"

    const-string/jumbo v0, "operateType"

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    iget v2, p0, Lcom/tencent/android/tpush/XGPushManager$11;->d:I

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const-string/jumbo v0, "uctnoao"

    const-string v0, "antoucu"

    const/4 v9, 0x6

    const-string/jumbo v0, "ucaotbc"

    const-string v0, "account"

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$11;->a:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {v2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v8, 0x3

    move v9, v8

    const-string v0, "dcctBeupuFaceao"

    const-string/jumbo v0, "tdcakFopecacBeu"

    const/4 v9, 0x6

    const-string v0, "aFnedacpcucekto"

    const-string v0, "accountFeedBack"

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$11;->f:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string/jumbo v0, "qcameaqN"

    const-string/jumbo v0, "qNacpame"

    const/4 v9, 0x1

    const-string v0, "eNskmcap"

    const-string/jumbo v0, "packName"

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$11;->c:Landroid/content/Context;

    const/4 v9, 0x7

    const/4 v8, 0x1

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-static {v2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$11;->c:Landroid/content/Context;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$11;->e:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    const/4 v3, 0x3

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {v0, v1, v2, v3}, Lcom/tencent/android/tpush/XGPushManager;->safeSendQuest(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_0

    :cond_3
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string v1, "etsccssd anoITeth  !e"

    const/4 v9, 0x5

    const-string/jumbo v1, "sIem!es dts hoe Tccan"

    const-string v1, "The accessId not set!"

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    or-int/2addr v9, v8

    throw v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    return-void
.end method
