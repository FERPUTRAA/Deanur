.class public Lcom/tencent/android/tpush/c/a$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/c/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field private a:Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;

.field private volatile b:J


# direct methods
.method protected constructor <init>(Lcom/tencent/tpns/mqttchannel/services/BaseMqttClientService;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->b()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/common/AppInfos;->getAppContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/c/a;->a(Landroid/content/Context;)Landroid/content/Context;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;

    const/4 v2, 0x0

    or-int/2addr v3, v2

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->b()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {v0, v1, p1}, Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;-><init>(Landroid/content/Context;Lcom/tencent/tpns/mqttchannel/services/BaseMqttClientService;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/c/a$a;->a:Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo p1, "rrsnqO eC Iotpp-tlMglmiMtetrIsaaa"

    const-string/jumbo p1, "pas-tO pIrgretrMaaenmtlMinCIqol t"

    const/4 v3, 0x6

    const-string p1, " irmI mqMnIttptlreagaCtpMoOnaeer-"

    const-string p1, "IMqttClientManager - OperatorImpl"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string/jumbo v0, "tSCMoqiumrsipeinst ,neaoxlnc e wbe#ctnlautvl"

    const-string/jumbo v0, "uSCmwlirqieltispc,esnx enutnvlMe at#na bteco"

    const/4 v3, 0x2

    const-string/jumbo v0, "nauvebpulteiCwe e,tcSqlo#a extisb nstenrcnMi"

    const-string v0, "#unexception, baseMqttClientService was null"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    new-instance p1, Ljava/lang/Exception;

    const/4 v3, 0x4

    const/4 v2, 0x1

    invoke-direct {p1, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    throw p1
.end method

.method static synthetic a(Lcom/tencent/android/tpush/c/a$a;)Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ t@m u@@~.~@o~ //   @1@~li~~~irb@~~u ~@@~n-i~S~yfbo~ao@4@@~ @~oK  l ~@~ b~@~ f@o Mtc o  v@~s@@d"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lcom/tencent/android/tpush/c/a$a;->a:Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method


# virtual methods
.method public a(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/c/a$a;->a:Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;->getIMqttService()Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService$Stub;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {v0, p1}, Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService;->startConnect(Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttCallback;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v0, "anognrtpeMetiqCMaI"

    const-string v0, "gatCoeMnttiMIqnrea"

    const-string v0, "aneiqMtrqtltgCnaIe"

    const-string v0, "IMqttClientManager"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    return-void
.end method

.method public a(Ljava/lang/String;Ljava/lang/String;Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v8, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string v1, "CtenlbIaMaMtinqetr"

    const/4 v8, 0x1

    const-string/jumbo v1, "tgsreaItlanCqtiMeM"

    const-string v1, "IMqttClientManager"

    const/4 v8, 0x3

    const/4 v7, 0x2

    if-nez p2, :cond_1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x1

    if-eqz p3, :cond_0

    :try_start_0
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string p1, "co olnunnestaalodshtbnetauPwtnutl  il o "

    const/4 v8, 0x5

    const-string/jumbo p1, "n dmocaabD no sioaenwlhP ttnsuloleltn tu"

    const-string/jumbo p1, "sendPublishData content not alow to null"

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/16 p2, -0x65

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {p3, p2, p1}, Lcom/tencent/tpns/mqttchannel/core/a/b;->handleCallback(ILjava/lang/String;)V

    :cond_0
    const/4 v7, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x4

    return-void

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-instance v2, Lcom/tencent/tpns/mqttchannel/core/common/data/Request;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    iget-wide v3, p0, Lcom/tencent/android/tpush/c/a$a;->b:J

    const/4 v8, 0x6

    const/4 v7, 0x1

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v8, 0x0

    const-wide/16 v5, 0x1

    const-wide/16 v5, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    add-long/2addr v3, v5

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    iput-wide v3, p0, Lcom/tencent/android/tpush/c/a$a;->b:J

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-direct {v2, v3, v4, p1, p2}, Lcom/tencent/tpns/mqttchannel/core/common/data/Request;-><init>(JLjava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    const/4 p1, 0x5

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    iput p1, v2, Lcom/tencent/tpns/mqttchannel/core/common/data/Request;->type:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v8, 0x0

    const/4 v7, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/c/a$a;->a:Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;->getIMqttService()Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService$Stub;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {p1, v2, p3}, Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService;->sendPublishData(Lcom/tencent/tpns/mqttchannel/core/common/data/Request;Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttCallback;)V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    goto :goto_0

    :catch_0
    move-exception p1

    :try_start_2
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-static {v1, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v8, 0x3

    const/4 v7, 0x7

    invoke-static {v1, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v8, 0x0

    return-void
.end method

.method public a(Ljava/lang/String;Lorg/json/JSONObject;Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x1

    const/4 v6, 0x2

    const-string/jumbo v1, "irnqoMagCIMetnetat"

    const-string v1, "IMqttClientManager"

    const/4 v6, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-nez p2, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz p3, :cond_0

    :try_start_0
    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string/jumbo p1, "lteuob nt meps PRanu ntwdrlols naosqo"

    const-string/jumbo p1, "roslltsptooPwoRtndu njaanq ne lse m u"

    const/4 v7, 0x0

    const-string/jumbo p1, "qnosneutuwlPoalomtend  Rsr  selnjoat "

    const-string/jumbo p1, "sendRequest jsonParm not alow to null"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/16 p2, -0x65

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p3, p2, p1}, Lcom/tencent/tpns/mqttchannel/core/a/b;->handleCallback(ILjava/lang/String;)V

    :cond_0
    const/4 v7, 0x5

    return-void

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-wide v2, p0, Lcom/tencent/android/tpush/c/a$a;->b:J

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v7, 0x2

    const-wide/16 v4, 0x1

    const-wide/16 v4, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    add-long/2addr v2, v4

    const/4 v7, 0x4

    const/4 v6, 0x2

    iput-wide v2, p0, Lcom/tencent/android/tpush/c/a$a;->b:J

    const/4 v7, 0x3

    iput-wide v2, p3, Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;->requestId:J

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-instance v4, Lcom/tencent/tpns/mqttchannel/core/common/data/Request;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-direct {v4, v2, v3, p1, p2}, Lcom/tencent/tpns/mqttchannel/core/common/data/Request;-><init>(JLjava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/4 p1, 0x6

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput p1, v4, Lcom/tencent/tpns/mqttchannel/core/common/data/Request;->type:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/c/a$a;->a:Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {p1}, Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;->getIMqttService()Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService$Stub;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-interface {p1, v4, p3}, Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService;->sendRequest(Lcom/tencent/tpns/mqttchannel/core/common/data/Request;Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttCallback;)V
    :try_end_1
    .catch Landroid/os/RemoteException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    goto :goto_0

    :catch_0
    move-exception p1

    :try_start_2
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {v1, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v7, 0x6

    invoke-static {v1, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    return-void
.end method

.method public b(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/c/a$a;->a:Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;->getIMqttService()Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService$Stub;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-interface {v0, p1}, Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService;->ping(Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttCallback;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string v0, "atqCMnrpenMailqtIe"

    const-string/jumbo v0, "naIaMleMqtCtnqeirg"

    const/4 v3, 0x7

    const-string v0, "atMerMeqqnICnligtt"

    const-string v0, "IMqttClientManager"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public c(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/c/a$a$1;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v1, p0, p1}, Lcom/tencent/android/tpush/c/a$a$1;-><init>(Lcom/tencent/android/tpush/c/a$a;Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v0, "testCtlIinaMeMgnaq"

    const/4 v3, 0x5

    const-string v0, "MqsantreintatIMeCg"

    const-string v0, "IMqttClientManager"

    const/4 v2, 0x2

    or-int/2addr v3, v2

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public d(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/c/a$a;->a:Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;->getIMqttService()Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService$Stub;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {v0, p1}, Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService;->getConnectState(Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttCallback;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v0, "qtemrteMnnICtaliaM"

    const-string v0, "IMqttClientManager"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    return-void
.end method

.method public e(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V
    .locals 5

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/c/a$a;->a:Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;->getIMqttService()Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService$Stub;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {v0, p1}, Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService;->isValidClientId(Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttCallback;)V
    :try_end_0
    .catch Landroid/os/RemoteException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo v1, "qnCtoeeMrtmMatnglI"

    const-string/jumbo v1, "qaemMrnilMItCtnteg"

    const/4 v4, 0x7

    const-string v1, "MlainbtaMetnqtrIeC"

    const-string v1, "IMqttClientManager"

    const/4 v4, 0x7

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v1, -0x1

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {p1, v1, v0}, Lcom/tencent/tpns/mqttchannel/core/a/b;->callback(ILjava/lang/String;)V

    :goto_0
    const/4 v4, 0x6

    return-void
.end method
