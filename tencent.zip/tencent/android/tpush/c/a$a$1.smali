.class Lcom/tencent/android/tpush/c/a$a$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/c/a$a;->c(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;

.field final synthetic b:Lcom/tencent/android/tpush/c/a$a;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/c/a$a;Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/c/a$a$1;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpush/c/a$a$1;->a:Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;

    const/4 v1, 0x0

    const/4 v0, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@@s o~-@~~4 1~ @o t~ ~@oo~do@@S~ ~/c~ @ f@/ru  b @bfl@b~ @y~Mv li@~  noi~a~.t ~~@~~ @@@@~@i@~ms~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/c/a$a$1;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v4, 0x7

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/c/a$a;->a(Lcom/tencent/android/tpush/c/a$a;)Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/tencent/tpns/mqttchannel/core/services/MqttServiceImpl;->getIMqttService()Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService$Stub;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/c/a$a$1;->a:Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {v0, v1}, Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttService;->stopConnect(Lcom/tencent/tpns/mqttchannel/core/common/inf/IMqttCallback;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v1, "MesClentMiaIttqngr"

    const/4 v4, 0x5

    const-string v1, "CiMmttatalqngInere"

    const-string v1, "IMqttClientManager"

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-void
.end method
