.class Lcom/tencent/android/tpush/c/a$b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/c/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# static fields
.field public static a:Lcom/tencent/android/tpush/c/a;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/android/tpush/c/a;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/tencent/android/tpush/c/a;-><init>(Lcom/tencent/android/tpush/c/a$1;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    sput-object v0, Lcom/tencent/android/tpush/c/a$b;->a:Lcom/tencent/android/tpush/c/a;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-void
.end method
