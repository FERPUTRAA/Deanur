.class public Lcom/tencent/android/tpush/c/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/c/a$a;,
        Lcom/tencent/android/tpush/c/a$c;,
        Lcom/tencent/android/tpush/c/a$b;
    }
.end annotation


# static fields
.field private static c:Landroid/content/Context;


# instance fields
.field public a:Lcom/tencent/android/tpush/c/a$c;

.field public b:Lcom/tencent/android/tpush/c/a$a;


# direct methods
.method private constructor <init>()V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/common/AppInfos;->getAppContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    sput-object v0, Lcom/tencent/android/tpush/c/a;->c:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v0, Lcom/tencent/android/tpush/c/a$c;

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    const/4 v1, 0x0

    move v4, v1

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Lcom/tencent/android/tpush/c/a$c;-><init>(Lcom/tencent/android/tpush/c/a$1;)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/c/a;->a:Lcom/tencent/android/tpush/c/a$c;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v1, Lcom/tencent/android/tpush/c/a$a;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v1, v0}, Lcom/tencent/android/tpush/c/a$a;-><init>(Lcom/tencent/tpns/mqttchannel/services/BaseMqttClientService;)V

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const-string v2, "iIsalsoaciflai uMti/: teg qrnffMnrentastCdne"

    const-string/jumbo v2, "ifsCnleilrf ueadInMia :nniMefoa aret/tsgcttq"

    const/4 v4, 0x4

    const-string v2, "giMmtadacI:utnrCilneae0lqeMfoarfi/it nstf e "

    const-string/jumbo v2, "init IMqttClientManager failed\uff0c reason:"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v1, "ClMmtgItraMitaeeqn"

    const/4 v4, 0x2

    const-string v1, "CMnMorttilIaneqtge"

    const-string v1, "IMqttClientManager"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/android/tpush/c/a$1;)V
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/android/tpush/c/a;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Landroid/content/Context;)Landroid/content/Context;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "S~@  bM@~~o@ao~~n~@r4ytf -v~ i /@@~~ l1u@~bb .i~  d ~fos@clo~K@~ ~i@ /ot  mb@~~@~@@@~@  ~@@~o~@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    sput-object p0, Lcom/tencent/android/tpush/c/a;->c:Landroid/content/Context;

    const/4 v1, 0x2

    return-object p0
.end method

.method public static a()Lcom/tencent/android/tpush/c/a;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/c/a$b;->a:Lcom/tencent/android/tpush/c/a;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method static synthetic b()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/c/a;->c:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method
