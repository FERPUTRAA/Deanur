.class public Lcom/tencent/android/tpush/c/a$c;
.super Lcom/tencent/tpns/mqttchannel/services/BaseMqttClientService;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/c/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# instance fields
.field private a:Lcom/tencent/android/tpush/service/channel/a;


# direct methods
.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/mqttchannel/services/BaseMqttClientService;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    new-instance v0, Lcom/tencent/android/tpush/service/channel/a;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-direct {v0}, Lcom/tencent/android/tpush/service/channel/a;-><init>()V

    const/4 v1, 0x1

    move v2, v1

    iput-object v0, p0, Lcom/tencent/android/tpush/c/a$c;->a:Lcom/tencent/android/tpush/service/channel/a;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/android/tpush/c/a$1;)V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/tencent/android/tpush/c/a$c;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onConnectComplete(Z)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "1-s~@fS  o.~cl~n ~@~ri~u@Momb i@dat~o@ @o/ @@~s~@@@b~@@ f~lvb ~o~~K@ ~o ~@~ y@ / ~ 4~@ti  @@ ~~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const-string/jumbo v1, "nes:emnCocie enolpccRtntoenCst"

    const-string/jumbo v1, "iocmoeCtsnn tCp:nenccenemetRoo"

    const-string/jumbo v1, "onConnectComplete isReconnect:"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string v0, "SlpaotaMimraltn-e tIIM egttqCn"

    const-string v0, "aqemea  lmSaMItngMirIptlttCn-t"

    const/4 v3, 0x3

    const-string v0, "aetttbleanMra t tiMeSIpm-IqnCg"

    const-string v0, "IMqttClientManager - StateImpl"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public onConnectionLost()V
    .locals 4

    const/4 v3, 0x7

    const-string v0, "CeegtnuSIiIMt-latmaqo plMetta "

    const-string/jumbo v0, "mgetoqtt lIipenaeSt-C tMMaalnI"

    const/4 v3, 0x0

    const-string v0, "IMqttClientManager - StateImpl"

    const/4 v3, 0x2

    const-string/jumbo v1, "tooiosopbCtnLnnc"

    const-string v1, "CttnnbnsooLoocin"

    const/4 v3, 0x3

    const-string/jumbo v1, "oonLnCotqninotes"

    const-string/jumbo v1, "onConnectionLost"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    return-void
.end method

.method public onHeartBeat()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const-string v0, "SCsMginetel- IIeaatMtmquntrpat"

    const-string v0, "et  tauqMtCiItnlSmra-MnteeaIgp"

    const-string/jumbo v0, "neam -etIrSttgltmlMqtaeCpinaM "

    const-string v0, "IMqttClientManager - StateImpl"

    const/4 v2, 0x2

    move v3, v2

    const-string v1, "Brteheapa"

    const/4 v3, 0x7

    const-string v1, "ateroaeth"

    const-string v1, "heartBeat"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->b()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/common/AppInfos;->getAppContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/c/a;->a(Landroid/content/Context;)Landroid/content/Context;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->b()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/a;->b(Landroid/content/Context;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->b()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/service/util/g;->d(Landroid/content/Context;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method

.method public onMessageArrived(Ljava/lang/String;Ljava/lang/String;)V
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    const-string v1, "co:r bngssriqteiMpd:Aeev"

    const-string/jumbo v1, "p eMevoaqigintr:d:rcsAes"

    const/4 v9, 0x2

    const-string v1, ":vo eAuMtniegcorpa:dsser"

    const-string/jumbo v1, "onMessageArrived: topic:"

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    const-string/jumbo v1, "m,aes:epss"

    const-string/jumbo v1, "s,se:mase "

    const/4 v9, 0x3

    const-string/jumbo v1, "m ags:s,qe"

    const-string v1, ", message:"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-string v1, " esilCIIpM-rg tmmqtttnMnalatee"

    const-string/jumbo v1, "leSmg atnm-netrtIMqpetI lCaitM"

    const/4 v9, 0x4

    const-string v1, "aMgmmi lr eCateeSMn-apttnqItlt"

    const-string v1, "IMqttClientManager - StateImpl"

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->b()Landroid/content/Context;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-nez v0, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/common/AppInfos;->getAppContext()Landroid/content/Context;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/c/a;->a(Landroid/content/Context;)Landroid/content/Context;

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->b()Landroid/content/Context;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x0

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/common/j;->b(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-eqz p1, :cond_1

    :try_start_0
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    new-instance p1, Lcom/tencent/android/tpush/service/protocol/k;

    const/4 v8, 0x2

    or-int/2addr v9, v8

    invoke-direct {p1}, Lcom/tencent/android/tpush/service/protocol/k;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {p1, p2}, Lcom/tencent/android/tpush/service/protocol/k;->a(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/service/b/a;->a()Lcom/tencent/android/tpush/service/b/a;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v2, p1, Lcom/tencent/android/tpush/service/protocol/k;->b:Ljava/util/ArrayList;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-wide v3, p1, Lcom/tencent/android/tpush/service/protocol/k;->a:J

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/c/a$c;->a:Lcom/tencent/android/tpush/service/channel/a;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v0, v2, v3, v4, p1}, Lcom/tencent/android/tpush/service/b/a;->a(Ljava/util/ArrayList;JLcom/tencent/android/tpush/service/channel/a;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string v0, "ecesoh f piodgslodua"

    const-string/jumbo v0, "miahosdgsp e ulfcoed"

    const/4 v9, 0x7

    const-string/jumbo v0, "ssddebi m gehufplaco"

    const-string v0, "decode push msg fail"

    const/4 v9, 0x1

    const/4 v8, 0x7

    invoke-static {v1, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x5

    move v9, v8

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->b()Landroid/content/Context;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/16 v3, -0x65

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string v0, "Meoevius:nreagrds"

    const-string/jumbo v0, "onMessageArrived:"

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v9, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v9, 0x5

    const-string v7, "ebpri"

    const-string v7, "berni"

    const/4 v9, 0x3

    const-string/jumbo v7, "inner"

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-static/range {v2 .. v7}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x0

    return-void
.end method
