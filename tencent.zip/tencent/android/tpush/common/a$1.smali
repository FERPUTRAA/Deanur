.class Lcom/tencent/android/tpush/common/a$1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/common/a;->a(Landroid/content/Context;Ljava/lang/String;JILcom/tencent/android/tpush/XGIOperateCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/XGIOperateCallback;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v0, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/common/a$1;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onFailure(ILjava/lang/String;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~tsr~b@l ~-sKo1 y@@oc @M/@~~ foo bo@@iuo~@~ ~ b@i ~ ~@~ @@@~   @~d@/ni~ ~4~ lf~@S~@~v~~ a@ t@.@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/common/a$1;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x2

    invoke-interface {v0, v1, p1, p2}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    return-void
.end method

.method public onSuccess(Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x3

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-nez v1, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v1, Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string p1, "e_cmtdes"

    const-string p1, "_osetecd"

    const/4 v4, 0x5

    const-string p1, "edoeocr_"

    const-string/jumbo p1, "ret_code"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/common/a$1;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {p1, v0, v1}, Lcom/tencent/android/tpush/XGIOperateCallback;->onSuccess(Ljava/lang/Object;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    return-void

    :catchall_0
    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpush/common/a$1;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v3, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz p1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x2

    sget-object v1, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_INNER_EXCEPTION_OCCUR:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-static {v1}, Lcom/tencent/android/tpush/common/ReturnCode;->errCodeToMsg(I)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {p1, v0, v2, v1}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void
.end method
