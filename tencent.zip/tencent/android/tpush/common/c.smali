.class public Lcom/tencent/android/tpush/common/c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/common/c$a;
    }
.end annotation


# static fields
.field private static a:I

.field private static b:I

.field private static c:Landroid/os/Handler;

.field private static d:Ljava/util/concurrent/locks/ReentrantLock;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x1

    new-instance v0, Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    invoke-direct {v0}, Ljava/util/concurrent/locks/ReentrantLock;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    sput-object v0, Lcom/tencent/android/tpush/common/c;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method static synthetic a()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s M~~r~oc~~~a .l~b@1~o@  @@~  fo~@@@s~@i ~ df @ @S@@~ b-~oy~n~/o ~ t~   t4Kl@~ /im@@~o~ib~@@v@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget v0, Lcom/tencent/android/tpush/common/c;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    return v0
.end method

.method static synthetic a(I)I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget v0, Lcom/tencent/android/tpush/common/c;->b:I

    const/4 v2, 0x0

    sub-int/2addr v0, p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    sput v0, Lcom/tencent/android/tpush/common/c;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return v0
.end method

.method public static a(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/c;->b(Landroid/content/Context;I)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public static a(Landroid/content/Context;I)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo v0, "rurmneahgahe  :koe icdwnaelu rb gc"

    const-string/jumbo v0, "rgswuihc:a bonr e aancee uk rdgehl"

    const/4 v5, 0x5

    const-string v0, "a bcou c eruehkaolg:eeowingrna dh "

    const-string v0, "change huawei badge unlock error: "

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string v1, "glaUmbdiBs"

    const-string v1, "gaBmdslUit"

    const-string/jumbo v1, "lsBdgaueUi"

    const-string v1, "BadgeUtils"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHuaWei()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-nez v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHonor()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-nez v2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isEmuiOrOhosVersion()Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v2, :cond_2

    :cond_0
    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    sget-object v2, Lcom/tencent/android/tpush/common/c;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-virtual {v2}, Ljava/util/concurrent/locks/ReentrantLock;->lock()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    sget-object v2, Lcom/tencent/android/tpush/common/c;->c:Landroid/os/Handler;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v2, Lcom/tencent/android/tpush/common/c$a;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v2, p0}, Lcom/tencent/android/tpush/common/c$a;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    sput-object v2, Lcom/tencent/android/tpush/common/c;->c:Landroid/os/Handler;

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    sget p0, Lcom/tencent/android/tpush/common/c;->b:I

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    add-int/2addr p0, v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    sput p0, Lcom/tencent/android/tpush/common/c;->b:I

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget p0, Lcom/tencent/android/tpush/common/c;->a:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    add-int/2addr p0, p1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x4

    sput p0, Lcom/tencent/android/tpush/common/c;->a:I

    new-instance p0, Landroid/os/Message;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {p0}, Landroid/os/Message;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iput v2, p0, Landroid/os/Message;->what:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    sget-object p1, Lcom/tencent/android/tpush/common/c;->c:Landroid/os/Handler;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const-wide/16 v2, 0xc8

    const-wide/16 v2, 0xc8

    const/4 v5, 0x4

    const-wide/16 v2, 0xc8

    const-wide/16 v2, 0xc8

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1, p0, v2, v3}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    sget-object p0, Lcom/tencent/android/tpush/common/c;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    goto :goto_0

    :catchall_1
    move-exception p0

    :try_start_2
    const/4 v5, 0x5

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v2, "orrheaapneag cdbi:e wrgoh u"

    const-string v2, "bg wo ga oradenceaeher:ihru"

    const/4 v5, 0x4

    const-string v2, "change huawei badge error: "

    const/4 v5, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    :try_start_3
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    sget-object p0, Lcom/tencent/android/tpush/common/c;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto :goto_1

    :catchall_2
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void

    :catchall_3
    move-exception p0

    :try_start_4
    const/4 v5, 0x0

    const/4 v4, 0x4

    sget-object p1, Lcom/tencent/android/tpush/common/c;->d:Ljava/util/concurrent/locks/ReentrantLock;

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/util/concurrent/locks/ReentrantLock;->unlock()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    const/4 v5, 0x0

    goto :goto_2

    :catchall_4
    move-exception p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_2
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    throw p0
.end method

.method static synthetic a(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/common/c;->c(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic b()I
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget v0, Lcom/tencent/android/tpush/common/c;->a:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return v0
.end method

.method static synthetic b(I)I
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    sput p0, Lcom/tencent/android/tpush/common/c;->a:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x7

    return p0
.end method

.method public static b(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/c;->b(Landroid/content/Context;I)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/c;->d(Landroid/content/Context;I)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/c;->e(Landroid/content/Context;I)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public static b(Landroid/content/Context;I)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHuaWei()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHonor()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isEmuiOrOhosVersion()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    if-eqz v0, :cond_2

    :cond_0
    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    sget-object v0, Lcom/tencent/android/tpush/common/c;->c:Landroid/os/Handler;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    new-instance v0, Lcom/tencent/android/tpush/common/c$a;

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/common/c$a;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/android/tpush/common/c;->c:Landroid/os/Handler;

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    new-instance p0, Landroid/os/Message;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-direct {p0}, Landroid/os/Message;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput v0, p0, Landroid/os/Message;->what:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput p1, p0, Landroid/os/Message;->arg1:I

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object p1, Lcom/tencent/android/tpush/common/c;->c:Landroid/os/Handler;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1, p0}, Landroid/os/Handler;->sendMessage(Landroid/os/Message;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string/jumbo v0, "ourgrth qeeabarb i d ws:"

    const-string/jumbo v0, "uebtdb a:ersi ahroregw  "

    const/4 v2, 0x3

    const-string v0, "a sruto: ghirsw re daeee"

    const-string/jumbo v0, "set huawei badge error: "

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string p1, "eilmgstdua"

    const-string p1, "Udesglutia"

    const/4 v2, 0x1

    const-string p1, "daiBotsleg"

    const-string p1, "BadgeUtils"

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic b(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/common/c;->d(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic c()Landroid/os/Handler;
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/common/c;->c:Landroid/os/Handler;

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public static c(Landroid/content/Context;I)V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    if-gez p1, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/c;->b(Landroid/content/Context;I)V

    const/4 v1, 0x5

    const/4 v0, 0x6

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/c;->e(Landroid/content/Context;I)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/c;->d(Landroid/content/Context;I)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    return-void
.end method

.method private static c(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    new-instance v0, Landroid/os/Bundle;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v1, "akacebp"

    const-string/jumbo v1, "ppkacae"

    const/4 v6, 0x4

    const-string/jumbo v1, "package"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const-string/jumbo v1, "sulcq"

    const-string v1, "clsqa"

    const/4 v6, 0x1

    const-string/jumbo v1, "lapsc"

    const-string v1, "class"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->q(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string v3, "bmNregauqbgstd"

    const-string v3, "absNubemgrtged"

    const-string/jumbo v3, "tbsmNggudreeba"

    const-string v3, "getbadgeNumber"

    const/4 v6, 0x3

    const/4 v4, 0x5

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x2

    invoke-virtual {v1, v2, v3, v4, v0}, Landroid/content/ContentResolver;->call(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string v2, "euammgrembd"

    const-string/jumbo v2, "mdrmgeeunab"

    const/4 v6, 0x2

    const-string v2, "bamuonedegr"

    const-string v2, "badgenumber"

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v3, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    move v1, v3

    move v1, v3

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    add-int/2addr v1, p2

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-gez v1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_1

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    move v3, v1

    move v3, v1

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0, v2, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string/jumbo p2, "naecgbbade_o"

    const-string p2, "debnoa_hgeca"

    const/4 v6, 0x7

    const-string p2, "a_gahcuedbge"

    const-string p2, "change_badge"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p0, p1, p2, v4, v0}, Landroid/content/ContentResolver;->call(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    return-void
.end method

.method public static d(Landroid/content/Context;I)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/common/j;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v1, "oppo"

    const-string/jumbo v1, "oopp"

    const/4 v3, 0x4

    const-string/jumbo v1, "popo"

    const-string/jumbo v1, "oppo"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v1, Lcom/tencent/android/tpush/common/c$3;

    const/4 v3, 0x7

    invoke-direct {v1, p1, p0}, Lcom/tencent/android/tpush/common/c$3;-><init>(ILandroid/content/Context;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method private static d(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Landroid/os/Bundle;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v0}, Landroid/os/Bundle;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const-string/jumbo v1, "ppcebka"

    const-string v1, "gackpbe"

    const/4 v4, 0x2

    const-string/jumbo v1, "kqaacgp"

    const-string/jumbo v1, "package"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo v1, "slscu"

    const-string v1, "cuals"

    const/4 v4, 0x2

    const-string/jumbo v1, "scams"

    const-string v1, "class"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->q(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/os/BaseBundle;->putString(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    or-int/2addr v4, v3

    const-string v1, "eabgonrpemu"

    const-string/jumbo v1, "ruaebmdpgen"

    const-string/jumbo v1, "nbadgbebrue"

    const-string v1, "badgenumber"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1, p2}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const-string/jumbo p2, "q_gdgeuaacbh"

    const-string p2, "eabnh_cgqgda"

    const/4 v4, 0x4

    const-string p2, "bcge_gapadne"

    const-string p2, "change_badge"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {p0, p1, p2, v1, v0}, Landroid/content/ContentResolver;->call(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void
.end method

.method public static e(Landroid/content/Context;I)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/common/j;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const-string/jumbo v1, "voiv"

    const-string/jumbo v1, "vivo"

    const/4 v3, 0x6

    const-string/jumbo v1, "ivov"

    const-string/jumbo v1, "vivo"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/common/c$4;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v1, p1, p0}, Lcom/tencent/android/tpush/common/c$4;-><init>(ILandroid/content/Context;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :cond_0
    return-void
.end method

.method static synthetic f(Landroid/content/Context;I)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/c;->h(Landroid/content/Context;I)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic g(Landroid/content/Context;I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/c;->i(Landroid/content/Context;I)V

    const/4 v0, 0x1

    xor-int/2addr v1, v0

    return-void
.end method

.method private static h(Landroid/content/Context;I)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHuaWei()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHonor()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isEmuiOrOhosVersion()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz v0, :cond_1

    :cond_0
    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v1, Lcom/tencent/android/tpush/common/c$1;

    const/4 v3, 0x0

    invoke-direct {v1, p1, p0}, Lcom/tencent/android/tpush/common/c$1;-><init>(ILandroid/content/Context;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method private static i(Landroid/content/Context;I)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHuaWei()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHonor()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isEmuiOrOhosVersion()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v1, Lcom/tencent/android/tpush/common/c$2;

    const/4 v3, 0x3

    invoke-direct {v1, p1, p0}, Lcom/tencent/android/tpush/common/c$2;-><init>(ILandroid/content/Context;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :cond_1
    const/4 v3, 0x2

    return-void
.end method
