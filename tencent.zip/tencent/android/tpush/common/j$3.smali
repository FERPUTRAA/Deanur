.class Lcom/tencent/android/tpush/common/j$3;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/common/j;->f(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/common/j$3;->a:Landroid/content/Context;

    const/4 v0, 0x3

    move v1, v0

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " /s @  u@oco@ ~~s/b@~@ Sr @a~ o lf~ ~ K@@~oM-~ o@@~@~t~~@~ l~t@~~@y~f  4v@.~@mo~@d@~1  bin~@b~ii"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "Ulti"

    const-string v0, "Util"

    const/4 v4, 0x2

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/common/j$3;->a:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->c(Landroid/content/Context;)I

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eq v1, v2, :cond_0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v1, " slm  oSccra r)-Litaetno2>ts(Ave"

    const-string v1, " rsnite>ta Ssti2)cLv Aaor(le-oc "

    const/4 v4, 0x1

    const-string/jumbo v1, "oslaoAro av te ict2ci(>-Ser)cLt "

    const-string v1, "Action2 -> start Local Service()"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/common/j$3;->a:Landroid/content/Context;

    const/4 v4, 0x0

    const/4 v3, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/service/b;->a(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo v2, "nrdSrbWeieoctvt akmSaehCnmroirom"

    const-string/jumbo v2, "retmS CnrevgniotkdmcaaSmoeWrroih"

    const/4 v4, 0x5

    const-string v2, "CcentmuotigSrd mvnaireorkWhroeaS"

    const-string v2, "CommonWorkingThread StartService"

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    return-void
.end method
