.class public Lcom/tencent/android/tpush/common/h;
.super Ljava/lang/Object;


# static fields
.field private static volatile a:Lcom/tencent/android/tpush/common/h;


# instance fields
.field private b:Z

.field private c:Z

.field private d:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x0

    move v1, v0

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/tencent/android/tpush/common/h;->b:Z

    const/4 v2, 0x2

    const/4 v1, 0x5

    iput-boolean v0, p0, Lcom/tencent/android/tpush/common/h;->c:Z

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/4 v0, -0x1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput v0, p0, Lcom/tencent/android/tpush/common/h;->d:I

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/common/d;->a()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/tencent/android/tpush/common/h;->b:Z

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/d/a;->a(Landroid/content/Context;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-boolean p1, p0, Lcom/tencent/android/tpush/common/h;->c:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/tencent/android/tpush/common/h;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~sS v@~ ~@f  @a~o~@~ ~/t~@ ~M@~~o~m~iK~ o o@~  d@o@ bc@ ~ifo@ur/b@ @ l1@s4-@ ln~y b@@~.t@~i @~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/tencent/android/tpush/common/h;->a:Lcom/tencent/android/tpush/common/h;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-class v0, Lcom/tencent/android/tpush/common/h;

    const-class v0, Lcom/tencent/android/tpush/common/h;

    const/4 v3, 0x7

    const-class v0, Lcom/tencent/android/tpush/common/h;

    const-class v0, Lcom/tencent/android/tpush/common/h;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v1, Lcom/tencent/android/tpush/common/h;->a:Lcom/tencent/android/tpush/common/h;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v1, Lcom/tencent/android/tpush/common/h;

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/common/h;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    sput-object v1, Lcom/tencent/android/tpush/common/h;->a:Lcom/tencent/android/tpush/common/h;

    :cond_0
    const/4 v2, 0x2

    move v3, v2

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    sget-object p0, Lcom/tencent/android/tpush/common/h;->a:Lcom/tencent/android/tpush/common/h;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object p0
.end method


# virtual methods
.method public a()Z
    .locals 3

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/tencent/android/tpush/common/h;->c:Z

    const/4 v2, 0x0

    const/4 v1, 0x7

    return v0
.end method
