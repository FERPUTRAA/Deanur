.class Lcom/tencent/android/tpush/common/c$4;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/common/c;->e(Landroid/content/Context;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Landroid/content/Context;


# direct methods
.method constructor <init>(ILandroid/content/Context;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p1, p0, Lcom/tencent/android/tpush/common/c$4;->a:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/tencent/android/tpush/common/c$4;->b:Landroid/content/Context;

    const/4 v0, 0x1

    shl-int/2addr v1, v0

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~ s~l ~ K~@~~  @ ~@n  ~@~~ub  ~// Msi-oi @ i~@t@r@~aly .@ @ov~d@~~@cob@o@1@~Sf@o~~@t@~ @o~4~m@f "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    const-string/jumbo v0, "ilgmUetssd"

    const-string/jumbo v0, "tdseiaglsU"

    const/4 v5, 0x4

    const-string/jumbo v0, "tldioesgaU"

    const-string v0, "BadgeUtils"

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string/jumbo v2, "igam ee tvobvds"

    const/4 v5, 0x0

    const-string v2, "gtoedbvbea s iv"

    const-string/jumbo v2, "set vivo badge "

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    iget v2, p0, Lcom/tencent/android/tpush/common/c$4;->a:I

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x1

    or-int/2addr v5, v4

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string/jumbo v2, "oLPPoNOelA_IcGnICAHUOa._iFuATEInCrMtaCTANcIN_NNOThI"

    const/4 v5, 0x5

    const-string/jumbo v2, "lMoCaIuFINIUOanEihANGACC_rnHNTOt..NLIccTT_e_INAPAPu"

    const-string/jumbo v2, "launcher.action.CHANGE_APPLICATION_NOTIFICATION_NUM"

    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v2, "gemaekbpcap"

    const-string v2, "gmeekbacapa"

    const/4 v5, 0x4

    const-string/jumbo v2, "pNeakameqcg"

    const-string/jumbo v2, "packageName"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/common/c$4;->b:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v2, "aesscausl"

    const-string v2, "csleaausN"

    const/4 v5, 0x2

    const-string/jumbo v2, "ssmmcNael"

    const-string v2, "className"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpush/common/c$4;->b:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v3}, Lcom/tencent/android/tpush/common/j;->q(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string v2, "cmnnotfNitoaoiu"

    const-string/jumbo v2, "notificationNum"

    const/4 v5, 0x2

    iget v3, p0, Lcom/tencent/android/tpush/common/c$4;->a:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    const/high16 v2, 0x1000000

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/common/c$4;->b:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v3, "bevedi psteroaov rgr :"

    const/4 v5, 0x2

    const-string v3, ":g e brrb tvevir odsea"

    const-string/jumbo v3, "set vivo badge error: "

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-void
.end method
