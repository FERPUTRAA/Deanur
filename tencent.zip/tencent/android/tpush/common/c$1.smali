.class Lcom/tencent/android/tpush/common/c$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/common/c;->h(Landroid/content/Context;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Landroid/content/Context;


# direct methods
.method constructor <init>(ILandroid/content/Context;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/android/tpush/common/c$1;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpush/common/c$1;->b:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@fs @~K~My@ osSi~ /m~ol~i udnb.~~~c @ o~@@@~~~~lao@@ft~v @1@@@     ~~r4@~/@o@~~-b ~ ~t@ @bi~o @ "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHonor()Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string v1, ":samo/ea/etugt.ctacich.aodlue.tidenshnw/nmg/.bdnesonr"

    const-string v1, "/usngtanat.d:d.elmbceaiu/tothcsoco./nd/ngr.enwrahesie"

    const/4 v7, 0x3

    const-string v1, "as/hoeow.cr:lsaneeob.tnrntau.tegic/dadgmtunneid/.hoci"

    const-string v1, "content://com.huawei.android.launcher.settings/badge/"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const-string/jumbo v2, "lgBUtbadmi"

    const-string/jumbo v2, "tdUmisaBgl"

    const/4 v7, 0x1

    const-string v2, "eBsUliutag"

    const-string v2, "BadgeUtils"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-string v4, "bgh rodpoc eagneaoh"

    const-string v4, "dnoooe aecha rbhggn"

    const/4 v7, 0x3

    const-string v4, " b eanedqrch ggonao"

    const-string v4, "change honor badge "

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget v4, p0, Lcom/tencent/android/tpush/common/c$1;->a:I

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string/jumbo v3, "rusnnnebtcnaot/odgg/ni..teeih.bnetrod/s:iocahdlch.sam/"

    const-string/jumbo v3, "on/:nbh.eleto.ontachrb/di.cngt/hauacosen.egid/rnitsmdo"

    const/4 v7, 0x7

    const-string/jumbo v3, "ocbmen.ait:/grur.atdgn.nhdmo/nco/eridnoitls.t/hheeosca"

    const-string v3, "content://com.hihonor.android.launcher.settings/badge/"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    goto :goto_1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHuaWei()Z

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-nez v3, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isEmuiOrOhosVersion()Z

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x0

    if-eqz v3, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x4

    const-string v3, ""

    const-string v3, ""

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string v4, "dinuobaghh aee aeucw"

    const-string v4, "g  naeuhbwuachea ied"

    const/4 v7, 0x7

    const-string v4, "eebaib a gadhhucen g"

    const-string v4, "change huawei badge "

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget v4, p0, Lcom/tencent/android/tpush/common/c$1;->a:I

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    move-object v3, v1

    :goto_1
    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpush/common/c$1;->b:Landroid/content/Context;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget v5, p0, Lcom/tencent/android/tpush/common/c$1;->a:I

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v4, v3, v5}, Lcom/tencent/android/tpush/common/c;->a(Landroid/content/Context;Ljava/lang/String;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    goto/16 :goto_2

    :catchall_0
    move-exception v3

    const/4 v6, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string v5, "ggor iueehw aec adp u:arbrh"

    const-string v5, " ne:ao pbuggercaiwha  rdehr"

    const/4 v7, 0x2

    const-string v5, "ebeo: apgeaed crwgurihra  h"

    const-string v5, "change huawei badge error: "

    const/4 v6, 0x4

    move v7, v6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v3}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    shr-int/2addr v7, v6

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v2, v4}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz v0, :cond_3

    :try_start_1
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/common/c$1;->b:Landroid/content/Context;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget v4, p0, Lcom/tencent/android/tpush/common/c$1;->a:I

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v0, v1, v4}, Lcom/tencent/android/tpush/common/c;->a(Landroid/content/Context;Ljava/lang/String;I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    goto :goto_2

    :catchall_1
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    const-string v1, "bhgtdienq waoh eoerncwhu ar iriheo gu rra:"

    const-string v1, "change honor badge with huawei uri error: "

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v3}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_2
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    return-void
.end method
