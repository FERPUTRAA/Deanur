.class public Lcom/tencent/android/tpush/common/i;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/tpns/baseapi/base/device/RequestProxy;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/common/i$a;
    }
.end annotation


# instance fields
.field private a:Lcom/tencent/android/tpush/XGPushProxy;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    return-void
.end method

.method public static a()Lcom/tencent/android/tpush/common/i;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "i~s~o ~bo~n ~S c @r@  @ l~ l@@i ~~-~@~t@@4@s~@ft m@@/@d.@M @ ~@K~y~ a~/ @b ~ @i@o1foov~~~ob~~@u~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/common/i$a;->a:Lcom/tencent/android/tpush/common/i;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    return-object v0
.end method


# virtual methods
.method public a(Lcom/tencent/android/tpush/XGPushProxy;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/common/i;->a:Lcom/tencent/android/tpush/XGPushProxy;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->setRequestProxy(Lcom/tencent/tpns/baseapi/base/device/RequestProxy;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public b()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/common/i;->a:Lcom/tencent/android/tpush/XGPushProxy;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method

.method public hasProxy()Z
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/i;->b()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public onRegister(Lorg/json/JSONObject;)Lorg/json/JSONObject;
    .locals 3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/i;->b()Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/common/i;->a:Lcom/tencent/android/tpush/XGPushProxy;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-interface {v0, p1}, Lcom/tencent/android/tpush/XGPushProxy;->onRegisterRequest(Lorg/json/JSONObject;)Lorg/json/JSONObject;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p1
.end method
