.class public Lcom/tencent/android/tpush/common/AppInfos;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/String; = ""

.field private static b:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public static checkApplicationIcon(Landroid/content/Context;)Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  siid@@@~ -lt @~ ni/@~ l~~oo f~f~@@~o~ ~.@~~y4@@@~ ~~m /~~ub@@ v@oM@~Sr~a@bso@ 1Kt~ c  b@@ o ~@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    const-string/jumbo v0, "nofmspsI"

    const-string v0, "fnsopIAs"

    const-string v0, "fAoIonps"

    const-string v0, "AppInfos"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x2

    const/4 v1, 0x0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/common/AppInfos;->getAppInfo(Landroid/content/Context;)Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez p0, :cond_0

    const/4 v5, 0x1

    const-string/jumbo p0, "iilpnbmc not fal tpde lioeAnulotn.I u iatdo"

    const-string p0, ".ilmenpfn atd nooindelauIt ptAcl ito ilu oi"

    const/4 v5, 0x6

    const-string/jumbo p0, "o ipuFunntu.lIeiitne oldaoadtico  liAl p nf"

    const-string p0, "Failed to init due to null ApplicationInfo."

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    return v1

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->icon:I

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-nez p0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo p0, "mws ncfpe nifdtMahad,F ds lm,xcspdnn.ein enpttyAro diiiacorboltfpn tclaaligt mnie.it li AadplteooopP aoAaMxo cipneo niAs YutonAaco id ien o nii ao"

    const-string/jumbo p0, "tcsxodtA pno Fi  bogianed ensmimoeniisoca aAcnppdrfitola f c. i M o,caP.mye M idfhdiilindptatnceioiit  llAidnx el auasn nAooYooArtnlnatipt,n opewa"

    const/4 v5, 0x1

    const-string/jumbo p0, "n eii giq,weucpiF aearfne pitsni AdnpAoniidp nAlddrMea  of.ol iA oi mntY i,mPsoc bontnectM.aanshc pce xAoldottoitanaiailn o msa ycotniafdo tdnlpxi"

    const-string p0, "Failed to get Application icon in AndroidManifest.xml, You App maybe can not show notification, Please add Application icon in AndroidManifest.xml"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    return v1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 p0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    return p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string v3, "besnclxAtd:ae icuneoiIhcfronoceppctp"

    const-string v3, "ccxtrbkelno hfeinteAupcp:cacIpneiodo"

    const/4 v5, 0x0

    const-string v3, " n:mcnxhpAdutncIieotiecpcfeplroco ek"

    const-string/jumbo v3, "unexpected for checkApplicationIcon:"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    return v1
.end method

.method public static forbidPullupService(Landroid/content/Context;)Z
    .locals 4

    :try_start_0
    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/16 v1, 0x80

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, p0, v1}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v2, 0x7

    and-int/2addr v3, v2

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p0, p0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v0, "_OI_oE_FR_VULEPuXGLCSU"

    const-string v0, "_F_ELIu_G_XPRLSOCPVEUU"

    const/4 v3, 0x0

    const-string v0, "FO__Pb_UXGSLPFIEVRULCE"

    const-string v0, "XG_SERVICE_PULL_UP_OFF"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0, v0}, Landroid/os/BaseBundle;->getBoolean(Ljava/lang/String;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string/jumbo v0, "pspfnpuI"

    const-string/jumbo v0, "pfpnIAsp"

    const/4 v3, 0x1

    const-string/jumbo v0, "pnoAIpsp"

    const-string v0, "AppInfos"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string/jumbo v1, "u lritcdqurc xfpioneveedeoSPbepqrl"

    const-string/jumbo v1, "uiedidufqe  eroxcrcbflroSPtvppeeln"

    const/4 v3, 0x7

    const-string v1, "c slcriuxevu prnrdlefebeuoSedPftip"

    const-string/jumbo v1, "unexpected for forbidPullupService"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x5

    return p0
.end method

.method public static getApiLevel()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public static getAppContext()Landroid/content/Context;
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    sget-object v0, Lcom/tencent/android/tpush/common/AppInfos;->b:Landroid/content/Context;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string v1, "AnpmofpI"

    const-string v1, "IpsfApno"

    const/4 v6, 0x3

    const-string/jumbo v1, "pAIpoofs"

    const-string v1, "AppInfos"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-nez v0, :cond_0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string/jumbo v0, "nhpvibiadoiedTrmad.Apyctra"

    const-string v0, "TiymriaAaited.dhavnpo.drpc"

    const/4 v6, 0x1

    const-string v0, "aa.anvu.ThortptiecipdAidry"

    const-string v0, "android.app.ActivityThread"

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string/jumbo v2, "nAtpatcpcnipolruoi"

    const-string v2, "copuotanirnAilptcr"

    const/4 v6, 0x5

    const-string v2, "Alcctnoaqiutinrrpp"

    const-string v2, "currentApplication"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v3, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    new-array v4, v3, [Ljava/lang/Class;

    const/4 v6, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    new-array v2, v3, [Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v3, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0, v3, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x1

    check-cast v0, Landroid/app/Application;

    const/4 v6, 0x6

    sput-object v0, Lcom/tencent/android/tpush/common/AppInfos;->b:Landroid/content/Context;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const-string v3, " osdiiannevAebtlatTfetr rlcchAipc: utiaypig te"

    const-string/jumbo v3, "liya:bdai Tfar ciitturevtAAltp cpe etgohcienrn"

    const/4 v6, 0x2

    const-string v3, " pdmr cAln rice ceiioyptdAf:ivttuehtaiaanlTget"

    const-string v3, " get ActivityThread currentApplication failed:"

    const/4 v6, 0x1

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    shr-int/2addr v6, v5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    sget-object v0, Lcom/tencent/android/tpush/common/AppInfos;->b:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-nez v0, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string/jumbo v0, "tgt o l c diutn.pdoie ixhun tfr !oUlss epslnuAt"

    const-string v0, "etitf unA  p nld.cshd! gp lotst Uxuiorui ktlnse"

    const/4 v6, 0x4

    const-string v0, "eAr hbtontU p td xotilklcspe!usudf ln   gs.nit "

    const-string v0, " App context get null! U should init sdk first."

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    sget-object v0, Lcom/tencent/android/tpush/common/AppInfos;->b:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    return-object v0
.end method

.method public static getAppInfo(Landroid/content/Context;)Landroid/content/pm/ApplicationInfo;
    .locals 4

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, p0, v1}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo v0, "ppsfpoun"

    const-string v0, "Asopnfpp"

    const/4 v3, 0x6

    const-string/jumbo v0, "spAnIopp"

    const-string v0, "AppInfos"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v1, " eidptegqlFoi inlpqof oti naac"

    const-string v1, " c ad inq oilfpeiaoneFgtttopil"

    const/4 v3, 0x0

    const-string v1, "aAsdnifp eFagooct oit iiltnelp"

    const-string v1, "Failed to get Application info"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-object p0
.end method

.method public static getAppVersion(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/common/AppInfos;->a:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->c(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    sget-object p0, Lcom/tencent/android/tpush/common/AppInfos;->a:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p0

    :cond_0
    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0, p0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    sput-object p0, Lcom/tencent/android/tpush/common/AppInfos;->a:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz p0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez p0, :cond_2

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo p0, "snkmonw"

    const-string/jumbo p0, "onsnwnk"

    const/4 v3, 0x5

    const-string/jumbo p0, "nnnkouo"

    const-string/jumbo p0, "unknown"
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo v0, "sofnpbmA"

    const-string/jumbo v0, "opnmspfA"

    const/4 v3, 0x2

    const-string v0, "IpApfnus"

    const-string v0, "AppInfos"

    const/4 v3, 0x7

    const-string/jumbo v1, "nVieooert r!orApgsrp"

    const/4 v3, 0x3

    const-string v1, "gon rtAposiper!rrepV"

    const-string v1, "getAppVersion error!"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget-object p0, Lcom/tencent/android/tpush/common/AppInfos;->a:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-object p0
.end method

.method public static getApplicationName(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget v1, v0, Landroid/content/pm/ApplicationInfo;->labelRes:I

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object p0, v0, Landroid/content/pm/ApplicationInfo;->nonLocalizedLabel:Ljava/lang/CharSequence;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-interface {p0}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0, v1}, Landroid/content/Context;->getString(I)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string/jumbo v0, "qAsbopIf"

    const-string/jumbo v0, "nsfAobIp"

    const/4 v3, 0x2

    const-string/jumbo v0, "pnspAofI"

    const-string v0, "AppInfos"

    const/4 v3, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p0
.end method

.method public static getCurAppVersion(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x3

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1, p0, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-nez p0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object v0

    :cond_0
    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo v1, "nuAmfspp"

    const-string/jumbo v1, "ofsAnpup"

    const/4 v4, 0x2

    const-string v1, "AppInfos"

    const/4 v4, 0x4

    const-string/jumbo v2, "pverorgpee ot oia srn"

    const-string v2, " air otprgsoprene vep"

    const/4 v4, 0x0

    const-string v2, "esgerbpoov er p tnrai"

    const-string v2, "get app version error"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-object v0
.end method

.method public static getCurrentPackageName(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    if-eqz p0, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p0

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v1, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-object p0
.end method

.method public static getLauncherPackageName(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    if-nez p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance v1, Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v2, "qcnInnu.itiad..dntMroeoANa"

    const-string v2, "dM.AnIntqiict.oNnodaera.ni"

    const-string/jumbo v2, "ntcIinMpnoi.iAttadondN.ae."

    const-string v2, "android.intent.action.MAIN"

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v2, "noodatrtqrit.deayOMien.nEgHc"

    const-string v2, "Oisttad.eEonnyiMnoeHrrtg.dca"

    const/4 v4, 0x5

    const-string/jumbo v2, "rnsegto.neyaOn..EadtocMdHitr"

    const-string v2, "android.intent.category.HOME"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0, v1, v2}, Landroid/content/pm/PackageManager;->resolveActivity(Landroid/content/Intent;I)Landroid/content/pm/ResolveInfo;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz p0, :cond_3

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v1, p0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-nez v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    iget-object v1, v1, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v2, "amomdrn"

    const-string v2, "dnrmoai"

    const-string v2, "diadonr"

    const-string v2, "android"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object v0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object p0, p0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object p0, p0, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object p0

    :cond_3
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object v0
.end method

.method public static getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 4

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/16 v1, 0x80

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p0, v1}, Landroid/content/pm/PackageManager;->getApplicationInfo(Ljava/lang/String;I)Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object p0, p0, Landroid/content/pm/ApplicationInfo;->metaData:Landroid/os/Bundle;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, p1}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p2
.end method

.method public static getOsVersion()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object v0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public static getRunningPkgsByPkgs(Landroid/content/Context;Ljava/util/List;)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x7

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x1

    shr-int/2addr v4, v3

    const/4 p0, 0x0

    or-int/2addr v4, p0

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-object p0

    :cond_0
    const/4 v3, 0x1

    move v4, v3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x7

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v4, 0x0

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-ge v1, v2, :cond_3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    check-cast v2, Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {p0, v2}, Lcom/tencent/android/tpush/common/AppInfos;->isAppOnForeground(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v2, :cond_1

    const/4 v3, 0x4

    move v4, v3

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object v0

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    check-cast v2, Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p0, v2}, Lcom/tencent/android/tpush/common/AppInfos;->isAppRunning(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v2

    const/4 v4, 0x1

    const/4 v3, 0x5

    if-eqz v2, :cond_2

    const/4 v4, 0x1

    invoke-interface {p1, v1}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :cond_3
    const/4 v3, 0x1

    move v4, v3

    return-object v0
.end method

.method public static init(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    sput-object p0, Lcom/tencent/android/tpush/common/AppInfos;->b:Landroid/content/Context;

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method

.method public static isAppOnForeground(Landroid/content/Context;)Z
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/AppInfos;->isAppOnForeground(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return p0
.end method

.method public static isAppOnForeground(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v0, "vyicabto"

    const-string/jumbo v0, "ytctoiva"

    const/4 v4, 0x3

    const-string v0, "activity"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    if-nez p0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    return v0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    check-cast v1, Landroid/app/ActivityManager$RunningAppProcessInfo;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v2, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v1, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->importance:I

    const/4 v4, 0x0

    const/16 v2, 0x64

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-ne v1, v2, :cond_1

    const/4 v4, 0x2

    const/4 p0, 0x1

    const/4 v4, 0x4

    move v3, p0

    move v3, p0

    return p0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    return v0
.end method

.method public static isAppRunning(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-string v0, "biitvaut"

    const-string v0, "iavtibty"

    const/4 v2, 0x2

    const-string v0, "aivtycip"

    const-string v0, "activity"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x3

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    check-cast v0, Landroid/app/ActivityManager$RunningAppProcessInfo;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, v0, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 p0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return p0

    :cond_1
    const/4 v2, 0x1

    const/4 p0, 0x0

    move v1, p0

    move v1, p0

    const/4 v2, 0x4

    return p0
.end method
