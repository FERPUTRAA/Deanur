.class public final enum Lcom/tencent/android/tpush/common/MobileType;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/tencent/android/tpush/common/MobileType;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/tencent/android/tpush/common/MobileType;

.field public static final enum CHINAMOBILE:Lcom/tencent/android/tpush/common/MobileType;

.field public static final enum TELCOM:Lcom/tencent/android/tpush/common/MobileType;

.field public static final enum UNICOM:Lcom/tencent/android/tpush/common/MobileType;

.field public static final enum UNKNOWN:Lcom/tencent/android/tpush/common/MobileType;


# instance fields
.field private str:Ljava/lang/String;

.field private type:B


# direct methods
.method static constructor <clinit>()V
    .locals 12

    const/4 v11, 0x5

    const/4 v10, 0x7

    new-instance v0, Lcom/tencent/android/tpush/common/MobileType;

    const/4 v11, 0x7

    const-string v1, "65s8s76/7udu44/5ue8au/55f2//u0"

    const-string v1, "8/s5/72/84d602556a57eu/uf/u4uu"

    const/4 v11, 0x5

    const-string/jumbo v1, "\u672a\u77e5\u8fd0\u8425\u5546"

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    const-string v2, "NKmmWON"

    const-string v2, "KNOmNNW"

    const/4 v11, 0x6

    const-string v2, "UNKNOWN"

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x2

    const/4 v3, 0x0

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-direct {v0, v2, v3, v3, v1}, Lcom/tencent/android/tpush/common/MobileType;-><init>(Ljava/lang/String;IBLjava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    sput-object v0, Lcom/tencent/android/tpush/common/MobileType;->UNKNOWN:Lcom/tencent/android/tpush/common/MobileType;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    new-instance v1, Lcom/tencent/android/tpush/common/MobileType;

    const/4 v11, 0x1

    const-string v2, "d5/uofed/4f2o/u1ue5573u6"

    const-string v2, "734fo1///6f5eud5deuu452u"

    const-string v2, "f3u46b145/2euu/f/7u5dde5"

    const-string/jumbo v2, "\u4e2d\u56fd\u7535\u4fe1"

    const/4 v11, 0x7

    const/4 v10, 0x1

    const-string/jumbo v4, "ubLMET"

    const-string v4, "METLCb"

    const/4 v11, 0x7

    const-string v4, "TELCOM"

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    const/4 v5, 0x1

    invoke-direct {v1, v4, v5, v5, v2}, Lcom/tencent/android/tpush/common/MobileType;-><init>(Ljava/lang/String;IBLjava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x3

    sput-object v1, Lcom/tencent/android/tpush/common/MobileType;->TELCOM:Lcom/tencent/android/tpush/common/MobileType;

    const/4 v11, 0x4

    const/4 v10, 0x4

    new-instance v2, Lcom/tencent/android/tpush/common/MobileType;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x1

    const-string v4, "duu5uaep94/f52/6du1/08/0"

    const-string v4, "8490e/u5/da652du1ufu//u0"

    const/4 v11, 0x1

    const-string/jumbo v4, "u0/4au4uqu56d/01/89d/25e"

    const-string/jumbo v4, "\u4e2d\u56fd\u8054\u901a"

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-string v6, "UNsCOp"

    const-string v6, "OpUCIN"

    const/4 v11, 0x3

    const-string v6, "UNICOM"

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x3

    const/4 v7, 0x2

    const/4 v10, 0x7

    move v11, v10

    invoke-direct {v2, v6, v7, v7, v4}, Lcom/tencent/android/tpush/common/MobileType;-><init>(Ljava/lang/String;IBLjava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x3

    sput-object v2, Lcom/tencent/android/tpush/common/MobileType;->UNICOM:Lcom/tencent/android/tpush/common/MobileType;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    new-instance v4, Lcom/tencent/android/tpush/common/MobileType;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    const-string v6, "4aqmbu97u5/ff6d2ued85u/2"

    const-string v6, "aed/uuf4q/u256b5d82/f7u9"

    const/4 v11, 0x4

    const-string v6, "du/4ob72/u//d68fue9f25au"

    const-string/jumbo v6, "\u4e2d\u56fd\u79fb\u52a8"

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x5

    const-string v8, "OMCsIbAHNEB"

    const-string v8, "IIsBHEANMOC"

    const/4 v11, 0x3

    const-string v8, "INBOILuCMEH"

    const-string v8, "CHINAMOBILE"

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    const/4 v9, 0x3

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-direct {v4, v8, v9, v9, v6}, Lcom/tencent/android/tpush/common/MobileType;-><init>(Ljava/lang/String;IBLjava/lang/String;)V

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    sput-object v4, Lcom/tencent/android/tpush/common/MobileType;->CHINAMOBILE:Lcom/tencent/android/tpush/common/MobileType;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x2

    const/4 v6, 0x4

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    new-array v6, v6, [Lcom/tencent/android/tpush/common/MobileType;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x6

    aput-object v0, v6, v3

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x7

    aput-object v1, v6, v5

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    aput-object v2, v6, v7

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    aput-object v4, v6, v9

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x0

    sput-object v6, Lcom/tencent/android/tpush/common/MobileType;->$VALUES:[Lcom/tencent/android/tpush/common/MobileType;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IBLjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(B",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x2

    const/4 v0, 0x2

    iput-byte p3, p0, Lcom/tencent/android/tpush/common/MobileType;->type:B

    const/4 v1, 0x5

    iput-object p4, p0, Lcom/tencent/android/tpush/common/MobileType;->str:Ljava/lang/String;

    const/4 v1, 0x1

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/tencent/android/tpush/common/MobileType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "o@/Syltp@ .c/@@@~@o b @@~ - t~ v~~~~4~1uoi o~ @@b o~~m~~ir ~d ~K@@~~f @o@ @lb~@@s@~aMn @ ~~ @f ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    const-class v0, Lcom/tencent/android/tpush/common/MobileType;

    const-class v0, Lcom/tencent/android/tpush/common/MobileType;

    const/4 v2, 0x7

    const-class v0, Lcom/tencent/android/tpush/common/MobileType;

    const-class v0, Lcom/tencent/android/tpush/common/MobileType;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    check-cast p0, Lcom/tencent/android/tpush/common/MobileType;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p0
.end method

.method public static values()[Lcom/tencent/android/tpush/common/MobileType;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/common/MobileType;->$VALUES:[Lcom/tencent/android/tpush/common/MobileType;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lcom/tencent/android/tpush/common/MobileType;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    check-cast v0, [Lcom/tencent/android/tpush/common/MobileType;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public getStr()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/common/MobileType;->str:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public getType()B
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    iget-byte v0, p0, Lcom/tencent/android/tpush/common/MobileType;->type:B

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method
