.class Lcom/tencent/android/tpush/common/c$3;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/common/c;->d(Landroid/content/Context;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Landroid/content/Context;


# direct methods
.method constructor <init>(ILandroid/content/Context;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/tencent/android/tpush/common/c$3;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/tencent/android/tpush/common/c$3;->b:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "-~si b1o@~fbm @i@o@o@@~tub. @ @ ol ~@@vS@ ~~ c/@K~ ~~4 d~ rn@@olM~i~~f@@ y~a~ @@~ ~/t@~~~~ o@ s "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x1

    const-string v0, "dlsmaUtBie"

    const-string/jumbo v0, "tBsasidelU"

    const/4 v7, 0x0

    const-string v0, "dBslotaUgi"

    const-string v0, "BadgeUtils"

    :try_start_0
    const/4 v6, 0x0

    const/4 v7, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string/jumbo v2, "mg eob bap dpoe"

    const-string v2, "edom  apgpob et"

    const/4 v7, 0x3

    const-string v2, " potgeu d opasb"

    const-string/jumbo v2, "set oppo badge "

    const/4 v6, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    iget v2, p0, Lcom/tencent/android/tpush/common/c$3;->a:I

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-instance v1, Landroid/os/Bundle;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-direct {v1}, Landroid/os/Bundle;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string/jumbo v2, "oc_gotaanuppdeb"

    const/4 v7, 0x0

    const-string v2, "dp_ao_uppaenctg"

    const-string v2, "app_badge_count"

    const/4 v7, 0x5

    const/4 v6, 0x3

    iget v3, p0, Lcom/tencent/android/tpush/common/c$3;->a:I

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v1, v2, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/common/c$3;->b:Landroid/content/Context;

    const/4 v7, 0x0

    invoke-virtual {v2}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v3, "d/.dd:.nqiaeegcodtnmabocnrgbe//ab"

    const-string/jumbo v3, "ncoanbbdondecigg.ttm/rae:e.//dbda"

    const-string v3, "cdseaa/r:aodt/omdnegcbn/ento..gbd"

    const-string v3, "content://com.android.badge/badge"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {v3}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string v4, "AoemaudpgCBspntu"

    const-string/jumbo v4, "uagCoeupeApBnsdt"

    const/4 v7, 0x5

    const-string v4, "gaetonBodeuppCAt"

    const-string/jumbo v4, "setAppBadgeCount"

    const/4 v6, 0x4

    const/4 v6, 0x0

    const/4 v5, 0x0

    xor-int/2addr v7, v5

    invoke-virtual {v2, v3, v4, v5, v1}, Landroid/content/ContentResolver;->call(Landroid/net/Uri;Ljava/lang/String;Ljava/lang/String;Landroid/os/Bundle;)Landroid/os/Bundle;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v7, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string v3, "de  epopsaotgrb rpoe"

    const/4 v7, 0x2

    const-string v3, " sb ebat prdorrgoeep"

    const-string/jumbo v3, "set oppo badge error"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    return-void
.end method
