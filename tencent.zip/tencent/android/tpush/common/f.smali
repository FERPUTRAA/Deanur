.class public Lcom/tencent/android/tpush/common/f;
.super Ljava/lang/Object;


# static fields
.field private static final a:[Ljava/lang/String;

.field private static b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v0, "Snseo.SsasinpiFs.Er_WCIdAoTi_dEmSTrI"

    const-string v0, "aSsEoCdpACsIWnF_eTIniS.dsrToEiSr_im."

    const/4 v4, 0x3

    const-string v0, "TidmTaSnIpF.oAsdWo.mErSenCirESCIA_i_"

    const-string v0, "android.permission.ACCESS_WIFI_STATE"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v1, "_WKSomsooCETOdRnpniriAmNearsSA..i_CdTSE"

    const-string/jumbo v1, "raKms.SeATSnp_dCroNACTsR.EioWTOiS_iEdnm"

    const/4 v4, 0x1

    const-string v1, "Tn.ACbTso_rpim.dOEEraCSWAKERT_iiSnoNdSe"

    const-string v1, "android.permission.ACCESS_NETWORK_STATE"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v2, "sp.IdTuoineoNinmE.saioNrTER"

    const-string/jumbo v2, "nEoNodompiRTTEras.iNers.iIn"

    const/4 v4, 0x2

    const-string/jumbo v2, "pEsdT.ipIim.ENrdosiNRornnTa"

    const-string v2, "android.permission.INTERNET"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    filled-new-array {v2, v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    sput-object v0, Lcom/tencent/android/tpush/common/f;->a:[Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v4, 0x5

    const/16 v1, 0x8

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v4, 0x5

    sput-object v0, Lcom/tencent/android/tpush/common/f;->b:Ljava/util/Map;

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method

.method public static a()Z
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "  fdl   q@@ @@  t~ @@@o@o@~Mi@y@~ @~~-c~~~bi@~t~v~m b~ ~o @~n~@ @o~SKa~@@.~1b4~lu@i s /~~r@ /~fo"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x6

    const-string/jumbo v0, "sssreibPhoeerncim"

    const-string/jumbo v0, "oihrnbmesPkrcseie"

    const/4 v11, 0x7

    const-string/jumbo v0, "iskmseimCehrnreoc"

    const-string v0, "PermissionChecker"

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/common/f;->b()Landroid/content/Context;

    move-result-object v1

    const/4 v11, 0x4

    const/4 v10, 0x6

    if-eqz v1, :cond_3

    const/4 v10, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    const/4 v2, 0x0

    :try_start_0
    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    if-eqz v3, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    const/16 v4, 0x1000

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v3, v1, v4}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v1

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x6

    iget-object v1, v1, Landroid/content/pm/PackageInfo;->requestedPermissions:[Ljava/lang/String;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    if-nez v1, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    return v2

    :cond_0
    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    sget-object v3, Lcom/tencent/android/tpush/common/f;->a:[Ljava/lang/String;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    array-length v4, v3

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    move v5, v2

    move v5, v2

    :goto_0
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    if-ge v5, v4, :cond_2

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x3

    aget-object v6, v3, v5

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-static {v1, v6}, Lcom/tencent/android/tpush/common/f;->a([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v7

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    sget-object v8, Lcom/tencent/android/tpush/common/f;->b:Ljava/util/Map;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-static {v7}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v9

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-interface {v8, v6, v9}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x7

    if-nez v7, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x3

    const-string v3, " irmoeqoih< riTrues uepe dos"

    const-string v3, "doisieu fre hos iqmT<eperr u"

    const/4 v11, 0x7

    const-string/jumbo v3, "r e ibhoneoeTpuiqdm s<eir rs"

    const-string v3, "The required permission of <"

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v3, "ospun>uo!neo d fd"

    const-string v3, "deno! opof >ndu s"

    const/4 v11, 0x1

    const-string/jumbo v3, "neu>!f poddot nso"

    const-string v3, "> does not found!"

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x7

    return v2

    :cond_1
    const/4 v11, 0x6

    add-int/lit8 v5, v5, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x7

    goto :goto_0

    :cond_2
    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v0, 0x1

    move v11, v0

    const/4 v10, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    return v0

    :catchall_0
    move-exception v1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    const-string v3, "eiseripsqx.dncmreqruesctk  nehq iioc"

    const-string v3, "erei iciqrkisenuceqexm.ctesdrp  oshn"

    const/4 v11, 0x0

    const-string v3, "drs  iet sericcqepenskpmusineoc.ixre"

    const-string v3, "check required permissins exception."

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {v0, v3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v11, 0x5

    const/4 v10, 0x4

    return v2

    :cond_3
    const/4 v10, 0x6

    move v11, v10

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-string v1, "hatmoa  e!br tsTntmlu p tclncanoe eere"

    const-string v1, " as utmrtecoh! eenteTretnap ncolblan  "

    const/4 v11, 0x2

    const-string v1, " a toexlmrnen ceTe nu patetoha!cnr tbo"

    const-string v1, "The context parameter can not be null!"

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x1

    throw v0
.end method

.method private static a([Ljava/lang/String;Ljava/lang/String;)Z
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    array-length v0, p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    move v2, v1

    move v2, v1

    const/4 v5, 0x4

    move v2, v1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-ge v2, v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    aget-object v3, p0, v2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x7

    if-eqz v3, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 p0, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    return p0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    add-int/lit8 v2, v2, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    return v1
.end method

.method private static b()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object v0
.end method
