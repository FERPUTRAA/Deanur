.class Lcom/tencent/android/tpush/common/j$4;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/common/j;->h(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "~os b@Slm~f@@i~t/y@@@@i ~K~  v/~ @o @a -~s@.  r@~~~@~i~@t @ dM~o o@@  1@~bc@~~~~ fon  ~4ulo@~~@b"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x5

    const-string v0, "filter components"

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x5

    if-nez v1, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    return-void

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/common/j;->b()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string v4, "T ymveeied:c"

    const-string v4, "deviceType: "

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {v0, v3}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandXiaoMi()Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-nez v3, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandBlackShark()Z

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-nez v3, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v4, "psalo-n-soot-otmsxbieidmcneip"

    const-string v4, "dosixeeimsocaltmnn-i-bspnp-ot"

    const/4 v7, 0x6

    const-string/jumbo v4, "laitpb-esna-dmxsipoino-toecbm"

    const-string/jumbo v4, "tpns-disable-component-xiaomi"

    const/4 v6, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v3, v4, v5}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    check-cast v3, Ljava/lang/Boolean;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-eqz v3, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    const-string v4, "iSrcxmusuXhoiahve.mmPis.oipeesu.cecr."

    const-string v4, "Xromia.cisSMieisccPu.hvrseux..ehpoemm"

    const/4 v7, 0x1

    const-string v4, ".criicvpemis.re.PcmMishuoa.hseupxoeXS"

    const-string v4, "com.xiaomi.push.service.XMPushService"

    const/4 v7, 0x1

    invoke-static {v1, v3, v4}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v4, "ec.voMicssmobpeo.rceeXuJSvhiioi.axr."

    const-string v4, "com.xiaomi.push.service.XMJobService"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v1, v3, v4}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string/jumbo v4, "uimplbasqe.HgMedPdsrcmsiua.omh.inhsaesox"

    const-string v4, "ensiubmrHheksolecdpumgshsdx.i.aaioP.maMs"

    const/4 v7, 0x6

    const-string v4, "ePsdmlukn.eisuarcmgsip.H..osaMasedhixmos"

    const-string v4, "com.xiaomi.mipush.sdk.PushMessageHandler"

    const/4 v7, 0x3

    const/4 v6, 0x3

    invoke-static {v1, v3, v4}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string v4, "aHsmpeceddeina.eismlur.sa.moigmc.oheSkvusx"

    const-string v4, "ageidiuoadac.uslH.enoemsmik.e.sSphrsvmicxe"

    const/4 v7, 0x2

    const-string v4, "e.croovosadigeiechsdHa.s.ms.nlMSuaixmeeimk"

    const-string v4, "com.xiaomi.mipush.sdk.MessageHandleService"

    const/4 v7, 0x1

    invoke-static {v1, v3, v4}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x7

    const-string/jumbo v4, "tismvbhecNec.rxeerurikswsvsuRirieactto...papvocemeeri.o"

    const-string v4, ".euisaeptmtps.xeircsvr..oeeiecsecRtrkro.Nhcioevmuwrveai"

    const/4 v7, 0x0

    const-string v4, "ecsikrueasxSecroNviceimwve..ueth.vterRioiprt.caseo.muse"

    const-string v4, "com.xiaomi.push.service.receivers.NetworkStatusReceiver"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v1, v3, v4}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string v4, "eqsPceepmerhore.imiiixcrnrc..vaiveogecsvu.pies"

    const-string/jumbo v4, "ivvmsegeq.ier.rPhseec.isaeooimcpneucxrce..viri"

    const/4 v7, 0x7

    const-string v4, ".veceeeeqrevsi.oorihRnecsiPxecuirmgcm..i.ivsap"

    const-string v4, "com.xiaomi.push.service.receivers.PingReceiver"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v1, v3, v4}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v6, 0x7

    move v7, v6

    const-string/jumbo v4, "umss.iersoiXen.u.eeddecnshphcrgaRs.aetocPmvMsMni"

    const-string v4, ".sstedcugnochPisMpaehmeunesne.cosevr.i.MmXiRadrt"

    const/4 v7, 0x2

    const-string v4, "com.tencent.android.mipush.XMPushMessageReceiver"

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v1, v3, v4}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHuaWei()Z

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-nez v3, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHonor()Z

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-nez v3, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isEmuiOrOhosVersion()Z

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    if-nez v3, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string/jumbo v3, "vadmeidliiaew euhcbes"

    const-string/jumbo v3, "seimb ihiwveeedcldaua"

    const/4 v7, 0x0

    const-string v3, "euehoiw dieaisbela dv"

    const-string v3, "disable device huawei"

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-static {v0, v3}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string/jumbo v3, "na-scbieuvowebhdltosn-tnao-pmp4-"

    const-string/jumbo v3, "mn-aoocvh-woeniu-ptlpete-abdss4n"

    const/4 v7, 0x6

    const-string v3, "4bse-cuuaaonmwne-vnelhoti-pd-pis"

    const-string/jumbo v3, "tpns-disable-component-huawei-v4"

    const/4 v7, 0x7

    const/4 v6, 0x0

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {v0, v3, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    check-cast v0, Ljava/lang/Boolean;

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v0, :cond_2

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string v3, "cpinodcpiienzniA.ePwarebitIcnrurdtC.regmt..ivonoachoerGocaol.e"

    const-string/jumbo v3, "ntrncboamIzotoo.irrpPadci.gvr.eewecrelitCcdeoiineaAicnG..enuho"

    const/4 v7, 0x1

    const-string v3, ".eauwierqtirclniiPa.mro.dtoenIeneneciAcrvdcp.eocgooohziaGvC.nt"

    const-string v3, "com.huawei.agconnect.core.provider.AGConnectInitializeProvider"

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v6, 0x3

    xor-int/2addr v7, v6

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string v3, "egscSohwuDitnvsaiure.coeceec..rmn.croiyceo"

    const-string v3, "accc.eueismi.onrya..ogvrchonieDuerccoStewe"

    const/4 v7, 0x3

    const-string/jumbo v3, "uivmsrwe.tee.oc.eocnri.yavcDimaheeconccrog"

    const-string v3, "com.huawei.agconnect.core.ServiceDiscovery"

    const/4 v7, 0x5

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    const-string v3, "coadoeevWn.tvp3rmeHi.u.cdswrtseheicsegnnshSmHapM"

    const-string/jumbo v3, "rstrvaeppvec.eoe.gnscwsdedcW3iuSMtmnn..mhhiHHase"

    const/4 v7, 0x2

    const-string v3, "aeigobtethrsmHh3sd.ocdeiWMScnvH.seecnrnvsepu.wm."

    const-string v3, "com.tencent.android.hwpushv3.HWHmsMessageService"

    const/4 v7, 0x3

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v6, 0x0

    move v7, v6

    const-string/jumbo v3, "mg..aruse.chep.uhuspmPiRssqosu.cvehorhuaiMtpp.w"

    const-string v3, "ce...s.oq.ghmRrsMtphPhpv.asurewucoepushpmsaiuei"

    const-string v3, "ah.msRipassuevpPes.ptgoiec.scMohirh.e.rumpuwphu"

    const-string v3, "com.huawei.hms.support.api.push.PushMsgReceiver"

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string v3, "..sircusqshpm.amihupepevPrtwueiahRhoos.p.uce"

    const-string/jumbo v3, "uesus.RsPp.poe.h.mpocitvsisciaphuemhr.hewura"

    const/4 v7, 0x0

    const-string/jumbo v3, "p.sh.urua.isp..scscerwm.iaPshtemoevuipupeohR"

    const-string v3, "com.huawei.hms.support.api.push.PushReceiver"

    const/4 v7, 0x4

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string/jumbo v3, "tismeahprehmushdp.opma...wmoso.hvuicprP.uiuP"

    const-string/jumbo v3, "uatmcspPsap..vudmPhuiehs.p.uiw.hmroprh.eosio"

    const/4 v7, 0x0

    const-string v3, "e.isoiurdsurhocmus..iosp.Ppruamhh.eoPvpawhp."

    const-string v3, "com.huawei.hms.support.api.push.PushProvider"

    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandMeiZu()Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-nez v0, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string/jumbo v3, "omdsebl-sezinetppoi-cmnan-bo"

    const-string v3, "icsno-mtptleoaobspdzmnie-en-"

    const/4 v7, 0x2

    const-string v3, "doao-puitemztn-sncpeluin-sbm"

    const-string/jumbo v3, "tpns-disable-component-meizu"

    const/4 v7, 0x7

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-static {v0, v3, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    check-cast v0, Ljava/lang/Boolean;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz v0, :cond_3

    const/4 v6, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-string v3, "ehahoMrpZnPsevec.rdRecmaegnpesMztue.bn.s.sdmoiui"

    const-string v3, "gcPtcbpreoemrRhudmeohMsineZansviMsna.dz.see..ecu"

    const/4 v7, 0x4

    const-string v3, "eaenesm.qztdphvce.Re.iidesuPtZco.augMshrrcoMnemn"

    const-string v3, "com.tencent.android.mzpush.MZPushMessageReceiver"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string/jumbo v3, "oeSvdiucuResemitzcumlesuc..pyomdhr.esk"

    const-string v3, "c.suS.omueeRshsczmdvdpieety.skecr.moui"

    const-string v3, "com.meizu.cloud.pushsdk.SystemReceiver"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x5

    const-string/jumbo v3, "o.zerocpfisshucSpmmt.clueivn.dtidueNicio.ao"

    const/4 v7, 0x3

    const-string/jumbo v3, "uoamitNisncSdzuhricuoocoekimvlfsdm..i.pet.e"

    const-string v3, "com.meizu.cloud.pushsdk.NotificationService"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    :cond_3
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo v0, "oopp"

    const/4 v7, 0x6

    const-string/jumbo v0, "oppo"

    const/4 v7, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-nez v0, :cond_4

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string/jumbo v0, "qsueoop"

    const-string/jumbo v0, "oquslep"

    const-string/jumbo v0, "penolbs"

    const-string/jumbo v0, "oneplus"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    if-nez v0, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string/jumbo v0, "ueemsr"

    const-string v0, "emsare"

    const/4 v7, 0x3

    const-string/jumbo v0, "rpeaml"

    const-string/jumbo v0, "realme"

    const/4 v6, 0x7

    move v7, v6

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-nez v0, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string/jumbo v3, "m-np-tioqmapdbl-soeeocnospp"

    const-string v3, "--omeompidtpop-elnsatbsconp"

    const-string/jumbo v3, "post-onomtnpc-ensplosdaeip-"

    const-string/jumbo v3, "tpns-disable-component-oppo"

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    sget-object v4, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {v0, v3, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    check-cast v0, Ljava/lang/Boolean;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz v0, :cond_4

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string v3, "ahamelpeh.tt.cDgeblSa.mopCeaoeamarccemsrsiisopsMuvsctCikee.pyalb"

    const-string/jumbo v3, "vtacormacihuppalmgocMSslieamapheetb.estakCreoeepbly.eCiss.sDvc.a"

    const/4 v7, 0x1

    const-string/jumbo v3, "oiraoeatel.bpmaeieceatm.ckapvsalbpcDM.ehSrC.iglpomeacsestyuCvshs"

    const-string v3, "com.heytap.msp.push.service.CompatibleDataMessageCallbackService"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x7

    const-string v3, "aeCaobctMcS.him.lc.aksle.v.repssegpvrbtDsaaesueheiaycp"

    const/4 v7, 0x2

    const-string v3, "cstvabei.psvcybkmhe..etamhalapDcesgC.ioMsasceulaep.rSe"

    const-string v3, "com.heytap.msp.push.service.DataMessageCallbackService"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v1, v0, v3}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    :cond_4
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string/jumbo v0, "ivov"

    const-string/jumbo v0, "vivo"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-nez v0, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string/jumbo v2, "oi-smtusvn-iape-bnveuctplno"

    const-string/jumbo v2, "n-vsidueovcbtpnmotlina-sep-"

    const-string v2, "abis-nvpd-cloevtpmsnn-opote"

    const-string/jumbo v2, "tpns-disable-component-vivo"

    const/4 v7, 0x0

    const/4 v6, 0x1

    sget-object v3, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v6, 0x2

    const/4 v6, 0x1

    invoke-static {v0, v2, v3}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    check-cast v0, Ljava/lang/Boolean;

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-eqz v0, :cond_5

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string/jumbo v2, "me.ccvdaqhnnmlpsmovSoesoee.itsceduvCii..ipvrC."

    const-string v2, ".oncl.dpieaiS.coeusoemehmimkeivsvcsdCCpvr.n.vt"

    const/4 v7, 0x4

    const-string/jumbo v2, "scs.aCrtnmsu.o.dvehmpiodevmre..iseeSvinCclkioc"

    const-string v2, "com.vivo.push.sdk.service.CommandClientService"

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v1, v0, v2}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string v2, "etALoldiqi.usknctvronmc.pv.PsyCoivthiixyk"

    const/4 v7, 0x5

    const-string/jumbo v2, "v.pmtkAiyvPn.ouitsncoyiedckxlt.s.iorvmhCi"

    const-string v2, "com.vivo.push.sdk.LinkProxyClientActivity"

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v1, v0, v2}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/common/j$4;->a:Landroid/content/Context;

    const/4 v7, 0x4

    const-string/jumbo v2, "vdinooomsvsiopecv.sgnrcurssvhd.eaouaei.PMchte.iRteVe"

    const-string v2, "eesavseVctddo..PaeusvisehoMiv.nniosmicteorurpveg.chR"

    const/4 v7, 0x7

    const-string v2, "auvribeevdmeunso.ee.ooavrtctiognsM.svshciViephPendc."

    const-string v2, "com.tencent.android.vivopush.VivoPushMessageReceiver"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {v1, v0, v2}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string/jumbo v1, "litU"

    const/4 v7, 0x3

    const-string v1, "Util"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string v2, "Csxpmeuduon crenanoeemttfs pbedi"

    const-string/jumbo v2, "idombeteeCnxdstocn mapepsreuo fn"

    const-string/jumbo v2, "psnn expelnoatmoptC rdedsucofbei"

    const-string/jumbo v2, "unexpected for disableComponents"

    const/4 v6, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_5
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    return-void
.end method
