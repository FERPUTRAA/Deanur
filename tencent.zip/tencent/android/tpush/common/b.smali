.class public Lcom/tencent/android/tpush/common/b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/common/b$a;,
        Lcom/tencent/android/tpush/common/b$b;
    }
.end annotation


# static fields
.field private static volatile a:Lcom/tencent/android/tpush/common/b$b;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "o s ~@@@@o~~.uo4~ @~@ ~l@~@~~ ~a ~i b@~b@ ~f@  oo-v@o@/~dl@M r ~y@~@ fb1@~ @~ts ~m@ ~Si~i@~K c/t"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    return-void
.end method
