.class Lcom/tencent/android/tpush/common/b$b;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/common/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "b"
.end annotation


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "Mls@-d@~~v@~K@@@@tu1a~~n of@ ~@~4 @mbt@oS~~~i  / @ o   o~i ~~ @@r@.~@~~sbi b  ~~@~o@~ @clf~~ @/o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    if-eqz p2, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    new-instance v1, Lcom/tencent/android/tpush/common/b$a;

    const/4 v3, 0x6

    invoke-direct {v1, p1, p2}, Lcom/tencent/android/tpush/common/b$a;-><init>(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method
