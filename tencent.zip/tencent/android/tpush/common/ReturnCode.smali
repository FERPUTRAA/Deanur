.class public final enum Lcom/tencent/android/tpush/common/ReturnCode;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/tencent/android/tpush/common/ReturnCode;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_ACCESSKET_OR_ACCESSID_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_DUPLICATE_REGISTER_EEROR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_INVALID_ACCOUNT:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_INVALID_ATTRIBUTE:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_INVALID_QUERYTAGS:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_INVALID_TAG:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_JCE_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_LOGIC_ILLEGAL_ARGUMENT:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_LOGIC_REGISTER_IN_PROCESS:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_NETWORK_CHANNEL_CANCELLED:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_NETWORK_HANDLER_NULL:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_NETWORK_INNER_EXCEPTION_OCCUR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_NETWORK_IOEXCEPTION_OCCUR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_NETWORK_SECERETY_EEROR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_NETWORK_TIMEOUT_EXCEPTION_OCCUR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_NETWORK_TIMEOUT_WAITING_FOR_RESPONSE:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_NETWORK_TIMEOUT_WAITING_TO_SEND:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_NETWORK_UNEXPECTED_DATA_EXCEPTION_OCCUR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_NETWORK_UNKNOWN_EXCEPTION:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_NETWORK_UNREACHABLE:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_PERMISSIONS_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_PROVIDER_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_SDK_API_FREQUENCY_LIMIT_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_SDK_PARAM_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_SERVICE_DISABLED:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_SO_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_STRATEGY_INIT:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum CODE_SUCCESS:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum ERRORCODE_UNKNOWN:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum FLAG_OFFLINE:Lcom/tencent/android/tpush/common/ReturnCode;

.field public static final enum FLAG_ONLINE:Lcom/tencent/android/tpush/common/ReturnCode;


# instance fields
.field private str:Ljava/lang/String;

.field private type:I


# direct methods
.method static constructor <clinit>()V
    .locals 36

    new-instance v0, Lcom/tencent/android/tpush/common/ReturnCode;

    const-string/jumbo v1, "uus6fdc38u///fd8ueaf429f/5f7/c0dcb46eu78/ud508uu/68/8/s4f7575/uu/6"

    const-string v1, "f3sduub8d/6072u8fuc5f/7cuu/8/d9d06ff/e7ce7a//8//u454u/u6f488/u5756"

    const-string v1, "/ucmf42594f08u//686f4uu/d/867f8d3c88a757cdbu6//fu7/fe/70d5u5ueu/uu"

    const-string/jumbo v1, "\u8fd4\u56de\u6807\u5fd7\uff0c\u8868\u793a\u5728\u7ebf\u64cd\u4f5c"

    const-string v2, "FIO_oLEAmNL"

    const-string v2, "LALmN_INFEO"

    const-string v2, "IGNLNbA_OLF"

    const-string v2, "FLAG_ONLINE"

    const/4 v3, 0x0

    invoke-direct {v0, v2, v3, v3, v1}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v0, Lcom/tencent/android/tpush/common/ReturnCode;->FLAG_ONLINE:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v1, Lcom/tencent/android/tpush/common/ReturnCode;

    const-string v2, "7/9f88uu/uuuf/7u4fb0c9uu7bb/0f7/6o/uu5d8f6/83//dd/ec5ca68u4feu/d76"

    const-string/jumbo v2, "u9u6o/u/5bdfaf6//uu3u/uufc80/d8/765dc4d/u956/7bce7fu8/88b7e0f/4u7f"

    const-string v2, "cf6/u/5pf/u8bfabdf8uf7u469ud75//7u4e8/08c7/0/7/d6/uu3469f8uuub5c/e"

    const-string/jumbo v2, "\u8fd4\u56de\u6807\u5fd7\uff0c\u8868\u793a\u79bb\u7ebf\u64cd\u4f5c"

    const-string v4, "bFEALNLGq_FO"

    const-string v4, "_IEGFbANOFLL"

    const-string v4, "ILsN_FALGFFO"

    const-string v4, "FLAG_OFFLINE"

    const/4 v5, 0x1

    invoke-direct {v1, v4, v5, v5, v2}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v1, Lcom/tencent/android/tpush/common/ReturnCode;->FLAG_OFFLINE:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v2, Lcom/tencent/android/tpush/common/ReturnCode;

    const-string v4, "5/um2692f/u0"

    const-string/jumbo v4, "\u6210\u529f"

    const-string v6, "COSEoU_SEuDS"

    const-string v6, "OU_CSSuDESCE"

    const-string v6, "SECCUbE_OSDS"

    const-string v6, "CODE_SUCCESS"

    const/4 v7, 0x2

    invoke-direct {v2, v6, v7, v3, v4}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v2, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SUCCESS:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v4, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v6, 0x2710

    const-string v8, "9uub8pu/9d/u71//b9eu875f"

    const-string v8, "/89bue8p/7b1f/u/95cd79uu"

    const-string v8, "eu1b5cbp8fu857u///7du/99"

    const-string/jumbo v8, "\u8d77\u59cb\u9519\u8bef"

    const-string v9, "R_NOERUEqRCqODONK"

    const-string v9, "KONURO_RqDCNENROE"

    const-string v9, "NRsKOEUROWDENRC_N"

    const-string v9, "ERRORCODE_UNKNOWN"

    const/4 v10, 0x3

    invoke-direct {v4, v9, v10, v6, v8}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v4, Lcom/tencent/android/tpush/common/ReturnCode;->ERRORCODE_UNKNOWN:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v6, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v8, 0x2711

    const-string v9, "6b/m45069/8uf/8//51b9/u7b59e//62/e/6/1s2/u54f5ue0/fuuu1uc8u5/ubduu78c5f8/59054c7u374/ffbufufc78uu/5501ba831uf8ud/6cb19571f9/u/u5e9u/"

    const-string v9, "88s9/uu/u0/c6u783u2u896ub1f/bc///bf/56/94/uuf556c1103775c07a0ue7c5u8/udf19u/71bueu5f9fe2u//cu/f/54/6ub55fu9beuu//5ffbd91/441/5u58588"

    const-string v9, "/8ubo74f1/15/89/4/2fbe/1uu3/578f6b976ffu1e7uuu/54u780u/u8fucb55956/54cbedc099/uuf13f/901cuc5055/88u/e9buu//u8/7c5dua66/b5u//51uf/u/2"

    const-string/jumbo v9, "\u64cd\u4f5c\u7c7b\u578b\u9519\u8bef\u7801\uff0c\u4f8b\u5982\u53c2\u6570\u9519\u8bef\u65f6\u5c06\u4f1a\u53d1\u751f\u8be5\u9519\u8bef"

    const-string v11, "IDmA_bOGLGOLLGTCCEL_UEMRAEN"

    const-string v11, "ICEmDNAM_TLRCOGILL_LUEOGGEA"

    const-string v11, "LEGACGuENRMI_DUET_GCLI_OLAO"

    const-string v11, "CODE_LOGIC_ILLEGAL_ARGUMENT"

    const/4 v12, 0x4

    invoke-direct {v6, v11, v12, v8, v9}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v6, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_LOGIC_ILLEGAL_ARGUMENT:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v8, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v9, 0x2712

    const-string v11, "60uc/u6pcu65fucucuecb5/c9/uc/8496u6e7f0uucu368/f85f65d8236u46/7duu14u/c875/1u14u78a//e2///5602/2bfcu848ce0c6/5f/5569/40u/ufc8u5/euu24/6u7/bf0u/56u//d/u0e01//8o3135u94/6"

    const-string v11, "15c6o87u0c/8bu0/0uu7/6f2c4uc/u/ce62buu6f/8c46d9u/fa4487c53ufu3u3c1fd634766/e/61u0u28/5uc/6/uu5/uece4168/95u252//u544f/9c0u/0c9050/u/u8/5/7uu/6668/5/u/88f/fe5665ed/cb1uu"

    const-string v11, "d//12a/7qduc6c6uu8/c6u5u1u/6fu/u//b/f523u9uu0/c452/6u8u0uu5cu/66125/5u75cuc/8/54uccf6u607/360/8609/f6uf3c/u6/f31u64d806bc0u84/8e81ebu5//e948784/0c//784uc62u5u5/e9fe/5ef"

    const-string/jumbo v11, "\u6b63\u5728\u6267\u884c\u6ce8\u518c\u64cd\u4f5c\u65f6\uff0c\u53c8\u6709\u4e00\u4e2a\u6ce8\u518c\u64cd\u4f5c\u5230\u6765\uff0c\u5219\u56de\u8c03\u6b64\u9519\u8bef\u7801"

    const-string v13, "PRsTLGE__SIERCE_O_SRIbNOCEICGD"

    const-string v13, "GNCR_bITSDOEPSCE_E_SRRELO_GICI"

    const-string v13, "_EOmCCGI_EDTSP_ONGECIROSLRSE_R"

    const-string v13, "CODE_LOGIC_REGISTER_IN_PROCESS"

    const/4 v14, 0x5

    invoke-direct {v8, v13, v14, v9, v11}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v8, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_LOGIC_REGISTER_IN_PROCESS:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v9, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v11, 0x2713

    const-string v13, "16/9o53u/9f1ua7u46uu595/"

    const-string v13, "5a/9/9u37/1f/516u469uuu5"

    const-string v13, "554u/b3u6u/76fu0591/a919"

    const-string/jumbo v13, "\u6743\u9650\u51fa\u9519"

    const-string v15, "EOMISRuECPE_NRSSOpOR_I"

    const-string v15, "IEIREOOp_PRMRNCODS_SSE"

    const-string v15, "RRIOIEOpSMPORDESS__CER"

    const-string v15, "CODE_PERMISSIONS_ERROR"

    const/4 v14, 0x6

    invoke-direct {v9, v15, v14, v11, v13}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v9, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_PERMISSIONS_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v11, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v13, 0x2714

    const-string v15, "5/suo11aq/5u9q9"

    const-string v15, "a/5/us91qf5uo91"

    const-string/jumbo v15, "o5su/59.ua191sf"

    const-string v15, ".so\u51fa\u9519"

    const-string v14, "EOsED_RRC_OOR"

    const-string v14, "RORmO_R_CSEDO"

    const-string v14, "CODE_SO_ERROR"

    const/4 v12, 0x7

    invoke-direct {v11, v14, v12, v13, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v11, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SO_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v13, Lcom/tencent/android/tpush/common/ReturnCode;

    const-string v14, "C_C_oDCR_ESKRSDmOOCORCETEAEEASSI"

    const-string v14, "DSOmRACER_ASERER_SDEI_OECCOTCSKC"

    const-string v14, "CA_ITbECRK_SROES_RDRECDCOAS_ECSE"

    const-string v14, "CODE_ACCESSKET_OR_ACCESSID_ERROR"

    const/16 v15, 0x8

    const/16 v12, 0x2716

    const-string v10, "b990s/uc sAe0euu1 /2K6e/uDyc56 fu1/csIcs5e8A"

    const-string v10, "AccessKey \u6216\u8005 AccessID \u9519\u8bef"

    invoke-direct {v13, v14, v15, v12, v10}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v13, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_ACCESSKET_OR_ACCESSID_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v12, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x2717

    const-string v15, "f34//dcp3fbu1e1e5/uue/vu1ce5/5o9/691b5ur9duei9uS2"

    const-string v15, "1cv3oicf935ur85u1d9u1Suuu///56ede/uf41ee/eb9b/592"

    const-string v15, "9f85r6duq5/ce/uudub/ece4/1/11u33evib9f9u2S/5u5/e9"

    const-string/jumbo v15, "\u521d\u59cb\u5316\u4fe1\u9e3dService\u9519\u8bef"

    const-string v7, "ESsRACBEED_IDCODIEb_V"

    const-string v7, "RCDBObECIVEDL__IEADSE"

    const-string v7, "DOEmS_EIVBCSDLEERAI_D"

    const-string v7, "CODE_SERVICE_DISABLED"

    const/16 v5, 0x9

    invoke-direct {v12, v7, v5, v14, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v12, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SERVICE_DISABLED:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v7, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x2718

    const-string v15, "RIEDoERE_RRVOuPOO_C"

    const-string v15, "ERR_ROuVROPEDOCR_IE"

    const-string v15, "RRRR_bOODRO_IEPECDV"

    const-string v15, "CODE_PROVIDER_ERROR"

    const/16 v5, 0xa

    invoke-direct {v7, v15, v5, v14, v10}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v7, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_PROVIDER_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v10, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x2719

    const-string v15, "//9e5fucRpbe uA8ujJ"

    const-string v15, "efR/cJApj59ue/9 8ub"

    const-string v15, "Re9b/fup5Aj/e89Ju c"

    const-string/jumbo v15, "jce JAR\u9519\u8bef"

    const-string v5, "CORRqOCEqR_E_J"

    const-string v5, "RCRO_C_JqREDEO"

    const-string v5, "_RsEDRC_EJOORC"

    const-string v5, "CODE_JCE_ERROR"

    const/16 v3, 0xb

    invoke-direct {v10, v5, v3, v14, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v10, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_JCE_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v5, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x2774

    const-string v15, "3edm7fu72e5/5uuff4dc3ud/s551/2/uu57//05/4e"

    const-string v15, "4usu25/75uf/534d2e03u157eu75dfd///e/fu5/cu"

    const-string v15, "f45dod/c557e5fu/74e2u5//u3fdu387e/u15u2//u"

    const-string/jumbo v15, "\u5f53\u524d\u7f51\u7edc\u4e0d\u53ef\u7528"

    const-string v3, "TDNAWbOBEE_UO_EKmNCARHRC"

    const-string v3, "EWEmDOONTCAER_KHRAEBCN_U"

    const-string v3, "ARAEOOuEUHRDN_KTLWCN_EEC"

    const-string v3, "CODE_NETWORK_UNREACHABLE"

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    const/16 v10, 0xc

    invoke-direct {v5, v3, v10, v14, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v5, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_UNREACHABLE:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v3, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x2775

    const-string v15, "b/2u/aupu8e/9518ef5e/f5f/2uuddo9534u"

    const-string v15, "f91do8be3u/15au9fdu8/5u/u2u//fee5542"

    const-string v15, "ffd512d5q/1e4a89uu59/u/ue/u3/ue/825b"

    const-string/jumbo v15, "\u521b\u5efa\u94fe\u8def\u5931\u8d25"

    const-string v10, "PEsC_WKCDbTAMESLAOLOTOREI_AT_IEOR__FDE"

    const-string v10, "CCOTAb_RPEL_WIKEEOD_ORLI_SAF_MAOTTEDCE"

    const-string v10, "_ATmAEMANDOLECL_IO_WOSREFTPT_CODEKI_EC"

    const-string v10, "CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED"

    move-object/from16 v17, v5

    move-object/from16 v17, v5

    move-object/from16 v17, v5

    move-object/from16 v17, v5

    const/16 v5, 0xd

    invoke-direct {v3, v10, v5, v14, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v3, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_CREATE_OPTIOMAL_SC_FAILED:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v10, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x2776

    const-string v15, "5e//ou/udf573bc5euu/6/c6/0/09e4u487au32/7u1c/f89/8bffuu0u2/ /8abfu47429e0ud7/8/u5bf4auu/ed4"

    const-string v15, "fb/84/ude0/ucudu/90/ef483/7fbfc05ueb4275/du/8u2/uuu19u80/c46u/u7a7/u/au4e527f6f8b3 4/9/u5ea"

    const-string v15, "7cafub974u/4u/ f7fe0e/5u25uf808udu/u82a4d/u/udbe/9/8e0b/58u/28a/3//fc4uc60bue74b57/61uf3/49"

    const-string/jumbo v15, "\u8bf7\u6c42\u5904\u7406\u8fc7\u7a0b\u4e2d\uff0c \u94fe\u8def\u88ab\u4e3b\u52a8\u5173\u95ed"

    const-string v5, "L__LpCuHCCDLCANEEENON_OEWAKNRD"

    const-string v5, "_AC_CNWpERCEHOLLEDNNENA_ODKELC"

    const-string v5, "LENOLEEpOCNAKAD_REWENT_DLHNCCC"

    const-string v5, "CODE_NETWORK_CHANNEL_CANCELLED"

    move-object/from16 v18, v3

    move-object/from16 v18, v3

    move-object/from16 v18, v3

    move-object/from16 v18, v3

    const/16 v3, 0xe

    invoke-direct {v10, v5, v3, v14, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v10, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_CHANNEL_CANCELLED:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v5, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x2777

    const-string v15, "74/fu/4aqq962/ub33ff1/d7470cuu4ua/8c48a650/6825d/659/ude/cu0//9u7f0uu7/e7uuu55fu/0/16eu6b/"

    const-string v15, "8bu3fuucqfc7b6da5//061uu410770u/f09e/f46a9c6225//2/uu85uu54d//u9e46/45u/7/f3/7a/d06uuu/87e"

    const-string v15, "97s4//fduuc//5uc7eucu//67e2uu4/4660//52ua15b/u0u///eu530bu775a/96/04d1f8d0uu93fu728865aff6"

    const-string/jumbo v15, "\u8bf7\u6c42\u5904\u7406\u8fc7\u7a0b\u4e2d\uff0c\u670d\u52a1\u5668\u5173\u95ed\u94fe\u63a5"

    const-string v3, "CNPmOECsDTEOXE_OKC__NOIIEUORRW"

    const-string v3, "NEsCCIXNEPCOORTROD_OCIWKEE_O_U"

    const-string v3, "_KOCoEROCNTEERIITXUOO_WECD_OPC"

    const-string v3, "CODE_NETWORK_IOEXCEPTION_OCCUR"

    move-object/from16 v19, v10

    move-object/from16 v19, v10

    const/16 v10, 0xf

    invoke-direct {v5, v3, v10, v14, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v5, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_IOEXCEPTION_OCCUR:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v3, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x2778

    const-string v15, "07e07b/f7/4u///2f/auu6fc2ebbbcu2f7u1387/4ufa3uu/55d0u/ebu/85c45/776//6040u2/5ub6u2f598au/4"

    const-string/jumbo v15, "\u8bf7\u6c42\u5904\u7406\u8fc7\u7a0b\u4e2d\uff0c\u5ba2\u6237\u6bb5\u4ea7\u751f\u5f02\u5e38"

    const-string v10, "O_KIC_uEO_EUECRETmXORNNR_IODTCNCWN"

    const-string v10, "EDKm_EOTR_ONWIUNE_RECCRNCCXOI_NOTE"

    const-string v10, "WNPCENCp_RDRIERC_ET_TXKEOO_OIENUCO"

    const-string v10, "CODE_NETWORK_INNER_EXCEPTION_OCCUR"

    move-object/from16 v20, v5

    move-object/from16 v20, v5

    move-object/from16 v20, v5

    move-object/from16 v20, v5

    const/16 v5, 0x10

    invoke-direct {v3, v10, v5, v14, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v3, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_INNER_EXCEPTION_OCCUR:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v10, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x2779

    const-string/jumbo v15, "uo48af6fqf0d/69u/6u7867u561/f0f//5d06/cu/u42eu9501//u46/cu2875uc681u28u5u//634050/7u6/uu52b/b6da/3ua3/"

    const-string v15, "1u/8o620d/u6/60u/5/6c0/86/3a04b4fa5ff6ucf75du64uu66/u//u1/e/59uu6c55582885/2/0169/u3a/uf037u/247b7uuud"

    const-string v15, "/1s09256euffu262/6/c6cc/u66/u7/d50df8u//58/50/6bu63u95u76ufb/43/50u7u8u5a044//u/u04/af66du1u/7u1a87258"

    const-string/jumbo v15, "\u8bf7\u6c42\u5904\u7406\u8fc7\u7a0b\u4e2d\uff0c\u53d1\u9001\u6216\u63a5\u6536\u62a5\u6587\u8d85\u65f6"

    const-string v5, "CTbmMCOCXII_OCRUTETDOP_TNUEOEEE_NWO_"

    const-string v5, "OET_TbEMC_EECOURONDWI_NCOUPOCRIXTE_T"

    const-string v5, "CODE_NETWORK_TIMEOUT_EXCEPTION_OCCUR"

    move-object/from16 v21, v3

    move-object/from16 v21, v3

    move-object/from16 v21, v3

    move-object/from16 v21, v3

    const/16 v3, 0x11

    invoke-direct {v10, v5, v3, v14, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v10, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_TIMEOUT_EXCEPTION_OCCUR:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v5, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x277a

    const-string v15, "f/2fo3b4f98f6udueu62//buc08u/ca7u961/u4u4785/0/672/5uu5/8/u/f5/4buu/0 c18f/0/d77c0du69fu484buu/57"

    const-string v15, "cuuf16u/4/8660/4u4 b4/2du6dbu/2u5249fu5f51/78c075f9cu/u8u80//f35ef/0/buudua///9f7uu784b0576c/u/87"

    const-string/jumbo v15, "\u8bf7\u6c42\u5904\u7406\u8fc7\u7a0b\u4e2d\uff0c \u7b49\u5f85\u53d1\u9001\u8bf7\u6c42\u8d85\u65f6"

    const-string v3, "CODE_NETWORK_TIMEOUT_WAITING_TO_SEND"

    move-object/from16 v22, v10

    move-object/from16 v22, v10

    const/16 v10, 0x12

    invoke-direct {v5, v3, v10, v14, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v5, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_TIMEOUT_WAITING_TO_SEND:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v3, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x277b

    const-string v15, "f55u4bu584eu5//a8d/c7b/u5u/4u4u/u2ub4u/ued6//0/5f7p86c33/2f06b0u506/c7uu967/74bf65/7/u/8uf8549fa"

    const-string v15, "85/4/46p6b//3/b5/f5//a706b0565ud6f/u70f6f5d8a/u7uuf388u7/5u2b/9f467cu0u54u/e8/7e4uuuc4/u4/cu5u92"

    const-string v15, "859e4/u473/f6f8/u6uc/f/u/u/a/uu5/7875d5/bu0ef4b80uu8c06u507u/b627/a5c46f9udu79//6u555/b324/uu4f6"

    const-string/jumbo v15, "\u8bf7\u6c42\u5904\u7406\u8fc7\u7a0b\u4e2d\uff0c\u7b49\u5f85\u63a5\u6536\u5e94\u7b54\u8d85\u65f6"

    const-string v10, "SCWDFNApTIEMW_ETESEROETGIRP__RNOONTIOU_qK"

    const-string v10, "UTMNRWTNq_TGIRPOKWR__DTEOIFOSE_ACEOENEIS_"

    const-string v10, "EMOET_TKqONREINEUACE_SO_ORTIRWDFWO__TNIGS"

    const-string v10, "CODE_NETWORK_TIMEOUT_WAITING_FOR_RESPONSE"

    move-object/from16 v23, v5

    move-object/from16 v23, v5

    move-object/from16 v23, v5

    const/16 v5, 0x13

    invoke-direct {v3, v10, v5, v14, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v3, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_TIMEOUT_WAITING_FOR_RESPONSE:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v10, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x277c

    const-string v15, "2asueud1655s0a5d6880/u//2d566u8e7u65//37/8u5fu/652uu//"

    const-string/jumbo v15, "u/s52a07u0/u3u5ue6/6655//52ddu18u6/du5/87fuea868/265/f"

    const-string v15, "850me5du6a5u86f2/5du5866/52u/u/u/eu40a/83u1df2/u/57/67"

    const-string/jumbo v15, "\u670d\u52a1\u5668\u8fd4\u56de\u5f02\u5e38\u62a5\u6587"

    const-string v5, "TOCm_EKNDXUETXW_TN_OIEECCPAUOPRRDCCE_AO_ENTD"

    const-string v5, "ICU_oCUEDXCERPEN_NAKTW_O_ETENA_COXDCTTOODPER"

    const-string v5, "CODE_NETWORK_UNEXPECTED_DATA_EXCEPTION_OCCUR"

    move-object/from16 v24, v3

    move-object/from16 v24, v3

    move-object/from16 v24, v3

    move-object/from16 v24, v3

    const/16 v3, 0x14

    invoke-direct {v10, v5, v3, v14, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v10, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_UNEXPECTED_DATA_EXCEPTION_OCCUR:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v5, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v14, 0x277d

    const-string v15, "/u285befeu6/a/7/u5o3207u"

    const-string v15, "2e/uo8u5e/u/3257ua/f0567"

    const-string v15, "57e278u/6035uue/7uua2//5"

    const-string/jumbo v15, "\u672a\u77e5\u5f02\u5e38"

    const-string v3, "UW_KPNTpKCEWNTNNORDEOO_ENbIOXC"

    const-string v3, "WTNRNbKWCPODOONXTE_ON_UIEEN_CK"

    const-string v3, "EKE_KNN_qO_NTDNUWONTCCWEOEORIX"

    const-string v3, "CODE_NETWORK_UNKNOWN_EXCEPTION"

    move-object/from16 v25, v10

    move-object/from16 v25, v10

    move-object/from16 v25, v10

    move-object/from16 v25, v10

    const/16 v10, 0x15

    invoke-direct {v5, v3, v10, v14, v15}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v5, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_UNKNOWN_EXCEPTION:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v3, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v10, 0x277e

    const-string v14, "8/s64/luaul4aff2edr5hn//eu3u1laue/ebu/8dnfe74u5"

    const-string/jumbo v14, "\u521b\u5efa\u94fe\u8def\u7684handler\u4e3anull"

    const-string v15, "DRNmELO__HEREUWCNDuNK_TOL"

    const-string v15, "RLOCENuDUH_WLON_EN_ELKTRD"

    const-string v15, "HNR_o_KNEL_LLEWTNEOADRDCO"

    const-string v15, "CODE_NETWORK_HANDLER_NULL"

    move-object/from16 v26, v5

    move-object/from16 v26, v5

    move-object/from16 v26, v5

    move-object/from16 v26, v5

    const/16 v5, 0x16

    invoke-direct {v3, v15, v5, v10, v14}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v3, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_HANDLER_NULL:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v5, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v10, 0x277f

    const-string v14, "5/u8ub/c9ufafa78p7c/1bbb4/8u0ebu/u89"

    const-string v14, "1ufau5bpu8b8f/ua/4ebbu99c/u7/871/8c0"

    const-string v14, "5ub//1u9/c//81f8cu9b7ebaau48b80uu/f7"

    const-string/jumbo v14, "\u8ba4\u8bc1\u8fc7\u7a0b\u9519\u8bef"

    const-string v15, "WONOEE_pEEO_RKqECRSYERETTCR"

    const-string v15, "RENREOKOqY_S_TEWE_RCETEROEC"

    const-string v15, "ETWRSNDEqKOC_CEETRO_OE_YRER"

    const-string v15, "CODE_NETWORK_SECERETY_EEROR"

    move-object/from16 v27, v3

    move-object/from16 v27, v3

    move-object/from16 v27, v3

    move-object/from16 v27, v3

    const/16 v3, 0x17

    invoke-direct {v5, v15, v3, v10, v14}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v5, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_SECERETY_EEROR:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v3, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v10, 0x2783

    const-string v14, "dus7fc/5f64//76/18u5985e98e/9u/udu/d15c05uu/csu5"

    const-string v14, "5ds781de4/ue76d1fu596c81/uu/uc555//9//58cf90uuu/"

    const-string v14, "76um65//f5c/55dud8/91u159e847ud/69//0cfucu8uu/e1"

    const-string/jumbo v14, "\u77ed\u65f6\u95f4\u5185\u91cd\u590d\u6ce8\u518c"

    const-string v15, "RR_EoL_EISCDTOGCERRUOEDEA_IEP"

    const-string v15, "CODE_DUPLICATE_REGISTER_EEROR"

    move-object/from16 v28, v5

    move-object/from16 v28, v5

    move-object/from16 v28, v5

    move-object/from16 v28, v5

    const/16 v5, 0x18

    invoke-direct {v3, v15, v5, v10, v14}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v3, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_DUPLICATE_REGISTER_EEROR:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v5, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v10, 0x2784

    const-string v14, "6/60fb2/46/55u8mdu/88u57u7/eu4"

    const-string v14, "5d/m654uu/58u7/088f2eu76/6/46u"

    const-string/jumbo v14, "uu/766u/82du/6/755f36u44808e5u"

    const-string/jumbo v14, "\u65e0\u6548\u7684\u8d26\u53f7"

    const-string v15, "CCVDATOpA_DOCLIIoN_N"

    const-string v15, "_INIoLDAVDOECCTAON_C"

    const-string v15, "TANOI_EUqALCVCIDO_ND"

    const-string v15, "CODE_INVALID_ACCOUNT"

    move-object/from16 v29, v3

    const/16 v3, 0x19

    invoke-direct {v5, v15, v3, v10, v14}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v5, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ACCOUNT:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v3, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v10, 0x2785

    const-string v14, "b/s8e46u//07uu467e/80/8ub57576"

    const-string v14, "55uu/b6e888b/06/u4/77e0/667u47"

    const-string/jumbo v14, "u/6m5u6760b/5e/78u7u88474e/u06"

    const-string/jumbo v14, "\u65e0\u6548\u7684\u6807\u7b7e"

    const-string/jumbo v15, "uLIVoDGC__ETAAOD"

    const-string v15, "DO_GNVuDIALCE_AT"

    const-string v15, "E_DTAbADV_CNOILI"

    const-string v15, "CODE_INVALID_TAG"

    move-object/from16 v30, v5

    move-object/from16 v30, v5

    move-object/from16 v30, v5

    move-object/from16 v30, v5

    const/16 v5, 0x1a

    invoke-direct {v3, v15, v5, v10, v14}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v3, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_TAG:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v5, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v10, 0x2786

    const-string v14, "83762euc5787u/e//562u55/702uu/u8u64660u5//"

    const-string/jumbo v14, "\u65e0\u6548\u7684\u7528\u6237\u5c5e\u6027"

    const-string v15, "UITEINTpOIEDRAB_pVTLAC"

    const-string v15, "ET_NTEDpAIIBLDIACOUTRV"

    const-string v15, "ADRUILE_qTBITE_DCTNOIV"

    const-string v15, "CODE_INVALID_ATTRIBUTE"

    move-object/from16 v31, v3

    move-object/from16 v31, v3

    const/16 v3, 0x1b

    invoke-direct {v5, v15, v3, v10, v14}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v5, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_ATTRIBUTE:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v3, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v10, 0x2787

    const-string v14, "55s/u//776G20e3ue8u6 Ac768u/4b4 55//ueq58u2u66T"

    const-string v14, "3/5/4u//q8 6ee6u/T60557846 /8euuAu6G2277u5b/cu5"

    const-string/jumbo v14, "\u65e0\u6548\u7684\u67e5\u8be2 TAG \u53c2\u6570"

    const-string v15, "OQ_mECGNULsR_STEDIIVAY"

    const-string v15, "IGsUIVRLCDEY_OATA_NSQE"

    const-string v15, "UTVRoEO_NYLCADAQ_ISIDG"

    const-string v15, "CODE_INVALID_QUERYTAGS"

    move-object/from16 v32, v5

    move-object/from16 v32, v5

    move-object/from16 v32, v5

    move-object/from16 v32, v5

    const/16 v5, 0x1c

    invoke-direct {v3, v15, v5, v10, v14}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v3, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_INVALID_QUERYTAGS:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v5, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v10, 0x2788

    const-string v14, "50fe/bu0fdu3/uuf3//03/6S553/uuc162185Du5dbu/  a8u8aK8/6u09 70ud6//u/8368f98101u2u/9m fu59a/u/161 5977/c3/7/51a5u8u372c35/0f/2bu05/ue"

    const-string v14, "duem/df/ff//0u6 ub7u 08a123au13u80u88D/19d1/1/35/21c9/68u3/u6/ce5u5 S72519uuuuu6/5f056533550 //9/ua8a2f3u25707b87/u/5/f/93u0K608u/ c"

    const-string v14, "5u1/f1u1/021u8/8361075c/15ub//u0ue3031f8c/Su/u75//7853u9u8/ /8u85u02ub6/069Kue/3f6/92u575/du/aa/c u98uf 5a02/u583/369 6a370 df25uDuf"

    const-string v14, "SDK \u63a5\u53e3\u9650\u9891\uff0c\u8bf7\u52ff\u8c03\u7528\u63a8\u9001\u670d\u52a1\u63a5\u53e3 10 \u79d2\u5185\u8d85\u8fc7 10 \u6b21"

    const-string v15, "FOIETo_pRDD_KSNURMYAQEREE_CP__CLOR"

    const-string v15, "YEOIoRERUTP_MAFSDR_IOCKCDQ_EEL__NR"

    const-string v15, "CODE_SDK_API_FREQUENCY_LIMIT_ERROR"

    move-object/from16 v33, v3

    move-object/from16 v33, v3

    move-object/from16 v33, v3

    move-object/from16 v33, v3

    const/16 v3, 0x1d

    invoke-direct {v5, v15, v3, v10, v14}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v5, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SDK_API_FREQUENCY_LIMIT_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v3, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v10, 0x283c

    const-string v14, "6uaf8e87q91761775/d8341d65bu//u57cbu//8u0du5/d6u5fuu//"

    const-string v14, "6/7/7bu9516u/5u/5fec/6/u1ub//3d8af576dd8u7u8714d5u0/u8"

    const-string v14, "/5s8f/d1654/u98/u6u167757uf/ud8u6/a05768c//d3u1/ued75b"

    const-string/jumbo v14, "\u8dd1\u9a6c\u7b56\u7565\u76f8\u5173\u8fd4\u56de\u7801"

    const-string v15, "_DOmTEGCYNI_TTASEI"

    const-string v15, "CODE_STRATEGY_INIT"

    move-object/from16 v34, v5

    move-object/from16 v34, v5

    move-object/from16 v34, v5

    move-object/from16 v34, v5

    const/16 v5, 0x1e

    invoke-direct {v3, v15, v5, v10, v14}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v3, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_STRATEGY_INIT:Lcom/tencent/android/tpush/common/ReturnCode;

    new-instance v5, Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v10, 0x28a0

    const-string v14, "K0D2ouub761/u5u99S/ec5583f/"

    const-string v14, "c350u/u7ue59u/fK9/Sub6D2158"

    const-string v14, "5/bK/b89/07Du1c5fuS2ue36u9/"

    const-string v14, "SDK\u53c2\u6570\u9519\u8bef"

    const-string v15, "_EAD_AEpRP_RSORRDCMK"

    const-string v15, "ADRCMRuDPE_RE_OSR_OK"

    const-string v15, "CODE_SDK_PARAM_ERROR"

    move-object/from16 v35, v3

    move-object/from16 v35, v3

    move-object/from16 v35, v3

    move-object/from16 v35, v3

    const/16 v3, 0x1f

    invoke-direct {v5, v15, v3, v10, v14}, Lcom/tencent/android/tpush/common/ReturnCode;-><init>(Ljava/lang/String;IILjava/lang/String;)V

    sput-object v5, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SDK_PARAM_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    const/16 v3, 0x20

    new-array v3, v3, [Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v10, 0x0

    aput-object v0, v3, v10

    const/4 v0, 0x1

    aput-object v1, v3, v0

    const/4 v0, 0x2

    aput-object v2, v3, v0

    const/4 v0, 0x3

    aput-object v4, v3, v0

    const/4 v0, 0x4

    aput-object v6, v3, v0

    const/4 v0, 0x5

    aput-object v8, v3, v0

    const/4 v0, 0x6

    aput-object v9, v3, v0

    const/4 v0, 0x7

    aput-object v11, v3, v0

    const/16 v0, 0x8

    aput-object v13, v3, v0

    const/16 v0, 0x9

    aput-object v12, v3, v0

    const/16 v0, 0xa

    aput-object v7, v3, v0

    const/16 v0, 0xb

    aput-object v16, v3, v0

    const/16 v0, 0xc

    aput-object v17, v3, v0

    const/16 v0, 0xd

    aput-object v18, v3, v0

    const/16 v0, 0xe

    aput-object v19, v3, v0

    const/16 v0, 0xf

    aput-object v20, v3, v0

    const/16 v0, 0x10

    aput-object v21, v3, v0

    const/16 v0, 0x11

    aput-object v22, v3, v0

    const/16 v0, 0x12

    aput-object v23, v3, v0

    const/16 v0, 0x13

    aput-object v24, v3, v0

    const/16 v0, 0x14

    aput-object v25, v3, v0

    const/16 v0, 0x15

    aput-object v26, v3, v0

    const/16 v0, 0x16

    aput-object v27, v3, v0

    const/16 v0, 0x17

    aput-object v28, v3, v0

    const/16 v0, 0x18

    aput-object v29, v3, v0

    const/16 v0, 0x19

    aput-object v30, v3, v0

    const/16 v0, 0x1a

    aput-object v31, v3, v0

    const/16 v0, 0x1b

    aput-object v32, v3, v0

    const/16 v0, 0x1c

    aput-object v33, v3, v0

    const/16 v0, 0x1d

    aput-object v34, v3, v0

    const/16 v0, 0x1e

    aput-object v35, v3, v0

    const/16 v0, 0x1f

    aput-object v5, v3, v0

    sput-object v3, Lcom/tencent/android/tpush/common/ReturnCode;->$VALUES:[Lcom/tencent/android/tpush/common/ReturnCode;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IILjava/lang/String;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/lang/String;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v0, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput p3, p0, Lcom/tencent/android/tpush/common/ReturnCode;->type:I

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p4, p0, Lcom/tencent/android/tpush/common/ReturnCode;->str:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public static errCodeToMsg(I)Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~MSo@~pbo@~t~a ool@@i~~@~  K~~ .f1sv ~ ~@@oy@@~ nb @~ @ bt i@ @cm@~d~~r  @-@ 4/l~i@fo@~@ /~ u~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const/4 v0, -0x1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eq p0, v0, :cond_3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/16 v0, 0x2783

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eq p0, v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/16 v0, 0x4e21

    const/4 v2, 0x0

    const/4 v1, 0x3

    if-eq p0, v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/16 v0, 0x4e22

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-eq p0, v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    packed-switch p0, :pswitch_data_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-string p0, "EWqDNKORqR_RUE_ONN"

    const-string p0, "N_RROUKNq_WDEOERNO"

    const/4 v2, 0x3

    const-string p0, "RUsO_KCNWE_NDORNOR"

    const-string p0, "UNKNOWN_ERROR_CODE"

    const/4 v2, 0x0

    return-object p0

    :pswitch_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string p0, "ORJmDROAC_JE_sEER_"

    const-string p0, "COsJR_RRAEEEC_D_JO"

    const/4 v2, 0x4

    const-string p0, "_AJ_oE_CRRJOEROREC"

    const-string p0, "CODE_JCE_JAR_ERROR"

    const/4 v1, 0x1

    move v2, v1

    return-object p0

    :pswitch_1
    const/4 v2, 0x2

    const-string p0, "ODCVEbGIPONRE__EC_IRmDROOR"

    const-string p0, "_R_mOOOREEOCCDIEGDRVNR_PIF"

    const/4 v2, 0x0

    const-string p0, "IENOROuCOR__RRCIO_VFEGRPDD"

    const-string p0, "CODE_PROVIDER_CONFIG_ERROR"

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0

    :pswitch_2
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string p0, "DoAEOELpIS_DVIBDS_EER"

    const-string p0, "IDESoADVD_ICBEEESO_RL"

    const/4 v2, 0x1

    const-string p0, "EIODCEEVqEASSIBCRDD_L"

    const-string p0, "CODE_SERVICE_DISABLED"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0

    :pswitch_3
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string p0, "AEsCERR__SSORCEIDYCAE__SSRECbOCD"

    const-string p0, "DSEODbE_Y_OREC_AR_RISCECCESAKCSR"

    const/4 v2, 0x2

    const-string p0, "___mSOSO_CSORKEARECCRYADEIECCSDR"

    const-string p0, "CODE_ACCESSKEY_OR_ACCESSID_ERROR"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p0

    :pswitch_4
    const/4 v2, 0x6

    const-string p0, "_CDRoOIOECOIE__FuDRLNG"

    const-string p0, "ECDRRNuO_I_ELICRO_FGOD"

    const/4 v2, 0x7

    const-string p0, "_ILRObCE_R_IRDGCAODFEO"

    const-string p0, "CODE_AIDL_CONFIG_ERROR"

    const/4 v2, 0x0

    return-object p0

    :pswitch_5
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string p0, "RpSOO_uRREECD"

    const-string p0, "COOSE_RpR_DRE"

    const/4 v2, 0x6

    const-string p0, "_EODREOpROC_S"

    const-string p0, "CODE_SO_ERROR"

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object p0

    :pswitch_6
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string p0, "OOqOSIRPqIDSR_RMCEN_EE"

    const-string p0, "IRCMR_INqPS_OSEEDSEROO"

    const/4 v2, 0x2

    const-string p0, "SEsNEOIMI_DROERPCR_SOS"

    const-string p0, "CODE_PERMISSIONS_ERROR"

    const/4 v2, 0x4

    return-object p0

    :pswitch_7
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-string p0, "RLEmsIERONREIC_OSP_EI_T_SSCOGG"

    const-string p0, "SSsCP_I_SOEEIEGOERRDICGLTRN_O_"

    const/4 v2, 0x7

    const-string p0, "RNSGoCG_IRIEOO_RIPCO_ELSSET_DE"

    const-string p0, "CODE_LOGIC_REGISTER_IN_PROCESS"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0

    :pswitch_8
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-string p0, "GMANmbELA_LTERIL"

    const-string p0, "TERm_GMLLGEAIANL"

    const/4 v2, 0x5

    const-string p0, "ULE_MGuGENLATALR"

    const-string p0, "ILLEGAL_ARGUMENT"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object p0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string p0, "OTOECRTpQ_RR_MNEToOCDN_"

    const-string p0, "RCONoRTETTM_N_EO_DERCQO"

    const/4 v2, 0x1

    const-string p0, "RNCTECTCq__DQEMNORETOO_"

    const-string p0, "CODE_MQTT_CONNECT_ERROR"

    const/4 v2, 0x0

    const/4 v1, 0x0

    return-object p0

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string p0, "SRsR_bURS_IBBOCREECD"

    const-string p0, "_RBCObCESEBORDRR_IUS"

    const/4 v2, 0x1

    const-string p0, "UCRm_R_REORCDIEBESOS"

    const-string p0, "CODE_SUBSCRIBE_ERROR"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object p0

    :cond_2
    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string p0, "P_RAoETCIREGIETRUEuRDOSEEDO_C"

    const-string p0, "OECIP_uEAT_TEREDDGOLRCEIRSURE"

    const/4 v2, 0x4

    const-string p0, "TSE_Eb_IUDGPRLIEOEDCETRROR_EA"

    const-string p0, "CODE_DUPLICATE_REGISTER_EEROR"

    const/4 v2, 0x3

    const/4 v1, 0x6

    return-object p0

    :cond_3
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string p0, "_KSRRNOpCEOE_DERNI_D"

    const/4 v2, 0x1

    const-string p0, "CO_RIKuDEORERRN__SDN"

    const-string p0, "CODE_SDK_INNER_ERROR"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object p0

    nop

    :pswitch_data_0
    .packed-switch 0x2711
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/tencent/android/tpush/common/ReturnCode;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-class v0, Lcom/tencent/android/tpush/common/ReturnCode;

    const-class v0, Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    check-cast p0, Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-object p0
.end method

.method public static values()[Lcom/tencent/android/tpush/common/ReturnCode;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/common/ReturnCode;->$VALUES:[Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lcom/tencent/android/tpush/common/ReturnCode;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    check-cast v0, [Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method


# virtual methods
.method public getStr()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/common/ReturnCode;->str:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x3

    return-object v0
.end method

.method public getType()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    iget v0, p0, Lcom/tencent/android/tpush/common/ReturnCode;->type:I

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    return v0
.end method
