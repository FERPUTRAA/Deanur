.class Lcom/tencent/android/tpush/common/c$a;
.super Landroid/os/Handler;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/common/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# instance fields
.field private a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/os/Handler;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/common/c$a;->a:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "uvs@~ @~~sb~@t~f~@~~.@b@/ a@~t~b~@ ~~@f@o~ mro ~/ yl So~~@lio @d  iio   n~~ 1~@~~4-@@@@ Mc  @K@@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/common/c$a;->a:Landroid/content/Context;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-super {p0, p1}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget v1, p1, Landroid/os/Message;->what:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    move v4, v3

    if-eq v1, v2, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    const/4 v2, 0x2

    const/4 v4, 0x1

    const/4 v3, 0x2

    if-eq v1, v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-super {p0, p1}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget p1, p1, Landroid/os/Message;->arg1:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/common/c;->g(Landroid/content/Context;I)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/common/c;->a()I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-lez p1, :cond_3

    const/4 v3, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {v2}, Lcom/tencent/android/tpush/common/c;->a(I)I

    :cond_3
    const/4 v4, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/common/c;->a()I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez p1, :cond_4

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/common/c$a;->a:Landroid/content/Context;

    const/4 v4, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/common/c;->b()I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/common/c;->f(Landroid/content/Context;I)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/4 p1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/common/c;->b(I)I

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/common/c;->c()Landroid/os/Handler;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_4
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method
