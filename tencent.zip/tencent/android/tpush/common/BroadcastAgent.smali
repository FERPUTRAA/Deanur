.class public Lcom/tencent/android/tpush/common/BroadcastAgent;
.super Ljava/lang/Object;


# static fields
.field private static volatile a:Z

.field private static b:Lcom/tencent/android/tpush/XGPushBaseReceiver;

.field private static c:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x0

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method private static a(Landroid/content/Context;)V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "~@s@~o ~ibo@rl4v@~Ms.@@~@ u 1n~@@~t  o y @i~~fb@~K@ @b-i~~d~@ @o~@mt ~/lcS ~@~@@~a @~ oo~   ~/ f"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    const-string/jumbo v0, "ngamdcBetrsaoA"

    const-string v0, "BroadcastAgent"

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    sget-boolean v1, Lcom/tencent/android/tpush/common/BroadcastAgent;->a:Z

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    return-void

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo v1, "rnecoItaeRnyssnivti eBeraitc"

    const-string/jumbo v1, "tesieIaeesv tnBnaRicrrtnycsi"

    const/4 v7, 0x2

    const-string v1, "iRceebacntI vinieBsetnetarry"

    const-string/jumbo v1, "try initBaseReceiverInstance"

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    if-nez v1, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-void

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-instance v2, Landroid/content/Intent;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string v3, "co.tSeuSxAnaG.itmoEecpmEPotUnad_rnvndH..cS.Mi."

    const-string v3, ".Snmvir_aoinSiee.HPxoEMGnc.dAptt..adtEnUccmSo."

    const/4 v7, 0x5

    const-string/jumbo v3, "tGiidnppSSam.cEeccenaPnx..indM._AHttUgoroov.ES"

    const-string v3, "com.tencent.android.xg.vip.action.PUSH_MESSAGE"

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/high16 v3, 0x20000

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->queryBroadcastReceivers(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v1, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-lez v2, :cond_3

    const/4 v7, 0x1

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v2, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x6

    check-cast v2, Landroid/content/pm/ResolveInfo;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object v3, v2, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v3, v3, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x2

    if-nez v4, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v4, v3}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-class v5, Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const-class v5, Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const/4 v7, 0x0

    const-class v5, Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const-class v5, Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v5, v4}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v5

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-eqz v5, :cond_2

    const/4 v7, 0x5

    iget-object v1, v2, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v1, v1, Landroid/content/pm/ActivityInfo;->processName:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v1, :cond_3

    :try_start_1
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/Util;->getCurProcessName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz p0, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result p0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    sput p0, Lcom/tencent/android/tpush/common/BroadcastAgent;->c:I

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v4}, Ljava/lang/Class;->newInstance()Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x5

    check-cast p0, Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    sput-object p0, Lcom/tencent/android/tpush/common/BroadcastAgent;->b:Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x4

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string/jumbo v1, "vineseucqe Iniestatseecc iBnoRsrs"

    const-string v1, "eeccouiiaicrtBtIeessenvs s neRnsa"

    const/4 v7, 0x4

    const-string v1, "BusecesscnrIRcneseiv aesicnaseit "

    const-string/jumbo v1, "initBaseReceiverInstance success "

    const/4 v6, 0x2

    move v7, v6

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v7, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string v2, "g:emBrseo irRvaecsrtIee rcaennb"

    const-string/jumbo v2, "saeeIbrRecvgr:o eseri enatnctBr"

    const/4 v7, 0x0

    const-string v2, "grrBocoeeeeIeaare: sRcttninve r"

    const-string v2, "getBaseReceiverInstance error: "

    const/4 v7, 0x5

    const/4 v6, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :catchall_1
    :cond_3
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    const/4 p0, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    sput-boolean p0, Lcom/tencent/android/tpush/common/BroadcastAgent;->a:Z

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-void
.end method

.method private static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string p0, "GsEEXbies.noHIR.CiPmEUpS_u"

    const-string p0, "SCsHoiuRnPsU_XEeri..IpEGmE"

    const/4 v2, 0x4

    const-string p0, "IVUEn.u.ioGrSHeXmPECEi_sRp"

    const-string p0, ".permission.XGPUSH_RECEIVE"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object p0
.end method

.method public static registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V
    .locals 10

    :try_start_0
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v8, 0x0

    shr-int/2addr v9, v8

    const/16 v1, 0x21

    const/4 v9, 0x2

    const/4 v8, 0x0

    if-lt v0, v1, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/4 v0, 0x2

    const/4 v8, 0x0

    move v9, v8

    if-eq p3, v0, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    const/4 v0, 0x4

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-eq p3, v0, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/4 v1, 0x1

    const/4 v9, 0x5

    if-eq p3, v1, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    move v7, v0

    move v7, v0

    move v7, v0

    move v7, v0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_0

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    move v7, p3

    move v7, p3

    const/4 v9, 0x5

    move v7, p3

    move v7, p3

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    const/4 v6, 0x0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static/range {v2 .. v7}, Ld3/i;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;I)Landroid/content/Intent;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    goto :goto_1

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p3

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    const/4 v0, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p3, p1, p2, p0, v0}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;Ljava/lang/String;Landroid/os/Handler;)Landroid/content/Intent;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x6

    const/4 v8, 0x0

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x7

    return-void
.end method

.method public static sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string v0, "gcoeBnrpAtastp"

    const-string v0, "ctraAgtpondBes"

    const-string/jumbo v0, "rgtcadteqBsnoa"

    const-string v0, "BroadcastAgent"

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string/jumbo v2, "nPsegacdo_ASmMG.ncUxE.doH.r.SiattiEp.einoqctnv"

    const-string/jumbo v2, "n.grao.SqdicEpc..tSimAv.tcieaHMSxnPonde_GnUEot"

    const/4 v5, 0x4

    const-string v2, "caEmn..._iUoviSnmtopAxG.aHPSt.reieMnnd.ogtdESc"

    const-string v2, "com.tencent.android.xg.vip.action.PUSH_MESSAGE"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string v2, "acpKon...er.iAg.eatnEidEDcnnittCxoBdo.csmv"

    const-string/jumbo v2, "masxopnCeEcdgcAa.cdreiviFK.tto..nEiB..ntnD"

    const/4 v5, 0x3

    const-string v2, "Kexnib.icBE.drg..ca.FdteooctvEDintpmnACo.n"

    const-string v2, "com.tencent.android.xg.vip.action.FEEDBACK"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v2, :cond_1

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->a(Landroid/content/Context;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget-object v2, Lcom/tencent/android/tpush/common/BroadcastAgent;->b:Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    sget v2, Lcom/tencent/android/tpush/common/BroadcastAgent;->c:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-ne v2, v3, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const-string/jumbo v3, "ssriaeuootBTsdcp escrBoeaevcera"

    const-string/jumbo v3, "processBroadcastToBaseReceiver "

    const/4 v5, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v1, Lcom/tencent/android/tpush/common/BroadcastAgent;->b:Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, p0, p1}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    return-void

    :catchall_0
    move-exception v1

    :try_start_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo v3, "reaedsBpsv oerrToRicocoerarc sapt:meBs"

    const-string/jumbo v3, "oesmpRtessrscBca :Be Tcdrriarrrvooaeoe"

    const/4 v5, 0x0

    const-string/jumbo v3, "sairsoBoq :rcrRaTpasrreeceooreecestvB "

    const-string/jumbo v3, "processBroadcastToBaseReceiver error: "

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {p1, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p0, p1, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v5, 0x6

    goto :goto_0

    :catchall_1
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v5, 0x3

    return-void
.end method

.method public static unregisterReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;)V
    .locals 2

    :try_start_0
    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Landroid/content/Context;->unregisterReceiver(Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method
