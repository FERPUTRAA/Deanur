.class public Lcom/tencent/android/tpush/common/a;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " vsm@uy f@ /@~~@ @~i  rb  ~ o@ob~ oSK@@~~~~~4@tl ltM~b @o.~@~ ~  @-@@~o~~  oind~/@1si@~@~ca@@@~f"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object v1

    :cond_0
    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v0, Ljava/net/URL;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v0, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/net/URL;->getHost()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/net/MalformedURLException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-object p0

    :catch_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v0, "HtpmneptetlccrsAH"

    const-string v0, "HtsrAlepnHcpoctte"

    const/4 v4, 0x3

    const-string v0, "eHplopneAccrtttou"

    const-string v0, "AccountHttpHelper"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo v2, "m:e ib gHnetexottpascoN"

    const-string v2, "c: mttHsaoeN pntigeomxe"

    const/4 v4, 0x2

    const-string/jumbo v2, "tiE smuxHN:cpto ntaegoe"

    const-string v2, "getHostName Exception :"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v0, v2, p0}, Lcom/tencent/tpns/baseapi/base/util/Logger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-object v1
.end method

.method private static a(Landroid/content/Context;Ljava/lang/String;JI)Lorg/json/JSONObject;
    .locals 5

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v1, Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x4

    const-string v2, "acIocsdp"

    const-string v2, "acssocId"

    const/4 v4, 0x7

    const-string/jumbo v2, "qcdsesca"

    const-string v2, "accessId"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, v2, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo p2, "rkssodbinV"

    const-string/jumbo p2, "sVirebonkd"

    const/4 v4, 0x3

    const-string/jumbo p2, "rdVmosnsei"

    const-string/jumbo p2, "sdkVersion"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo p3, "u.3.o19"

    const-string p3, "1...93u"

    const/4 v4, 0x4

    const-string p3, ".419.b3"

    const-string p3, "1.4.3.9"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo p2, "omrf"

    const-string/jumbo p2, "mrof"

    const/4 v4, 0x7

    const-string/jumbo p2, "rfom"

    const-string p2, "from"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    const/4 p3, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 p2, 0x6

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v2, "eyroaput_erto"

    const-string/jumbo v2, "oror_tapytpee"

    const/4 v4, 0x6

    const-string/jumbo v2, "oepp_ttporray"

    const-string/jumbo v2, "operator_type"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eq p4, p2, :cond_5

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 p2, 0x2

    move v4, p2

    const/4 v3, 0x3

    move v4, v3

    if-ne p4, p2, :cond_0

    const/4 v3, 0x2

    move v4, v3

    goto/16 :goto_1

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-ne p4, p3, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    const/4 p1, 0x4

    :try_start_1
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1, v2, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance p1, Lorg/json/JSONArray;

    const/4 v4, 0x0

    invoke-direct {p1}, Lorg/json/JSONArray;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1, p0}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo p0, "ket_tnsiql"

    const-string p0, "_lnettsiqk"

    const/4 v4, 0x2

    const-string/jumbo p0, "kisleotns_"

    const-string/jumbo p0, "token_list"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1, p0, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x2

    return-object v1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-nez p4, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1, v2, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto :goto_2

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 p2, 0x3

    const/4 v4, 0x3

    if-eq p4, p2, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const/4 p3, 0x7

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-ne p4, p3, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    goto :goto_0

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x7

    const-string p0, "HcsteActHpeuortln"

    const/4 v4, 0x1

    const-string p0, "HrHmtpntucteplceA"

    const-string p0, "AccountHttpHelper"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo p2, "yepcoo prfau anrfo1p mtuoputtstae/ne"

    const-string/jumbo p2, "unum yt  octr1paaepafrtefutpc/onespo"

    const/4 v4, 0x2

    const-string/jumbo p2, "unsupport account operate type\uff1a"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, p4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p0, p1}, Lcom/tencent/tpns/baseapi/base/util/Logger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object v0

    :cond_4
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1, v2, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_2

    :cond_5
    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v1, v2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    :goto_2
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance p2, Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {p2}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p3

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-nez p3, :cond_6

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance p3, Lorg/json/JSONArray;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {p3, p1}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const-string/jumbo p1, "uaciobol_ctt"

    const-string/jumbo p1, "t_scoaotiluc"

    const/4 v4, 0x7

    const-string p1, "cittasuncu_l"

    const-string p1, "account_list"

    invoke-virtual {p2, p1, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_6
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string p1, "ebpnt"

    const-string p1, "btoen"

    const/4 v4, 0x7

    const-string/jumbo p1, "token"

    const/4 v4, 0x1

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-virtual {p2, p1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance p0, Lorg/json/JSONArray;

    const/4 v3, 0x2

    move v4, v3

    invoke-direct {p0}, Lorg/json/JSONArray;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, p2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo p1, "nuoa_ockqtncte"

    const-string/jumbo p1, "uc_netutcnokoa"

    const/4 v4, 0x2

    const-string p1, "e_satcnnksutoc"

    const-string/jumbo p1, "token_accounts"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, p1, p0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object v1

    :catchall_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    return-object v0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;JILcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 9

    const-string v0, ""

    const-string/jumbo v1, "retmoctHHupAntcpl"

    const-string/jumbo v1, "tleonpcprAtHctHpu"

    const-string v1, "ceonotHcAeuHptlpr"

    const-string v1, "AccountHttpHelper"

    :try_start_0
    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object v2

    invoke-virtual {v2}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->shouldRefuse()Z

    move-result v2

    if-eqz v2, :cond_1

    const-string/jumbo p0, "rlnuybtoypo t c tcqAhsbddufeecBusn"

    const-string/jumbo p0, "ynoedouyqfltedthAnreups c bB usctc"

    const-string p0, "Ahyd cuncelupofotdc dbtysuBt eerus"

    const-string/jumbo p0, "sendAccountByhttp refused by cloud"

    invoke-static {v1, p0}, Lcom/tencent/tpns/baseapi/base/util/Logger;->i(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz p5, :cond_0

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SERVICE_DISABLED:Lcom/tencent/android/tpush/common/ReturnCode;

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->errCodeToMsg(I)Ljava/lang/String;

    move-result-object p0

    invoke-interface {p5, v0, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_0
    return-void

    :cond_1
    invoke-static {p0, p1, p2, p3, p4}, Lcom/tencent/android/tpush/common/a;->a(Landroid/content/Context;Ljava/lang/String;JI)Lorg/json/JSONObject;

    move-result-object p1

    if-nez p1, :cond_3

    if-eqz p5, :cond_2

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_INNER_EXCEPTION_OCCUR:Lcom/tencent/android/tpush/common/ReturnCode;

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->errCodeToMsg(I)Ljava/lang/String;

    move-result-object p0

    invoke-interface {p5, v0, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_2
    return-void

    :cond_3
    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getBatchOpertorServerAddr(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/tencent/android/tpush/common/a;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    new-instance p1, Ljava/lang/StringBuilder;

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const-string p2, "ctce:sqptranRS"

    const-string p2, "custe:arqtcRSn"

    const-string/jumbo p2, "tcoceutRqanrq:"

    const-string p2, "accountReqStr:"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo p2, "musl :"

    const-string p2, ":urm l"

    const-string/jumbo p2, "ul,m: "

    const-string p2, ", url:"

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v1, p1}, Lcom/tencent/tpns/baseapi/base/util/Logger;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {p0, v4}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->getServerIPAddress(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    new-instance v7, Lcom/tencent/android/tpush/common/a$1;

    invoke-direct {v7, p5}, Lcom/tencent/android/tpush/common/a$1;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v8, 0x1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    invoke-static/range {v2 .. v8}, Lcom/tencent/tpns/baseapi/base/util/HttpHelper;->sendHttpRequest(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;Z)Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    return-void

    :catchall_0
    move-exception p0

    const-string/jumbo p1, "pptcoche npxout,denifeecesoy onorAtcxn:dBetu"

    const-string/jumbo p1, "tn,no eortfoxhpeneudeux:endpBe ci cpoAttsycc"

    const-string/jumbo p1, "tdeccbcpeeontdxesrBoxe,u Ancniuoyp ttpfe tnh"

    const-string/jumbo p1, "unexpected for sendAccountByhttp, exception:"

    invoke-static {v1, p1, p0}, Lcom/tencent/tpns/baseapi/base/util/Logger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    if-eqz p5, :cond_4

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_INNER_EXCEPTION_OCCUR:Lcom/tencent/android/tpush/common/ReturnCode;

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->errCodeToMsg(I)Ljava/lang/String;

    move-result-object p0

    invoke-interface {p5, v0, p1, p0}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_4
    return-void
.end method
