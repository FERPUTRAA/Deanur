.class Lcom/tencent/android/tpush/common/i$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/common/i;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# static fields
.field public static a:Lcom/tencent/android/tpush/common/i;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance v0, Lcom/tencent/android/tpush/common/i;

    const/4 v1, 0x7

    move v2, v1

    invoke-direct {v0}, Lcom/tencent/android/tpush/common/i;-><init>()V

    const/4 v1, 0x1

    move v2, v1

    sput-object v0, Lcom/tencent/android/tpush/common/i$a;->a:Lcom/tencent/android/tpush/common/i;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method
