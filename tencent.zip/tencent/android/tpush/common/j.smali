.class public Lcom/tencent/android/tpush/common/j;
.super Ljava/lang/Object;


# static fields
.field public static a:Ljava/lang/String;

.field private static b:Ljava/util/concurrent/atomic/AtomicBoolean;

.field private static c:Z

.field private static final d:Ljavax/security/auth/x500/X500Principal;

.field private static e:Ljava/lang/String;

.field private static f:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    sput-object v0, Lcom/tencent/android/tpush/common/j;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    sput-boolean v1, Lcom/tencent/android/tpush/common/j;->c:Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    new-instance v0, Ljavax/security/auth/x500/X500Principal;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string v1, "=rssogDCNeoindSUO,,dC Adnr=iudb"

    const-string v1, "iCsri Agbdo,Un=,SNCedduDr=AOnod"

    const/4 v3, 0x2

    const-string v1, "dUumoASd,iNn,br=rCendDOgioCdA=="

    const-string v1, "CN=Android Debug,O=Android,C=US"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Ljavax/security/auth/x500/X500Principal;-><init>(Ljava/lang/String;)V

    sput-object v0, Lcom/tencent/android/tpush/common/j;->d:Ljavax/security/auth/x500/X500Principal;

    const/4 v3, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    sput-object v0, Lcom/tencent/android/tpush/common/j;->e:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    sput-object v0, Lcom/tencent/android/tpush/common/j;->f:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v2, 0x1

    sput-object v0, Lcom/tencent/android/tpush/common/j;->a:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-void
.end method

.method public static a(Landroid/content/Context;)I
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "d~@yo @@~unc@-@i~K M  @@@i i@ o@o~r~@ 1 @ ~fo~~~lo ~fbl s@ /~ t@~~@~ ~ao~t @@S~. ~bm v@o~b~~~@/@"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x3

    const-string v0, "Ulti"

    const-string v0, "Util"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    sget-object v1, Lcom/tencent/android/tpush/common/j;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v1}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    const/4 v2, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz v1, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    return v2

    :cond_0
    :try_start_0
    const/4 v8, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->init(Landroid/content/Context;)V

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-nez v1, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->setContext(Landroid/content/Context;)V

    :cond_1
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-nez v1, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/service/b;->b(Landroid/content/Context;)V

    :cond_2
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushProvider;->fetchProviderAuthorities(Landroid/content/Context;)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->i(Landroid/content/Context;)Z

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-nez v1, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string p0, " XisGbme adil"

    const-string/jumbo p0, "siemd  iGXsal"

    const/4 v9, 0x5

    const-string p0, "XG is disable"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    sget-object p0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SERVICE_DISABLED:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    return p0

    :cond_3
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/security/Security;->checkTpnsSecurityLibSo(Landroid/content/Context;)Z

    move-result v1

    const/4 v9, 0x0

    const/4 v8, 0x4

    if-nez v1, :cond_4

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string/jumbo v1, "obtin umac lroaf rdln i ar oosfol"

    const-string/jumbo v1, "iyo ooont l oladclirr af srfa mbn"

    const/4 v9, 0x3

    const-string v1, "fo rnonptlf  lmlbaiao  adercros i"

    const-string v1, "can not load library from so file"

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    sget-object v1, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SO_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {v1}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const-string/jumbo v4, "tfcyoo nqai mfbrb nlodarrae o  li"

    const-string v4, " cf bbfyaro nooea rndasim o tillr"

    const/4 v9, 0x4

    const-string/jumbo v4, "tlsrlr iasffo nyn omdoloicr e  ab"

    const-string v4, "can not load library from so file"

    const/4 v9, 0x2

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v9, 0x0

    const-wide/16 v5, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string/jumbo v7, "nuime"

    const-string/jumbo v7, "iuner"

    const/4 v9, 0x1

    const-string v7, "ennio"

    const-string/jumbo v7, "inner"

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static/range {v2 .. v7}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v1}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p0

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    return p0

    :cond_4
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/common/AppInfos;->checkApplicationIcon(Landroid/content/Context;)Z

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->init(Landroid/content/Context;)V

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->r(Landroid/content/Context;)V

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->h(Landroid/content/Context;)V

    const/4 v8, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->s(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    sget-object p0, Lcom/tencent/android/tpush/common/j;->b:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    const/4 v0, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    return v2

    :catchall_0
    move-exception p0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string v1, "boUalbt tll p>n-Gi"

    const-string v1, ">iilt apobtGl- lnU"

    const/4 v9, 0x5

    const-string/jumbo v1, "itlG-luil>ni  Uatb"

    const-string v1, "Util -> initGlobal"

    const/4 v9, 0x3

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    const/4 p0, -0x1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    return p0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget-object v0, Lcom/tencent/android/tpush/common/j;->a:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    sget-object p0, Lcom/tencent/android/tpush/common/j;->a:Ljava/lang/String;

    const/4 v4, 0x7

    return-object p0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/content/res/Resources;->getAssets()Landroid/content/res/AssetManager;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0, p1}, Landroid/content/res/AssetManager;->open(Ljava/lang/String;)Ljava/io/InputStream;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-nez p0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-object v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance p1, Ljava/io/InputStreamReader;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v1, "q-p8T"

    const-string v1, "8T-qF"

    const/4 v4, 0x5

    const-string v1, "-UTq8"

    const-string v1, "UTF-8"

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {p1, p0, v1}, Ljava/io/InputStreamReader;-><init>(Ljava/io/InputStream;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :try_start_1
    const/4 v3, 0x5

    move v4, v3

    new-instance p0, Ljava/io/BufferedReader;

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-direct {p0, p1}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz v2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    sput-object v1, Lcom/tencent/android/tpush/common/j;->a:Ljava/lang/String;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_4

    :try_start_3
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/io/BufferedReader;->close()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :catchall_0
    :try_start_4
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/io/InputStreamReader;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    return-object v1

    :catchall_2
    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_1

    :catchall_3
    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p0, v0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    move-object p1, p0

    :catchall_4
    :goto_1
    :try_start_5
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string v1, "Uilt"

    const-string v1, "Util"

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v2, " sse usilstssn"

    const-string/jumbo v2, "sss s tusaneil"

    const/4 v4, 0x1

    const-string/jumbo v2, "nslmisesa s tl"

    const-string v2, "assets is null"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_7

    const/4 v4, 0x1

    if-eqz p0, :cond_3

    :try_start_6
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/io/BufferedReader;->close()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_5

    :catchall_5
    :cond_3
    const/4 v4, 0x3

    if-eqz p1, :cond_4

    :try_start_7
    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/io/InputStreamReader;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_6

    :catchall_6
    :cond_4
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object v0

    :catchall_7
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p0, :cond_5

    :try_start_8
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/io/BufferedReader;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_8

    :catchall_8
    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz p1, :cond_6

    :try_start_9
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/io/InputStreamReader;->close()V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_9

    :catchall_9
    :cond_6
    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    throw v0
.end method

.method public static a()V
    .locals 5

    const/4 v4, 0x7

    const-string v0, "iUlt"

    const-string v0, "Uilt"

    const/4 v4, 0x2

    const-string/jumbo v0, "iltU"

    const-string v0, "Util"

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/service/d;->a()Lcom/tencent/android/tpush/service/d;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/d;->b()Landroid/os/PowerManager$WakeLock;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1}, Landroid/os/PowerManager$WakeLock;->isHeld()Z

    move-result v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v2, :cond_0

    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-virtual {v1}, Landroid/os/PowerManager$WakeLock;->release()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :catchall_0
    move-exception v1

    :try_start_2
    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v2, "cm Wocotnakoexeikl"

    const-string/jumbo v2, "ketmnakciopeWclxo "

    const/4 v4, 0x4

    const-string/jumbo v2, "xoka btloeWkceecni"

    const-string v2, "Wakelock exception"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const-string v1, "Wopea uotU cPCskk"

    const-string v1, "PaUkoWpo sk oCtec"

    const/4 v4, 0x3

    const-string v1, "Pt  akepcWpskLCoo"

    const-string/jumbo v1, "stop WakeLock CPU"

    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto :goto_1

    :catchall_1
    move-exception v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v2, "kopcLWteqkoa"

    const-string v2, "cWLkabpkoote"

    const/4 v4, 0x3

    const-string v2, "cLsWakkoepot"

    const-string/jumbo v2, "stopWakeLock"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void
.end method

.method public static a(Landroid/content/Context;I)V
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v0, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v1, ", "

    const-string v1, ", "

    const/4 v6, 0x4

    const-string v1, ", "

    const-string v1, ", "

    const/4 v6, 0x5

    const/4 v2, 0x6

    const/4 v6, 0x7

    const/4 v2, 0x4

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo v3, "litU"

    const-string/jumbo v3, "itlU"

    const/4 v6, 0x3

    const-string v3, "Util"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x5

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x1

    if-ne v0, p1, :cond_0

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string/jumbo p1, "uzpmisiihu.mda._.ueco"

    const-string p1, "i._uoiu..haepdmiucpzs"

    const/4 v6, 0x6

    const-string/jumbo p1, "supeo_mchduim.zaoi.p."

    const-string p1, "com.meizu.push.api_id"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p0, p1, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    check-cast p1, Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string v0, ".pmiechp.ep.uios_myuzk"

    const/4 v6, 0x2

    const-string v0, "eh..ib.cpys_ukmoemazpi"

    const-string v0, "com.meizu.push.api_key"

    const/4 v6, 0x7

    invoke-static {p0, v0, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    check-cast p0, Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    sput-object p1, Lcom/tencent/android/tpush/d/d;->c:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    sput-object p0, Lcom/tencent/android/tpush/d/d;->d:Ljava/lang/String;

    const/4 v6, 0x3

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const-string/jumbo p1, "m:z"

    const-string/jumbo p1, "mz:"

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    sget-object p1, Lcom/tencent/android/tpush/d/d;->c:Ljava/lang/String;

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    sget-object p1, Lcom/tencent/android/tpush/d/d;->d:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    move v6, v5

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto/16 :goto_0

    :catchall_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string/jumbo p0, "t eextuu imn drioecpqn"

    const-string p0, "ee ri udqmxninecpt tzo"

    const/4 v6, 0x2

    const-string/jumbo p0, "n rdectp xptzenomiefi "

    const-string/jumbo p0, "unexpected for init mz"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    goto/16 :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v0, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-ne v0, p1, :cond_1

    :try_start_1
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    const-string p1, "dms_pomxqiihaosip.u.c."

    const-string p1, "casom.s.dxam_phipui.oi"

    const/4 v6, 0x5

    const-string/jumbo p1, "saspim._.hdiaici.oxmuo"

    const-string p1, "com.xiaomi.push.api_id"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {p0, p1, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    check-cast p1, Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string/jumbo v0, "myim.mausocop.p_hek.aii"

    const-string/jumbo v0, "kmim_.a.cuopm.hysaipeio"

    const-string/jumbo v0, "mcyhopuxaa_p.okieimiso."

    const-string v0, "com.xiaomi.push.api_key"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {p0, v0, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    check-cast p0, Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    sput-object p1, Lcom/tencent/android/tpush/d/d;->a:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    sput-object p0, Lcom/tencent/android/tpush/d/d;->b:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string p1, ":im"

    const-string/jumbo p1, "im:"

    const/4 v6, 0x3

    const-string p1, "i:m"

    const-string/jumbo p1, "mi:"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    sget-object p1, Lcom/tencent/android/tpush/d/d;->a:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    sget-object p1, Lcom/tencent/android/tpush/d/d;->b:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    goto/16 :goto_0

    :catchall_1
    const/4 v6, 0x5

    const-string/jumbo p0, "p nnubxdeixf ociemtr t"

    const-string p0, "enexomixe uptf ci dtrn"

    const/4 v6, 0x0

    const-string p0, "etiu xuetemi n xcprdnf"

    const-string/jumbo p0, "unexpected for init xm"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v0, 0x6

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-ne v0, p1, :cond_2

    :try_start_2
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string p1, ".iiosbcm.a_pppp.ouod"

    const/4 v6, 0x6

    const-string/jumbo p1, "phupp_.po.c.isdamoio"

    const-string p1, "com.oppo.push.api_id"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p0, p1, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    check-cast p1, Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo v0, "imu.pps_q.koyeaoop.uc"

    const-string/jumbo v0, "opyapcuio.oepus..p_km"

    const/4 v6, 0x2

    const-string v0, "com.oppo.push.api_key"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {p0, v0, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    check-cast p0, Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p1, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    sput-object p1, Lcom/tencent/android/tpush/d/d;->e:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0, v2}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    sput-object p0, Lcom/tencent/android/tpush/d/d;->f:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    move v6, v5

    const-string/jumbo p1, "o:sop"

    const-string/jumbo p1, "oopp:"

    const/4 v6, 0x1

    const-string/jumbo p1, "popm:"

    const-string/jumbo p1, "oppo:"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    sget-object p1, Lcom/tencent/android/tpush/d/d;->e:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    sget-object p1, Lcom/tencent/android/tpush/d/d;->f:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v6, 0x7

    const/4 v5, 0x6

    goto :goto_0

    :catchall_2
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string/jumbo p0, "qtido cx ppoepun iftoneo"

    const-string p0, " pppcexnq  otdurfoeionit"

    const-string p0, " xoopbdfipnteceip  noreu"

    const-string/jumbo p0, "unexpected for init oppo"

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    return-void
.end method

.method static synthetic a(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/common/j;->b(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Lorg/json/JSONObject;Ljava/lang/String;J)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    cmp-long v0, p2, v0

    const/4 v2, 0x7

    xor-int/2addr v3, v2

    if-lez v0, :cond_0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, p1, p2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method

.method public static a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz p2, :cond_0

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-lez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public static a(JJ)Z
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v0, ":-dyHyu m-HMyMs :ysm"

    const-string/jumbo v0, "mysydMHd -y:Hyms-:M "

    const/4 v6, 0x5

    const-string v0, "H:-M Hdp:yyydMss-my "

    const-string/jumbo v0, "yyyy-MM-dd  HH:mm:ss"

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v3, Ljava/text/SimpleDateFormat;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-direct {v3, v0}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v4, Ljava/text/SimpleDateFormat;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-direct {v4, v0}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {p0, p1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v3, p0}, Ljava/text/Format;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {p2, p3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v4, p1}, Ljava/text/Format;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v3, p0}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v4, p1}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v1, p0}, Ljava/util/Calendar;->setTime(Ljava/util/Date;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v2, p1}, Ljava/util/Calendar;->setTime(Ljava/util/Date;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/common/j;->a(Ljava/util/Calendar;Ljava/util/Calendar;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    return p0

    :catchall_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo p0, "iltU"

    const-string p0, "Ulit"

    const/4 v6, 0x5

    const-string p0, "Util"

    const-string p0, "Util"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string p1, ""

    const/4 v6, 0x1

    const-string p1, ""

    const-string p1, ""

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p0, p1}, Lcom/tencent/tpns/baseapi/base/util/Logger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 p0, 0x6

    const/4 v6, 0x5

    const/4 p0, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    return p0
.end method

.method public static a(Landroid/content/Context;Landroid/content/BroadcastReceiver;)Z
    .locals 3

    :try_start_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->unregisterReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    const/4 p0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    return p0

    :catchall_0
    move-exception p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string/jumbo p1, "litU"

    const-string/jumbo p1, "itUl"

    const/4 v2, 0x3

    const-string/jumbo p1, "tliU"

    const-string p1, "Util"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string/jumbo v0, "rUgraeerqc reteifvrmroseseeR"

    const-string v0, "ersmergefrrrUe cReotsaveerni"

    const/4 v2, 0x1

    const-string/jumbo v0, "safeUnregisterReceiver error"

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p1, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x0

    return p0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Z)Z
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x0

    const-string/jumbo v0, "liUt"

    const-string/jumbo v0, "tUil"

    const/4 v8, 0x3

    const-string/jumbo v0, "tUli"

    const-string v0, "Util"

    const/4 v8, 0x3

    const/4 v1, 0x1

    const/4 v8, 0x5

    const/4 v1, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz p0, :cond_4

    :try_start_0
    const/4 v7, 0x1

    const/4 v8, 0x6

    const-string v2, "dosaiaArprv.ihpyattceidnd."

    const-string/jumbo v2, "radro.oihetiAptaddcya.vipn"

    const/4 v8, 0x0

    const-string/jumbo v2, "irvminydcTphdAaatoedrpti.a"

    const-string v2, "android.app.ActivityThread"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string v3, "etvaoricirrchunTedtby"

    const-string/jumbo v3, "uyeirbvctdtrnAaicrheT"

    const/4 v8, 0x5

    const-string v3, "edrttbucvcThiratiyenr"

    const-string v3, "currentActivityThread"

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    new-array v4, v1, [Ljava/lang/Class;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v2, v3, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    new-array v4, v1, [Ljava/lang/Object;

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    const/4 v5, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v3, v5, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string v4, "etcAmsutuii"

    const-string v4, "eciisAutmit"

    const/4 v8, 0x7

    const-string/jumbo v4, "viAtiiepmct"

    const-string/jumbo v4, "mActivities"

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v2, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/4 v4, 0x1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v2, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    check-cast v2, Ljava/util/Map;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x5

    if-nez v2, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string/jumbo v2, "vieitsesqti s lcett lhpiirgutrttiaeno Tyn,ru vctaucvAcitefnr rd cire"

    const-string/jumbo v2, "tAt cTsptr gienteleiutrie siivflcvt cniivhatrue, ot rrcueyncisaa trd"

    const/4 v8, 0x2

    const-string v2, "get current activities for currentActivityThread, activities is null"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {v0, v2}, Lcom/tencent/tpns/baseapi/base/util/Logger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    return v1

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-interface {v2}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-interface {v2}, Ljava/util/Collection;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-eqz v3, :cond_4

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string v6, "dasequ"

    const-string v6, "daquse"

    const/4 v8, 0x0

    const-string/jumbo v6, "uaemps"

    const-string/jumbo v6, "paused"

    const/4 v8, 0x3

    const/4 v7, 0x5

    invoke-virtual {v5, v6}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v6

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v6, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v6, v3}, Ljava/lang/reflect/Field;->getBoolean(Ljava/lang/Object;)Z

    move-result v6

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    if-nez v6, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    const-string v2, "ctsvyiti"

    const/4 v8, 0x3

    const-string/jumbo v2, "iyctoati"

    const-string v2, "activity"

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v5, v2}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v2, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v7, 0x1

    or-int/2addr v8, v7

    invoke-virtual {v2, v3}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    check-cast v2, Landroid/app/Activity;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x2

    if-nez v2, :cond_2

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string/jumbo v2, "vitrub iticusi tCgtnymlilcAae]e ttn[y"

    const-string/jumbo v2, "rcvmuenti]siglA[utycaityle tit  irntC"

    const/4 v8, 0x6

    const-string/jumbo v2, "v inlsuu[c]t iviAreyyltctterttniaCi g"

    const-string v2, "[getCurrentActivity] activity is null"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {v0, v2}, Lcom/tencent/tpns/baseapi/base/util/Logger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    return v1

    :cond_2
    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-nez v3, :cond_3

    const/4 v8, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    move v8, v7

    const-string/jumbo v4, "rNuagtnpakioypi :ceemeacr atcv"

    const-string/jumbo v4, "ret ogiacNatecuevynikt :aamrpc"

    const-string v4, "erNgtyn qkaaimu ct:aerivaetcc "

    const-string v4, "current activity packageName: "

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string v2, "aks:NepbapamP,ec  "

    const-string v2, "aPap,b pec kaeam:N"

    const/4 v8, 0x2

    const-string/jumbo v2, "kapm :eapNaamcegP,"

    const-string v2, ", appPackageName: "

    const/4 v8, 0x0

    const/4 v7, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x5

    invoke-static {v0, v2}, Lcom/tencent/tpns/baseapi/base/util/Logger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    return v1

    :cond_3
    const/4 v7, 0x0

    move v8, v7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string/jumbo v5, "uturoet:enCiyt cviAr"

    const-string/jumbo v5, "retiCuutgtnc:iAyver "

    const/4 v8, 0x2

    const-string/jumbo v5, "ny:cib ruttivrAtgetC"

    const-string v5, "getCurrentActivity: "

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v2}, Landroid/app/Activity;->getLocalClassName()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {v0, v2}, Lcom/tencent/tpns/baseapi/base/util/Logger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x2

    return v4

    :catchall_0
    move-exception v2

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string/jumbo v4, "uprAegu]errt[y Ctvrrin :ciot"

    const-string/jumbo v4, "rcet[inpCv e]tgoyuie rtrrr:A"

    const/4 v8, 0x7

    const-string/jumbo v4, "rtrvrtupe ]teit noyCrr:ciAg["

    const-string v4, "[getCurrentActivity] error: "

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    move v8, v7

    invoke-virtual {v2}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {v0, v2}, Lcom/tencent/tpns/baseapi/base/util/Logger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz p2, :cond_4

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/j;->e(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    return p0

    :cond_4
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    return v1
.end method

.method public static a(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v1, 0x7

    or-int/2addr v2, v1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    const/16 v0, 0x20

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-lt p0, v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 p0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x1

    return p0
.end method

.method static synthetic a(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return p0
.end method

.method public static a(Ljava/util/Calendar;Ljava/util/Calendar;)Z
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz p0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-eqz p1, :cond_0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0, v0}, Ljava/util/Calendar;->get(I)I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p1, v0}, Ljava/util/Calendar;->get(I)I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    if-ne v1, v2, :cond_0

    const/4 v4, 0x3

    move v5, v4

    const/4 v1, 0x1

    move v5, v1

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    invoke-virtual {p0, v1}, Ljava/util/Calendar;->get(I)I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1, v1}, Ljava/util/Calendar;->get(I)I

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-ne v2, v3, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v2, 0x6

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0, v2}, Ljava/util/Calendar;->get(I)I

    move-result p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p1, v2}, Ljava/util/Calendar;->get(I)I

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-ne p0, p1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    move v0, v1

    move v0, v1

    const/4 v5, 0x4

    move v0, v1

    move v0, v1

    :catchall_0
    :cond_0
    const/4 v4, 0x4

    const/4 v5, 0x7

    return v0
.end method

.method public static b()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v3, 0x6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-object v0
.end method

.method private static b(Landroid/content/pm/PackageManager;Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    if-eqz p2, :cond_1

    :try_start_0
    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    if-eqz p0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-instance v0, Landroid/content/ComponentName;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-direct {v0, p1, p2}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/content/pm/PackageManager;->getComponentEnabledSetting(Landroid/content/ComponentName;)I

    move-result p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 p2, 0x4

    const/4 p2, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x5

    if-eq p1, p2, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 p1, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p0, v0, p2, p1}, Landroid/content/pm/PackageManager;->setComponentEnabledSetting(Landroid/content/ComponentName;II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public static b(Landroid/content/Context;)Z
    .locals 4

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string v1, "P_HICPOXqAqVNUGT_I"

    const-string v1, "PHX_CNAIqOI_PGUTSV"

    const/4 v3, 0x4

    const-string v1, "G.sXHNITAP_SOV_CUP"

    const-string v1, ".XGVIP_PUSH_ACTION"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/service/util/g;->c(Landroid/content/Context;Ljava/lang/String;)Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-lez p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 p0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    return p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v0, "iUtl"

    const-string v0, "iUtl"

    const/4 v3, 0x0

    const-string/jumbo v0, "litU"

    const-string v0, "Util"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string/jumbo v1, "oi m >gAsUe-liIiCtdnfD"

    const-string v1, ">lsC-Uei  soAdfgiInitD"

    const/4 v3, 0x7

    const-string v1, "gfetol U-LsinADIo>i di"

    const-string v1, "Util -> isAIDLConfiged"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    return p0
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p0, p1}, Lcom/tencent/tpns/mqttchannel/api/MqttTools;->isPushMsgTopic(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p0, p1}, Lcom/tencent/tpns/mqttchannel/api/MqttTools;->isAesPushMsgTopic(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p0, p1}, Lcom/tencent/tpns/mqttchannel/api/MqttTools;->isGZipPushMsgTopic(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v1, 0x0

    shl-int/2addr v2, v1

    invoke-static {p0, p1}, Lcom/tencent/tpns/mqttchannel/api/MqttTools;->isGZipAesPushMsgTopic(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-eqz p0, :cond_0

    const/4 v1, 0x5

    shl-int/2addr v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 p0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p0, 0x1

    :goto_1
    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return p0
.end method

.method public static b(Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    if-eqz p0, :cond_1

    const/4 v1, 0x4

    const/4 v0, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-nez p0, :cond_0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 p0, 0x7

    const/4 p0, 0x0

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    const/4 p0, 0x1

    :goto_1
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p0
.end method

.method private static b(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string v1, "."

    const-string v1, "."

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-virtual {p1, v1, v0}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0}, Ljava/lang/Float;->valueOf(Ljava/lang/String;)Ljava/lang/Float;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Float;->floatValue()F

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p1}, Ljava/lang/Float;->valueOf(Ljava/lang/String;)Ljava/lang/Float;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    cmpl-float p0, p1, p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-lez p0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 p0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    return p0

    :catchall_0
    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 p0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    return p0
.end method

.method public static c(Landroid/content/Context;)I
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string v0, "agaStbeiectsnrom ueStci"

    const-string v0, "cncmatriveaSSiuoe tgest"

    const/4 v7, 0x0

    const-string v0, "iSeSttuuvastoeiancc get"

    const-string v0, "action getServiceStatus"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string/jumbo v1, "iltU"

    const-string/jumbo v1, "tliU"

    const/4 v7, 0x5

    const-string/jumbo v1, "itlU"

    const-string v1, "Util"

    const/4 v6, 0x1

    move v7, v6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz p0, :cond_2

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string/jumbo v0, "yvittcap"

    const-string v0, "activity"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    check-cast v0, Landroid/app/ActivityManager;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    const v2, 0x7fffffff

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v0, v2}, Landroid/app/ActivityManager;->getRunningServices(I)Ljava/util/List;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz v0, :cond_2

    const/4 v6, 0x2

    move v7, v6

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-lez v2, :cond_2

    const/4 v6, 0x0

    move v7, v6

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz v3, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x1

    check-cast v3, Landroid/app/ActivityManager$RunningServiceInfo;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v4, v3, Landroid/app/ActivityManager$RunningServiceInfo;->service:Landroid/content/ComponentName;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v4}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v5, v3, Landroid/app/ActivityManager$RunningServiceInfo;->service:Landroid/content/ComponentName;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v5}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-eqz v4, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-eqz v4, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget p0, v3, Landroid/app/ActivityManager$RunningServiceInfo;->pid:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz p0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 p0, 0x1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 p0, 0x2

    :goto_0
    const/4 v7, 0x4

    return p0

    :catchall_0
    move-exception p0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo v0, "igaSotvtqsutSere"

    const-string/jumbo v0, "vastoSctgeSetrui"

    const/4 v7, 0x4

    const-string/jumbo v0, "irssttevueegatSS"

    const-string v0, "getServiceStatus"

    const/4 v7, 0x2

    const/4 v6, 0x1

    invoke-static {v1, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 p0, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    return p0
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0, p1, v0}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-wide v1, p0, Landroid/content/pm/PackageInfo;->firstInstallTime:J

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-wide p0, p0, Landroid/content/pm/PackageInfo;->lastUpdateTime:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    cmp-long p0, v1, p0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-nez p0, :cond_0

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v0, 0x1

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    return v0

    :catchall_0
    move-exception p0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo v1, "nFimufI ordrs tel tntsbs:cepalx"

    const-string/jumbo v1, "ltipsbes  :fI utnedrectsanrFxol"

    const/4 v4, 0x3

    const-string/jumbo v1, "rp:lossxn utlceniI d eiftoatrFe"

    const-string/jumbo v1, "unexpected for isFirstInstall: "

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo p1, "ilUt"

    const-string/jumbo p1, "tUil"

    const/4 v4, 0x2

    const-string/jumbo p1, "itlU"

    const-string p1, "Util"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    return v0
.end method

.method public static c(Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    if-eqz p0, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-nez p0, :cond_0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 p0, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return p0

    :cond_1
    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    const/4 p0, 0x0

    const/4 v1, 0x7

    const/4 v0, 0x3

    return p0
.end method

.method public static d(Ljava/lang/String;)J
    .locals 15

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    if-eqz p0, :cond_2

    const-string v2, "0"

    const-string v2, "0"

    const-string v2, "0"

    const-string v2, "0"

    invoke-virtual {p0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-nez v2, :cond_2

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    invoke-virtual {p0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    if-eqz v2, :cond_0

    goto/16 :goto_2

    :cond_0
    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    new-array v3, v2, [J

    const-string v4, "."

    const-string v4, "."

    const-string v4, "."

    const-string v4, "."

    invoke-virtual {p0, v4}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v5

    add-int/lit8 v6, v5, 0x1

    invoke-virtual {p0, v4, v6}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v7

    add-int/lit8 v8, v7, 0x1

    invoke-virtual {p0, v4, v8}, Ljava/lang/String;->indexOf(Ljava/lang/String;I)I

    move-result v4

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x1

    :try_start_0
    invoke-virtual {p0, v11, v5}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v13

    aput-wide v13, v3, v10

    invoke-virtual {p0, v6, v7}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v5

    aput-wide v5, v3, v9

    invoke-virtual {p0, v8, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v5

    aput-wide v5, v3, v12

    add-int/2addr v4, v12

    invoke-virtual {p0, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    aput-wide v4, v3, v11
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception v4

    move v5, v11

    move v5, v11

    move v5, v11

    :goto_0
    if-ge v5, v2, :cond_1

    aput-wide v0, v3, v5

    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "UAp @bacdselvd(Ireersiesuir@s"

    const-string v1, "Aevpisua@dss err@erielsI(tdcU"

    const-string v1, "e esIpuira@Ui@rAtdsrplecd(ess"

    const-string/jumbo v1, "service Util@@parseIpAddress("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string p0, ")"

    const-string p0, ")"

    const-string p0, ")"

    const-string p0, ")"

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const-string v0, "Uilt"

    const-string/jumbo v0, "litU"

    const-string/jumbo v0, "ltUi"

    const-string v0, "Util"

    invoke-static {v0, p0, v4}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_1
    aget-wide v0, v3, v11

    const/16 p0, 0x18

    shl-long/2addr v0, p0

    aget-wide v4, v3, v12

    const/16 p0, 0x10

    shl-long/2addr v4, p0

    add-long/2addr v0, v4

    aget-wide v4, v3, v9

    const/16 p0, 0x8

    shl-long/2addr v4, p0

    add-long/2addr v0, v4

    aget-wide v2, v3, v10

    add-long/2addr v0, v2

    :cond_2
    :goto_2
    return-wide v0
.end method

.method public static d(Landroid/content/Context;)V
    .locals 8

    const/4 v7, 0x1

    const-string/jumbo v0, "scvpti paernieuatSctotS"

    const-string/jumbo v0, "tSstiatpaiocce nuteSevr"

    const/4 v7, 0x1

    const-string/jumbo v0, "rcetiaetqusSaSveig ncot"

    const-string v0, "action getServiceStatus"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string v1, "Utli"

    const-string v1, "Uitl"

    const/4 v7, 0x0

    const-string/jumbo v1, "liUt"

    const-string v1, "Util"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-eqz p0, :cond_1

    :try_start_0
    const/4 v6, 0x7

    move v7, v6

    const-string/jumbo v0, "qtaiytci"

    const/4 v7, 0x5

    const-string/jumbo v0, "ycsitaiv"

    const-string v0, "activity"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    check-cast v0, Landroid/app/ActivityManager;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    const v2, 0x7fffffff

    const/4 v6, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v0, v2}, Landroid/app/ActivityManager;->getRunningServices(I)Ljava/util/List;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    if-eqz v0, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-lez v2, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v7, 0x6

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-eqz v3, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    check-cast v3, Landroid/app/ActivityManager$RunningServiceInfo;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v4, v3, Landroid/app/ActivityManager$RunningServiceInfo;->service:Landroid/content/ComponentName;

    const/4 v7, 0x0

    const/4 v6, 0x2

    invoke-virtual {v4}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v5, v3, Landroid/app/ActivityManager$RunningServiceInfo;->service:Landroid/content/ComponentName;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v5}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v2, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz v4, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v4, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v4, v3, Landroid/app/ActivityManager$RunningServiceInfo;->process:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-nez v4, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-object v4, v3, Landroid/app/ActivityManager$RunningServiceInfo;->process:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {v4, v5}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-nez v4, :cond_0

    const/4 v7, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    and-int/2addr v7, v6

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v5, "ceomsssxr vuve:prhisisePc"

    const-string v5, "eese:prxhvs vcicrgsPisous"

    const/4 v7, 0x6

    const-string v5, "Pxsrocu:eiv rossvpehpcieg"

    const-string/jumbo v5, "xgvipPushservice process:"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v5, v3, Landroid/app/ActivityManager$RunningServiceInfo;->process:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v1, v4}, Lcom/tencent/tpns/baseapi/base/util/Logger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget v3, v3, Landroid/app/ActivityManager$RunningServiceInfo;->pid:I

    const/4 v7, 0x1

    if-eqz v3, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v3}, Landroid/os/Process;->killProcess(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto/16 :goto_0

    :catchall_0
    move-exception p0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string v0, "etuvmbrestieSatc"

    const-string v0, "etrmvticSuaeetsS"

    const/4 v7, 0x4

    const-string v0, "getteeuautvrsicS"

    const-string v0, "getServiceStatus"

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {v1, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    return-void
.end method

.method public static d(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    return p0
.end method

.method public static e(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v0, "U-pTF"

    const-string v0, "TUF-o"

    const/4 v4, 0x6

    const-string v0, "8FTqU"

    const-string v0, "UTF-8"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-nez p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 p0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-object p0

    :cond_0
    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/service/channel/security/a;->a([BI)[B

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v1}, Lcom/tencent/tpns/baseapi/base/util/RC4;->decrypt([B)[B

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v2, Ljava/lang/String;

    const/4 v3, 0x2

    move v4, v3

    invoke-direct {v2, v1, v0}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v4, 0x3

    return-object v2

    :catchall_0
    move-exception v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v1, "iUlt"

    const-string/jumbo v1, "lUit"

    const/4 v4, 0x2

    const-string/jumbo v1, "tiUl"

    const-string v1, "Util"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo v2, "obs reerddro"

    const-string v2, "doeorbd reer"

    const/4 v4, 0x4

    const-string/jumbo v2, "reemcr ordeo"

    const-string v2, "decode error"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-object p0
.end method

.method public static e(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v1, "CirtoruStnvtAursaprceee"

    const-string/jumbo v1, "prevtSuraeucrtApitCresn"

    const/4 v3, 0x4

    const-string v1, "SCr tbetspuavpeiArcnetr"

    const-string/jumbo v1, "startCurrentAppService "

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string/jumbo v1, "itlU"

    const-string v1, "Util"

    const/4 v3, 0x5

    const-string/jumbo v1, "tlUi"

    const-string v1, "Util"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-class v1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v3, 0x6

    const-class v1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0, p0, v1}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method public static e(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 5

    const/4 v3, 0x5

    move v4, v3

    const/4 v0, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v1, "iaitvcut"

    const-string v1, "activity"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-nez p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    return v0

    :cond_0
    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    check-cast v1, Landroid/app/ActivityManager$RunningAppProcessInfo;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v2, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz v2, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x3

    iget v1, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->importance:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/16 v2, 0x64

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ne v1, v2, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 p0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    return p0

    :catchall_0
    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    return v0
.end method

.method public static f(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v0, "Upp8T"

    const-string v0, "-Tp8U"

    const/4 v4, 0x7

    const-string v0, "8U-qF"

    const-string v0, "UTF-8"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-nez p0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 p0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object p0

    :cond_0
    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v1}, Lcom/tencent/tpns/baseapi/base/util/RC4;->encrypt([B)[B

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/service/channel/security/a;->b([BI)[B

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance v2, Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {v2, v1, v0}, Ljava/lang/String;-><init>([BLjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    return-object v2

    :catchall_0
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const-string/jumbo v1, "iltU"

    const-string/jumbo v1, "tiUl"

    const/4 v4, 0x0

    const-string v1, "Ulit"

    const-string v1, "Util"

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v2, " csedeeqrroo"

    const-string/jumbo v2, "rorerce qeod"

    const/4 v4, 0x2

    const-string v2, "eromrodee rn"

    const-string v2, "encode error"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object p0
.end method

.method public static f(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x2

    if-eqz p0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedTpnsChannel(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string/jumbo v1, "itUl"

    const-string/jumbo v1, "tliU"

    const/4 v5, 0x2

    const-string/jumbo v1, "tlUi"

    const-string v1, "Util"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo p0, "lsrnoaicpibtea,esu Tvashr neltostr n sheoscei nS c"

    const-string/jumbo p0, "oes,coue r t sl scsSsraiaihbec v niaTehltnenentpsr"

    const/4 v5, 0x2

    const-string/jumbo p0, "ta,nTbe oesvrciirilnrleth vsepn  autcaSo beshencs "

    const-string/jumbo p0, "startService abolish, not use Tpns channel service"

    const/4 v5, 0x7

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    return-void

    :cond_0
    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/service/util/g;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->e(Landroid/content/Context;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/service/b;->b(Landroid/content/Context;)V

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/service/b;->a(Landroid/content/Context;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v0, "vc S>)unera (om-tLAcltc itosari"

    const-string/jumbo v0, "rtimi sat cA>-e tacnolevLrc)(So"

    const/4 v5, 0x5

    const-string v0, ">A-asLlpt)nti(o t icacSv  ceeor"

    const-string v0, "Action -> start Local Service()"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x0

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v2, "arSeoetSqvri"

    const-string v2, "StvaoereircS"

    const/4 v5, 0x2

    const-string v2, "SaseecvtrrSt"

    const-string v2, "StartService"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance v1, Lcom/tencent/android/tpush/common/j$3;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/common/j$3;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x5dc

    const-wide/16 v2, 0x5dc

    const/4 v5, 0x1

    const-wide/16 v2, 0x5dc

    const-wide/16 v2, 0x5dc

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2, v3}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;J)Z

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    return-void
.end method

.method private static f(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x0

    if-eqz p0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x1

    if-eqz p1, :cond_1

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v1, Landroid/content/ComponentName;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v1, p0, p1}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    invoke-virtual {v0, v1}, Landroid/content/pm/PackageManager;->getComponentEnabledSetting(Landroid/content/ComponentName;)I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 p1, 0x3

    const/4 p1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eq p0, p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, v1, p1, p1}, Landroid/content/pm/PackageManager;->setComponentEnabledSetting(Landroid/content/ComponentName;II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void
.end method

.method public static g(Landroid/content/Context;)V
    .locals 8

    const/4 v7, 0x4

    if-nez p0, :cond_0

    return-void

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    sget-boolean v0, Lcom/tencent/android/tpush/common/j;->c:Z

    const/4 v7, 0x0

    if-nez v0, :cond_4

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-class v0, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v0, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v7, 0x5

    const-class v0, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v0, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/j;->f(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-class v0, Lcom/tencent/android/tpush/TpnsActivity;

    const-class v0, Lcom/tencent/android/tpush/TpnsActivity;

    const/4 v7, 0x3

    const/4 v6, 0x3

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/j;->f(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-class v0, Lcom/tencent/android/tpush/XGPushProvider;

    const-class v0, Lcom/tencent/android/tpush/XGPushProvider;

    const/4 v7, 0x3

    const-class v0, Lcom/tencent/android/tpush/XGPushProvider;

    const-class v0, Lcom/tencent/android/tpush/XGPushProvider;

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/j;->f(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-class v0, Lcom/tencent/android/tpush/SettingsContentProvider;

    const-class v0, Lcom/tencent/android/tpush/SettingsContentProvider;

    const/4 v7, 0x5

    const-class v0, Lcom/tencent/android/tpush/SettingsContentProvider;

    const-class v0, Lcom/tencent/android/tpush/SettingsContentProvider;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/j;->f(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 v2, 0x2

    const/4 v7, 0x7

    invoke-virtual {v1, v0, v2}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v0, v0, Landroid/content/pm/PackageInfo;->receivers:[Landroid/content/pm/ActivityInfo;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    array-length v1, v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-ge v2, v1, :cond_3

    const/4 v6, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    aget-object v3, v0, v2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v3, v3, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :try_start_1
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v4

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v4, v3}, Ljava/lang/ClassLoader;->loadClass(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-class v5, Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const-class v5, Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const/4 v7, 0x7

    const-class v5, Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const-class v5, Lcom/tencent/android/tpush/XGPushBaseReceiver;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v5, v4}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result v5

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-nez v5, :cond_1

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-class v5, Lcom/tencent/android/tpush/XGPushReceiver;

    const-class v5, Lcom/tencent/android/tpush/XGPushReceiver;

    const/4 v7, 0x7

    const-class v5, Lcom/tencent/android/tpush/XGPushReceiver;

    const/4 v7, 0x5

    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-eqz v4, :cond_2

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {p0, v3}, Lcom/tencent/android/tpush/common/j;->f(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catch_0
    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string/jumbo v0, "itUl"

    const-string/jumbo v0, "tlUi"

    const/4 v7, 0x5

    const-string/jumbo v0, "litU"

    const-string v0, "Util"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    const-string/jumbo v1, "lenmenesonbCbmto"

    const-string v1, "beeCnbolmaensont"

    const/4 v7, 0x5

    const-string/jumbo v1, "naeoompenCsnolbe"

    const-string v1, "enableComponents"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_3
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 p0, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    sput-boolean p0, Lcom/tencent/android/tpush/common/j;->c:Z

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    return-void
.end method

.method public static h(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    new-instance v1, Lcom/tencent/android/tpush/common/j$4;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/common/j$4;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public static i(Landroid/content/Context;)Z
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/XGApiConfig;->isEnableService(Landroid/content/Context;)Z

    move-result p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    return p0
.end method

.method public static j(Landroid/content/Context;)V
    .locals 5

    :try_start_0
    invoke-static {}, Lcom/tencent/android/tpush/common/j;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v1, "opop"

    const-string/jumbo v1, "opop"

    const/4 v4, 0x7

    const-string/jumbo v1, "oppo"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v1, "r_EFebG.NTtcAoSAATNIeOTEntI.tfepOTt_nona.eCIcCuHianN.ps"

    const-string v1, "AcIeA.utTONFpenTEG_tcnH.tpsIt_f.aorOETCANieNnnIT.oSoCea"

    const-string/jumbo v1, "oppo.safecenter.intent.action.CHANGE_NOTIFICATION_STATE"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x4

    const-string v1, "epknmguacapa"

    const-string v1, "eagaanppmcek"

    const/4 v4, 0x3

    const-string/jumbo v1, "pkaeaa_pngem"

    const-string/jumbo v1, "package_name"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v1, "flnoliyqq_oa"

    const-string/jumbo v1, "ni_llaotqofy"

    const/4 v4, 0x1

    const-string/jumbo v1, "ynsltfo_laiw"

    const-string v1, "allow_notify"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 v2, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string/jumbo v0, "itsoeicfannpiotN"

    const/4 v4, 0x1

    const-string/jumbo v0, "openNotification"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {v0, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    return-void
.end method

.method public static k(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/common/j;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo v1, "imzme"

    const-string/jumbo v1, "mezmi"

    const/4 v4, 0x1

    const-string/jumbo v1, "zumeo"

    const-string/jumbo v1, "meizu"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto/16 :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v1, "ppoo"

    const-string/jumbo v1, "popo"

    const/4 v4, 0x7

    const-string/jumbo v1, "oppo"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v1, "ic.orbcroocn.ntatomsfelinaoioga"

    const-string/jumbo v1, "irftom.oagsa.iiacnctolcnorooneo"

    const-string v1, "c.ans.uomiltciaocgfoanoitromner"

    const-string v1, "com.coloros.notificationmanager"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v2, "oArtalope.ccefenniAtngmmobclaifpevpatoPcosDariier.nit.yeiot"

    const-string/jumbo v2, "istplbacmlvotoamonpePnt.eicgeice.rrrAaai.nrootoAcftiyfeDien"

    const/4 v4, 0x6

    const-string v2, "Det.teotqgliAnamctefisnnanc.icacpe.PvrioiloropofimerreyaAct"

    const-string v2, "com.coloros.notificationmanager.AppDetailPreferenceActivity"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClassName(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo v1, "orslanotsioml..pemrcdatp.uaceiicaoigo.ntfn"

    const-string v1, "cpciriuomro.t.ndegooai.cmoatlse.finlaapnot"

    const/4 v4, 0x0

    const-string/jumbo v1, "paom.aefitiol.aorctas.pncogtlniiedon.arcmo"

    const-string v1, "com.coloros.notificationmanager.app.detail"

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo v2, "peg:opck"

    const-string/jumbo v2, "pg:acekp"

    const/4 v4, 0x5

    const-string v2, "ekcapbga"

    const-string/jumbo v2, "package:"

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string/jumbo v1, "nkpqgaum"

    const-string/jumbo v1, "qk_gapnm"

    const/4 v4, 0x6

    const-string/jumbo v1, "p_mneagp"

    const-string/jumbo v1, "pkg_name"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v1, "qasa_pne"

    const-string/jumbo v1, "p_saeanp"

    const/4 v4, 0x6

    const-string v1, "aes_pnap"

    const-string v1, "app_name"

    const/4 v3, 0x5

    and-int/2addr v4, v3

    invoke-static {p0}, Lcom/tencent/android/tpush/common/AppInfos;->getApplicationName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x6

    const-string/jumbo v1, "lmams_emns"

    const-string v1, "_lsmcsenma"

    const/4 v4, 0x1

    const-string v1, "escmoa_nal"

    const-string v1, "class_name"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo v0, "liUt"

    const-string v0, "Uitl"

    const/4 v4, 0x3

    const-string/jumbo v0, "liUt"

    const-string v0, "Util"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string/jumbo v1, "tntaNbtoinsecpineootfSoi"

    const-string v1, "enipoiNnosticfonioSetatt"

    const/4 v4, 0x1

    const-string/jumbo v1, "topeigufinNcosotniatSetn"

    const-string/jumbo v1, "openNotificationSettings"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void
.end method

.method public static l(Landroid/content/Context;)V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string v0, "bpppay"

    const-string v0, "apeypb"

    const/4 v6, 0x4

    const-string v0, "epqyap"

    const-string v0, "appkey"

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string/jumbo v1, "idspu"

    const-string v1, "aupdi"

    const/4 v6, 0x7

    const-string v1, "dpima"

    const-string v1, "appid"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const-string v2, "htefoo.csuso_nonjhpip"

    const-string/jumbo v2, "nopshefp.oucgitjnoh_s"

    const/4 v6, 0x1

    const-string/jumbo v2, "topjsbfcrgohseniuhn.o"

    const-string/jumbo v2, "otherpush_config.json"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-static {p0, v2}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eqz v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-void

    :cond_0
    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x5

    new-instance v2, Lorg/json/JSONObject;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-direct {v2, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 p0, 0x0

    :try_start_1
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string/jumbo v3, "uaqmoi"

    const-string v3, "iaqxom"

    const/4 v6, 0x5

    const-string v3, "apoixm"

    const-string/jumbo v3, "xiaomi"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v3, v1, p0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    sput-object v4, Lcom/tencent/android/tpush/d/d;->a:Ljava/lang/String;

    const/4 v5, 0x5

    move v6, v5

    invoke-virtual {v3, v0, p0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    sput-object v3, Lcom/tencent/android/tpush/d/d;->b:Ljava/lang/String;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :cond_1
    :try_start_2
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string/jumbo v3, "mzequ"

    const-string/jumbo v3, "zmsue"

    const/4 v6, 0x1

    const-string/jumbo v3, "iesmz"

    const-string/jumbo v3, "meizu"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    if-eqz v2, :cond_2

    const/4 v6, 0x7

    invoke-virtual {v2, v1, p0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x7

    sput-object v1, Lcom/tencent/android/tpush/d/d;->c:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-virtual {v2, v0, p0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    sput-object p0, Lcom/tencent/android/tpush/d/d;->d:Ljava/lang/String;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_0

    :catchall_1
    move-exception p0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string/jumbo v0, "tiUl"

    const-string v0, "iUtl"

    const/4 v6, 0x5

    const-string v0, "Util"

    const-string v0, "Util"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :catchall_2
    :cond_2
    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    return-void
.end method

.method public static m(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/android/tpush/common/j;->e:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v0, "com.huawei.hms.client.appid"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    sput-object p0, Lcom/tencent/android/tpush/common/j;->e:Ljava/lang/String;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object p0, Lcom/tencent/android/tpush/common/j;->e:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    if-eqz p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object p0, Lcom/tencent/android/tpush/d/d;->h:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    sput-object p0, Lcom/tencent/android/tpush/common/j;->e:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    const/4 v3, 0x1

    const-string/jumbo p0, "litU"

    const-string/jumbo p0, "lUti"

    const/4 v3, 0x7

    const-string/jumbo p0, "tilU"

    const-string p0, "Util"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo v0, "wpem mogeHg idxeocrenntCfu"

    const-string/jumbo v0, "peHmniufxeondr wfgegeoctC "

    const/4 v3, 0x6

    const-string/jumbo v0, "xoeCoggnptedfr Hf nutieowc"

    const-string/jumbo v0, "unexpected for getHwConfig"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget-object p0, Lcom/tencent/android/tpush/common/j;->e:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object p0
.end method

.method public static n(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object v0, Lcom/tencent/android/tpush/common/j;->f:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v0, "shpiod..mv_puc.ipoov"

    const/4 v3, 0x7

    const-string/jumbo v0, "vp.cdbi..sohopupim_v"

    const-string v0, "com.vivo.push.app_id"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v1, ""

    const/4 v3, 0x5

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p0}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    sput-object p0, Lcom/tencent/android/tpush/common/j;->f:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    goto :goto_0

    :catchall_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo p0, "tilU"

    const-string/jumbo p0, "ilUt"

    const/4 v3, 0x0

    const-string/jumbo p0, "tlUi"

    const-string p0, "Util"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const-string v0, "i unepuenoogtrefxfvbt ioCcgV"

    const-string v0, "fCgovbceentfoxnte rigup oieV"

    const/4 v3, 0x7

    const-string v0, "fo iprepxeuvVnietgog Cfncdoe"

    const-string/jumbo v0, "unexpected for getVivoConfig"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v2, 0x0

    const/4 v3, 0x3

    sget-object p0, Lcom/tencent/android/tpush/common/j;->f:Ljava/lang/String;

    const/4 v2, 0x7

    return-object p0
.end method

.method public static o(Landroid/content/Context;)Z
    .locals 4

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v0, "RPEE_HLEqTSOuNHAU"

    const-string v0, "ETABS_uEHEUPONHRL"

    const-string v0, "LEsPUSHNBH__EOARE"

    const-string v0, "ENABLE_OTHER_PUSH"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    check-cast p0, Ljava/lang/Boolean;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return p0

    :catchall_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo p0, "itlU"

    const-string/jumbo p0, "tUli"

    const/4 v3, 0x2

    const-string/jumbo p0, "tUil"

    const-string p0, "Util"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const-string v0, "4ptmesedsitfunsiPuP  OldenUc eoitrrihungxh"

    const-string v0, "i4 hsdtprfnuleUisuunptnPdt ih geOsPirxceeo"

    const/4 v3, 0x1

    const-string v0, "dncnorudu puhsei4rsPog OieehnliPesftx tteU"

    const-string/jumbo v0, "unexpected for init isUsedOtherPush4Plugin"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    return p0
.end method

.method public static p(Landroid/content/Context;)B
    .locals 5

    const/4 v4, 0x2

    sget-object v0, Lcom/tencent/android/tpush/common/MobileType;->UNKNOWN:Lcom/tencent/android/tpush/common/MobileType;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpush/common/MobileType;->getType()B

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-eqz p0, :cond_5

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/tencent/tpns/dataacquisition/CustomDeviceInfos;->getSimOperator(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz p0, :cond_5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v1, "b06q0"

    const-string v1, "046q0"

    const/4 v4, 0x7

    const-string v1, "0u460"

    const-string v1, "46000"

    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-nez v1, :cond_4

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string v1, "4sp60"

    const-string v1, "40s60"

    const/4 v4, 0x6

    const-string v1, "462q0"

    const-string v1, "46002"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-nez v1, :cond_4

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v1, "00s76"

    const-string v1, "46007"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v1, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v1, "20mm4"

    const-string v1, "420m6"

    const/4 v4, 0x5

    const-string v1, "0620o"

    const-string v1, "46020"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v1, "b4o61"

    const-string v1, "0146o"

    const/4 v4, 0x0

    const-string v1, "0u601"

    const-string v1, "46001"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-nez v1, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v1, "b0p64"

    const-string v1, "b0604"

    const/4 v4, 0x4

    const-string v1, "006q4"

    const-string v1, "46006"

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v1, "60s0u"

    const-string v1, "0u063"

    const/4 v4, 0x2

    const-string v1, "403m6"

    const-string v1, "46003"

    const/4 v4, 0x3

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    if-nez v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string v1, "46005"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v4, 0x1

    const/4 v3, 0x2

    if-eqz p0, :cond_5

    :cond_2
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    sget-object p0, Lcom/tencent/android/tpush/common/MobileType;->TELCOM:Lcom/tencent/android/tpush/common/MobileType;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/MobileType;->getType()B

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    goto :goto_2

    :cond_3
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    sget-object p0, Lcom/tencent/android/tpush/common/MobileType;->UNICOM:Lcom/tencent/android/tpush/common/MobileType;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/MobileType;->getType()B

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    goto :goto_2

    :cond_4
    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    sget-object p0, Lcom/tencent/android/tpush/common/MobileType;->CHINAMOBILE:Lcom/tencent/android/tpush/common/MobileType;

    const/4 v4, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpush/common/MobileType;->getType()B

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    goto :goto_2

    :catchall_0
    move-exception p0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const-string/jumbo v1, "tlUi"

    const-string v1, "Uitl"

    const-string/jumbo v1, "tUli"

    const-string v1, "Util"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo v2, "pgsIop"

    const-string v2, "gpptsI"

    const/4 v4, 0x6

    const-string/jumbo v2, "tgeIpb"

    const-string v2, "getIsp"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_5
    :goto_2
    const/4 v3, 0x3

    move v4, v3

    return v0
.end method

.method public static q(Landroid/content/Context;)Ljava/lang/String;
    .locals 6

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v1, Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v2, "iAtnnou.MIia.ectdonrdN.ian"

    const-string v2, "android.intent.action.MAIN"

    const/4 v5, 0x4

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string v2, "cnqoRdLpiaHEC.eytdtroaNgn.ternUA"

    const-string/jumbo v2, "nRadnretqtonyErCdANLaH.Ugco..tie"

    const/4 v5, 0x2

    const-string/jumbo v2, "r.ndcernqELCitoaHRo.igAeantdU.yt"

    const-string v2, "android.intent.category.LAUNCHER"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    check-cast v1, Landroid/content/pm/ResolveInfo;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v2, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v2, v2, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v2, v2, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object p0, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object p0, p0, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v1, "  srnhae oc aatlrrmecrgle:ssns "

    const-string/jumbo v1, "tes:gnlee mncsrhocr rs a luaa r"

    const/4 v5, 0x7

    const-string v1, " e m:msercleuars rn atncroa gle"

    const-string v1, "get launcher class name error: "

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v0, "iltU"

    const-string v0, "Uilt"

    const/4 v5, 0x2

    const-string v0, "Util"

    const/4 v5, 0x3

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v5, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x1

    move v5, v4

    return-object p0
.end method

.method private static r(Landroid/content/Context;)V
    .locals 4

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v1, Lcom/tencent/android/tpush/common/j$1;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/common/j$1;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v2, 0x2

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v1, "feoroCoraad Dangm rlti"

    const-string/jumbo v1, "raamroenl itr CogDoadf"

    const/4 v3, 0x6

    const-string v1, "d l:Cboarnt Dforrgoaea"

    const-string/jumbo v1, "loadConfigData error: "

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const-string/jumbo v0, "itlU"

    const-string/jumbo v0, "tUil"

    const/4 v3, 0x4

    const-string/jumbo v0, "tUil"

    const-string v0, "Util"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-void
.end method

.method private static s(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->flags:I

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    and-int/lit8 v0, v0, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x5

    or-int/2addr v3, v0

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x5

    const-string v1, "Util"

    const-string v1, "Uitl"

    const/4 v4, 0x0

    const-string/jumbo v1, "tilU"

    const-string v1, "Util"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/Thread;

    const/4 v3, 0x0

    move v4, v3

    new-instance v2, Lcom/tencent/android/tpush/common/j$2;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v2, p0}, Lcom/tencent/android/tpush/common/j$2;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {v0, v2}, Ljava/lang/Thread;-><init>(Ljava/lang/Runnable;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/Thread;->start()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const-string/jumbo v2, "irUeprute cacreskoooedhrn"

    const-string v2, "cdceoteiUo krporrseenarh "

    const/4 v4, 0x2

    const-string v2, " eirsotpphrc rncVderUaeok"

    const-string v2, "checkVersionUpdate error "

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v1, p0}, Lcom/tencent/tpns/baseapi/base/util/Logger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_1

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string p0, "blsae eIqei t"

    const-string/jumbo p0, "s te beslaIei"

    const/4 v4, 0x5

    const-string p0, "It is release"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v1, p0}, Lcom/tencent/tpns/baseapi/base/util/Logger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    return-void
.end method
