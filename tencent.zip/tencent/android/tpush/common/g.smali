.class public Lcom/tencent/android/tpush/common/g;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/String; = ""

.field private static b:Ljava/lang/String; = ""

.field private static c:Ljava/lang/String; = ""

.field private static d:Ljava/lang/String; = ""

.field private static e:Ljava/lang/String; = ""

.field private static f:Ljava/lang/String; = ""


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x5

    return-void
.end method

.method public static a()Ljava/lang/String;
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s~tS@l~~ov@f@ ~~s/~~~~ ~nr@@@ ~ @@~ ~@K@@M o @ mb1@o- ifcy~@ ~@oi ~dtbi o ol~@u@~.4@~/ ~ a~  b"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const-string/jumbo v1, "usamwe"

    const-string v1, "hwsaue"

    const/4 v3, 0x3

    const-string v1, "ahiwoe"

    const-string v1, "huawei"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/common/g;->f()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const-string/jumbo v1, "mmixob"

    const-string/jumbo v1, "oiamxm"

    const-string/jumbo v1, "uimxao"

    const-string/jumbo v1, "xiaomi"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/common/g;->j()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    return-object v0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string/jumbo v1, "ompie"

    const-string/jumbo v1, "mizeo"

    const/4 v3, 0x4

    const-string/jumbo v1, "umiqz"

    const-string/jumbo v1, "meizu"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/common/g;->i()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v1, "popo"

    const/4 v3, 0x1

    const-string/jumbo v1, "poop"

    const-string/jumbo v1, "oppo"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-nez v1, :cond_5

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v1, "lrseam"

    const-string v1, "ermalb"

    const/4 v3, 0x1

    const-string/jumbo v1, "mlrmae"

    const-string/jumbo v1, "realme"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v1, :cond_3

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string/jumbo v1, "viov"

    const-string/jumbo v1, "vvoi"

    const/4 v3, 0x5

    const-string/jumbo v1, "vivo"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v1, :cond_4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/common/g;->g()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0

    :cond_4
    const/4 v3, 0x7

    const-string/jumbo v1, "luenops"

    const-string/jumbo v1, "lopnseu"

    const-string/jumbo v1, "oneplus"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_6

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/common/g;->k()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    return-object v0

    :cond_5
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/common/g;->h()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0

    :catchall_0
    :cond_6
    const/4 v3, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-object v0
.end method

.method private static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v0, 0x1

    move v5, v0

    :try_start_0
    const/4 v4, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-array v1, v0, [Ljava/lang/Class;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-class v2, Ljava/lang/String;

    const-class v2, Ljava/lang/String;

    const/4 v5, 0x0

    const-class v2, Ljava/lang/String;

    const-class v2, Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    aput-object v2, v1, v3

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    aput-object p0, v0, v3

    const/4 v5, 0x6

    const-string/jumbo v2, "ntyosbdaoiSrrser.Pmote.edpi"

    const-string v2, ".ioiderpreoo.semytrspSnatPd"

    const/4 v5, 0x6

    const-string v2, "dS.rpeuayPoisoednse.tirrtso"

    const-string v2, "android.os.SystemProperties"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v3, "get"

    const-string v3, "get"

    const/4 v5, 0x3

    const-string/jumbo v3, "tge"

    const-string v3, "get"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v2, v3, v1}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v1, v2, v0}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    check-cast v0, Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo v1, "soolRHppeimrrene"

    const-string v1, "RioemrHpqrlnosee"

    const/4 v5, 0x3

    const-string v1, "HeeoseRVqprmonlr"

    const-string v1, "RomVersionHelper"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo v3, "tge "

    const-string v3, "get "

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo p0, "sisoesi rs: "

    const-string/jumbo p0, "resois si:n "

    const/4 v5, 0x2

    const-string/jumbo p0, "s emi:vnoi s"

    const-string p0, " version is:"

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-object v0

    :catchall_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string p0, ""

    const-string p0, ""

    const/4 v5, 0x4

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x0

    move v5, v4

    return-object p0
.end method

.method public static b()Z
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x5

    const-string/jumbo v1, "u.stoleeuicomBhdiy.a.Emmw"

    const-string/jumbo v1, "imBmiyd.etauwosmx.ceEulh."

    const/4 v6, 0x3

    const-string v1, "desymb..xuileocEsiwhaBut."

    const-string v1, "com.huawei.system.BuildEx"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {v1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v2, "ensgOrutoa"

    const-string v2, "gaOdoersnt"

    const/4 v6, 0x0

    const-string/jumbo v2, "tnBOdaepgs"

    const-string v2, "getOsBrand"

    const/4 v5, 0x7

    or-int/2addr v6, v5

    new-array v3, v0, [Ljava/lang/Class;

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1, v2, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string v3, "bqynohm"

    const-string v3, "aohynbm"

    const/4 v6, 0x1

    const-string/jumbo v3, "rysnmho"

    const-string v3, "harmony"

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    new-array v4, v0, [Ljava/lang/Object;

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-virtual {v2, v1, v4}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/NoSuchMethodException; {:try_start_0 .. :try_end_0} :catch_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    return v0
.end method

.method public static c()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string v0, "_vpmirbod.owssranhl.u.uilftc"

    const-string/jumbo v0, "ils.dvubiptraousr._ce.hnfowl"

    const/4 v2, 0x7

    const-string v0, "hw_sc.build.platform.version"

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/common/g;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public static d()I
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string v0, "."

    const-string v0, "."

    const/4 v7, 0x5

    const-string v0, "."

    const-string v0, "."

    const/4 v6, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string/jumbo v1, "olpioeRnrpmeseHr"

    const-string v1, "elrRVrpposmineeH"

    const/4 v7, 0x3

    const-string/jumbo v1, "noRplbeormVieseH"

    const-string v1, "RomVersionHelper"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v2, -0x1

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v3, "ruoiciu.swadmqlrhnsfp.ve.otl"

    const-string v3, "cot_doriqnvfapsuwlrlh...mies"

    const/4 v7, 0x2

    const-string v3, "cweabfrpm_lvso...stiilphndru"

    const-string v3, "hw_sc.build.platform.version"

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v3}, Lcom/tencent/android/tpush/common/g;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v3, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-ltz v4, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v3, v0}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v0

    const/4 v7, 0x1

    const/4 v4, 0x2

    const/4 v7, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v3, v4, v0}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    move-object v0, v3

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v5, 0x1

    const/4 v7, 0x2

    if-lt v4, v5, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    goto :goto_1

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string v5, "bgsists:qu"

    const-string/jumbo v5, "rssgus:itb"

    const-string v5, "gtsnr:sbsu"

    const-string/jumbo v5, "substring:"

    const/4 v7, 0x4

    const/4 v6, 0x3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-string v0, ",romthesrnyVrmmSain "

    const-string/jumbo v0, "roimatseSnrrm,Vynh o"

    const-string/jumbo v0, "oyiro,Shnmnas tVero:"

    const-string v0, ", harmonyVersionStr:"

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const-string/jumbo v3, "yoMm:bjroeaVnsaIohtnriOyo"

    const-string/jumbo v3, "nrnoooIOatroyVjhmi:aensMy"

    const/4 v7, 0x2

    const-string/jumbo v3, "omMroyusjahantoV:eIySOnni"

    const-string v3, "harmonyOSMajoyVersionInt:"

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    goto :goto_2

    :catchall_0
    move-exception v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string v4, "aogmMdopVtyljbaorye enariIen:tfH"

    const-string/jumbo v4, "ilrodbae:HIygefjnnaanMrmtyVot oe"

    const/4 v7, 0x2

    const-string/jumbo v4, "tomjfainqlHreyryMdgI tnVeoaoiean"

    const-string v4, "getHarmonyVerionMajoyInt failed:"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_2
    const/4 v6, 0x6

    const/4 v7, 0x1

    return v2
.end method

.method public static e()Z
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/common/g;->b()Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo v2, "omsRpesVlHrrniou"

    const-string v2, "RrmporuelnoViHse"

    const/4 v4, 0x3

    const-string/jumbo v2, "seRmoprelnmoiVHr"

    const-string v2, "RomVersionHelper"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez v1, :cond_0

    :try_start_1
    const/4 v4, 0x0

    const/4 v3, 0x4

    const-string v1, "SaO o rnnmyoop"

    const-string/jumbo v1, "oayOSnmpnt ro "

    const/4 v4, 0x2

    const-string/jumbo v1, "oo Hnbraynt mS"

    const-string v1, " not HarmonyOS"

    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    return v0

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHuaWei()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-nez v1, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v1, "r nioWuadBetun H"

    const-string v1, "Brand not HuaWei"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/common/g;->d()I

    move-result v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v2, 0x4

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-lt v1, v2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v0, 0x1

    :catchall_0
    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    return v0
.end method

.method private static f()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/common/g;->a:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/common/g;->a:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    const-string v0, ".q.u.noprierubmilisdv"

    const-string v0, ".rdoeivbqum..sloiurin"

    const/4 v2, 0x0

    const-string v0, "deouosniqrile..i.urmv"

    const-string/jumbo v0, "ro.build.version.emui"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/common/g;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    sput-object v0, Lcom/tencent/android/tpush/common/g;->a:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method private static g()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/common/g;->c:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/common/g;->c:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    const-string v0, ".osp.yuvdb.vddiios.ial.sloi"

    const-string/jumbo v0, "ro.vivo.os.build.display.id"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/common/g;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    sput-object v0, Lcom/tencent/android/tpush/common/g;->c:Ljava/lang/String;

    const/4 v2, 0x6

    return-object v0
.end method

.method private static h()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object v0, Lcom/tencent/android/tpush/common/g;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/common/g;->b:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v2, 0x2

    const-string v0, ".psvirsooi.lomu.rpobeodn"

    const-string/jumbo v0, "rbumnplid.mipororo.oosev"

    const-string/jumbo v0, "ro.build.version.opporom"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/common/g;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    sput-object v0, Lcom/tencent/android/tpush/common/g;->b:Ljava/lang/String;

    const/4 v2, 0x1

    return-object v0
.end method

.method private static i()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/android/tpush/common/g;->f:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    sget-object v0, Lcom/tencent/android/tpush/common/g;->f:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string/jumbo v0, "iilmos.pbrlui.a.ddd"

    const/4 v2, 0x5

    const-string v0, "dlbioai.dsrli.duyop"

    const-string/jumbo v0, "ro.build.display.id"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/common/g;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    sput-object v0, Lcom/tencent/android/tpush/common/g;->f:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method private static j()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/common/g;->e:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/common/g;->e:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    const-string/jumbo v0, "ro.miui.ui.version.name"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/common/g;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    sput-object v0, Lcom/tencent/android/tpush/common/g;->e:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object v0
.end method

.method private static k()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/common/g;->d:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/common/g;->d:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string/jumbo v0, "or.eobiomor.vs"

    const-string/jumbo v0, "meoros.ir.rovo"

    const/4 v2, 0x6

    const-string/jumbo v0, "oim.v.uoersnrr"

    const-string/jumbo v0, "ro.rom.version"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/common/g;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/android/tpush/common/g;->d:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-object v0
.end method
