.class public Lcom/tencent/android/tpush/common/e;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ljava/lang/String;)Ljava/lang/Object;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " @sS-@@@ f@o~i s~~~u@@  ~i@lob@  @~f  v~~c/.~ d~m~@ @@@~bt  ~ ol~a@~ ~@Mt/y@b~r@~~@1~o n ~4~io@K"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-eqz p0, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_1

    :cond_0
    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v1, Ljava/io/ByteArrayInputStream;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/common/e;->b(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-direct {v1, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance p0, Ljava/io/ObjectInputStream;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {p0, v1}, Ljava/io/ObjectInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/io/ObjectInputStream;->readObject()Ljava/lang/Object;

    move-result-object v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/io/ObjectInputStream;->close()V

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/io/ByteArrayInputStream;->close()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :catchall_1
    move-exception p0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    move-object p0, v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :catchall_2
    move-exception p0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    move-object p0, v1

    :goto_0
    :try_start_3
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    throw v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    :catchall_3
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    if-eqz p0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/io/ObjectInputStream;->close()V

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/io/ByteArrayInputStream;->close()V

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    throw v0

    :cond_3
    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v0
.end method

.method public static a(Ljava/io/Serializable;)Ljava/lang/String;
    .locals 5

    if-nez p0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x7

    move v4, v3

    const/4 v0, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x6

    new-instance v1, Ljava/io/ByteArrayOutputStream;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v2, Ljava/io/ObjectOutputStream;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v2, v1}, Ljava/io/ObjectOutputStream;-><init>(Ljava/io/OutputStream;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v2, p0}, Ljava/io/ObjectOutputStream;->writeObject(Ljava/lang/Object;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/common/e;->a([B)Ljava/lang/String;

    move-result-object p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v2}, Ljava/io/ObjectOutputStream;->close()V

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    return-object p0

    :catchall_0
    move-exception p0

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    move-object v0, v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto :goto_0

    :catchall_1
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto :goto_0

    :catchall_2
    move-exception p0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    :goto_0
    :try_start_3
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    throw p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    :catchall_3
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/io/ObjectOutputStream;->close()V

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/io/ByteArrayOutputStream;->close()V

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    throw p0
.end method

.method public static a([B)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuffer;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    array-length v2, p0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-ge v1, v2, :cond_0

    const/4 v3, 0x6

    move v4, v3

    aget-byte v2, p0, v1

    shr-int/lit8 v2, v2, 0x4

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    and-int/lit8 v2, v2, 0xf

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    add-int/lit8 v2, v2, 0x61

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    int-to-char v2, v2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    aget-byte v2, p0, v1

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    and-int/lit8 v2, v2, 0xf

    const/4 v4, 0x3

    add-int/lit8 v2, v2, 0x61

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    int-to-char v2, v2

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuffer;->append(C)Ljava/lang/StringBuffer;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object p0
.end method

.method public static b(Ljava/lang/String;)[B
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    div-int/lit8 v0, v0, 0x2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    new-array v1, v0, [B

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-ge v2, v3, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v7, 0x2

    const/4 v6, 0x3

    div-int/lit8 v4, v2, 0x2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-ge v4, v0, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    add-int/lit8 v3, v3, -0x61

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    shl-int/lit8 v3, v3, 0x4

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    int-to-byte v3, v3

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    aput-byte v3, v1, v4

    const/4 v7, 0x3

    add-int/lit8 v3, v2, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p0, v3}, Ljava/lang/String;->charAt(I)C

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    aget-byte v5, v1, v4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    add-int/lit8 v3, v3, -0x61

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    add-int/2addr v5, v3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    int-to-byte v3, v5

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    aput-byte v3, v1, v4

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    add-int/lit8 v2, v2, 0x2

    const/4 v7, 0x1

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    return-object v1
.end method
