.class Lcom/tencent/android/tpush/TpnsActivity$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/TpnsActivity;->b(Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/os/Bundle;

.field final synthetic b:Lcom/tencent/android/tpush/XGPushClickedResult;

.field final synthetic c:Lcom/tencent/android/tpush/TpnsActivity;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/TpnsActivity;Landroid/os/Bundle;Lcom/tencent/android/tpush/XGPushClickedResult;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/TpnsActivity$1;->c:Lcom/tencent/android/tpush/TpnsActivity;

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/TpnsActivity$1;->a:Landroid/os/Bundle;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p3, p0, Lcom/tencent/android/tpush/TpnsActivity$1;->b:Lcom/tencent/android/tpush/XGPushClickedResult;

    const/4 v1, 0x7

    const/4 v0, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "o@sti@~i@f t~1i@r@o.- Md~@l@@~o~/@ o~c~  ~~ ~@~  ~@so@n~~S K  ~~m@@@@@uol  ~bf~~@~~y @~4  b/@av "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/TpnsActivity$1;->c:Lcom/tencent/android/tpush/TpnsActivity;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-lez v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v0, "ciTmstsAnvpy"

    const-string/jumbo v0, "ptscsvyTiniA"

    const/4 v4, 0x4

    const-string/jumbo v0, "tcTnosiyiAvt"

    const-string v0, "TpnsActivity"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo v1, "plehcbokdlefmatbafmnae LlGDiiinnineC"

    const-string/jumbo v1, "kelmnlLplCidhlaenctnaa iimineobfDfGe"

    const-string v1, " mdapiuaeiGtcfLennlobehllnlf nDkCeai"

    const-string v1, "fcmChannelDeepLink initGlobal failed"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/TpnsActivity$1;->c:Lcom/tencent/android/tpush/TpnsActivity;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/TpnsActivity$1;->a:Landroid/os/Bundle;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/TpnsActivity$1;->b:Lcom/tencent/android/tpush/XGPushClickedResult;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v0, v1, v2}, Lcom/tencent/android/tpush/TpnsActivity;->a(Lcom/tencent/android/tpush/TpnsActivity;Landroid/os/Bundle;Lcom/tencent/android/tpush/XGPushClickedResult;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void
.end method
