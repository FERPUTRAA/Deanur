.class public Lcom/tencent/android/tpush/data/CachedMessageIntent;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x17eda7b651108297L


# instance fields
.field public intent:Ljava/lang/String;

.field public msgId:J

.field public pkgName:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string v0, ""

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/data/CachedMessageIntent;->pkgName:Ljava/lang/String;

    const/4 v1, 0x5

    move v2, v1

    iput-object v0, p0, Lcom/tencent/android/tpush/data/CachedMessageIntent;->intent:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@~s4vo @f~/~o~~M@~u-~ .@ c~  ~m ~@@so oo K~~nb a l1@tS~/@d@@i@@  ~@@@ if@@ bby ~~t @~i~~ @~ol~r@"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    instance-of v0, p1, Lcom/tencent/android/tpush/data/CachedMessageIntent;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    check-cast p1, Lcom/tencent/android/tpush/data/CachedMessageIntent;

    const/4 v5, 0x3

    iget-object v0, p1, Lcom/tencent/android/tpush/data/CachedMessageIntent;->pkgName:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/data/CachedMessageIntent;->pkgName:Ljava/lang/String;

    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget-wide v0, p1, Lcom/tencent/android/tpush/data/CachedMessageIntent;->msgId:J

    const/4 v5, 0x5

    const/4 v4, 0x1

    iget-wide v2, p0, Lcom/tencent/android/tpush/data/CachedMessageIntent;->msgId:J

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    cmp-long p1, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-nez p1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    const/4 p1, 0x1

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 p1, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    return p1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-super {p0, p1}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    return p1
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-super {p0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v1, " egm[teMksseecatsdmnIaCe=pnNa"

    const-string v1, "cIses=N epnmnekMeCtatsgegdaa["

    const/4 v4, 0x6

    const-string v1, "Mcgnodt eehasaCkpe[sNenIg=tem"

    const-string v1, "CachedMessageIntent [pkgName="

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/data/CachedMessageIntent;->pkgName:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v1, "gmm,Ib=s"

    const-string/jumbo v1, "mgIm=s,d"

    const/4 v4, 0x3

    const-string v1, "=m,Id ug"

    const-string v1, ", msgId="

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/CachedMessageIntent;->msgId:J

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x3

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-object v0
.end method
