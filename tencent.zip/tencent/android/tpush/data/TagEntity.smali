.class public Lcom/tencent/android/tpush/data/TagEntity;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final serialVersionUID:J = 0x14218be8431737b2L


# instance fields
.field public accessId:J

.field public flag:I

.field public tag:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/tencent/android/tpush/data/TagEntity;->accessId:J

    const/4 v2, 0x3

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/data/TagEntity;->tag:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x1

    iput v0, p0, Lcom/tencent/android/tpush/data/TagEntity;->flag:I

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-void
.end method
