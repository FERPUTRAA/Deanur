.class public Lcom/tencent/android/tpush/data/UnregisterInfo;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final TYPE_UNINSTALL:B = 0x1t

.field public static final TYPE_UNREGISTER:B = 0x0t

.field private static final serialVersionUID:J = -0x1fd3f7b98d8ad375L


# instance fields
.field public accessId:J

.field public accessKey:Ljava/lang/String;

.field public appCert:Ljava/lang/String;

.field public isUninstall:B

.field public option:Ljava/lang/String;

.field public packName:Ljava/lang/String;

.field public timestamp:J

.field public token:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;BLjava/lang/String;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    int-to-long v0, p1

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/data/UnregisterInfo;->accessId:J

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpush/data/UnregisterInfo;->accessKey:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object p3, p0, Lcom/tencent/android/tpush/data/UnregisterInfo;->token:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-byte p4, p0, Lcom/tencent/android/tpush/data/UnregisterInfo;->isUninstall:B

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput-object p5, p0, Lcom/tencent/android/tpush/data/UnregisterInfo;->packName:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "fos @ m @@o/ ~n~@@~@l/~ Sol @ @~@~~@@@~ i1r~u.~~@t@@~~@f~  K~~M~b4 ~ao@ @ ~o~ @bioy-tbcd  ~@siv "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v1, "--em---er--nn--f-oi-s-g-/--s---It--Un---r---"

    const-string v1, "--so---e------n----esf----I-t/-rrU-i-nng----"

    const-string v1, "------------UnregisterInfo----------------\n"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v1, "=dmcosIce"

    const-string v1, "cdsm=sIce"

    const/4 v4, 0x4

    const-string/jumbo v1, "s=seabIdc"

    const-string v1, "accessId="

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/UnregisterInfo;->accessId:J

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string v1, "/n"

    const-string/jumbo v1, "n/"

    const/4 v4, 0x6

    const-string/jumbo v1, "n/"

    const-string v1, "\n"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo v2, "seo=kyuace"

    const-string/jumbo v2, "yesao=kecs"

    const/4 v4, 0x3

    const-string v2, "=ykecacpss"

    const-string v2, "accesskey="

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/data/UnregisterInfo;->accessKey:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v2, "koqte="

    const-string v2, "=ktoeb"

    const/4 v4, 0x0

    const-string/jumbo v2, "nkset="

    const-string/jumbo v2, "token="

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/data/UnregisterInfo;->token:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v2, "nslms=Uuitna"

    const-string v2, "Ulss=autnini"

    const/4 v4, 0x7

    const-string/jumbo v2, "tni=oslUslni"

    const-string/jumbo v2, "isUninstall="

    const/4 v4, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-byte v2, p0, Lcom/tencent/android/tpush/data/UnregisterInfo;->isUninstall:B

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v2, "aapmNbep="

    const-string v2, "=mapeaNpc"

    const/4 v4, 0x6

    const-string/jumbo v2, "packName="

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/data/UnregisterInfo;->packName:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v1, "--U--Ius--------nn-d-rn-gro-E ---e-ie---f-t-"

    const-string v1, "--------------UnregisterInfo End------------"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object v0
.end method
