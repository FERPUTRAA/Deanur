.class public Lcom/tencent/android/tpush/data/RegisterEntity;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field private static final TAG:Ljava/lang/String; = "RegisterEntity"

.field public static final TYPE_REGISTER:B = 0x0t

.field public static final TYPE_REMOTE_UNINSTALL:B = 0x4t

.field public static final TYPE_REMOTE_UNREGISTER:B = 0x3t

.field public static final TYPE_UNINSTALL:B = 0x2t

.field public static final TYPE_UNREGISTER:B = 0x1t

.field private static final serialVersionUID:J = -0x6ee64ba43c00faaeL


# instance fields
.field public accessId:J

.field public accessKey:Ljava/lang/String;

.field public appVersion:Ljava/lang/String;

.field public channelId:J

.field public guid:J

.field public packageName:Ljava/lang/String;

.field public state:I

.field public timestamp:J

.field public token:Ljava/lang/String;

.field public xgSDKVersion:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, "9ss.4.."

    const-string v0, "14s..9."

    const/4 v2, 0x1

    const-string v0, "1.4.3.9"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->xgSDKVersion:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public static decode(Ljava/lang/String;)Lcom/tencent/android/tpush/data/RegisterEntity;
    .locals 3

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "do@m  ~ bo~. /   l~@ ~@@i@ 1/~ ~Kt@i@~@~o~r y@~~ @~ ~v~s@bnc-@4So~f M@liu bot~@@@of@~~@@@~~ ~ma~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/common/e;->a(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast p0, Lcom/tencent/android/tpush/data/RegisterEntity;
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x7

    move v2, v1

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    goto :goto_0

    :catch_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    const-string/jumbo p0, "ytEtogsntieime"

    const-string/jumbo p0, "neRmisetigtyEt"

    const-string/jumbo p0, "tseytbrREeigni"

    const-string p0, "RegisterEntity"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string v0, "egoFRsucinedstutyConeslt oaodedtNEr"

    const-string v0, "Etdnoeoio lgscteunCeNadsstoFtRedyr "

    const/4 v2, 0x2

    const-string v0, "RegisterEntity decode ClassNotFound"

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 p0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method public static encode(Lcom/tencent/android/tpush/data/RegisterEntity;)Ljava/lang/String;
    .locals 2

    :try_start_0
    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/common/e;->a(Ljava/io/Serializable;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    const/4 p0, 0x0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-object p0
.end method


# virtual methods
.method public getGuid()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->guid:J

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-wide v0
.end method

.method public isRegistered()Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->state:I

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return v0
.end method

.method public isUnregistered()Z
    .locals 4

    const/4 v2, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->state:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    return v1
.end method

.method public isUnstalled()Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v0, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->state:I

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v3, 0x4

    return v0
.end method

.method public setGuid(J)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-wide p1, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->guid:J

    const/4 v0, 0x3

    xor-int/2addr v1, v0

    return-void
.end method

.method public setRegistered()V
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    iput v0, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->state:I

    const/4 v1, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method

.method public setUnregistered()V
    .locals 3

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v2, 0x6

    iput v0, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->state:I

    const/4 v2, 0x1

    return-void
.end method

.method public setUnstalled()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x2

    const/4 v2, 0x1

    iput v0, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->state:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string v1, "g dtsb[peEetRsIcycsriae=t"

    const-string/jumbo v1, "ns=rIbRyett Eegisctaces[d"

    const/4 v4, 0x2

    const-string v1, "RegisterEntity [accessId="

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->accessId:J

    const/4 v4, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string v1, "ecuyK s=q,ac"

    const-string v1, "cec=a,uyKss "

    const/4 v4, 0x0

    const-string v1, ", accessKey="

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->accessKey:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo v1, "k=spnte "

    const-string v1, " =etkn,p"

    const/4 v4, 0x0

    const-string v1, "=, mekto"

    const-string v1, ", token="

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->token:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v1, "= aNo,kaepcaem"

    const-string v1, " Naceam,qk=pae"

    const/4 v4, 0x1

    const-string v1, ",aakebap mecN="

    const-string v1, ", packageName="

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->packageName:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v1, ",tsateus"

    const-string/jumbo v1, "ttss e,a"

    const/4 v4, 0x5

    const-string v1, "a test=p"

    const-string v1, ", state="

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget v1, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->state:I

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v1, " tmpmti,qm=e"

    const-string/jumbo v1, "mm,m ttae=ip"

    const/4 v4, 0x5

    const-string/jumbo v1, "mestism pat="

    const-string v1, ", timestamp="

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->timestamp:J

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v1, "DKgmsSne=xV,io "

    const-string/jumbo v1, "inoxo SV=gKe,Ds"

    const/4 v4, 0x0

    const-string v1, "=Srnog,sDoeKiVx"

    const-string v1, ", xgSDKVersion="

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->xgSDKVersion:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v1, "b=opabiVe np,"

    const-string/jumbo v1, "oiVs beanpp=,"

    const/4 v4, 0x7

    const-string/jumbo v1, "siep puoVa=r,"

    const-string v1, ", appVersion="

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->appVersion:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo v1, "pi u,d="

    const-string/jumbo v1, "ig d=,u"

    const/4 v4, 0x3

    const-string/jumbo v1, "uq di=g"

    const-string v1, ", guid="

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/RegisterEntity;->guid:J

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x5

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object v0
.end method
