.class public Lcom/tencent/android/tpush/data/StorageEntity;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/tencent/android/tpush/data/StorageEntity;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field public a:Ljava/lang/String;

.field public b:I

.field public c:Z

.field public d:Ljava/lang/String;

.field public e:I

.field public f:F

.field public g:J


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Lcom/tencent/android/tpush/data/StorageEntity$1;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-direct {v0}, Lcom/tencent/android/tpush/data/StorageEntity$1;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/android/tpush/data/StorageEntity;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string v0, ""

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/data/StorageEntity;->a:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, -0x1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    iput v0, p0, Lcom/tencent/android/tpush/data/StorageEntity;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/os/Parcel;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/data/StorageEntity;->a:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v0, -0x4

    const/4 v0, -0x1

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    iput v0, p0, Lcom/tencent/android/tpush/data/StorageEntity;->b:I

    const/4 v1, 0x0

    move v2, v1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/data/StorageEntity;->a(Landroid/os/Parcel;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method private a(Landroid/os/Parcel;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "coso@-@S~t~@r@iM o ~~tu bi@@~@ ~ om~~~/ ~1nf@soo~~fK@ @~   ~~@@y~@l@ 4 ~@ad~~ v@i~@~b@  l@/@b~ ."

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/data/StorageEntity;->a:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    iput v0, p0, Lcom/tencent/android/tpush/data/StorageEntity;->b:I

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p1}, Landroid/os/Parcel;->readByte()B

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x0

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-boolean v1, p0, Lcom/tencent/android/tpush/data/StorageEntity;->c:Z

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/data/StorageEntity;->d:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    iput v0, p0, Lcom/tencent/android/tpush/data/StorageEntity;->e:I

    const/4 v2, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/os/Parcel;->readFloat()F

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput v0, p0, Lcom/tencent/android/tpush/data/StorageEntity;->f:F

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/data/StorageEntity;->g:J

    const/4 v3, 0x6

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public describeContents()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v1, "S:emkgEstetyiyrt[n"

    const-string v1, "Eestgokn:Syeiyr[tt"

    const/4 v4, 0x2

    const-string v1, ":Eeyonkotiay[gteSt"

    const-string v1, "StorageEntity[key:"

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/data/StorageEntity;->a:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v1, ":m,ptb"

    const-string v1, ",epm:t"

    const/4 v4, 0x4

    const-string/jumbo v1, "u:py,e"

    const-string v1, ",type:"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    iget v1, p0, Lcom/tencent/android/tpush/data/StorageEntity;->b:I

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const-string v1, ",Vteuarp:l"

    const-string v1, ",strValue:"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/data/StorageEntity;->d:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string v1, ":eaoV,uoqob"

    const-string/jumbo v1, "ueabooVol,:"

    const/4 v4, 0x0

    const-string v1, "besaloVo,u:"

    const-string v1, ",boolValue:"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-boolean v1, p0, Lcom/tencent/android/tpush/data/StorageEntity;->c:Z

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    shr-int/2addr v4, v3

    const-string v1, "aeimutl,b"

    const-string v1, "Vuteabil,"

    const/4 v4, 0x2

    const-string/jumbo v1, "natioVe,u"

    const-string v1, ",intValue"

    const/4 v3, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget v1, p0, Lcom/tencent/android/tpush/data/StorageEntity;->e:I

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo v1, "tufVlbaloae:"

    const-string v1, ",floatValue:"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/android/tpush/data/StorageEntity;->f:F

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v1, "el:l,uugnao"

    const/4 v4, 0x3

    const-string/jumbo v1, "lnu:Vou,egl"

    const-string v1, ",longValue:"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/StorageEntity;->g:J

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    move v4, v3

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x0

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object p2, p0, Lcom/tencent/android/tpush/data/StorageEntity;->a:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget p2, p0, Lcom/tencent/android/tpush/data/StorageEntity;->b:I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-boolean p2, p0, Lcom/tencent/android/tpush/data/StorageEntity;->c:Z

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeByte(B)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    iget-object p2, p0, Lcom/tencent/android/tpush/data/StorageEntity;->d:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget p2, p0, Lcom/tencent/android/tpush/data/StorageEntity;->e:I

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x1

    iget p2, p0, Lcom/tencent/android/tpush/data/StorageEntity;->f:F

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeFloat(F)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/tencent/android/tpush/data/StorageEntity;->g:J

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method
