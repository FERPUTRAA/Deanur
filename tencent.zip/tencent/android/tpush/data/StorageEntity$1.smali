.class Lcom/tencent/android/tpush/data/StorageEntity$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/data/StorageEntity;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Landroid/os/Parcelable$Creator<",
        "Lcom/tencent/android/tpush/data/StorageEntity;",
        ">;"
    }
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(Landroid/os/Parcel;)Lcom/tencent/android/tpush/data/StorageEntity;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "rbs  @@ du~ @~v@@K@l t@~~- @/~o @ ~b   @s~f@.~ao~~tio~/~l~~  n4f@SM@ i@ c@~ ~~ @~o~~@~@1~mo@oybi"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    new-instance v0, Lcom/tencent/android/tpush/data/StorageEntity;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {v0, p1}, Lcom/tencent/android/tpush/data/StorageEntity;-><init>(Landroid/os/Parcel;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public a(I)[Lcom/tencent/android/tpush/data/StorageEntity;
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    new-array p1, p1, [Lcom/tencent/android/tpush/data/StorageEntity;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-object p1
.end method

.method public synthetic createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/data/StorageEntity$1;->a(Landroid/os/Parcel;)Lcom/tencent/android/tpush/data/StorageEntity;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-object p1
.end method

.method public synthetic newArray(I)[Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/data/StorageEntity$1;->a(I)[Lcom/tencent/android/tpush/data/StorageEntity;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    return-object p1
.end method
