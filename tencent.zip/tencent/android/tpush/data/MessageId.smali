.class public Lcom/tencent/android/tpush/data/MessageId;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/io/Serializable;


# static fields
.field public static final FLAG_ACK:S = 0x1s

.field public static final FLAG_UNACK:S = 0x0s

.field private static final serialVersionUID:J = 0x78d997784a0c7922L


# instance fields
.field public accessId:J

.field public apn:B

.field public busiMsgId:J

.field public channelId:J

.field public date:Ljava/lang/String;

.field public groupId:Ljava/lang/String;

.field public host:J

.field public id:J

.field public isAck:S

.field public isp:B

.field public msgType:J

.field public multiPkg:J

.field public nGroupId:Ljava/lang/String;

.field public pact:B

.field public pkgName:Ljava/lang/String;

.field public port:I

.field public pushChannel:I

.field public pushTime:J

.field public receivedTime:J

.field public revokeId:I

.field public serverTime:J

.field public serviceHost:Ljava/lang/String;

.field public statTag:Ljava/lang/String;

.field public timestamp:J

.field public ttl:J


# direct methods
.method public constructor <init>()V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/data/MessageId;->busiMsgId:J

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/data/MessageId;->timestamp:J

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x0

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    iput-wide v2, p0, Lcom/tencent/android/tpush/data/MessageId;->msgType:J

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/data/MessageId;->multiPkg:J

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/data/MessageId;->date:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput-wide v2, p0, Lcom/tencent/android/tpush/data/MessageId;->channelId:J

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/data/MessageId;->nGroupId:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/data/MessageId;->statTag:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/data/MessageId;->groupId:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    iput v0, p0, Lcom/tencent/android/tpush/data/MessageId;->revokeId:I

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void
.end method


# virtual methods
.method public isMsgAcked()Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "K s /l~~~ @@~ o~u sy  mof~@i~d@~1@~v@~~@~l -@ S.o  ~~iM@~@i@ @@~ba@ ~ @@o~@ ~/rnc ~of@@4tb @~bo~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-short v0, p0, Lcom/tencent/android/tpush/data/MessageId;->isAck:S

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-ne v0, v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return v1
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const-string/jumbo v1, "sa=megsIMds[d "

    const-string v1, "aIss dedesMg[="

    const/4 v4, 0x7

    const-string v1, "MessageId [id="

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/MessageId;->id:J

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v1, "mA,koics"

    const-string/jumbo v1, "sikmA,c "

    const/4 v4, 0x3

    const-string v1, "c,=i bkA"

    const-string v1, ", isAck="

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    iget-short v1, p0, Lcom/tencent/android/tpush/data/MessageId;->isAck:S

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo v1, "u s=pi"

    const-string v1, "i =sop"

    const/4 v4, 0x7

    const-string/jumbo v1, "ip=sp "

    const-string v1, ", isp="

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-byte v1, p0, Lcom/tencent/android/tpush/data/MessageId;->isp:B

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const-string v1, "=aqpb "

    const-string v1, "a =pnb"

    const/4 v4, 0x2

    const-string v1, "=as,pn"

    const-string v1, ", apn="

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    iget-byte v1, p0, Lcom/tencent/android/tpush/data/MessageId;->apn:B

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v1, "duIm=s,c cs"

    const-string v1, ",ssc= uecId"

    const/4 v4, 0x5

    const-string/jumbo v1, "s c=osd,cae"

    const-string v1, ", accessId="

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/MessageId;->accessId:J

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string/jumbo v1, "peTe=bdvei,me i"

    const-string v1, "eie,eerp=iTdvm "

    const/4 v4, 0x1

    const-string v1, ", receivedTime="

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/MessageId;->receivedTime:J

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v1, "a=tqc u"

    const-string/jumbo v1, "tq,c= a"

    const/4 v4, 0x3

    const-string/jumbo v1, "pc=pa, "

    const-string v1, ", pact="

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-byte v1, p0, Lcom/tencent/android/tpush/data/MessageId;->pact:B

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo v1, "tqo ssh"

    const-string/jumbo v1, "t soh,s"

    const/4 v4, 0x2

    const-string v1, ", host="

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/MessageId;->host:J

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v1, " p=m,ro"

    const/4 v4, 0x4

    const-string v1, "=ospt r"

    const-string v1, ", port="

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/android/tpush/data/MessageId;->port:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo v1, "item=eoo,ss Hv"

    const-string v1, "esHeov s=io,tc"

    const/4 v4, 0x5

    const-string v1, "Hieeo,=ss vtcr"

    const-string v1, ", serviceHost="

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/data/MessageId;->serviceHost:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v1, "mg ,abb=ek"

    const-string v1, "a,pkmb= eg"

    const/4 v4, 0x1

    const-string v1, " g,pamuN=k"

    const-string v1, ", pkgName="

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/data/MessageId;->pkgName:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const-string v1, "gb,sMs piuI="

    const-string/jumbo v1, "sdIb= us,gMi"

    const-string/jumbo v1, "usMsd ibq=,g"

    const-string v1, ", busiMsgId="

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/MessageId;->busiMsgId:J

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v1, "=as,mpmt tsi"

    const-string/jumbo v1, "ist,am pt=me"

    const/4 v4, 0x4

    const-string/jumbo v1, "mt,mia =mstp"

    const-string v1, ", timestamp="

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/MessageId;->timestamp:J

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v3, 0x5

    const-string/jumbo v1, "p, Tomgsqe"

    const-string v1, ",gspm yeqT"

    const/4 v4, 0x1

    const-string v1, ", msgType="

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/MessageId;->msgType:J

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v1, ",suPgbmlk=i"

    const-string v1, "=ismPgt,kul"

    const-string v1, "=gPkuiu,mt "

    const-string v1, ", multiPkg="

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/MessageId;->multiPkg:J

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo v1, "pmea=t,"

    const-string/jumbo v1, "tdame=,"

    const/4 v4, 0x6

    const-string v1, ",qa=de "

    const-string v1, ", date="

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/data/MessageId;->date:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo v1, "rrs,vesiTemo="

    const-string/jumbo v1, "m=r,oieeeTsvr"

    const/4 v4, 0x5

    const-string/jumbo v1, "irmm, Tee=rev"

    const-string v1, ", serverTime="

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/MessageId;->serverTime:J

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v1, "t b,ot"

    const-string/jumbo v1, "tt ,lb"

    const-string v1, " =ttlb"

    const-string v1, ", ttl="

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/data/MessageId;->ttl:J

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x7

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v1, "k=,Ioeuue d"

    const-string v1, "de,ko uve=I"

    const-string/jumbo v1, "rdvk eopeI="

    const-string v1, ", revokeId="

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v1, p0, Lcom/tencent/android/tpush/data/MessageId;->revokeId:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    return-object v0
.end method
