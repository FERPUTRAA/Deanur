.class public Lcom/tencent/android/tpush/XGNotifaction;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20150316"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->RECEIVERCHECK:Lcom/jg/EType;,
        .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;
    }
.end annotation


# instance fields
.field private a:I

.field private b:Landroid/app/Notification;

.field private c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Landroid/content/Context;

.field private g:Ljava/lang/String;

.field private h:Ljava/lang/String;

.field private i:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;ILandroid/app/Notification;Lcom/tencent/android/tpush/message/d;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iput v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->a:I

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->b:Landroid/app/Notification;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->c:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->d:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->e:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->f:Landroid/content/Context;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->g:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->h:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->i:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    if-nez p4, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGNotifaction;->f:Landroid/content/Context;

    const/4 v2, 0x1

    iput p2, p0, Lcom/tencent/android/tpush/XGNotifaction;->a:I

    const/4 v1, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object p3, p0, Lcom/tencent/android/tpush/XGNotifaction;->b:Landroid/app/Notification;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p4}, Lcom/tencent/android/tpush/message/a;->d()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGNotifaction;->c:Ljava/lang/String;

    const/4 v1, 0x0

    move v2, v1

    invoke-virtual {p4}, Lcom/tencent/android/tpush/message/a;->e()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGNotifaction;->d:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x4

    invoke-virtual {p4}, Lcom/tencent/android/tpush/message/a;->f()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGNotifaction;->e:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p4}, Lcom/tencent/android/tpush/message/d;->l()Lcom/tencent/android/tpush/message/d$a;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    iget-object p1, p1, Lcom/tencent/android/tpush/message/d$a;->d:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGNotifaction;->g:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p4}, Lcom/tencent/android/tpush/message/d;->l()Lcom/tencent/android/tpush/message/d$a;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object p1, p1, Lcom/tencent/android/tpush/message/d$a;->f:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGNotifaction;->h:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p4}, Lcom/tencent/android/tpush/message/d;->l()Lcom/tencent/android/tpush/message/d$a;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object p1, p1, Lcom/tencent/android/tpush/message/d$a;->b:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGNotifaction;->i:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public doNotify()Z
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->b:Landroid/app/Notification;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->f:Landroid/content/Context;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const-string v1, "fnsitcsoitao"

    const-string/jumbo v1, "nascottiiiof"

    const/4 v4, 0x5

    const-string v1, "atnmoioicfni"

    const-string/jumbo v1, "notification"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    check-cast v0, Landroid/app/NotificationManager;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    iget v1, p0, Lcom/tencent/android/tpush/XGNotifaction;->a:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/XGNotifaction;->b:Landroid/app/Notification;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    return v0

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x7

    return v0
.end method

.method public getContent()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->d:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x2

    return-object v0
.end method

.method public getCustomContent()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->e:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public getNotifaction()Landroid/app/Notification;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->b:Landroid/app/Notification;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public getNotifyId()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->a:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method

.method public getTargetActivity()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->i:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public getTargetIntent()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->g:Ljava/lang/String;

    const/4 v1, 0x2

    move v2, v1

    return-object v0
.end method

.method public getTargetUrl()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->h:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGNotifaction;->c:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object v0
.end method

.method public setNotifyId(I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    iput p1, p0, Lcom/tencent/android/tpush/XGNotifaction;->a:I

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v2, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string v1, "NnfXoI[otcft=doGmiiiyota"

    const-string/jumbo v1, "ifomaytdNGocItnXnf=[oiit"

    const/4 v3, 0x4

    const-string v1, "=Gayob ocfdotIiXtniNf[tn"

    const-string v1, "XGNotifaction [notifyId="

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iget v1, p0, Lcom/tencent/android/tpush/XGNotifaction;->a:I

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const-string v1, " =loeiu,"

    const-string/jumbo v1, "l i=o,et"

    const/4 v3, 0x5

    const-string v1, " iettl,p"

    const-string v1, ", title="

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGNotifaction;->c:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v1, "ctotb= eq,"

    const-string/jumbo v1, "nt=eob tc,"

    const/4 v3, 0x3

    const-string v1, ", content="

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGNotifaction;->d:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string/jumbo v1, "tesuutCtoonmcs=,"

    const-string/jumbo v1, "ne,tutunto=Cmsoc"

    const/4 v3, 0x3

    const-string/jumbo v1, "untmt=otesmc,oCn"

    const-string v1, ", customContent="

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGNotifaction;->e:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string v1, "]"

    const-string v1, "]"

    const/4 v3, 0x2

    const-string v1, "]"

    const-string v1, "]"

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object v0
.end method
