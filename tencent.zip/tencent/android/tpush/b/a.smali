.class public Lcom/tencent/android/tpush/b/a;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/String; = "InMsgManagerInstance"

.field private static b:Ljava/lang/String; = "com.tencent.android.tpush.inapp.InMsgManager"

.field private static c:Ljava/lang/String; = "show"

.field private static d:Ljava/lang/String; = "dismiss"

.field private static e:Ljava/lang/Class;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/lang/Class<",
            "*>;"
        }
    .end annotation
.end field

.field private static f:Ljava/lang/reflect/Method;

.field private static g:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public static a()V
    .locals 8

    :try_start_0
    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@is  @lsfo~~  @i~~@~~om@~ @ @b ~~/.  t Mtn~-@loorbi@~4~d@ ~@@~@~  @~yooba/K1~@@@~ f @Scv~ ~~@ @~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    sget-boolean v0, Lcom/tencent/android/tpush/b/a;->g:Z

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-nez v0, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    sget-object v0, Lcom/tencent/android/tpush/b/a;->e:Ljava/lang/Class;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-nez v0, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x7

    sget-object v0, Lcom/tencent/android/tpush/b/a;->b:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    sput-object v0, Lcom/tencent/android/tpush/b/a;->e:Ljava/lang/Class;

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    sget-object v0, Lcom/tencent/android/tpush/b/a;->f:Ljava/lang/reflect/Method;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    const/4 v1, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    if-nez v0, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    sget-object v0, Lcom/tencent/android/tpush/b/a;->e:Ljava/lang/Class;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    sget-object v2, Lcom/tencent/android/tpush/b/a;->c:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    const/4 v3, 0x2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-array v3, v3, [Ljava/lang/Class;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-class v4, Landroid/content/Context;

    const/4 v7, 0x3

    const-class v4, Landroid/content/Context;

    const-class v4, Landroid/content/Context;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v5, 0x0

    const/4 v7, 0x6

    aput-object v4, v3, v5

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-class v4, Lcom/tencent/android/tpush/message/PushMessageManager;

    const-class v4, Lcom/tencent/android/tpush/message/PushMessageManager;

    const/4 v7, 0x5

    const-class v4, Lcom/tencent/android/tpush/message/PushMessageManager;

    const-class v4, Lcom/tencent/android/tpush/message/PushMessageManager;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    aput-object v4, v3, v1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0, v2, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    sput-object v0, Lcom/tencent/android/tpush/b/a;->f:Ljava/lang/reflect/Method;

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    sput-boolean v1, Lcom/tencent/android/tpush/b/a;->g:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x2

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    sget-object v1, Lcom/tencent/android/tpush/b/a;->a:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string/jumbo v3, "r hmv ohsdownoe)t see: orr(k"

    const-string/jumbo v3, "otshkohni ov(w ) :rodres ere"

    const/4 v7, 0x7

    const-string v3, " d)woo voekorr(sinotehhe :mr"

    const-string/jumbo v3, "invoke method show() error: "

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v6, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    return-void
.end method

.method public static a(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V
    .locals 6

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/b/a;->a()V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    sget-object v0, Lcom/tencent/android/tpush/b/a;->f:Ljava/lang/reflect/Method;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    sget-object v1, Lcom/tencent/android/tpush/b/a;->e:Ljava/lang/Class;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v2, 0x2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    aput-object p0, v2, v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/4 p0, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    aput-object p1, v2, p0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    sget-object p1, Lcom/tencent/android/tpush/b/a;->a:Ljava/lang/String;

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string/jumbo v1, "vk)smbho o:rer omht ie dwron"

    const-string/jumbo v1, "kromemhnse :i) d rower tohov"

    const/4 v5, 0x1

    const-string/jumbo v1, "rersw)uk( vrneh ootie :dho m"

    const-string/jumbo v1, "invoke method show() error: "

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    return-void
.end method
