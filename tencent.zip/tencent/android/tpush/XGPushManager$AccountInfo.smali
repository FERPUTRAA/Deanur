.class public Lcom/tencent/android/tpush/XGPushManager$AccountInfo;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/XGPushManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "AccountInfo"
.end annotation


# instance fields
.field public accountName:Ljava/lang/String;

.field public accountType:I


# direct methods
.method public constructor <init>(ILjava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/android/tpush/XGPushManager$AccountInfo;->accountType:I

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$AccountInfo;->accountName:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method
