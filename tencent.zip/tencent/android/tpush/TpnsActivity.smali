.class public Lcom/tencent/android/tpush/TpnsActivity;
.super Landroid/app/Activity;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20150316"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->ACTIVITYCHECK:Lcom/jg/EType;,
        .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;,
        .enum Lcom/jg/EType;->INTENTSCHEMECHECK:Lcom/jg/EType;
    }
.end annotation


# static fields
.field public static final CHECK_CODE:Ljava/lang/String; = "checkCode"

.field public static final CUSTOM_CONTENT:Ljava/lang/String; = "customContent"

.field public static final JUMP_type:Ljava/lang/String; = "jumpType"

.field public static final MSG_TYPE:Ljava/lang/String; = "msgType"

.field public static final TARGE_ACTIVITY:Ljava/lang/String; = "targetActivity"

.field public static final TIMESTAMP:Ljava/lang/String; = "timestamp"

.field static a:Landroid/app/Application$ActivityLifecycleCallbacks; = null

.field static b:Ljava/util/List; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field static c:Ljava/lang/String; = ""

.field static d:J

.field static e:J


# instance fields
.field private f:Ljava/lang/String;

.field private g:I

.field private h:Ljava/security/interfaces/RSAPublicKey;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v1, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/TpnsActivity;->f:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    const/16 v0, 0x64

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput v0, p0, Lcom/tencent/android/tpush/TpnsActivity;->g:I

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x1

    shr-int/2addr v1, v0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/TpnsActivity;->h:Ljava/security/interfaces/RSAPublicKey;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method private static a(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v2, "tMsanId.nc.Aatrnn.isoeiNti"

    const-string v2, "IdsAtrioaanctntonneM..i.Ni"

    const/4 v4, 0x3

    const-string v2, "icomie.A.n.ittNanatoMdnnrI"

    const-string v2, "android.intent.action.MAIN"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo v2, "teo.odinLCmatgrAHeinURtEraN..doy"

    const-string v2, "gtLmiUnrnnaCeAoeN.yr.a.RdtEdoiHt"

    const/4 v4, 0x1

    const-string v2, "iLtcrbradiyN.Ce.Ee.oRoAnUttdgHnn"

    const-string v2, "android.intent.category.LAUNCHER"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p0, v1, v2}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-eqz v1, :cond_1

    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast v1, Landroid/content/pm/ResolveInfo;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v1, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object p0, v1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v1, "tTcivtupisnA"

    const-string v1, "TpnsActivity"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo v2, "ttioAcrpro egve tr"

    const-string v2, "iAytortv cetoeg rr"

    const/4 v4, 0x2

    const-string/jumbo v2, "rt rvorgqtiiec tey"

    const-string v2, "get Activity error"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-object v0
.end method

.method private a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)V
    .locals 10

    const/4 v8, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    new-instance v7, Lcom/tencent/android/tpush/TpnsActivity$2;

    move-object v1, v7

    move-object v1, v7

    move-object v1, v7

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x0

    move v4, p3

    move v4, p3

    const/4 v9, 0x2

    move v4, p3

    move v4, p3

    move-object v5, p4

    move-object v5, p4

    move-object v5, p4

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct/range {v1 .. v6}, Lcom/tencent/android/tpush/TpnsActivity$2;-><init>(Lcom/tencent/android/tpush/TpnsActivity;Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    and-int/2addr v9, v8

    invoke-virtual {v0, v7}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    return-void
.end method

.method private a(Landroid/net/Uri;)V
    .locals 33

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    const-string v2, "ersdaIb"

    const-string/jumbo v2, "tdarIbe"

    const-string v2, "Icamtrd"

    const-string/jumbo v2, "traceId"

    const-string/jumbo v3, "tmuaoIdplt"

    const-string v3, "Ietmadulpt"

    const-string/jumbo v3, "latpmbetde"

    const-string/jumbo v3, "templateId"

    const-string/jumbo v4, "uceosu"

    const-string/jumbo v4, "upseoc"

    const-string/jumbo v4, "source"

    const-string/jumbo v5, "qiusThpp"

    const-string/jumbo v5, "qsTupeih"

    const-string/jumbo v5, "pushTime"

    const-string v6, "eastpTgytr"

    const-string/jumbo v6, "yttrgaeTqe"

    const-string/jumbo v6, "targetType"

    const-string v7, "ehsmChspnln"

    const-string/jumbo v7, "pnamlCsenhh"

    const-string/jumbo v7, "lahmpuhnCns"

    const-string/jumbo v7, "pushChannel"

    const-string/jumbo v8, "ogpdouo"

    const-string v8, "gpudoro"

    const-string/jumbo v8, "udoprbI"

    const-string v8, "groupId"

    const-string/jumbo v9, "isugMdusb"

    const-string/jumbo v9, "sduMsbgIi"

    const-string v9, "gdiMIsupb"

    const-string v9, "busiMsgId"

    const-string/jumbo v10, "npyuvitsqciT"

    const-string v10, "AticTpunvisy"

    const-string v10, "cysvtinpsitT"

    const-string v10, "TpnsActivity"

    const-string v11, "gdsmp"

    const-string v11, "Ispgd"

    const-string/jumbo v11, "mdgIo"

    const-string/jumbo v11, "msgId"

    :try_start_0
    const-string/jumbo v12, "jmeypbTp"

    const-string/jumbo v12, "qjmTppye"

    const-string v12, "Tjmpepuy"

    const-string/jumbo v12, "jumpType"

    invoke-virtual {v0, v12}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0, v9}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v0, v11}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string/jumbo v15, "pmTsgey"

    const-string v15, "Tgsmsye"

    const-string/jumbo v15, "sqemTyp"

    const-string/jumbo v15, "msgType"

    invoke-virtual {v0, v15}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    :try_start_1
    invoke-virtual {v0, v8}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    move-object/from16 v17, v12

    move-object/from16 v17, v12

    move-object/from16 v17, v12

    move-object/from16 v17, v12

    invoke-virtual {v0, v7}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    invoke-virtual {v0, v6}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    invoke-virtual {v0, v5}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v19, v3

    move-object/from16 v19, v3

    move-object/from16 v19, v3

    move-object/from16 v19, v3

    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v20, v4

    move-object/from16 v20, v4

    move-object/from16 v20, v4

    move-object/from16 v20, v4

    const-string/jumbo v4, "tmsimepma"

    const-string/jumbo v4, "paimmmset"

    const-string/jumbo v4, "mpemmisat"

    const-string/jumbo v4, "timestamp"

    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v21, v4

    move-object/from16 v21, v4

    move-object/from16 v21, v4

    move-object/from16 v21, v4

    const-string/jumbo v4, "ttoeonusctmCo"

    const-string/jumbo v4, "tesoouCnttomc"

    const-string v4, "customContent"

    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    const-string/jumbo v4, "vctiybrtatgitA"

    const-string/jumbo v4, "targetActivity"

    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v23, v4

    move-object/from16 v23, v4

    move-object/from16 v23, v4

    move-object/from16 v23, v4

    const-string/jumbo v4, "lpmt"

    const-string/jumbo v4, "lmtp"

    const-string/jumbo v4, "lmtp"

    const-string/jumbo v4, "tmpl"

    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v24, v4

    move-object/from16 v24, v4

    move-object/from16 v24, v4

    move-object/from16 v24, v4

    const-string v4, "eubar"

    const-string v4, "barte"

    const-string/jumbo v4, "tcpar"

    const-string/jumbo v4, "trace"

    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v4, Landroid/content/Intent;

    invoke-direct {v4}, Landroid/content/Intent;-><init>()V

    const-wide/16 v25, 0x0

    const-wide/16 v25, 0x0

    const-wide/16 v25, 0x0

    const-wide/16 v25, 0x0

    if-eqz v13, :cond_0

    invoke-static {v13}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v27

    invoke-virtual/range {v27 .. v27}, Ljava/lang/Long;->longValue()J

    move-result-wide v27

    move-wide/from16 v31, v27

    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-wide/from16 v2, v31

    goto :goto_0

    :cond_0
    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-wide/from16 v2, v25

    :goto_0
    invoke-virtual {v4, v9, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    if-eqz v14, :cond_1

    invoke-static {v14}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    goto :goto_1

    :cond_1
    move-wide/from16 v2, v25

    :goto_1
    invoke-virtual {v4, v11, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string/jumbo v2, "ptey"

    const-string/jumbo v2, "ytpe"

    const-string/jumbo v2, "ptey"

    const-string/jumbo v2, "type"

    if-eqz v15, :cond_2

    invoke-static {v15}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v29

    goto :goto_2

    :cond_2
    const-wide/16 v29, 0x1

    const-wide/16 v29, 0x1

    const-wide/16 v29, 0x1

    :goto_2
    move-object v3, v14

    move-object v3, v14

    move-object v3, v14

    move-object v3, v14

    move-object v9, v15

    move-object v9, v15

    move-object v9, v15

    move-object v9, v15

    move-wide/from16 v14, v29

    invoke-virtual {v4, v2, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {v4, v8, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x0

    if-eqz v12, :cond_3

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    goto :goto_3

    :cond_3
    move v8, v2

    move v8, v2

    move v8, v2

    move v8, v2

    :goto_3
    invoke-virtual {v4, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    if-eqz v1, :cond_4

    invoke-static {v1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    goto :goto_4

    :cond_4
    move-wide/from16 v7, v25

    :goto_4
    invoke-virtual {v4, v6, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    if-eqz v27, :cond_5

    invoke-static/range {v27 .. v27}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    mul-long/2addr v14, v6

    goto :goto_5

    :cond_5
    move-wide/from16 v14, v25

    :goto_5
    invoke-virtual {v4, v5, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    if-eqz v28, :cond_6

    invoke-static/range {v28 .. v28}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    move-object/from16 v5, v20

    move-object/from16 v5, v20

    move-object/from16 v5, v20

    move-object/from16 v5, v20

    goto :goto_6

    :cond_6
    move-object/from16 v5, v20

    move-object/from16 v5, v20

    move-object/from16 v5, v20

    move-object/from16 v5, v20

    move-wide/from16 v14, v25

    :goto_6
    invoke-virtual {v4, v5, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string/jumbo v5, "putsmtisqm"

    const-string/jumbo v5, "mmtptsusia"

    const-string/jumbo v5, "timestamps"

    if-eqz v21, :cond_7

    invoke-static/range {v21 .. v21}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    mul-long/2addr v14, v6

    goto :goto_7

    :cond_7
    move-wide/from16 v14, v25

    :goto_7
    invoke-virtual {v4, v5, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-object/from16 v6, v19

    move-object/from16 v6, v19

    move-object/from16 v6, v19

    move-object/from16 v6, v19

    move-object/from16 v5, v24

    move-object/from16 v5, v24

    move-object/from16 v5, v24

    move-object/from16 v5, v24

    invoke-virtual {v4, v6, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-object/from16 v7, v18

    move-object/from16 v7, v18

    move-object/from16 v7, v18

    move-object/from16 v7, v18

    invoke-virtual {v4, v7, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    :try_start_3
    invoke-direct {v1, v4}, Lcom/tencent/android/tpush/TpnsActivity;->d(Landroid/content/Intent;)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, " isgeeyI nmme Atir:sc iBdtsdsvuapcalpTprir"

    const-string/jumbo v14, "yscIevrpum p cmiiisBderd :TtAneltprgasa vi"

    const-string/jumbo v14, "imvmIia  s pcpvgBerc:iAatlsieyTsmdn rtrdu "

    const-string v14, "TpnsActivity receiver params : msgBuildId "

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v13, " d qo ,msg="

    const-string v13, ",d sm gIq ="

    const-string/jumbo v13, "m  dsb  ,=g"

    const-string v13, " , msgId = "

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v13, "puym,=us  e jT"

    const-string v13, " msT u p=ey ,j"

    const-string/jumbo v13, "j mup ype=,p T"

    const-string v13, " , jumpType = "

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v13, v17

    move-object/from16 v13, v17

    move-object/from16 v13, v17

    move-object/from16 v13, v17

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v14, "y gm m=eq,  p"

    const-string/jumbo v14, "p =mTm,eg  y "

    const-string/jumbo v14, "yms se  gpT=,"

    const-string v14, " , msgType = "

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, "Igpdo r=  , u"

    const-string/jumbo v9, "od m=rI, g  p"

    const-string v9, " , groupId = "

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, "h,leo b nuhCn as "

    const-string v9, " ,un ble h hnaCps"

    const-string v9, " a Chbh ulp,nn e="

    const-string v9, " , pushChannel = "

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v9, "ty=ugputT,e   ra"

    const-string v9, "=e pg uareT,ty t"

    const-string v9, "g etyt p ,=pre T"

    const-string v9, " , targetType = "

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "e= m ,ppqTuh s"

    const-string v8, " pT ,eup  h=ms"

    const-string/jumbo v8, "pssh=e  m T u,"

    const-string v8, " , pushTime = "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v8, v27

    move-object/from16 v8, v27

    move-object/from16 v8, v27

    move-object/from16 v8, v27

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "cq mor,ue  s"

    const-string v8, "c, s o uqr e"

    const-string v8, " c,uore=o   "

    const-string v8, " , source = "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v8, v28

    move-object/from16 v8, v28

    move-object/from16 v8, v28

    move-object/from16 v8, v28

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "et sibs  a,m p="

    const-string/jumbo v8, "pas ts  e,mi =t"

    const-string/jumbo v8, "t mma,ue=  p ts"

    const-string v8, " , timestamp = "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v8, v21

    move-object/from16 v8, v21

    move-object/from16 v8, v21

    move-object/from16 v8, v21

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, ",mdlea pmIt e=t "

    const-string/jumbo v8, "mtdm   et=,pelIa"

    const-string/jumbo v8, "peed, m qIl ta ="

    const-string v8, " , templateId = "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "aesI rd ct o "

    const-string v8, "  cdo, taeI r"

    const-string v8, " , traceId = "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    :try_start_4
    invoke-static {v8, v4}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v4, Landroid/content/Intent;

    const-string/jumbo v9, "nc..nbdoetaBp.icKntACeDgdrt.E.ocaniEx.Fvom"

    const-string v9, "avnmodiE.dtAFeKnBxEcin.ci.Doe.a.totr.Ccgpn"

    const-string v9, "com.tencent.android.xg.vip.action.FEEDBACK"

    invoke-direct {v4, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v9

    invoke-virtual {v9}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v9}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const-string v9, "CAuFoETUKHBS.E"

    const-string v9, "HTFEKAu.CBPUSE"

    const-string v9, "UTAE.bHBPEDKFS"

    const-string v9, "TPUSH.FEEDBACK"

    const/4 v10, 0x4

    invoke-virtual {v4, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v9, "S.PEROuURDHOpRE"

    const-string v9, "RREOSHEpRCPDUO."

    const-string v9, ".RPEOEOpRSRCUHT"

    const-string v9, "TPUSH.ERRORCODE"

    invoke-virtual {v4, v9, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v9, "HHqA.NNSqCPE"

    const-string v9, "NNEPS.CHqLHA"

    const-string v9, "H.sELUAHSNNP"

    const-string v9, "PUSH.CHANNEL"

    if-eqz v12, :cond_8

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    :cond_8
    invoke-virtual {v4, v9, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v2, "cnsmia"

    const-string/jumbo v2, "itsnca"

    const-string v2, "action"

    sget-object v9, Lcom/tencent/android/tpush/NotificationAction;->clicked:Lcom/tencent/android/tpush/NotificationAction;

    invoke-virtual {v9}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v9

    invoke-virtual {v4, v2, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v2, "niecoTtonmaftotnpyAoci"

    const-string/jumbo v2, "ntompyicfiionTnoacettA"

    const-string/jumbo v2, "iopnobiifTencttinycoAt"

    const-string/jumbo v2, "notificationActionType"

    if-eqz v13, :cond_9

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    goto :goto_8

    :cond_9
    sget-object v9, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    invoke-virtual {v9}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v9

    :goto_8
    invoke-virtual {v4, v2, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v2, "o_ontcunotmseu"

    const-string v2, "coston_onutcme"

    const-string/jumbo v2, "suocontptcmte_"

    const-string v2, "custom_content"

    move-object/from16 v9, v22

    move-object/from16 v9, v22

    move-object/from16 v9, v22

    move-object/from16 v9, v22

    invoke-virtual {v4, v2, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    if-eqz v3, :cond_a

    invoke-static {v3}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v25

    :cond_a
    move-wide/from16 v2, v25

    invoke-virtual {v4, v11, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {v4, v6, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v4, v7, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const-string/jumbo v0, "qiyitcva"

    const-string v0, "activity"

    if-eqz v23, :cond_b

    :try_start_5
    invoke-static/range {v23 .. v23}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_b

    move-object/from16 v2, v23

    move-object/from16 v2, v23

    move-object/from16 v2, v23

    move-object/from16 v2, v23

    invoke-virtual {v4, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_9

    :cond_b
    invoke-static/range {p0 .. p0}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v1, Lcom/tencent/android/tpush/TpnsActivity;->f:Ljava/lang/String;

    invoke-virtual {v4, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :goto_9
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v4}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    goto :goto_c

    :catchall_0
    move-exception v0

    goto :goto_b

    :catchall_1
    move-exception v0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    goto :goto_a

    :catchall_2
    move-exception v0

    :goto_a
    move-object/from16 v8, v16

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    goto :goto_b

    :catchall_3
    move-exception v0

    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    :goto_b
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "nxsplrerceyeDnepentLo:bhot eiaAtnTtOsrpevitikCchp "

    const-string v3, "epoxebTAvDoitLpatnhni hticstp: necnernkeCOeyplrtre"

    const-string v3, "DnamnoteiceeerrtpTetCinetpOe hx r:hnktLnypvcpoAiil"

    const-string v3, "TpnsActivity reportOtherChannelDeepLink exception:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v8, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :goto_c
    return-void
.end method

.method private a(Landroid/os/Bundle;Lcom/tencent/android/tpush/XGPushClickedResult;)V
    .locals 28

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    const-string/jumbo v3, "naepolCuhsn"

    const-string v3, "ehulapusCnn"

    const-string v3, "hslhnbaCeup"

    const-string/jumbo v3, "pushChannel"

    const-string/jumbo v4, "type"

    const-string/jumbo v4, "type"

    const-string/jumbo v5, "ucures"

    const-string/jumbo v5, "source"

    const-string v6, "Thmpeupp"

    const-string v6, "hmpeusTp"

    const-string/jumbo v6, "qpesTmiu"

    const-string/jumbo v6, "pushTime"

    const-string v7, "Mqsiusbds"

    const-string/jumbo v7, "ugiMssbdq"

    const-string/jumbo v7, "isdmbgMsu"

    const-string v7, "busiMsgId"

    const-string v8, "aeTtostryg"

    const-string v8, "aesgyprTtt"

    const-string/jumbo v8, "retepbaygT"

    const-string/jumbo v8, "targetType"

    const-string/jumbo v9, "udgIpmu"

    const-string v9, "Ipumdrg"

    const-string/jumbo v9, "pdgrIpu"

    const-string v9, "groupId"

    const-string v10, "eqItrda"

    const-string/jumbo v10, "traceId"

    const-string/jumbo v11, "testeoIlpd"

    const-string/jumbo v11, "ldemotItep"

    const-string v11, "atemptmlde"

    const-string/jumbo v11, "templateId"

    const-string/jumbo v12, "mgbso"

    const-string v12, "bmgIs"

    const-string v12, "bmIsg"

    const-string/jumbo v12, "msgId"

    :try_start_0
    invoke-virtual {v0, v9}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const-string/jumbo v14, "ts"

    const-string/jumbo v14, "ts"

    const-string/jumbo v14, "st"

    const-string/jumbo v14, "ts"

    invoke-virtual {v0, v14}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v0, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v0, v7}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    invoke-virtual {v0, v12}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    invoke-virtual {v0, v6}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    invoke-virtual {v0, v5}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    invoke-virtual {v0, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    invoke-virtual {v0, v3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual {v0, v11}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v10}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const-wide/16 v22, 0x0

    const-wide/16 v22, 0x0

    const-wide/16 v22, 0x0

    const-wide/16 v22, 0x0

    if-eqz v16, :cond_0

    sget-wide v24, Lcom/tencent/android/tpush/TpnsActivity;->e:J

    invoke-static/range {v24 .. v25}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/Long;->longValue()J

    move-result-wide v24

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-wide/from16 v26, v24

    move-object/from16 v24, v11

    move-object/from16 v24, v11

    move-wide/from16 v10, v26

    goto :goto_0

    :cond_0
    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v24, v11

    move-object/from16 v24, v11

    move-object/from16 v24, v11

    move-object/from16 v24, v11

    move-wide/from16 v10, v22

    :goto_0
    invoke-virtual {v1, v7, v10, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    if-eqz v17, :cond_1

    invoke-static/range {v17 .. v17}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    goto :goto_1

    :cond_1
    move-wide/from16 v10, v22

    :goto_1
    invoke-virtual {v1, v12, v10, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    if-eqz v20, :cond_2

    invoke-static/range {v20 .. v20}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    goto :goto_2

    :cond_2
    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    :goto_2
    invoke-virtual {v1, v4, v10, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {v1, v9, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v4, 0x65

    if-eqz v21, :cond_3

    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    goto :goto_3

    :cond_3
    move v7, v4

    move v7, v4

    move v7, v4

    move v7, v4

    :goto_3
    invoke-virtual {v1, v3, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    if-eqz v15, :cond_4

    invoke-static {v15}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v9

    goto :goto_4

    :cond_4
    move-wide/from16 v9, v22

    :goto_4
    invoke-virtual {v1, v8, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-wide/16 v7, 0x3e8

    const-wide/16 v7, 0x3e8

    const-wide/16 v7, 0x3e8

    const-wide/16 v7, 0x3e8

    if-eqz v18, :cond_5

    invoke-static/range {v18 .. v18}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v9

    mul-long/2addr v9, v7

    goto :goto_5

    :cond_5
    move-wide/from16 v9, v22

    :goto_5
    invoke-virtual {v1, v6, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    if-eqz v19, :cond_6

    invoke-static/range {v19 .. v19}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v9

    goto :goto_6

    :cond_6
    move-wide/from16 v9, v22

    :goto_6
    invoke-virtual {v1, v5, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string/jumbo v3, "smmattuise"

    const-string/jumbo v3, "ttimamusse"

    const-string/jumbo v3, "piaesmmpst"

    const-string/jumbo v3, "timestamps"

    if-eqz v14, :cond_7

    invoke-static {v14}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    mul-long/2addr v5, v7

    goto :goto_7

    :cond_7
    move-wide/from16 v5, v22

    :goto_7
    invoke-virtual {v1, v3, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-object/from16 v3, v24

    move-object/from16 v3, v24

    move-object/from16 v3, v24

    move-object/from16 v3, v24

    invoke-virtual {v1, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    invoke-virtual {v1, v5, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    :try_start_2
    invoke-direct {v1, v6}, Lcom/tencent/android/tpush/TpnsActivity;->d(Landroid/content/Intent;)V

    new-instance v6, Landroid/content/Intent;

    const-string v7, "Kao.nptnqmiDccaE.BFeconitpegx.oC.nivEdrd.."

    const-string/jumbo v7, "oavnnc.pAFrK.gnxicoDEpo.eiadB.inEt.et.cdCm"

    const-string/jumbo v7, "tAsg.tnC..diFK.tEDonpac.xiEBeoecrincvm.dao"

    const-string v7, "com.tencent.android.xg.vip.action.FEEDBACK"

    invoke-direct {v6, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const-string v7, "CEKmSqPBHFA.DU"

    const-string v7, "BKTDHSAUqE.PCF"

    const-string v7, "KEBSoDFCU.THAE"

    const-string v7, "TPUSH.FEEDBACK"

    const/4 v8, 0x4

    invoke-virtual {v6, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v7, "HDOEsbOT.RPECSR"

    const-string v7, "OSsOTRHEURE.DCP"

    const-string v7, "HERPUTuEOCSO.DR"

    const-string v7, "TPUSH.ERRORCODE"

    const/4 v8, 0x0

    invoke-virtual {v6, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v7, "PCHmHLASUN.N"

    const-string v7, "NCH.ASPpEHLN"

    const-string v7, "PUSH.CHANNEL"

    if-eqz v21, :cond_8

    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    :cond_8
    invoke-virtual {v6, v7, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v4, "tcqani"

    const-string/jumbo v4, "tacion"

    const-string/jumbo v4, "ocsnat"

    const-string v4, "action"

    sget-object v7, Lcom/tencent/android/tpush/NotificationAction;->clicked:Lcom/tencent/android/tpush/NotificationAction;

    invoke-virtual {v7}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v7

    invoke-virtual {v6, v4, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v4, "AoimninptTtyoabicntice"

    const-string v4, "ayeptbinitoifnicTAnotc"

    const-string/jumbo v4, "notificationActionType"

    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    iget v8, v2, Lcom/tencent/android/tpush/XGPushClickedResult;->notificationActionType:I

    if-eqz v8, :cond_9

    goto :goto_8

    :cond_9
    sget-object v8, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    invoke-virtual {v8}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v8

    :goto_8
    invoke-virtual {v6, v4, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v4, "nontoutmuoct_e"

    const-string v4, "_cnncmueoottut"

    const-string/jumbo v4, "ttnoubc_mtnseo"

    const-string v4, "custom_content"

    iget-object v8, v2, Lcom/tencent/android/tpush/XGPushClickedResult;->customContent:Ljava/lang/String;

    invoke-virtual {v6, v4, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    if-eqz v17, :cond_a

    invoke-static/range {v17 .. v17}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v22

    :cond_a
    move-wide/from16 v8, v22

    invoke-virtual {v6, v12, v8, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {v6, v3, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v6, v5, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object v0, v2, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const-string/jumbo v3, "ivtiptuc"

    const-string/jumbo v3, "yvictitp"

    const-string/jumbo v3, "ittivayp"

    const-string v3, "activity"

    if-eqz v0, :cond_b

    :try_start_3
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_b

    iget-object v0, v2, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    invoke-virtual {v6, v3, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_9

    :cond_b
    invoke-static/range {p0 .. p0}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Lcom/tencent/android/tpush/TpnsActivity;->f:Ljava/lang/String;

    invoke-virtual {v6, v3, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :goto_9
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v6}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_b

    :catchall_0
    move-exception v0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    goto :goto_a

    :catchall_1
    move-exception v0

    :goto_a
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "dFinkpnrqcLoabTann kthtpynelrvCeeqkpFcmDtseAe:ceiAe"

    const-string/jumbo v3, "npastpe q:FakcekpmnLCrTc ehDAeiiennbFtloAryendectvk"

    const-string/jumbo v3, "n syaoncleb psnteFpetADikicnLehCrierenkmT:pAkvdaFtc"

    const-string v3, "TpnsActivity reportAndFeekbackFcmChannelDeepLink e:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "Tssmptvntiyc"

    const-string/jumbo v2, "itsTpvytncAs"

    const-string/jumbo v2, "tcsioytinATp"

    const-string v2, "TpnsActivity"

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :goto_b
    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/TpnsActivity;Landroid/net/Uri;)V
    .locals 2

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/net/Uri;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/TpnsActivity;Landroid/os/Bundle;Lcom/tencent/android/tpush/XGPushClickedResult;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/os/Bundle;Lcom/tencent/android/tpush/XGPushClickedResult;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method private a(Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v4, 0x0

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/TpnsActivity;->f:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_1

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpush/TpnsActivity;->f:Ljava/lang/String;

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v2, " rA mbchAi iiatnteyyrTptv tttugnsejAtvrle  eCvvcipatm=hiyiOcirnee"

    const-string/jumbo v2, "tyvm prTinhrtsvtOpteAiAmaieyrtejgnvilithia yc teee=uC t vAtccrin "

    const/4 v5, 0x7

    const-string v2, "AuheA uttiev sycglTjn iyOvmtc Aaan =ivicrvtnieCrec riipeetytrpttt"

    const-string v2, "TpnsActivity receiver  jumpOtherChannelActivity targetActivity = "

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/TpnsActivity;->f:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v2, "iyAtipspnvtc"

    const-string v2, "TpnsActivity"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/TpnsActivity;->f:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/high16 v1, 0x24000000

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v1, "ohlushpCqnn"

    const-string/jumbo v1, "pChnonsheul"

    const/4 v5, 0x0

    const-string v1, "epsnuChhlas"

    const-string/jumbo v1, "pushChannel"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget v3, p0, Lcom/tencent/android/tpush/TpnsActivity;->g:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    if-nez v1, :cond_2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v1, "o_mmcncnobutte"

    const-string/jumbo v1, "osnembountcct_"

    const/4 v5, 0x6

    const-string/jumbo v1, "metcootostc_un"

    const-string v1, "custom_content"

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_2
    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-string v1, "NnctFbAcioptecTAoeeE tuuit i=iodryspx viv ncttyenv"

    const-string v1, "eyA  nun eosrocTrevtcnpi=yopttFAuiviv ExNdcctieitt"

    const/4 v5, 0x0

    const-string/jumbo v1, "yrpii uie oeA ot tonteuFTdAcnctinitse=cvvpxNtirEcy"

    const-string v1, "TpnsActivity receiver ActivityNotFoundException = "

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-void
.end method

.method private a(Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v0, "AviypnipttTs"

    const-string/jumbo v0, "ytnpsvipTtAi"

    const/4 v5, 0x3

    const-string v0, "TpnsActivity"

    :try_start_0
    const/4 v5, 0x1

    new-instance v1, Landroid/content/Intent;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v3, "htteyvhnqi ivsucrtyTteACjqietnp imiir=gAal ttceretvvOcycp ti anse "

    const-string v3, "iai t=mtqaAetnuvnthr OprhT  nrei gstveiirtieevccvej CttptAicscyyly"

    const/4 v5, 0x3

    const-string v3, "TpnsActivity receiver  jumpOtherChannelActivitys targetActivity = "

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v2, p1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo p1, "spsnCanhlsh"

    const-string/jumbo p1, "nCsnlsehhap"

    const/4 v5, 0x2

    const-string p1, "anhmeslupCn"

    const-string/jumbo p1, "pushChannel"

    const/4 v5, 0x5

    iget v2, p0, Lcom/tencent/android/tpush/TpnsActivity;->g:I

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    const/high16 p1, 0x24000000

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez p1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string/jumbo p1, "o_tuomtenocscm"

    const-string/jumbo p1, "mcnmetou_ttocs"

    const/4 v5, 0x4

    const-string/jumbo p1, "ocnsobcenttutm"

    const-string p1, "custom_content"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v1, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v1, "TiOveiuvyacArivtt mntsjupys e erinltAcn =ehCephctr"

    const-string v1, "TpnsActivity receiver jumpOtherChannelActivitys = "

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void
.end method

.method private a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 16

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    move-object/from16 v4, p3

    move-object/from16 v5, p4

    move-object/from16 v5, p4

    move-object/from16 v5, p4

    move-object/from16 v5, p4

    move-object/from16 v0, p6

    move-object/from16 v0, p6

    move-object/from16 v0, p6

    move-object/from16 v0, p6

    const-string/jumbo v6, "yoai nhpe:vlipspTd"

    const-string v6, "apdiol iynhupes:vT"

    const-string/jumbo v6, "invalid pushType: "

    const-string/jumbo v7, "ucscethdqeprmbyk"

    const-string v7, ":humkbtperccdsye"

    const-string v7, "cpsuyethmkc:seCr"

    const-string v7, "decryptChecksum:"

    const-string/jumbo v8, "musmkhuul  elawsn"

    const-string/jumbo v8, "s aewhuunsckmlul "

    const-string/jumbo v8, "necuowssk ucll ma"

    const-string v8, "checksum was null"

    const-string v9, ""

    const-string v9, ""

    const-string v9, ""

    const-string v9, ""

    const-string/jumbo v10, "nysvpbiTicAp"

    const-string v10, "cysivnAppiTt"

    const-string/jumbo v10, "vcitnputTysi"

    const-string v10, "TpnsActivity"

    const/4 v11, 0x0

    :try_start_0
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v13, "qpdgms"

    const-string/jumbo v13, "msqgd:"

    const-string/jumbo v13, "msgid:"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v13, "esshhn:uqlnp"

    const-string v13, "anseplhush:n"

    const-string v13, "husnp:Cnlsah"

    const-string/jumbo v13, "pushChannel:"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v13, "tuem:mjpy"

    const-string v13, "eupmptj:y"

    const-string/jumbo v13, "mepuoptjy"

    const-string/jumbo v13, "jumptype:"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v13, "etoagbt"

    const-string v13, "gttroea"

    const-string v13, "egtrt:u"

    const-string/jumbo v13, "target:"

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v13, p5

    move-object/from16 v13, p5

    move-object/from16 v13, p5

    move-object/from16 v13, p5

    invoke-virtual {v12, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, "cum:ebkps"

    const-string/jumbo v14, "u:ckhbmes"

    const-string v14, "checksum:"

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v10, v12}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static/range {p6 .. p6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v12

    if-eqz v12, :cond_0

    invoke-static {v10, v8}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v0, -0x4b1

    invoke-direct {v1, v2, v3, v0, v8}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)V

    return v11

    :cond_0
    invoke-static/range {p2 .. p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    if-eqz v8, :cond_1

    const-string/jumbo v0, "mlswdgauq l sn"

    const-string/jumbo v0, "iml wsua dgnsl"

    const-string/jumbo v0, "las sulmnwdi g"

    const-string/jumbo v0, "msgid was null"

    invoke-static {v10, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    return v11

    :cond_1
    iget-object v8, v1, Lcom/tencent/android/tpush/TpnsActivity;->h:Ljava/security/interfaces/RSAPublicKey;

    if-nez v8, :cond_2

    const-string v8, "XQPmf1KAriwrA=wuDYICAn1HoBJOVXVEvwus/ZhYDAKwm+aQJgMwaQ9Jk8StIyb1SlANH4XZJBbWpeZB4YAVDOAEHMe0J4SVQcNw=FYxwQ6p2rWO8wSSoezFKgvAPAr3"

    const-string/jumbo v8, "pYuBrwwpwMDBFZ+=e0H1vYrwcCu3bS8O/FwEmAV6nNSOPAzlHiEJaASVeKYWPE4B=ZAJDA1V8gQKJawIAMyOH1AeI4QQfQAZN4rDSoJJhV9SowWtQKvXrXbxkXAwYs2g"

    const-string v8, "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAMw0HSS1vXYrOeuXPEIKiJpe4xY9flsHmWb21O34FZVBwXnrKtDWgPQY+uV48ZJ6bVzaySwNrAa/eJo1HrOgVk8CAwEAAQ=="

    invoke-static {v8}, Lcom/tencent/android/tpush/service/channel/security/d;->a(Ljava/lang/String;)Ljava/security/interfaces/RSAPublicKey;

    move-result-object v8

    iput-object v8, v1, Lcom/tencent/android/tpush/TpnsActivity;->h:Ljava/security/interfaces/RSAPublicKey;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    const/16 v8, -0x4b2

    :try_start_1
    invoke-static {v0, v11}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v0

    iget-object v12, v1, Lcom/tencent/android/tpush/TpnsActivity;->h:Ljava/security/interfaces/RSAPublicKey;

    invoke-static {v0, v12}, Lcom/tencent/android/tpush/service/channel/security/d;->a([BLjava/security/interfaces/RSAPublicKey;)Ljava/lang/String;

    move-result-object v0
    :try_end_1
    .catch Ljava/lang/Exception; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catch_0
    move-exception v0

    :try_start_2
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v14, "qthpoilereVdiaRudl kyeedqcrcraee,:t s "

    const-string/jumbo v14, "rekdcliuqaaeerdyiehcerdteqR:f p  ,tlVs"

    const-string v14, ": lpfbdchkricyseucr eqdaeereaVi,tlt de"

    const-string v14, "checkValidRequest decrypt failed, err:"

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v10, v12}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, "eisshcudu mlp cdykfCetr"

    const-string/jumbo v14, "tds dccferCyuekshmplei "

    const-string/jumbo v14, "rCaciu pkyestcpd medfhl"

    const-string v14, "decryptChecksum failed "

    invoke-virtual {v12, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-direct {v1, v2, v3, v8, v0}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)V

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    move-object v0, v9

    :goto_0
    new-instance v12, Ljava/lang/StringBuilder;

    invoke-direct {v12}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v12, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v12}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v12

    invoke-static {v10, v12}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const-string/jumbo v12, "mtknheuuqlaCdemwps ysclc"

    const-string/jumbo v12, "lClmtknuuemchdssacypw e "

    const-string v12, "d selstam hyunluserCkwcp"

    const-string v12, "decryptChecksum was null"

    if-eqz v0, :cond_a

    :try_start_3
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v14

    if-eqz v14, :cond_3

    goto/16 :goto_4

    :cond_3
    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v14

    add-int/lit8 v15, v14, -0x1

    invoke-virtual {v0, v15, v14}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v14

    invoke-static {v14}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v14

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v11, "pTu:oepsy"

    const-string/jumbo v11, "uepmy:hsT"

    const-string/jumbo v11, "pushType:"

    invoke-virtual {v8, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v10, v8}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v11, 0x1

    if-ne v14, v11, :cond_4

    invoke-static/range {p1 .. p1}, Lcom/tencent/android/tpush/XGPushConfig;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    goto :goto_1

    :cond_4
    if-ne v14, v8, :cond_9

    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    :goto_1
    invoke-static/range {p5 .. p5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v14

    if-eqz v14, :cond_5

    goto :goto_2

    :cond_5
    move-object v9, v13

    move-object v9, v13

    move-object v9, v13

    move-object v9, v13

    :goto_2
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v13

    if-nez v13, :cond_8

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v13

    if-ge v13, v8, :cond_6

    goto :goto_3

    :cond_6
    const/4 v8, 0x0

    invoke-virtual {v0, v8, v15}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v0

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "b,dtor S5:"

    const-string v6, ",5 :tbSr d"

    const-string v6, " r:,db5tmS"

    const-string v6, " , md5Str:"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v10, v5}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0, v4}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_7

    return v11

    :cond_7
    const-string v0, "c psyeukrmcuiuaeawlhCvdntd "

    const-string v0, "dyeus urmcnw tleCpiaihcdkav"

    const-string v0, "Cwdsuhtpicelv iysedapckm nr"

    const-string v0, "decryptChecksum was invalid"

    invoke-static {v10, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "etiyuspcqsemmmrthdckcCpa"

    const-string/jumbo v0, "rmmhCaspdyutmkchpceicest"

    const-string v0, "Custierycsekasmmchptmc h"

    const-string v0, "decryptChecksum mismatch"

    const/16 v4, -0x4b3

    invoke-direct {v1, v2, v3, v4, v0}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)V

    goto/16 :goto_5

    :cond_8
    :goto_3
    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "cq mmkdshnawyaive:esltCduic "

    const-string/jumbo v5, "ni:wCstrqeldac mikedusvcyh a"

    const-string v5, "decryptChecksum was invalid:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v10, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v4, -0x4b2

    invoke-direct {v1, v2, v3, v4, v12}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)V

    const/4 v2, 0x0

    return v2

    :cond_9
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v10, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/16 v4, -0x4b4

    invoke-direct {v1, v2, v3, v4, v0}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)V

    const/4 v2, 0x0

    return v2

    :cond_a
    :goto_4
    invoke-static {v10, v12}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v2, 0x0

    return v2

    :catchall_0
    move-exception v0

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "tes l,Viheaedskcduf:rlraRecq e"

    const-string v5, "eit oeaddVf:keceeuhil,Rl rcaqs"

    const-string v5, "checkValidRequest failed, err:"

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    invoke-static {v10, v4}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, "cop sbhhreeukmC mt:ordytecr e"

    const-string/jumbo v5, "rremdthepmycehr uo kCesrc:t o"

    const-string v5, " ckyrsuhteoeCrpre:hrrectmod u"

    const-string v5, "decryptChecksum other error: "

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/16 v4, -0x4b9

    invoke-direct {v1, v2, v3, v4, v0}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)V

    :goto_5
    const/4 v2, 0x0

    return v2
.end method

.method private a(Landroid/content/Intent;)Z
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v0, 0x0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-eqz p1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo v1, "preocop"

    const-string v1, "cpteoro"

    const/4 v6, 0x2

    const-string/jumbo v1, "protect"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p1, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    if-eqz v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-nez v1, :cond_0

    const/4 v5, 0x6

    shl-int/2addr v6, v5

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {p1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    cmp-long v1, v1, v3

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-lez v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x3

    cmp-long p1, v1, v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-ltz p1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v0, 0x1

    :catch_0
    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    return v0
.end method

.method public static addActivityNames(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/TpnsActivity;->b:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    sput-object v0, Lcom/tencent/android/tpush/TpnsActivity;->b:Ljava/util/List;

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/TpnsActivity;->b:Ljava/util/List;

    const/4 v2, 0x6

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-nez v0, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/android/tpush/TpnsActivity;->b:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    return-void
.end method

.method private b(Landroid/content/Intent;)V
    .locals 14

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v0

    if-nez v0, :cond_0

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_0
    const-string/jumbo v1, "okchdeCeq"

    const-string v1, "deCckboeh"

    const-string/jumbo v1, "ohsdCecec"

    const-string v1, "checkCode"

    invoke-virtual {p1, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v2, "dImmu"

    const-string v2, "dusIm"

    const-string v2, "Imgdo"

    const-string/jumbo v2, "msgId"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const-string v2, "c"

    const-string v2, "c"

    const-string v2, "c"

    const-string v2, "c"

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v5}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    if-eqz p1, :cond_7

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    if-eqz p1, :cond_7

    const-string/jumbo p1, "pteonbt"

    const-string/jumbo p1, "ptncoet"

    const-string/jumbo p1, "tcetnnu"

    const-string p1, "content"

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "cnitafteqpLhkfDnnfanCm/cel eueo 1"

    const-string v2, "1oena tp/keheDnmecCftfnfnpin lacu"

    const-string v2, "fcmChannelDeepLink content \uff1a"

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string/jumbo v2, "yAtivsnsqpti"

    const-string/jumbo v2, "iysTnApvstit"

    const-string/jumbo v2, "vAsitpnsticT"

    const-string v2, "TpnsActivity"

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz p1, :cond_8

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_8

    :try_start_0
    new-instance v1, Lorg/json/JSONObject;

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string/jumbo p1, "nacmio"

    const-string p1, "icomtn"

    const-string p1, "action"

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    const-string/jumbo v3, "to_aoctponi"

    const-string v3, "aotpo_nyict"

    const-string/jumbo v3, "ypa_cbteoin"

    const-string v3, "action_type"

    const/4 v4, 0x0

    invoke-virtual {p1, v3, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v10

    const-string v3, "ibtvatuc"

    const-string/jumbo v3, "ivcitbta"

    const-string/jumbo v3, "ittyavip"

    const-string v3, "activity"

    invoke-virtual {p1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string/jumbo v3, "sqrerow"

    const-string v3, "browser"

    invoke-virtual {p1, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3

    const-string/jumbo v4, "lur"

    const-string/jumbo v4, "url"

    const-string/jumbo v4, "ulr"

    const-string/jumbo v4, "url"

    invoke-virtual {v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string/jumbo v3, "nesttu"

    const-string/jumbo v3, "untnet"

    const-string/jumbo v3, "ntemti"

    const-string/jumbo v3, "intent"

    invoke-virtual {p1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string/jumbo v3, "octtomsotnpecn"

    const-string/jumbo v3, "snttotcpo_nmec"

    const-string v3, "cnoctbmt_utnso"

    const-string v3, "custom_content"

    invoke-virtual {v1, v3}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    new-instance v13, Lcom/tencent/android/tpush/XGPushClickedResult;

    invoke-direct {v13}, Lcom/tencent/android/tpush/XGPushClickedResult;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    if-eq v10, v3, :cond_4

    const/4 v6, 0x2

    if-eq v10, v6, :cond_3

    const/4 v6, 0x3

    if-eq v10, v6, :cond_2

    const/4 v6, 0x5

    if-eq v10, v6, :cond_1

    goto/16 :goto_0

    :cond_1
    :try_start_1
    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_6

    iput-object p1, v13, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v6

    const-string v7, "011"

    const-string v7, "101"

    const-string v7, "101"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v4, v6

    move-object v4, v6

    move-object v4, v6

    move-object v4, v6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v7, v8

    move-object v7, v8

    move-object v7, v8

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    invoke-direct/range {v3 .. v9}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_6

    invoke-direct {p0, p1, v1}, Lcom/tencent/android/tpush/TpnsActivity;->c(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_2
    if-eqz p1, :cond_6

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_6

    iput-object p1, v13, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v6

    const-string v7, "011"

    const-string v7, "110"

    const-string v7, "101"

    const-string v7, "101"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v4, v6

    move-object v4, v6

    move-object v4, v6

    move-object v4, v6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v7, v8

    move-object v7, v8

    move-object v7, v8

    move-object v7, v8

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    move-object v8, p1

    invoke-direct/range {v3 .. v9}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_6

    invoke-direct {p0, p1, v1}, Lcom/tencent/android/tpush/TpnsActivity;->b(Ljava/lang/String;Ljava/lang/String;)V

    goto/16 :goto_0

    :cond_3
    if-eqz v12, :cond_6

    invoke-static {v12}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_6

    iput-object v12, v13, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const-string v6, "101"

    const-string v6, "101"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v8, v12

    move-object v8, v12

    move-object v8, v12

    move-object v8, v12

    invoke-direct/range {v3 .. v9}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_6

    invoke-direct {p0, v12}, Lcom/tencent/android/tpush/TpnsActivity;->b(Ljava/lang/String;)V

    goto :goto_0

    :cond_4
    if-eqz v11, :cond_5

    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    if-nez p1, :cond_5

    iput-object v11, v13, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const-string v6, "011"

    const-string v6, "011"

    const-string v6, "101"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v8, v11

    move-object v8, v11

    move-object v8, v11

    move-object v8, v11

    invoke-direct/range {v3 .. v9}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_6

    invoke-direct {p0, v11, v1}, Lcom/tencent/android/tpush/TpnsActivity;->a(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_0

    :cond_5
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const-string v6, "110"

    const-string v6, "011"

    const-string v6, "101"

    const-string v6, "101"

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const-string v8, ""

    const-string v8, ""

    const-string v8, ""

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    invoke-direct/range {v3 .. v9}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v3

    if-eqz v3, :cond_6

    iput-object v11, v13, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/TpnsActivity;->a(Ljava/lang/String;)V

    :cond_6
    :goto_0
    iput v10, v13, Lcom/tencent/android/tpush/XGPushClickedResult;->notificationActionType:I

    iput-object v1, v13, Lcom/tencent/android/tpush/XGPushClickedResult;->customContent:Ljava/lang/String;

    if-eqz v3, :cond_8

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p1

    new-instance v1, Lcom/tencent/android/tpush/TpnsActivity$1;

    invoke-direct {v1, p0, v0, v13}, Lcom/tencent/android/tpush/TpnsActivity$1;-><init>(Lcom/tencent/android/tpush/TpnsActivity;Landroid/os/Bundle;Lcom/tencent/android/tpush/XGPushClickedResult;)V

    invoke-virtual {p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_1

    :catchall_0
    move-exception p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "htpiasuAivk:lnnm LDeeynipCenTqcetc"

    const-string v1, "AmspieekqCn:plttyDnLiinTveh aenfcc"

    const-string v1, "cpiceampLnnetekTDi ylthn Cisf:Avpe"

    const-string v1, "TpnsActivity fcmChannelDeepLink e:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1

    :cond_7
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_8
    :goto_1
    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    return-void
.end method

.method private b(Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo v0, "viytAtnTqpci"

    const-string v0, "TpnsActivity"

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo v2, "visiA e:thenUc ihlCtOvelpi acyrrmrtAcjee prentsnarytttgsTv"

    const-string/jumbo v2, "lvscmT:acpehnhrAtrrpviyCUtAa ivnit etielegtteeruy jsO crnt"

    const/4 v4, 0x1

    const-string v2, "TpnsActivity receiver jumpOtherChannelUrl targetActivity :"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    or-int/2addr v4, v3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string v2, "Indmoto.WrdEtianiiVeanntc."

    const-string v2, "android.intent.action.VIEW"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v1, v2, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/high16 p1, 0x10000000

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string p1, "Clamopnneuh"

    const-string/jumbo p1, "nslmnuhaeCp"

    const/4 v4, 0x2

    const-string p1, "Chsnpbunhea"

    const-string/jumbo p1, "pushChannel"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget v2, p0, Lcom/tencent/android/tpush/TpnsActivity;->g:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v1, "nrolUeur ooepr"

    const-string/jumbo v1, "lepeoUro nrorr"

    const/4 v4, 0x5

    const-string/jumbo v1, "r.Ulproprn oer"

    const-string/jumbo v1, "openUrl error."

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x7

    return-void
.end method

.method private b(Ljava/lang/String;Ljava/lang/String;)V
    .locals 11

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    const-string/jumbo v0, "tbvTcisyqtpA"

    const-string v0, "cTtipbstAnvy"

    const/4 v10, 0x1

    const-string/jumbo v0, "syscvniittAp"

    const-string v0, "TpnsActivity"

    :try_start_0
    const/4 v10, 0x7

    const/4 v9, 0x1

    new-instance v1, Landroid/content/Intent;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-string/jumbo v3, "sytmy nueett:ApeievmAajv nth CceiTntanrhlriintcreciOrtepIvtu"

    const-string v3, "aeevnvuetlri htAn:mc Instrcjrtte vtepihyetTiCnptOarinuyteicA"

    const/4 v10, 0x3

    const-string/jumbo v3, "rTeeoetvptnyh teacniiIlntjyctecapOu:iiiAetrrAsrmte hvgntnt v"

    const-string v3, "TpnsActivity receiver jumpOtherChannelIntent targetActivity:"

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x5

    const/4 v9, 0x0

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    const-string v2, "dandcteponotten.n.rtin"

    const/4 v10, 0x1

    const-string/jumbo v2, "roncebtn.dto.ninanIdtt"

    const-string v2, "android.content.Intent"

    const/4 v10, 0x3

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x7

    const-string v3, "=cqcmGucy2FV"

    const-string v3, "V=FycccmqGV2"

    const/4 v10, 0x5

    const-string v3, "cGFyc2VVcmk="

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    new-instance v4, Ljava/lang/String;

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x3

    const/4 v5, 0x0

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {v3, v5}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-string/jumbo v6, "sFpU-"

    const-string v6, "U-s8F"

    const/4 v10, 0x6

    const-string v6, "TF8qU"

    const-string v6, "UTF-8"

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-direct {v4, v3, v6}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/4 v3, 0x2

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x7

    new-array v6, v3, [Ljava/lang/Class;

    const/4 v10, 0x7

    const-class v7, Ljava/lang/String;

    const-class v7, Ljava/lang/String;

    const-class v7, Ljava/lang/String;

    const-class v7, Ljava/lang/String;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    aput-object v7, v6, v5

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    sget-object v7, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x2

    const/4 v8, 0x1

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x6

    aput-object v7, v6, v8

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v2, v4, v6}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v10, 0x0

    const/4 v9, 0x5

    aput-object p1, v3, v5

    const/4 v10, 0x1

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x4

    aput-object p1, v3, v8

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v4, v2, v3}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    if-eqz p1, :cond_0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    check-cast v1, Landroid/content/Intent;

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x6

    const-string p1, "icstaid.nndrmt.WVI.ianEoot"

    const-string/jumbo p1, "itnma.dVEidtnirecoo.an.IWt"

    const/4 v10, 0x2

    const-string p1, "android.intent.action.VIEW"

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x2

    const-string p1, "eahsouphnCl"

    const/4 v10, 0x7

    const-string/jumbo p1, "nlsmehuhnap"

    const-string/jumbo p1, "pushChannel"

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget v2, p0, Lcom/tencent/android/tpush/TpnsActivity;->g:I

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    invoke-virtual {v1, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v10, 0x3

    const/4 v9, 0x2

    if-nez p1, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-string/jumbo p1, "snttotuenmo_cc"

    const-string p1, "custom_content"

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v1, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_1
    const/4 v9, 0x5

    move v10, v9

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const/4 v10, 0x6

    const/4 v9, 0x1

    invoke-virtual {v1, p1}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    if-eqz p1, :cond_2

    const/4 v10, 0x6

    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x2

    const-string p2, "e hjCbpnIhutlnertboarnOmr.nrt"

    const-string/jumbo p2, "neorrbeOmejC.nnnrrtuttalIhp h"

    const/4 v10, 0x7

    const-string p2, "enoCehunetrhmenIrnr.rl tjatup"

    const-string/jumbo p2, "jumpOtherChannelIntent error."

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    invoke-static {v0, p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_2
    :goto_0
    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    return-void
.end method

.method private c(Landroid/content/Intent;)V
    .locals 14

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v13, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x4

    const-string/jumbo v1, "itytisucnAvp"

    const/4 v13, 0x3

    const-string/jumbo v1, "npcAvtipiysT"

    const-string v1, "TpnsActivity"

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x0

    if-eqz p1, :cond_8

    :try_start_0
    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x0

    if-eqz p1, :cond_8

    const/4 v13, 0x6

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x6

    const-string v4, " ituihAeqelksyDvtci lpeLncearehnipTrtnnr:eeo vr"

    const-string v4, "TpnsActivity receiver otherChannelDeepLink url:"

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x5

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x7

    const-string/jumbo v2, "sgspm"

    const-string/jumbo v2, "mspgd"

    const/4 v13, 0x4

    const-string v2, "dmsmg"

    const-string/jumbo v2, "msgId"

    const/4 v13, 0x3

    const/4 v12, 0x4

    invoke-virtual {p1, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x3

    const-string v2, "dCqcoehkc"

    const-string v2, "chkeedCcq"

    const/4 v13, 0x4

    const-string v2, "eokchbeCc"

    const-string v2, "checkCode"

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x6

    invoke-virtual {p1, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x6

    const-string/jumbo v3, "npsushuCnhe"

    const-string/jumbo v3, "pasunhnChse"

    const-string/jumbo v3, "upehsClphan"

    const-string/jumbo v3, "pushChannel"

    const/4 v12, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x6

    invoke-virtual {p1, v3}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x2

    const-string v4, "c"

    const-string v4, "c"

    const/4 v13, 0x7

    const-string v4, "c"

    const-string v4, "c"

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x1

    invoke-virtual {p1, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x6

    const/4 v12, 0x1

    const-string/jumbo v4, "sCntnmcoqtmou"

    const-string/jumbo v4, "oommcnnCsttue"

    const/4 v13, 0x0

    const-string/jumbo v4, "nnsceotmutCts"

    const-string v4, "customContent"

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x6

    invoke-virtual {p1, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x2

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x4

    if-nez v4, :cond_0

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x4

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x3

    iput v3, p0, Lcom/tencent/android/tpush/TpnsActivity;->g:I

    :cond_0
    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x0

    if-eqz v5, :cond_8

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x3

    if-nez v3, :cond_8

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x0

    if-eqz v2, :cond_8

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x7

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x2

    if-nez v2, :cond_8

    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-static {v5}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x7

    const-string/jumbo v2, "opTmmuey"

    const-string/jumbo v2, "mueTojyp"

    const/4 v13, 0x0

    const-string/jumbo v2, "pejTomup"

    const-string/jumbo v2, "jumpType"

    const/4 v13, 0x5

    const/4 v12, 0x7

    invoke-virtual {p1, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x4

    const-string/jumbo v3, "yttrtbivaegtAi"

    const-string v3, "etiAibtatgrvty"

    const/4 v13, 0x3

    const-string/jumbo v3, "tytrgcueAivtta"

    const-string/jumbo v3, "targetActivity"

    const/4 v12, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-virtual {p1, v3}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v4

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x6

    iget v6, p0, Lcom/tencent/android/tpush/TpnsActivity;->g:I

    const/4 v13, 0x0

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x5

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x7

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x3

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v8, v11

    move-object v8, v11

    move-object v8, v11

    move-object v8, v11

    const/4 v13, 0x0

    const/4 v12, 0x4

    invoke-direct/range {v3 .. v9}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x5

    if-eqz v0, :cond_7

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x6

    if-eqz v2, :cond_5

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x7

    if-eqz v11, :cond_5

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x3

    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x4

    if-eqz v0, :cond_1

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x6

    goto/16 :goto_0

    :cond_1
    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x7

    invoke-virtual {v11}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x2

    if-lez v0, :cond_6

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x0

    const-string v0, "0"

    const-string v0, "0"

    const/4 v13, 0x7

    const-string v0, "0"

    const/4 v12, 0x7

    const/4 v13, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x0

    if-eqz v0, :cond_2

    const/4 v12, 0x7

    move v13, v12

    invoke-direct {p0, v10}, Lcom/tencent/android/tpush/TpnsActivity;->a(Ljava/lang/String;)V

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x3

    goto :goto_1

    :cond_2
    const/4 v13, 0x1

    const-string v0, "1"

    const-string v0, "1"

    const/4 v13, 0x4

    const-string v0, "1"

    const-string v0, "1"

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x6

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x4

    if-eqz v0, :cond_3

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-direct {p0, v11, v10}, Lcom/tencent/android/tpush/TpnsActivity;->a(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x5

    goto :goto_1

    :cond_3
    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x2

    const-string v0, "2"

    const-string v0, "2"

    const/4 v13, 0x0

    const-string v0, "2"

    const-string v0, "2"

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v13, 0x6

    const/4 v12, 0x0

    if-eqz v0, :cond_4

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x7

    invoke-direct {p0, v11}, Lcom/tencent/android/tpush/TpnsActivity;->b(Ljava/lang/String;)V

    const/4 v12, 0x4

    or-int/2addr v13, v12

    goto :goto_1

    :cond_4
    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x5

    const-string v0, "3"

    const-string v0, "3"

    const/4 v13, 0x0

    const-string v0, "3"

    const-string v0, "3"

    const/4 v13, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v13, 0x7

    if-eqz v0, :cond_6

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x4

    invoke-direct {p0, v11, v10}, Lcom/tencent/android/tpush/TpnsActivity;->b(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x4

    const/4 v12, 0x7

    goto :goto_1

    :cond_5
    :goto_0
    const/4 v13, 0x3

    const/4 v12, 0x0

    const-string v0, " epvulut e vtatptAI|Tuli==c  rles =tunn=Tnjncrlieytn|e gymrpei"

    const/4 v13, 0x5

    const-string/jumbo v0, "tin IAnpceep=|pT l sjaeeyeuig tnc vm= lr|r=yeunv t titrpTl=lun"

    const-string v0, "TpnsActivity receiver jumpType == null || targetIntent == null"

    const/4 v13, 0x2

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x7

    invoke-direct {p0, v10}, Lcom/tencent/android/tpush/TpnsActivity;->a(Ljava/lang/String;)V

    :cond_6
    :goto_1
    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x7

    new-instance v2, Lcom/tencent/android/tpush/TpnsActivity$3;

    const/4 v13, 0x2

    const/4 v12, 0x1

    const/4 v13, 0x6

    invoke-direct {v2, p0, p1}, Lcom/tencent/android/tpush/TpnsActivity$3;-><init>(Lcom/tencent/android/tpush/TpnsActivity;Landroid/net/Uri;)V

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x6

    invoke-virtual {v0, v2}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x7

    goto :goto_2

    :cond_7
    const/4 v13, 0x1

    const/4 v12, 0x4

    const-string/jumbo p1, "ueleea eqtVhpacsdqkRfcii"

    const-string p1, " VlkdcepiaehtRuqsafieedc"

    const/4 v13, 0x3

    const-string p1, "aes edlVqidctkauhliesfec"

    const-string p1, "checkValidRequest failed"

    const/4 v13, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x3

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_8
    :goto_2
    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x4

    goto :goto_3

    :catchall_0
    move-exception p1

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x4

    const-string/jumbo v2, "nAemytcqptvr vriis eee:c"

    const-string/jumbo v2, "ivsceircq:Ateerip eytnv "

    const/4 v13, 0x6

    const-string/jumbo v2, "v:Aioperyi r evcteietcns"

    const-string v2, "TpnsActivity receiver e:"

    const/4 v13, 0x3

    const/4 v12, 0x3

    const/4 v13, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    shl-int/2addr v13, v12

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x7

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :goto_3
    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x2

    return-void
.end method

.method private c(Ljava/lang/String;Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v0, "stnvibpytcsT"

    const-string/jumbo v0, "pTstnycsAitv"

    const/4 v5, 0x2

    const-string/jumbo v0, "ipcnttusvyAi"

    const-string v0, "TpnsActivity"

    :try_start_0
    new-instance v1, Landroid/content/Intent;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v3, "jpeivctpTecrcntrmnrnAttn:ovl mrgeahiscvihi etIitAnatOtynynte ituICrApee"

    const-string v3, "entmOaanCAlopgcieiru nttyr invycvcTmjvt niIteiI:tetAtpetnrAenehnthsicrr"

    const/4 v5, 0x1

    const-string/jumbo v3, "rCnuOeTiqeArjiyrt:reiverimvttIeA  onatcetyacniitplntceIthpvA hnnsntnegt"

    const-string v3, "InnerTpnsActivity receiver jumpOtherChannelIntentAction targetActivity:"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/high16 p1, 0x10000000

    const/4 v5, 0x5

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-nez p1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo p1, "ntstou_mccnsoo"

    const-string p1, "conuocntetm_so"

    const/4 v5, 0x2

    const-string p1, "_otmsnomcetunt"

    const-string p1, "custom_content"

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v1, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1, p1}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eqz p1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string p2, "hochortj aOAtr tpCnotnbenrnmnIuli:ee"

    const-string p2, "e t ubenArojipnmCotIntne:anteOchrhlr"

    const/4 v5, 0x5

    const-string/jumbo p2, "jAeorbne cr:nraetttiCmtphnronIeOun l"

    const-string/jumbo p2, "jumpOtherChannelIntentAction error: "

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0, p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-void
.end method

.method private d(Landroid/content/Intent;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method

.method public static getMsgIdWithIntent(Landroid/content/Intent;)J
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-nez p0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x7

    return-wide v0

    :cond_0
    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x0

    const/4 v6, 0x0

    const-string v3, "Iudgs"

    const-string v3, "Iusgd"

    const/4 v7, 0x2

    const-string v3, "dIpmg"

    const-string/jumbo v3, "msgId"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v2, :cond_2

    :try_start_1
    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eqz v2, :cond_2

    const/4 v6, 0x6

    xor-int/2addr v7, v6

    instance-of v4, v2, Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-eqz v4, :cond_1

    const/4 v6, 0x3

    move v7, v6

    check-cast v2, Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    instance-of v4, v2, Ljava/lang/Long;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v4, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    check-cast v2, Ljava/lang/Long;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto :goto_0

    :cond_2
    move-wide v4, v0

    :goto_0
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    cmp-long v2, v4, v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-nez v2, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz p0, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {p0, v3}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-nez v2, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    return-wide v4

    :catchall_0
    const/4 v6, 0x0

    const/4 v7, 0x4

    return-wide v0
.end method

.method public static isMonitorActivityNames(Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget-object v0, Lcom/tencent/android/tpush/TpnsActivity;->b:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    return v1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    return v1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object v0, Lcom/tencent/android/tpush/TpnsActivity;->b:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x6

    if-eqz p0, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    const/4 p0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    return p0

    :cond_2
    const/4 v2, 0x7

    const/4 v3, 0x6

    return v1
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string v0, "ATctvniyqtpp"

    const-string/jumbo v0, "vTsptAtpnyic"

    const/4 v5, 0x2

    const-string v0, "TssipAttinvy"

    const-string v0, "TpnsActivity"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    sget-boolean p1, Lcom/tencent/android/tpush/XGPushConfig;->enableActivityWindowSecFlag:Z

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eqz p1, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/16 v1, 0x2000

    const/4 v4, 0x2

    move v5, v4

    invoke-static {p1, v1, v1}, Lru/oleg543/utils/Window;->setFlags(Landroid/view/Window;II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    :try_start_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string v2, "etsmti:tyrAqeeivcepnicnnr t v"

    const-string v2, "A :nieisqptctvi tnericreneyvt"

    const/4 v5, 0x5

    const-string v2, "Aee otnnvetTirtirvtiyepic n:s"

    const-string v2, "TpnsActivity receiver intent:"

    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const-string/jumbo v1, "npsnCbusheh"

    const-string/jumbo v1, "npsuahCnshe"

    const-string v1, "Cuhhpluaenn"

    const-string/jumbo v1, "pushChannel"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz p1, :cond_1

    :try_start_2
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v2, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-virtual {v2, v1}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    instance-of v3, v3, Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x0

    if-eqz v3, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-virtual {v2, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez v3, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    iput v2, p0, Lcom/tencent/android/tpush/TpnsActivity;->g:I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/16 v3, 0x65

    const/4 v4, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ne v2, v3, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/TpnsActivity;->b(Landroid/content/Intent;)V

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Intent;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-eqz v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/16 v2, 0x64

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p1, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    iput p1, p0, Lcom/tencent/android/tpush/TpnsActivity;->g:I

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/TpnsActivity;->c(Landroid/content/Intent;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v5, 0x1

    goto :goto_0

    :catchall_1
    move-exception p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const-string/jumbo v1, "pgnnima"

    const-string/jumbo v1, "nngmari"

    const/4 v5, 0x4

    const-string/jumbo v1, "nqnirga"

    const-string/jumbo v1, "warning"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :try_start_3
    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :catchall_2
    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    return-void
.end method

.method protected onPause()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method protected onResume()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method protected onStart()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method protected onStop()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    const/4 v0, 0x0

    move v1, v0

    return-void
.end method
