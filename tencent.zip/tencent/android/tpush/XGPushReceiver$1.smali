.class Lcom/tencent/android/tpush/XGPushReceiver$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushReceiver;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Landroid/content/Intent;

.field final synthetic d:Lcom/tencent/android/tpush/XGPushReceiver;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGPushReceiver;Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->d:Lcom/tencent/android/tpush/XGPushReceiver;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->a:Landroid/content/Context;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->b:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p4, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->c:Landroid/content/Intent;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "K s@@   br s@o~So ~~o@i@~@~@@1@f~~~My~ @~-@ ~n~@m~i~@i/l@l bo@~4a~~ d@ .@to~ ~vo~~~bf  @  ut/ c@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->a:Landroid/content/Context;

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->i(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->a:Landroid/content/Context;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/base/util/Util;->killPushProcess(Landroid/content/Context;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const-string v0, "IEEmGSNRsAedTNMedHioLSS.E.iPnamUtontcAg.cx.tn._provainc"

    const-string v0, "_NsoeGAcnPMHpUtIT.EimctdSoivN..Rc_AaEdtgaS.eLrSnonnxEi."

    const/4 v4, 0x1

    const-string v0, "_dMEoL.ceNnAmvn.SN.cceRnEIdarEAiGtnxgiUT.iSopHtto.o._Sa"

    const-string v0, "com.tencent.android.xg.vip.action.INTERNAL_PUSH_MESSAGE"

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->b:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/a;->b(Landroid/content/Context;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    goto/16 :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v0, "vdeeDbd.t.nK.ogattnmimcpin.oxrc.ncio."

    const-string v0, "So.mgteccndadr..ceK.nnDxoniotiiv.mpt."

    const/4 v4, 0x0

    const-string v0, "com.tencent.android.xg.vip.action.SDK"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->b:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    goto :goto_0

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v0, "cAonICue_S.c.vgLOaDtoKotemdnticNdxKEaprnIEi.VniP.._AET"

    const-string v0, "com.tencent.android.xg.vip.action.ACTION_SDK_KEEPALIVE"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->b:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v0, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->d:Lcom/tencent/android/tpush/XGPushReceiver;

    const/4 v3, 0x5

    move v4, v3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->a:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->c:Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lcom/tencent/android/tpush/XGPushReceiver;->a(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_3
    const/4 v4, 0x1

    const/4 v3, 0x3

    const-string v0, "hGeioeXuevsrPc"

    const/4 v4, 0x5

    const-string v0, "huieGXPpseRevc"

    const-string v0, "XGPushReceiver"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v1, "SberXtisqt rGcv"

    const-string/jumbo v1, "tteG bricsSXrev"

    const/4 v4, 0x6

    const-string/jumbo v1, "ststGr cvXaeSie"

    const-string/jumbo v1, "start XGService"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->a:Landroid/content/Context;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-wide/16 v1, 0xdac

    const-wide/16 v1, 0xdac

    const/4 v4, 0x3

    const-wide/16 v1, 0xdac

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v0, v1, v2}, Lcom/tencent/android/tpush/service/b;->a(Landroid/content/Context;J)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushReceiver$1;->a:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/a;->b(Landroid/content/Context;)V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method
