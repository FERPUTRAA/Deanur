.class Lcom/tencent/android/tpush/InnerTpnsActivity$2;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/InnerTpnsActivity;->b(ILandroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Lcom/tencent/android/tpush/InnerTpnsActivity;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$2;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$2;->a:Landroid/content/Intent;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ s m~4y@@o i~ @@i/@1~@  oo~to@M~ v~~/d@@o~b~~-n@~f~  @~@au@   ~@ o~f ~~S@~ c@@ l b~i~l@srt~b@.~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$2;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$2;->a:Landroid/content/Intent;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity;->b(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$2;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    const/4 v0, 0x2

    xor-int/2addr v1, v0

    return-void
.end method
