.class Lcom/tencent/android/tpush/XGPushConfig$2;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushConfig;->setHeartbeatInterval(Landroid/content/Context;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:I


# direct methods
.method constructor <init>(Landroid/content/Context;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushConfig$2;->a:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput p2, p0, Lcom/tencent/android/tpush/XGPushConfig$2;->b:I

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5
    .annotation build Lcom/jg/JgMethodChecked;
        author = 0x1
        fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
        lastDate = "20150316"
        reviewer = 0x3
        vComment = {
            .enum Lcom/jg/EType;->RECEIVERCHECK:Lcom/jg/EType;,
            .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;
        }
    .end annotation

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " ~s@/@@~~f@  ~d~btu@~~@i l~4 Mi l@ibr@c@yKf@@@@~~@o~o~@~1 ~@ ~@ ~m~ ~n o@~vt@- ao~Soo~@    ~. /b"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushConfig$2;->a:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string v2, "i.pmeRNsdSnSoot4MamiVn.tcTLrdeVvcn..Hg.T.AcnIEtx._Eoi"

    const-string v2, "c.svn4RgTciTVId..E_nnTe.Siomxio.oEHcSrA.LnNMttepVt.ad"

    const/4 v4, 0x5

    const-string/jumbo v2, "m_t.oneoc.MnHS.gd4TTaE.r.oiRiAoc.tNpVtLIv.TnVadxSnEie"

    const-string v2, "com.tencent.android.xg.vip.action.SET_HTINTERVALMS.V4"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string/jumbo v1, "mraeibnl"

    const-string v1, "aeimlvrn"

    const/4 v4, 0x5

    const-string/jumbo v1, "nvlreiua"

    const-string/jumbo v1, "interval"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget v2, p0, Lcom/tencent/android/tpush/XGPushConfig$2;->b:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushConfig$2;->a:Landroid/content/Context;

    const/4 v4, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v1, "fPiCsnXpGhou"

    const-string v1, "XhinosGfgPCu"

    const/4 v4, 0x7

    const-string v1, "PihsXCgnquof"

    const-string v1, "XGPushConfig"

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v2, "arsebaaseHntv Iebtert"

    const-string/jumbo v2, "t erHbaaetaretbnevlsI"

    const/4 v4, 0x7

    const-string v2, "aremvetaetsHta Inrtel"

    const-string/jumbo v2, "setHeartbeatInterval "

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    return-void
.end method
