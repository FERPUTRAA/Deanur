.class Lcom/tencent/android/tpush/XGPushManager$d;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/XGIOperateCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/XGPushManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "d"
.end annotation


# instance fields
.field public a:Z

.field public b:Lcom/tencent/android/tpush/XGIOperateCallback;

.field public c:Lcom/tencent/tpns/baseapi/base/util/TTask;

.field public d:Ljava/lang/String;


# direct methods
.method public constructor <init>(Lcom/tencent/android/tpush/XGIOperateCallback;Lcom/tencent/tpns/baseapi/base/util/TTask;Ljava/lang/String;)V
    .locals 3

    const/4 v1, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-boolean v0, p0, Lcom/tencent/android/tpush/XGPushManager$d;->a:Z

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$d;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$d;->c:Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPushManager$d;->d:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public onFail(Ljava/lang/Object;ILjava/lang/String;)V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "-tsi@ yl@@~b@ nvr~@m@a~~o@l/~i~i~ ~  1@  Kuf@b/s o o~.M@d~t@bc~@~o~@~@o~o~~@   @~f~~~4 ~@ @@   S"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x1

    iget-boolean v0, p0, Lcom/tencent/android/tpush/XGPushManager$d;->a:Z

    const/4 v7, 0x1

    const-string/jumbo v1, "mg,m:"

    const-string/jumbo v1, "m,s:g"

    const-string v1, "g,s:o"

    const-string v1, ",msg:"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string v2, " r:Cebo,m e"

    const-string v2, ":e merCo,d "

    const/4 v7, 0x7

    const-string v2, ":C  roue,ed"

    const-string v2, " , errCode:"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string v3, ":aaF onpioa d"

    const-string v3, "dFl oo:aiaan "

    const/4 v7, 0x6

    const-string v3, "al:datFoqan  "

    const-string v3, " onFail data:"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string v4, "aPsbasnuhXGMe"

    const-string v4, "easPnbuMXrGah"

    const/4 v7, 0x3

    const-string v4, "eXamuhaGnPsgr"

    const-string v4, "XGPushManager"

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-nez v0, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$d;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-interface {v0, p1, p2, p3}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string v5, "XGInnerCallback , callback was null, "

    const-string v5, "XGInnerCallback , callback was null, "

    const/4 v7, 0x4

    const-string v5, "XGInnerCallback , callback was null, "

    const-string v5, "XGInnerCallback , callback was null, "

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v5, p0, Lcom/tencent/android/tpush/XGPushManager$d;->d:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v4, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    const/4 p1, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-boolean p1, p0, Lcom/tencent/android/tpush/XGPushManager$d;->a:Z

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    goto :goto_1

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string v5, ", eIosvc cn aabadnlXebhiakoCkla nGrllk"

    const-string v5, "XGInnerCallback , has invoked callback"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v5, p0, Lcom/tencent/android/tpush/XGPushManager$d;->d:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v4, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    return-void
.end method

.method public onSuccess(Ljava/lang/Object;I)V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x1

    iget-boolean v0, p0, Lcom/tencent/android/tpush/XGPushManager$d;->a:Z

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string v1, "aulg,b  "

    const-string v1, " :gl,au "

    const/4 v6, 0x1

    const-string v1, " :l gfu,"

    const-string v1, " , flag:"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string/jumbo v2, "ncscSt popesua :"

    const-string v2, " a: Sucpcaossten"

    const/4 v6, 0x0

    const-string v2, "ao Ss neqaucsd:t"

    const-string v2, " onSuccess data:"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    const-string/jumbo v3, "qnshGsrMPuXag"

    const-string/jumbo v3, "usagXnhrqGaPM"

    const/4 v6, 0x4

    const-string/jumbo v3, "uGemhgrnaXPsM"

    const-string v3, "XGPushManager"

    const/4 v5, 0x3

    shr-int/2addr v6, v5

    if-nez v0, :cond_2

    const/4 v5, 0x1

    shl-int/2addr v6, v5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$d;->c:Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v5, 0x1

    move v6, v5

    if-eqz v0, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$d;->c:Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v6, 0x4

    invoke-virtual {p1, p2}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v5, 0x7

    move v6, v5

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$d;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 p2, -0x1

    const/4 v6, 0x1

    const-string/jumbo v1, "tnseor erlneri"

    const-string/jumbo v1, "iesnlrte rerrn"

    const/4 v6, 0x0

    const-string/jumbo v1, "itle brenrrore"

    const-string/jumbo v1, "internel error"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-interface {v0, p1, p2, v1}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v4, "XGInnerCallback , callback was null, "

    const-string v4, "XGInnerCallback , callback was null, "

    const/4 v6, 0x1

    const-string v4, "XGInnerCallback , callback was null, "

    const-string v4, "XGInnerCallback , callback was null, "

    const/4 v5, 0x4

    or-int/2addr v6, v5

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$d;->d:Ljava/lang/String;

    const/4 v6, 0x7

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 p1, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    iput-boolean p1, p0, Lcom/tencent/android/tpush/XGPushManager$d;->a:Z

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    goto :goto_1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string v4, "aecockuneCicnaa G  snlbkdlalXIvr h,lma"

    const-string/jumbo v4, "nlnmk k aelall cGnrasXCcI kehobavad,ci"

    const/4 v6, 0x7

    const-string/jumbo v4, "lr ,hakpIXkvGdocl nae Cl ancalsceabnki"

    const-string v4, "XGInnerCallback , has invoked callback"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$d;->d:Ljava/lang/String;

    const/4 v6, 0x7

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-void
.end method
