.class public Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;
.super Lcom/tencent/android/tpush/XGPushNotificationBuilder;


# instance fields
.field private F:Ljava/lang/Integer;

.field private G:Ljava/lang/Integer;

.field private H:Ljava/lang/Integer;

.field private I:Ljava/lang/Integer;

.field private J:Ljava/lang/Integer;

.field private K:Ljava/lang/Integer;

.field private L:Ljava/lang/Integer;

.field private M:Landroid/graphics/Bitmap;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->F:Ljava/lang/Integer;

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->G:Ljava/lang/Integer;

    const/4 v2, 0x5

    const/4 v1, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->H:Ljava/lang/Integer;

    const/4 v2, 0x1

    const/4 v1, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->I:Ljava/lang/Integer;

    const/4 v1, 0x2

    move v2, v1

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->J:Ljava/lang/Integer;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->K:Ljava/lang/Integer;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->L:Ljava/lang/Integer;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->M:Landroid/graphics/Bitmap;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method protected a(Lorg/json/JSONObject;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, ".vs~@1~~m~t~o~tf~n/ @~@@ o  ~@@sy fo -~~~K4  @lo@@ c~M   ud ~ ~b~~@@~l @ a@i@@b~~i @o/rS@@~~o@b@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "atdmuolI"

    const-string/jumbo v0, "olsadtuI"

    const/4 v3, 0x6

    const-string/jumbo v0, "taIlodyo"

    const-string/jumbo v0, "layoutId"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->F:Ljava/lang/Integer;

    const/4 v2, 0x7

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo v0, "lmooybcaItnI"

    const-string v0, "ctnmoIalyIod"

    const-string/jumbo v0, "tooIdauulcIy"

    const-string/jumbo v0, "layoutIconId"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->G:Ljava/lang/Integer;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v0, "yToiltopueatl"

    const-string/jumbo v0, "ioleoadTulytt"

    const/4 v3, 0x6

    const-string v0, "TyioIallqdute"

    const-string/jumbo v0, "layoutTitleId"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->H:Ljava/lang/Integer;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v0, "tosaxTlutIbe"

    const-string v0, "IotTabdtxeul"

    const/4 v3, 0x4

    const-string/jumbo v0, "xlymtdIuTtae"

    const-string/jumbo v0, "layoutTextId"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->I:Ljava/lang/Integer;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v0, "cartodlouubayIInDwel"

    const-string/jumbo v0, "lwleIyunoaorDuactdbI"

    const/4 v3, 0x4

    const-string/jumbo v0, "yDadtbarIleIcoulnbaw"

    const-string/jumbo v0, "layoutIconDrawableId"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->J:Ljava/lang/Integer;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    const-string v0, "dbaateupantcrusoBDIlIsw"

    const-string v0, "DaawsIcprBoabrstteIulnd"

    const/4 v3, 0x7

    const-string v0, "ewsbdlIpBaoausInaratDcr"

    const-string/jumbo v0, "statusBarIconDrawableId"

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->K:Ljava/lang/Integer;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const-string v0, "etyqIouTqdla"

    const-string v0, "dyoeaIuTqlit"

    const/4 v3, 0x4

    const-string v0, "dusmoTleayiI"

    const-string/jumbo v0, "layoutTimeId"

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->L:Ljava/lang/Integer;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v3, 0x3

    return-void
.end method

.method protected b(Lorg/json/JSONObject;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo v0, "yaomdtul"

    const-string v0, "alsyutod"

    const/4 v3, 0x7

    const-string v0, "Ioduoaty"

    const-string/jumbo v0, "layoutId"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->F:Ljava/lang/Integer;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v0, "nyolabcuIIom"

    const-string v0, "IadmocyunIlo"

    const/4 v3, 0x2

    const-string/jumbo v0, "uldIoIucotya"

    const-string/jumbo v0, "layoutIconId"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->G:Ljava/lang/Integer;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const-string/jumbo v0, "tToldIepoaytu"

    const-string v0, "TutloteyIiaod"

    const/4 v3, 0x1

    const-string v0, "TyatlIdoquiet"

    const-string/jumbo v0, "layoutTitleId"

    const/4 v2, 0x6

    move v3, v2

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->H:Ljava/lang/Integer;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v0, "tbsdteTIylxa"

    const-string v0, "atTeIbyutdxl"

    const/4 v3, 0x6

    const-string/jumbo v0, "tlemTdaoytxu"

    const-string/jumbo v0, "layoutTextId"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->I:Ljava/lang/Integer;

    const/4 v3, 0x6

    const-string v0, "IoaoorIbtlnclDyudaeu"

    const-string/jumbo v0, "tloIbruInoludycDwaae"

    const-string/jumbo v0, "layoutIconDrawableId"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->J:Ljava/lang/Integer;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v0, "ewtnrbaolIbsaurItBaDdcs"

    const-string/jumbo v0, "statusBarIconDrawableId"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->K:Ljava/lang/Integer;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo v0, "tyipTouaudlI"

    const-string/jumbo v0, "touTalipdIey"

    const/4 v3, 0x6

    const-string/jumbo v0, "lIeytudpaioT"

    const-string/jumbo v0, "layoutTimeId"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x4

    check-cast p1, Ljava/lang/Integer;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->L:Ljava/lang/Integer;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method public buildNotification(Landroid/content/Context;)Landroid/util/Pair;
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Landroid/util/Pair<",
            "Landroid/app/Notification;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->F:Ljava/lang/Integer;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v0, :cond_5

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    new-instance v0, Landroid/widget/RemoteViews;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->F:Ljava/lang/Integer;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {v0, v1, v2}, Landroid/widget/RemoteViews;-><init>(Ljava/lang/String;I)V

    const/4 v5, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->H:Ljava/lang/Integer;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getTitle(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->I:Ljava/lang/Integer;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->s:Ljava/lang/CharSequence;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    :cond_1
    const/4 v5, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->G:Ljava/lang/Integer;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    if-eqz v1, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->J:Ljava/lang/Integer;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/widget/RemoteViews;->setImageViewResource(II)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->M:Landroid/graphics/Bitmap;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz v1, :cond_2

    const/4 v5, 0x6

    shr-int/2addr v6, v5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->G:Ljava/lang/Integer;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->M:Landroid/graphics/Bitmap;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/widget/RemoteViews;->setImageViewBitmap(ILandroid/graphics/Bitmap;)V

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->K:Ljava/lang/Integer;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-eqz v1, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getTitle(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->L:Ljava/lang/Integer;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v1, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    new-instance v1, Ljava/text/SimpleDateFormat;

    const/4 v5, 0x1

    move v6, v5

    const-string/jumbo v2, "qH:qm"

    const-string/jumbo v2, "m:mqH"

    const/4 v6, 0x2

    const-string v2, "H:smH"

    const-string v2, "HH:mm"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    new-instance v2, Ljava/util/Date;

    const/4 v6, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v2, v3, v4}, Ljava/util/Date;-><init>(J)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->L:Ljava/lang/Integer;

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/Integer;->intValue()I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v1}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v3, v1}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    :cond_4
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->e:Landroid/widget/RemoteViews;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->a(Landroid/content/Context;)Landroid/util/Pair;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-object p1

    :cond_5
    const/4 v5, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->a(Landroid/content/Context;)Landroid/util/Pair;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    return-object p1
.end method

.method public getLayoutIconDrawableId()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->J:Ljava/lang/Integer;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return v0
.end method

.method public getLayoutIconId()Ljava/lang/Integer;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->G:Ljava/lang/Integer;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public getLayoutId()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->F:Ljava/lang/Integer;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    return v0
.end method

.method public getLayoutTextId()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->I:Ljava/lang/Integer;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public getLayoutTimeId()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->L:Ljava/lang/Integer;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public getLayoutTitleId()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->H:Ljava/lang/Integer;

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x3

    return v0
.end method

.method public getType()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string/jumbo v0, "omsucs"

    const/4 v2, 0x6

    const-string/jumbo v0, "sucmot"

    const-string v0, "custom"

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-object v0
.end method

.method public setLayoutIconDrawableBmp(Landroid/graphics/Bitmap;)Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->M:Landroid/graphics/Bitmap;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0
.end method

.method public setLayoutIconDrawableId(I)Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;
    .locals 2

    const/4 v0, 0x4

    const/4 v0, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->J:Ljava/lang/Integer;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-object p0
.end method

.method public setLayoutIconId(I)Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->G:Ljava/lang/Integer;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method public setLayoutId(I)Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->F:Ljava/lang/Integer;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-object p0
.end method

.method public setLayoutTextId(I)Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->I:Ljava/lang/Integer;

    const/4 v0, 0x3

    move v1, v0

    return-object p0
.end method

.method public setLayoutTimeId(I)Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;
    .locals 2

    const/4 v0, 0x3

    move v1, v0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->L:Ljava/lang/Integer;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method public setLayoutTitleId(I)Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->H:Ljava/lang/Integer;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method
