.class public Lcom/tencent/android/tpush/XGPushTextMessage;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable;


# static fields
.field public static final CREATOR:Landroid/os/Parcelable$Creator;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/os/Parcelable$Creator<",
            "Lcom/tencent/android/tpush/XGPushTextMessage;",
            ">;"
        }
    .end annotation
.end field


# instance fields
.field a:J

.field b:Ljava/lang/String;

.field c:Ljava/lang/String;

.field d:Ljava/lang/String;

.field e:I

.field f:Ljava/lang/String;

.field g:Ljava/lang/String;

.field private h:Landroid/content/Intent;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Lcom/tencent/android/tpush/XGPushTextMessage$1;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGPushTextMessage$1;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    sput-object v0, Lcom/tencent/android/tpush/XGPushTextMessage;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-void
.end method

.method protected constructor <init>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->a:J

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const-string v0, ""

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->b:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->c:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->d:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/16 v1, 0x64

    const/4 v3, 0x2

    const/4 v2, 0x7

    iput v1, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->e:I

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->f:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->g:Ljava/lang/String;

    const/4 v2, 0x4

    move v3, v2

    const/4 v0, 0x0

    xor-int/2addr v3, v0

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->h:Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-void
.end method

.method protected constructor <init>(Landroid/os/Parcel;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->a:J

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x1

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->b:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->c:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->d:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/16 v1, 0x64

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput v1, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->e:I

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->f:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->g:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->h:Landroid/content/Intent;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readLong()J

    move-result-wide v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->a:J

    const/4 v3, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->b:Ljava/lang/String;

    const/4 v2, 0x2

    and-int/2addr v3, v2

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->c:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->d:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/os/Parcel;->readInt()I

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    iput v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->e:I

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-class v0, Landroid/content/Intent;

    const-class v0, Landroid/content/Intent;

    const/4 v3, 0x7

    const-class v0, Landroid/content/Intent;

    const-class v0, Landroid/content/Intent;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1, v0}, Landroid/os/Parcel;->readParcelable(Ljava/lang/ClassLoader;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    check-cast v0, Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->h:Landroid/content/Intent;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->f:Ljava/lang/String;

    const/4 v3, 0x4

    invoke-virtual {p1}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->g:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method


# virtual methods
.method a()Landroid/content/Intent;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@os tn s1~o@@~~ ~a .@f@~~~~~S~@ ci@u~M~y~-@@ tb@~m@b 4   o io~l@~o~r @b f@~d K i@ /@v ~@~/~~@@@l"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->h:Landroid/content/Intent;

    const/4 v2, 0x6

    return-object v0
.end method

.method a(Landroid/content/Intent;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->h:Landroid/content/Intent;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    move v2, v1

    const-string/jumbo v0, "sntmnce"

    const-string v0, "cnsntet"

    const/4 v2, 0x5

    const-string/jumbo v0, "tetcono"

    const-string v0, "content"

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-virtual {p1, v0}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    :cond_0
    const/4 v1, 0x2

    const/4 v2, 0x1

    return-void
.end method

.method public describeContents()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public getContent()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->c:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public getCustomContent()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->d:Ljava/lang/String;

    const/4 v1, 0x3

    move v2, v1

    return-object v0
.end method

.method public getMsgId()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-wide v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->a:J

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-wide v0
.end method

.method public getPushChannel()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->e:I

    const/4 v1, 0x5

    move v2, v1

    return v0
.end method

.method public getTemplateId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->f:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->b:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public getTraceId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->g:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v1, "sMXmemgPdGt x=as u[TeshseIg"

    const/4 v4, 0x1

    const-string v1, "eIdXebmT[sMstaGxuPghg  s=s "

    const-string v1, "XGPushTextMessage [msgId = "

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->a:J

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string v1, ",te =iut"

    const-string v1, ", title="

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->b:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string/jumbo v1, "t oonecp,="

    const-string v1, " oe=otnn,c"

    const/4 v4, 0x1

    const-string/jumbo v1, "te,ton cqn"

    const-string v1, ", content="

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->c:Ljava/lang/String;

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v1, "ns tcbuCtm,e=too"

    const/4 v4, 0x6

    const-string/jumbo v1, "t=s,oso nCmetutc"

    const-string v1, ", customContent="

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->d:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v1, " l mnCau =esuhhp"

    const-string v1, "eCp,s u  h=ahunl"

    const/4 v4, 0x5

    const-string v1, ",C lohus  ap=hne"

    const-string v1, ", pushChannel = "

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->e:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v1, "I, dmblapet ept"

    const-string v1, " pIe= tpemdl,ta"

    const/4 v4, 0x0

    const-string/jumbo v1, "tpt lmuaIe ,ed="

    const-string v1, ", templateId = "

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->f:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string v1, "I= tardp,eq "

    const-string/jumbo v1, "r,e=ct dqIa "

    const/4 v4, 0x6

    const-string v1, "etc adr q I="

    const-string v1, ", traceId = "

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->g:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x3

    const-string v1, "]"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object v0
.end method

.method public writeToParcel(Landroid/os/Parcel;I)V
    .locals 4

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->a:J

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    invoke-virtual {p1, v0, v1}, Landroid/os/Parcel;->writeLong(J)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->b:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object p2, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->c:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object p2, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->d:Ljava/lang/String;

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    iget p2, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->e:I

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeInt(I)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->h:Landroid/content/Intent;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p1, p2, v0}, Landroid/os/Parcel;->writeParcelable(Landroid/os/Parcelable;I)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object p2, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->f:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object p2, p0, Lcom/tencent/android/tpush/XGPushTextMessage;->g:Ljava/lang/String;

    const/4 v2, 0x3

    xor-int/2addr v3, v2

    invoke-virtual {p1, p2}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method
