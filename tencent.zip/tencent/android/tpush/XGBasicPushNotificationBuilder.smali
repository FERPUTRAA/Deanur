.class public Lcom/tencent/android/tpush/XGBasicPushNotificationBuilder;
.super Lcom/tencent/android/tpush/XGPushNotificationBuilder;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    invoke-direct {p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected a(Lorg/json/JSONObject;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "c@s@@/. @   ~a@~t@~ ~~~  @~@io@n~~K/l@ iM o o~b@ ~-bt~~ @v~~ob ~~m li @ r@y@S~~f@4@odo~@~s@~1 fu"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    return-void
.end method

.method protected b(Lorg/json/JSONObject;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    return-void
.end method

.method public buildNotification(Landroid/content/Context;)Landroid/util/Pair;
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Landroid/util/Pair<",
            "Landroid/app/Notification;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->a(Landroid/content/Context;)Landroid/util/Pair;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p1
.end method

.method public getType()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const-string/jumbo v0, "sacmb"

    const-string v0, "bssac"

    const/4 v2, 0x3

    const-string/jumbo v0, "sabio"

    const-string v0, "basic"

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method
