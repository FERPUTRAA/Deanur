.class Lcom/tencent/android/tpush/XGPushConfig$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushConfig;->enableDebug(Landroid/content/Context;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Z


# direct methods
.method constructor <init>(Landroid/content/Context;Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushConfig$1;->a:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-boolean p2, p0, Lcom/tencent/android/tpush/XGPushConfig$1;->b:Z

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5
    .annotation build Lcom/jg/JgMethodChecked;
        author = 0x1
        fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
        lastDate = "20150316"
        reviewer = 0x3
        vComment = {
            .enum Lcom/jg/EType;->RECEIVERCHECK:Lcom/jg/EType;,
            .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;
        }
    .end annotation

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " 4syito~S bMb v@ 1~@~a@~  ~@  lo@o~~o@@~ ~@@~@@ofc~~   o@~@d/l@bK @~i /  t~@~@n-~@i~ u~@@~m.sf~r"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$1;->a:Landroid/content/Context;

    const/4 v4, 0x2

    iget-boolean v1, p0, Lcom/tencent/android/tpush/XGPushConfig$1;->b:Z

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->enableDebug(Landroid/content/Context;Z)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$1;->a:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const-string/jumbo v2, "mespn.thbua..eecndgncttosud.di,r"

    const/4 v4, 0x0

    const-string v2, "eoemdt,oitmtup.rdeac.nn.hc.gbuns"

    const-string v2, "com.tencent.android.tpush.debug,"

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushConfig$1;->a:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-boolean v2, p0, Lcom/tencent/android/tpush/XGPushConfig$1;->b:Z

    const/4 v4, 0x3

    if-eqz v2, :cond_0

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x5

    shl-int/2addr v3, v2

    const/4 v4, 0x6

    goto :goto_0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v0, v1, v2}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putInt(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushConfig$1;->a:Landroid/content/Context;

    const/4 v4, 0x5

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v2, "Vm.novDxGEiNoB.n.o.c.nB.padLdAtcertntUEcmi4geaEi_"

    const-string v2, "d..mia_NdigriLEUttncEx.G4nenc.c.e..BAaBvtooDEVnmp"

    const/4 v4, 0x6

    const-string v2, "e.nGobcNx.dpD4LiU.itc.VBgo.nanrcEm.E_Btoen.vdEAti"

    const-string v2, "com.tencent.android.xg.vip.action.ENABLE_DEBUG.V4"

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string v1, "doeoeMubd"

    const-string v1, "eoMboegdd"

    const/4 v4, 0x5

    const-string v1, "Mdegebdpu"

    const-string v1, "debugMode"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-boolean v2, p0, Lcom/tencent/android/tpush/XGPushConfig$1;->b:Z

    const/4 v4, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushConfig$1;->a:Landroid/content/Context;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto :goto_1

    :catchall_0
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v1, "bXfisPhCqonG"

    const-string/jumbo v1, "sinuPbGXfoCh"

    const/4 v4, 0x0

    const-string v1, "XGPushConfig"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo v2, "leeb uugDabe"

    const/4 v4, 0x3

    const-string v2, "geseelauD bn"

    const-string v2, "enableDebug "

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method
