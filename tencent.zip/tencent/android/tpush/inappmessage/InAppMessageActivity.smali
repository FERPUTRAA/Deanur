.class public Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;
.super Landroid/app/Activity;


# instance fields
.field private a:Landroid/content/Context;

.field private b:Landroid/os/Handler;

.field private c:Lcom/tencent/android/tpush/inappmessage/c;

.field private d:Landroid/content/Intent;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;)Landroid/content/Context;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "u@s@K@n@S ~M i@~1 ~@~i~otr@~ ~@~ @/  ~@d~~ot~- ly/@slo  fi@~~@~ob@@@~c~ @ o ~b@~~  4. @@ v~abmo~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->a:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-object p0
.end method

.method static synthetic a(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;Lcom/tencent/android/tpush/inappmessage/c;)Lcom/tencent/android/tpush/inappmessage/c;
    .locals 2

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->c:Lcom/tencent/android/tpush/inappmessage/c;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p1
.end method

.method private a(Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string/jumbo v1, "s:emnraspsgpDp Iat A"

    const-string v1, " aspApsaaDsI: npterg"

    const/4 v3, 0x3

    const-string v1, "I aso r:pMeaptDsAang"

    const-string v1, "InAppMsg parseData :"

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v1, "stipIbyaAesncpmgAMet"

    const-string v1, "MeAmtncIiiageAstpysp"

    const/4 v3, 0x4

    const-string/jumbo v1, "pAesiyuetspvIicnAMtg"

    const-string v1, "InAppMessageActivity"

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    if-eqz p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v1, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-direct {v1, p0, p1}, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;-><init>(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method

.method private a(Landroid/content/Intent;)Z
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v0, 0x0

    const/4 v6, 0x5

    if-eqz p1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string/jumbo v1, "inapp_protect"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p1, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {p1, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-nez v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {p1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x0

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x0

    cmp-long v1, v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-lez v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    cmp-long p1, v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-ltz p1, :cond_0

    const/4 v6, 0x4

    const/4 v0, 0x1

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    return v0

    :catch_0
    move-exception p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x7

    const-string v2, "e:nt kMpIthAogcppsenIc"

    const-string/jumbo v2, "n MsoAhpcetp I:tnIgcke"

    const/4 v6, 0x1

    const-string v2, "InAppMsg checkIntent :"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v1, "niyvcbstqgpMateAAIse"

    const-string/jumbo v1, "ticIsbvAAMnaitypgsee"

    const/4 v6, 0x6

    const-string/jumbo v1, "sgstsAAIniypaMitevce"

    const-string v1, "InAppMessageActivity"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    return v0
.end method

.method static synthetic b(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;)Landroid/content/Intent;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    iget-object p0, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->d:Landroid/content/Intent;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method static synthetic c(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;)Lcom/tencent/android/tpush/inappmessage/c;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    iget-object p0, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->c:Lcom/tencent/android/tpush/inappmessage/c;

    const/4 v1, 0x1

    return-object p0
.end method

.method static synthetic d(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;)Landroid/os/Handler;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x3

    iget-object p0, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->b:Landroid/os/Handler;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-object p0
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 5
    .param p1    # Landroid/os/Bundle;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v4, 0x1

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    :try_start_0
    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    sget-boolean p1, Lcom/tencent/android/tpush/XGPushConfig;->enableActivityWindowSecFlag:Z

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    const/16 v0, 0x2000

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {p1, v0, v0}, Lru/oleg543/utils/Window;->setFlags(Landroid/view/Window;II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    :try_start_1
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-object p0, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->a:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    new-instance p1, Landroid/os/Handler;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-direct {p1}, Landroid/os/Handler;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->b:Landroid/os/Handler;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->d:Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->a(Landroid/content/Intent;)Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-eqz p1, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->d:Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string/jumbo v0, "nMumsApg"

    const-string v0, "gisnApuM"

    const/4 v4, 0x2

    const-string/jumbo v0, "nAipoMpg"

    const-string/jumbo v0, "inAppMsg"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->d:Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo v1, "splapbnhhnu"

    const-string v1, "ennslpapuhh"

    const/4 v4, 0x7

    const-string v1, "ahsCheuunpl"

    const-string/jumbo v1, "pushChannel"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/16 v2, 0x64

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->a(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto/16 :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v3, 0x3

    const/4 v4, 0x6

    goto/16 :goto_0

    :catchall_1
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    move v4, v3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const-string/jumbo v1, "yvpp:tnpan ssig Aq IsApgrMpceattAIiet"

    const-string v1, " yaiaee qitvpgsn ttsprIMAgIstAp:nAMpc"

    const/4 v4, 0x3

    const-string/jumbo v1, "itpAMgatqAsptgeM: rnvstpyiI nscI Asea"

    const-string v1, "InAppMsg start InAppMessageActivity :"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const-string/jumbo v0, "iisytpcpgAnasIvAseMs"

    const-string/jumbo v0, "pascIsAtpsveiitAyMng"

    const/4 v4, 0x0

    const-string/jumbo v0, "niMmaIeetsscypvtAipA"

    const-string v0, "InAppMessageActivity"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_2
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v4, 0x3

    goto :goto_0

    :catchall_2
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string v2, "etstocpiyIhgapisfsspinin I:nM gAeMA vm"

    const-string v2, "cpvm:efAngsss Igi eitypIMs ihpaMAntnpi"

    const/4 v4, 0x6

    const-string/jumbo v2, "paIApbthpesiMA: Itis  ApniMgfgiescnsny"

    const-string v2, "InAppMsg finish InAppMessageActivity :"

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-void
.end method

.method protected onDestroy()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->c:Lcom/tencent/android/tpush/inappmessage/c;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x5

    invoke-virtual {v0}, Landroid/app/Dialog;->dismiss()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-super {p0}, Landroid/app/Activity;->onDestroy()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-void
.end method
