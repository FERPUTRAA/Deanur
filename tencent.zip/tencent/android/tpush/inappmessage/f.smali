.class public Lcom/tencent/android/tpush/inappmessage/f;
.super Landroid/os/AsyncTask;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Landroid/os/AsyncTask<",
        "Ljava/lang/Void;",
        "Ljava/lang/Void;",
        "Landroid/graphics/Bitmap;",
        ">;"
    }
.end annotation


# instance fields
.field private a:Ljava/lang/String;

.field private b:Landroid/view/View;

.field private c:Landroid/content/Context;

.field private d:I


# direct methods
.method public constructor <init>(Ljava/lang/String;Landroid/view/View;Landroid/content/Context;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Landroid/os/AsyncTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/f;->a:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/tencent/android/tpush/inappmessage/f;->b:Landroid/view/View;

    const/4 v1, 0x4

    const/4 v0, 0x0

    iput-object p3, p0, Lcom/tencent/android/tpush/inappmessage/f;->c:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p4, p0, Lcom/tencent/android/tpush/inappmessage/f;->d:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method protected varargs a([Ljava/lang/Void;)Landroid/graphics/Bitmap;
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@so@if~ ~~ @1~~i~ . @~l~~ @M~-~@ i ~~/n~ @  t@ 4us@oa@@o ~ ~oKf~~ br@cob@l ~m S ~@o/bvt@@yd@~~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    new-instance p1, Ljava/net/URL;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/f;->a:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {p1, v0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-virtual {p1}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast p1, Ljava/net/HttpURLConnection;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1, v0}, Ljava/net/URLConnection;->setDoInput(Z)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/net/URLConnection;->connect()V

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p1}, Landroid/graphics/BitmapFactory;->decodeStream(Ljava/io/InputStream;)Landroid/graphics/Bitmap;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p1

    :catch_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const-string/jumbo v1, "pnLmr ITas:egkBd npgAsdakoIoagMcndo mIa"

    const-string v1, "InAppMsg ImageLoadTask doInBackground :"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v0, "TsagoadLskmae"

    const-string v0, "TmsgaakoesadL"

    const/4 v3, 0x6

    const-string v0, "aaeoTbaLkmgdI"

    const-string v0, "ImageLoadTask"

    const/4 v3, 0x0

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 p1, 0x0

    shl-int/2addr v3, p1

    return-object p1
.end method

.method protected a(Landroid/graphics/Bitmap;)V
    .locals 10

    const/4 v8, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-super {p0, p1}, Landroid/os/AsyncTask;->onPostExecute(Ljava/lang/Object;)V

    :try_start_0
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/f;->b:Landroid/view/View;

    const/4 v9, 0x2

    if-eqz v0, :cond_1

    const/4 v9, 0x7

    instance-of v1, v0, Landroid/widget/ImageView;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eqz v1, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-eqz p1, :cond_1

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    check-cast v0, Landroid/widget/ImageView;

    const/4 v9, 0x1

    const/4 v8, 0x4

    invoke-virtual {v0, p1}, Landroid/widget/ImageView;->setImageBitmap(Landroid/graphics/Bitmap;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    goto/16 :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x1

    instance-of v0, v0, Landroid/widget/RelativeLayout;

    const/4 v8, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-eqz v0, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x5

    if-eqz p1, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getWidth()I

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {p1}, Landroid/graphics/Bitmap;->getHeight()I

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    int-to-float v0, v4

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x1

    div-float/2addr v0, v0

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/f;->b:Landroid/view/View;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v1}, Landroid/view/View;->getHeight()I

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    int-to-float v1, v1

    const/4 v8, 0x5

    const/4 v9, 0x5

    int-to-float v2, v5

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    div-float/2addr v1, v2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    new-instance v6, Landroid/graphics/Matrix;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-direct {v6}, Landroid/graphics/Matrix;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v6, v0, v1}, Landroid/graphics/Matrix;->postScale(FF)Z

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    const/4 v2, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    const/4 v3, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/4 v7, 0x1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static/range {v1 .. v7}, Landroid/graphics/Bitmap;->createBitmap(Landroid/graphics/Bitmap;IIIILandroid/graphics/Matrix;Z)Landroid/graphics/Bitmap;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/f;->c:Landroid/content/Context;

    invoke-virtual {v0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {v0, p1}, Landroidx/core/graphics/drawable/j;->a(Landroid/content/res/Resources;Landroid/graphics/Bitmap;)Landroidx/core/graphics/drawable/i;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/4 v0, 0x1

    const/4 v9, 0x1

    invoke-virtual {p1, v0}, Landroidx/core/graphics/drawable/i;->k(Z)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/inappmessage/f;->d:I

    const/4 v9, 0x2

    int-to-float v0, v0

    const/4 v8, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {p1, v0}, Landroidx/core/graphics/drawable/i;->m(F)V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/f;->b:Landroid/view/View;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v0, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x3

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string v1, "MIsoedueoassPnaLTtmApconxp gmu a E:tkg"

    const-string v1, "dLsm tptgnIEoogaMsune TexePAmosacapk: "

    const/4 v9, 0x5

    const-string v1, "axoga tpntnue posdIAc:eeTLEIso maPMsgp"

    const-string v1, "InAppMsg ImageLoadTask onPostExecute :"

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string v0, "aTgeodLsqmoIa"

    const-string v0, "ImsdoaeLaoagT"

    const/4 v9, 0x6

    const-string/jumbo v0, "oassmagLaIdkT"

    const-string v0, "ImageLoadTask"

    const/4 v9, 0x2

    const/4 v8, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    return-void
.end method

.method protected synthetic doInBackground([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    check-cast p1, [Ljava/lang/Void;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/inappmessage/f;->a([Ljava/lang/Void;)Landroid/graphics/Bitmap;

    move-result-object p1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p1
.end method

.method protected synthetic onPostExecute(Ljava/lang/Object;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x7

    check-cast p1, Landroid/graphics/Bitmap;

    const/4 v0, 0x6

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/inappmessage/f;->a(Landroid/graphics/Bitmap;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method
