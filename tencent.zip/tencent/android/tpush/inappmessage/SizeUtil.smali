.class public Lcom/tencent/android/tpush/inappmessage/SizeUtil;
.super Ljava/lang/Object;


# static fields
.field public static final TEXT_SIZE_0:I = 0x14

.field public static final TEXT_SIZE_0_1:I = 0x12

.field public static final TEXT_SIZE_0_2:I = 0x10

.field public static final TEXT_SIZE_1:I = 0x16

.field public static final TEXT_SIZE_2:I = 0x18

.field private static a:Z

.field public static dp10:I

.field public static dp100:I

.field public static dp14:I

.field public static dp16:I

.field public static dp18:I

.field public static dp180:I

.field public static dp2:I

.field public static dp20:I

.field public static dp200:I

.field public static dp250:I

.field public static dp30:I

.field public static dp48:I

.field public static dp5:I

.field public static dp50:I

.field public static dp606:I

.field public static dp7:I

.field public static dp846:I

.field public static dp96:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public static dipTopx(Landroid/content/Context;F)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~osm~  @~i @~~ttb ~~@~@-@@~~s~~ obva  @.@~~4l@@u@  y ~/~/Monod~o@i~@Sb@ @ oK@r 1 @i@ f~ ~@@ l~~f"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    invoke-static {p1}, Ljava/lang/Float;->valueOf(F)Ljava/lang/Float;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-virtual {p1}, Ljava/lang/Float;->floatValue()F

    move-result p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {v0, p1, p0}, Landroid/util/TypedValue;->applyDimension(IFLandroid/util/DisplayMetrics;)F

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    float-to-int p0, p0

    const/4 v2, 0x2

    return p0
.end method

.method public static dpToPx(Landroid/content/Context;I)I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->init(Landroid/content/Context;)V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x5

    int-to-float p1, p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget p0, p0, Landroid/util/DisplayMetrics;->xdpi:F

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    const/high16 v0, 0x43200000    # 160.0f

    const/4 v1, 0x3

    shl-int/2addr v2, v1

    div-float/2addr p0, v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    mul-float/2addr p1, p0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    return p0
.end method

.method public static getDisplaySize(Landroid/app/Activity;)Landroid/graphics/Point;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v0, Landroid/graphics/Point;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {v0}, Landroid/graphics/Point;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-object v0

    :cond_0
    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/app/Activity;->getWindowManager()Landroid/view/WindowManager;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-interface {p0}, Landroid/view/WindowManager;->getDefaultDisplay()Landroid/view/Display;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p0, v0}, Landroid/view/Display;->getSize(Landroid/graphics/Point;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v1, "SizeUtil"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x7

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v0
.end method

.method public static getStatusBarHeight(Landroid/app/Activity;)I
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->init(Landroid/content/Context;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    iget v0, v0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/16 v1, 0x400

    and-int/2addr v0, v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 v2, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-ne v0, v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v0, 0x1

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x5

    move v0, v2

    move v0, v2

    const/4 v6, 0x5

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eqz v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    return v2

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string/jumbo v1, "siemn"

    const-string v1, "eisnd"

    const/4 v6, 0x6

    const-string v1, "dneio"

    const-string v1, "dimen"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string/jumbo v3, "rdadobm"

    const-string v3, "adomdrn"

    const/4 v6, 0x6

    const-string/jumbo v3, "nrdadou"

    const-string v3, "android"

    const/4 v6, 0x2

    const-string/jumbo v4, "taat_rhpoisuteh_s"

    const-string/jumbo v4, "uahtogsa__httersi"

    const/4 v6, 0x5

    const-string/jumbo v4, "shiurb_aqe_htagts"

    const-string/jumbo v4, "status_bar_height"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v0, v4, v1, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-lez v0, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p0, v0}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result v2

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    return v2
.end method

.method public static getStatusBarHeight(Landroid/content/Context;)I
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->init(Landroid/content/Context;)V

    const/4 v6, 0x6

    const/4 v0, 0x0

    const/4 v6, 0x2

    move v5, v0

    move v5, v0

    :try_start_0
    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    const-string/jumbo v2, "trsbasbe_tsiuga_h"

    const-string v2, "h_se_bgrattsuahbi"

    const/4 v6, 0x0

    const-string v2, "_atmesubriaghstt_"

    const-string/jumbo v2, "status_bar_height"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string v3, "diueo"

    const-string/jumbo v3, "iuedm"

    const/4 v6, 0x3

    const-string v3, "bnmdi"

    const-string v3, "dimen"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v4, "pdroanu"

    const-string/jumbo v4, "piadron"

    const/4 v6, 0x0

    const-string v4, "android"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1, v2, v3, v4}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-lez v1, :cond_0

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p0, v1}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    move v0, p0

    move v0, p0

    const/4 v6, 0x5

    move v0, p0

    move v0, p0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const-string v1, "SzUiiltp"

    const-string/jumbo v1, "qzlitiUS"

    const/4 v6, 0x1

    const-string/jumbo v1, "qiitSlze"

    const-string v1, "SizeUtil"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x2

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    return v0
.end method

.method public static init(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-boolean v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->a:Z

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    sput-boolean v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->a:Z

    const/4 v1, 0x3

    shr-int/2addr v2, v1

    const/16 v0, 0x60

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp96:I

    const/4 v2, 0x5

    const/16 v0, 0x30

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp48:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/16 v0, 0x1e

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp30:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    const/4 v0, 0x5

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp5:I

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/16 v0, 0x14

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp20:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    const/16 v0, 0xa

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp10:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    const/4 v0, 0x7

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp7:I

    const/4 v1, 0x3

    move v2, v1

    const/16 v0, 0x12

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp18:I

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/16 v0, 0x10

    const/4 v1, 0x7

    shr-int/2addr v2, v1

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp16:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/16 v0, 0xe

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp14:I

    const/4 v2, 0x3

    const/16 v0, 0x64

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp100:I

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/16 v0, 0xc8

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp200:I

    const/4 v1, 0x4

    and-int/2addr v2, v1

    const/16 v0, 0xfa

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp250:I

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x2

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp2:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/16 v0, 0x32

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp50:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    const/16 v0, 0xb4

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x6

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp180:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/16 v0, 0x25e

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    const/4 v1, 0x4

    move v2, v1

    sput v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp606:I

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/16 v0, 0x34e

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    sput p0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp846:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public static pxToDp(Landroid/content/Context;I)I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->init(Landroid/content/Context;)V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    int-to-float p1, p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget p0, p0, Landroid/util/DisplayMetrics;->xdpi:F

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    const/high16 v0, 0x43200000    # 160.0f

    div-float/2addr p0, v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x2

    div-float/2addr p1, p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    return p0
.end method

.method public static pxToSp(Landroid/content/Context;I)I
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->init(Landroid/content/Context;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x3

    int-to-float p1, p1

    const/4 v0, 0x5

    move v1, v0

    iget p0, p0, Landroid/util/DisplayMetrics;->scaledDensity:F

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    div-float/2addr p1, p0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x5

    float-to-int p0, p1

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p0
.end method

.method public static spToPx(Landroid/content/Context;I)I
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->init(Landroid/content/Context;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    int-to-float p1, p1

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x0

    iget p0, p0, Landroid/util/DisplayMetrics;->scaledDensity:F

    mul-float/2addr p1, p0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    float-to-int p0, p1

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    return p0
.end method
