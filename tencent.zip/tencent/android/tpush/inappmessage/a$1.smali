.class Lcom/tencent/android/tpush/inappmessage/a$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/inappmessage/a;->a(Landroid/view/View;)Lcom/tencent/android/tpush/inappmessage/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/inappmessage/a;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/inappmessage/a;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/a$1;->a:Lcom/tencent/android/tpush/inappmessage/a;

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/a$1;->a:Lcom/tencent/android/tpush/inappmessage/a;

    const/4 v2, 0x0

    const/4 v1, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/a;->cancel()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/a$1;->a:Lcom/tencent/android/tpush/inappmessage/a;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object p1, p1, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/a$1;->a:Lcom/tencent/android/tpush/inappmessage/a;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object p1, p1, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p1, v0, v0}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method
