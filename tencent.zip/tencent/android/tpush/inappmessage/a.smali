.class abstract Lcom/tencent/android/tpush/inappmessage/a;
.super Landroid/app/Dialog;


# instance fields
.field protected a:Landroid/widget/RelativeLayout;

.field protected b:Landroid/app/Activity;

.field protected c:Z


# direct methods
.method protected constructor <init>(Landroid/app/Activity;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/tencent/android/tpush/inappmessage/i;->a(Landroid/app/Activity;)I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-direct {p0, p1, v0}, Landroid/app/Dialog;-><init>(Landroid/content/Context;I)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    iput-boolean v0, p0, Lcom/tencent/android/tpush/inappmessage/a;->c:Z

    const/4 v1, 0x0

    shl-int/2addr v2, v1

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->init(Landroid/content/Context;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method private a(Landroid/view/View;)Lcom/tencent/android/tpush/inappmessage/e;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@~s .4@M ~ ~K~~~to b~@@b ~uf~1@imcn~ v@~ @o/@~~~r~@ @b~  @o doo@o@~@f@@@s  l@@ /i~~-S~lt ai @~ ~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    new-instance v0, Lcom/tencent/android/tpush/inappmessage/e;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {v0, v1}, Lcom/tencent/android/tpush/inappmessage/e;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance v1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    const/4 v2, -0x2

    const/4 v5, 0x3

    shl-int/2addr v6, v5

    invoke-direct {v1, v2, v2}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/inappmessage/a;->d()Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz v2, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/16 p1, 0xa

    const/4 v5, 0x7

    shl-int/2addr v6, v5

    invoke-virtual {v1, p1}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    const/16 p1, 0xb

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v1, p1}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(I)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    sget p1, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp5:I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v1, v3, p1, p1, v3}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v4, 0x6

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v1, v4, v2}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(II)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/4 v2, 0x7

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1}, Landroid/view/View;->getId()I

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1, v2, p1}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(II)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    sget p1, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp7:I

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    neg-int v2, p1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    neg-int p1, p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1, v3, v2, p1, v3}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    new-instance p1, Lcom/tencent/android/tpush/inappmessage/a$1;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {p1, p0}, Lcom/tencent/android/tpush/inappmessage/a$1;-><init>(Lcom/tencent/android/tpush/inappmessage/a;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v0, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-object v0
.end method

.method private g()Landroid/widget/RelativeLayout;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    new-instance v0, Landroid/widget/RelativeLayout;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v0, v1}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v1, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v2, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {v1, v2, v2}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    const/4 v3, 0x1

    shl-int/2addr v4, v3

    const/4 v2, 0x0

    xor-int/2addr v4, v2

    const/4 v3, 0x2

    and-int/2addr v4, v3

    invoke-virtual {v0, v2}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    return-object v0
.end method

.method private h()Landroid/widget/RelativeLayout;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v0, Landroid/widget/RelativeLayout;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v0, v1}, Landroid/widget/RelativeLayout;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {}, Landroid/view/View;->generateViewId()I

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Landroid/view/View;->setId(I)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/inappmessage/a;->b()Landroid/widget/RelativeLayout$LayoutParams;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/inappmessage/a;->d()Z

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    xor-int/lit8 v1, v1, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/inappmessage/i;->a(Landroid/view/View;IZ)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpush/inappmessage/a;->a(Landroid/widget/RelativeLayout;)V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-object v0
.end method


# virtual methods
.method protected a()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-direct {p0}, Lcom/tencent/android/tpush/inappmessage/a;->g()Landroid/widget/RelativeLayout;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/inappmessage/a;->a:Landroid/widget/RelativeLayout;

    const/4 v4, 0x7

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/inappmessage/a;->h()Landroid/widget/RelativeLayout;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->a:Landroid/widget/RelativeLayout;

    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpush/inappmessage/a;->c()Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {p0, v0}, Lcom/tencent/android/tpush/inappmessage/a;->a(Landroid/view/View;)Lcom/tencent/android/tpush/inappmessage/e;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->a:Landroid/widget/RelativeLayout;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/a;->a:Landroid/widget/RelativeLayout;

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1}, Landroid/app/Dialog;->setContentView(Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/a;->a:Landroid/widget/RelativeLayout;

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-wide/16 v1, 0x15e

    const-wide/16 v1, 0x15e

    const/4 v4, 0x7

    const-wide/16 v1, 0x15e

    const-wide/16 v1, 0x15e

    const/4 v4, 0x6

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/inappmessage/i;->a(J)Landroid/view/animation/Animation;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Landroid/view/View;->setAnimation(Landroid/view/animation/Animation;)V

    const/4 v4, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/inappmessage/a;->e()V

    const/4 v4, 0x1

    return-void
.end method

.method abstract a(Landroid/widget/RelativeLayout;)V
.end method

.method abstract b()Landroid/widget/RelativeLayout$LayoutParams;
.end method

.method abstract c()Z
.end method

.method public cancel()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    iget-boolean v0, p0, Lcom/tencent/android/tpush/inappmessage/a;->c:Z

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x4

    iput-boolean v0, p0, Lcom/tencent/android/tpush/inappmessage/a;->c:Z

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpush/inappmessage/a;->f()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method abstract d()Z
.end method

.method abstract e()V
.end method

.method protected f()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-super {p0}, Landroid/app/Dialog;->cancel()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method
