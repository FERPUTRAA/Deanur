.class abstract Lcom/tencent/android/tpush/inappmessage/b;
.super Ljava/lang/Object;


# instance fields
.field private a:I

.field private b:I


# direct methods
.method protected constructor <init>(Lcom/tencent/android/tpush/inappmessage/a/a;)V
    .locals 3

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/a/a;->a()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {p0, v0}, Lcom/tencent/android/tpush/inappmessage/b;->a(I)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/a/a;->b()I

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/inappmessage/b;->b(I)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method private a(I)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "oost   4@@S@~l~ t~@@i@@ in ~K ~ ci@-@fm~ ~M.b@@a ~~~bv@/ ~of@@ d~~ y~~o~~~s  ~@@~/@ @1l~ou@ o@b~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/android/tpush/inappmessage/b;->a:I

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method private b(I)V
    .locals 2

    const/4 v1, 0x2

    iput p1, p0, Lcom/tencent/android/tpush/inappmessage/b;->b:I

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/android/tpush/inappmessage/b;->a:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/inappmessage/b;->b:I

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method
