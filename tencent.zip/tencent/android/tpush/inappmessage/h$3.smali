.class Lcom/tencent/android/tpush/inappmessage/h$3;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/inappmessage/h;->d(Landroid/content/Context;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/inappmessage/h;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/inappmessage/h;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "n@s@d@ c~~  bfS~u@-~~4@a@~/~  o Ko@sy~ ~o@~~ ~@bf@r@ tol~@to~@~i1~~@ @.  ~o~@@l b i@  v~ ~@@mi~/"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object p1, p1, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->o()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v0, v0, Lcom/tencent/android/tpush/inappmessage/h;->f:Landroid/content/Intent;

    const/4 v4, 0x2

    const-string v1, "_ovmp_sspmiudaecttie_"

    const-string/jumbo v1, "tispenvcotsd_a_eiu_mp"

    const/4 v4, 0x4

    const-string/jumbo v1, "nstdoctp_aipo_ve_ieum"

    const-string/jumbo v1, "inapp_custom_event_id"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const-string v2, "INNER_MESSAGE"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-object v1, v0, Lcom/tencent/android/tpush/inappmessage/h;->f:Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v0, v0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpush/inappmessage/d;->p()I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v2, "uevptb_n_adnpnt_btmoe"

    const-string/jumbo v2, "tetmd_pavunibotnn_p_e"

    const/4 v4, 0x1

    const-string/jumbo v2, "peb_uvuitttend_pna_no"

    const-string/jumbo v2, "inapp_button_event_id"

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, v1, Lcom/tencent/android/tpush/inappmessage/h;->f:Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/stat/ServiceStat;->appReportNotificationClicked(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v4, 0x5

    iget-object v0, v0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpush/inappmessage/d;->c()I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    if-eq v0, v1, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v1, 0x2

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eq v0, v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x3

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eq v0, v1, :cond_1

    const/4 v4, 0x7

    const/4 p1, 0x4

    const/4 v4, 0x0

    xor-int/2addr v3, p1

    if-eq v0, p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v4, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    invoke-static {p1}, Lcom/tencent/android/tpush/inappmessage/h;->a(Lcom/tencent/android/tpush/inappmessage/h;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/inappmessage/h;->b(Lcom/tencent/android/tpush/inappmessage/h;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    goto :goto_0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/inappmessage/h;->a(Lcom/tencent/android/tpush/inappmessage/h;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/a;->cancel()V

    :goto_0
    const/4 v3, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/a;->cancel()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object p1, p1, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$3;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object p1, p1, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {p1, v0, v0}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v4, 0x5

    return-void
.end method
