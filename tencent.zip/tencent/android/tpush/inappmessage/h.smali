.class abstract Lcom/tencent/android/tpush/inappmessage/h;
.super Lcom/tencent/android/tpush/inappmessage/a;


# instance fields
.field protected d:Lcom/tencent/android/tpush/inappmessage/d;

.field protected e:Ljava/lang/String;

.field protected f:Landroid/content/Intent;


# direct methods
.method protected constructor <init>(Landroid/app/Activity;Lcom/tencent/android/tpush/inappmessage/d;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/inappmessage/a;-><init>(Landroid/app/Activity;)V

    const/4 v1, 0x1

    const-string/jumbo p1, "sssMuePegTalspppeeoa"

    const-string p1, "apsselTuppMemePsagoe"

    const/4 v1, 0x4

    const-string p1, "gstmealeppusepTPemMa"

    const-string p1, "PopupMessageTemplate"

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->e:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p3, p0, Lcom/tencent/android/tpush/inappmessage/h;->f:Landroid/content/Intent;

    const/4 v0, 0x0

    move v1, v0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/inappmessage/a;->a()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    return-void
.end method

.method private a(Landroid/content/Context;)Landroid/widget/ImageView;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "c~-@o~iv K @@t@  @ f/ u~y~ @~o~@oi /~~ob@~l~@o1t m@@i~~@@~~  .Sb@n~M@d@o~s ~ r~ ~a~@@~4b @f o @~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v5, 0x2

    const/4 v4, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/inappmessage/h;->b(Landroid/content/Context;)Landroid/widget/ImageView;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    new-instance v0, Lcom/tencent/android/tpush/inappmessage/f;

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpush/inappmessage/d;->h()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x4

    invoke-direct {v0, v1, p1, v2, v3}, Lcom/tencent/android/tpush/inappmessage/f;-><init>(Ljava/lang/String;Landroid/view/View;Landroid/content/Context;I)V

    const/4 v5, 0x3

    new-array v1, v3, [Ljava/lang/Void;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/android/tpush/inappmessage/h;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    invoke-direct {p0}, Lcom/tencent/android/tpush/inappmessage/h;->g()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/inappmessage/h;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/inappmessage/h;->b(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method private a(Ljava/lang/String;)V
    .locals 5

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h;->e:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v2, "lpiiub :tmrmvaAtgUtcjtey"

    const-string/jumbo v2, "iurmpAmettiU:rtacvtgljy "

    const/4 v4, 0x2

    const-string/jumbo v2, "rctpviujtrlm :g itueyAat"

    const-string/jumbo v2, "jumpUrl targetActivity :"

    const/4 v4, 0x7

    const/4 v3, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v1, "dnIartnpV.Eooioc.i.diWtnne"

    const-string/jumbo v1, "nr.ioWtd.oIeVn.nEaacdinito"

    const/4 v4, 0x3

    const-string/jumbo v1, "oertdcaEqnt.odIWanniit.nV."

    const-string v1, "android.intent.action.VIEW"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v0, v1, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v4, 0x7

    const/high16 p1, 0x10000000

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h;->e:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const-string/jumbo v1, "rUsrolo rp.enr"

    const-string/jumbo v1, "ron.obrUep rlr"

    const/4 v4, 0x1

    const-string v1, "e.nmrrpUerr lo"

    const-string/jumbo v1, "openUrl error."

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method

.method private b(Landroid/content/Context;)Landroid/widget/ImageView;
    .locals 6

    const/4 v5, 0x4

    new-instance v0, Landroid/widget/ImageView;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v0, p1}, Landroid/widget/ImageView;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x1

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/inappmessage/d;->i()I

    move-result v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v3}, Lcom/tencent/android/tpush/inappmessage/d;->j()I

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v2, 0x1

    const/4 v5, 0x4

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/high16 v2, 0x41c00000    # 24.0f

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {p1, v2}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iput v3, v1, Landroid/widget/LinearLayout$LayoutParams;->topMargin:I

    const/4 v5, 0x7

    invoke-static {p1, v2}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput v3, v1, Landroid/widget/LinearLayout$LayoutParams;->leftMargin:I

    const/4 v4, 0x2

    shr-int/2addr v5, v4

    invoke-static {p1, v2}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    iput p1, v1, Landroid/widget/LinearLayout$LayoutParams;->rightMargin:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v4, 0x1

    xor-int/2addr v5, v4

    return-object v0
.end method

.method private b(Landroid/widget/RelativeLayout;)Landroid/widget/RelativeLayout;
    .locals 6

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpush/inappmessage/d;->v()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpush/inappmessage/d;->v()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-nez v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    new-instance v0, Landroid/graphics/drawable/ShapeDrawable;

    const/4 v5, 0x3

    invoke-direct {v0}, Landroid/graphics/drawable/ShapeDrawable;-><init>()V

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v4, 0x1

    move v5, v4

    invoke-virtual {v1}, Lcom/tencent/android/tpush/inappmessage/d;->g()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/tencent/android/tpush/inappmessage/i;->a(I)Landroid/graphics/drawable/shapes/Shape;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/drawable/ShapeDrawable;->setShape(Landroid/graphics/drawable/shapes/Shape;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/graphics/drawable/ShapeDrawable;->getPaint()Landroid/graphics/Paint;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/inappmessage/d;->v()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1, v0}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpush/inappmessage/d;->H()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v5, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0}, Lcom/tencent/android/tpush/inappmessage/d;->H()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-nez v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    const/4 v0, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v0, Lcom/tencent/android/tpush/inappmessage/f;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1}, Lcom/tencent/android/tpush/inappmessage/d;->H()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {v3}, Lcom/tencent/android/tpush/inappmessage/d;->g()I

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {v0, v1, p1, v2, v3}, Lcom/tencent/android/tpush/inappmessage/f;-><init>(Ljava/lang/String;Landroid/view/View;Landroid/content/Context;I)V

    const/4 v4, 0x7

    const/4 v5, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x4

    move v5, v4

    new-array v1, v1, [Ljava/lang/Void;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/os/AsyncTask;->execute([Ljava/lang/Object;)Landroid/os/AsyncTask;

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-object p1
.end method

.method static synthetic b(Lcom/tencent/android/tpush/inappmessage/h;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/inappmessage/h;->a(Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method private b(Ljava/lang/String;)V
    .locals 6

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->e:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v3, "nmjrottneityt:vciAutagpu t"

    const-string v3, "eAinttu mtenatuirgyvjttc:p"

    const/4 v5, 0x2

    const-string v3, "Anitybtarj: gmetnevtIictup"

    const-string/jumbo v3, "jumpIntent targetActivity:"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v1, "ntd.pIudi.nenoc.ianortEitV"

    const-string/jumbo v1, "ni..cnapVoitIdrditW.Etnnoe"

    const/4 v5, 0x7

    const-string v1, "anrdtitp.tiiEIdoW.c.noenna"

    const-string v1, "android.intent.action.VIEW"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h;->e:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-string/jumbo v1, "pntmortIqeu.n qrj"

    const-string v1, "Ijrrut.rqto enmpn"

    const/4 v5, 0x1

    const-string/jumbo v1, "trs mep.onIterjur"

    const-string/jumbo v1, "jumpIntent error."

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void
.end method

.method private c(Landroid/content/Context;)Landroid/widget/TextView;
    .locals 7

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v0, Landroid/widget/TextView;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-direct {v0, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x6

    const/4 v6, 0x6

    const/high16 v1, 0x41c00000    # 24.0f

    const/4 v6, 0x5

    invoke-static {p1, v1}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {p1, v1}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {p1, v1}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result p1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 v1, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v0, v2, v3, p1, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->x()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->y()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->A()I

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    int-to-float p1, p1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v1, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v0, v1, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string p1, "NED"

    const-string p1, "DEN"

    const/4 v6, 0x4

    const-string p1, "EDN"

    const-string p1, "END"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {p1}, Landroid/text/TextUtils$TruncateAt;->valueOf(Ljava/lang/String;)Landroid/text/TextUtils$TruncateAt;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/4 p1, 0x1

    const/4 v5, 0x5

    shr-int/2addr v6, v5

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setSingleLine(Z)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v6, 0x2

    invoke-virtual {v2}, Lcom/tencent/android/tpush/inappmessage/d;->z()I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v3, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v2, :cond_3

    const/4 v5, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    if-eq v2, p1, :cond_2

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-eq v2, v1, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eq v2, v3, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/16 v4, 0x8

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v2, v4}, Landroid/graphics/Paint;->setFlags(I)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v0, v2, v1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_0

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    sget-object v2, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto :goto_0

    :cond_3
    const/4 v6, 0x3

    sget-object v2, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v6, 0x7

    invoke-virtual {v0, v2}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    new-instance v2, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v4, -0x2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-direct {v2, v4, v4}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v6, 0x0

    const/4 v5, 0x3

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->B()I

    move-result v4

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v4, :cond_6

    const/4 v6, 0x2

    const/4 v5, 0x2

    if-eq v4, p1, :cond_5

    const/4 v6, 0x2

    if-eq v4, v1, :cond_4

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_1

    :cond_4
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 p1, 0x5

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput p1, v2, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    goto :goto_1

    :cond_5
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput p1, v2, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    goto :goto_1

    :cond_6
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    iput v3, v2, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    :goto_1
    const/4 v6, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    return-object v0
.end method

.method private d(Landroid/content/Context;)Landroid/view/View;
    .locals 10

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x0

    invoke-virtual {v0}, Lcom/tencent/android/tpush/inappmessage/d;->f()I

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    const/high16 v1, 0x42400000    # 48.0f

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v2, -0x2

    const/4 v2, -0x1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/4 v3, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    const/high16 v4, 0x41c00000    # 24.0f

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v5, 0x2

    const/4 v5, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    if-ne v0, v5, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    new-instance v0, Landroid/widget/Button;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-direct {v0, p1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    new-instance v6, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-static {p1, v1}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-direct {v6, v2, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {p1, v4}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {p1, v4}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v2

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {p1, v4}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v7

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p1, v4}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result p1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v6, v1, v2, v7, p1}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    iput v5, v6, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    const/4 v9, 0x7

    const/4 v8, 0x0

    invoke-virtual {v0, v6}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->I()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v0, p1}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    new-instance p1, Landroid/graphics/drawable/GradientDrawable;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-direct {p1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v8, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {p1, v3}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    const/4 v8, 0x5

    and-int/2addr v9, v8

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v1}, Lcom/tencent/android/tpush/inappmessage/d;->l()I

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x2

    int-to-float v1, v1

    const/4 v8, 0x3

    move v9, v8

    invoke-virtual {p1, v1}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v1}, Lcom/tencent/android/tpush/inappmessage/d;->I()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {v1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p1, v1}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/4 v8, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v0, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->w()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->J()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->k()I

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    int-to-float p1, p1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    new-instance p1, Lcom/tencent/android/tpush/inappmessage/h$1;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct {p1, p0}, Lcom/tencent/android/tpush/inappmessage/h$1;-><init>(Lcom/tencent/android/tpush/inappmessage/h;)V

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v0, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v8, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    return-object v0

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpush/inappmessage/d;->f()I

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v5, 0x2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    if-ne v0, v5, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    new-instance v0, Landroid/widget/LinearLayout;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-direct {v0, p1}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    new-instance v5, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {p1, v1}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-direct {v5, v2, v1}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {p1, v4}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {p1, v4}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v6

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {p1, v4}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v7

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {p1, v4}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v5, v1, v6, v7, v4}, Landroid/view/ViewGroup$MarginLayoutParams;->setMargins(IIII)V

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v0, v5}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v0, v3}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-instance v1, Landroid/widget/Button;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-direct {v1, p1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, 0x7

    const/high16 v5, 0x3f800000    # 1.0f

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-direct {v4, v3, v2, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 v6, 0x3

    const/4 v8, 0x1

    xor-int/2addr v9, v8

    iput v6, v4, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v1, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->I()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v1, v4}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v9, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x7

    const/4 v8, 0x1

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->w()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x1

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x7

    const/4 v8, 0x1

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->J()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {v4}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v4

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->k()I

    move-result v4

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    int-to-float v4, v4

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v1, v4}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    new-instance v4, Landroid/graphics/drawable/GradientDrawable;

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-direct {v4}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v4, v3}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object v6, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v6}, Lcom/tencent/android/tpush/inappmessage/d;->l()I

    move-result v6

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    int-to-float v6, v6

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    iget-object v6, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v6}, Lcom/tencent/android/tpush/inappmessage/d;->I()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {v6}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v6

    const/4 v9, 0x0

    const/4 v8, 0x3

    invoke-virtual {v4, v6}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v1, v4}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance v4, Lcom/tencent/android/tpush/inappmessage/h$2;

    const/4 v9, 0x4

    invoke-direct {v4, p0}, Lcom/tencent/android/tpush/inappmessage/h$2;-><init>(Lcom/tencent/android/tpush/inappmessage/h;)V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {v1, v4}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    new-instance v1, Landroid/view/View;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {v1, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    new-instance v4, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    const v6, 0x3e4ccccd    # 0.2f

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-direct {v4, v3, v2, v6}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v1, v4}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    new-instance v1, Landroid/widget/Button;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-direct {v1, p1}, Landroid/widget/Button;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x2

    new-instance p1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-direct {p1, v3, v2, v5}, Landroid/widget/LinearLayout$LayoutParams;-><init>(IIF)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/4 v2, 0x5

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    iput v2, p1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v1, p1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v8, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->u()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v1, p1}, Landroid/view/View;->setBackgroundColor(I)V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x5

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->t()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->s()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x4

    const/4 v8, 0x5

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    const/4 v9, 0x6

    const/4 v8, 0x5

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v8, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->r()I

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x3

    int-to-float p1, p1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {v1, p1}, Landroid/widget/TextView;->setTextSize(F)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    new-instance p1, Landroid/graphics/drawable/GradientDrawable;

    const/4 v9, 0x5

    invoke-direct {p1}, Landroid/graphics/drawable/GradientDrawable;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p1, v3}, Landroid/graphics/drawable/GradientDrawable;->setShape(I)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v2}, Lcom/tencent/android/tpush/inappmessage/d;->q()I

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x7

    int-to-float v2, v2

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p1, v2}, Landroid/graphics/drawable/GradientDrawable;->setCornerRadius(F)V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x5

    const/4 v8, 0x0

    invoke-virtual {v2}, Lcom/tencent/android/tpush/inappmessage/d;->u()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-static {v2}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p1, v2}, Landroid/graphics/drawable/GradientDrawable;->setColor(I)V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v1, p1}, Landroid/view/View;->setBackground(Landroid/graphics/drawable/Drawable;)V

    const/4 v9, 0x3

    const/4 v8, 0x7

    new-instance p1, Lcom/tencent/android/tpush/inappmessage/h$3;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-direct {p1, p0}, Lcom/tencent/android/tpush/inappmessage/h$3;-><init>(Lcom/tencent/android/tpush/inappmessage/h;)V

    invoke-virtual {v1, p1}, Landroid/view/View;->setOnClickListener(Landroid/view/View$OnClickListener;)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v0, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    return-object v0

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    const/4 p1, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    return-object p1
.end method

.method private e(Landroid/content/Context;)Landroid/widget/TextView;
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    new-instance v0, Landroid/widget/TextView;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-direct {v0, p1}, Landroid/widget/TextView;-><init>(Landroid/content/Context;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v2, -0x2

    move v8, v2

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-direct {v1, v2, v2}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v2}, Lcom/tencent/android/tpush/inappmessage/d;->D()I

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/4 v3, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 v4, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/4 v5, 0x2

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-eqz v2, :cond_2

    const/4 v8, 0x1

    const/4 v7, 0x5

    if-eq v2, v4, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    if-eq v2, v5, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    const/4 v2, 0x5

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    iput v2, v1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    goto :goto_0

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    iput v4, v1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    goto :goto_0

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    iput v3, v1, Landroid/widget/LinearLayout$LayoutParams;->gravity:I

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v8, 0x3

    const/high16 v1, 0x41c00000    # 24.0f

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {p1, v1}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v2

    const/4 v7, 0x2

    move v8, v7

    invoke-static {p1, v1}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v6

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {p1, v1}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result p1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    invoke-virtual {v0, v2, v6, p1, v1}, Landroid/widget/TextView;->setPadding(IIII)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->F()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x7

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setText(Ljava/lang/CharSequence;)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->G()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {p1}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result p1

    const/4 v8, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTextColor(I)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->C()I

    move-result p1

    const/4 v8, 0x5

    const/4 v7, 0x2

    int-to-float p1, p1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v0, v5, p1}, Landroid/widget/TextView;->setTextSize(IF)V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    const/16 p1, 0x8

    const/4 v8, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setMaxLines(I)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-string v1, "DNE"

    const-string v1, "END"

    const/4 v8, 0x5

    const-string v1, "END"

    const-string v1, "END"

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {v1}, Landroid/text/TextUtils$TruncateAt;->valueOf(Ljava/lang/String;)Landroid/text/TextUtils$TruncateAt;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Landroid/widget/TextView;->setEllipsize(Landroid/text/TextUtils$TruncateAt;)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v7, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-virtual {v1}, Lcom/tencent/android/tpush/inappmessage/d;->E()I

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    if-eqz v1, :cond_6

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-eq v1, v4, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-eq v1, v5, :cond_4

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    if-eq v1, v3, :cond_3

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    goto :goto_1

    :cond_3
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v0}, Landroid/widget/TextView;->getPaint()Landroid/text/TextPaint;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v1, p1}, Landroid/graphics/Paint;->setFlags(I)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    goto :goto_1

    :cond_4
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    const/4 p1, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v0, p1, v5}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;I)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    goto :goto_1

    :cond_5
    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    sget-object p1, Landroid/graphics/Typeface;->DEFAULT_BOLD:Landroid/graphics/Typeface;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    goto :goto_1

    :cond_6
    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    sget-object p1, Landroid/graphics/Typeface;->DEFAULT:Landroid/graphics/Typeface;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v0, p1}, Landroid/widget/TextView;->setTypeface(Landroid/graphics/Typeface;)V

    :goto_1
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-object v0
.end method

.method private g()V
    .locals 6

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string v1, "Idrms_NIOtTii_ICTnTPSoANtFNgAdsaePG.IsOE.S"

    const-string/jumbo v1, "tisdsFSTAOasi.e_TSdC_OEAII.NPPtngNonrTGNII"

    const/4 v5, 0x2

    const-string v1, "_P.nosnidt_SsTGaoCAT.FITOIPgrNAeSEOtdNiITN"

    const-string v1, "android.settings.APP_NOTIFICATION_SETTINGS"

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v1, ".epdrbKtima.dCvPioAadEGProeAnArr_x"

    const-string v1, "AAimdpraao.id_oAeCPKPernP.trdEvrxG"

    const/4 v5, 0x5

    const-string v1, "AoeaexunAPdiiorr.d.P_ErG.rKaAtPvCp"

    const-string v1, "android.provider.extra.APP_PACKAGE"

    const/4 v5, 0x1

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string v1, "NIt.rn_pEoxCdinLnH.AoaaDtidreNe"

    const-string v1, ".ettoNt_CrdnaniAda.eIrLixDnENoH"

    const/4 v5, 0x6

    const-string v1, "android.intent.extra.CHANNEL_ID"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    iget v2, v2, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const-string v1, "a_pkppceqaa"

    const-string v1, "app_package"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string v1, "apsu_pd"

    const-string v1, "_ppdabu"

    const/4 v5, 0x0

    const-string/jumbo v1, "pudmp_i"

    const-string v1, "app_uid"

    const/4 v4, 0x5

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    iget v2, v2, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v5, 0x5

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x6

    const-string v1, "LTTdooCt.nIiTIeLA.NnSSAaPtIsA_suED_iGNIErSgdP"

    const-string v1, "EsI_eouNa.n_NGDSTSnEgPiLT.AsIPiATddSCOAtrtIIL"

    const/4 v5, 0x2

    const-string v1, "DSLt_bgAIid.n.dStPePosCEA_GNENTTTAnsIIaOiLISr"

    const-string v1, "android.settings.APPLICATION_DETAILS_SETTINGS"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v3, "agacppu"

    const-string/jumbo v3, "pcegpaa"

    const/4 v5, 0x3

    const-string/jumbo v3, "pkgpaca"

    const-string/jumbo v3, "package"

    invoke-static {v3, v1, v2}, Landroid/net/Uri;->fromParts(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Landroid/app/Activity;->startActivity(Landroid/content/Intent;)V

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    return-void
.end method


# virtual methods
.method a(Landroid/widget/RelativeLayout;)V
    .locals 10
    .annotation build Landroidx/annotation/w0;
        api = 0x17
    .end annotation

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    new-instance v0, Landroid/widget/ScrollView;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-direct {v0, v1}, Landroid/widget/ScrollView;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    const/4 v1, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v0, v1}, Landroid/view/View;->setVerticalScrollBarEnabled(Z)V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    new-instance v1, Landroid/widget/LinearLayout$LayoutParams;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    const/4 v2, -0x1

    const/4 v8, 0x6

    move v9, v8

    const/4 v3, -0x2

    move v9, v3

    const/4 v8, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-direct {v1, v2, v3}, Landroid/widget/LinearLayout$LayoutParams;-><init>(II)V

    const/4 v9, 0x7

    new-instance v2, Landroid/widget/LinearLayout;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v3, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-direct {v2, v3}, Landroid/widget/LinearLayout;-><init>(Landroid/content/Context;)V

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v2, v1}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/4 v1, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v2, v1}, Landroid/widget/LinearLayout;->setOrientation(I)V

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v3, v1}, Lcom/tencent/android/tpush/inappmessage/d;->a(I)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const-string v3, "T.netoqoqcaliL"

    const-string/jumbo v3, "loLieTniqoa.tc"

    const-string/jumbo v3, "nTsoati.eLoict"

    const-string v3, "Title.Location"

    const/4 v8, 0x5

    shl-int/2addr v9, v8

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string/jumbo v5, "isLmnaotBnuc.tt"

    const-string v5, "iBsttaunoo.ctnL"

    const/4 v9, 0x7

    const-string v5, "i.atotoooButncL"

    const-string v5, "Button.Location"

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string v6, "aaoiibeMcL.mtd"

    const-string v6, "iLdmneao.itcMa"

    const/4 v9, 0x0

    const-string v6, "Media.Location"

    const/4 v9, 0x5

    const/4 v8, 0x5

    const-string v7, "anLecousaeit.Mso"

    const-string v7, "cL.eosetsMnoaagi"

    const-string/jumbo v7, "sL.eciMpaoongaet"

    const-string v7, "Message.Location"

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-eqz v4, :cond_0

    const/4 v9, 0x2

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x3

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->x()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-nez v4, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->c(Landroid/content/Context;)Landroid/widget/TextView;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    goto/16 :goto_0

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    if-eqz v4, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x2

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->F()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-nez v4, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->e(Landroid/content/Context;)Landroid/widget/TextView;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v8, 0x2

    const/4 v9, 0x6

    goto :goto_0

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v6, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-eqz v4, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->h()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-nez v4, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->a(Landroid/content/Context;)Landroid/widget/ImageView;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v8, 0x4

    or-int/2addr v9, v8

    goto :goto_0

    :cond_2
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-eqz v1, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x1

    invoke-virtual {v1}, Lcom/tencent/android/tpush/inappmessage/d;->f()I

    move-result v1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-lez v1, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->d(Landroid/content/Context;)Landroid/view/View;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    if-eqz v1, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_3
    :goto_0
    const/4 v9, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    const/4 v4, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v1, v4}, Lcom/tencent/android/tpush/inappmessage/d;->a(I)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x0

    if-eqz v4, :cond_4

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v8, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->x()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x3

    if-nez v4, :cond_4

    const/4 v9, 0x3

    const/4 v8, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->c(Landroid/content/Context;)Landroid/widget/TextView;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x5

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    goto/16 :goto_1

    :cond_4
    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x5

    if-eqz v4, :cond_5

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->F()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x7

    if-nez v4, :cond_5

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->e(Landroid/content/Context;)Landroid/widget/TextView;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    goto :goto_1

    :cond_5
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v6, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-eqz v4, :cond_6

    const/4 v9, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v8, 0x7

    xor-int/2addr v9, v8

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->h()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-nez v4, :cond_6

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->a(Landroid/content/Context;)Landroid/widget/ImageView;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x3

    goto :goto_1

    :cond_6
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-eqz v1, :cond_7

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpush/inappmessage/d;->f()I

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-lez v1, :cond_7

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->d(Landroid/content/Context;)Landroid/view/View;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x0

    if-eqz v1, :cond_7

    const/4 v9, 0x3

    const/4 v8, 0x7

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_7
    :goto_1
    const/4 v8, 0x4

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    const/4 v4, 0x3

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v1, v4}, Lcom/tencent/android/tpush/inappmessage/d;->a(I)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-eqz v4, :cond_8

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x4

    const/4 v8, 0x2

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->x()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v9, 0x4

    const/4 v8, 0x5

    if-nez v4, :cond_8

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->c(Landroid/content/Context;)Landroid/widget/TextView;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    goto/16 :goto_2

    :cond_8
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    if-eqz v4, :cond_9

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->F()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x3

    if-nez v4, :cond_9

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->e(Landroid/content/Context;)Landroid/widget/TextView;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    goto :goto_2

    :cond_9
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v6, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-eqz v4, :cond_a

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v4}, Lcom/tencent/android/tpush/inappmessage/d;->h()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    if-nez v4, :cond_a

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v8, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->a(Landroid/content/Context;)Landroid/widget/ImageView;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    goto :goto_2

    :cond_a
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-eqz v1, :cond_b

    const/4 v9, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x4

    const/4 v8, 0x4

    invoke-virtual {v1}, Lcom/tencent/android/tpush/inappmessage/d;->f()I

    move-result v1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-lez v1, :cond_b

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->d(Landroid/content/Context;)Landroid/view/View;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-eqz v1, :cond_b

    const/4 v8, 0x5

    shl-int/2addr v9, v8

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_b
    :goto_2
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    const/4 v4, 0x4

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v1, v4}, Lcom/tencent/android/tpush/inappmessage/d;->a(I)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-eqz v3, :cond_c

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x7

    const/4 v8, 0x1

    invoke-virtual {v3}, Lcom/tencent/android/tpush/inappmessage/d;->x()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v9, 0x4

    const/4 v8, 0x4

    if-nez v3, :cond_c

    const/4 v9, 0x7

    const/4 v8, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->c(Landroid/content/Context;)Landroid/widget/TextView;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto/16 :goto_3

    :cond_c
    const/4 v9, 0x5

    invoke-virtual {v7, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eqz v3, :cond_d

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v3}, Lcom/tencent/android/tpush/inappmessage/d;->F()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    if-nez v3, :cond_d

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->e(Landroid/content/Context;)Landroid/widget/TextView;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    goto :goto_3

    :cond_d
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v6, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    if-eqz v3, :cond_e

    const/4 v8, 0x7

    shl-int/2addr v9, v8

    iget-object v3, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v3}, Lcom/tencent/android/tpush/inappmessage/d;->h()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-nez v3, :cond_e

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->a(Landroid/content/Context;)Landroid/widget/ImageView;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x2

    const/4 v8, 0x3

    goto :goto_3

    :cond_e
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-virtual {v5, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-eqz v1, :cond_f

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v1}, Lcom/tencent/android/tpush/inappmessage/d;->f()I

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-lez v1, :cond_f

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/inappmessage/h;->d(Landroid/content/Context;)Landroid/view/View;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-eqz v1, :cond_f

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v2, v1}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    :cond_f
    :goto_3
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/inappmessage/h;->b(Landroid/widget/RelativeLayout;)Landroid/widget/RelativeLayout;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v0, v2}, Landroid/widget/ScrollView;->addView(Landroid/view/View;)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {p1, v0}, Landroid/view/ViewGroup;->addView(Landroid/view/View;)V

    const/4 v9, 0x5

    return-void
.end method

.method protected c()Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpush/inappmessage/d;->e()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x2

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    return v1
.end method
