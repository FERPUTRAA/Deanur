.class Lcom/tencent/android/tpush/inappmessage/h$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/view/View$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/inappmessage/h;->d(Landroid/content/Context;)Landroid/view/View;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/inappmessage/h;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/inappmessage/h;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public onClick(Landroid/view/View;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~ts@ v1Moa @@4my~@ @~@u~@i~b@d@/ ~ i@ ~o~f~Kbf@o~~ c~~ o @~ -~tiob@S~@@ ~~so  l~/@@rl@.n @~~  @~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object p1, p1, Lcom/tencent/android/tpush/inappmessage/h;->f:Landroid/content/Intent;

    const/4 v3, 0x6

    const-string v0, "dipmptseintsae__cvumn"

    const-string/jumbo v0, "iss_mtnnpat_pucdeeiv_"

    const/4 v3, 0x4

    const-string/jumbo v0, "naevosndt_i_ipoptm_ue"

    const-string/jumbo v0, "inapp_custom_event_id"

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v1, "NMSNAbGREE_IE"

    const-string v1, "MG_mIREESNEAN"

    const/4 v3, 0x1

    const-string v1, "EESMRIuNNGE_A"

    const-string v1, "INNER_MESSAGE"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p1, Lcom/tencent/android/tpush/inappmessage/h;->f:Landroid/content/Intent;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object p1, p1, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->m()I

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v1, "dtpt_onp__teeniuobivn"

    const-string/jumbo v1, "tvn_obiodn_tteu_npipe"

    const/4 v3, 0x6

    const-string/jumbo v1, "ntpn_nevqi_tuieadp_ot"

    const-string/jumbo v1, "inapp_button_event_id"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x7

    iget-object v0, v0, Lcom/tencent/android/tpush/inappmessage/h;->f:Landroid/content/Intent;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/stat/ServiceStat;->appReportNotificationClicked(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    iget-object p1, p1, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/d;->n()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, v0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpush/inappmessage/d;->d()I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eq v0, v1, :cond_3

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x6

    move v2, v1

    move v2, v1

    const/4 v3, 0x7

    if-eq v0, v1, :cond_2

    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-eq v0, v1, :cond_1

    const/4 v3, 0x0

    const/4 p1, 0x4

    const/4 v3, 0x1

    or-int/2addr v2, p1

    const/4 v3, 0x1

    if-eq v0, p1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/inappmessage/h;->a(Lcom/tencent/android/tpush/inappmessage/h;)V

    const/4 v2, 0x4

    const/4 v3, 0x0

    goto :goto_0

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/inappmessage/h;->b(Lcom/tencent/android/tpush/inappmessage/h;Ljava/lang/String;)V

    const/4 v3, 0x4

    goto :goto_0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/inappmessage/h;->a(Lcom/tencent/android/tpush/inappmessage/h;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    goto :goto_0

    :cond_3
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/a;->cancel()V

    :goto_0
    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpush/inappmessage/a;->cancel()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object p1, p1, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/inappmessage/h$1;->a:Lcom/tencent/android/tpush/inappmessage/h;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object p1, p1, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v0}, Landroid/app/Activity;->overridePendingTransition(II)V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method
