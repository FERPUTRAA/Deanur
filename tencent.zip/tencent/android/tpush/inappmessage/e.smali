.class public Lcom/tencent/android/tpush/inappmessage/e;
.super Landroid/view/View;


# instance fields
.field private a:Landroid/graphics/Paint;

.field private b:Landroid/graphics/Paint;

.field private c:Landroid/graphics/Paint;

.field private d:F

.field private e:F

.field private f:F

.field private g:F

.field private h:F

.field private i:Z


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Landroid/view/View;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    new-instance p1, Landroid/graphics/Paint;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/e;->a:Landroid/graphics/Paint;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    new-instance p1, Landroid/graphics/Paint;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/e;->b:Landroid/graphics/Paint;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    new-instance p1, Landroid/graphics/Paint;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p1}, Landroid/graphics/Paint;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/e;->c:Landroid/graphics/Paint;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-boolean p1, p0, Lcom/tencent/android/tpush/inappmessage/e;->i:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/inappmessage/e;->a()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method private a()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " bs@s~~@ ~ov~ ~ai@.o~ ~  ~@c~oo~ ~@@@m @~4@d b oM@y@@@@~@t@u/b l-~@~iff~/   lSoK ~~n ~1~~@i@rt@ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->a:Landroid/graphics/Paint;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v1, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->a:Landroid/graphics/Paint;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    const v2, -0x222223

    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->a:Landroid/graphics/Paint;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/high16 v2, 0x40000000    # 2.0f

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v4, 0x0

    or-int/2addr v5, v4

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->a:Landroid/graphics/Paint;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    sget-object v3, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->b:Landroid/graphics/Paint;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->b:Landroid/graphics/Paint;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const v3, -0x666667

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0, v3}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->b:Landroid/graphics/Paint;

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->b:Landroid/graphics/Paint;

    const/4 v5, 0x2

    sget-object v2, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->c:Landroid/graphics/Paint;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setAntiAlias(Z)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->c:Landroid/graphics/Paint;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/high16 v1, -0x1000000

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v4, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->c:Landroid/graphics/Paint;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/high16 v1, 0x40400000    # 3.0f

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->c:Landroid/graphics/Paint;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v1, Landroid/graphics/Paint$Style;->FILL_AND_STROKE:Landroid/graphics/Paint$Style;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    const/4 v5, 0x1

    sget v0, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp30:I

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    int-to-float v0, v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    iput v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->d:F

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    const v1, 0x3eaaaaab

    const/4 v5, 0x2

    mul-float v2, v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput v2, p0, Lcom/tencent/android/tpush/inappmessage/e;->e:F

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    const v2, 0x3f2aaaab

    const/4 v5, 0x7

    const/4 v4, 0x1

    mul-float v3, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput v3, p0, Lcom/tencent/android/tpush/inappmessage/e;->g:F

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    mul-float/2addr v1, v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    iput v1, p0, Lcom/tencent/android/tpush/inappmessage/e;->f:F

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    mul-float/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    iput v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->h:F

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    return-void
.end method


# virtual methods
.method protected onDraw(Landroid/graphics/Canvas;)V
    .locals 13

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x0

    invoke-super {p0, p1}, Landroid/view/View;->onDraw(Landroid/graphics/Canvas;)V

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x6

    iget-boolean v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->i:Z

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x1

    if-eqz v0, :cond_0

    const/4 v12, 0x2

    const/4 v11, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->b:Landroid/graphics/Paint;

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x2

    goto :goto_0

    :cond_0
    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/e;->a:Landroid/graphics/Paint;

    :goto_0
    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v1

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    int-to-float v1, v1

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x4

    const/high16 v2, 0x40000000    # 2.0f

    const/4 v11, 0x6

    move v12, v11

    div-float/2addr v1, v2

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v3

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x2

    int-to-float v3, v3

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x7

    div-float/2addr v3, v2

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v4

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x5

    int-to-float v4, v4

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x1

    div-float/2addr v4, v2

    const/4 v12, 0x4

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x4

    sub-float/2addr v4, v2

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {p1, v1, v3, v4, v0}, Landroid/graphics/Canvas;->drawCircle(FFFLandroid/graphics/Paint;)V

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x3

    iget v6, p0, Lcom/tencent/android/tpush/inappmessage/e;->e:F

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x3

    iget v7, p0, Lcom/tencent/android/tpush/inappmessage/e;->f:F

    const/4 v12, 0x0

    iget v8, p0, Lcom/tencent/android/tpush/inappmessage/e;->g:F

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x4

    iget v9, p0, Lcom/tencent/android/tpush/inappmessage/e;->h:F

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x3

    iget-object v10, p0, Lcom/tencent/android/tpush/inappmessage/e;->c:Landroid/graphics/Paint;

    move-object v5, p1

    move-object v5, p1

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-virtual/range {v5 .. v10}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const/4 v11, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x4

    iget v1, p0, Lcom/tencent/android/tpush/inappmessage/e;->g:F

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x4

    iget v2, p0, Lcom/tencent/android/tpush/inappmessage/e;->f:F

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget v3, p0, Lcom/tencent/android/tpush/inappmessage/e;->e:F

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x2

    iget v4, p0, Lcom/tencent/android/tpush/inappmessage/e;->h:F

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x4

    iget-object v5, p0, Lcom/tencent/android/tpush/inappmessage/e;->c:Landroid/graphics/Paint;

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    const/4 v12, 0x3

    const/4 v11, 0x4

    return-void
.end method

.method protected onMeasure(II)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-super {p0, p1, p1}, Landroid/view/View;->onMeasure(II)V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    iget p1, p0, Lcom/tencent/android/tpush/inappmessage/e;->d:F

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    float-to-int p2, p1

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    float-to-int p1, p1

    const/4 v1, 0x6

    const/4 v0, 0x1

    invoke-virtual {p0, p2, p1}, Landroid/view/View;->setMeasuredDimension(II)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-boolean v1, p0, Lcom/tencent/android/tpush/inappmessage/e;->i:Z

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    return v1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-ne v0, v1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput-boolean p1, p0, Lcom/tencent/android/tpush/inappmessage/e;->i:Z

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/inappmessage/e;->performClick()Z

    const/4 v3, 0x5

    return v1

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-super {p0, p1}, Landroid/view/View;->onTouchEvent(Landroid/view/MotionEvent;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    return p1
.end method

.method public performClick()Z
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-super {p0}, Landroid/view/View;->performClick()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method
