.class public Lcom/tencent/android/tpush/inappmessage/g$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/inappmessage/g;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# static fields
.field public static a:Lcom/tencent/android/tpush/inappmessage/g;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    new-instance v0, Lcom/tencent/android/tpush/inappmessage/g;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {v0}, Lcom/tencent/android/tpush/inappmessage/g;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    sput-object v0, Lcom/tencent/android/tpush/inappmessage/g$a;->a:Lcom/tencent/android/tpush/inappmessage/g;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method
