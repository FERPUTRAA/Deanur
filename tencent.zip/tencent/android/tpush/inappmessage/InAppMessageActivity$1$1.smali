.class Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;->TRun()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/util/HashMap;

.field final synthetic b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;Ljava/util/HashMap;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1$1;->a:Ljava/util/HashMap;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    :try_start_0
    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " os~m @ @lt@@ br Sol@ o 1~~@@~~~@f@o4~~ @ty~ b~ii@ o@ .@ /~i-@K~  ~@M ~~ a~c@@~do~~~@n~bvu /~f@s"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    new-instance v0, Lcom/tencent/android/tpush/inappmessage/a/a;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string/jumbo v1, "nucmtp_pesre"

    const-string/jumbo v1, "oesnreptucp_"

    const/4 v6, 0x0

    const-string/jumbo v1, "toerounpp_ec"

    const-string v1, "center_popup"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1$1;->a:Ljava/util/HashMap;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string v3, "i_gsebasem"

    const-string/jumbo v3, "issmgamee_"

    const/4 v6, 0x3

    const-string v3, "dsmi_euseg"

    const-string/jumbo v3, "message_id"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-direct {v0, v1, v2, v3}, Lcom/tencent/android/tpush/inappmessage/a/a;-><init>(Ljava/lang/String;Ljava/util/Map;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    new-instance v1, Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-direct {v1, v0}, Lcom/tencent/android/tpush/inappmessage/d;-><init>(Lcom/tencent/android/tpush/inappmessage/a/a;)V

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;

    const/4 v6, 0x4

    iget-object v0, v0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    new-instance v2, Lcom/tencent/android/tpush/inappmessage/c;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v3, v3, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v3}, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->a(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;)Landroid/content/Context;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    check-cast v3, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v4, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v4, v4, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    const/4 v6, 0x2

    invoke-static {v4}, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->b(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;)Landroid/content/Intent;

    move-result-object v4

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-direct {v2, v3, v1, v4}, Lcom/tencent/android/tpush/inappmessage/c;-><init>(Landroid/app/Activity;Lcom/tencent/android/tpush/inappmessage/d;Landroid/content/Intent;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->a(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;Lcom/tencent/android/tpush/inappmessage/c;)Lcom/tencent/android/tpush/inappmessage/c;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;

    const/4 v5, 0x3

    move v6, v5

    iget-object v0, v0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    const/4 v5, 0x1

    move v6, v5

    invoke-static {v0}, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->c(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;)Lcom/tencent/android/tpush/inappmessage/c;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0}, Landroid/app/Dialog;->show()V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v1, v1, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->b(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;)Landroid/content/Intent;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/stat/ServiceStat;->appReportSDKReceived(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string/jumbo v2, "nenuir poCiPte op:"

    const-string v2, ":no oiuer eipttCPn"

    const/4 v6, 0x0

    const-string v2, "eitrinoeq:n  utPpC"

    const-string/jumbo v2, "init CenterPopup :"

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string/jumbo v1, "pAsbicttsneesviagMpA"

    const-string v1, "AgytpbeMasvApenticsi"

    const/4 v6, 0x1

    const-string v1, "etAmssytMIAnvciigpea"

    const-string v1, "InAppMessageActivity"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    return-void
.end method
