.class public Lcom/tencent/android/tpush/inappmessage/c;
.super Lcom/tencent/android/tpush/inappmessage/h;


# direct methods
.method public constructor <init>(Landroid/app/Activity;Lcom/tencent/android/tpush/inappmessage/d;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2, p3}, Lcom/tencent/android/tpush/inappmessage/h;-><init>(Landroid/app/Activity;Lcom/tencent/android/tpush/inappmessage/d;Landroid/content/Intent;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method protected b()Landroid/widget/RelativeLayout$LayoutParams;
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "~@si@~o @4@~l yrn@bv~ ~ t~~  @ ~@f~~@@.@Kiba@u@M  oS~ @o~ /~1t@ odc@~ms ~~@-bo o~~@@ ~@i~~ @f l~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v10, 0x2

    const/4 v9, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->getDisplaySize(Landroid/app/Activity;)Landroid/graphics/Point;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v9, 0x4

    shl-int/2addr v10, v9

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v2}, Lcom/tencent/android/tpush/inappmessage/d;->a()I

    move-result v2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    int-to-float v2, v2

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/inappmessage/a;->b:Landroid/app/Activity;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/inappmessage/h;->d:Lcom/tencent/android/tpush/inappmessage/d;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-virtual {v3}, Lcom/tencent/android/tpush/inappmessage/d;->b()I

    move-result v3

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    int-to-float v3, v3

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v2

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    xor-int/2addr v10, v9

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x5

    const-string v4, "e zm=sxs."

    const-string v4, "e=s. zisx"

    const/4 v10, 0x4

    const-string/jumbo v4, "zs.io=  x"

    const-string/jumbo v4, "size.x = "

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x2

    iget v4, v0, Landroid/graphics/Point;->x:I

    const/4 v10, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x2

    const-string/jumbo v4, "iz,mes  =y"

    const/4 v10, 0x2

    const-string/jumbo v4, "zy=sebi., "

    const-string v4, ", size.y ="

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    iget v4, v0, Landroid/graphics/Point;->y:I

    const/4 v9, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const-string v4, "hdiwt u="

    const-string/jumbo v4, "wih=o dt"

    const/4 v10, 0x0

    const-string/jumbo v4, "w td hip"

    const-string/jumbo v4, "width = "

    const/4 v10, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-string/jumbo v4, "iht, eghq "

    const-string v4, ", height ="

    const/4 v10, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x4

    const-string v4, "bnspurC oPtp"

    const-string/jumbo v4, "oCturbpP pen"

    const/4 v10, 0x3

    const-string/jumbo v4, "pPemeCutno p"

    const-string v4, "Center Popup"

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-static {v4, v3}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x7

    iget v3, v0, Landroid/graphics/Point;->x:I

    const/4 v9, 0x2

    const/4 v10, 0x6

    sget v5, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp20:I

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x6

    sub-int/2addr v3, v5

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget v0, v0, Landroid/graphics/Point;->y:I

    const/4 v10, 0x0

    const/4 v9, 0x1

    sub-int/2addr v0, v5

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x4

    int-to-double v5, v1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    int-to-double v7, v2

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    div-double v7, v5, v7

    const/4 v10, 0x1

    if-le v1, v3, :cond_0

    const/4 v9, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    div-double/2addr v5, v7

    const/4 v10, 0x0

    const/4 v9, 0x6

    double-to-int v5, v5

    const/4 v10, 0x0

    const/4 v9, 0x4

    if-ge v5, v0, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x5

    int-to-double v1, v3

    const/4 v9, 0x7

    move v10, v9

    div-double/2addr v1, v7

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    double-to-int v2, v1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x4

    move v1, v3

    move v1, v3

    :cond_0
    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    if-le v2, v0, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x1

    int-to-double v5, v2

    const/4 v9, 0x1

    const/4 v9, 0x3

    mul-double/2addr v5, v7

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x5

    double-to-int v5, v5

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-ge v5, v3, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    int-to-double v1, v0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    mul-double/2addr v1, v7

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x0

    double-to-int v1, v1

    const/4 v10, 0x6

    const/4 v9, 0x4

    goto :goto_0

    :cond_1
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x0

    move v0, v2

    move v0, v2

    const/4 v10, 0x7

    move v0, v2

    move v0, v2

    :goto_0
    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    const-string/jumbo v3, "pAaMosu gLdrmaP a=otnyupw Its "

    const-string/jumbo v3, "p d g uw=htuyLIaop PMasrantAsm"

    const/4 v10, 0x1

    const-string/jumbo v3, "moiIsbPawn=LrdtMg aas h puAyp "

    const-string v3, "InAppMsg LayoutParams width = "

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-string v3, " eg h uipt,"

    const-string v3, "g ,hi =pet "

    const/4 v10, 0x1

    const-string v3, " t= i ephh,"

    const-string v3, ", height = "

    const/4 v10, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x6

    invoke-static {v4, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    new-instance v0, Landroid/widget/RelativeLayout$LayoutParams;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x3

    const/4 v2, -0x2

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-direct {v0, v1, v2}, Landroid/widget/RelativeLayout$LayoutParams;-><init>(II)V

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    const/16 v1, 0xd

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    const/4 v2, -0x1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/widget/RelativeLayout$LayoutParams;->addRule(II)V

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x7

    return-object v0
.end method

.method public bridge synthetic cancel()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-super {p0}, Lcom/tencent/android/tpush/inappmessage/a;->cancel()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method d()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return v0
.end method

.method protected e()V
    .locals 4

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/app/Dialog;->getWindow()Landroid/view/Window;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lru/oleg543/utils/Window;->addFlags(Landroid/view/Window;I)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    const v1, 0x3f333333    # 0.7f

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/view/Window;->setDimAmount(F)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method
