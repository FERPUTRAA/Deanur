.class public Lcom/tencent/android/tpush/inappmessage/i;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/app/Activity;)I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, ". sb4 ~~yo  ~~li@ @/i@ S @ ~~b-c~~taf~~@~o@i~d@ ~l f~~~@@~Mon@~ @@uov  @1~~@~@ t@b~K r @@o/m@ s@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/view/Window;->getAttributes()Landroid/view/WindowManager$LayoutParams;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget p0, p0, Landroid/view/WindowManager$LayoutParams;->flags:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/16 v0, 0x400

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    and-int/2addr p0, v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    if-ne p0, v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 p0, 0x1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 p0, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz p0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    const p0, 0x1030011

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    return p0

    :cond_1
    const/4 v2, 0x5

    const/4 v1, 0x0

    const p0, 0x1030010

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return p0
.end method

.method public static a(I)Landroid/graphics/drawable/shapes/Shape;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/16 v0, 0x8

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-array v0, v0, [F

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    int-to-float p0, p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    aput p0, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    aput p0, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x2

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    aput p0, v0, v1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x3

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    aput p0, v0, v1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x4

    const/4 v3, 0x3

    const/4 v2, 0x6

    aput p0, v0, v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/4 v1, 0x5

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    aput p0, v0, v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v1, 0x6

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    aput p0, v0, v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x7

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    aput p0, v0, v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-instance p0, Landroid/graphics/drawable/shapes/RoundRectShape;

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    xor-int/2addr v2, v1

    const/4 v3, 0x1

    invoke-direct {p0, v0, v1, v1}, Landroid/graphics/drawable/shapes/RoundRectShape;-><init>([FLandroid/graphics/RectF;[F)V

    const/4 v3, 0x7

    return-object p0
.end method

.method public static a(J)Landroid/view/animation/Animation;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v0, Landroid/view/animation/AlphaAnimation;

    const/4 v3, 0x7

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/high16 v2, 0x3f800000    # 1.0f

    const/4 v4, 0x4

    invoke-direct {v0, v1, v2}, Landroid/view/animation/AlphaAnimation;-><init>(FF)V

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v1, Landroid/view/animation/DecelerateInterpolator;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v1}, Landroid/view/animation/DecelerateInterpolator;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Landroid/view/animation/Animation;->setInterpolator(Landroid/view/animation/Interpolator;)V

    const/4 v4, 0x1

    invoke-virtual {v0, p0, p1}, Landroid/view/animation/Animation;->setDuration(J)V

    const/4 v4, 0x2

    return-object v0
.end method

.method public static a(Landroid/view/View;IZ)V
    .locals 3
    .param p0    # Landroid/view/View;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->init(Landroid/content/Context;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    new-instance v0, Landroid/graphics/drawable/ShapeDrawable;

    const/4 v2, 0x2

    invoke-direct {v0}, Landroid/graphics/drawable/ShapeDrawable;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    if-eqz p2, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    sget p2, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dp20:I

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 p2, 0x0

    :goto_0
    const/4 v1, 0x5

    move v2, v1

    invoke-static {p2}, Lcom/tencent/android/tpush/inappmessage/i;->a(I)Landroid/graphics/drawable/shapes/Shape;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, p2}, Landroid/graphics/drawable/ShapeDrawable;->setShape(Landroid/graphics/drawable/shapes/Shape;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Landroid/graphics/drawable/ShapeDrawable;->getPaint()Landroid/graphics/Paint;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p2, p1}, Landroid/graphics/Paint;->setColor(I)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p0, v0}, Landroidx/core/view/k1;->I1(Landroid/view/View;Landroid/graphics/drawable/Drawable;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-void
.end method
