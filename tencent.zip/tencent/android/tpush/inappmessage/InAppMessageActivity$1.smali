.class Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->a(Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    const/4 v1, 0x2

    const/4 v0, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v0, 0x1

    and-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 24

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    :try_start_0
    new-instance v0, Ljava/util/HashMap;

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    new-instance v2, Lorg/json/JSONObject;

    iget-object v3, v1, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;->a:Ljava/lang/String;

    invoke-direct {v2, v3}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const-string/jumbo v3, "tisdostpnns"

    const-string/jumbo v3, "nosetpdnist"

    const-string v3, "eitmCosnnpt"

    const-string v3, "dispContent"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v2

    if-nez v2, :cond_0

    return-void

    :cond_0
    const-string v3, "emlpoteTptem"

    const-string v3, "eepmltetpmTa"

    const-string v3, "Teapebltpmye"

    const-string/jumbo v3, "templateType"

    const/4 v4, 0x1

    invoke-virtual {v2, v3, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v3

    const-string/jumbo v5, "teyeaMuoests.gtapepml"

    const-string v5, "asepom.e.eltsegaytptM"

    const-string v5, "gMsept.pmtpealyaes.et"

    const-string v5, "Message.template.type"

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v5, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v3, "tbaltlLeqi"

    const-string/jumbo v3, "ttbllbaiLe"

    const-string v3, "aeslebLitt"

    const-string/jumbo v3, "titleLabel"

    invoke-virtual {v2, v3}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    const-string/jumbo v6, "laumnimng"

    const-string/jumbo v6, "nengimual"

    const-string/jumbo v6, "tmgnoanil"

    const-string v6, "alignment"

    const-string v7, "blsep"

    const-string/jumbo v7, "yspel"

    const-string/jumbo v7, "tuyse"

    const-string/jumbo v7, "style"

    const-string v8, "fton"

    const-string/jumbo v8, "otnf"

    const-string/jumbo v8, "tofn"

    const-string v8, "font"

    const-string/jumbo v9, "zsei"

    const-string/jumbo v9, "izse"

    const-string v9, "eisz"

    const-string/jumbo v9, "size"

    const-string/jumbo v10, "olrqc"

    const-string/jumbo v10, "ocprl"

    const-string v10, "color"

    const-string v11, "Haesevilq stI"

    const-string/jumbo v11, "l sIieHv tsae"

    const-string v11, "eesIvilHt a s"

    const-string v11, "Title Is Have"

    const-string/jumbo v12, "tmimlnoc"

    const-string/jumbo v12, "nlimtooc"

    const-string v12, "aontoloi"

    const-string/jumbo v12, "location"

    const/16 v13, 0x14

    const-string/jumbo v14, "txet"

    const-string/jumbo v14, "xett"

    const-string v14, "ettx"

    const-string/jumbo v14, "text"

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    if-eqz v3, :cond_1

    :try_start_1
    invoke-virtual {v3, v14, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v3, v10, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v3, v9, v13}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v17

    invoke-virtual {v3, v8, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const/4 v1, 0x0

    invoke-virtual {v3, v7, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v18

    const/16 v1, 0x11

    invoke-virtual {v3, v6, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v19

    const/4 v1, 0x0

    invoke-virtual {v3, v12, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v3

    const-string v1, "eoTtTbexl."

    const-string/jumbo v1, "t.TeoileTx"

    const-string v1, "eti.xtuTTl"

    const-string v1, "Title.Text"

    invoke-virtual {v0, v1, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v1, "r.boolipTlt"

    const-string v1, ".ilTtbloore"

    const-string v1, "Title.Color"

    invoke-virtual {v0, v1, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "eTtzl.uieS"

    const-string/jumbo v1, "itlSzieeqT"

    const-string v1, "Title.Size"

    invoke-static/range {v17 .. v17}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v0, v1, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v1, "ltlg.TnpiiA"

    const-string/jumbo v1, "tlsleii.Ang"

    const-string v1, "Title.Align"

    invoke-static/range {v19 .. v19}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v0, v1, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v1, "qiametPliTt"

    const-string/jumbo v1, "il.aPitTqte"

    const-string v1, "e.Tlotiatin"

    const-string v1, "Title.Paint"

    invoke-virtual {v0, v1, v13}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "icT.pbeysaeefl"

    const-string v1, "epsftyieacT.le"

    const-string v1, "Title.Typeface"

    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v0, v1, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string/jumbo v3, "mlnci.uToaotti"

    const-string/jumbo v3, "tLim.ctioTnola"

    const-string/jumbo v3, "laocLinpTo.itt"

    const-string v3, "Title.Location"

    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v0, v11, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_0

    :cond_1
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v0, v11, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_0
    const-string/jumbo v1, "lnnebetLqcao"

    const-string v1, "cealobentLon"

    const-string v1, "contentLabel"

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const-string/jumbo v3, "sesv egesaM asI"

    const-string v3, "Message Is Have"

    if-eqz v1, :cond_2

    :try_start_2
    invoke-virtual {v1, v14, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v1, v10, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/16 v11, 0x14

    invoke-virtual {v1, v9, v11}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v9

    invoke-virtual {v1, v8, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x0

    invoke-virtual {v1, v7, v11}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v7

    const/16 v13, 0x11

    invoke-virtual {v1, v6, v13}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v6

    invoke-virtual {v1, v12, v11}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    const-string/jumbo v11, "zSbmeegasi.e"

    const-string v11, "egze.beiSsaM"

    const-string v11, "as.zoesegMSe"

    const-string v11, "Message.Size"

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v9

    invoke-virtual {v0, v11, v9}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v9, "snaieblMesgA."

    const-string v9, "Message.Align"

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v6

    invoke-virtual {v0, v9, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v6, "geassPueuaiM."

    const-string/jumbo v6, "tPMe.susaagie"

    const-string v6, ".aMngaepsPest"

    const-string v6, "Message.Paint"

    invoke-virtual {v0, v6, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v6, "ypafTsgsqaepe.ee"

    const-string v6, "aecgasypee.eTspf"

    const-string v6, "eesyepcsagf.MaeT"

    const-string v6, "Message.Typeface"

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v0, v6, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v6, ".MsmatqexeTg"

    const-string v6, "aeTteMseq.xg"

    const-string v6, "gxsaoetMeseT"

    const-string v6, "Message.Text"

    invoke-virtual {v0, v6, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v5, "os.oebgaCMsle"

    const-string/jumbo v5, "seslos.CaMego"

    const-string/jumbo v5, "rCoMg.uaeloes"

    const-string v5, "Message.Color"

    invoke-virtual {v0, v5, v10}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v5, "Message.Location"

    invoke-virtual {v0, v1, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_1

    :cond_2
    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v0, v3, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_1
    const-string v1, "ewadmiipe"

    const-string/jumbo v1, "mediaView"

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const-string/jumbo v3, "rlu"

    const-string/jumbo v3, "rlu"

    const-string/jumbo v3, "lur"

    const-string/jumbo v3, "url"

    const-string v5, "eesdIHaaqmM i"

    const-string v5, "eMemsava diHI"

    const-string v5, "eis MHvaeaIs "

    const-string v5, "Media Is Have"

    if-eqz v1, :cond_3

    :try_start_3
    invoke-virtual {v1, v3, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const-string/jumbo v7, "tihmd"

    const-string/jumbo v7, "thdio"

    const-string/jumbo v7, "idwho"

    const-string/jumbo v7, "width"
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    move-object/from16 v8, p0

    move-object/from16 v8, p0

    move-object/from16 v8, p0

    move-object/from16 v8, p0

    :try_start_4
    iget-object v9, v8, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    invoke-static {v9}, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->a(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;)Landroid/content/Context;

    move-result-object v9

    const/high16 v10, 0x437f0000    # 255.0f

    invoke-static {v9, v10}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v9

    invoke-virtual {v1, v7, v9}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v7

    const-string/jumbo v9, "igthhb"

    const-string/jumbo v9, "tghhib"

    const-string/jumbo v9, "ughteh"

    const-string v9, "height"

    iget-object v10, v8, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    invoke-static {v10}, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->a(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;)Landroid/content/Context;

    move-result-object v10

    const/high16 v11, 0x43570000    # 215.0f

    invoke-static {v10, v11}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dipTopx(Landroid/content/Context;F)I

    move-result v10

    invoke-virtual {v1, v9, v10}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v9

    const/4 v10, 0x0

    invoke-virtual {v1, v12, v10}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    const-string v10, "Milaurupd"

    const-string v10, "drlauMu i"

    const-string/jumbo v10, "rea lMuiq"

    const-string v10, "Media url"

    invoke-virtual {v0, v10, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v6, "disiaht pwM"

    const-string v6, "i eaMdipwth"

    const-string/jumbo v6, "twima dedhM"

    const-string v6, "Media width"

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v0, v6, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v6, " eigoheMdqh"

    const-string v6, "eihge hMqad"

    const-string v6, "hhgMeb eiia"

    const-string v6, "Media heigh"

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v0, v6, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const-string v6, "iLMan.uicotsda"

    const-string v6, ".isMtiLanocaod"

    const-string v6, "Mcntdoepaa.iiL"

    const-string v6, "Media.Location"

    invoke-virtual {v0, v1, v6}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    invoke-virtual {v0, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    :cond_3
    move-object/from16 v8, p0

    move-object/from16 v8, p0

    move-object/from16 v8, p0

    move-object/from16 v8, p0

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    invoke-virtual {v0, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :goto_2
    const-string/jumbo v1, "loCsnostqBmw"

    const-string/jumbo v1, "lsBmooentwsC"

    const-string v1, "CnsswheltBoo"

    const-string/jumbo v1, "showCloseBtn"

    const/4 v5, 0x1

    invoke-virtual {v2, v1, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    const-string/jumbo v5, "nltmtoosoeu "

    const-string/jumbo v5, "oottobesu ln"

    const-string v5, " lbooeCtostu"

    const-string v5, "Close button"

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v0, v5, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "Btntsbsocb"

    const-string/jumbo v1, "ttBmnbsocs"

    const-string v1, "customBtns"

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const-string/jumbo v5, "ucerno"

    const-string/jumbo v5, "ucnore"

    const-string/jumbo v5, "rpoenc"

    const-string v5, "corner"

    const-string/jumbo v6, "prCbgol"

    const-string/jumbo v6, "oqgbrCo"

    const-string v6, "bgColor"

    const-string/jumbo v7, "qisont"

    const-string/jumbo v7, "oiqtna"

    const-string/jumbo v7, "toimcn"

    const-string v7, "action"

    if-eqz v1, :cond_6

    :try_start_5
    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v9

    if-lez v9, :cond_6

    const/4 v10, 0x0

    invoke-virtual {v1, v10}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v11
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    const-string/jumbo v13, "zeetotxi"

    const-string/jumbo v13, "txsiezte"

    const-string/jumbo v13, "itztebSx"

    const-string/jumbo v13, "textSize"

    const-string/jumbo v15, "totolxueC"

    const-string/jumbo v15, "textColor"

    const-string/jumbo v10, "mItbtdup"

    const-string v10, "dntmbtuI"

    const-string/jumbo v10, "qdubotnI"

    const-string v10, "buttonId"

    if-eqz v11, :cond_4

    const/4 v8, 0x0

    :try_start_6
    invoke-virtual {v11, v10, v8}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v16

    if-eqz v16, :cond_4

    invoke-virtual {v11, v6, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    invoke-virtual {v11, v14, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    invoke-virtual {v11, v15, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v19, v15

    move-object/from16 v19, v15

    move-object/from16 v19, v15

    const/16 v15, 0x14

    invoke-virtual {v11, v13, v15}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v20

    const/4 v15, 0x0

    invoke-virtual {v11, v5, v15}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v21

    invoke-virtual {v11, v12, v15}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v12

    invoke-virtual {v11, v7, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    move-object/from16 v22, v7

    move-object/from16 v22, v7

    move-object/from16 v22, v7

    move-object/from16 v22, v7

    const-string v7, "cosyeantop"

    const-string/jumbo v7, "onyaopectT"

    const-string/jumbo v7, "yoTmipnate"

    const-string v7, "actionType"

    move-object/from16 v23, v5

    move-object/from16 v23, v5

    move-object/from16 v23, v5

    move-object/from16 v23, v5

    const/4 v5, 0x0

    invoke-virtual {v11, v7, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v7

    const-string v5, "bncuoptettt.oex Ac"

    const-string/jumbo v5, "tecc btoAnxuteTt.p"

    const-string/jumbo v5, "xoTepbAc bct.tetun"

    const-string v5, "Accept button.Text"

    invoke-virtual {v0, v5, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v3, "u oukbug.ccnroaA unpecortoctBd"

    const-string/jumbo v3, "tororcuuco.cAo nBnkcdattubpeg "

    const-string/jumbo v3, "ntuar lpb dkcAeoBcng.tcpotrcou"

    const-string v3, "Accept button.Background color"

    invoke-virtual {v0, v3, v8}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v3, "btto T oqxepccet.trlAupo"

    const-string/jumbo v3, "loccp cp TuAtobrtot.eetx"

    const-string/jumbo v3, "oosobr ct.uttcpecAexT nl"

    const-string v3, "Accept button.Text color"

    invoke-virtual {v0, v3, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "Ttcm ubtnczoAsqteee itx"

    const-string/jumbo v2, "nttbeeTpqz i tutceoxcAs"

    const-string/jumbo v2, "p.Aeox osbee ziTctttutn"

    const-string v2, "Accept button.Text size"

    invoke-static/range {v20 .. v20}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v2, "nccAsbec.rntouret ot"

    const-string/jumbo v2, "ttstncroneuAcpr.ce o"

    const-string/jumbo v2, "ru ncnuAecerotbpto.t"

    const-string v2, "Accept button.corner"

    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " po.ccepdttmAbnu"

    const-string/jumbo v2, "tntmebcA.tdupc o"

    const-string/jumbo v2, "pudtbttiq Aeccn."

    const-string v2, "Accept button.id"

    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " cstct.eoAouiptotcan"

    const-string/jumbo v2, "tbcAoictant to.epcou"

    const-string v2, ".nAmtitaeocop tcncbt"

    const-string v2, "Accept button.action"

    invoke-virtual {v0, v2, v15}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const-string v3, "c.oBoLtnuoianbt"

    const-string/jumbo v3, "uiotLbnnttoc.Ba"

    const-string/jumbo v3, "octoub.itnLoaBt"

    const-string v3, "Button.Location"

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, ". eAcuuonptubcnottc"

    const-string v2, "Accept button.count"

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v2, "titcocuptonntp e.uApaybct"

    const-string/jumbo v2, "titpteutnu ectyabc.Aconpo"

    const-string/jumbo v2, "u cpAttnqpeeo.c.atbtintoc"

    const-string v2, "Accept button.action.type"

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_3

    :cond_4
    move-object/from16 v18, v2

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v23, v5

    move-object/from16 v23, v5

    move-object/from16 v23, v5

    move-object/from16 v23, v5

    move-object/from16 v22, v7

    move-object/from16 v22, v7

    move-object/from16 v22, v7

    move-object/from16 v22, v7

    move-object/from16 v19, v15

    move-object/from16 v19, v15

    move-object/from16 v19, v15

    move-object/from16 v19, v15

    :goto_3
    const/4 v2, 0x2

    if-ne v9, v2, :cond_5

    const/4 v2, 0x1

    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v1

    if-eqz v1, :cond_5

    const/4 v2, 0x0

    invoke-virtual {v1, v10, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v3

    if-eqz v3, :cond_5

    invoke-virtual {v1, v6, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v14, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    move-object/from16 v7, v19

    move-object/from16 v7, v19

    move-object/from16 v7, v19

    move-object/from16 v7, v19

    invoke-virtual {v1, v7, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/16 v8, 0x14

    invoke-virtual {v1, v13, v8}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v8

    move-object/from16 v9, v23

    move-object/from16 v9, v23

    move-object/from16 v9, v23

    move-object/from16 v9, v23

    const/4 v10, 0x0

    invoke-virtual {v1, v9, v10}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v12

    move-object/from16 v13, v22

    move-object/from16 v13, v22

    move-object/from16 v13, v22

    move-object/from16 v13, v22

    invoke-virtual {v1, v13, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v14, "cesntyTppo"

    const-string/jumbo v14, "tycpTenpoa"

    const-string/jumbo v14, "oetmyicnap"

    const-string v14, "actionType"

    invoke-virtual {v11, v14, v10}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v11

    const-string/jumbo v10, "s.uooebccqtTe t eAcxtp"

    const-string v10, " pec tesqcxcbut.tAoenT"

    const-string v10, "Accept sec button.Text"

    invoke-virtual {v0, v10, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v5, "o  esbanbc.rocdour ctlksoAuetcBgcn"

    const-string/jumbo v5, "nkscB bdctnAgoaetreccoso.cpour l u"

    const-string v5, "ag tlruueBocc tnokenrd.copbsAtu oc"

    const-string v5, "Accept sec button.Background color"

    invoke-virtual {v0, v5, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, " cApmsepenTeoo orbxltc.cct t"

    const-string v2, "boemoccro tl ttctTne.pAsc xe"

    const-string/jumbo v2, "tccoclerqoTe ob nAx epctut.t"

    const-string v2, "Accept sec button.Text color"

    invoke-virtual {v0, v2, v7}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v2, "t sispoTco.tu Aecceee szntx"

    const-string v2, "eo Aoccnpt.b Txuesztctesi e"

    const-string v2, "e Tmxetctc. tsizs otbueApcn"

    const-string v2, "Accept sec button.Text size"

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v0, v2, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "bc. ooAetnrsuccbo nreetp"

    const-string v2, ".rAsebpeburntocccnec  to"

    const-string/jumbo v2, "rcnutbAot ebreopnt.cc es"

    const-string v2, "Accept sec button.corner"

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    invoke-virtual {v0, v2, v5}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v2, "bttip uec noceA.udsc"

    const-string/jumbo v2, "od  ueubtcnc.cAiptes"

    const-string/jumbo v2, "scitAcppontbd. eutce"

    const-string v2, "Accept sec button.id"

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    invoke-virtual {v0, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v2, "pat otncqeActeioccpbu ns"

    const-string v2, "a.ntpospccnubectctoA i e"

    const-string/jumbo v2, "pcsncetoAsutt caicbe nto"

    const-string v2, "Accept sec button.action"

    invoke-virtual {v0, v2, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "Ascmpoboei qnectte pu.tnaytc."

    const-string v1, ".ntct.onqb eetttAcea upoycsip"

    const-string/jumbo v1, "scy op.pbAoutannt itecc.eoett"

    const-string v1, "Accept sec button.action.type"

    invoke-static {v11}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_4

    :cond_5
    move-object/from16 v13, v22

    move-object/from16 v13, v22

    move-object/from16 v13, v22

    move-object/from16 v13, v22

    move-object/from16 v9, v23

    move-object/from16 v9, v23

    move-object/from16 v9, v23

    goto :goto_4

    :cond_6
    move-object/from16 v18, v2

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object/from16 v17, v3

    move-object v9, v5

    move-object v9, v5

    move-object v9, v5

    move-object v9, v5

    move-object v13, v7

    move-object v13, v7

    move-object v13, v7

    move-object v13, v7

    :goto_4
    const-string/jumbo v1, "rgsaCb"

    const-string v1, "Cragbb"

    const-string v1, "bgCard"

    move-object/from16 v2, v18

    move-object/from16 v2, v18

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    if-eqz v1, :cond_7

    move-object/from16 v2, v17

    move-object/from16 v2, v17

    move-object/from16 v2, v17

    move-object/from16 v2, v17

    invoke-virtual {v1, v2, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v1, v13, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    invoke-virtual {v1, v9, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v5

    invoke-virtual {v1, v6, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const-string v4, "gldrcoukuocrnBmo"

    const-string/jumbo v4, "uoomnkograldcBcr"

    const-string v4, "Background color"

    invoke-virtual {v0, v4, v1}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "gmorkuaprBclude naig"

    const-string v1, "cgmio re nakuguBadrl"

    const-string v1, "iBrlgor quaumcadneg "

    const-string v1, "Background image url"

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v1, "rcst canbndgooiku"

    const-string v1, "dncaubotB rkngcoi"

    const-string v1, "aoomcurig nBntcda"

    const-string v1, "Background action"

    invoke-virtual {v0, v1, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string/jumbo v1, "uBakooreo ugndcrn"

    const-string v1, "enBonuud cgorackr"

    const-string v1, "dcBraboongnceu kr"

    const-string v1, "Background corner"

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_7
    const-string/jumbo v1, "idatWouputyh"

    const-string/jumbo v1, "iyutWaopdtLh"

    const-string/jumbo v1, "uidWayhpLto."

    const-string v1, "Layout.Width"

    const/16 v2, 0x12f

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const-string v1, "atqthLHyqugo."

    const-string v1, "ahiyHLu.qttgo"

    const-string/jumbo v1, "ugstahtyiL.oH"

    const-string v1, "Layout.Height"

    const/16 v2, 0x258

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v0, v1, v2}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    :try_start_7
    iget-object v2, v1, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;->b:Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    invoke-static {v2}, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;->d(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;)Landroid/os/Handler;

    move-result-object v2

    new-instance v3, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1$1;

    invoke-direct {v3, v1, v0}, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1$1;-><init>(Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity$1;Ljava/util/HashMap;)V

    invoke-virtual {v2, v3}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    goto :goto_6

    :catchall_0
    move-exception v0

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    move-object v1, v8

    goto :goto_5

    :catchall_1
    move-exception v0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    goto :goto_5

    :catchall_2
    move-exception v0

    :goto_5
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "epImppxcsdAnst e gnouMfe"

    const-string/jumbo v3, "u spfxMAgI poe:entencspd"

    const-string v3, ":ppforeugxnctM so penedA"

    const-string/jumbo v3, "unexpected for InAppMsg:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v2, "pstegbAcsMmIpytaAenv"

    const-string v2, "iAgmvpysIepatstcMenA"

    const-string v2, "InAppMessageActivity"

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_6
    return-void
.end method
