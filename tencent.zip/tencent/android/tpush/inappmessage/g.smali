.class public Lcom/tencent/android/tpush/inappmessage/g;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/inappmessage/g$a;
    }
.end annotation


# static fields
.field private static a:Landroid/content/Context;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/tencent/android/tpush/inappmessage/g;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s@1/@4@uasnmc~t@f/~o@~ lo~i~~~~@@v~@@@M o @d@ o~~@K~b@ ~ bi  ~~@-@    ~ t ~ilb@@ f.S~~~o~o y@r"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/android/tpush/inappmessage/g;->a:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    sput-object p0, Lcom/tencent/android/tpush/inappmessage/g;->a:Landroid/content/Context;

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object p0, Lcom/tencent/android/tpush/inappmessage/g$a;->a:Lcom/tencent/android/tpush/inappmessage/g;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object p0
.end method

.method private b(Lcom/tencent/android/tpush/service/protocol/j;)V
    .locals 6

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v1, p1, Lcom/tencent/android/tpush/service/protocol/j;->r:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo v2, "ougmr_pi"

    const-string/jumbo v2, "upsri_go"

    const/4 v5, 0x2

    const-string v2, "gri_ooud"

    const-string v2, "group_id"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string v1, "bsmId"

    const-string/jumbo v1, "sImmd"

    const/4 v5, 0x0

    const-string v1, "gudIs"

    const-string/jumbo v1, "msgId"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    const/4 v5, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string/jumbo v1, "ptye"

    const-string/jumbo v1, "teyp"

    const/4 v5, 0x4

    const-string/jumbo v1, "pyte"

    const-string/jumbo v1, "type"

    const/4 v5, 0x0

    const/4 v4, 0x7

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->f:J

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string/jumbo v1, "saupelnphCo"

    const-string/jumbo v1, "naslopenhuC"

    const/4 v5, 0x7

    const-string/jumbo v1, "psaunnhCqel"

    const-string/jumbo v1, "pushChannel"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/16 v2, 0x64

    const/4 v4, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string v1, "eesetvrsmi_"

    const-string/jumbo v1, "vmirtbe_ees"

    const/4 v5, 0x5

    const-string v1, "_trmiemsvee"

    const-string/jumbo v1, "server_time"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->k:J

    const/4 v5, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo v1, "tyaeoeTtgp"

    const-string v1, "gTayeputet"

    const/4 v5, 0x4

    const-string/jumbo v1, "tpygTbteae"

    const-string/jumbo v1, "targetType"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->t:J

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo v1, "spoucr"

    const-string/jumbo v1, "uuoecs"

    const-string/jumbo v1, "source"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->u:J

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v1, "qsesatmptm"

    const-string/jumbo v1, "tpmaessmqt"

    const/4 v5, 0x5

    const-string/jumbo v1, "sestimtpqa"

    const-string/jumbo v1, "timestamps"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->h:J

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v5, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/stat/ServiceStat;->appReportServiceReceived(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    return-void
.end method


# virtual methods
.method public a(Lcom/tencent/android/tpush/service/protocol/j;)V
    .locals 8

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v0, p1, Lcom/tencent/android/tpush/service/protocol/j;->y:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/base/util/Util;->isNullOrEmptyString(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-nez v1, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    sget-object v1, Lcom/tencent/android/tpush/inappmessage/g;->a:Landroid/content/Context;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-nez v1, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x0

    goto/16 :goto_0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/inappmessage/g;->b(Lcom/tencent/android/tpush/service/protocol/j;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v1, Landroid/content/Intent;

    const/4 v7, 0x5

    const/4 v6, 0x6

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    sget-object v2, Lcom/tencent/android/tpush/inappmessage/g;->a:Landroid/content/Context;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-class v3, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    const-class v3, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    const/4 v7, 0x3

    const-class v3, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    const-class v3, Lcom/tencent/android/tpush/inappmessage/InAppMessageActivity;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string/jumbo v2, "nsspMsAp"

    const-string/jumbo v2, "pMspnAis"

    const/4 v7, 0x7

    const-string/jumbo v2, "pMAmnips"

    const-string/jumbo v2, "inAppMsg"

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string v0, "_gpmourd"

    const/4 v7, 0x6

    const-string/jumbo v0, "ug_ropid"

    const-string v0, "group_id"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    iget-object v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->r:Ljava/lang/String;

    invoke-virtual {v1, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string v0, "bmdso"

    const-string v0, "Imsdo"

    const/4 v7, 0x0

    const-string/jumbo v0, "sumdg"

    const-string/jumbo v0, "msgId"

    const/4 v7, 0x7

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    const/4 v7, 0x4

    const/4 v6, 0x0

    invoke-virtual {v1, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-string/jumbo v0, "pyte"

    const-string/jumbo v0, "tepy"

    const/4 v7, 0x2

    const-string/jumbo v0, "ypte"

    const-string/jumbo v0, "type"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->f:J

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v1, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string/jumbo v0, "unahleppnbh"

    const-string/jumbo v0, "nluhebnCaph"

    const-string v0, "aulseCnhqhn"

    const-string/jumbo v0, "pushChannel"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->m:J

    const/4 v7, 0x3

    const/4 v6, 0x1

    invoke-virtual {v1, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo v0, "ivsus_reere"

    const-string/jumbo v0, "ivmreeu_res"

    const/4 v7, 0x5

    const-string/jumbo v0, "teemrirs_em"

    const-string/jumbo v0, "server_time"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->k:J

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v1, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string/jumbo v0, "petroatgpe"

    const-string v0, "eptgrTapte"

    const/4 v7, 0x1

    const-string v0, "Tteaebprgt"

    const-string/jumbo v0, "targetType"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->t:J

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v1, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string/jumbo v0, "ucqsor"

    const-string/jumbo v0, "osqcur"

    const/4 v7, 0x7

    const-string v0, "epcuro"

    const-string/jumbo v0, "source"

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->u:J

    const/4 v6, 0x5

    and-int/2addr v7, v6

    invoke-virtual {v1, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string/jumbo v0, "pistamesqt"

    const-string/jumbo v0, "misematstp"

    const/4 v7, 0x0

    const-string/jumbo v0, "ttspimaesm"

    const-string/jumbo v0, "timestamps"

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-wide v2, p1, Lcom/tencent/android/tpush/service/protocol/j;->h:J

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v1, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v6, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v6, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x7

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x3

    const/4 v6, 0x3

    sub-long/2addr v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const-string/jumbo p1, "np_mtapetipmr"

    const-string/jumbo p1, "ippmttr_pecna"

    const-string/jumbo p1, "r_pnoctpoieat"

    const-string/jumbo p1, "inapp_protect"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string v4, ""

    const-string v4, ""

    const/4 v7, 0x3

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    move v7, v6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v1, p1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/high16 p1, 0x10000000

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v1, p1}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    sget-object p1, Lcom/tencent/android/tpush/inappmessage/g;->a:Landroid/content/Context;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p1, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v7, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string v1, "eppaAbMoginpgrInsApIs Mns:Cgpf"

    const-string/jumbo v1, "p:p op CnMIsinnsgApegfspaIMrgA"

    const/4 v7, 0x6

    const-string v1, "Mngfpeuss gaCoApsin:rAppp gMIn"

    const-string v1, "InAppMsg parseInAppMsgConfig :"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string v0, "eabIsMApgpnepasrgMn"

    const-string v0, "eegnMbnIsgpMrspeaAa"

    const/4 v7, 0x4

    const-string v0, "MprpeeaAqsMIangngse"

    const-string v0, "InAppMessageManager"

    const/4 v7, 0x6

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    return-void
.end method
