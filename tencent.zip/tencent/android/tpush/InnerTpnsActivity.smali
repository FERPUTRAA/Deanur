.class public Lcom/tencent/android/tpush/InnerTpnsActivity;
.super Landroid/app/Activity;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20150316"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->ACTIVITYCHECK:Lcom/jg/EType;,
        .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;,
        .enum Lcom/jg/EType;->INTENTSCHEMECHECK:Lcom/jg/EType;
    }
.end annotation


# static fields
.field public static final CHECK_CODE:Ljava/lang/String; = "checkCode"

.field public static final CUSTOM_CONTENT:Ljava/lang/String; = "customContent"

.field public static final JUMP_type:Ljava/lang/String; = "jumpType"

.field public static final MSG_TYPE:Ljava/lang/String; = "msgType"

.field public static final TARGE_ACTIVITY:Ljava/lang/String; = "targetActivity"

.field public static final TIMESTAMP:Ljava/lang/String; = "timestamp"

.field static a:Landroid/app/Application$ActivityLifecycleCallbacks; = null

.field static b:Ljava/util/List; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field static c:Ljava/lang/String; = ""

.field static d:J

.field static e:J


# instance fields
.field private f:Ljava/lang/String;

.field private g:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Landroid/app/Activity;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->f:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/16 v0, 0x64

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x5

    iput v0, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->g:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method private static a(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v2, "nostoan..eAiscnidaMndItir."

    const-string v2, "M.sda.reintnctoa.noiNndiIA"

    const/4 v4, 0x0

    const-string/jumbo v2, "nntm.i.taidcitendaoNn.MoIr"

    const-string v2, "android.intent.action.MAIN"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v2, "L.HcomntgedraeEaNir.t.dRiCootynn"

    const-string/jumbo v2, "negmrttHntr.o.NddEenci.ALyoCiRaa"

    const/4 v4, 0x2

    const-string/jumbo v2, "tEHLNbnrAgCtr.odne.anoidtyUciea."

    const-string v2, "android.intent.category.LAUNCHER"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p0, v1, v2}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    check-cast v1, Landroid/content/pm/ResolveInfo;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    if-eqz v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    iget-object p0, v1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v1, "nTtrvcutAeipyinsn"

    const-string v1, "InnerTpnsActivity"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v2, "trieir p teAgorvco"

    const-string v2, "grrioe cvttyiAr oe"

    const/4 v4, 0x0

    const-string/jumbo v2, "rettycgiq Arvte io"

    const-string v2, "get Activity error"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v4, 0x3

    return-object v0
.end method

.method private a()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->f:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    :cond_0
    const/4 v4, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->f:Ljava/lang/String;

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v2, "rcsitveavn pIehnpi  Tt ntmCevttee ibrtOnu nyjAvertccyytrsehiA=Agliraci"

    const-string v2, "=invObt hctittnIevirrcAercuAieetyA  cernCitvhnpep Tet airm ntlytjsaygv"

    const/4 v5, 0x0

    const-string/jumbo v2, "stgmvj ceitueicyitn ttvapehnicATrtepthec yv nOyeArv=Iainl nmeirtrrtCiA"

    const-string v2, "InnerTpnsActivity receiver  jumpOtherChannelActivity targetActivity = "

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->f:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x4

    const-string/jumbo v2, "sneIoiptvnTtuycAr"

    const-string/jumbo v2, "sIncnruvtTytpieAi"

    const/4 v5, 0x7

    const-string v2, "eitsIbninpycATntr"

    const-string v2, "InnerTpnsActivity"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->f:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/high16 v1, 0x24000000

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v1, "nhhanpulCue"

    const-string/jumbo v1, "nealhpnpuhC"

    const/4 v5, 0x6

    const-string/jumbo v1, "pushChannel"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    iget v3, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->g:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    :try_start_0
    const/4 v5, 0x4

    invoke-virtual {p0, v0}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    goto :goto_0

    :catch_0
    move-exception v0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string v3, " Tqeorepviryt iviEx cntnAocticnuycisIeeptvdrAnpNe=iFnot"

    const-string v3, "ETyvrvreqnixisiAFrtnttncot onyuIv tc=ApNeneiiecepiod  c"

    const/4 v5, 0x0

    const-string/jumbo v3, "in=uevieqnNTApie tpc icydnisoAtvFcEv  ytecrnxInoeittrto"

    const-string v3, "InnerTpnsActivity receiver ActivityNotFoundException = "

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-void
.end method

.method private a(ILandroid/content/Intent;)V
    .locals 5

    const/4 v3, 0x2

    move v4, v3

    if-nez p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance p1, Landroid/app/AlertDialog$Builder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v0, Lcom/tencent/android/tpush/InnerTpnsActivity$7;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v0, p0, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity$7;-><init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Landroid/app/AlertDialog$Builder;->setOnCancelListener(Landroid/content/DialogInterface$OnCancelListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v1, "7us/363d9/u0"

    const/4 v4, 0x0

    const-string v1, "6usd3u30/7a/"

    const-string/jumbo v1, "\u63d0\u793a"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v1, "m27m5/540566/f3uueuu///517f826//58uufbua6u5949260buf66/2/4eu"

    const-string v1, "7ufm652/fuu8u45/9u65u/06/e9e08/5/1/u52ufu/f47662u36a/b/2645b"

    const/4 v4, 0x2

    const-string v1, "5f0uo5f/uu564/1uub5/u/uf7u5068b/ua26///62532/46u8ff7969e42e/"

    const-string/jumbo v1, "\u662f\u5426\u786e\u5b9a\u6253\u5f00\u6b64\u5e94\u7528\uff1f"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v1, Lcom/tencent/android/tpush/InnerTpnsActivity$6;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-direct {v1, p0, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity$6;-><init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v2, "f/u30bu0625/"

    const-string/jumbo v2, "uu52o0/03f6/"

    const-string v2, "/u5f0/uu0623"

    const-string/jumbo v2, "\u6253\u5f00"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v2, v1}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    new-instance v1, Lcom/tencent/android/tpush/InnerTpnsActivity$5;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v1, p0, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity$5;-><init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string p2, "/68uub3d/65d"

    const/4 v4, 0x0

    const-string/jumbo p2, "u/u5/68p8dd3"

    const-string/jumbo p2, "\u53d6\u6d88"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, p2, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->create()Landroid/app/AlertDialog;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/app/Dialog;->show()V

    :cond_0
    const/4 v3, 0x6

    move v4, v3

    return-void
.end method

.method static a(Landroid/app/Application;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/android/tpush/InnerTpnsActivity;->a:Landroid/app/Application$ActivityLifecycleCallbacks;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    new-instance v0, Lcom/tencent/android/tpush/InnerTpnsActivity$4;

    invoke-direct {v0}, Lcom/tencent/android/tpush/InnerTpnsActivity$4;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    sput-object v0, Lcom/tencent/android/tpush/InnerTpnsActivity;->a:Landroid/app/Application$ActivityLifecycleCallbacks;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    check-cast p0, Landroid/app/Application;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/InnerTpnsActivity;->a:Landroid/app/Application$ActivityLifecycleCallbacks;

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-virtual {p0, v0}, Landroid/app/Application;->registerActivityLifecycleCallbacks(Landroid/app/Application$ActivityLifecycleCallbacks;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method private a(Landroid/net/Uri;)V
    .locals 33

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    const-string v2, "Iqcdeua"

    const-string/jumbo v2, "rdIceau"

    const-string v2, "cdsaeIr"

    const-string/jumbo v2, "traceId"

    const-string/jumbo v3, "ptImtpdlme"

    const-string/jumbo v3, "talpeIdpmt"

    const-string/jumbo v3, "ptIaoeedlm"

    const-string/jumbo v3, "templateId"

    const-string/jumbo v4, "uqoreb"

    const-string v4, "esquro"

    const-string/jumbo v4, "uorcsu"

    const-string/jumbo v4, "source"

    const-string v5, "hiesTusp"

    const-string/jumbo v5, "sishTuep"

    const-string/jumbo v5, "qeuTismh"

    const-string/jumbo v5, "pushTime"

    const-string v6, "etsrmytTga"

    const-string v6, "Tyrmtgetea"

    const-string v6, "geymTeprta"

    const-string/jumbo v6, "targetType"

    const-string/jumbo v7, "seoponlChha"

    const-string v7, "hnuaoelhspC"

    const-string/jumbo v7, "pslanbnChuh"

    const-string/jumbo v7, "pushChannel"

    const-string/jumbo v8, "odrbugu"

    const-string/jumbo v8, "uorpgbd"

    const-string/jumbo v8, "pIogpdr"

    const-string v8, "groupId"

    const-string v9, "gudsMsIuq"

    const-string v9, "IsduMgusb"

    const-string v9, "MbssusdIi"

    const-string v9, "busiMsgId"

    const-string/jumbo v10, "ivemspAntTipynctI"

    const-string/jumbo v10, "vyntrTippIAtecisn"

    const-string v10, "cintoITtAnsyvnpir"

    const-string v10, "InnerTpnsActivity"

    const-string v11, "bqsIm"

    const-string/jumbo v11, "mgsqI"

    const-string/jumbo v11, "mugsd"

    const-string/jumbo v11, "msgId"

    :try_start_0
    const-string/jumbo v12, "uepjpmTp"

    const-string/jumbo v12, "jumpType"

    invoke-virtual {v0, v12}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v0, v9}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v0, v11}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string v15, "Tqsmegp"

    const-string v15, "Tessmgp"

    const-string/jumbo v15, "spsTemg"

    const-string/jumbo v15, "msgType"

    invoke-virtual {v0, v15}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    :try_start_1
    invoke-virtual {v0, v8}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    move-object/from16 v17, v12

    move-object/from16 v17, v12

    move-object/from16 v17, v12

    move-object/from16 v17, v12

    invoke-virtual {v0, v7}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    invoke-virtual {v0, v6}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    move-object/from16 v18, v2

    invoke-virtual {v0, v5}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    move-object/from16 v19, v3

    move-object/from16 v19, v3

    move-object/from16 v19, v3

    move-object/from16 v19, v3

    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    move-object/from16 v20, v4

    move-object/from16 v20, v4

    move-object/from16 v20, v4

    move-object/from16 v20, v4

    const-string/jumbo v4, "immmttape"

    const-string/jumbo v4, "tptmaisem"

    const-string/jumbo v4, "tpmmoaeti"

    const-string/jumbo v4, "timestamp"

    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v21, v4

    move-object/from16 v21, v4

    move-object/from16 v21, v4

    const-string/jumbo v4, "tteuCbncsoonm"

    const-string v4, "customContent"

    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    move-object/from16 v22, v4

    const-string v4, "eotryiucAvaitt"

    const-string v4, "egyioAtivtcrat"

    const-string/jumbo v4, "tgartcepAyitvt"

    const-string/jumbo v4, "targetActivity"

    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v23, v4

    move-object/from16 v23, v4

    move-object/from16 v23, v4

    move-object/from16 v23, v4

    const-string/jumbo v4, "tmpl"

    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    move-object/from16 v24, v4

    move-object/from16 v24, v4

    move-object/from16 v24, v4

    move-object/from16 v24, v4

    const-string/jumbo v4, "trbqa"

    const-string v4, "brtea"

    const-string v4, "arsec"

    const-string/jumbo v4, "trace"

    invoke-virtual {v0, v4}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    new-instance v4, Landroid/content/Intent;

    invoke-direct {v4}, Landroid/content/Intent;-><init>()V

    const-wide/16 v25, 0x0

    const-wide/16 v25, 0x0

    const-wide/16 v25, 0x0

    if-eqz v13, :cond_0

    invoke-static {v13}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v27

    invoke-virtual/range {v27 .. v27}, Ljava/lang/Long;->longValue()J

    move-result-wide v27

    move-wide/from16 v31, v27

    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-wide/from16 v2, v31

    goto :goto_0

    :cond_0
    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v27, v2

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-object/from16 v28, v3

    move-wide/from16 v2, v25

    :goto_0
    invoke-virtual {v4, v9, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    if-eqz v14, :cond_1

    invoke-static {v14}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v2

    goto :goto_1

    :cond_1
    move-wide/from16 v2, v25

    :goto_1
    invoke-virtual {v4, v11, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string/jumbo v2, "ytep"

    const-string/jumbo v2, "tpye"

    const-string/jumbo v2, "ytep"

    const-string/jumbo v2, "type"

    if-eqz v15, :cond_2

    invoke-static {v15}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v29

    goto :goto_2

    :cond_2
    const-wide/16 v29, 0x1

    const-wide/16 v29, 0x1

    const-wide/16 v29, 0x1

    const-wide/16 v29, 0x1

    :goto_2
    move-object v3, v14

    move-object v3, v14

    move-object v3, v14

    move-object v3, v14

    move-object v9, v15

    move-object v9, v15

    move-object v9, v15

    move-object v9, v15

    move-wide/from16 v14, v29

    invoke-virtual {v4, v2, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {v4, v8, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x0

    if-eqz v12, :cond_3

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    goto :goto_3

    :cond_3
    move v8, v2

    move v8, v2

    move v8, v2

    :goto_3
    invoke-virtual {v4, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    if-eqz v1, :cond_4

    invoke-static {v1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    goto :goto_4

    :cond_4
    move-wide/from16 v7, v25

    :goto_4
    invoke-virtual {v4, v6, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    if-eqz v27, :cond_5

    invoke-static/range {v27 .. v27}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    mul-long/2addr v14, v6

    goto :goto_5

    :cond_5
    move-wide/from16 v14, v25

    :goto_5
    invoke-virtual {v4, v5, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    if-eqz v28, :cond_6

    invoke-static/range {v28 .. v28}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    move-object/from16 v5, v20

    move-object/from16 v5, v20

    move-object/from16 v5, v20

    move-object/from16 v5, v20

    goto :goto_6

    :cond_6
    move-object/from16 v5, v20

    move-object/from16 v5, v20

    move-object/from16 v5, v20

    move-object/from16 v5, v20

    move-wide/from16 v14, v25

    :goto_6
    invoke-virtual {v4, v5, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string/jumbo v5, "paimusemts"

    const-string/jumbo v5, "ismeptuast"

    const-string/jumbo v5, "tiamotmspe"

    const-string/jumbo v5, "timestamps"

    if-eqz v21, :cond_7

    invoke-static/range {v21 .. v21}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v8

    invoke-virtual {v8}, Ljava/lang/Long;->longValue()J

    move-result-wide v14

    mul-long/2addr v14, v6

    goto :goto_7

    :cond_7
    move-wide/from16 v14, v25

    :goto_7
    invoke-virtual {v4, v5, v14, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-object/from16 v6, v19

    move-object/from16 v6, v19

    move-object/from16 v6, v19

    move-object/from16 v5, v24

    move-object/from16 v5, v24

    move-object/from16 v5, v24

    move-object/from16 v5, v24

    invoke-virtual {v4, v6, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-object/from16 v7, v18

    move-object/from16 v7, v18

    move-object/from16 v7, v18

    move-object/from16 v7, v18

    invoke-virtual {v4, v7, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object v8, v1

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    :try_start_3
    invoke-direct {v1, v4}, Lcom/tencent/android/tpush/InnerTpnsActivity;->g(Landroid/content/Intent;)V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, " ynevbmsisrm:tTpiAi tpIprdaccanreIvder u gslen "

    const-string v14, "e vd tIpumtApaiTgnrinc pyB:selsIr i anesdecmrrv"

    const-string/jumbo v14, "rv nanuBdtiunIypiis:vAspTemtmrir dleeceIc sarg "

    const-string v14, "InnerTpnsActivity receiver params : msgBuildId "

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v13, " s=,  Ipq g"

    const-string v13, "=s , Im q g"

    const-string v13, "  m,=I dqs "

    const-string v13, " , msgId = "

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v13, "=ysu ,p jseT m"

    const-string v13, "e su=j,pp yTm "

    const-string/jumbo v13, "p jm meyu= ,pT"

    const-string v13, " , jumpType = "

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v13, v17

    move-object/from16 v13, v17

    move-object/from16 v13, v17

    move-object/from16 v13, v17

    invoke-virtual {v4, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, ",Tm o sm ypg "

    const-string/jumbo v14, "myTm,=s p g  "

    const-string/jumbo v14, "p yg b,T=m  s"

    const-string v14, " , msgType = "

    invoke-virtual {v4, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, ",d   puou Ig="

    const-string v9, "g,= ouo   dIp"

    const-string v9, " I rop,pug=d "

    const-string v9, " , groupId = "

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, " =Che laqu,pb s n"

    const-string/jumbo v9, "naCs bu,nl = hpe "

    const-string v9, " , pushChannel = "

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, "  sey=uTgt ,erat"

    const-string/jumbo v9, "rt e Tua ,gte= y"

    const-string v9, "epTm= etar yg t,"

    const-string v9, " , targetType = "

    invoke-virtual {v4, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, ",mpioe up hs T"

    const-string v8, " h ise,pm T=pu"

    const-string v8, "i=,ehbu psm   "

    const-string v8, " , pushTime = "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v8, v27

    move-object/from16 v8, v27

    move-object/from16 v8, v27

    move-object/from16 v8, v27

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "cor e,usqu  "

    const-string v8, "=  ,rescquo "

    const-string/jumbo v8, "s=cue  pr ,o"

    const-string v8, " , source = "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v8, v28

    move-object/from16 v8, v28

    move-object/from16 v8, v28

    move-object/from16 v8, v28

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v8, "me=amt iq ss tp"

    const-string/jumbo v8, "t smt p = imase"

    const-string/jumbo v8, "stsm a,em= ti  "

    const-string v8, " , timestamp = "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    move-object/from16 v8, v21

    move-object/from16 v8, v21

    move-object/from16 v8, v21

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, ",aIme ltm d = tm"

    const-string v8, "=m m etd, pa lIt"

    const-string v8, "eet op I a=,dmlt"

    const-string v8, " , templateId = "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v8, "d rc b,e a t="

    const-string v8, "  aco=r ,de t"

    const-string/jumbo v8, "tarI= u cd  e"

    const-string v8, " , traceId = "

    invoke-virtual {v4, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    :try_start_4
    invoke-static {v8, v4}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v4, Landroid/content/Intent;

    const-string/jumbo v9, "ttciairpbc.eFtxnnan.pdo.gAdmE.KcD.Bn.oCeov"

    const-string/jumbo v9, "xAvorb.an.eiigoKnmaFcpEntntcCodB.Deicdt..."

    const-string v9, "cACeronBq.cEEc.pmioaoKFtdv.da.nine.gx.Ditt"

    const-string v9, "com.tencent.android.xg.vip.action.FEEDBACK"

    invoke-direct {v4, v9}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v9

    invoke-virtual {v9}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v4, v9}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const-string v9, ".HsKDAuFSBPCET"

    const-string v9, "FT.PKUuEBCASDH"

    const-string v9, "BPDmTFAS.EUKHC"

    const-string v9, "TPUSH.FEEDBACK"

    const/4 v10, 0x4

    invoke-virtual {v4, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v9, "RRp.oREEPOTDSUH"

    const-string v9, "DRETUORpSOE.PRH"

    const-string v9, "UPDTCb.SRREOHRO"

    const-string v9, "TPUSH.ERRORCODE"

    invoke-virtual {v4, v9, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v9, "EqHNHPu.LACU"

    const-string v9, "UEANPHCSqLH."

    const-string v9, "HN.LUPHpNSCA"

    const-string v9, "PUSH.CHANNEL"

    if-eqz v12, :cond_8

    invoke-static {v12}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    :cond_8
    invoke-virtual {v4, v9, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v2, "itqosa"

    const-string/jumbo v2, "otsnai"

    const-string/jumbo v2, "ocsnai"

    const-string v2, "action"

    sget-object v9, Lcom/tencent/android/tpush/NotificationAction;->clicked:Lcom/tencent/android/tpush/NotificationAction;

    invoke-virtual {v9}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v9

    invoke-virtual {v4, v2, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v2, "icimeoiontyAimanTptncf"

    const-string v2, "ictmnotypTaoiAnnefitci"

    const-string v2, "ApafonoiTitotiynteicon"

    const-string/jumbo v2, "notificationActionType"

    if-eqz v13, :cond_9

    invoke-static {v13}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v9

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    goto :goto_8

    :cond_9
    sget-object v9, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    invoke-virtual {v9}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v9

    :goto_8
    invoke-virtual {v4, v2, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v2, "oo_mtbntnoccte"

    const-string/jumbo v2, "m_tootoctnnecs"

    const-string/jumbo v2, "tutencunocst_o"

    const-string v2, "custom_content"

    move-object/from16 v9, v22

    move-object/from16 v9, v22

    invoke-virtual {v4, v2, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    if-eqz v3, :cond_a

    invoke-static {v3}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v2

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v25

    :cond_a
    move-wide/from16 v2, v25

    invoke-virtual {v4, v11, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {v4, v6, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v4, v7, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const-string v0, "atyviitp"

    const-string/jumbo v0, "tavtybii"

    const-string/jumbo v0, "qviacity"

    const-string v0, "activity"

    if-eqz v23, :cond_b

    :try_start_5
    invoke-static/range {v23 .. v23}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_b

    move-object/from16 v2, v23

    move-object/from16 v2, v23

    invoke-virtual {v4, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_9

    :cond_b
    invoke-static/range {p0 .. p0}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    iput-object v2, v1, Lcom/tencent/android/tpush/InnerTpnsActivity;->f:Ljava/lang/String;

    invoke-virtual {v4, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :goto_9
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v4}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_0

    goto :goto_c

    :catchall_0
    move-exception v0

    goto :goto_b

    :catchall_1
    move-exception v0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    goto :goto_a

    :catchall_2
    move-exception v0

    :goto_a
    move-object/from16 v8, v16

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    move-object/from16 v8, v16

    goto :goto_b

    :catchall_3
    move-exception v0

    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    move-object v8, v10

    :goto_b
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "eostsnpihnereecTIOu tnnplnretcinrytx :ACetiDovhpaknprLe"

    const-string/jumbo v3, "nn tlruavhrTtkneiipoDeertriiscenntphnpeetOpen CxAyocLI:"

    const-string/jumbo v3, "taomp:hektvnOrheeltIsiCn reentncyieropinAxptenn pLcDier"

    const-string v3, "InnerTpnsActivity reportOtherChannelDeepLink exception:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v8, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :goto_c
    return-void
.end method

.method private a(Landroid/os/Bundle;Lcom/tencent/android/tpush/XGPushClickedResult;)V
    .locals 28

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    const-string/jumbo v3, "lnaCohpnuhe"

    const-string/jumbo v3, "lshneuapCnh"

    const-string/jumbo v3, "sahChbennul"

    const-string/jumbo v3, "pushChannel"

    const-string v4, "eytp"

    const-string/jumbo v4, "type"

    const-string/jumbo v5, "uusoer"

    const-string/jumbo v5, "source"

    const-string v6, "emihqTpp"

    const-string/jumbo v6, "qehspimT"

    const-string/jumbo v6, "qepsmihu"

    const-string/jumbo v6, "pushTime"

    const-string v7, "bssMsugsd"

    const-string v7, "Mssusgdbi"

    const-string v7, "MgbmdsuIi"

    const-string v7, "busiMsgId"

    const-string v8, "atrTotmype"

    const-string v8, "etympTrtea"

    const-string/jumbo v8, "tTyaebegpt"

    const-string/jumbo v8, "targetType"

    const-string/jumbo v9, "pgIroou"

    const-string/jumbo v9, "ogrdopI"

    const-string/jumbo v9, "pgurpId"

    const-string v9, "groupId"

    const-string v10, "eqbdcIa"

    const-string v10, "dtecabI"

    const-string v10, "Itsaedc"

    const-string/jumbo v10, "traceId"

    const-string/jumbo v11, "ptmmtaleeu"

    const-string v11, "Ielameuptt"

    const-string v11, "daItoeltme"

    const-string/jumbo v11, "templateId"

    const-string v12, "bgdIs"

    const-string v12, "dspgI"

    const-string v12, "gusmI"

    const-string/jumbo v12, "msgId"

    :try_start_0
    invoke-virtual {v0, v9}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const-string/jumbo v14, "st"

    const-string/jumbo v14, "ts"

    const-string/jumbo v14, "ts"

    const-string/jumbo v14, "ts"

    invoke-virtual {v0, v14}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v0, v8}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v0, v7}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    invoke-virtual {v0, v12}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v17

    invoke-virtual {v0, v6}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v18

    invoke-virtual {v0, v5}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v19

    invoke-virtual {v0, v4}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v20

    invoke-virtual {v0, v3}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v21

    invoke-virtual {v0, v11}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v10}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    new-instance v1, Landroid/content/Intent;

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const-wide/16 v22, 0x0

    const-wide/16 v22, 0x0

    if-eqz v16, :cond_0

    sget-wide v24, Lcom/tencent/android/tpush/InnerTpnsActivity;->e:J

    invoke-static/range {v24 .. v25}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v16

    invoke-virtual/range {v16 .. v16}, Ljava/lang/Long;->longValue()J

    move-result-wide v24

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-wide/from16 v26, v24

    move-object/from16 v24, v11

    move-object/from16 v24, v11

    move-wide/from16 v10, v26

    goto :goto_0

    :cond_0
    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v16, v10

    move-object/from16 v24, v11

    move-object/from16 v24, v11

    move-wide/from16 v10, v22

    :goto_0
    invoke-virtual {v1, v7, v10, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    if-eqz v17, :cond_1

    invoke-static/range {v17 .. v17}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    goto :goto_1

    :cond_1
    move-wide/from16 v10, v22

    :goto_1
    invoke-virtual {v1, v12, v10, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    if-eqz v20, :cond_2

    invoke-static/range {v20 .. v20}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    goto :goto_2

    :cond_2
    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    const-wide/16 v10, 0x1

    :goto_2
    invoke-virtual {v1, v4, v10, v11}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {v1, v9, v13}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/16 v4, 0x65

    if-eqz v21, :cond_3

    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v7

    invoke-virtual {v7}, Ljava/lang/Integer;->intValue()I

    move-result v7

    goto :goto_3

    :cond_3
    move v7, v4

    move v7, v4

    move v7, v4

    :goto_3
    invoke-virtual {v1, v3, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    if-eqz v15, :cond_4

    invoke-static {v15}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v9

    goto :goto_4

    :cond_4
    move-wide/from16 v9, v22

    :goto_4
    invoke-virtual {v1, v8, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-wide/16 v7, 0x3e8

    const-wide/16 v7, 0x3e8

    const-wide/16 v7, 0x3e8

    const-wide/16 v7, 0x3e8

    if-eqz v18, :cond_5

    invoke-static/range {v18 .. v18}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v9

    mul-long/2addr v9, v7

    goto :goto_5

    :cond_5
    move-wide/from16 v9, v22

    :goto_5
    invoke-virtual {v1, v6, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    if-eqz v19, :cond_6

    invoke-static/range {v19 .. v19}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v3

    invoke-virtual {v3}, Ljava/lang/Long;->longValue()J

    move-result-wide v9

    goto :goto_6

    :cond_6
    move-wide/from16 v9, v22

    :goto_6
    invoke-virtual {v1, v5, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string v3, "eaqmsstpmi"

    const-string v3, "iasetmtsqm"

    const-string/jumbo v3, "memtissaqt"

    const-string/jumbo v3, "timestamps"

    if-eqz v14, :cond_7

    invoke-static {v14}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v5

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    mul-long/2addr v5, v7

    goto :goto_7

    :cond_7
    move-wide/from16 v5, v22

    :goto_7
    invoke-virtual {v1, v3, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    move-object/from16 v3, v24

    move-object/from16 v3, v24

    move-object/from16 v3, v24

    move-object/from16 v3, v24

    invoke-virtual {v1, v3, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    move-object/from16 v5, v16

    invoke-virtual {v1, v5, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object v6, v1

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    :try_start_2
    invoke-direct {v1, v6}, Lcom/tencent/android/tpush/InnerTpnsActivity;->g(Landroid/content/Intent;)V

    new-instance v6, Landroid/content/Intent;

    const-string v7, "Bosactntxr...eingKAci.padDsdiCooe.nvFEtEn."

    const-string/jumbo v7, "o.sgavnaB..piEnKcdn.cxEn.eFicCderAtttoi.oD"

    const-string v7, ".BomdencA.Conac.dtFKo..nEt.EatixmiciegDnpv"

    const-string v7, "com.tencent.android.xg.vip.action.FEEDBACK"

    invoke-direct {v6, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v7

    invoke-virtual {v7}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const-string v7, "UHT.oECAmDFKBE"

    const-string v7, "EHAmKUBT.CFDSE"

    const-string v7, "FDAEBbKCUETHSP"

    const-string v7, "TPUSH.FEEDBACK"

    const/4 v8, 0x4

    invoke-virtual {v6, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v7, "CHR.ODuUEREOToP"

    const-string v7, "THEPoORCEORUD.R"

    const-string v7, "TO.PODRpURCEREH"

    const-string v7, "TPUSH.ERRORCODE"

    const/4 v8, 0x0

    invoke-virtual {v6, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v7, "ULPNEbNHAHSC"

    const-string v7, "SP.NANCUqEHL"

    const-string v7, "PUSH.CHANNEL"

    if-eqz v21, :cond_8

    invoke-static/range {v21 .. v21}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    :cond_8
    invoke-virtual {v6, v7, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v4, "unscti"

    const-string/jumbo v4, "ucoint"

    const-string v4, "iaomnt"

    const-string v4, "action"

    sget-object v7, Lcom/tencent/android/tpush/NotificationAction;->clicked:Lcom/tencent/android/tpush/NotificationAction;

    invoke-virtual {v7}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v7

    invoke-virtual {v6, v4, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v4, "iiofoioTntcnptpanyteoc"

    const-string v4, "cctotoypiitnepnfinoTaA"

    const-string/jumbo v4, "taoycbntnicpTifeAontoi"

    const-string/jumbo v4, "notificationActionType"

    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    move-object v7, v2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    iget v8, v2, Lcom/tencent/android/tpush/XGPushClickedResult;->notificationActionType:I

    if-eqz v8, :cond_9

    goto :goto_8

    :cond_9
    sget-object v8, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    invoke-virtual {v8}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v8

    :goto_8
    invoke-virtual {v6, v4, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v4, "nctcesuuomnt_t"

    const-string v4, "custom_content"

    iget-object v8, v2, Lcom/tencent/android/tpush/XGPushClickedResult;->customContent:Ljava/lang/String;

    invoke-virtual {v6, v4, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    if-eqz v17, :cond_a

    invoke-static/range {v17 .. v17}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v4

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v22

    :cond_a
    move-wide/from16 v8, v22

    invoke-virtual {v6, v12, v8, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {v6, v3, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v6, v5, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object v0, v2, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const-string/jumbo v3, "tivtiacp"

    const-string v3, "activity"

    if-eqz v0, :cond_b

    :try_start_3
    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    if-nez v0, :cond_b

    iget-object v0, v2, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    invoke-virtual {v6, v3, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    goto :goto_9

    :cond_b
    invoke-static/range {p0 .. p0}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v1, Lcom/tencent/android/tpush/InnerTpnsActivity;->f:Ljava/lang/String;

    invoke-virtual {v6, v3, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :goto_9
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v6}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    goto :goto_b

    :catchall_0
    move-exception v0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    goto :goto_a

    :catchall_1
    move-exception v0

    :goto_a
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "kqrnrLhtqnpoaeATDtnpencvitmAeyl:kcc Fe nedniereCenbpiFIa"

    const-string/jumbo v3, "irvikderqIlmcAanAhe CnpnnneknpeDept eoe:LaFTtesbcciFntyr"

    const-string/jumbo v3, "kdstneApLaeorneFvTDcalin CAebitnktch nkpFps:rIyeemcenrin"

    const-string v3, "InnerTpnsActivity reportAndFeekbackFcmChannelDeepLink e:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v2, "IisniyntsecrvnApT"

    const-string/jumbo v2, "ynTmvtnnirAetIpcs"

    const-string v2, "InnerTpnsActivity"

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :goto_b
    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->g(Landroid/content/Intent;)V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/net/Uri;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Landroid/net/Uri;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/os/Bundle;Lcom/tencent/android/tpush/XGPushClickedResult;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Landroid/os/Bundle;Lcom/tencent/android/tpush/XGPushClickedResult;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/InnerTpnsActivity;Ljava/lang/String;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Ljava/lang/String;Landroid/content/Intent;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method private a(Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo v0, "snrtoTitcmepynnIi"

    const-string v0, "InsmtincTptnvyier"

    const/4 v5, 0x4

    const-string v0, "eIivAbtrscnptniny"

    const-string v0, "InnerTpnsActivity"

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v1, Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string v3, " tetinuci iAhpottTsu mrvnetiIa =pOeytisnAeyrletricrjcvhacgvei eAyn tnCv"

    const-string v3, "Ast ocOgttAieneypcpuceAsil Cttieir Irtyvant  eetmiva th=eniirhnvcTrnyjv"

    const/4 v5, 0x5

    const-string/jumbo v3, "pethgtspyciu tjnCIncAct TimerOnynnliver y=tcvarArere tettph  aiitvieivA"

    const-string v3, "InnerTpnsActivity receiver  jumpOtherChannelActivitys targetActivity = "

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v2, p1}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const-string/jumbo p1, "lanCesnhqub"

    const-string/jumbo p1, "uhnnsbalCeh"

    const/4 v5, 0x1

    const-string/jumbo p1, "slspnChhnae"

    const-string/jumbo p1, "pushChannel"

    const/4 v5, 0x0

    const/4 v4, 0x1

    iget v2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->g:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v1, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    const/high16 p1, 0x24000000

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v2, "Ieimn=utr yiAvcvuTAetvcecjianys enptCsh e rOtmphrenlint"

    const-string v2, "aeniT upnjAp vesuOChtctlieeinv rvresAIiitychmntre=ynct "

    const/4 v5, 0x1

    const-string/jumbo v2, "niproe iu=eirCsnrjttycevatltvv mtnAnI npeOyheAhireccs T"

    const-string v2, "InnerTpnsActivity receiver jumpOtherChannelActivitys = "

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void
.end method

.method private a(Ljava/lang/String;Landroid/content/Intent;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance p2, Landroid/content/Intent;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string/jumbo v0, "ordanb.inEI.nta.doieniWtpV"

    const-string v0, "iaattrnp.dE.IiotWnni.oenVd"

    const/4 v2, 0x1

    const-string v0, "android.intent.action.VIEW"

    const/4 v2, 0x1

    invoke-direct {p2, v0, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    const/high16 p1, 0x10000000

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-virtual {p2, p1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string p1, "huCsqnueanl"

    const-string p1, "haClhnunqse"

    const/4 v2, 0x6

    const-string/jumbo p1, "nsahhuppeCn"

    const-string/jumbo p1, "pushChannel"

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->g:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p2, p1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/app/Activity;)Lcom/tencent/android/tpush/XGPushClickedResult;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p0, p2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const-string/jumbo p2, "rsnntniTqAvcIeysp"

    const-string p2, "iAsncerpsnITtntvy"

    const/4 v2, 0x4

    const-string/jumbo p2, "tsseinintArpvnTIy"

    const-string p2, "InnerTpnsActivity"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string v0, "e. mlrmrreropU"

    const-string/jumbo v0, "onemrUrr. relp"

    const/4 v2, 0x5

    const-string/jumbo v0, "oeUroeplorr .n"

    const-string/jumbo v0, "openUrl error."

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-static {p2, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method private a(Landroid/content/Intent;)Z
    .locals 7

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    const/4 v0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz p1, :cond_0

    const/4 v5, 0x0

    move v6, v5

    const-string v1, "cpteobr"

    const-string v1, "ctprote"

    const/4 v6, 0x0

    const-string v1, "cperttu"

    const-string/jumbo v1, "protect"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {p1, v1}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v2, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p1, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-nez v1, :cond_0

    const/4 v5, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {p1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    cmp-long v1, v1, v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-lez v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v3
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    cmp-long p1, v1, v3

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-ltz p1, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    const/4 v0, 0x1

    :catch_0
    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    return v0
.end method

.method public static addActivityNames(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/InnerTpnsActivity;->b:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-nez v0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/android/tpush/InnerTpnsActivity;->b:Ljava/util/List;

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/InnerTpnsActivity;->b:Ljava/util/List;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/InnerTpnsActivity;->b:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method private b(ILandroid/content/Intent;)V
    .locals 8

    const/4 v7, 0x6

    const-string v0, "38d/ub6p/d5u"

    const-string v0, "d6u8/b5/d36u"

    const/4 v7, 0x6

    const-string v0, "8//635u8q6dd"

    const-string/jumbo v0, "\u53d6\u6d88"

    const/4 v7, 0x3

    const-string v1, "86sab4uu/u/8"

    const-string v1, "/ba7u/u486u8"

    const/4 v7, 0x0

    const-string v1, "a48mueu//876"

    const-string/jumbo v1, "\u786e\u8ba4"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string v2, "36adou7//9u0"

    const-string v2, "7u9u6/dp0a/3"

    const/4 v7, 0x2

    const-string v2, "d7/3abu306u9"

    const-string/jumbo v2, "\u63d0\u793a"

    const/4 v7, 0x5

    const-string/jumbo v3, "itcnoaun_fciom"

    const-string v3, "action_confirm"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    const/4 v4, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v5, 0x0

    shr-int/2addr v7, v5

    const/4 v6, 0x2

    move v7, v6

    if-nez p1, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string/jumbo p1, "ycvqitap"

    const-string/jumbo p1, "qiatytcv"

    const/4 v7, 0x6

    const-string/jumbo p1, "qtiyitva"

    const-string p1, "activity"

    const/4 v7, 0x1

    const/4 v6, 0x5

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {p2, v3, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-ne v3, v4, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    new-instance v3, Landroid/app/AlertDialog$Builder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    invoke-direct {v3, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const/4 v6, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v3, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v2, v5}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string v4, "53s6u//f9/42/f6u2duauu2:5fs//50u65071"

    const-string v4, "5fs72u59f66204u1/f5u/uu/a3/25d/u7:/06"

    const/4 v7, 0x1

    const-string v4, "/uumaf75u/0/d6562:u/72f354219uf/u065/"

    const-string/jumbo v4, "\u662f\u5426\u6253\u5f00\u7f51\u7ad9:"

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v4, "?"

    const-string v4, "?"

    const/4 v7, 0x1

    const-string v4, "?"

    const-string v4, "?"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v2, v3}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    new-instance v3, Lcom/tencent/android/tpush/InnerTpnsActivity$9;

    const/4 v7, 0x0

    invoke-direct {v3, p0, p1, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity$9;-><init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Ljava/lang/String;Landroid/content/Intent;)V

    const/4 v6, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v2, v1, v3}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x2

    new-instance v1, Lcom/tencent/android/tpush/InnerTpnsActivity$8;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {v1, p0, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity$8;-><init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto :goto_0

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Ljava/lang/String;Landroid/content/Intent;)V

    const/4 v6, 0x1

    move v7, v6

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-ne p1, v4, :cond_3

    const/4 v7, 0x6

    invoke-virtual {p2, v3, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    if-ne p1, v4, :cond_2

    const/4 v6, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-instance p1, Landroid/app/AlertDialog$Builder;

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-direct {p1, p0}, Landroid/app/AlertDialog$Builder;-><init>(Landroid/content/Context;)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p1, v2}, Landroid/app/AlertDialog$Builder;->setTitle(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p1, v5}, Landroid/app/AlertDialog$Builder;->setCancelable(Z)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string v2, "fn23o7etu7e/65//Ieuu5?em/t00d7n"

    const-string/jumbo v2, "u/tm2/u/eue5eIu3fen77d0n/7065?t"

    const/4 v7, 0x6

    const-string v2, "/50?Ib2u5feuu70/t7uee37tdn6ne//"

    const-string/jumbo v2, "\u7ee7\u7eed\u6253\u5f00Intent?"

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p1, v2}, Landroid/app/AlertDialog$Builder;->setMessage(Ljava/lang/CharSequence;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance v2, Lcom/tencent/android/tpush/InnerTpnsActivity$2;

    const/4 v6, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {v2, p0, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity$2;-><init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {p1, v1, v2}, Landroid/app/AlertDialog$Builder;->setPositiveButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    new-instance v1, Lcom/tencent/android/tpush/InnerTpnsActivity$10;

    const/4 v6, 0x0

    move v7, v6

    invoke-direct {v1, p0, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity$10;-><init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V

    const/4 v7, 0x2

    invoke-virtual {p1, v0, v1}, Landroid/app/AlertDialog$Builder;->setNegativeButton(Ljava/lang/CharSequence;Landroid/content/DialogInterface$OnClickListener;)Landroid/app/AlertDialog$Builder;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p1}, Landroid/app/AlertDialog$Builder;->show()Landroid/app/AlertDialog;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto :goto_0

    :cond_2
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {p0, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity;->f(Landroid/content/Intent;)V

    :cond_3
    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    return-void
.end method

.method private b(Landroid/content/Intent;)V
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    if-nez v0, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_0
    const/4 v9, 0x1

    const-string/jumbo v1, "oecdoeChk"

    const/4 v9, 0x7

    const-string v1, "hekCcduoc"

    const-string v1, "checkCode"

    const/4 v8, 0x3

    move v9, v8

    invoke-virtual {p1, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string v2, "dgpbm"

    const-string v2, "bgIdm"

    const/4 v9, 0x6

    const-string v2, "Imsqd"

    const-string/jumbo v2, "msgId"

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-eqz p1, :cond_6

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-eqz p1, :cond_6

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    const-string p1, "eusntto"

    const-string/jumbo p1, "tetoncu"

    const/4 v9, 0x2

    const-string/jumbo p1, "otnmetn"

    const-string p1, "content"

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v0, p1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string/jumbo v2, "ntecoieopDenlCfnmfak1/Lea fhunt p"

    const-string/jumbo v2, "nLcf flpef ep/1ueoianetkDatnhnnmC"

    const/4 v9, 0x4

    const-string v2, "fcmChannelDeepLink content \uff1a"

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string/jumbo v2, "tcrATbvetIiynsnnp"

    const-string v2, "InnerTpnsActivity"

    const/4 v8, 0x1

    or-int/2addr v9, v8

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x1

    if-eqz p1, :cond_7

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-nez v1, :cond_7

    :try_start_0
    const/4 v9, 0x0

    const/4 v8, 0x2

    new-instance v1, Lorg/json/JSONObject;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const-string p1, "action"

    const/4 v9, 0x3

    const/4 v8, 0x1

    invoke-virtual {v1, p1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string/jumbo v3, "iettnoupq_a"

    const-string v3, "aon_ytepqti"

    const/4 v9, 0x0

    const-string v3, "cin_aptpyoe"

    const-string v3, "action_type"

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    const/4 v4, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p1, v3, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v3

    const/4 v9, 0x2

    const/4 v8, 0x6

    const-string/jumbo v4, "qvtaisti"

    const-string/jumbo v4, "yisavtit"

    const-string/jumbo v4, "tisacivt"

    const-string v4, "activity"

    const/4 v9, 0x5

    invoke-virtual {p1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string/jumbo v5, "orrmmsw"

    const-string/jumbo v5, "srwmoer"

    const-string/jumbo v5, "swroobe"

    const-string v5, "browser"

    const/4 v9, 0x4

    const/4 v8, 0x3

    invoke-virtual {p1, v5}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string/jumbo v6, "lur"

    const-string/jumbo v6, "lur"

    const/4 v9, 0x5

    const-string/jumbo v6, "ulr"

    const-string/jumbo v6, "url"

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v5, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    const-string/jumbo v6, "nieotb"

    const-string/jumbo v6, "tetion"

    const/4 v9, 0x5

    const-string/jumbo v6, "uetnit"

    const-string/jumbo v6, "intent"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p1, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    const-string/jumbo v6, "uosenompcbtttc"

    const-string v6, "ctecnbnomttosu"

    const/4 v9, 0x0

    const-string/jumbo v6, "otccmsntqeonut"

    const-string v6, "custom_content"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v1, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    new-instance v6, Lcom/tencent/android/tpush/XGPushClickedResult;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-direct {v6}, Lcom/tencent/android/tpush/XGPushClickedResult;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-eq v3, v7, :cond_3

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    const/4 v4, 0x2

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-eq v3, v4, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x7

    const/4 v4, 0x3

    const/4 v8, 0x1

    move v9, v8

    if-eq v3, v4, :cond_1

    const/4 v9, 0x3

    goto :goto_0

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-eqz p1, :cond_5

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-nez v4, :cond_5

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    iput-object p1, v6, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->c(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    goto :goto_0

    :cond_2
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-eqz v5, :cond_5

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-nez p1, :cond_5

    const/4 v8, 0x0

    move v9, v8

    iput-object v5, v6, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-direct {p0, v5}, Lcom/tencent/android/tpush/InnerTpnsActivity;->b(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    goto :goto_0

    :cond_3
    const/4 v9, 0x1

    const/4 v8, 0x3

    if-eqz v4, :cond_4

    const/4 v9, 0x3

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-nez p1, :cond_4

    const/4 v8, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    iput-object v4, v6, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-direct {p0, v4}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    goto :goto_0

    :cond_4
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    iput-object v4, v6, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-direct {p0}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a()V

    :cond_5
    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    iput v3, v6, Lcom/tencent/android/tpush/XGPushClickedResult;->notificationActionType:I

    const/4 v9, 0x0

    iput-object v1, v6, Lcom/tencent/android/tpush/XGPushClickedResult;->customContent:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p1

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    new-instance v1, Lcom/tencent/android/tpush/InnerTpnsActivity$1;

    const/4 v8, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-direct {v1, p0, v0, v6}, Lcom/tencent/android/tpush/InnerTpnsActivity$1;-><init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/os/Bundle;Lcom/tencent/android/tpush/XGPushClickedResult;)V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x3

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    const-string/jumbo v1, "itsetcnnpTnnn:ifCeAshIepvDui l kmecyenL"

    const-string/jumbo v1, "ncpfeeucn CnmpAniLesth Di:nikTvntlreIye"

    const/4 v9, 0x6

    const-string v1, "DekmIpethnainycre:C ALnninpi smvflceten"

    const-string v1, "InnerTpnsActivity fcmChannelDeepLink e:"

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x3

    const/4 v8, 0x1

    invoke-static {v2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    goto :goto_1

    :cond_6
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :cond_7
    :goto_1
    const/4 v9, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x3

    return-void
.end method

.method static synthetic b(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->f(Landroid/content/Intent;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method private b(Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string v0, "ictIoptrTnnnysepi"

    const-string/jumbo v0, "nepItntpcryTsiAin"

    const/4 v4, 0x7

    const-string/jumbo v0, "yeiIvbTcAtninspnt"

    const-string v0, "InnerTpnsActivity"

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v2, "trCnrAucuUO erIh jhtepetritn:iaevtl yneiiasgrAt vcpeymrTtcnlnve"

    const-string v2, "InnerTpnsActivity receiver jumpOtherChannelUrl targetActivity :"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const-string/jumbo v2, "o.nditidqro.ectnaaVWin.InE"

    const/4 v4, 0x3

    const-string/jumbo v2, "ni..od.pntVtcoaeEadnrIiWin"

    const-string v2, "android.intent.action.VIEW"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v1, v2, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/high16 p1, 0x10000000

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1, p1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v3, 0x0

    move v4, v3

    const-string/jumbo p1, "lsnnChpsqeu"

    const-string/jumbo p1, "nnsashlpueC"

    const/4 v4, 0x7

    const-string/jumbo p1, "nnseahhupCl"

    const-string/jumbo p1, "pushChannel"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget v2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->g:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, p1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v1, "orrmeer: rm Unp"

    const-string v1, "Uo:m nlperr err"

    const/4 v4, 0x3

    const-string/jumbo v1, "onr oep oerlrr:"

    const-string/jumbo v1, "openUrl error: "

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void
.end method

.method private c(Landroid/content/Intent;)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo v0, "nnToAbIspvtyiecni"

    const-string/jumbo v0, "vnysopetiAnrTIinc"

    const/4 v6, 0x2

    const-string/jumbo v0, "nrvnsiuTitItcneAp"

    const-string v0, "InnerTpnsActivity"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz p1, :cond_7

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p1}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-eqz p1, :cond_7

    const/4 v6, 0x4

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string/jumbo v3, "ncieeInpbrpecelnAnovy:kr  nCTersruha hepLinDtvettrii"

    const-string/jumbo v3, "unLpsbrnkcaCntyIprheAtr reoD:eeinTeicievr e ilvtnhen"

    const/4 v6, 0x0

    const-string/jumbo v3, "iiLeetrnq rnaeirnevchCesIupcoeenretp t :llrkDTnyhiAn"

    const-string v3, "InnerTpnsActivity receiver otherChannelDeepLink url:"

    const/4 v5, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x0

    const-string/jumbo v1, "mgssu"

    const-string/jumbo v1, "sumgI"

    const/4 v6, 0x4

    const-string v1, "dIsmg"

    const-string/jumbo v1, "msgId"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p1, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string v2, "hkcdopoeC"

    const-string v2, "hkdCccepo"

    const/4 v6, 0x5

    const-string v2, "cCkhobdee"

    const-string v2, "checkCode"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p1, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string/jumbo v3, "lehnnsuhqpa"

    const-string v3, "elChnhsnqap"

    const/4 v6, 0x2

    const-string/jumbo v3, "snunlhapCph"

    const-string/jumbo v3, "pushChannel"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p1, v3}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-nez v4, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v3}, Ljava/lang/Integer;->parseInt(Ljava/lang/String;)I

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    iput v3, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->g:I

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v1, :cond_7

    const/4 v6, 0x0

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez v3, :cond_7

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v2, :cond_7

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v6, 0x2

    const/4 v5, 0x6

    if-nez v3, :cond_7

    const/4 v6, 0x7

    invoke-static {v1}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz v1, :cond_7

    const/4 v6, 0x5

    const/4 v5, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v1, :cond_7

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string/jumbo v1, "quyjTpem"

    const-string v1, "Tmsupyej"

    const/4 v6, 0x1

    const-string/jumbo v1, "upseympT"

    const-string/jumbo v1, "jumpType"

    const/4 v5, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p1, v1}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string v2, "crmmttgiAveytt"

    const-string/jumbo v2, "yvemrtitgctAti"

    const/4 v6, 0x3

    const-string/jumbo v2, "igceorittvatAt"

    const-string/jumbo v2, "targetActivity"

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p1, v2}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz v1, :cond_5

    const/4 v6, 0x3

    const/4 v5, 0x1

    if-eqz v2, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eqz v3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-lez v3, :cond_6

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v3, "0"

    const-string v3, "0"

    const/4 v6, 0x0

    const-string v3, "0"

    const-string v3, "0"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eqz v3, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a()V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto :goto_1

    :cond_2
    const/4 v6, 0x4

    const-string v3, "1"

    const-string v3, "1"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v3, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-direct {p0, v2}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto :goto_1

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string v3, "2"

    const-string v3, "2"

    const/4 v6, 0x0

    const-string v3, "2"

    const-string v3, "2"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v3, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {p0, v2}, Lcom/tencent/android/tpush/InnerTpnsActivity;->b(Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    goto :goto_1

    :cond_4
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v3, "3"

    const-string v3, "3"

    const/4 v6, 0x7

    const-string v3, "3"

    const-string v3, "3"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-eqz v1, :cond_6

    const/4 v6, 0x1

    const/4 v5, 0x2

    invoke-direct {p0, v2}, Lcom/tencent/android/tpush/InnerTpnsActivity;->c(Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    goto :goto_1

    :cond_5
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v1, "entv|bup jltrrAcmtniI = seurcyuTenp n oiIiar=l|ee=lnl=nyttgT vepnt "

    const-string v1, "eelTot|ys|=nvjungt cer= nyunI eiaImi c=tlp= p ineplt  AlrnTuvenrrtt"

    const/4 v6, 0x1

    const-string/jumbo v1, "nervncuv=recnrAte I|u Tst ItplaiytT yinlutln=|ue  plen =jt e=mrgipe"

    const-string v1, "InnerTpnsActivity receiver jumpType == null || targetIntent == null"

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a()V

    :cond_6
    :goto_1
    const/4 v6, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v2, Lcom/tencent/android/tpush/InnerTpnsActivity$3;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-direct {v2, p0, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity$3;-><init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/net/Uri;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :cond_7
    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto :goto_2

    :catchall_0
    move-exception p1

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string/jumbo v2, "rvtiApTp vs:ryireieI nececben"

    const-string v2, "cyceebe  vTpnenAiiinrI:rrevts"

    const/4 v6, 0x0

    const-string/jumbo v2, "incIteAnqrveiseryteT npvcer: "

    const-string v2, "InnerTpnsActivity receiver e:"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    :goto_2
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    return-void
.end method

.method private c(Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string/jumbo v0, "rvscnnntyieAIpTsi"

    const-string v0, "TtiiInuAeyvpcnnsr"

    const/4 v4, 0x0

    const-string v0, "TnvmcysAtprItnein"

    const-string v0, "InnerTpnsActivity"

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo v2, "trevopCneI nTnt caetyrmien tptieOreretujnicAitnscl:ayvvAtheIhrtig"

    const-string v2, "eC iumcpvnep lrtIeyOnrniTceniarryv hi:tIttttatiteAhertenvsncejgnA"

    const/4 v4, 0x6

    const-string v2, ":Crrtbv iehunitrnimeeletaac pttAitvrntIIyOtensnAenevcirhT tpycneg"

    const-string v2, "InnerTpnsActivity receiver jumpOtherChannelIntent targetActivity:"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x1

    move v4, v1

    const/4 v3, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1, v1}, Landroid/content/Intent;->parseUri(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v1, "nd.ItouaiainntedrqcWEtnVoi"

    const-string v1, "d.iEncatqWteonniir.VonIatd"

    const/4 v4, 0x4

    const-string v1, "a.ItnnopVeiE.do.ctWinrdnia"

    const-string v1, "android.intent.action.VIEW"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x2

    const-string v1, "henlhsauqCn"

    const-string/jumbo v1, "nasCluphhne"

    const-string v1, "ahspulneshn"

    const-string/jumbo v1, "pushChannel"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->g:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1, v1}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo v1, "uanmht mprhnoCtlernrIr: tOejme"

    const-string/jumbo v1, "nrrmeeIljpnta  C:thoOeurhrntme"

    const/4 v4, 0x1

    const-string/jumbo v1, "rretoeoI:a pnrelnhmteC hunjtrn"

    const-string/jumbo v1, "jumpOtherChannelIntent error: "

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method

.method private d(Ljava/lang/String;)Landroid/content/pm/ResolveInfo;
    .locals 7

    const/4 v5, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    new-instance v2, Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string/jumbo v3, "rnettbc.iaMio.natoNd.onAnd"

    const-string/jumbo v3, "itAMoItcda.onn..tNdrnnoeai"

    const-string/jumbo v3, "iinco.undt.MAnoIetrdntaai."

    const-string v3, "android.intent.action.MAIN"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-direct {v2, v3, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v6, 0x3

    const/4 v5, 0x0

    const-string v3, "AERU.doptgNrndytetn.oibr.aiLenHC"

    const-string v3, "CtAaabUnyt.ntiREdodornLeiNer.H.g"

    const/4 v6, 0x5

    const-string/jumbo v3, "tRioHoanqCatL.Ngi.rrcdnE.UnyeteA"

    const-string v3, "android.intent.category.LAUNCHER"

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v2, v3}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v3, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    new-instance v3, Landroid/content/pm/ResolveInfo$DisplayNameComparator;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v3, v1}, Landroid/content/pm/ResolveInfo$DisplayNameComparator;-><init>(Landroid/content/pm/PackageManager;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v2, v3}, Ljava/util/Collections;->sort(Ljava/util/List;Ljava/util/Comparator;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x1

    if-eqz v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    check-cast v2, Landroid/content/pm/ResolveInfo;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v3, v2, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v4, v3, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x0

    iget-object v3, v3, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v3, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-eqz v3, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x6

    return-object v2

    :catchall_0
    move-exception p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const-string/jumbo v1, "unstIteTipvirsnnA"

    const-string/jumbo v1, "pvInAiutictTnersn"

    const/4 v6, 0x1

    const-string/jumbo v1, "ttrmypInecAnivnsT"

    const-string v1, "InnerTpnsActivity"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string/jumbo v2, "uA5eot45u37/c6ev19/ubiy725f9aut/16/upe"

    const-string v2, "51c/6Aupy4uut5iu3a962bf/u/v1//e5e797te"

    const/4 v6, 0x3

    const-string v2, "e/i29b/7ea636uy7uvft/tAc/511buiu54ue9/"

    const-string/jumbo v2, "\u67e5\u627e\u4e3bActivity\u51fa\u9519"

    const/4 v5, 0x5

    move v6, v5

    invoke-static {v1, v2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-object v0
.end method

.method private d(Landroid/content/Intent;)V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz p1, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-string/jumbo v0, "viqtyaui"

    const-string/jumbo v0, "qtviayit"

    const/4 v7, 0x0

    const-string/jumbo v0, "tivcyaip"

    const-string v0, "activity"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v1, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto :goto_0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x6

    const-string v0, ""

    const-string v0, ""

    :goto_0
    const/4 v6, 0x6

    move v7, v6

    sget-boolean v1, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    if-eqz v1, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string v2, "a nci ntq=settity"

    const-string/jumbo v2, "ttsaticie tnyni ="

    const/4 v7, 0x3

    const-string v2, " nst=tyen aiittci"

    const-string v2, "activity intent ="

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string/jumbo v2, "mt mv= iciy"

    const-string/jumbo v2, "viamc=yi t "

    const/4 v7, 0x5

    const-string/jumbo v2, "tac=o  itiv"

    const-string v2, "activity = "

    const/4 v7, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v2, "etionb.n)tgaest(l"

    const-string/jumbo v2, "t)lsoanneg(itgt.e"

    const/4 v7, 0x7

    const-string v2, ".)atilueFt(gnsgen"

    const-string/jumbo v2, "intent.getFlags()"

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p1}, Landroid/content/Intent;->getFlags()I

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string v2, "icpsnynpbTtetvIrn"

    const-string v2, "TInynbetvirnscptA"

    const/4 v7, 0x1

    const-string/jumbo v2, "nynerpitqiTsAncvI"

    const-string v2, "InnerTpnsActivity"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo v1, "udssI"

    const-string/jumbo v1, "suIgd"

    const/4 v7, 0x3

    const-string v1, "Ismmd"

    const-string/jumbo v1, "msgId"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p1, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    sput-wide v4, Lcom/tencent/android/tpush/InnerTpnsActivity;->d:J

    const/4 v7, 0x5

    const/4 v6, 0x2

    const-string v1, "dpsioMsbg"

    const-string/jumbo v1, "isbudMspg"

    const/4 v7, 0x3

    const-string/jumbo v1, "sugbsbdiI"

    const-string v1, "busiMsgId"

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p1, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    sput-wide v1, Lcom/tencent/android/tpush/InnerTpnsActivity;->e:J

    const/4 v7, 0x4

    const/4 v6, 0x0

    sput-object v0, Lcom/tencent/android/tpush/InnerTpnsActivity;->c:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto :goto_1

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v0, 0x0

    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    new-instance v1, Landroid/content/Intent;

    const/4 v7, 0x2

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-eqz p1, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {p1}, Landroid/content/Intent;->getFlags()I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string v0, "MsaGqhuutS.gt"

    const-string/jumbo v0, "tus.tapGqSghM"

    const/4 v7, 0x0

    const-string/jumbo v0, "sSGpth.patM.g"

    const-string/jumbo v0, "tag.tpush.MSG"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string/jumbo v2, "rteu"

    const-string v2, "eutr"

    const/4 v7, 0x0

    const-string/jumbo v2, "teru"

    const-string/jumbo v2, "true"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {p1, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v1, p1}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/high16 v0, 0x20000000

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v1, v0}, Landroid/content/Intent;->addFlags(I)Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/app/Activity;)Lcom/tencent/android/tpush/XGPushClickedResult;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string v2, "gaTs.tItqFhICuspO"

    const-string v2, "FNsuI.tICphgstTaO"

    const/4 v7, 0x1

    const-string v2, "IssOCathutNIFT..p"

    const-string/jumbo v2, "tag.tpush.NOTIFIC"

    const/4 v7, 0x0

    invoke-virtual {v1, v2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const-string/jumbo v0, "utom_nsmottccn"

    const-string v0, "ctmm_ntuconsto"

    const/4 v7, 0x5

    const-string/jumbo v0, "unntotsmcot_co"

    const-string v0, "custom_content"

    const/4 v7, 0x1

    const/4 v6, 0x0

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-nez v2, :cond_4

    const/4 v6, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v1, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_4
    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Landroid/app/Application;)V

    const/4 v7, 0x0

    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    return-void
.end method

.method private e(Landroid/content/Intent;)V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->g(Landroid/content/Intent;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v0, "amkeebapNca"

    const-string/jumbo v0, "packageName"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {p0, v0}, Lcom/tencent/android/tpush/InnerTpnsActivity;->d(Ljava/lang/String;)Landroid/content/pm/ResolveInfo;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    iget-object v0, v0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v5, 0x0

    iget-object v1, v0, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, v0, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    const/4 v5, 0x4

    new-instance v2, Landroid/content/Intent;

    const/4 v5, 0x1

    invoke-direct {v2}, Landroid/content/Intent;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v3, Landroid/content/ComponentName;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v3, v0, v1}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const-string/jumbo v0, "unotsnuoeco_tc"

    const-string/jumbo v0, "stceocnouot_mn"

    const/4 v5, 0x1

    const-string/jumbo v0, "n_centtpmctsuo"

    const-string v0, "custom_content"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    if-nez v1, :cond_0

    const/4 v5, 0x3

    invoke-virtual {v2, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    const/4 p1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {p0, p1, v2}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(ILandroid/content/Intent;)V

    const/4 v4, 0x3

    move v5, v4

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v0, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {p0, v0, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(ILandroid/content/Intent;)V

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-void
.end method

.method private f(Landroid/content/Intent;)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    const-string/jumbo v0, "tncm_useqocbnt"

    const-string/jumbo v0, "omsc_btenuncot"

    const-string/jumbo v0, "utsceoctmonst_"

    const-string v0, "custom_content"

    :try_start_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    new-instance v1, Landroid/content/Intent;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-direct {v1}, Landroid/content/Intent;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v2, "_cimoattpny"

    const-string v2, "action_type"

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    sget-object v3, Lcom/tencent/android/tpush/NotificationAction;->intent:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v3}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1, v2, v4}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v3}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string/jumbo v4, "ytatoicu"

    const-string/jumbo v4, "itcatiuy"

    const/4 v6, 0x1

    const-string v4, "aityibvt"

    const-string v4, "activity"

    const/4 v6, 0x5

    const/4 v5, 0x0

    if-ne v2, v3, :cond_2

    :try_start_1
    const/4 v5, 0x3

    move v6, v5

    const-string v1, "CpPNUHuA.SEL"

    const-string v1, "ECH.PUNpLHAS"

    const/4 v6, 0x0

    const-string v1, "PAENH.LpUCNH"

    const-string v1, "PUSH.CHANNEL"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/16 v2, 0x64

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {p1, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    iput v1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->g:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/16 v2, 0x65

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/4 v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    if-eq v1, v2, :cond_1

    const/4 v6, 0x5

    const/16 v2, 0x63

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-ne v1, v2, :cond_0

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p1, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v1, v3}, Landroid/content/Intent;->parseUri(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p1, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo v2, "q8FqU"

    const-string v2, "8UTqF"

    const/4 v6, 0x1

    const-string v2, "FUs8-"

    const-string v2, "UTF-8"

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {v1, v2}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v1, v3}, Landroid/content/Intent;->parseUri(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v1

    :goto_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v2, ".nWmaiode.IE.siVndoitnrctt"

    const-string/jumbo v2, "iisotd..ntdntWnr.onIVcaeEi"

    const/4 v6, 0x5

    const-string v2, "iIdioidnn..Eta.rotVaenontc"

    const-string v2, "android.intent.action.VIEW"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_2

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    sget-object v3, Lcom/tencent/android/tpush/NotificationAction;->intent_with_action:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v3}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-ne v2, v3, :cond_3

    const/4 v5, 0x6

    or-int/2addr v6, v5

    invoke-virtual {p1, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/high16 v2, 0x10000000

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    :cond_3
    :goto_2
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string v2, "Cnslnbpamhu"

    const-string/jumbo v2, "lnamphCnhsu"

    const/4 v6, 0x2

    const-string v2, "Csuahnunplh"

    const-string/jumbo v2, "pushChannel"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget v3, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->g:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-nez v2, :cond_4

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v1, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_4
    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/app/Activity;)Lcom/tencent/android/tpush/XGPushClickedResult;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v1, p1}, Landroid/content/Intent;->resolveActivity(Landroid/content/pm/PackageManager;)Landroid/content/ComponentName;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    if-eqz p1, :cond_5

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V

    :cond_5
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x6

    goto :goto_3

    :catchall_0
    move-exception p1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string/jumbo v0, "nTinevspcIrypnito"

    const-string/jumbo v0, "pInsoyetivrticnnT"

    const/4 v6, 0x2

    const-string v0, "ItepvyAtqnnsrTici"

    const-string v0, "InnerTpnsActivity"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string v1, " nre.boproeteIrnt"

    const/4 v6, 0x6

    const-string/jumbo v1, "nes.err nportonet"

    const-string/jumbo v1, "openIntent error."

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_3
    const/4 v6, 0x5

    return-void
.end method

.method private g(Landroid/content/Intent;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v2, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public static getMsgIdWithIntent(Landroid/content/Intent;)J
    .locals 8

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-nez p0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-wide v0

    :cond_0
    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p0}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string/jumbo v3, "suImd"

    const-string/jumbo v3, "sumId"

    const/4 v7, 0x0

    const-string/jumbo v3, "smIgo"

    const-string/jumbo v3, "msgId"

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    if-eqz v2, :cond_2

    :try_start_1
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    if-eqz v2, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x0

    instance-of v4, v2, Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-eqz v4, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    check-cast v2, Ljava/lang/String;

    const/4 v6, 0x6

    move v7, v6

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    const/4 v7, 0x7

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    instance-of v4, v2, Ljava/lang/Long;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-eqz v4, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    check-cast v2, Ljava/lang/Long;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v2}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto :goto_0

    :cond_2
    move-wide v4, v0

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    cmp-long v2, v4, v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-nez v2, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x2

    if-eqz p0, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {p0, v3}, Landroid/net/Uri;->getQueryParameter(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-nez v2, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-static {p0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_3
    const/4 v7, 0x7

    const/4 v6, 0x3

    return-wide v4

    :catchall_0
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x5

    return-wide v0
.end method

.method public static isMonitorActivityNames(Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/android/tpush/InnerTpnsActivity;->b:Ljava/util/List;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    move v3, v2

    if-nez v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    return v1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    return v1

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object v0, Lcom/tencent/android/tpush/InnerTpnsActivity;->b:Ljava/util/List;

    const/4 v3, 0x4

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz p0, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 p0, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    return p0

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    return v1
.end method


# virtual methods
.method protected onCreate(Landroid/os/Bundle;)V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string/jumbo v0, "pIrcsbpynttnnieiT"

    const-string v0, "TcIvnpipysrienttn"

    const/4 v6, 0x0

    const-string/jumbo v0, "pAtiirunncsTtvenI"

    const-string v0, "InnerTpnsActivity"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-super {p0, p1}, Landroid/app/Activity;->onCreate(Landroid/os/Bundle;)V

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    sget-boolean p1, Lcom/tencent/android/tpush/XGPushConfig;->enableActivityWindowSecFlag:Z

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz p1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->getWindow()Landroid/view/Window;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/16 v1, 0x2000

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-static {p1, v1, v1}, Lru/oleg543/utils/Window;->setFlags(Landroid/view/Window;II)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    :try_start_1
    const/4 v5, 0x3

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string/jumbo v2, "ttcntAipnIiitrven ceevpnn Teyrsriq"

    const-string/jumbo v2, "rI cenp qtrviniesTtentinieyncAevtr"

    const/4 v6, 0x2

    const-string/jumbo v2, "tTentticqvrIiAtev  n:csrnrpieinney"

    const-string v2, "InnerTpnsActivity receiver intent:"

    const/4 v5, 0x4

    shr-int/2addr v6, v5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string/jumbo v1, "uCsenhsapln"

    const-string/jumbo v1, "nasnhpleCsu"

    const/4 v6, 0x6

    const-string v1, "enpmlsunhhC"

    const-string/jumbo v1, "pushChannel"

    if-eqz p1, :cond_1

    :try_start_2
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p1}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x7

    invoke-virtual {v2, v1}, Landroid/os/BaseBundle;->containsKey(Ljava/lang/String;)Z

    move-result v3

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eqz v3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v2, v1}, Landroid/os/BaseBundle;->get(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    instance-of v3, v3, Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v3, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x2

    invoke-virtual {v2, v1}, Landroid/os/BaseBundle;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    if-eqz v2, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-nez v3, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    iput v2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->g:I

    const/4 v6, 0x5

    const/16 v3, 0x65

    const/4 v6, 0x2

    const/4 v5, 0x3

    if-ne v2, v3, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->b(Landroid/content/Intent;)V

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Landroid/content/Intent;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v2, :cond_8

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/16 v2, 0x64

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {p1, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    iput v1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity;->g:I

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v1, "ti_modiconfnia"

    const-string/jumbo v1, "nacmdifi_titno"

    const-string/jumbo v1, "tnti_bndioaifo"

    const-string/jumbo v1, "notifaction_id"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {p1, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    const-string/jumbo v3, "kisttautoConntCooIcLBumiuuy"

    const-string v3, "ansuotCtLnoyouCmiciBIutktol"

    const/4 v6, 0x5

    const-string/jumbo v3, "ytkiuasptuCocouClnniLstomtI"

    const-string/jumbo v3, "isButtonClickInCustomLayout"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p1, v3, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-eqz v3, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v3, v1}, Lcom/tencent/android/tpush/XGPushManager;->cancelNotifaction(Landroid/content/Context;I)V

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo v1, "ticotbna_yp"

    const/4 v6, 0x4

    const-string v1, "capity_nqoe"

    const-string v1, "action_type"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    sget-object v3, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v3}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p1, v1, v4}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v3}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-ne v1, v3, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->d(Landroid/content/Intent;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto/16 :goto_1

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    sget-object v3, Lcom/tencent/android/tpush/NotificationAction;->action_package:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v3}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-ne v1, v3, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->e(Landroid/content/Intent;)V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    goto :goto_1

    :cond_4
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    sget-object v3, Lcom/tencent/android/tpush/NotificationAction;->url:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v5, 0x5

    and-int/2addr v6, v5

    invoke-virtual {v3}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-ne v1, v3, :cond_5

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-direct {p0, v2, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->b(ILandroid/content/Intent;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    goto :goto_1

    :cond_5
    const/4 v6, 0x3

    sget-object v2, Lcom/tencent/android/tpush/NotificationAction;->intent:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v2}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    if-eq v1, v2, :cond_7

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    sget-object v2, Lcom/tencent/android/tpush/NotificationAction;->intent_with_action:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-ne v1, v2, :cond_6

    const/4 v6, 0x6

    goto :goto_0

    :cond_6
    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_1

    :cond_7
    :goto_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    const/4 v1, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {p0, v1, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->b(ILandroid/content/Intent;)V

    const/4 v6, 0x7

    const/4 v5, 0x2

    goto :goto_1

    :cond_8
    const/4 v6, 0x0

    const/4 v5, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/InnerTpnsActivity;->c(Landroid/content/Intent;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    goto :goto_1

    :catchall_1
    move-exception p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string/jumbo v1, "nnsrawu"

    const-string/jumbo v1, "nraniwu"

    const-string v1, "awnmirn"

    const-string/jumbo v1, "warning"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :try_start_3
    const/4 v5, 0x5

    move v6, v5

    invoke-virtual {p0}, Landroid/app/Activity;->finish()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :catchall_2
    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    return-void
.end method

.method protected onPause()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-super {p0}, Landroid/app/Activity;->onPause()V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method protected onResume()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-super {p0}, Landroid/app/Activity;->onResume()V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method protected onStart()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-super {p0}, Landroid/app/Activity;->onStart()V

    const/4 v0, 0x6

    move v1, v0

    return-void
.end method

.method protected onStop()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-super {p0}, Landroid/app/Activity;->onStop()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-void
.end method
