.class Lcom/tencent/android/tpush/XGPushManager$21;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/XGIOperateCallback;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:I

.field final synthetic e:Ljava/lang/String;

.field final synthetic f:J

.field final synthetic g:Ljava/lang/String;

.field final synthetic h:Ljava/lang/String;

.field final synthetic i:Ljava/lang/String;

.field final synthetic j:Ljava/lang/String;

.field final synthetic k:J


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;Ljava/lang/String;ILjava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$21;->a:Landroid/content/Context;

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$21;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPushManager$21;->c:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput p4, p0, Lcom/tencent/android/tpush/XGPushManager$21;->d:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p5, p0, Lcom/tencent/android/tpush/XGPushManager$21;->e:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-wide p6, p0, Lcom/tencent/android/tpush/XGPushManager$21;->f:J

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p8, p0, Lcom/tencent/android/tpush/XGPushManager$21;->g:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p9, p0, Lcom/tencent/android/tpush/XGPushManager$21;->h:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p10, p0, Lcom/tencent/android/tpush/XGPushManager$21;->i:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p11, p0, Lcom/tencent/android/tpush/XGPushManager$21;->j:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-wide p12, p0, Lcom/tencent/android/tpush/XGPushManager$21;->k:J

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 15

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$21;->a:Landroid/content/Context;

    const-string v1, ""

    const-string v1, ""

    if-nez v0, :cond_0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$21;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    sget-object v2, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_LOGIC_ILLEGAL_ARGUMENT:Lcom/tencent/android/tpush/common/ReturnCode;

    invoke-virtual {v2}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v2

    const-string/jumbo v3, "llsotnnaccaetpera tr ut  me onne!Teshb"

    const-string v3, "eesm te aap n eoe!trtTtlnn  nhaboucclr"

    const-string v3, "crem tec e mbtnlnxh  raotao unpltaeT!e"

    const-string v3, "The context parameter can not be null!"

    invoke-interface {v0, v1, v2, v3}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    return-void

    :cond_0
    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->a()Z

    move-result v0

    if-eqz v0, :cond_2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$21;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    if-eqz v0, :cond_1

    sget-object v2, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_SDK_API_FREQUENCY_LIMIT_ERROR:Lcom/tencent/android/tpush/common/ReturnCode;

    invoke-virtual {v2}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v0, v1, v3, v2}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_1
    return-void

    :cond_2
    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$21;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/base/util/NetworkUtil;->isNetworkConnected(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$21;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    if-eqz v0, :cond_3

    sget-object v2, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_NETWORK_UNREACHABLE:Lcom/tencent/android/tpush/common/ReturnCode;

    invoke-virtual {v2}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v2

    const-string v3, "cck ooe!sohw ,akepigltaeen annm"

    const-string v3, " !nmee,ikc notlenaasweorcgphk a"

    const-string v3, "aegtib hn ekocwea k ,n!prnloces"

    const-string/jumbo v3, "no network, please check again!"

    invoke-interface {v0, v1, v2, v3}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    return-void

    :cond_3
    const/4 v0, 0x1

    sput v0, Lcom/tencent/android/tpush/service/util/c;->a:I

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$21;->a:Landroid/content/Context;

    invoke-static {v1}, Lcom/tencent/android/tpush/XGPushManager;->initCommonComponents(Landroid/content/Context;)V

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$21;->a:Landroid/content/Context;

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v1, 0x0

    const-string v3, "_asv_ruribe_teceoyssu"

    const-string/jumbo v3, "r_r_osutbeaeeissyvt_c"

    const-string/jumbo v3, "start_service_by_user"

    invoke-static {v2, v3, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getBoolean(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result v1

    if-nez v1, :cond_4

    invoke-static {v2, v3, v0}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putBoolean(Landroid/content/Context;Ljava/lang/String;Z)V

    :cond_4
    invoke-static {v2}, Lcom/tencent/android/tpush/XGPushManager;->setContext(Landroid/content/Context;)V

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/XGPushManager;->enableService(Landroid/content/Context;Z)V

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->b()Z

    move-result v1

    if-nez v1, :cond_5

    invoke-static {v2}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportIsCustomDataAcquisitionVersion(Landroid/content/Context;)V

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Z)Z

    :cond_5
    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/lang/Long;)Ljava/lang/Long;

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$21;->c:Ljava/lang/String;

    iget v4, p0, Lcom/tencent/android/tpush/XGPushManager$21;->d:I

    iget-object v5, p0, Lcom/tencent/android/tpush/XGPushManager$21;->e:Ljava/lang/String;

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$21;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    iget-wide v7, p0, Lcom/tencent/android/tpush/XGPushManager$21;->f:J

    iget-object v9, p0, Lcom/tencent/android/tpush/XGPushManager$21;->g:Ljava/lang/String;

    iget-object v10, p0, Lcom/tencent/android/tpush/XGPushManager$21;->h:Ljava/lang/String;

    iget-object v11, p0, Lcom/tencent/android/tpush/XGPushManager$21;->i:Ljava/lang/String;

    iget-object v12, p0, Lcom/tencent/android/tpush/XGPushManager$21;->j:Ljava/lang/String;

    iget-wide v13, p0, Lcom/tencent/android/tpush/XGPushManager$21;->k:J

    invoke-static/range {v2 .. v14}, Lcom/tencent/android/tpush/XGPushManager;->c(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V

    return-void
.end method
