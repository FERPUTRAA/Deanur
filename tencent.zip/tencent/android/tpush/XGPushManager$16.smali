.class Lcom/tencent/android/tpush/XGPushManager$16;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Lcom/tencent/android/tpush/XGLocalMessage;J)J
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Lcom/tencent/android/tpush/XGLocalMessage;

.field final synthetic d:J


# direct methods
.method constructor <init>(JLandroid/content/Context;Lcom/tencent/android/tpush/XGLocalMessage;J)V
    .locals 2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-wide p1, p0, Lcom/tencent/android/tpush/XGPushManager$16;->a:J

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPushManager$16;->b:Landroid/content/Context;

    const/4 v1, 0x5

    iput-object p4, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v1, 0x5

    iput-wide p5, p0, Lcom/tencent/android/tpush/XGPushManager$16;->d:J

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 15

    const-string v14, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v13, " os~l1~  @@o~@ @yb~@~ob@ ~.@vM@ba@@~  m~ @-t@K@~l4@r  ~ f@t~/~~ ~  is~in  ~ou@oco~d@~ @@~~i~/fS~"

    const-string v13, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v14, 0x6

    const-string v0, "PsMmgXeaansGh"

    const-string v0, "eXsnPasraGgMh"

    const/4 v14, 0x7

    const-string v0, "MaGgoesaXuhrn"

    const-string v0, "XGPushManager"

    :try_start_0
    const/4 v13, 0x5

    const/4 v14, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/XGPushManager$16;->a:J

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x6

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v14, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v14, 0x0

    cmp-long v5, v1, v3

    const/4 v14, 0x0

    const/4 v13, 0x2

    if-gtz v5, :cond_0

    const/4 v13, 0x6

    move v14, v13

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$16;->b:Landroid/content/Context;

    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v1

    :cond_0
    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x6

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    or-int/2addr v14, v13

    const/16 v6, 0x40

    const/4 v14, 0x3

    const/4 v13, 0x2

    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-virtual {v5, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x6

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x4

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getMsgId()J

    move-result-wide v6

    const/4 v14, 0x5

    const/4 v13, 0x4

    invoke-virtual {v5, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x3

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->b:Landroid/content/Context;

    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x3

    invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x5

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getTitle()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x5

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x5

    const-string v7, ""

    const-string v7, ""

    const/4 v14, 0x0

    const-string v7, ""

    const-string v7, ""

    const/4 v13, 0x5

    and-int/2addr v14, v13

    if-eqz v6, :cond_1

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x1

    goto :goto_0

    :cond_1
    :try_start_1
    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x6

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getTitle()Ljava/lang/String;

    move-result-object v6

    :goto_0
    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x3

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x0

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x6

    const/4 v13, 0x4

    const/4 v14, 0x6

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getContent()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x0

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v14, 0x6

    const/4 v13, 0x4

    const/4 v14, 0x7

    if-eqz v6, :cond_2

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x6

    goto :goto_1

    :cond_2
    const/4 v14, 0x2

    const/4 v13, 0x0

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x1

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getContent()Ljava/lang/String;

    move-result-object v6

    :goto_1
    const/4 v14, 0x4

    const/4 v13, 0x6

    const/4 v14, 0x4

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const/4 v13, 0x6

    const/4 v14, 0x7

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v13, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x0

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getCustom_content()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x1

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x2

    if-nez v8, :cond_3

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x1

    new-instance v8, Lorg/json/JSONObject;

    const/4 v14, 0x1

    const/4 v13, 0x3

    invoke-direct {v8, v6}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x4

    invoke-virtual {v8}, Lorg/json/JSONObject;->length()I

    move-result v8

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x6

    if-nez v8, :cond_4

    :cond_3
    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    :cond_4
    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x2

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x0

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v13, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x6

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getType()I

    move-result v6

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x5

    const/4 v8, 0x1

    const/4 v14, 0x4

    const/4 v13, 0x2

    if-ne v6, v8, :cond_8

    const/4 v14, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x5

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x1

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getUrl()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x3

    const/4 v13, 0x1

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v14, 0x3

    const/4 v13, 0x6

    const/4 v14, 0x2

    if-eqz v6, :cond_5

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x4

    goto :goto_2

    :cond_5
    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x2

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x6

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getUrl()Ljava/lang/String;

    move-result-object v6

    :goto_2
    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x4

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x0

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x4

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getIntent()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x3

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x0

    if-eqz v6, :cond_6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x3

    goto :goto_3

    :cond_6
    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x3

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x5

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getIntent()Ljava/lang/String;

    move-result-object v6

    :goto_3
    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x2

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x0

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x4

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getActivity()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x3

    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x2

    if-eqz v6, :cond_7

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x0

    goto :goto_4

    :cond_7
    const/4 v14, 0x5

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x2

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getActivity()Ljava/lang/String;

    move-result-object v7

    :goto_4
    const/4 v14, 0x2

    const/4 v13, 0x6

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_8
    const/4 v14, 0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v14, 0x2

    const/4 v13, 0x3

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x5

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x0

    const-string v7, "h.smtbc.loulapgs"

    const-string v7, "hscmsg.tu.ll.oap"

    const/4 v14, 0x6

    const-string/jumbo v7, "tpush.local.msg."

    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x2

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x1

    invoke-static {v5}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x4

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x6

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x7

    iget-object v7, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x4

    invoke-virtual {v7}, Lcom/tencent/android/tpush/XGLocalMessage;->getExpirationTimeMs()J

    move-result-wide v9

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x3

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x7

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v14, 0x5

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x1

    const-string/jumbo v5, "out,g"

    const-string v5, "a,tgo"

    const/4 v14, 0x7

    const-string v5, ":gp,a"

    const-string v5, ",tag:"

    const/4 v14, 0x3

    const/4 v13, 0x5

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    const-string/jumbo v5, "xpbq:"

    const-string v5, "b:px,"

    const-string/jumbo v5, "p:sx,"

    const-string v5, ",exp:"

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x7

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x1

    invoke-virtual {v7, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    const/4 v13, 0x2

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x1

    invoke-static {v0, v5}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x4

    new-instance v5, Lcom/tencent/android/tpush/service/protocol/j;

    const/4 v13, 0x4

    const/4 v13, 0x6

    const/4 v14, 0x4

    invoke-direct {v5}, Lcom/tencent/android/tpush/service/protocol/j;-><init>()V

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x0

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x2

    invoke-virtual {v6}, Lcom/tencent/android/tpush/XGLocalMessage;->getMsgId()J

    move-result-wide v6

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x6

    iput-wide v6, v5, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x4

    iput-wide v1, v5, Lcom/tencent/android/tpush/service/protocol/j;->b:J

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$16;->b:Landroid/content/Context;

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x7

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x4

    iput-object v1, v5, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v13, 0x6

    move v14, v13

    invoke-virtual {v1}, Lcom/tencent/android/tpush/XGLocalMessage;->getBusiMsgId()J

    move-result-wide v1

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x7

    iput-wide v1, v5, Lcom/tencent/android/tpush/service/protocol/j;->c:J

    const/4 v13, 0x1

    shr-int/2addr v14, v13

    iget-wide v1, p0, Lcom/tencent/android/tpush/XGPushManager$16;->d:J

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x0

    const-wide/16 v6, 0x3e8

    const/4 v14, 0x7

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x0

    div-long v11, v1, v6

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x6

    iput-wide v11, v5, Lcom/tencent/android/tpush/service/protocol/j;->h:J

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x7

    neg-long v1, v1

    const/4 v13, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x5

    iput-wide v1, v5, Lcom/tencent/android/tpush/service/protocol/j;->k:J

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x1

    invoke-virtual {v1}, Lcom/tencent/android/tpush/XGLocalMessage;->getTtl()I

    move-result v1

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x1

    iput v1, v5, Lcom/tencent/android/tpush/service/protocol/j;->l:I

    const/4 v14, 0x1

    const/4 v13, 0x4

    const/4 v14, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x7

    const/4 v13, 0x6

    const/4 v14, 0x6

    invoke-virtual {v1}, Lcom/tencent/android/tpush/XGLocalMessage;->getType()I

    move-result v1

    const/4 v14, 0x1

    const/4 v13, 0x7

    int-to-long v1, v1

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x6

    iput-wide v1, v5, Lcom/tencent/android/tpush/service/protocol/j;->f:J

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x1

    iput-wide v3, v5, Lcom/tencent/android/tpush/service/protocol/j;->i:J

    const/4 v13, 0x4

    const/4 v14, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x3

    invoke-virtual {v1}, Lcom/tencent/android/tpush/XGLocalMessage;->getDate()Ljava/lang/String;

    move-result-object v1

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x4

    iput-object v1, v5, Lcom/tencent/android/tpush/service/protocol/j;->j:Ljava/lang/String;

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v14, 0x0

    const/4 v13, 0x4

    const-string/jumbo v2, "l{:m//i///ett"

    const-string v2, "/{ti/tu//el:/"

    const/4 v14, 0x2

    const-string/jumbo v2, "{\"title\":\""

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x7

    const/4 v13, 0x6

    const/4 v14, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x0

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getTitle()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x6

    const-string v2, "c/noot///te//n/p,"

    const-string v2, "//,/nc/p/nt/et/o:"

    const/4 v14, 0x2

    const-string/jumbo v2, "n:/e/b/n//,tt/c/o"

    const-string v2, "\",\"content\":\""

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getContent()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x0

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x2

    const-string/jumbo v2, "u:rl//i/qbd/e_/id/"

    const/4 v14, 0x1

    const-string v2, "_bidliu///,ed/ru/:"

    const-string v2, "\",\"builder_id\":"

    const/4 v14, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getBuilderId()J

    move-result-wide v2

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x1

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v14, 0x7

    const-string/jumbo v2, "t/,o_tepsms:otncu/c/"

    const-string v2, "/:setnocosut/_c/t,/m"

    const/4 v14, 0x0

    const-string v2, ",e/c/n/tqtm_s:ot/ucn"

    const-string v2, ",\"custom_content\":"

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x6

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getCustom_content()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x0

    const/4 v13, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const-string/jumbo v2, "r/s/gm:,i/"

    const-string v2, "/rnm//ig:,"

    const/4 v14, 0x5

    const-string/jumbo v2, "n/:m/,ig/r"

    const-string v2, ",\"ring\":"

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getRing()I

    move-result v2

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v2, "ea/vo,//riot:"

    const-string v2, ",/ibor//ea:tv"

    const/4 v14, 0x6

    const-string v2, "a/b:ebi/r//vt"

    const-string v2, ",\"vibrate\":"

    const/4 v14, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x4

    const/4 v13, 0x3

    const/4 v14, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getVibrate()I

    move-result v2

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x4

    const-string v2, "bs//g,u:/ilt"

    const-string/jumbo v2, "t//g:bi/,sl/"

    const/4 v14, 0x6

    const-string v2, "///t,lsph/:i"

    const-string v2, ",\"lights\":"

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x5

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getLights()I

    move-result v2

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x6

    const-string v2, "_/,/i/:/qu"

    const-string v2, "/,/ni:u_//"

    const/4 v14, 0x3

    const-string v2, "dns_//i:/,"

    const-string v2, ",\"n_id\":"

    const/4 v14, 0x3

    const/4 v13, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x5

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getNotificationId()I

    move-result v2

    const/4 v14, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x4

    const-string v2, "///m,s/wpeoiyt:psh"

    const-string/jumbo v2, "o//_e,sp/s/iyhptw:"

    const/4 v14, 0x4

    const-string v2, ",\"is_show_type\":"

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const/4 v13, 0x4

    const/4 v14, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x7

    const/4 v13, 0x3

    const/4 v14, 0x0

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getNsModel()I

    move-result v2

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x6

    const-string v2, "__nho:iq/d/// ,/"

    const-string v2, "d_/ n/_/q/,hi/:/"

    const/4 v14, 0x6

    const-string v2, "_,/dhb:/_c// /n/"

    const-string v2, ", \"n_ch_id\":\""

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x6

    const/4 v13, 0x5

    const/4 v14, 0x6

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getChannelId()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x6

    const-string/jumbo v2, "os/ miue/a//c:pt_/rn/"

    const-string/jumbo v2, "pistn/r//:o_n///a emc"

    const/4 v14, 0x0

    const-string/jumbo v2, "n prcntp_ea//o//mi//:"

    const-string v2, "\", \"n_importance\":"

    const/4 v14, 0x5

    const/4 v13, 0x7

    const/4 v14, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const/4 v13, 0x4

    const/4 v14, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v13, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getNotificationImportance()I

    move-result v2

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x6

    const-string v2, "/y//gar/qen:/mt/ c_"

    const-string v2, "/y,m :a//cen/g/r/t_"

    const-string/jumbo v2, "ons/cgy_r /t/ea,://"

    const-string v2, ", \"n_category\":\""

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x4

    const/4 v13, 0x3

    const/4 v14, 0x6

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getNotificationCategory()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x0

    const-string v2, "gnwm/,a_/:/rio////"

    const-string v2, "///ro/_w:/rig,a/n/"

    const/4 v14, 0x1

    const-string v2, "/_/goi,/ra//r//nw:"

    const-string v2, "\",\"ring_raw\":\""

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getRing_raw()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x2

    const/4 v13, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x6

    const-string v2, "//tepb,by/o//c/i:"

    const-string v2, ",/_/obte/piy/:/c/"

    const/4 v14, 0x3

    const-string/jumbo v2, "t/p/n/uyi:o//e_/c"

    const-string v2, "\",\"icon_type\":"

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x7

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getIcon_type()I

    move-result v2

    const/4 v14, 0x7

    const/4 v13, 0x7

    const/4 v14, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x6

    const-string/jumbo v2, "o/:r/o/puc/"

    const-string v2, ":///l/uroco"

    const-string/jumbo v2, "l:o/o/,rqc/"

    const-string v2, ",\"color\":"

    const/4 v13, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x1

    const/4 v13, 0x7

    const/4 v14, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x0

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getColor()I

    move-result v2

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x6

    const-string v2, ":nsoir/_/cse,///"

    const-string v2, "/i:_/,/pnrc//ose"

    const/4 v14, 0x7

    const-string v2, "//:m/s,/o_ce/rin"

    const-string v2, ",\"icon_res\":\""

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getIcon_res()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x7

    const-string v2, "g/q/o:so/r,/_isd/rm/x//ecu_e"

    const-string/jumbo v2, "rcm//oa:qs__esig/x/u///d/,er"

    const/4 v14, 0x4

    const-string v2, "/,s:rb_a//eeoumd/xg/e//i_rsc"

    const-string v2, "\",\"xg_media_resources\":\""

    const/4 v14, 0x5

    const/4 v13, 0x2

    const/4 v14, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getTpns_media_resources()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x5

    const/4 v13, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x1

    const-string v2, "/d///su/:_yiet/,"

    const-string/jumbo v2, "l/syi/d,//_//t:e"

    const/4 v14, 0x2

    const-string/jumbo v2, "slyd/i/p_,/e:/t/"

    const-string v2, "\",\"style_id\":"

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x5

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getStyle_id()I

    move-result v2

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const-string/jumbo v2, "o:inm//lq/,lsmc//_"

    const-string/jumbo v2, "ocmml/si,_//l:/n//"

    const/4 v14, 0x2

    const-string v2, ",\"small_icon\":\""

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x5

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getSmall_icon()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x4

    const-string v2, "/:set//be_/y/opdg,"

    const-string v2, "/tg/o,y/p/:b/ede_/"

    const/4 v14, 0x2

    const-string v2, "_pbm:g///t/dya,e//"

    const-string v2, "\",\"badge_type\":"

    const/4 v14, 0x7

    const/4 v13, 0x0

    const/4 v14, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getBadgeType()I

    move-result v2

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    const/4 v13, 0x6

    const/4 v14, 0x5

    const-string/jumbo v2, "r,/e/b_/id/ad/:h/"

    const/4 v14, 0x4

    const-string v2, "ha:/o/ri//ddt_/e,"

    const-string v2, ",\"thread_id\":\""

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getThreadId()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x6

    const/4 v14, 0x1

    const-string v2, "a/xmebt,dr_u:/sth///teu/"

    const-string/jumbo v2, "u//redu//te/smx,a/tth/:_"

    const-string v2, "//:th/urx///dtae,s/mt_ue"

    const-string v2, "\",\"thread_sumtext\":\""

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const/4 v13, 0x3

    const/4 v14, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getThreadSumText()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x3

    const/4 v13, 0x4

    const/4 v14, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x0

    const-string/jumbo v2, "r/i/tm/pt//[aee:/:u//r/h/t:scae/bope{_t,{apc//rcl/,1/:/a///"

    const-string v2, "e/c/e{ept/ts[ht/{///b/1/t/e_/m:p/aaourc:al:,,/ri://///clra/"

    const/4 v14, 0x6

    const-string/jumbo v2, "m/:eua//qc_/ert/b//r/////://,latci/aa:///:,etso1{et{/lr/p[c"

    const-string v2, "\",\"clearable\":1,\"accept_time\":[{\"start\":{\"hour\":\""

    const/4 v13, 0x4

    and-int/2addr v14, v13

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x7

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getHour()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x1

    const-string/jumbo v2, "nis//,///m//:"

    const-string v2, "///://n,q//mi"

    const/4 v14, 0x5

    const-string v2, "//nmi//,/m/:/"

    const-string v2, "\",\"min\":\""

    const/4 v13, 0x3

    move v14, v13

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x7

    const/4 v13, 0x6

    const/4 v14, 0x5

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getMin()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x6

    const/4 v13, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x3

    const-string v2, "/:p,o,/t//n:a{::en/u}i//hoi:{////n/mso5/nc/o//}/,//e/3y/d/ait/tr//2}/]/9/_c"

    const-string/jumbo v2, "y}sao/on}:ac/uc/////{i9no//{t///:p}/em_:rntid//n/]//////h/,2:3/e5,,i//t///:"

    const/4 v14, 0x5

    const-string v2, "/:,3/bh////u/_//:{/,//a/ei}py//d{////t}/i]t:o/tn//a////i/no}nr:e,/om2cn5/:9"

    const-string v2, "\"},\"end\":{\"hour\":\"23\",\"min\":\"59\"}}],\"action\":{\"action_type\":"

    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    const/4 v13, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x5

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getAction_type()I

    move-result v2

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x7

    const-string v2, ",aim/:ct/yi/t//v"

    const/4 v14, 0x0

    const-string v2, "////c/ui/tia,v:t"

    const-string v2, ",\"activity\":\""

    const/4 v14, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v13, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x0

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getActivity()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x4

    const/4 v13, 0x7

    const/4 v14, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x6

    const-string v2, "//s/o{///u/l/worbe,/:r/r/:"

    const/4 v14, 0x3

    const-string v2, "://o/rrpbe:/r//l/us///w/{,"

    const-string v2, "\",\"browser\":{\"url\":\""

    const/4 v14, 0x3

    const/4 v13, 0x6

    const/4 v14, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getUrl()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x4

    const-string v2, "/:i///ebqt/,/tnn}"

    const-string v2, "/tn//b},neti///:/"

    const/4 v14, 0x0

    const-string/jumbo v2, "t/s,e///nn/:/i/}/"

    const-string v2, "\"},\"intent\":\""

    const/4 v14, 0x4

    const/4 v13, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getIntent()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x6

    const-string v2, "/cnm/eeUo/gpd///aalamwu/a/p,ankD/e_/{gar:l/k:c"

    const-string v2, "g,:/p/u/akl_{cloapanwn/ak//m/D/edU/:/r//egecaa"

    const/4 v14, 0x5

    const-string v2, "_kaoo/npk,lD/lpo//rndaaaemU:/gga:/a{c//ew//e//"

    const-string v2, "\",\"package_name\":{\"packageDownloadUrl\":\""

    const/4 v14, 0x4

    const/4 v13, 0x1

    const/4 v14, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getPackageDownloadUrl()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x2

    const/4 v13, 0x4

    const/4 v14, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x7

    const-string v2, "ek/ppb/am/e/caag/,//N"

    const-string/jumbo v2, "k/a/e/Npa//e//amcg,p/"

    const-string v2, "e:aN/mupk/ae/////,c/g"

    const-string v2, "\",\"packageName\":\""

    const/4 v14, 0x4

    const/4 v13, 0x1

    const/4 v14, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v13, 0x1

    xor-int/2addr v14, v13

    invoke-virtual {v2}, Lcom/tencent/android/tpush/XGLocalMessage;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x6

    const-string v2, "/}pq/"

    const-string v2, "/}}q/"

    const/4 v14, 0x5

    const-string v2, "/}}q/"

    const-string v2, "\"}}}"

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    move v14, v13

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v14, 0x0

    const/4 v13, 0x5

    const/4 v14, 0x0

    iput-object v1, v5, Lcom/tencent/android/tpush/service/protocol/j;->e:Ljava/lang/String;

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x6

    iget-wide v2, v1, Lcom/tencent/android/tpush/XGLocalMessage;->targetType:J

    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x0

    iput-wide v2, v5, Lcom/tencent/android/tpush/service/protocol/j;->t:J

    const/4 v14, 0x6

    const/4 v13, 0x2

    iget-wide v2, v1, Lcom/tencent/android/tpush/XGLocalMessage;->source:J

    const/4 v14, 0x2

    const/4 v13, 0x5

    const/4 v14, 0x4

    iput-wide v2, v5, Lcom/tencent/android/tpush/service/protocol/j;->u:J

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x1

    iget-object v2, v1, Lcom/tencent/android/tpush/XGLocalMessage;->templateId:Ljava/lang/String;

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x5

    iput-object v2, v5, Lcom/tencent/android/tpush/service/protocol/j;->w:Ljava/lang/String;

    const/4 v14, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x5

    iget-object v1, v1, Lcom/tencent/android/tpush/XGLocalMessage;->traceId:Ljava/lang/String;

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x1

    iput-object v1, v5, Lcom/tencent/android/tpush/service/protocol/j;->x:Ljava/lang/String;

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x7

    new-instance v1, Lcom/tencent/android/tpush/service/channel/a;

    const/4 v14, 0x1

    const/4 v13, 0x1

    const/4 v14, 0x3

    const/4 v2, 0x2

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x5

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v14, 0x0

    const/4 v3, 0x7

    const/4 v14, 0x6

    const/4 v3, 0x0

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x4

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x5

    aput-object v4, v2, v3

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x4

    const-string v3, ".1s7.100."

    const-string v3, "127.0.0.1"

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x0

    aput-object v3, v2, v8

    const/4 v14, 0x2

    const/4 v13, 0x5

    invoke-direct {v1, v2}, Lcom/tencent/android/tpush/service/channel/a;-><init>([Ljava/lang/Object;)V

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x2

    new-instance v2, Landroid/content/Intent;

    const/4 v14, 0x0

    const/4 v13, 0x0

    const/4 v14, 0x6

    const-string v3, "aMcmEHnmS.gnUSI.dTENn.aoextcNiiinodpv.Rte_rPEsAGot.A_LS"

    const-string/jumbo v3, "ipsTGtenrtnc.dmtn.n.v.iac_ioodLPUIEES.MeoAAN.H_NgaSRSEx"

    const/4 v14, 0x7

    const-string v3, ".c_EoRx.tNodgeST..trivdUSEiMnHcI_p..ANnenLPAmianoSGcEot"

    const-string v3, "com.tencent.android.xg.vip.action.INTERNAL_PUSH_MESSAGE"

    const/4 v14, 0x2

    const/4 v13, 0x4

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v14, 0x1

    const/4 v13, 0x6

    const/4 v14, 0x5

    iget-object v3, v5, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x6

    invoke-virtual {v2, v3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v14, 0x4

    const-string v3, "bmgsm"

    const-string v3, "dmgms"

    const/4 v14, 0x2

    const-string/jumbo v3, "suImg"

    const-string/jumbo v3, "msgId"

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x1

    iget-wide v11, v5, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    const/4 v14, 0x7

    const/4 v13, 0x4

    const/4 v14, 0x3

    invoke-virtual {v2, v3, v11, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v14, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x3

    const-string/jumbo v3, "pctneto"

    const-string/jumbo v3, "ntoeotc"

    const/4 v14, 0x6

    const-string/jumbo v3, "tqoetnn"

    const-string v3, "content"

    const/4 v14, 0x5

    const/4 v13, 0x4

    iget-object v4, v5, Lcom/tencent/android/tpush/service/protocol/j;->e:Ljava/lang/String;

    const/4 v14, 0x2

    const/4 v13, 0x0

    const/4 v14, 0x1

    invoke-static {v4}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v14, 0x4

    const/4 v13, 0x1

    const/4 v14, 0x5

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v14, 0x7

    const-string v3, "edat"

    const-string v3, "date"

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x1

    iget-object v4, v5, Lcom/tencent/android/tpush/service/protocol/j;->j:Ljava/lang/String;

    const/4 v13, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x3

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v14, 0x2

    const/4 v13, 0x1

    const/4 v14, 0x6

    const-string/jumbo v3, "ytpe"

    const-string v3, "epyt"

    const/4 v14, 0x3

    const-string/jumbo v3, "peyt"

    const-string/jumbo v3, "type"

    const/4 v14, 0x6

    const/4 v13, 0x1

    const/4 v14, 0x7

    iget-wide v11, v5, Lcom/tencent/android/tpush/service/protocol/j;->f:J

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x3

    invoke-virtual {v2, v3, v11, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v13, 0x6

    move v14, v13

    const-string v3, "cbsda"

    const-string v3, "bacdc"

    const/4 v14, 0x5

    const-string v3, "cIcmd"

    const-string v3, "accId"

    const/4 v14, 0x5

    const/4 v13, 0x3

    const/4 v14, 0x1

    iget-wide v11, v5, Lcom/tencent/android/tpush/service/protocol/j;->b:J

    const/4 v14, 0x7

    const/4 v13, 0x2

    const/4 v14, 0x4

    invoke-virtual {v2, v3, v11, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v13, 0x0

    move v14, v13

    const-string/jumbo v3, "sMgdousib"

    const-string v3, "bMgdiuuss"

    const/4 v14, 0x7

    const-string v3, "MsgbsbdiI"

    const-string v3, "busiMsgId"

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x4

    iget-wide v11, v5, Lcom/tencent/android/tpush/service/protocol/j;->c:J

    const/4 v14, 0x4

    const/4 v13, 0x0

    const/4 v14, 0x0

    invoke-virtual {v2, v3, v11, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x7

    const-string/jumbo v3, "tpespauist"

    const-string v3, "epstsiapmt"

    const/4 v14, 0x6

    const-string/jumbo v3, "timestamps"

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x5

    iget-wide v11, v5, Lcom/tencent/android/tpush/service/protocol/j;->h:J

    const/4 v14, 0x0

    const/4 v13, 0x7

    const/4 v14, 0x4

    invoke-virtual {v2, v3, v11, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v14, 0x6

    const/4 v13, 0x0

    const/4 v14, 0x6

    const-string/jumbo v3, "lkugmtPp"

    const-string/jumbo v3, "multiPkg"

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x1

    iget-wide v11, v5, Lcom/tencent/android/tpush/service/protocol/j;->i:J

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x4

    invoke-virtual {v2, v3, v11, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v14, 0x6

    const-string v3, "e_mrsretqvi"

    const-string/jumbo v3, "server_time"

    const/4 v14, 0x4

    const/4 v13, 0x6

    const/4 v14, 0x4

    iget-wide v11, v5, Lcom/tencent/android/tpush/service/protocol/j;->k:J

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x5

    mul-long/2addr v11, v6

    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x5

    invoke-virtual {v2, v3, v11, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v14, 0x6

    const/4 v13, 0x4

    const/4 v14, 0x6

    const-string/jumbo v3, "ltt"

    const-string/jumbo v3, "ltt"

    const/4 v14, 0x0

    const-string/jumbo v3, "ttl"

    const-string/jumbo v3, "ttl"

    const/4 v14, 0x6

    const/4 v13, 0x6

    const/4 v14, 0x5

    iget v4, v5, Lcom/tencent/android/tpush/service/protocol/j;->l:I

    const/4 v14, 0x0

    const/4 v13, 0x4

    const/4 v14, 0x4

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v13, 0x5

    shl-int/2addr v14, v13

    const-string v3, "_esipxmeqri"

    const-string/jumbo v3, "iie_tmrpqex"

    const/4 v14, 0x2

    const-string/jumbo v3, "p_xmreeeimi"

    const-string v3, "expire_time"

    const/4 v14, 0x3

    const/4 v13, 0x7

    const/4 v14, 0x1

    invoke-virtual {v2, v3, v9, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v14, 0x5

    const/4 v13, 0x4

    const/4 v14, 0x0

    const-string v3, "Caunosnsehp"

    const-string v3, "hnsuneClasp"

    const/4 v14, 0x3

    const-string/jumbo v3, "snuhebChaln"

    const-string/jumbo v3, "pushChannel"

    const/4 v14, 0x4

    const/4 v13, 0x1

    const/4 v14, 0x1

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x1

    const/4 v13, 0x3

    const/4 v14, 0x4

    iget v4, v4, Lcom/tencent/android/tpush/XGLocalMessage;->pushChannel:I

    const/4 v14, 0x1

    const/4 v13, 0x0

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v14, 0x5

    const-string/jumbo v3, "mshumiup"

    const-string/jumbo v3, "pimmeuhs"

    const/4 v14, 0x0

    const-string/jumbo v3, "psuTeimp"

    const-string/jumbo v3, "pushTime"

    const/4 v13, 0x3

    const/4 v14, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v13, 0x3

    xor-int/2addr v14, v13

    iget-wide v6, v4, Lcom/tencent/android/tpush/XGLocalMessage;->pushTime:J

    const/4 v14, 0x1

    const/4 v13, 0x0

    const/4 v14, 0x3

    invoke-virtual {v2, v3, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x7

    const-string/jumbo v3, "oqrgpIo"

    const-string v3, "doIgopr"

    const/4 v14, 0x4

    const-string v3, "gosrpId"

    const-string v3, "groupId"

    const/4 v14, 0x5

    const/4 v13, 0x5

    const/4 v14, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$16;->c:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x5

    iget-object v4, v4, Lcom/tencent/android/tpush/XGLocalMessage;->nGroupId:Ljava/lang/String;

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x1

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v14, 0x7

    const/4 v13, 0x1

    const-string v3, "cAbmsk"

    const-string v3, "crsAkb"

    const-string/jumbo v3, "skvAoc"

    const-string/jumbo v3, "svrAck"

    const/4 v14, 0x7

    const/4 v13, 0x4

    invoke-virtual {v2, v3, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x2

    const-string/jumbo v3, "xto_hbresu"

    const-string/jumbo v3, "rtxesauho_"

    const/4 v14, 0x3

    const-string v3, "_hxteouatr"

    const-string v3, "extra_host"

    const/4 v14, 0x1

    const/4 v13, 0x5

    const/4 v14, 0x2

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/channel/a;->b()Ljava/lang/String;

    move-result-object v4

    const/4 v14, 0x4

    const/4 v13, 0x4

    const/4 v14, 0x2

    invoke-static {v4}, Lcom/tencent/android/tpush/common/j;->d(Ljava/lang/String;)J

    move-result-wide v6

    const/4 v14, 0x4

    const/4 v13, 0x5

    const/4 v14, 0x1

    invoke-virtual {v2, v3, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v14, 0x4

    const-string/jumbo v3, "xrer_appto"

    const-string v3, "extra_port"

    const/4 v14, 0x5

    const/4 v13, 0x1

    const/4 v14, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/channel/a;->c()I

    move-result v4

    const/4 v14, 0x3

    const/4 v13, 0x2

    const/4 v14, 0x1

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v14, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x7

    const-string/jumbo v3, "pxp_tecaqt"

    const-string v3, "catxae_ptp"

    const/4 v14, 0x6

    const-string/jumbo v3, "tas_ecxarp"

    const-string v3, "extra_pact"

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x2

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/channel/a;->a()Z

    move-result v1

    const/4 v14, 0x1

    const/4 v13, 0x2

    const/4 v14, 0x5

    invoke-static {v1}, Lcom/tencent/android/tpush/service/c;->a(Z)B

    move-result v1

    const/4 v14, 0x3

    const/4 v13, 0x5

    invoke-virtual {v2, v3, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;B)Landroid/content/Intent;

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x1

    const-string v1, "ia_mpeht_qteuxs"

    const-string v1, "ai_putetq_rhesx"

    const/4 v14, 0x1

    const-string v1, "_uxhopeitmer_st"

    const-string v1, "extra_push_time"

    const/4 v13, 0x3

    const/4 v13, 0x3

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPushManager$16;->d:J

    const/4 v14, 0x5

    const/4 v13, 0x0

    const/4 v14, 0x6

    invoke-virtual {v2, v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v14, 0x7

    const/4 v13, 0x5

    const/4 v14, 0x0

    const-string v1, "eTyrpbeasg"

    const-string v1, "eestgrpTya"

    const/4 v14, 0x3

    const-string/jumbo v1, "ptgrTeutey"

    const-string/jumbo v1, "targetType"

    const/4 v14, 0x3

    const/4 v13, 0x7

    iget-wide v3, v5, Lcom/tencent/android/tpush/service/protocol/j;->t:J

    const/4 v14, 0x0

    const/4 v13, 0x3

    const/4 v14, 0x0

    invoke-virtual {v2, v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v14, 0x5

    const/4 v13, 0x6

    const/4 v14, 0x1

    const-string/jumbo v1, "uprome"

    const-string/jumbo v1, "uesmro"

    const/4 v14, 0x6

    const-string v1, "cuqors"

    const-string/jumbo v1, "source"

    const/4 v14, 0x0

    const/4 v13, 0x1

    const/4 v14, 0x4

    iget-wide v3, v5, Lcom/tencent/android/tpush/service/protocol/j;->u:J

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x6

    invoke-virtual {v2, v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v14, 0x3

    const/4 v13, 0x5

    const/4 v14, 0x5

    const-string/jumbo v1, "pestltameo"

    const-string v1, "eetIolmpat"

    const/4 v14, 0x6

    const-string/jumbo v1, "tdmmltIape"

    const-string/jumbo v1, "templateId"

    const/4 v14, 0x4

    const/4 v13, 0x2

    const/4 v14, 0x4

    iget-object v3, v5, Lcom/tencent/android/tpush/service/protocol/j;->w:Ljava/lang/String;

    const/4 v14, 0x2

    const/4 v13, 0x3

    const/4 v14, 0x3

    invoke-virtual {v2, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v14, 0x3

    const/4 v13, 0x0

    const/4 v14, 0x0

    const-string v1, "bcadorI"

    const-string/jumbo v1, "rIdecba"

    const/4 v14, 0x1

    const-string v1, "aetdrbI"

    const-string/jumbo v1, "traceId"

    const/4 v14, 0x7

    const/4 v13, 0x1

    const/4 v14, 0x2

    iget-object v3, v5, Lcom/tencent/android/tpush/service/protocol/j;->x:Ljava/lang/String;

    const/4 v14, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x3

    invoke-virtual {v2, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v14, 0x6

    const/4 v13, 0x3

    const/4 v14, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$16;->b:Landroid/content/Context;

    const/4 v14, 0x6

    const/4 v13, 0x2

    const/4 v14, 0x7

    invoke-static {v1}, Lcom/tencent/android/tpush/message/e;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/message/e;

    move-result-object v1

    const/4 v14, 0x6

    const/4 v13, 0x7

    const/4 v14, 0x6

    invoke-virtual {v1, v2}, Lcom/tencent/android/tpush/message/e;->b(Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v14, 0x3

    const/4 v13, 0x1

    const/4 v14, 0x3

    goto :goto_5

    :catchall_0
    move-exception v1

    const/4 v14, 0x0

    const/4 v13, 0x2

    const/4 v14, 0x4

    const-string/jumbo v2, "loLntfucoia aitNicado"

    const/4 v14, 0x6

    const-string v2, "LicadNutitndafocloo a"

    const-string v2, "addLocalNotification "

    const/4 v14, 0x2

    const/4 v13, 0x7

    const/4 v14, 0x4

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_5
    const/4 v14, 0x6

    const/4 v13, 0x4

    const/4 v14, 0x7

    return-void
.end method
