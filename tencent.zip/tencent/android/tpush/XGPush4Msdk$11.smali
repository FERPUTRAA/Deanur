.class Lcom/tencent/android/tpush/XGPush4Msdk$11;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPush4Msdk;->addTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Ljava/util/Set;


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;Ljava/util/Set;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$11;->a:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$11;->b:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$11;->c:Ljava/util/Set;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x2

    sget-boolean v0, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x0

    const-string/jumbo v1, "sdss4sGMXhu"

    const-string/jumbo v1, "sXs4sdMGuhP"

    const/4 v11, 0x1

    const-string v1, "GkumP4hsdsX"

    const-string v1, "XGPush4Msdk"

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    if-eqz v0, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-string/jumbo v2, "omtaoad=srmeTpag:deeN"

    const-string v2, "Nt:m=geaoapdesaTrdem "

    const/4 v11, 0x5

    const-string v2, "a:rtmbdag ade=aeeNpsT"

    const-string v2, "addTags: operateName="

    const/4 v11, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$11;->a:Ljava/lang/String;

    const/4 v11, 0x1

    const/4 v10, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x1

    const-string v2, "dpoAq=upq"

    const-string/jumbo v2, "pA,qo=qdp"

    const/4 v11, 0x1

    const-string/jumbo v2, "q=pAip,pq"

    const-string v2, ",qqAppid="

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/XGPush4Msdk;->c()J

    move-result-wide v2

    const/4 v11, 0x2

    const/4 v10, 0x7

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const-string v2, "ga=d,_ecqibsc"

    const-string v2, "_s=dibccsea,g"

    const/4 v11, 0x7

    const-string v2, "cgsi_e=xass,c"

    const-string v2, ",xg_accessid="

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$11;->b:Landroid/content/Context;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$11;->b:Landroid/content/Context;

    const/4 v10, 0x1

    xor-int/2addr v11, v10

    if-eqz v0, :cond_4

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$11;->c:Ljava/util/Set;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    if-eqz v0, :cond_4

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-eqz v0, :cond_1

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    goto/16 :goto_0

    :cond_1
    const/4 v11, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$11;->c:Ljava/util/Set;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string v2, "agumTad"

    const-string v2, "aagdTdu"

    const/4 v11, 0x0

    const-string v2, "aasdodT"

    const-string v2, "addTags"

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/Set;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    if-nez v4, :cond_2

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-string/jumbo v0, "tpt>Sba T gn! ddrsnuerl ar!Tt-sa!euomgeg"

    const-string v0, "erg>tndp!gsrser ou datSTal ! nmteTlg-au!"

    const-string/jumbo v0, "uus ltust g-god nnTS>d!aaetTFrermrga! el"

    const-string v0, "addTags -> getTagsFromSet return null!!!"

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    return-void

    :cond_2
    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x3

    sget-boolean v0, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    if-eqz v0, :cond_3

    const/4 v10, 0x3

    xor-int/2addr v11, v10

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x6

    const-string v2, "T a swapdia gglTtd ssth glat ase-=>"

    const-string v2, "addTags -> setTags with all tags = "

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$11;->b:Landroid/content/Context;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x2

    const/4 v5, 0x5

    const/4 v11, 0x1

    const/4 v10, 0x4

    invoke-static {v3}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v6

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$11;->b:Landroid/content/Context;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAppKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    iget-object v9, p0, Lcom/tencent/android/tpush/XGPush4Msdk$11;->a:Ljava/lang/String;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-static/range {v3 .. v9}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x2

    return-void

    :cond_4
    :goto_0
    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x5

    const-string v0, "  eai apqgao tsnddt sTgisrrre  fxtaoi aeaovlectq.mht"

    const-string v0, "e  txagnq ctrriproeviostdot aefei.alhd  ssTaa ga dmt"

    const/4 v11, 0x4

    const-string v0, "Tdstdnra i fesvaa rhxs .graaaol iceometeop ditn s tg"

    const-string/jumbo v0, "the parameter context or tags of addTags is invalid."

    const/4 v10, 0x1

    move v11, v10

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    return-void
.end method
