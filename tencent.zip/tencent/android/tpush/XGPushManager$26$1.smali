.class Lcom/tencent/android/tpush/XGPushManager$26$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager$26;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/XGPushManager$26;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGPushManager$26;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$26$1;->b:Lcom/tencent/android/tpush/XGPushManager$26;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$26$1;->a:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, ".ssM~~ ~d~@rfob@i@f~io~@~ ~ @ o@@ -@@@/c@~ ~@~~@t yo K@~@~ 4l@i@l~ @ t@~~~u1a S o~v~ b~ b@ ~o/n "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$26$1;->a:Landroid/content/Context;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/XGApiConfig;->clearRegistered(Landroid/content/Context;)V

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$26$1;->a:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/XGPushManager;->enableService(Landroid/content/Context;Z)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$26$1;->a:Landroid/content/Context;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$26$1;->a:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpush/d/d;->a()Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$26$1;->a:Landroid/content/Context;

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpush/d/d;->e()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    shl-int/2addr v4, v3

    const-string/jumbo v2, "on mte erueiurPogrt hresrhs"

    const-string/jumbo v2, "o ssrheo ertrh rrngeerutiPu"

    const/4 v4, 0x4

    const-string v2, "eugron tr Posrirrer usehhte"

    const-string/jumbo v2, "unregister otherPush error "

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v1, "aegXPbrGhaMnm"

    const-string v1, "PramnGaXegsMh"

    const/4 v4, 0x7

    const-string v1, "geahMGuXarsnP"

    const-string v1, "XGPushManager"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void
.end method
