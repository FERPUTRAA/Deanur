.class Lcom/tencent/android/tpush/XGPushManager$8$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager$8;->TRun()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/XGPushManager$8;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGPushManager$8;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$8$1;->a:Lcom/tencent/android/tpush/XGPushManager$8;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "-osno @~ ~sbc i@~@@ f@~~~Sm @. @i@~~@o f~ @K/ubo  4b~@yv@~M~l@t~ @/~ @~~a~ @~li~~r~t@o @ do@ 1~ "

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$8$1;->a:Lcom/tencent/android/tpush/XGPushManager$8;

    const/4 v10, 0x0

    iget-object v1, v0, Lcom/tencent/android/tpush/XGPushManager$8;->a:Landroid/content/Context;

    const/4 v9, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x7

    iget-object v2, v0, Lcom/tencent/android/tpush/XGPushManager$8;->b:Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget v3, v0, Lcom/tencent/android/tpush/XGPushManager$8;->c:I

    const/4 v10, 0x3

    iget-wide v4, v0, Lcom/tencent/android/tpush/XGPushManager$8;->d:J

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-object v6, v0, Lcom/tencent/android/tpush/XGPushManager$8;->e:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    iget-object v7, v0, Lcom/tencent/android/tpush/XGPushManager$8;->f:Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object v8, v0, Lcom/tencent/android/tpush/XGPushManager$8;->g:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v9, 0x7

    move v10, v9

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    return-void
.end method
