.class Lcom/tencent/android/tpush/XGPushManager$b;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/XGPushManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "b"
.end annotation


# instance fields
.field a:Landroid/content/Context;

.field b:Landroid/content/Intent;

.field c:Lcom/tencent/android/tpush/XGIOperateCallback;

.field d:I


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$b;->a:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$b;->b:Landroid/content/Intent;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPushManager$b;->c:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput p4, p0, Lcom/tencent/android/tpush/XGPushManager$b;->d:I

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~@s ~biM~@ 4 ~@@b~/@~iy@~@@ oSo~@fr  ~@ .@ -@do@l@~@~/@ a~~o@@co ~@~b~ fi ~1~uvmo~@ t ~ Klsn~ t~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    const-string p1, "XaemuansPMgGh"

    const-string p1, "XGPushManager"

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->d()Ljava/util/Map;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-interface {v0}, Ljava/util/Map;->size()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v2, "stsaoiomrtc pS:f ar epvr"

    const-string/jumbo v2, "rast t oipvpScar :esf rm"

    const-string/jumbo v2, "pvr:fbpcS tsi eore tarm "

    const-string v2, "Service start from app :"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const-string/jumbo v2, "kpg"

    const-string/jumbo v2, "pgk"

    const-string/jumbo v2, "pgk"

    const-string/jumbo v2, "pkg"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v2, ",ksm r sdni:e v"

    const/4 v4, 0x6

    const-string v2, " , sdk version:"

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo v2, "rve"

    const-string/jumbo v2, "rve"

    const/4 v4, 0x0

    const-string/jumbo v2, "rev"

    const-string/jumbo v2, "ver"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo p2, "zS:moeua"

    const-string/jumbo p2, "z:eiomaS"

    const/4 v4, 0x3

    const-string/jumbo p2, "miS:zaep"

    const-string/jumbo p2, "mapSize:"

    const/4 v3, 0x2

    move v4, v3

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v3, 0x7

    move v4, v3

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->d()Ljava/util/Map;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {p2, p0}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    check-cast p2, Lcom/tencent/android/tpush/XGPushManager$c;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getHandler()Landroid/os/Handler;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, p2}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :try_start_2
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v0, "bpcartfeqSeeeiiceeo evexyre ma crvrRpr:T S"

    const-string v0, "erSeibvycrpviacoceexa: e repeRr tTeo refSm"

    const/4 v4, 0x3

    const-string v0, "e serem cxvcevryopieSarereR:ftoaSTerp  tei"

    const-string v0, " exec from ServiceStartReceiver operaType:"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/XGPushManager$b;->d:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$b;->a:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$b;->b:Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$b;->c:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v4, 0x6

    const/4 v3, 0x7

    iget v2, p0, Lcom/tencent/android/tpush/XGPushManager$b;->d:I

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p2, v0, v1, v2}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$b;->a:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p2, p0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;)Z
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v3, 0x7

    move v4, v3

    goto :goto_0

    :catchall_1
    move-exception p2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string v0, "SremorertgvietuearitrRrRe s"

    const-string v0, "eeSsrtuReirRtirtoe eegrvrar"

    const/4 v4, 0x3

    const-string v0, "RegisterStartReceiver error"

    const/4 v3, 0x3

    or-int/2addr v4, v3

    invoke-static {p1, v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void
.end method
