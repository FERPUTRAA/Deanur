.class Lcom/tencent/android/tpush/XGPushManager$2;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/XGIOperateCallback;

.field final synthetic c:J

.field final synthetic d:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$2;->a:Landroid/content/Context;

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$2;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x0

    iput-wide p3, p0, Lcom/tencent/android/tpush/XGPushManager$2;->c:J

    const/4 v1, 0x6

    iput-object p5, p0, Lcom/tencent/android/tpush/XGPushManager$2;->d:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 10

    :try_start_0
    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "a~sv~@~m- @ld~~ @@@ @~o~~ r/f~ @ i~ S@ .b@~@~~u@o~@~@@n@b~yol ~  ~ot ~ 1@o~M@fib@t @c  ~Ks 4o~/@"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$2;->a:Landroid/content/Context;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v9, 0x1

    const-string v1, ""

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-eqz v0, :cond_1

    :try_start_1
    const/4 v9, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$2;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-eqz v2, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    const-string v3, "fEDmGrKrroo nSi gcXNIe"

    const-string v3, "XINGE SDK config error"

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-interface {v2, v1, v0, v3}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_0
    const/4 v8, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    return-void

    :cond_1
    const/4 v8, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-wide v2, p0, Lcom/tencent/android/tpush/XGPushManager$2;->c:J

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    cmp-long v0, v2, v4

    const/4 v9, 0x2

    if-gtz v0, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$2;->a:Landroid/content/Context;

    const/4 v8, 0x7

    and-int/2addr v9, v8

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v2

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$2;->d:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-eqz v0, :cond_3

    const/4 v8, 0x3

    shr-int/2addr v9, v8

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$2;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto :goto_0

    :cond_3
    const/4 v8, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$2;->d:Ljava/lang/String;

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$2;->a:Landroid/content/Context;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v6}, Lcom/tencent/android/tpush/XGPushConfig;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    cmp-long v4, v2, v4

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-lez v4, :cond_4

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-nez v4, :cond_4

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {v6}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-eqz v4, :cond_5

    :cond_4
    const/4 v9, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$2;->b:Lcom/tencent/android/tpush/XGIOperateCallback;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-nez v4, :cond_6

    :cond_5
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    new-instance v4, Landroid/content/Intent;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x6

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x7

    iget-object v7, p0, Lcom/tencent/android/tpush/XGPushManager$2;->a:Landroid/content/Context;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v7}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x3

    const-string/jumbo v7, "n.Ioon.4GtmdRevncaVEarsiEi.doi.NUgcxenptcRt..oS"

    const-string/jumbo v7, "vnscR..mx.Spe.rIoGRo4dgEotiaiVU.dn..nEatencNict"

    const/4 v9, 0x0

    const-string v7, "GgvtRbceo.mioNpo.iiSad.RIaTVE...nd4EertnntcxUcn"

    const-string v7, "com.tencent.android.xg.vip.action.UNREGISTER.V4"

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v5, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-direct {v4, v5}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x4

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v5, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-static {v1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const-string v2, "audmc"

    const-string v2, "Iacmd"

    const/4 v9, 0x3

    const-string v2, "ccpaI"

    const-string v2, "accId"

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v4, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    const-string v1, "Koqecy"

    const-string v1, "aeyKoc"

    const/4 v9, 0x2

    const-string/jumbo v1, "ycsaKe"

    const-string v1, "accKey"

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x1

    invoke-virtual {v4, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string v0, "etkmn"

    const-string/jumbo v0, "token"

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {v6}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {v4, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$2;->a:Landroid/content/Context;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string/jumbo v1, "kapbocem"

    const-string/jumbo v1, "pckmabae"

    const/4 v9, 0x1

    const-string v1, "Ncaepbka"

    const-string/jumbo v1, "packName"

    const/4 v9, 0x4

    const/4 v8, 0x7

    invoke-virtual {v4, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-string/jumbo v0, "npoieouru"

    const-string/jumbo v0, "onrpotuei"

    const/4 v9, 0x2

    const-string/jumbo v0, "nreapitpo"

    const-string/jumbo v0, "operation"

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    const/16 v1, 0x65

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v4, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    const-string/jumbo v0, "pyqeop"

    const-string/jumbo v0, "ypopep"

    const/4 v9, 0x3

    const-string/jumbo v0, "oesTyp"

    const-string/jumbo v0, "opType"

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    const/4 v1, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {v4, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$2;->a:Landroid/content/Context;

    const/4 v8, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$2;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {v0, v4, v2, v1}, Lcom/tencent/android/tpush/XGPushManager;->safeSendQuest(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    return-void

    :cond_6
    :try_start_2
    const/4 v8, 0x2

    move v9, v8

    sget-object v0, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_LOGIC_ILLEGAL_ARGUMENT:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    const-string/jumbo v6, "s im snscv ,crTea aaccKIdys=idsk!ieec sdntslaeIohe e o"

    const-string v6, "ahao acsqic !yce ev=aeeddekcTsn tKsdrosil,scnIs iIs e "

    const/4 v9, 0x2

    const-string v6, "The accessId, accessKey or token is invalid! accessId="

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v5, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-interface {v4, v1, v0, v2}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    new-instance v0, Ljava/lang/IllegalArgumentException;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string/jumbo v1, "sisoo. v KIydseci,sdnkce enaroa  ctlseas"

    const-string/jumbo v1, "s skIeccs v  lre,aKidei.oyaitsscsdno nae"

    const/4 v9, 0x3

    const-string/jumbo v1, "sc enbi.iddsoecraass,l  sa KcicevnkIty e"

    const-string v1, "accessId, accessKey or token is invalid."

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    throw v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :catchall_0
    move-exception v0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string v1, "GuMsehuragPXn"

    const-string v1, "GrsmgehPanuMX"

    const/4 v9, 0x6

    const-string/jumbo v1, "sMGnarapueXPh"

    const-string v1, "XGPushManager"

    const/4 v8, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string/jumbo v2, "isoreutuqsnPer"

    const-string/jumbo v2, "rseeoushrntiuP"

    const/4 v9, 0x5

    const-string v2, "egsniruhssertP"

    const-string/jumbo v2, "unregisterPush"

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v9, 0x0

    const/4 v8, 0x2

    return-void
.end method
