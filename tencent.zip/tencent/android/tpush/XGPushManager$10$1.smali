.class Lcom/tencent/android/tpush/XGPushManager$10$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager$10;->TRun()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/XGPushManager$10;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGPushManager$10;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$10$1;->a:Lcom/tencent/android/tpush/XGPushManager$10;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, "a s@ d@-l @~uofl@~~ ~@m@~    ~ios@y~ ~@@c~~ @~/ @bo~@~ ~@notS@b i f @obo.@@r K@@t~1~~~/@~4M~i ~~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$10$1;->a:Lcom/tencent/android/tpush/XGPushManager$10;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object v1, v0, Lcom/tencent/android/tpush/XGPushManager$10;->a:Landroid/content/Context;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x6

    iget-object v2, v0, Lcom/tencent/android/tpush/XGPushManager$10;->b:Ljava/lang/String;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-wide v3, v0, Lcom/tencent/android/tpush/XGPushManager$10;->c:J

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-object v5, v0, Lcom/tencent/android/tpush/XGPushManager$10;->d:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget v6, v0, Lcom/tencent/android/tpush/XGPushManager$10;->e:I

    const/4 v10, 0x6

    iget-object v7, v0, Lcom/tencent/android/tpush/XGPushManager$10;->f:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v8, v0, Lcom/tencent/android/tpush/XGPushManager$10;->g:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x2

    return-void
.end method
