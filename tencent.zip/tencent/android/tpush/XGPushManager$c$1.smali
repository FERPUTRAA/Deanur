.class Lcom/tencent/android/tpush/XGPushManager$c$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager$c;->TRun()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/XGPushManager$c;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGPushManager$c;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$c$1;->a:Lcom/tencent/android/tpush/XGPushManager$c;

    const/4 v1, 0x0

    const/4 v0, 0x0

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " ~s@nM@@~ ~@bl@~l o - ~o@o f@c~ ~~t/o1@~@@ fvr@~m@@u~i~@ ~  tK~d ~i@~o@ @ @.S  oyi/~@b@~ abs~~~4"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$c$1;->a:Lcom/tencent/android/tpush/XGPushManager$c;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v1, v0, Lcom/tencent/android/tpush/XGPushManager$c;->a:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v2, v0, Lcom/tencent/android/tpush/XGPushManager$c;->b:Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    iget-object v3, v0, Lcom/tencent/android/tpush/XGPushManager$c;->c:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget v0, v0, Lcom/tencent/android/tpush/XGPushManager$c;->d:I

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v1, v2, v3, v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-void
.end method
