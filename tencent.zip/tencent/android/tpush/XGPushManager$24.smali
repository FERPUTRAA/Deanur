.class Lcom/tencent/android/tpush/XGPushManager$24;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->d(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/XGIOperateCallback;

.field final synthetic c:J

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:J

.field final synthetic f:I

.field final synthetic g:Ljava/lang/String;

.field final synthetic h:Ljava/lang/String;

.field final synthetic i:Ljava/lang/String;

.field final synthetic j:Ljava/lang/String;

.field final synthetic k:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;JILjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-wide p3, p0, Lcom/tencent/android/tpush/XGPushManager$24;->c:J

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p5, p0, Lcom/tencent/android/tpush/XGPushManager$24;->d:Ljava/lang/String;

    const/4 v1, 0x6

    iput-wide p6, p0, Lcom/tencent/android/tpush/XGPushManager$24;->e:J

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p8, p0, Lcom/tencent/android/tpush/XGPushManager$24;->f:I

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p9, p0, Lcom/tencent/android/tpush/XGPushManager$24;->g:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x7

    iput-object p10, p0, Lcom/tencent/android/tpush/XGPushManager$24;->h:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p11, p0, Lcom/tencent/android/tpush/XGPushManager$24;->i:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p12, p0, Lcom/tencent/android/tpush/XGPushManager$24;->j:Ljava/lang/String;

    const/4 v1, 0x5

    iput-object p13, p0, Lcom/tencent/android/tpush/XGPushManager$24;->k:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 15

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v1, "hrsunaMgsGXaP"

    const-string v1, "XGPushManager"

    :try_start_0
    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v2

    if-eqz v2, :cond_1

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$24;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    if-eqz v3, :cond_0

    invoke-static {v2}, Lcom/tencent/android/tpush/common/ReturnCode;->errCodeToMsg(I)Ljava/lang/String;

    move-result-object v4

    invoke-interface {v3, v0, v2, v4}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_0
    return-void

    :cond_1
    iget-wide v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->c:J

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    cmp-long v6, v2, v4

    if-lez v6, :cond_2

    goto :goto_0

    :cond_2
    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v2

    :goto_0
    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$24;->d:Ljava/lang/String;

    invoke-static {v6}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v6

    if-eqz v6, :cond_3

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v6}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    goto :goto_1

    :cond_3
    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$24;->d:Ljava/lang/String;

    :goto_1
    cmp-long v7, v2, v4

    if-lez v7, :cond_10

    invoke-static {v6}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v7
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    if-eqz v7, :cond_4

    goto/16 :goto_5

    :cond_4
    :try_start_1
    const-string v7, " tsesthe otsmn arphitrrgae hcel r!n"

    const-string v7, "e! mapnhr resttnsorhst alhre tige c"

    const-string/jumbo v7, "titmepl uanheoseehr ahrs !  ncgtrrt"

    const-string/jumbo v7, "start other push channel register !"

    invoke-static {v1, v7}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v7, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    iget-wide v8, p0, Lcom/tencent/android/tpush/XGPushManager$24;->e:J

    const/4 v10, 0x1

    invoke-static {v7, v10, v8, v9}, Lcom/tencent/android/tpush/XGPushManager;->loadOtherPushToken(Landroid/content/Context;ZJ)Ljava/lang/String;

    new-instance v7, Landroid/content/Intent;

    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    iget-object v9, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-virtual {v9}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, "doRSocoi..tErgntta.TdcncvxnR.oaemVeEi.ni.4IpG"

    const-string v9, "cneEoGcc.aVvtnn4dIaernSiRigEtdRm.poot..T.oi.."

    const-string v9, "com.tencent.android.xg.vip.action.REGISTER.V4"

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-direct {v7, v8}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v8, "bcdbI"

    const-string v8, "bdIac"

    const-string v8, "Iudcc"

    const-string v8, "accId"

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v9, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v7, v8, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v2, "hlucCncpna"

    const-string v2, "cennahuCcl"

    const-string v2, "ccaCalnnqh"

    const-string v2, "accChannel"

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v3}, Lcom/tencent/android/tpush/XGPushConfig;->getChannelId(Landroid/content/Context;)J

    move-result-wide v8

    invoke-virtual {v7, v2, v8, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string v2, "cyseap"

    const-string/jumbo v2, "ypeacK"

    const-string v2, "acKmcy"

    const-string v2, "accKey"

    invoke-static {v6}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v7, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->f:I

    shr-int/lit8 v2, v2, 0x4

    const/4 v3, 0x0

    if-eq v2, v10, :cond_7

    const-string/jumbo v2, "qpeaor"

    const-string/jumbo v2, "raqepV"

    const-string/jumbo v2, "rppaeb"

    const-string v2, "appVer"

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v6}, Lcom/tencent/android/tpush/common/AppInfos;->getCurAppVersion(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v2, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v2, "asaNkmup"

    const-string/jumbo v2, "kcsapamN"

    const-string v2, "akamecNp"

    const-string/jumbo v2, "packName"

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-virtual {v6}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-static {v6}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v2, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->g:Ljava/lang/String;

    if-eqz v2, :cond_5

    new-instance v3, Lcom/tencent/android/tpush/XGPushManager$AccountInfo;

    iget v6, p0, Lcom/tencent/android/tpush/XGPushManager$24;->f:I

    invoke-direct {v3, v6, v2}, Lcom/tencent/android/tpush/XGPushManager$AccountInfo;-><init>(ILjava/lang/String;)V

    const-string v2, "ctqkmi"

    const-string/jumbo v2, "tiemck"

    const-string v2, "ctskti"

    const-string/jumbo v2, "ticket"

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$24;->g:Ljava/lang/String;

    invoke-static {v6}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v7, v2, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_5
    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->h:Ljava/lang/String;

    if-eqz v2, :cond_6

    const-string v6, "aqu"

    const-string v6, "aqu"

    const-string/jumbo v6, "uqa"

    const-string/jumbo v6, "qua"

    invoke-static {v2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v7, v6, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_6
    const-string v2, "ernmiootp"

    const-string/jumbo v2, "pareoniot"

    const-string/jumbo v2, "operation"

    const/16 v6, 0x64

    invoke-virtual {v7, v2, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v2, "ilad"

    const-string v2, "dial"

    const-string v2, "aidl"

    const-string v2, "aidl"

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v6}, Lcom/tencent/android/tpush/common/j;->b(Landroid/content/Context;)Z

    move-result v6

    invoke-virtual {v7, v2, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    :cond_7
    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush(Landroid/content/Context;)Z

    move-result v2

    if-eqz v2, :cond_8

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v2}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v2

    invoke-virtual {v2}, Lcom/tencent/android/tpush/d/d;->l()Z

    move-result v2

    if-eqz v2, :cond_8

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v2}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v2

    invoke-virtual {v2}, Lcom/tencent/android/tpush/d/d;->k()Ljava/lang/String;

    move-result-object v2

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v6}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v6

    invoke-virtual {v6}, Lcom/tencent/android/tpush/d/d;->f()Ljava/lang/String;

    move-result-object v6

    iget-object v8, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v8}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v8

    invoke-virtual {v8}, Lcom/tencent/android/tpush/d/d;->g()Ljava/lang/String;

    move-result-object v8

    new-instance v9, Ljava/lang/StringBuilder;

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, " ksooh:rbtoi  hp nseeu"

    const-string/jumbo v10, "spktnboh shu:ro    iee"

    const-string/jumbo v10, "uh r bten: e itphks so"

    const-string/jumbo v10, "other push token is : "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v10, "e tyoeuhrh tu psp u"

    const-string v10, "  e osuept prhu thy"

    const-string/jumbo v10, "o ep tsprep h  :yuh"

    const-string v10, "  other push type: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v10, "ngteup oqhso:hpr ie "

    const-string v10, "epei  sp ontgh o:urh"

    const-string v10, "ers u  ohtghr so:iep"

    const-string v10, " other push region: "

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-static {v1, v9}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_8

    invoke-static {v6}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v9

    if-nez v9, :cond_8

    const-string v9, "cnemekTnhlna"

    const-string/jumbo v9, "nnecnehkqlaT"

    const-string v9, "eeTloankcnnh"

    const-string v9, "channelToken"

    invoke-virtual {v7, v9, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v6, "hepnsbayTce"

    const-string v6, "ecsTpyalehn"

    const-string v6, "cnhpTeueayn"

    const-string v6, "channelType"

    invoke-virtual {v7, v6, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v2, "nieevdopmgiR"

    const-string v2, "dRcmgoivneie"

    const-string/jumbo v2, "oegcveinqieR"

    const-string v2, "deviceRegion"

    invoke-virtual {v7, v2, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_8
    const-string/jumbo v2, "otsiekepTt"

    const-string v2, "etTkoetpiy"

    const-string v2, "Tpemitkeyt"

    const-string/jumbo v2, "ticketType"

    iget v6, p0, Lcom/tencent/android/tpush/XGPushManager$24;->f:I

    invoke-virtual {v7, v2, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string v2, "erMmocuetlrbiTlsi"

    const-string/jumbo v2, "srTuebllinrcimetM"

    const-string/jumbo v2, "ncrMibTiueetlmrsi"

    const-string v2, "currentTimeMillis"

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v8

    invoke-virtual {v7, v2, v8, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string/jumbo v2, "upuyep"

    const-string/jumbo v2, "uyppoe"

    const-string/jumbo v2, "yppTpo"

    const-string/jumbo v2, "opType"

    const/4 v6, 0x0

    invoke-virtual {v7, v2, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->i:Ljava/lang/String;

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_9

    const-string/jumbo v2, "rlu"

    const-string/jumbo v2, "lru"

    const-string/jumbo v2, "rlu"

    const-string/jumbo v2, "url"

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$24;->i:Ljava/lang/String;

    invoke-virtual {v7, v2, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-wide/16 v4, 0x4

    const-wide/16 v4, 0x4

    const-wide/16 v4, 0x4

    const-wide/16 v4, 0x4

    :cond_9
    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->j:Ljava/lang/String;

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_b

    const-string v2, "Teohotnpke"

    const-string/jumbo v2, "otherToken"

    iget-object v8, p0, Lcom/tencent/android/tpush/XGPushManager$24;->j:Ljava/lang/String;

    invoke-virtual {v7, v2, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    iget-object v8, p0, Lcom/tencent/android/tpush/XGPushManager$24;->j:Ljava/lang/String;

    invoke-static {v2, v8, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v2}, Lcom/tencent/android/tpush/service/cache/CacheManager;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_a

    const-wide/16 v8, 0x2

    const-wide/16 v8, 0x2

    const-wide/16 v8, 0x2

    const-wide/16 v8, 0x2

    goto :goto_2

    :cond_a
    const-wide/16 v8, 0x3

    const-wide/16 v8, 0x3

    const-wide/16 v8, 0x3

    goto :goto_2

    :cond_b
    const-wide/16 v8, 0x1

    const-wide/16 v8, 0x1

    const-wide/16 v8, 0x1

    :goto_2
    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$24;->k:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_c

    const-string/jumbo v0, "qqoplda"

    const-string/jumbo v0, "pqlydoa"

    const-string/jumbo v0, "plsyoad"

    const-string/jumbo v0, "payload"

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->k:Ljava/lang/String;

    invoke-virtual {v7, v0, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_c
    const-string/jumbo v0, "upemskPOporhTenthTso"

    const-string/jumbo v0, "rospphOtToTusePehkne"

    const-string/jumbo v0, "pTOyoretThokohspePue"

    const-string/jumbo v0, "otherPushTokenOpType"

    invoke-virtual {v7, v0, v8, v9}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string/jumbo v0, "uPeTebrhtmshy"

    const-string/jumbo v0, "thumroTPseeyh"

    const-string v0, "PeuhoyuhTstpe"

    const-string/jumbo v0, "otherPushType"

    invoke-virtual {v7, v0, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " pr=o "

    const-string v2, " r =ou"

    const-string/jumbo v2, "urq  l"

    const-string/jumbo v2, "url = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->i:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "y sd aloab="

    const-string/jumbo v2, "oy p=bla da"

    const-string v2, " = mao aylp"

    const-string v2, " payload = "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->k:Ljava/lang/String;

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "uTtyo ueosrPeh "

    const-string/jumbo v2, "r heeoutuTyPs h"

    const-string v2, "ery hbe PohsTtp"

    const-string v2, " otherPushType "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "urpOTtuphpe  koseyhoTe"

    const-string/jumbo v2, "ukpTeOoptPph eoerTs hy"

    const-string/jumbo v2, "oy TheepsTruO penkhpoP"

    const-string v2, " otherPushTokenOpType "

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    invoke-static {v0, v7, v2, v3}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;Lcom/tencent/android/tpush/XGPushManager$AccountInfo;)Landroid/content/Intent;

    move-result-object v0

    invoke-static {}, Lcom/tencent/android/tpush/common/i;->a()Lcom/tencent/android/tpush/common/i;

    move-result-object v2

    invoke-virtual {v2}, Lcom/tencent/android/tpush/common/i;->b()Z

    move-result v2

    if-eqz v2, :cond_d

    const-string/jumbo v2, "tiRstqhpqagetied"

    const-string v2, "etRetilgqsaipdht"

    const-string v2, "dtspihgsRtaeetFi"

    const-string v2, "httpRegistedFail"

    invoke-virtual {v0, v2, v6}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v2

    if-eqz v2, :cond_d

    const-string v0, "ei musspgnesurr edpn sttgxsu  u a nerloyilpacrfr Ttrts emecoe enduei toshn nhr,s"

    const-string/jumbo v0, "use custom push proxy register failed, not use Tpns channel send register return"

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_d
    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedTpnsChannel(Landroid/content/Context;)Z

    move-result v2

    if-nez v2, :cond_e

    const-string/jumbo v0, "rieso sches lu sspnrPttoecg nnrsvh eTneea"

    const-string/jumbo v0, "rcsslgepnursoa tes nvshnt eir enTcuePe sh"

    const-string/jumbo v0, "registerPush not use Tpns channel service"

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_e
    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$24;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    invoke-static {v2, v0, v3, v6}, Lcom/tencent/android/tpush/XGPushManager;->safeSendQuest(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_3

    :catchall_0
    move-exception v0

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "feeirbTgr xctdam la:iesee"

    const-string/jumbo v3, "t emakfeTreseiired:lgxa c"

    const-string v3, "ea eecu:xegrdkiTsaefrs ti"

    const-string v3, "exec registerTask failed:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_3
    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushConfig;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->a(Ljava/lang/String;)Z

    move-result v0

    if-nez v0, :cond_f

    :try_start_2
    const-string/jumbo v0, "vietobupnlpt r srgostDie nteeayRuerec4N"

    const-string v0, "4nevontrga tReiwueDrsopseee lNb tctiryu"

    const-string/jumbo v0, "vseDwelbqcrpse  NgtentuueeRoi iyatner4r"

    const-string/jumbo v0, "try to setup registerRunnable4NewDevice"

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$24;->a:Landroid/content/Context;

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$24;->g:Ljava/lang/String;

    iget v4, p0, Lcom/tencent/android/tpush/XGPushManager$24;->f:I

    iget-object v5, p0, Lcom/tencent/android/tpush/XGPushManager$24;->h:Ljava/lang/String;

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$24;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    iget-wide v7, p0, Lcom/tencent/android/tpush/XGPushManager$24;->c:J

    iget-object v9, p0, Lcom/tencent/android/tpush/XGPushManager$24;->d:Ljava/lang/String;

    iget-object v10, p0, Lcom/tencent/android/tpush/XGPushManager$24;->i:Ljava/lang/String;

    iget-object v11, p0, Lcom/tencent/android/tpush/XGPushManager$24;->k:Ljava/lang/String;

    iget-object v12, p0, Lcom/tencent/android/tpush/XGPushManager$24;->j:Ljava/lang/String;

    iget-wide v13, p0, Lcom/tencent/android/tpush/XGPushManager$24;->e:J

    invoke-static/range {v2 .. v14}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    goto :goto_4

    :catchall_1
    move-exception v0

    const-string v2, "errr bviieeNeeDpeDueosgd mcRet4orx"

    const-string v2, "DxseRic dpuriteDrveeg o4eeoemesNrw"

    const-string v2, "doDumpRegister4NewDevice exe error"

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_f
    :goto_4
    return-void

    :cond_10
    :goto_5
    :try_start_3
    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$24;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    sget-object v5, Lcom/tencent/android/tpush/common/ReturnCode;->CODE_LOGIC_ILLEGAL_ARGUMENT:Lcom/tencent/android/tpush/common/ReturnCode;

    invoke-virtual {v5}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v5

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v8, "ssKm(eIseI ie@lu!ccsis: cc rea)eydcosic Tnaaedd rsva"

    const-string/jumbo v8, "ncari usyccvrciIaed@ )a:selsdeTK s Id(cshie ec!sesao"

    const-string v8, "aeaKoadescdrdvii T  h!ass@ri IeeosI cessecac)nlys(cc"

    const-string v8, "The accessId or accessKey is(are) invalid!@accessId:"

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v2, "Kpscebsa :e@c"

    const-string v2, "cy: ecKpa@sse"

    const-string/jumbo v2, "ss ee,ucKac:y"

    const-string v2, ", @accessKey:"

    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v4, v0, v5, v2}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    return-void

    :catchall_2
    move-exception v2

    const-string v3, "egqertrp"

    const-string/jumbo v3, "qrsrgete"

    const-string/jumbo v3, "qgretire"

    const-string/jumbo v3, "register"

    invoke-static {v1, v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$24;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    sget-object v3, Lcom/tencent/android/tpush/common/ReturnCode;->ERRORCODE_UNKNOWN:Lcom/tencent/android/tpush/common/ReturnCode;

    invoke-virtual {v3}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v4

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v3}, Lcom/tencent/android/tpush/common/ReturnCode;->getStr()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-interface {v1, v0, v4, v2}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    return-void
.end method
