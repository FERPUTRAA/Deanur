.class Lcom/tencent/android/tpush/XGPushManager$18;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->initCommonComponents(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$18;->a:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " vs~c b-o/~~@M lo~o4n i  /m~u~~~  ~ayi@rb~1~@~@ @So @@o @K~t@@l~t~  ~ @i @~~bo@@@. ~sd@~@ @~@ff~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$18;->a:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$18;->a:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->g(Landroid/content/Context;)V

    const/4 v2, 0x0

    return-void
.end method
