.class Lcom/tencent/android/tpush/XGPush4Msdk$10;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPush4Msdk;->setTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Ljava/util/Set;


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;Ljava/util/Set;)V
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$10;->a:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$10;->b:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$10;->c:Ljava/util/Set;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v10, "~vs~@@mo~@ o~/~ @ b@-@~ o~o oM~@~b~rf u @ ~@ @ @ 4@.t ~@bt~i/~ @~fl S n@i1~~~@ K@aysd~i@c@l~~~@o"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x3

    sget-boolean v0, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v10, 0x4

    or-int/2addr v11, v10

    const-string/jumbo v1, "sPhmMXs4kGd"

    const-string v1, "4hsXdkPuGsM"

    const/4 v11, 0x2

    const-string/jumbo v1, "s4kPodushMG"

    const-string v1, "XGPush4Msdk"

    const/4 v10, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x5

    if-eqz v0, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-string/jumbo v2, "r=eeabmaeNpss :taoTtg"

    const-string v2, "epNmTag=soamtesar: te"

    const/4 v11, 0x6

    const-string v2, "Tssp:mueetgNt=oraaaee"

    const-string/jumbo v2, "setTags: operateName="

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$10;->a:Ljava/lang/String;

    const/4 v11, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x7

    const-string v2, "dpoiqpqp="

    const-string/jumbo v2, "qiAqo=ppd"

    const/4 v11, 0x6

    const-string/jumbo v2, "qqAppdi=q"

    const-string v2, ",qqAppid="

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/XGPush4Msdk;->c()J

    move-result-wide v2

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    const-string v2, "cesgcadi,ssxb"

    const-string/jumbo v2, "xisaebgs_cdc,"

    const/4 v11, 0x1

    const-string v2, "g=smscc_xidae"

    const-string v2, ",xg_accessid="

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$10;->b:Landroid/content/Context;

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$10;->b:Landroid/content/Context;

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-eqz v0, :cond_3

    const/4 v10, 0x2

    shl-int/2addr v11, v10

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$10;->c:Ljava/util/Set;

    const/4 v10, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-eqz v0, :cond_3

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    if-eqz v0, :cond_1

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x6

    goto/16 :goto_0

    :cond_1
    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$10;->c:Ljava/util/Set;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    const-string/jumbo v2, "tTusoge"

    const-string v2, "agtseTu"

    const/4 v11, 0x7

    const-string/jumbo v2, "tassebg"

    const-string/jumbo v2, "setTags"

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/Set;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x7

    if-nez v4, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-string v0, "arau su!>eF-euepSseTgrTt!stg on mgttl nl"

    const-string/jumbo v0, "seu>atap m-!l!!egostrnr S eestglTgutTFn "

    const/4 v11, 0x2

    const-string v0, "a!esSelpt>rTF g steTtu!ngmgoelsraur  nt-"

    const-string/jumbo v0, "setTags -> getTagsFromSet return null!!!"

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x3

    return-void

    :cond_2
    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x1

    const-string/jumbo v2, "s t- TcAqs>whli  aa qegia no =gtls"

    const-string v2, " oa>gTitq ta e=slg  -s stwilAnahc "

    const/4 v11, 0x3

    const-string/jumbo v2, "wsslTat ai=hs got t-itan A l> c ge"

    const-string v2, "Action -> setTags with all tags = "

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$10;->b:Landroid/content/Context;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v5, 0x6

    xor-int/2addr v11, v5

    const/4 v10, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-static {v3}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v6

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$10;->b:Landroid/content/Context;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAppKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x4

    const/4 v10, 0x4

    iget-object v9, p0, Lcom/tencent/android/tpush/XGPush4Msdk$10;->a:Ljava/lang/String;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-static/range {v3 .. v9}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    return-void

    :cond_3
    :goto_0
    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    const-string/jumbo v0, "txsmi vaf nodaamtertiess  lneeh sgsteta grp o ac.ori"

    const-string v0, "  snaietsc ove paag.gttsoixe lmtesnfh tradtsi r oera"

    const/4 v11, 0x0

    const-string v0, " lg ov aisrgtsatn oeoif attsmpc axr.heeit aTeend ost"

    const-string/jumbo v0, "the parameter context or tags of setTags is invalid."

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x6

    return-void
.end method
