.class Lcom/tencent/android/tpush/XGPush4Msdk$4;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPush4Msdk;->unregisterPush(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/XGIOperateCallback;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$4;->a:Landroid/content/Context;

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$4;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v10, "@~s@ ~K 1~ ~ ~lM~~~b-i@ ~ mv@~n~ d  @b~bts ~i~ o@@@r~ul@~@@ o@tic @@. ~/@o4S@o@~@a~f ~@o y@/o~ ~"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x4

    sget-boolean v0, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x0

    if-eqz v0, :cond_0

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-string/jumbo v1, "pnhmurs,=usipdeqgieqArt"

    const-string v1, "eissp,iqdtusephgu=rqnrA"

    const/4 v11, 0x6

    const-string/jumbo v1, "tupsoqeipqrPhdiergAs=un"

    const-string/jumbo v1, "unregisterPush,qqAppid="

    const/4 v10, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/XGPush4Msdk;->c()J

    move-result-wide v1

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const-string v1, "gs,=ibc_cxsde"

    const-string v1, ",xg_accessid="

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$4;->a:Landroid/content/Context;

    const/4 v10, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-static {v1}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    const-string/jumbo v1, "mGMPdhusXs4"

    const-string v1, "d4smkMhGPsX"

    const/4 v11, 0x0

    const-string v1, "4dsuMGXpksP"

    const-string v1, "XGPush4Msdk"

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$4;->a:Landroid/content/Context;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$4;->b:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v4

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$4;->a:Landroid/content/Context;

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAppKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x2

    const/4 v7, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    const/4 v8, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    const/4 v9, 0x0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-static/range {v2 .. v9}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x3

    return-void
.end method
