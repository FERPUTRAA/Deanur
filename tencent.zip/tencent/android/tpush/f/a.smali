.class public Lcom/tencent/android/tpush/f/a;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/Boolean;

.field private static b:Ljava/lang/Boolean;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static a()I
    .locals 4

    :try_start_0
    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " Ms~ ~@~@d/~@~oyKi~@s@l~~~   @@ ~oSi@@~@~~ ibt @ ~~lm~  /1 @4 @fo@@@~@r.coov- @ @~bn~b@~tf ~o~au"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    const-string v0, "cysmmoe.eSmpu...hGcetysnnstnshttPXsps"

    const-string v0, "Stsencppe.st.sshnuoesysP.nm.mXtGychst"

    const/4 v3, 0x2

    const-string v0, "hspsoeonGtmsnycy.tXemstpP.uunssSteh.."

    const-string v0, "com.tencent.tpns.syspush.XGSystemPush"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/tencent/tpns/reflecttools/Reflect;->on(Ljava/lang/String;)Lcom/tencent/tpns/reflecttools/Reflect;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v1, "etgmpbnlnPahhTyees"

    const-string v1, "PThmeapeetnnyhCgls"

    const/4 v3, 0x7

    const-string v1, "eteyhhuglsnaTpCuPe"

    const-string v1, "getPushChannelType"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/reflecttools/Reflect;->call(Ljava/lang/String;)Lcom/tencent/tpns/reflecttools/Reflect;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/tencent/tpns/reflecttools/Reflect;->get()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    check-cast v0, Ljava/lang/Integer;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0
    :try_end_0
    .catch Lcom/tencent/tpns/reflecttools/ReflectException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    return v0

    :catch_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 v0, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x5

    return v0
.end method

.method public static a(Landroid/content/Context;J)Ljava/lang/String;
    .locals 6

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v0, "umnes..pyohtsPtnGshppucoScem.sXnsyets"

    const-string/jumbo v0, "thheoy.moutuPc.nnsyssGtesnXsSpm.stepc"

    const/4 v5, 0x2

    const-string v0, ".nmsSut.qsct.espGsnnhecXmyPsouyhest.t"

    const-string v0, "com.tencent.tpns.syspush.XGSystemPush"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/tencent/tpns/reflecttools/Reflect;->on(Ljava/lang/String;)Lcom/tencent/tpns/reflecttools/Reflect;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const-string v1, "ecspPpgAaagek"

    const-string v1, "getAppPackage"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    const/4 v2, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    aput-object p0, v2, v3

    const/4 v5, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 p1, 0x1

    const/4 v5, 0x0

    aput-object p0, v2, p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Lcom/tencent/tpns/reflecttools/Reflect;->call(Ljava/lang/String;[Ljava/lang/Object;)Lcom/tencent/tpns/reflecttools/Reflect;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/tencent/tpns/reflecttools/Reflect;->get()Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    check-cast p0, Ljava/lang/String;
    :try_end_0
    .catch Lcom/tencent/tpns/reflecttools/ReflectException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x7

    return-object p0

    :catch_0
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const/4 p0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-object p0
.end method

.method public static a(Landroid/content/Context;)Z
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object v0, Lcom/tencent/android/tpush/f/a;->a:Ljava/lang/Boolean;

    const/4 v4, 0x0

    if-nez v0, :cond_2

    const/4 v3, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget v0, p0, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/16 v1, 0x3e8

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v2, "sPSmhby"

    const-string/jumbo v2, "sSsPhby"

    const/4 v4, 0x3

    const-string/jumbo v2, "ysuPosS"

    const-string v2, "SysPush"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-le v0, v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->flags:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    and-int/lit8 p0, p0, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    sput-object p0, Lcom/tencent/android/tpush/f/a;->a:Ljava/lang/Boolean;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo p0, "nprmubolaai p u R"

    const-string p0, " rnampuali Rpuon "

    const/4 v4, 0x2

    const-string/jumbo p0, "oaalp u iu rRpnnn"

    const-string p0, "Run in normal app"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_1

    :cond_1
    :goto_0
    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string p0, ".ussscXponSGpct.Phshtnypesumtp.yeem.s"

    const-string/jumbo p0, "u..hseSptp.teycsmhns.mGscpustoeyntPXs"

    const/4 v4, 0x4

    const-string/jumbo p0, "yttsctsSquGysph.e.P.nmnpot.smsesnhuXc"

    const-string p0, "com.tencent.tpns.syspush.XGSystemPush"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v4, 0x6

    const/4 v3, 0x7

    sput-object p0, Lcom/tencent/android/tpush/f/a;->a:Ljava/lang/Boolean;

    const/4 v4, 0x4

    const-string/jumbo p0, "sqs s!uSn PAusy"

    const-string/jumbo p0, "yssn!u  qAuPshS"

    const/4 v4, 0x3

    const-string p0, "hRnmu!y sPuSAs "

    const-string p0, "Run As SysPush!"

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    goto :goto_1

    :catchall_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    sput-object p0, Lcom/tencent/android/tpush/f/a;->a:Ljava/lang/Boolean;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string p0, " ounosnupsdpt  psy nR,dss anubs fh tiu k y"

    const-string/jumbo p0, "yos suudu ikspRnust  b  ndssoytahnn pf,  p"

    const-string p0, "Run in sys app, but not found sys push sdk"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    sget-object p0, Lcom/tencent/android/tpush/f/a;->a:Ljava/lang/Boolean;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x7

    return p0

    :cond_2
    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    sget-object p0, Lcom/tencent/android/tpush/f/a;->a:Ljava/lang/Boolean;

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    return p0
.end method

.method public static a(Landroid/content/Context;JLjava/lang/String;)Z
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v0, 0x0

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string v1, "GsymeshuXm.pose.ttcscyusttne.hsnP.Spm"

    const/4 v5, 0x5

    const-string v1, ".uysmb...mnSuchpetPthXssestenstnsyocp"

    const-string v1, "com.tencent.tpns.syspush.XGSystemPush"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/tencent/tpns/reflecttools/Reflect;->on(Ljava/lang/String;)Lcom/tencent/tpns/reflecttools/Reflect;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v2, "PceeoncgahkdAcceAkscIsa"

    const/4 v5, 0x0

    const-string v2, "checkAccessIdAndPackage"

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    const/4 v3, 0x3

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    new-array v3, v3, [Ljava/lang/Object;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    aput-object p0, v3, v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 p1, 0x1

    and-int/2addr v5, p1

    aput-object p0, v3, p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    const/4 p0, 0x2

    const/4 v4, 0x6

    move v5, v4

    aput-object p3, v3, p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v1, v2, v3}, Lcom/tencent/tpns/reflecttools/Reflect;->call(Ljava/lang/String;[Ljava/lang/Object;)Lcom/tencent/tpns/reflecttools/Reflect;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/tencent/tpns/reflecttools/Reflect;->get()Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    check-cast p0, Ljava/lang/Boolean;

    const/4 v5, 0x6

    const/4 v4, 0x2

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_0
    .catch Lcom/tencent/tpns/reflecttools/ReflectException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    return p0

    :catch_0
    const/4 v4, 0x0

    move v5, v4

    return v0
.end method

.method public static b(Landroid/content/Context;)Z
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    sget-object v0, Lcom/tencent/android/tpush/f/a;->b:Ljava/lang/Boolean;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string/jumbo v1, "sshPySu"

    const-string v1, "SysPush"

    const/4 v6, 0x4

    const/4 v5, 0x2

    if-nez v0, :cond_4

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v2, 0x0

    const/4 v6, 0x4

    move v5, v2

    move v5, v2

    const/4 v6, 0x6

    const/4 v3, 0x3

    const/4 v6, 0x6

    const/4 v3, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0, v2, v3, v3}, Landroid/content/pm/PackageManager;->queryContentProviders(Ljava/lang/String;II)Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x0

    xor-int/2addr v6, v5

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eqz v2, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    check-cast v2, Landroid/content/pm/ProviderInfo;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v3, v2, Landroid/content/pm/ProviderInfo;->name:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string/jumbo v4, "tyu.tsXpSp.nvonscmesesdmrsiePyocsr.hthPuen.tp"

    const-string v4, "com.tencent.tpns.syspush.XGSystemPushProvider"

    const/4 v5, 0x4

    move v6, v5

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget-object v3, v2, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string v4, "ehnah.stquctptubcsseympnsnt.."

    const-string/jumbo v4, "uc.stbhtu.eppetsyn.nssnchtamo"

    const/4 v6, 0x1

    const-string v4, "com.tencent.tpns.syspush.auth"

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    if-eqz v3, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string v3, "ces gupvtnrryestioedhpsoun   "

    const-string/jumbo v3, "pcvtoeu  yensesd irrhsgtnp uo"

    const/4 v6, 0x7

    const-string v3, " semsog tipnohsveut dn rrtcye"

    const-string v3, "get sys push content provider"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v1, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v2, v2, Landroid/content/pm/ProviderInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v5, 0x7

    move v6, v5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    iget-object v4, v2, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v3, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x1

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    sput-object p0, Lcom/tencent/android/tpush/f/a;->b:Ljava/lang/Boolean;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string p0, " sfsolDlustv i  GisSe tesUaegip bfcisX,eyeseeeat"

    const-string p0, " yefsa pea,tee sls seUugiDvsitislftbXSs i ecceGe"

    const-string/jumbo p0, "svDisbeteciSi eGiaseXetif   lsfge, Usa yscsutbel"

    const-string p0, "Get isUseXgSysDevice false, beacuse it is itself"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    sget-object p0, Lcom/tencent/android/tpush/f/a;->b:Ljava/lang/Boolean;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    return p0

    :cond_1
    const/4 v6, 0x7

    iget v3, v2, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v6, 0x5

    const/16 v4, 0x3e8

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-le v3, v4, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget v3, v2, Landroid/content/pm/ApplicationInfo;->flags:I

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    and-int/lit8 v3, v3, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v3, :cond_0

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x5

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    sput-object p0, Lcom/tencent/android/tpush/f/a;->b:Ljava/lang/Boolean;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string v0, "eeS:tdusvG>csriy-geeDU  quiXiu ts"

    const-string/jumbo v0, "sDieieigqs:rXs>tvG ueuedySt  eUc-"

    const/4 v6, 0x5

    const-string/jumbo v0, "ie suDXpSetdUG:visctg-seei>e ruy "

    const-string v0, "Get isUseXgSysDevice true -> uid:"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget v0, v2, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const-string/jumbo v0, "lpio sngqfl.atas:Ifpicao"

    const-string v0, " csgifat.lp,loiIofsa:npa"

    const/4 v6, 0x5

    const-string v0, ", applicationInfo.flags:"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget v0, v2, Landroid/content/pm/ApplicationInfo;->flags:I

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    sget-object p0, Lcom/tencent/android/tpush/f/a;->b:Ljava/lang/Boolean;

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    return p0

    :catchall_0
    move-exception p0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string v0, " csmbyTvaS eirlUisgseoeesDw"

    const-string v0, "hgbmvrUTesaSiissDclee  ewyo"

    const/4 v6, 0x1

    const-string v0, "aoimsehvXD eiyS glsrbTUwees"

    const-string/jumbo v0, "isUseXgSysDevice Throwable "

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-static {v1, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_3
    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    sput-object p0, Lcom/tencent/android/tpush/f/a;->b:Ljava/lang/Boolean;

    :cond_4
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string v0, "evioogeDXcUiSy:es "

    const-string v0, "eUD:ogvi ySeseiXsc"

    const/4 v6, 0x3

    const-string/jumbo v0, "sgeXDbiv:Uc iSesey"

    const-string/jumbo v0, "isUseXgSysDevice: "

    const/4 v6, 0x5

    const/4 v5, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    sget-object v0, Lcom/tencent/android/tpush/f/a;->b:Ljava/lang/Boolean;

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    sget-object p0, Lcom/tencent/android/tpush/f/a;->b:Ljava/lang/Boolean;

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    return p0
.end method
