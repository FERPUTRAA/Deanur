.class Lcom/tencent/android/tpush/stat/StatServiceImpl$5;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/Context;DJZ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:D

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:J


# direct methods
.method constructor <init>(DLandroid/content/Context;J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-wide p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$5;->a:D

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p3, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$5;->b:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x3

    iput-wide p4, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$5;->c:J

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public run()V
    .locals 11

    :try_start_0
    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "slsb .ti ~4~/Sd@@~o@b~  ~t o~ ~oo~ub@n~iK@@y  @ oraMf~@m~o~c@~ ~@~@- i~@@  ~@@~@ v~1~ f@@~@ @l/~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-string/jumbo v2, "uisrtagcnrouaaro:nkctkdd "

    const/4 v10, 0x5

    const-string/jumbo v2, "k :mncdBcaatuoogurnrdrikt"

    const-string/jumbo v2, "trackBackground duration:"

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$5;->a:D

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(D)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Object;)V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x4

    iget-wide v0, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$5;->a:D

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v10, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    cmpg-double v2, v0, v2

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    if-gtz v2, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-wide v0, 0x3fb999999999999aL    # 0.1

    const-wide v0, 0x3fb999999999999aL    # 0.1

    const/4 v10, 0x7

    const-wide v0, 0x3fb999999999999aL    # 0.1

    const-wide v0, 0x3fb999999999999aL    # 0.1

    :cond_0
    move-wide v5, v0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x5

    new-instance v0, Lcom/tencent/android/tpush/stat/event/a;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$5;->b:Landroid/content/Context;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$5;->b:Landroid/content/Context;

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-wide v7, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$5;->c:J

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {v1, v7, v8}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Landroid/content/Context;J)I

    move-result v4

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x4

    iget-wide v7, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$5;->c:J

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    move-object v2, v0

    const/4 v10, 0x6

    invoke-direct/range {v2 .. v8}, Lcom/tencent/android/tpush/stat/event/a;-><init>(Landroid/content/Context;IDJ)V

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    new-instance v1, Ljava/util/ArrayList;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-interface {v1, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Ljava/util/List;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x5

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-virtual {v1, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    return-void
.end method
