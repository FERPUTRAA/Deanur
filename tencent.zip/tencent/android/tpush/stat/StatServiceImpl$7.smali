.class Lcom/tencent/android/tpush/stat/StatServiceImpl$7;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/stat/c;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/app/Application;J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J


# direct methods
.method constructor <init>(J)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-wide p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$7;->a:J

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/bsilM~tici~~dbo@f~l@@@b @ o@~y@o@tr~-. m~~ ~ @@oa~~  K4  ~@@u~~   @@o@/  ~nv@S os ~~~~~@f~@@@ ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(J)J

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public b()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-wide v1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$7;->a:J

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/common/d;->a()Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v0, v1, v2, v3}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/Context;JZ)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    return-void
.end method
