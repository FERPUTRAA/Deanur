.class Lcom/tencent/android/tpush/stat/ServiceStat$a$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/ServiceStat$a;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/stat/ServiceStat$a;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/stat/ServiceStat$a;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/ServiceStat$a$1;->b:Lcom/tencent/android/tpush/stat/ServiceStat$a;

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/stat/ServiceStat$a$1;->a:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~s~v@@@boiof@a or~@// io~ ~@~@@@b.~c~@@ ~@t@@@@@S@~t d osl~-  f ~~n K ~u~bo~4M1~m~i ~y@~~l@ ~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/ServiceStat$a$1;->a:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/ServiceStat;->sendLocalMsg(Landroid/content/Context;)V

    const/4 v1, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method
