.class Lcom/tencent/android/tpush/stat/StatServiceImpl$8;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/stat/lifecycle/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl;->checkAppLunch(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(Landroid/app/Activity;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "b~s yo@. ~ i~~ t~@ ~4@~@ o @sl@@fb@@i~af~iS/ovr~@t~~~~@  M~~ /co1@@~@@ @b~ lo~d  K@ ~u-@ ~@~ @no"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    return-void
.end method

.method public a(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x7

    return-void
.end method

.method public b(Landroid/app/Activity;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    const-string/jumbo v0, "ontmeysaditASvtit"

    const-string v0, "dosiAetcSittyanvt"

    const/4 v2, 0x4

    const-string/jumbo v0, "onActivityStarted"

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/stat/a/a;->b(Landroid/app/Activity;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-void
.end method

.method public b(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    const-string/jumbo p2, "meCeoAoctirdnytit"

    const-string/jumbo p2, "ittmridcaeAentCoy"

    const/4 v1, 0x3

    const-string/jumbo p2, "tciiCbeAtevyadtnr"

    const-string/jumbo p2, "onActivityCreated"

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/stat/a/a;->b(Landroid/app/Activity;Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public c(Landroid/app/Activity;)V
    .locals 2

    const/4 v0, 0x4

    move v1, v0

    return-void
.end method

.method public d(Landroid/app/Activity;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string/jumbo v0, "uayAPsudeinvtoto"

    const-string/jumbo v0, "oytiocPvseAndaut"

    const/4 v2, 0x3

    const-string/jumbo v0, "svtnidepauAcPyio"

    const-string/jumbo v0, "onActivityPaused"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/stat/a/a;->a(Landroid/app/Activity;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method public e(Landroid/app/Activity;)V
    .locals 3

    const/4 v2, 0x7

    const-string/jumbo v0, "teboAriDqeovdyytisc"

    const-string v0, "ersAeboydittyvcDino"

    const/4 v2, 0x7

    const-string v0, "DisveeAtnyoiyoscrdt"

    const-string/jumbo v0, "onActivityDestroyed"

    const/4 v1, 0x5

    xor-int/2addr v2, v1

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/stat/a/a;->a(Landroid/app/Activity;Ljava/lang/String;)V

    const/4 v2, 0x3

    return-void
.end method
