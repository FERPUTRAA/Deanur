.class public Lcom/tencent/android/tpush/stat/a/a;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# static fields
.field private static a:J

.field private static b:J

.field private static g:Ljava/lang/String;

.field private static volatile h:Z

.field private static i:Lcom/tencent/android/tpush/stat/a/a;


# instance fields
.field private c:Landroid/content/Intent;

.field private d:Ljava/lang/String;

.field private e:Landroid/content/Context;

.field private f:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/content/Intent;Ljava/lang/String;I)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string v0, "AussTLhnakcsp"

    const-string/jumbo v0, "kAsushcaapLnT"

    const/4 v2, 0x5

    const-string v0, "haAmapcsnTpkL"

    const-string v0, "AppLaunchTask"

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpush/stat/a/a;->c:Landroid/content/Intent;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object p3, p0, Lcom/tencent/android/tpush/stat/a/a;->d:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/a/a;->e:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput p4, p0, Lcom/tencent/android/tpush/stat/a/a;->f:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-void
.end method

.method private static a(Landroid/app/Activity;Ljava/lang/String;I)Lcom/tencent/android/tpush/stat/a/a;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~.to  vro@~  ~@/~sb~@@i~  ~@@~@~b~@@4oi@ @ @ l u@o~/f@ Ki-n ~~ ~~~o~~@b1   m~M@ ~@Sta@loydf@~c@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string p0, "hnuckbapLAaTs"

    const-string p0, "AppLaunchTask"

    const/4 v2, 0x5

    xor-int/2addr v3, v2

    const-string/jumbo p1, "ucialpuumntlah wAc pur-isv tynnL"

    const-string/jumbo p1, "unhmpLu pcusiwAncaylav-rnlatit  "

    const/4 v3, 0x5

    const-string/jumbo p1, "nuiutaipwphna yAclr-lLcpsunt a  "

    const-string/jumbo p1, "runAppLaunch - activity was null"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object p0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/app/Activity;->getComponentName()Landroid/content/ComponentName;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p0}, Landroid/app/Activity;->getIntent()Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v1, Lcom/tencent/android/tpush/stat/a/a;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v1, p0, v0, p1, p2}, Lcom/tencent/android/tpush/stat/a/a;-><init>(Landroid/content/Context;Landroid/content/Intent;Ljava/lang/String;I)V

    const/4 v2, 0x4

    shr-int/2addr v3, v2

    return-object v1
.end method

.method private a()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a/a;->e:Landroid/content/Context;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/common/j;->c(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a/a;->e:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v1, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v2, "rh_s_ptcqifolupn"

    const-string/jumbo v2, "ncstof_rulpaph_i"

    const/4 v4, 0x3

    const-string v2, "hnssrlftpiu_aapc"

    const-string v2, "app_first_launch"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v0, v2, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getBoolean(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a/a;->e:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportCustomData4FirstLaunch(Landroid/content/Context;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a/a;->e:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-static {v0, v2, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putBoolean(Landroid/content/Context;Ljava/lang/String;Z)V

    :cond_0
    const/4 v4, 0x3

    return-void
.end method

.method public static a(Landroid/app/Activity;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez p0, :cond_0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string p0, "anpmsbhTApLcu"

    const-string/jumbo p0, "uapnTbALhaspc"

    const/4 v3, 0x3

    const-string/jumbo p0, "nppkoauATcsLh"

    const-string p0, "AppLaunchTask"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v1, "toiaabcsiiunnn-atwi sytt lAl sixtov rvu :Ec,"

    const-string/jumbo v1, "oxnttvui tn:lAilsay so,iusactn - aiEcrw etiv"

    const/4 v3, 0x6

    const-string/jumbo v1, "onActivityExits - activity was null, reason:"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    sput-wide p0, Lcom/tencent/android/tpush/stat/a/a;->a:J

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    sget-wide p0, Lcom/tencent/android/tpush/stat/a/a;->b:J

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    cmp-long p0, p0, v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz p0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    sput-wide v0, Lcom/tencent/android/tpush/stat/a/a;->b:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo v0, "pLpuaAupTsank"

    const-string v0, "hnpkTsappALau"

    const/4 v2, 0x5

    const-string v0, "AppLaunchTask"

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p2, :cond_0

    :try_start_1
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-string/jumbo p0, "ukln lotqn aes"

    const/4 v2, 0x3

    const-string/jumbo p0, "lwkaontpnl eus"

    const-string/jumbo p0, "token was null"

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez p0, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string/jumbo p0, "uctllsa q noxnes"

    const-string/jumbo p0, "u s lnntsoelawxc"

    const/4 v2, 0x0

    const-string p0, " ssw nlcoenaultx"

    const-string p0, "context was null"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void

    :cond_1
    const/4 v1, 0x0

    move v2, v1

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/Util;->isMainProcess(Landroid/content/Context;)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-nez p0, :cond_2

    const/4 v2, 0x1

    const-string/jumbo p0, "metmmt nn sm uaosu prarc"

    const-string/jumbo p0, "mcamsatrnm rpuisu n teo "

    const/4 v2, 0x4

    const-string/jumbo p0, "isr on sc ut stmeraopmnu"

    const-string/jumbo p0, "must run at main process"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void

    :cond_2
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    sput-object p1, Lcom/tencent/android/tpush/stat/a/a;->g:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x2

    sget-boolean p0, Lcom/tencent/android/tpush/stat/a/a;->h:Z

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    if-eqz p0, :cond_3

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object p0, Lcom/tencent/android/tpush/stat/a/a;->i:Lcom/tencent/android/tpush/stat/a/a;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-eqz p0, :cond_3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x3

    sget-object p1, Lcom/tencent/android/tpush/stat/a/a;->i:Lcom/tencent/android/tpush/stat/a/a;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v2, 0x4

    const/4 p0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    sput-boolean p0, Lcom/tencent/android/tpush/stat/a/a;->h:Z

    const/4 v1, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    const/4 p0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    sput-object p0, Lcom/tencent/android/tpush/stat/a/a;->i:Lcom/tencent/android/tpush/stat/a/a;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :cond_3
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method private static a(Landroid/content/Context;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    if-nez p0, :cond_0

    const/4 v1, 0x5

    shr-int/2addr v2, v1

    return v0

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x3

    sget-object p0, Lcom/tencent/android/tpush/stat/a/a;->g:Ljava/lang/String;

    const/4 v2, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    if-eqz p0, :cond_1

    const/4 v2, 0x7

    sget-object p0, Lcom/tencent/android/tpush/stat/a/a;->g:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0

    :cond_1
    const/4 v2, 0x0

    const/4 p0, 0x1

    const/4 v2, 0x0

    const/4 p0, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    return p0
.end method

.method private b(Landroid/content/Context;)I
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string/jumbo v2, "ufhaobes.rfttdnylch.i.o"

    const-string v2, ".audohnfaeoycftir.s.htl"

    const/4 v6, 0x2

    const-string/jumbo v2, "n.catuuhf.rehlo.difatys"

    const-string v2, "fisrt.launch.of.the.day"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {p1, v2, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getLong(Landroid/content/Context;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v3, v4, v0, v1}, Lcom/tencent/android/tpush/common/j;->a(JJ)Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez v0, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {p1, v2, v3, v4}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putLong(Landroid/content/Context;Ljava/lang/String;J)V

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    xor-int/lit8 p1, v0, 0x1

    const/4 v6, 0x6

    return p1
.end method

.method private b()V
    .locals 8

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a/a;->e:Landroid/content/Context;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->disableRepLanuEv()Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-nez v0, :cond_5

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a/a;->d:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-class v1, Lcom/tencent/android/tpush/TpnsActivity;

    const-class v1, Lcom/tencent/android/tpush/TpnsActivity;

    const/4 v6, 0x3

    and-int/2addr v7, v6

    invoke-virtual {v1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-nez v0, :cond_4

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a/a;->d:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-class v1, Lcom/tencent/android/tpush/InnerTpnsActivity;

    const-class v1, Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v7, 0x5

    const-class v1, Lcom/tencent/android/tpush/InnerTpnsActivity;

    const-class v1, Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/lang/Class;->getCanonicalName()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {v0, v1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    if-eqz v0, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    goto/16 :goto_1

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a/a;->c:Landroid/content/Intent;

    const/4 v6, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x1

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v7, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz v0, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v0}, Landroid/content/Intent;->getData()Landroid/net/Uri;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x7

    if-eqz v0, :cond_1

    const/4 v6, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0}, Landroid/net/Uri;->getHost()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    if-nez v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    const/4 v0, 0x2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    goto/16 :goto_2

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a/a;->c:Landroid/content/Intent;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/stat/a/a;->c:Landroid/content/Intent;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v3}, Landroid/content/Intent;->getCategories()Ljava/util/Set;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 v4, 0x1

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v3, :cond_2

    const/4 v7, 0x0

    const-string v5, ".geyCeapdr.rdcHRatLEnNtoUinnbt.A"

    const-string/jumbo v5, "taAngbtNEotaen.iRidHcryUnr.LC.de"

    const/4 v7, 0x5

    const-string/jumbo v5, "nrNdtotnqoyiCdgRcrta.nH.ea.eEUAL"

    const-string v5, "android.intent.category.LAUNCHER"

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-interface {v3, v5}, Ljava/util/Set;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eqz v3, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    move v3, v4

    move v3, v4

    const/4 v7, 0x0

    move v3, v4

    move v3, v4

    const/4 v7, 0x3

    goto :goto_0

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v3, 0x0

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string v5, "a.noncuinoItrdtdiM.atie.NA"

    const/4 v7, 0x3

    const-string v5, "dtsdnirnIAMnao.itne.coNita"

    const-string v5, "android.intent.action.MAIN"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {v0, v5}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eqz v0, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v3, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    move v0, v4

    move v0, v4

    const/4 v7, 0x0

    move v0, v4

    move v0, v4

    const/4 v7, 0x4

    const/4 v6, 0x1

    goto :goto_2

    :cond_3
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 v0, 0x4

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    goto :goto_2

    :cond_4
    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a/a;->c:Landroid/content/Intent;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/TpnsActivity;->getMsgIdWithIntent(Landroid/content/Intent;)J

    move-result-wide v1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    const/4 v0, 0x3

    :goto_2
    const/4 v7, 0x7

    const/4 v6, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpush/stat/a/a;->e:Landroid/content/Context;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-direct {p0, v3}, Lcom/tencent/android/tpush/stat/a/a;->b(Landroid/content/Context;)I

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpush/stat/a/a;->e:Landroid/content/Context;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {v4, v0, v3, v1, v2}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportLaunchEvent(Landroid/content/Context;IIJ)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    goto :goto_3

    :cond_5
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    const-string/jumbo v0, "ppLmcuaAaTnsp"

    const-string/jumbo v0, "nuLATapphsacp"

    const/4 v7, 0x2

    const-string/jumbo v0, "unpcoAThaksLp"

    const-string v0, "AppLaunchTask"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string/jumbo v1, "ptadrb ueanle b sdeoqehcvlit"

    const-string v1, "e httcalqubvddparierso nele "

    const/4 v7, 0x4

    const-string v1, "ichernu voeatlspenlbtaddr u "

    const-string v1, "disabled report launch event"

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :goto_3
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    return-void
.end method

.method public static b(Landroid/app/Activity;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-nez p0, :cond_0

    :try_start_0
    const/4 v3, 0x6

    const-string p0, "hAspLaappuksc"

    const-string/jumbo p0, "phsacpLAuaskT"

    const/4 v3, 0x6

    const-string/jumbo p0, "kpcnshuaqTAap"

    const-string p0, "AppLaunchTask"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v1, "m s:io reatan -nyicilr, cvAsu nwEttoynsvayli"

    const-string/jumbo v1, "nnimto:tra Aiuao nvyvw -ynia cel ,tEilsrctys"

    const/4 v3, 0x2

    const-string v1, "acymulioetntynloit A nasr v :,nai -vywsictEt"

    const-string/jumbo v1, "onActivityEntry - activity was null, reason:"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-void

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/stat/a/a;->c()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/a/a;->a(Landroid/content/Context;)Z

    move-result v1

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-nez v1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-ne v0, v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v1, 0x1

    move v3, v1

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    sput-boolean v1, Lcom/tencent/android/tpush/stat/a/a;->h:Z

    const/4 v3, 0x3

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpush/stat/a/a;->a(Landroid/app/Activity;Ljava/lang/String;I)Lcom/tencent/android/tpush/stat/a/a;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    sput-object p0, Lcom/tencent/android/tpush/stat/a/a;->i:Lcom/tencent/android/tpush/stat/a/a;

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void

    :cond_2
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-lez v0, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpush/stat/a/a;->b(Landroid/app/Activity;Ljava/lang/String;I)V

    :cond_3
    const/4 v2, 0x1

    move v3, v2

    sget-wide p0, Lcom/tencent/android/tpush/stat/a/a;->b:J

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v2, 0x1

    move v3, v2

    cmp-long p0, p0, v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez p0, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    sput-wide p0, Lcom/tencent/android/tpush/stat/a/a;->b:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_4
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method private static b(Landroid/app/Activity;Ljava/lang/String;I)V
    .locals 2

    :try_start_0
    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/stat/a/a;->a(Landroid/app/Activity;Ljava/lang/String;I)Lcom/tencent/android/tpush/stat/a/a;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x4

    if-eqz p0, :cond_0

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p1

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-virtual {p1, p0}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :cond_0
    const/4 v0, 0x5

    const/4 v1, 0x2

    const/4 p0, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x0

    sput-object p0, Lcom/tencent/android/tpush/stat/a/a;->i:Lcom/tencent/android/tpush/stat/a/a;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    const/4 p0, 0x0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x0

    sput-boolean p0, Lcom/tencent/android/tpush/stat/a/a;->h:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x3

    const-string p2, "dpoaoectnc opxfuLnAehre:pr u"

    const-string/jumbo p2, "p neoaoLuAtxrupruefdncp:he c"

    const/4 v1, 0x5

    const-string/jumbo p2, "upouebrnLpur exAapn:tfneh dc"

    const-string/jumbo p2, "unexpected for runAppLaunch:"

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const-string/jumbo p1, "pLcApnubaahkT"

    const-string/jumbo p1, "phkanbapcTAsL"

    const/4 v1, 0x1

    const-string p1, "LpsnaAuphkaTp"

    const-string p1, "AppLaunchTask"

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method

.method private static declared-synchronized c()I
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x3

    const-class v0, Lcom/tencent/android/tpush/stat/a/a;

    const/4 v10, 0x2

    const-class v0, Lcom/tencent/android/tpush/stat/a/a;

    const-class v0, Lcom/tencent/android/tpush/stat/a/a;

    const/4 v9, 0x0

    const/4 v9, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v10, 0x1

    const/4 v9, 0x3

    sget-wide v3, Lcom/tencent/android/tpush/stat/a/a;->a:J

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x4

    sub-long/2addr v1, v3

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    sget-wide v3, Lcom/tencent/android/tpush/stat/a/a;->b:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v10, 0x1

    const-wide/16 v5, 0x0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x3

    cmp-long v7, v3, v5

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x5

    if-nez v7, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x5

    const-wide/16 v7, 0x7530

    const-wide/16 v7, 0x7530

    const/4 v10, 0x4

    const-wide/16 v7, 0x7530

    const-wide/16 v7, 0x7530

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    cmp-long v7, v1, v7

    const/4 v9, 0x5

    move v10, v9

    if-lez v7, :cond_0

    const/4 v10, 0x0

    monitor-exit v0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x2

    const/4 v0, 0x2

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x2

    return v0

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    cmp-long v3, v3, v5

    const/4 v10, 0x1

    if-nez v3, :cond_1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    const-wide/16 v3, 0x1f40

    const-wide/16 v3, 0x1f40

    const/4 v10, 0x2

    const-wide/16 v3, 0x1f40

    const-wide/16 v3, 0x1f40

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    cmp-long v1, v1, v3

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    if-lez v1, :cond_1

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x3

    monitor-exit v0

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x3

    const/4 v0, 0x1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    return v0

    :cond_1
    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    monitor-exit v0

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    const/4 v0, -0x1

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    return v0

    :catchall_0
    move-exception v1

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    monitor-exit v0

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x1

    throw v1
.end method


# virtual methods
.method public TRun()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a/a;->e:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string/jumbo v1, "papLcAanquuTh"

    const-string/jumbo v1, "puAThnuLpaasc"

    const/4 v3, 0x1

    const-string/jumbo v1, "pcssuTpLAahkn"

    const-string v1, "AppLaunchTask"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v0, "nstmnpwtx lleoa "

    const-string/jumbo v0, "n asellpxwout tn"

    const/4 v3, 0x6

    const-string/jumbo v0, "xa loonslwute ct"

    const-string v0, "context was null"

    const/4 v2, 0x6

    move v3, v2

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-lez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v0, "fdP!tbTii qaSeiNl"

    const-string v0, "fl N tPSq!daiiTei"

    const/4 v3, 0x3

    const-string/jumbo v0, "ltTfiiuiP  nNdaSe"

    const-string v0, "TPNS init failed!"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    iget v0, p0, Lcom/tencent/android/tpush/stat/a/a;->f:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x2

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-ne v0, v1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpush/stat/a/a;->a()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpush/stat/a/a;->b()V

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a/a;->e:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/service/util/c;->a(Landroid/content/Context;Z)V

    const/4 v2, 0x1

    move v3, v2

    return-void
.end method
