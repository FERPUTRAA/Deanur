.class Lcom/tencent/android/tpush/stat/StatServiceImpl$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl;->inerTrackBeginPage(Landroid/content/Context;Ljava/lang/String;J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:J


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;J)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$3;->a:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$3;->b:Landroid/content/Context;

    const/4 v1, 0x6

    iput-wide p3, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$3;->c:J

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public run()V
    .locals 7

    :try_start_0
    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@@s~@ ~b@K~-@o iffl i@~oo~ dbt~@v~@ o / o @ 1c~@r~@ ~~~@  /t@yM@@@~@ns~~~~o4um~ bl  @. @Sa@ ~~~~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g()Ljava/util/Map;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    monitor-enter v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g()Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x0

    invoke-interface {v1}, Ljava/util/Map;->size()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->f()I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-lt v1, v2, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    or-int/2addr v6, v5

    const-string/jumbo v3, "rbfmsecTetemvme dpuxe meu aei vnsah  xmeoe  nahgltue"

    const-string v3, "The number of page events exceeds the maximum value "

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->f()I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-static {v3}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1, v2}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    monitor-exit v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    return-void

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$3;->a:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x7

    invoke-static {v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Ljava/lang/String;)Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g()Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->h()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {v1, v2}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const-string/jumbo v3, "seDgoulD P aaIpi ce"

    const-string v3, "gcsaDe uI :il DaePp"

    const/4 v6, 0x5

    const-string v3, "e :DDbaacgp e ItluP"

    const-string v3, "Duplicate PageID : "

    const/4 v6, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->h()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string v3, "eem  (u)opdRtaesmue?nr"

    const-string/jumbo v3, "m(emRtre?u psn)ae e,od"

    const/4 v6, 0x0

    const-string v3, " a),pedpe(usee ?enRort"

    const-string v3, ", onResume() repeated?"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Lcom/tencent/android/tpush/stat/b/c;->f(Ljava/lang/Object;)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    monitor-exit v0

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    return-void

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g()Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->h()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-interface {v1, v2, v3}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$3;->b:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$3;->c:J

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {v0, v1, v2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Landroid/content/Context;J)I
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    goto :goto_0

    :catchall_0
    move-exception v1

    :try_start_3
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    throw v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception v0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v1, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-void
.end method
