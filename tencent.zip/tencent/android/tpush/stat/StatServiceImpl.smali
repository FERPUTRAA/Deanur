.class public Lcom/tencent/android/tpush/stat/StatServiceImpl;
.super Ljava/lang/Object;


# static fields
.field static volatile a:J

.field private static b:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private static volatile c:Landroid/os/Handler;

.field private static volatile d:I

.field private static volatile e:Ljava/lang/String;

.field private static volatile f:Ljava/lang/String;

.field private static g:Lcom/tencent/android/tpush/stat/b/c;

.field private static volatile h:Z

.field private static volatile i:Z

.field private static j:Landroid/os/Handler;

.field private static volatile k:Ljava/lang/Runnable;

.field private static l:J

.field private static m:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tencent/android/tpush/stat/c;",
            ">;"
        }
    .end annotation
.end field

.field private static n:J

.field private static volatile o:J

.field private static p:Landroid/content/Context;

.field private static q:Ljava/lang/String;

.field private static volatile r:Landroid/content/SharedPreferences;

.field private static volatile s:Landroid/content/SharedPreferences;

.field public static volatile storedList:Z

.field private static volatile t:Landroid/content/SharedPreferences;

.field private static u:Ljava/util/concurrent/atomic/AtomicInteger;

.field private static final v:Ljava/lang/Integer;

.field private static w:Ljava/util/concurrent/atomic/AtomicBoolean;


# direct methods
.method static constructor <clinit>()V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance v0, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-direct {v0}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b:Ljava/util/Map;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    const/4 v0, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    const/4 v1, 0x0

    const/4 v8, 0x5

    sput v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d:I

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string v2, ""

    const-string v2, ""

    const/4 v8, 0x7

    const-string v2, ""

    const-string v2, ""

    const/4 v8, 0x4

    sput-object v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->e:Ljava/lang/String;

    const/4 v8, 0x6

    sput-object v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->f:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/stat/b/b;->b()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    sput-object v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v8, 0x4

    sput-boolean v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->h:Z

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/4 v2, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    sput-boolean v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->i:Z

    const/4 v8, 0x0

    const/4 v7, 0x3

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->j:Landroid/os/Handler;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->k:Ljava/lang/Runnable;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x1

    sput-wide v3, Lcom/tencent/android/tpush/stat/StatServiceImpl;->l:J

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x1

    new-instance v5, Ljava/util/concurrent/CopyOnWriteArrayList;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {v5}, Ljava/util/concurrent/CopyOnWriteArrayList;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x3

    sput-object v5, Lcom/tencent/android/tpush/stat/StatServiceImpl;->m:Ljava/util/List;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-wide/16 v5, 0x320

    const-wide/16 v5, 0x320

    const/4 v8, 0x7

    const-wide/16 v5, 0x320

    const-wide/16 v5, 0x320

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    sput-wide v5, Lcom/tencent/android/tpush/stat/StatServiceImpl;->n:J

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v8, 0x5

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v8, 0x7

    sput-wide v5, Lcom/tencent/android/tpush/stat/StatServiceImpl;->o:J

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x6

    sput-wide v3, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a:J

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x2

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->q:Ljava/lang/String;

    const/4 v8, 0x5

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->r:Landroid/content/SharedPreferences;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->s:Landroid/content/SharedPreferences;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->t:Landroid/content/SharedPreferences;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    sput-boolean v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->storedList:Z

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x4

    new-instance v0, Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;-><init>(I)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->u:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v8, 0x4

    const/4 v0, 0x0

    const/4 v8, 0x4

    const/4 v0, 0x3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->v:Ljava/lang/Integer;

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x5

    new-instance v0, Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-direct {v0, v1}, Ljava/util/concurrent/atomic/AtomicBoolean;-><init>(Z)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x2

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->w:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v8, 0x0

    const/4 v7, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic a(J)J
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@is~-t~ oK@u.~@r~ti@ 1@v ~ f@l@c@o@@ @~o~/o~@m do~~n~4bi~b~ b~~~a@M~o ~~ @~ f@ y/@  ~@@~S @l  @s"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sput-wide p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->l:J

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-wide p0
.end method

.method static synthetic a(Ljava/lang/Runnable;)Ljava/lang/Runnable;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    sput-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->k:Ljava/lang/Runnable;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method static a()Lorg/json/JSONObject;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    new-instance v0, Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v1, Lorg/json/JSONObject;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x7

    sget-object v2, Lcom/tencent/android/tpush/stat/d;->b:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget v2, v2, Lcom/tencent/android/tpush/stat/d$a;->d:I
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string/jumbo v3, "v"

    const-string/jumbo v3, "v"

    const-string/jumbo v3, "v"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-eqz v2, :cond_0

    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    sget-object v2, Lcom/tencent/android/tpush/stat/d;->b:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget v2, v2, Lcom/tencent/android/tpush/stat/d$a;->a:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x1

    and-int/2addr v5, v4

    new-instance v1, Lorg/json/JSONObject;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x7

    sget-object v2, Lcom/tencent/android/tpush/stat/d;->a:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget v2, v2, Lcom/tencent/android/tpush/stat/d$a;->d:I

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v1, v3, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-object v2, Lcom/tencent/android/tpush/stat/d;->a:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    iget v2, v2, Lcom/tencent/android/tpush/stat/d$a;->a:I

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :catch_0
    move-exception v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget-object v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v2, v1}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-object v0
.end method

.method private static a(Landroid/app/Application;J)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz p0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/b/e;->b(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getHandler(Landroid/content/Context;)Landroid/os/Handler;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->j:Landroid/os/Handler;

    const/4 v4, 0x6

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance v0, Landroid/os/Handler;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    sput-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->j:Landroid/os/Handler;

    :cond_0
    const/4 v4, 0x3

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const/4 v4, 0x3

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v1, Lcom/tencent/android/tpush/stat/StatServiceImpl$6;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v1, p1, p2}, Lcom/tencent/android/tpush/stat/StatServiceImpl$6;-><init>(J)V

    const/4 v4, 0x2

    new-instance v2, Lcom/tencent/android/tpush/stat/StatServiceImpl$7;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v2, p1, p2}, Lcom/tencent/android/tpush/stat/StatServiceImpl$7;-><init>(J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {v2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Lcom/tencent/android/tpush/stat/c;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p0, v1}, Lcom/tencent/android/tpush/stat/lifecycle/MtaActivityLifeCycle;->registerActivityLifecycleCallbacks(Landroid/app/Application;Lcom/tencent/android/tpush/stat/lifecycle/a;)Ljava/lang/Boolean;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_2
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void

    :catchall_1
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    throw p0

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method

.method private static a(Landroid/content/Context;DJZ)V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result p5

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-nez p5, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    return-void

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-nez v3, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x0

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string p1, "Ttam g!xcter. tvnkicteaCeonktb uS(uoe)n dalohnca cnos Sl Beft"

    const-string/jumbo p1, "nusleTSnbtutfn!k (iloac gatc)Bntdanvr .roetoCe o cSce tae hxk"

    const/4 v7, 0x1

    const-string p1, "cn(ConBikttnrnf.!olS ctehegtkx) oa eou T otaSnre ecdvra lacbu"

    const-string p1, "The Context of StatService.trackBackground() can not be null!"

    const/4 v7, 0x1

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    return-void

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {v3}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getHandler(Landroid/content/Context;)Landroid/os/Handler;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz p0, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance p5, Lcom/tencent/android/tpush/stat/StatServiceImpl$5;

    move-object v0, p5

    move-object v0, p5

    move-object v0, p5

    move-object v0, p5

    move-wide v1, p1

    move-wide v4, p3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-direct/range {v0 .. v5}, Lcom/tencent/android/tpush/stat/StatServiceImpl$5;-><init>(DLandroid/content/Context;J)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {p0, p5}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    return-void
.end method

.method private static a(Landroid/content/Context;ILjava/lang/String;Ljava/lang/Throwable;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-static {p3}, Lcom/tencent/android/tpush/stat/b/b;->a(Ljava/lang/Throwable;)Lorg/json/JSONArray;

    move-result-object p3

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/Context;ILjava/lang/String;Lorg/json/JSONArray;)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method private static a(Landroid/content/Context;ILjava/lang/String;Lorg/json/JSONArray;)V
    .locals 10

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x2

    if-nez v0, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    return-void

    :cond_0
    const/4 v9, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-nez v2, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v8, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string p1, "auv  ban(eiEtenotbs eSCl!xTnl csCSmeenrhveocnohtr  tta.d )te"

    const-string/jumbo p1, "nshmSTda ntCebrcEaCe(vntout  aixte.th svt! lcenn Sooee nel)r"

    const/4 v9, 0x3

    const-string p1, "  nt.nutenshuC txla e(enfn nTbS!Stoce httrdsvoerCoc iea)Eavl"

    const-string p1, "The Context of StatService.sendCrashEvent() can not be null!"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    return-void

    :cond_1
    :try_start_0
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    new-instance v0, Lcom/tencent/android/tpush/stat/event/d;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x4

    const/4 v3, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v6

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    move v4, p1

    move v4, p1

    const/4 v9, 0x2

    move v4, p1

    move v4, p1

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    move-object v5, p3

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-direct/range {v1 .. v7}, Lcom/tencent/android/tpush/stat/event/d;-><init>(Landroid/content/Context;IILorg/json/JSONArray;J)V

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {v0, p2}, Lcom/tencent/android/tpush/stat/event/d;->a(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpush/stat/event/d;->a()Z

    move-result p0

    const/4 v9, 0x5

    const/4 v8, 0x5

    if-nez p0, :cond_2

    const/4 v9, 0x7

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-string/jumbo p1, "tnso n pa.kodio nftsnc"

    const-string/jumbo p1, "not contains sdk info."

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->c(Ljava/lang/Object;)V

    const/4 v9, 0x6

    const/4 v8, 0x5

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {p0, p3}, Lcom/tencent/android/tpush/stat/b/c;->c(Ljava/lang/Object;)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    return-void

    :cond_2
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    new-instance p0, Ljava/util/ArrayList;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-interface {p0, v0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Ljava/util/List;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x6

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    sget-object p1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {p1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x2

    return-void
.end method

.method static a(Landroid/content/Context;J)V
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x3

    new-instance v6, Lcom/tencent/android/tpush/stat/event/h;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    sget v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d:I

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a()Lorg/json/JSONObject;

    move-result-object v3

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-wide v4, p1

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct/range {v0 .. v5}, Lcom/tencent/android/tpush/stat/event/h;-><init>(Landroid/content/Context;ILorg/json/JSONObject;J)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-static {v6}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Lcom/tencent/android/tpush/stat/event/Event;)V

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    return-void
.end method

.method static a(Landroid/content/Context;JZ)V
    .locals 10

    :try_start_0
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string v1, "crntrdn:qFksodoc sgkoerutuTraaglB"

    const-string/jumbo v1, "u:gkoTsdtedFkltrcBnroagsournora c"

    const/4 v9, 0x3

    const-string/jumbo v1, "trackBackground lastForegroundTs:"

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x5

    sget-wide v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->o:J

    const/4 v9, 0x0

    const/4 v8, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x7

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpush/stat/b/c;->h(Ljava/lang/Object;)V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    sget-wide v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->o:J

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    cmp-long p0, v0, v2

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-lez p0, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    sget-wide v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->o:J

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    sub-long/2addr v0, v2

    const/4 v9, 0x2

    const/4 v8, 0x5

    sget-wide v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->n:J

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    sub-long/2addr v0, v2

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x4

    long-to-double v0, v0

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-wide v2, 0x408f400000000000L    # 1000.0

    const-wide v2, 0x408f400000000000L    # 1000.0

    const-wide v2, 0x408f400000000000L    # 1000.0

    const-wide v2, 0x408f400000000000L    # 1000.0

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    div-double/2addr v0, v2

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x3

    cmpg-double p0, v0, v2

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-gtz p0, :cond_0

    const/4 v9, 0x3

    const-wide v0, 0x3fb999999999999aL    # 0.1

    const-wide v0, 0x3fb999999999999aL    # 0.1

    const/4 v9, 0x2

    const-wide v0, 0x3fb999999999999aL    # 0.1

    const-wide v0, 0x3fb999999999999aL    # 0.1

    :cond_0
    move-wide v3, v0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    sget-object v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    move-wide v5, p1

    const/4 v9, 0x1

    const/4 v8, 0x7

    move v7, p3

    move v7, p3

    const/4 v9, 0x3

    move v7, p3

    move v7, p3

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static/range {v2 .. v7}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/Context;DJZ)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    sget-object p1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {p1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :cond_1
    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-wide/16 p0, -0x1

    const-wide/16 p0, -0x1

    const/4 v9, 0x3

    const-wide/16 p0, -0x1

    const-wide/16 p0, -0x1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    sput-wide p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->o:J

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    return-void
.end method

.method static synthetic a(Landroid/content/Context;Ljava/lang/String;JJJ)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-static/range {p0 .. p7}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Landroid/content/Context;Ljava/lang/String;JJJ)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method static a(Landroid/content/Context;Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v0, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x7

    shr-int/2addr v2, v1

    const/4 v3, 0x1

    invoke-static {p0, v0, v1, p1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/Context;ILjava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method static a(Landroid/content/SharedPreferences;)V
    .locals 9

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences;->getAll()Ljava/util/Map;

    move-result-object p0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x2

    if-eqz p0, :cond_0

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string/jumbo v2, "vsst eaeEdbocLl"

    const-string v2, "de oLbscaEevlnt"

    const/4 v8, 0x5

    const-string v2, "dnem LeEtcovsan"

    const-string/jumbo v2, "sendLocalEvent "

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-interface {p0}, Ljava/util/Map;->size()I

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    move v8, v7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/stat/b/c;->a(Ljava/lang/Object;)V

    :cond_0
    if-eqz p0, :cond_3

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-interface {p0}, Ljava/util/Map;->size()I

    move-result v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    if-lez v0, :cond_3

    const/4 v7, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v7, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    const/16 v1, 0xa

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    new-instance v2, Ljava/util/ArrayList;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-direct {v2, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-interface {p0}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object p0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-interface {p0}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-eqz v3, :cond_2

    const/4 v8, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x1

    check-cast v3, Ljava/util/Map$Entry;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    new-instance v4, Lorg/json/JSONObject;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    check-cast v5, Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-direct {v4, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string/jumbo v5, "umsro"

    const-string/jumbo v5, "tumrs"

    const/4 v8, 0x0

    const-string v5, "bsTrt"

    const-string/jumbo v5, "rtTms"

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-interface {v3}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v4, v5, v6}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v4}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-interface {v2, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    goto :goto_1

    :catchall_0
    :try_start_2
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v4

    const/4 v8, 0x6

    const/4 v7, 0x3

    invoke-interface {v2, v4}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :goto_1
    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-interface {v3}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-interface {v0, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v3

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-ne v3, v1, :cond_1

    const/4 v7, 0x7

    shl-int/2addr v8, v7

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Ljava/util/List;Ljava/util/List;)V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-interface {v0}, Ljava/util/List;->clear()V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    goto/16 :goto_0

    :cond_2
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Ljava/util/List;Ljava/util/List;)V

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-interface {v0}, Ljava/util/List;->clear()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    goto :goto_2

    :catchall_1
    move-exception p0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v8, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x6

    const-string/jumbo v2, "ovnesrult :dEperLeonc "

    const-string/jumbo v2, "re scnoprlLvoE: detner"

    const/4 v8, 0x7

    const-string/jumbo v2, "rnv:rstpaLdec  erlEeno"

    const-string/jumbo v2, "sendLocalEvent error: "

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v0, p0}, Lcom/tencent/android/tpush/stat/b/c;->f(Ljava/lang/Object;)V

    :cond_3
    :goto_2
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-void
.end method

.method private static a(Landroid/content/SharedPreferences;Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/SharedPreferences;",
            "Ljava/util/List<",
            "*>;)V"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez p0, :cond_0

    const/4 v5, 0x5

    return-void

    :cond_0
    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/4 v2, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-interface {p0, v1, v2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-lez v2, :cond_1

    const/4 v4, 0x1

    move v5, v4

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->e()S

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-gt v2, v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-interface {v0, v1, v2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {v0, v1}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_0

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-interface {v0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    sget-object p1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x2

    invoke-virtual {p1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_1
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-void
.end method

.method private static a(Lcom/tencent/android/tpush/stat/c;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->m:Ljava/util/List;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-interface {v0, p0}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method static a(Lcom/tencent/android/tpush/stat/event/Event;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/b;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/b;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpush/stat/b;->c()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v1, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    sget-boolean v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->storedList:Z

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/16 v2, 0x64

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->sendLocalMsg(Landroid/content/Context;I)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    xor-int/2addr v0, v1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    sput-boolean v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->storedList:Z

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Lcom/tencent/android/tpush/stat/event/Event;)V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-array v0, v1, [Lcom/tencent/android/tpush/stat/event/Event;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    aput-object p0, v0, v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Ljava/util/List;)V

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-void
.end method

.method static a(Ljava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tencent/android/tpush/stat/event/Event;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/b;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/b;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpush/stat/b;->c()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/f;->b(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/f;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v1, Lcom/tencent/android/tpush/stat/StatServiceImpl$15;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl$15;-><init>(Ljava/util/List;)V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, p0, v1}, Lcom/tencent/android/tpush/stat/f;->b(Ljava/util/List;Lcom/tencent/android/tpush/stat/e;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Ljava/util/List;)V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    return-void
.end method

.method private static a(Ljava/util/List;Landroid/content/SharedPreferences;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "*>;",
            "Landroid/content/SharedPreferences;",
            ")V"
        }
    .end annotation

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {p1, v0, v1}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    sget-object p1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_1
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method

.method static a(Ljava/util/List;Ljava/util/List;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz p0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v3, 0x6

    if-eqz p1, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {p1}, Ljava/util/List;->size()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/f;->b(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/f;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v1, Lcom/tencent/android/tpush/stat/StatServiceImpl$2;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl$2;-><init>(Ljava/util/List;)V

    const/4 v3, 0x7

    invoke-virtual {v0, p1, v1}, Lcom/tencent/android/tpush/stat/f;->b(Ljava/util/List;Lcom/tencent/android/tpush/stat/e;)V

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method static a(Landroid/content/Context;)Z
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    sget-object v0, Lcom/tencent/android/tpush/stat/d;->c:Ljava/lang/String;

    const-wide/16 v1, 0x0

    const/4 v7, 0x1

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {p0, v0, v1, v2}, Lcom/tencent/android/tpush/stat/b/d;->a(Landroid/content/Context;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-string p0, "062q."

    const/4 v7, 0x5

    const-string p0, "0..q6"

    const-string p0, "2.0.6"

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/b/b;->b(Ljava/lang/String;)J

    move-result-wide v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    cmp-long p0, v2, v0

    const/4 v7, 0x1

    if-gtz p0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string v5, "eds sToAeotrsren: ri blcnrfiaiM  su"

    const-string/jumbo v5, "irs aMtrldA: ebTfsnesuieso oc  inrr"

    const/4 v7, 0x1

    const-string v5, "MTA is disable for current version:"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v4, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string v2, " uimvakoe:n,rwps"

    const-string v2, ",wakeup version:"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v4, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 p0, 0x0

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    const/4 p0, 0x1

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/d;->b(Z)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    return p0
.end method

.method static a(Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    if-eqz p0, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-nez p0, :cond_0

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    const/4 p0, 0x0

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    return p0

    :cond_1
    :goto_0
    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    const/4 p0, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x2

    return p0
.end method

.method static synthetic a(Z)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    sput-boolean p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->i:Z

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p0
.end method

.method static b(Landroid/content/Context;J)I
    .locals 9

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    sget-wide v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a:J

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x5

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    cmp-long v2, v2, v4

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    const-string v3, "R__Ao_TEYM_NXTNDEIm"

    const-string v3, "DATmXN_TER_M_EITYN_"

    const/4 v8, 0x1

    const-string v3, "YRAANbE_M_ETDTN_XIT"

    const-string v3, "_INTER_MTA_NEXT_DAY"

    const/4 v8, 0x7

    const/4 v7, 0x7

    if-nez v2, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    sget-object v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v8, 0x6

    invoke-static {v2, v3, v4, v5}, Lcom/tencent/android/tpush/stat/b/d;->a(Landroid/content/Context;Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    sput-wide v4, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a:J

    :cond_0
    const/4 v8, 0x2

    const/4 v7, 0x3

    sget v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d:I

    const/4 v4, 0x1

    const/4 v8, 0x4

    const/4 v4, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-nez v2, :cond_1

    const/4 v7, 0x6

    xor-int/2addr v8, v7

    goto :goto_0

    :cond_1
    const/4 v8, 0x3

    sget-wide v5, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a:J

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    cmp-long v0, v0, v5

    const/4 v8, 0x4

    const/4 v7, 0x0

    if-ltz v0, :cond_2

    const/4 v7, 0x2

    goto :goto_0

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x3

    const/4 v4, 0x0

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-eqz v4, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/stat/b/b;->a()I

    move-result v0

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    sput v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d:I

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/stat/b/b;->c()J

    move-result-wide v0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    sput-wide v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a:J

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    sget-wide v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a:J

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {v0, v3, v1, v2}, Lcom/tencent/android/tpush/stat/b/d;->b(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v8, 0x4

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/Context;J)V

    :cond_3
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    sget p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d:I

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    return p0
.end method

.method static synthetic b(J)J
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    sput-wide p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->o:J

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-wide p0
.end method

.method static synthetic b(Landroid/content/SharedPreferences;)Landroid/content/SharedPreferences;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x4

    sput-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->r:Landroid/content/SharedPreferences;

    const/4 v1, 0x5

    const/4 v0, 0x1

    return-object p0
.end method

.method static synthetic b(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x5

    sput-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->e:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method static declared-synchronized b()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const/4 v2, 0x2

    move v3, v2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->r:Landroid/content/SharedPreferences;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->r:Landroid/content/SharedPreferences;

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/SharedPreferences;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->s:Landroid/content/SharedPreferences;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v1, :cond_1

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->s:Landroid/content/SharedPreferences;

    const/4 v2, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/SharedPreferences;)V

    :cond_1
    const/4 v3, 0x3

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->t:Landroid/content/SharedPreferences;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v1, :cond_2

    const/4 v3, 0x7

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->t:Landroid/content/SharedPreferences;

    const/4 v3, 0x1

    invoke-static {v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/SharedPreferences;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-void

    :catchall_0
    move-exception v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    throw v1
.end method

.method private static b(Landroid/content/Context;Ljava/lang/String;JJJ)V
    .locals 11

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    move-object v0, p1

    if-nez v0, :cond_0

    return-void

    :cond_0
    new-instance v1, Ljava/lang/String;

    invoke-direct {v1, p1}, Ljava/lang/String;-><init>(Ljava/lang/String;)V

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getHandler(Landroid/content/Context;)Landroid/os/Handler;

    move-result-object v0

    if-eqz v0, :cond_1

    sget-object v9, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    new-instance v10, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;

    move-object v0, v10

    move-object v0, v10

    move-object v0, v10

    move-object v0, v10

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-wide v3, p2

    move-wide v5, p4

    move-wide/from16 v7, p6

    invoke-direct/range {v0 .. v8}, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;-><init>(Ljava/lang/String;Landroid/content/Context;JJJ)V

    invoke-virtual {v9, v10}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_1
    return-void
.end method

.method static b(Lcom/tencent/android/tpush/stat/event/Event;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/f;->b(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/f;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v1, Lcom/tencent/android/tpush/stat/StatServiceImpl$16;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl$16;-><init>(Lcom/tencent/android/tpush/stat/event/Event;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, p0, v1}, Lcom/tencent/android/tpush/stat/f;->a(Lcom/tencent/android/tpush/stat/event/Event;Lcom/tencent/android/tpush/stat/e;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method static declared-synchronized b(Ljava/util/List;)V
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "*>;)V"
        }
    .end annotation

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const/4 v6, 0x4

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    monitor-enter v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz p0, :cond_2

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x2

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->r:Landroid/content/SharedPreferences;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    if-eqz v1, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->s:Landroid/content/SharedPreferences;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-eqz v1, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->t:Landroid/content/SharedPreferences;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eqz v1, :cond_2

    const/4 v1, 0x1

    move v6, v1

    move v5, v1

    move v5, v1

    const/4 v6, 0x1

    sput-boolean v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->storedList:Z

    const/4 v6, 0x6

    const/4 v5, 0x3

    sget-object v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string/jumbo v4, "zenottur vss: eoi"

    const-string v4, "eveooternz s:sit "

    const/4 v6, 0x1

    const-string v4, "e zeettp:sr ieons"

    const-string/jumbo v4, "store event size:"

    const/4 v6, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v2, v3}, Lcom/tencent/android/tpush/stat/b/c;->h(Ljava/lang/Object;)V

    const/4 v6, 0x7

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->e(Ljava/util/List;)I

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eq v2, v1, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x3

    const/4 v1, 0x2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eq v2, v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->s:Landroid/content/SharedPreferences;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {p0, v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Ljava/util/List;Landroid/content/SharedPreferences;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->t:Landroid/content/SharedPreferences;

    const/4 v5, 0x7

    move v6, v5

    invoke-static {p0, v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Ljava/util/List;Landroid/content/SharedPreferences;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x0

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->r:Landroid/content/SharedPreferences;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {p0, v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Ljava/util/List;Landroid/content/SharedPreferences;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x0

    goto :goto_0

    :catchall_1
    move-exception p0

    const/4 v6, 0x6

    monitor-exit v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    throw p0

    :cond_2
    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    monitor-exit v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    return-void
.end method

.method private static b(Ljava/util/List;Landroid/content/SharedPreferences;)V
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "*>;",
            "Landroid/content/SharedPreferences;",
            ")V"
        }
    .end annotation

    :try_start_0
    const/4 v1, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {p1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-interface {p1, v0}, Landroid/content/SharedPreferences$Editor;->remove(Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-interface {p1}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    sget-object p1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x7

    invoke-virtual {p1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_1
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method static synthetic b(Z)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    sput-boolean p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->h:Z

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x1

    return p0
.end method

.method static synthetic c()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x6

    return-object v0
.end method

.method static synthetic c(Landroid/content/SharedPreferences;)Landroid/content/SharedPreferences;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    sput-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->s:Landroid/content/SharedPreferences;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic c(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x2

    sput-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->f:Ljava/lang/String;

    const/4 v1, 0x0

    return-object p0
.end method

.method static declared-synchronized c(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "*>;)V"
        }
    .end annotation

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const/4 v5, 0x0

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    monitor-enter v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz p0, :cond_2

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->r:Landroid/content/SharedPreferences;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-eqz v1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->s:Landroid/content/SharedPreferences;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->t:Landroid/content/SharedPreferences;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-string/jumbo v3, "s n:eedtqtvize bee"

    const-string/jumbo v3, "ie debe:n tetevzse"

    const/4 v5, 0x7

    const-string/jumbo v3, "tlszeet is:veeen e"

    const-string v3, "delete event size:"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Lcom/tencent/android/tpush/stat/b/c;->h(Ljava/lang/Object;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->e(Ljava/util/List;)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-eq v1, v2, :cond_1

    const/4 v4, 0x2

    xor-int/2addr v5, v4

    const/4 v2, 0x2

    move v5, v2

    const/4 v4, 0x3

    move v5, v4

    if-eq v1, v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->s:Landroid/content/SharedPreferences;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p0, v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Ljava/util/List;Landroid/content/SharedPreferences;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x1

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->t:Landroid/content/SharedPreferences;

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {p0, v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Ljava/util/List;Landroid/content/SharedPreferences;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    move v5, v4

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->r:Landroid/content/SharedPreferences;

    const/4 v4, 0x0

    move v5, v4

    invoke-static {p0, v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Ljava/util/List;Landroid/content/SharedPreferences;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :catchall_1
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    throw p0

    :cond_2
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-void
.end method

.method public static checkAppLunch(Landroid/content/Context;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    instance-of v0, p0, Landroid/app/Application;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_0

    const/4 v1, 0x3

    xor-int/2addr v2, v1

    check-cast p0, Landroid/app/Application;

    const/4 v1, 0x1

    move v2, v1

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x6

    instance-of v0, p0, Landroid/app/Activity;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    check-cast p0, Landroid/app/Activity;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :cond_1
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast p0, Landroid/app/Application;

    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/Util;->isMainProcess(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-eqz p0, :cond_3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    if-eqz v0, :cond_3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->w:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->get()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    if-eqz v0, :cond_2

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x3

    new-instance v0, Lcom/tencent/android/tpush/stat/StatServiceImpl$8;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-direct {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl$8;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/stat/lifecycle/MtaActivityLifeCycle;->registerActivityLifecycleCallbacks(Landroid/app/Application;Lcom/tencent/android/tpush/stat/lifecycle/a;)Ljava/lang/Boolean;

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->w:Ljava/util/concurrent/atomic/AtomicBoolean;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Ljava/util/concurrent/atomic/AtomicBoolean;->set(Z)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    goto :goto_1

    :catchall_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string/jumbo p0, "tast"

    const-string/jumbo p0, "ttas"

    const/4 v2, 0x3

    const-string/jumbo p0, "satt"

    const-string/jumbo p0, "stat"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-string/jumbo v0, "rcnmecfoheppeptdcAuen Luxhuk"

    const-string v0, "Lnnedhukoc rfApeethuexcppcu "

    const/4 v2, 0x6

    const-string/jumbo v0, "rLc ouptcp ehfucehnAdeeoxnkp"

    const-string/jumbo v0, "unexpected for checkAppLunch"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_1
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method public static commitEvents(Landroid/content/Context;I)Z
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    return v1

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->b()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v0, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo v3, "tmebebvmxop m=rNmnciE,st"

    const-string v3, "bvNtnu ptmcEmemri=o,xmes"

    const/4 v5, 0x7

    const-string/jumbo v3, "mxsb=,uetEtmmNnaeim ruvc"

    const-string v3, "commitEvents, maxNumber="

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v0, v2}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Object;)V

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez p0, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo p1, "tcb t TpcqEtlo(mivesnne cnuaSav ! Stfeme oeCn)orxelt.ntoi "

    const-string/jumbo p1, "n fvitvtq(cmnt lea a !nn.oCoxttitoerees StETol  ce)ebnumSc"

    const/4 v5, 0x7

    const-string/jumbo p1, "xen !aieqlvtcno ocl Sett Tnrnt)Eenf(S vi mstueot htce.obCa"

    const-string p1, "The Context of StatService.commitEvents() can not be null!"

    const/4 v5, 0x5

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    return v1

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v0, -0x1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-lt p1, v0, :cond_6

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-nez p1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/b;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/b;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpush/stat/b;->c()Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-nez p1, :cond_4

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    return v1

    :cond_4
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getHandler(Landroid/content/Context;)Landroid/os/Handler;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz p0, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v4, 0x4

    move v5, v4

    new-instance p1, Lcom/tencent/android/tpush/stat/StatServiceImpl$13;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {p1}, Lcom/tencent/android/tpush/stat/StatServiceImpl$13;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v5, 0x4

    const/4 p0, 0x6

    const/4 v5, 0x6

    const/4 p0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    return p0

    :cond_5
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    return v1

    :cond_6
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string p1, "a-savlorxtc g  mit1rienu fSo.)E etee0sedn bmrhbahbu vmoer  cT(Nhem.Stoti s"

    const/4 v5, 0x1

    const-string p1, "Nnsfvou rah i m shSottbier u( rv)mehtEgs  rc-bTtoemgeS.t1cad.oe0aixebe mnl"

    const-string p1, "The maxNumber of StatService.commitEvents() should be -1 or bigger than 0."

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    return v1
.end method

.method static synthetic d(Landroid/content/SharedPreferences;)Landroid/content/SharedPreferences;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    sput-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->t:Landroid/content/SharedPreferences;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic d()Lcom/tencent/android/tpush/stat/b/c;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-object v0
.end method

.method static declared-synchronized d(Ljava/util/List;)V
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "*>;)V"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const/4 v5, 0x1

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    monitor-enter v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz p0, :cond_2

    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->r:Landroid/content/SharedPreferences;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->s:Landroid/content/SharedPreferences;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    if-eqz v1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->t:Landroid/content/SharedPreferences;

    const/4 v5, 0x2

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string v3, "ee mtp:dzn iveseat"

    const/4 v5, 0x0

    const-string/jumbo v3, "te muip:snetvaed e"

    const-string/jumbo v3, "update event size:"

    const/4 v4, 0x4

    xor-int/2addr v5, v4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Lcom/tencent/android/tpush/stat/b/c;->h(Ljava/lang/Object;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->e(Ljava/util/List;)I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eq v1, v2, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v2, 0x2

    move v5, v2

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eq v1, v2, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->s:Landroid/content/SharedPreferences;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/SharedPreferences;Ljava/util/List;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->t:Landroid/content/SharedPreferences;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/SharedPreferences;Ljava/util/List;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->r:Landroid/content/SharedPreferences;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/SharedPreferences;Ljava/util/List;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :catchall_1
    move-exception p0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    throw p0

    :cond_2
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    return-void
.end method

.method private static e(Ljava/util/List;)I
    .locals 7
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "*>;)I"
        }
    .end annotation

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v0, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz p0, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    if-nez v1, :cond_5

    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-interface {p0, v0}, Ljava/util/List;->get(I)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x0

    instance-of v1, p0, Lcom/tencent/android/tpush/stat/event/Event;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v2, 0x2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/4 v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz v1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x4

    instance-of v1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;

    const/4 v6, 0x3

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x5

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string/jumbo v1, "oMQnoasnt ceeteEeTatisTv ntvna "

    const-string v1, "aitnoecET aaMntTe ven  tntsevsQ"

    const/4 v6, 0x2

    const-string/jumbo v1, "n etsbtMeinTtn QTavt Eeavcst ne"

    const-string v1, "a stat instance MQTTEvent event"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/android/tpush/stat/b/c;->d(Ljava/lang/Object;)V

    const/4 v5, 0x6

    xor-int/2addr v6, v5

    return v3

    :cond_0
    const/4 v6, 0x6

    instance-of p0, p0, Lcom/tencent/android/tpush/stat/event/c;

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz p0, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v1, " ttnonuecatiueatvmsc  nbt sa"

    const-string v1, "aemc b estaittnuot ancs ntve"

    const/4 v6, 0x0

    const-string/jumbo v1, "s ecninpaemtoauttst  vnate s"

    const-string v1, "a stat instance custom event"

    invoke-virtual {p0, v1}, Lcom/tencent/android/tpush/stat/b/c;->d(Ljava/lang/Object;)V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    return v2

    :cond_1
    const/4 v6, 0x4

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string v1, "Eouete nqraEettoori rv nhecshr rnt"

    const-string v1, " viehEurtnr troaoreEtte orhns econ"

    const/4 v6, 0x2

    const-string/jumbo v1, "tvs ir EnreretteoronhhnarsrcooeEt "

    const-string/jumbo v1, "other instance ErrorEvent or other"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {p0, v1}, Lcom/tencent/android/tpush/stat/b/c;->d(Ljava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    return v0

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x7

    new-instance v1, Lorg/json/JSONObject;

    const/4 v5, 0x4

    const/4 v6, 0x3

    check-cast p0, Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-direct {v1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo p0, "mgsmI"

    const-string p0, "gmpsI"

    const-string p0, "dmsgo"

    const-string/jumbo p0, "msgId"

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x2

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v1, p0, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    if-eqz p0, :cond_3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v4

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-lez v4, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x5

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v6, 0x0

    const/4 v5, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x4

    const-string/jumbo v4, "st :abamne  vtI trgi snqgdt"

    const-string v4, "Inv g dtqteirmnss ga as t:t"

    const/4 v6, 0x3

    const-string v4, "ag esguttd  I vts:s tmneran"

    const-string v4, "a stat string event msgId: "

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x5

    invoke-virtual {v1, p0}, Lcom/tencent/android/tpush/stat/b/c;->d(Ljava/lang/Object;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x6

    return v3

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string/jumbo p0, "ntcsoEmptvu"

    const-string/jumbo p0, "tvsutoEncms"

    const/4 v6, 0x2

    const-string/jumbo p0, "tstumceoqvE"

    const-string p0, "customEvent"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v1, p0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-eqz p0, :cond_4

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x5

    move v6, v5

    const-string/jumbo v1, "uestgEm  visotctsnn"

    const-string v1, "gosmtunitntmEe  cvs"

    const-string v1, " tomcrsutsnEnmigt v"

    const-string v1, " string customEvent"

    const/4 v6, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0, v1}, Lcom/tencent/android/tpush/stat/b/c;->d(Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    return v2

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string/jumbo v1, "r toothe onri"

    const-string/jumbo v1, "r esortn toih"

    const/4 v6, 0x6

    const-string/jumbo v1, "rhis b entort"

    const-string/jumbo v1, "other string "

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p0, v1}, Lcom/tencent/android/tpush/stat/b/c;->d(Ljava/lang/Object;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    return v0

    :catchall_0
    move-exception p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v6, 0x6

    const/4 v5, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v3, "tirsebrnortinei sehgud "

    const-string v3, "dhsvrtunise  rngeieroti"

    const-string v3, "distinguish event error"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    invoke-virtual {v1, p0}, Lcom/tencent/android/tpush/stat/b/c;->d(Ljava/lang/Object;)V

    :cond_5
    const/4 v6, 0x7

    return v0
.end method

.method static synthetic e()Ljava/util/concurrent/atomic/AtomicInteger;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->u:Ljava/util/concurrent/atomic/AtomicInteger;

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic f()Ljava/lang/Integer;
    .locals 3

    const/4 v2, 0x6

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->v:Ljava/lang/Integer;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic g()Ljava/util/Map;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b:Ljava/util/Map;

    const/4 v2, 0x7

    return-object v0
.end method

.method public static getContext(Landroid/content/Context;)Landroid/content/Context;
    .locals 2

    const/4 v0, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-eqz p0, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-object p0

    :cond_0
    const/4 v1, 0x7

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-object p0
.end method

.method public static getHandler(Landroid/content/Context;)Landroid/os/Handler;
    .locals 4

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const/4 v3, 0x3

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const/4 v3, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v1, :cond_0

    :try_start_1
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->init(Landroid/content/Context;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_2
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v1, p0}, Lcom/tencent/android/tpush/stat/b/c;->a(Ljava/lang/Throwable;)V

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/d;->b(Z)V

    :cond_0
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    goto :goto_1

    :catchall_1
    move-exception p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    monitor-exit v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v3, 0x5

    throw p0

    :cond_1
    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x2

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object p0
.end method

.method static synthetic h()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->e:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-object v0
.end method

.method static synthetic i()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->f:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public static inerTrackBeginPage(Landroid/content/Context;Ljava/lang/String;J)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x3

    return-void

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-direct {v0, p1}, Ljava/lang/String;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getHandler(Landroid/content/Context;)Landroid/os/Handler;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-eqz p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object p1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v1, Lcom/tencent/android/tpush/stat/StatServiceImpl$3;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {v1, v0, p0, p2, p3}, Lcom/tencent/android/tpush/stat/StatServiceImpl$3;-><init>(Ljava/lang/String;Landroid/content/Context;J)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p1, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_1
    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public static declared-synchronized init(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const-class v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    monitor-enter v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    if-nez p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v3, 0x4

    const/4 v3, 0x2

    return-void

    :cond_0
    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->checkAppLunch(Landroid/content/Context;)V

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-nez v1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/Context;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez v1, :cond_1

    const/4 v3, 0x0

    const/4 v4, 0x1

    monitor-exit v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-void

    :cond_1
    :try_start_1
    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    sput-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    new-instance v1, Landroid/os/HandlerThread;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v2, "XpgauS"

    const-string/jumbo v2, "uXagSt"

    const/4 v4, 0x6

    const-string/jumbo v2, "taqXgt"

    const-string v2, "XgStat"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {v1, v2}, Landroid/os/HandlerThread;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/Thread;->start()V

    const/4 v4, 0x3

    new-instance v2, Landroid/os/Handler;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1}, Landroid/os/HandlerThread;->getLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v2, v1}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    sput-object v2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    sget-object v1, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    new-instance v2, Lcom/tencent/android/tpush/stat/StatServiceImpl$1;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v2, p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl$1;-><init>(Landroid/content/Context;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :cond_2
    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    return-void

    :catchall_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v3, 0x5

    shl-int/2addr v4, v3

    throw p0
.end method

.method public static initAutoStats(Landroid/content/Context;J)V
    .locals 3

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    instance-of v0, p0, Landroid/app/Application;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    check-cast p0, Landroid/app/Application;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    instance-of v0, p0, Landroid/app/Activity;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    check-cast p0, Landroid/app/Activity;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/app/Activity;->getApplication()Landroid/app/Application;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x5

    goto :goto_0

    :cond_1
    :try_start_1
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    check-cast p0, Landroid/app/Application;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_2
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 p0, 0x0

    and-int/2addr v2, p0

    :goto_0
    const/4 v1, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz p0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/app/Application;J)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_1

    :catchall_1
    move-exception p0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_2
    :goto_1
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method static synthetic j()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-boolean v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->h:Z

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method static synthetic k()Ljava/lang/Runnable;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->k:Ljava/lang/Runnable;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method static synthetic l()Landroid/os/Handler;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->j:Landroid/os/Handler;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method static synthetic m()Ljava/util/List;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->m:Ljava/util/List;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic n()Z
    .locals 3

    const/4 v1, 0x5

    const/4 v2, 0x3

    sget-boolean v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->i:Z

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    return v0
.end method

.method static synthetic o()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-wide v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->n:J

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-wide v0
.end method

.method public static reportEvent(Landroid/content/Context;Lcom/tencent/android/tpush/stat/event/Event;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    return-void

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->init(Landroid/content/Context;)V

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getHandler(Landroid/content/Context;)Landroid/os/Handler;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    if-eqz p0, :cond_2

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lcom/tencent/android/tpush/stat/StatServiceImpl$9;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0, p1}, Lcom/tencent/android/tpush/stat/StatServiceImpl$9;-><init>(Lcom/tencent/android/tpush/stat/event/Event;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public static reportXGEvent(Landroid/content/Context;Lcom/tencent/android/tpush/stat/event/Event;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string/jumbo p0, "stat"

    const-string/jumbo p0, "tast"

    const/4 v2, 0x4

    const-string/jumbo p0, "stta"

    const-string/jumbo p0, "stat"

    const/4 v1, 0x1

    and-int/2addr v2, v1

    const-string/jumbo p1, "tpsavicailssestb ee "

    const-string/jumbo p1, "tsavciipedsae tbls e"

    const/4 v2, 0x5

    const-string/jumbo p1, "tsbmeevaec laiitrdss"

    const-string p1, "disable stat service"

    const/4 v2, 0x4

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-void

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-nez p0, :cond_1

    const/4 v1, 0x3

    and-int/2addr v2, v1

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string p1, " rnloonst c!  a tvvTieaSctfho tttElqbeoe meCnnnk(extC.aSeutcru"

    const-string/jumbo p1, "rexcmbvuqeC nnctSs.etaeeac(f ailtnuEtnC ktotrh lve) o otTnt S!"

    const/4 v2, 0x7

    const-string p1, " nCorbesne.euetanh Sv(nticbc)  kTvtor !Ec teoCS luaoletttafxmn"

    const-string p1, "The Context of StatService.trackCustomEvent() can not be null!"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-void

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getHandler(Landroid/content/Context;)Landroid/os/Handler;

    move-result-object p0

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    if-eqz p0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance v0, Lcom/tencent/android/tpush/stat/StatServiceImpl$10;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0, p1}, Lcom/tencent/android/tpush/stat/StatServiceImpl$10;-><init>(Lcom/tencent/android/tpush/stat/event/Event;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-virtual {p0, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-void
.end method

.method public static send3rdCaughtException(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    const/16 v0, 0x1e

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0, v0, p1, p2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/Context;ILjava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public static sendLocalMsg(Landroid/content/Context;I)Z
    .locals 6

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    return v1

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->b()Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v3, "t=eonsuemi,aumtscxErmmN "

    const-string v3, "=EsNmxonatmcei,tmmuv esr"

    const/4 v5, 0x4

    const-string/jumbo v3, "tesnmucpvbN=amio,x erEmm"

    const-string v3, "commitEvents, maxNumber="

    const/4 v5, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v2}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Object;)V

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-nez p0, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string p1, "EtamTvctn otbmt nhs!ontaeoenm Ce)elu.t torS f(le enxiv icc"

    const/4 v5, 0x3

    const-string p1, "Tlt(lt.aqrt!efoctu c) CvtSax em in nnbo nStvcnoesee eihmEo"

    const-string p1, "The Context of StatService.commitEvents() can not be null!"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    return v1

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v0, -0x1

    move v5, v0

    const/4 v4, 0x3

    move v5, v4

    if-lt p1, v0, :cond_6

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-nez p1, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/b;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/b;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpush/stat/b;->c()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-nez v0, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    return v1

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v3, "=lsdsmMxgnoN bac,smruoeL"

    const-string v3, "ega odn=ex,LcuolmrssmNbM"

    const/4 v5, 0x5

    const-string/jumbo v3, "sendLocalMsg, maxNumber="

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Object;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getHandler(Landroid/content/Context;)Landroid/os/Handler;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz p0, :cond_5

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance p1, Lcom/tencent/android/tpush/stat/StatServiceImpl$14;

    const/4 v5, 0x2

    invoke-direct {p1}, Lcom/tencent/android/tpush/stat/StatServiceImpl$14;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0, p1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 p0, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    return p0

    :cond_5
    const/4 v5, 0x3

    const/4 v4, 0x4

    return v1

    :cond_6
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string p1, "etmm. b rlm1ervahohgoab- ncNufiS Tmgoeme  Ses tE ixihve( s) carun.ed0ottbr"

    const-string p1, " xatSb cvie- me)Sasme.tmetro oEied1eNtbn0r(lv roehsh noumi a. ugrTgfb  chb"

    const/4 v5, 0x0

    const-string p1, "caSrosgxbmeo onbu.  m(rtc m-SgN eetsiedut Taem.tEra)eioevfvib1n hrt  loh0h"

    const-string p1, "The maxNumber of StatService.commitEvents() should be -1 or bigger than 0."

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    return v1
.end method

.method public static sendTryCatchException(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p0, v0, p1, p2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/Context;ILjava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public static setContext(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-eqz p0, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    sput-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->p:Landroid/content/Context;

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public static setCrashMatchString(Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x5

    const/4 v1, 0x1

    sput-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->q:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method public static setupExceptionHandler(Landroid/content/Context;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/a;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/a;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/a;->a()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    return-void
.end method

.method public static trackBeginPage(Landroid/content/Context;Ljava/lang/String;J)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz p0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz p1, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    goto :goto_0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p0, p1, p2, p3}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->inerTrackBeginPage(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v1, 0x5

    move v2, v1

    return-void

    :cond_2
    :goto_0
    const/4 v2, 0x0

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    const-string p1, "ep tybtea lneleoe xtnnoftepoB bng.atkcamaThSaePrigrvm (rSN io ncecu ! ot etrageC)"

    const-string p1, "The Context or pageName of StatService.trackBeginPage() can not be null or empty!"

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method public static trackCustomKVEvent(Landroid/content/Context;Ljava/lang/String;Ljava/util/Properties;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez p0, :cond_1

    const/4 v2, 0x4

    move v3, v2

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo p1, "o tlb uEttuk !e(moetCxeo tenoet ct.anl)SirunccSavvnsrh eCT afn"

    const-string p1, "The Context of StatService.trackCustomEvent() can not be null!"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    if-eqz v0, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string p1, "e nT ru e.th  etoaSeCvctu._nnceEp ee)uftotktbvvnmsitaloid rS trc nmoyel("

    const/4 v3, 0x3

    const-string/jumbo p1, "oytSmCvp.clct. nTekt a_tmnp(eoene n lteshvuno rSbevt)ree  o  rEiadttfaui"

    const-string p1, "The event_id of StatService.trackCustomEvent() can not be null or empty."

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-void

    :cond_2
    const/4 v3, 0x6

    new-instance v0, Lcom/tencent/android/tpush/stat/event/c$a;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0, p1, v1, p2}, Lcom/tencent/android/tpush/stat/event/c$a;-><init>(Ljava/lang/String;[Ljava/lang/String;Ljava/util/Properties;)V

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getHandler(Landroid/content/Context;)Landroid/os/Handler;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-eqz p2, :cond_3

    const/4 v3, 0x2

    sget-object p2, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/stat/StatServiceImpl$12;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v1, p0, p1, v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl$12;-><init>(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/stat/event/c$a;)V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p2, v1}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_3
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    return-void
.end method

.method public static trackEndPage(Landroid/content/Context;Ljava/lang/String;J)V
    .locals 11

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x2

    if-nez v0, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    return-void

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-eqz v1, :cond_2

    const/4 v9, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x2

    if-eqz p1, :cond_2

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v10, 0x7

    const/4 v9, 0x5

    if-nez p0, :cond_1

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x0

    goto :goto_0

    :cond_1
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v10, 0x3

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x1

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x1

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-wide v3, p2

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Landroid/content/Context;Ljava/lang/String;JJJ)V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    return-void

    :cond_2
    :goto_0
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x3

    const-string p1, "P ucmlxnqee!oetoSNaogrebCt)a pf natnel(Tt r  a tr.epooartScn mpdenteagevhkiE cy"

    const-string/jumbo p1, "to)aEo.p onTN ttr ! mce  Caeeatamykgrcx ncnfotdr ( valeepgpePSeheernbnu itoSatl"

    const/4 v10, 0x3

    const-string p1, "The Context or pageName of StatService.trackEndPage() can not be null or empty!"

    const/4 v10, 0x2

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x2

    return-void
.end method

.method public static trackEndPage(Landroid/content/Context;Ljava/lang/String;JJJ)V
    .locals 9

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result v0

    if-nez v0, :cond_0

    return-void

    :cond_0
    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v1

    if-eqz v1, :cond_2

    if-eqz p1, :cond_2

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v0

    if-nez v0, :cond_1

    goto :goto_0

    :cond_1
    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-wide v3, p2

    move-wide v5, p4

    move-wide v7, p6

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Landroid/content/Context;Ljava/lang/String;JJJ)V

    return-void

    :cond_2
    :goto_0
    sget-object v0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const-string/jumbo v1, "n seetEtTatd ct(eyhot  rtoa.qri uCopm rnefo cSoSleaNb) r nc!exeevPnnaelgt ma gp"

    const-string/jumbo v1, "tgyca eeql nr  ataeupS rNSaoorne TgbnreviaetmEcxndm !cttt eP f t.a(e)oholp oCne"

    const-string/jumbo v1, "tdnmr!aeeobpSetE xa(nS lyrocNnftmtr)opmigea Cle e  u t Ttak Peohne .tve canagor"

    const-string v1, "The Context or pageName of StatService.trackEndPage() can not be null or empty!"

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    return-void
.end method

.method public static trackLaunchEvent(Landroid/content/Context;IIJ)V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result v0

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-nez v0, :cond_0

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    return-void

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getContext(Landroid/content/Context;)Landroid/content/Context;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-nez v2, :cond_1

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string/jumbo p1, "n)beotnsnkiCfuolc vhe aatts(reStttn Setcet ! nrxclov. CTmE aeo"

    const-string p1, "eSsTrtoal teC t!nuolhcratCneabSmecs t(tf)n iev nEo evtun .kxtc"

    const/4 v8, 0x4

    const-string p1, "The Context of StatService.trackCustomEvent() can not be null!"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    return-void

    :cond_1
    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {v2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->getHandler(Landroid/content/Context;)Landroid/os/Handler;

    move-result-object p0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-eqz p0, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    sget-object p0, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c:Landroid/os/Handler;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    new-instance v0, Lcom/tencent/android/tpush/stat/StatServiceImpl$11;

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    move v3, p1

    move v3, p1

    move v3, p1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    move v4, p2

    const/4 v8, 0x6

    move v4, p2

    move v4, p2

    move-wide v5, p3

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct/range {v1 .. v6}, Lcom/tencent/android/tpush/stat/StatServiceImpl$11;-><init>(Landroid/content/Context;IIJ)V

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {p0, v0}, Landroid/os/Handler;->post(Ljava/lang/Runnable;)Z

    :cond_2
    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    return-void
.end method
