.class public Lcom/tencent/android/tpush/stat/event/c;
.super Lcom/tencent/android/tpush/stat/event/Event;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/stat/event/c$a;
    }
.end annotation


# instance fields
.field protected a:Lcom/tencent/android/tpush/stat/event/c$a;

.field protected b:J


# direct methods
.method public constructor <init>(Landroid/content/Context;ILjava/lang/String;JJ)V
    .locals 2

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2, p4, p5}, Lcom/tencent/android/tpush/stat/event/Event;-><init>(Landroid/content/Context;IJ)V

    const/4 v1, 0x5

    new-instance p1, Lcom/tencent/android/tpush/stat/event/c$a;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct {p1}, Lcom/tencent/android/tpush/stat/event/c$a;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/c;->a:Lcom/tencent/android/tpush/stat/event/c$a;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    const-wide/16 p4, -0x1

    const-wide/16 p4, -0x1

    const/4 v1, 0x6

    const-wide/16 p4, -0x1

    const-wide/16 p4, -0x1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-wide p4, p0, Lcom/tencent/android/tpush/stat/event/c;->b:J

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p3, p1, Lcom/tencent/android/tpush/stat/event/c$a;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-wide p6, p0, Lcom/tencent/android/tpush/stat/event/Event;->j:J

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()Lcom/tencent/android/tpush/stat/event/c$a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@ s/@ct~~~l @~s @ d~@@~~ o~~o~@ n~ bb~t@@~oy1 @@fMi~i@ 4 ~ ~ l@@~~r i@ f@o@o.So Kmb@ ~@v-@u~~/a "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/c;->a:Lcom/tencent/android/tpush/stat/event/c$a;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public getType()Lcom/tencent/android/tpush/stat/event/EventType;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/stat/event/EventType;->CUSTOM:Lcom/tencent/android/tpush/stat/event/EventType;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method public onEncode(Lorg/json/JSONObject;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    const/4 p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x4

    return p1
.end method

.method public toJsonString()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    new-instance v0, Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x5

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    new-instance v1, Lorg/json/JSONObject;

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string v2, "Isemvet"

    const-string v2, "desIevt"

    const/4 v7, 0x0

    const-string v2, "eevnotI"

    const-string v2, "eventId"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v3, p0, Lcom/tencent/android/tpush/stat/event/c;->a:Lcom/tencent/android/tpush/stat/event/c$a;

    const/4 v7, 0x4

    iget-object v3, v3, Lcom/tencent/android/tpush/stat/event/c$a;->a:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x7

    move v7, v6

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/c;->a:Lcom/tencent/android/tpush/stat/event/c$a;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v2, v2, Lcom/tencent/android/tpush/stat/event/c$a;->c:Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-eqz v2, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v2}, Lorg/json/JSONObject;->length()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    if-eqz v2, :cond_0

    const/4 v6, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v2, "vk"

    const-string/jumbo v2, "vk"

    const/4 v7, 0x6

    const-string/jumbo v2, "vk"

    const-string/jumbo v2, "kv"

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/stat/event/c;->a:Lcom/tencent/android/tpush/stat/event/c$a;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v3, v3, Lcom/tencent/android/tpush/stat/event/c$a;->c:Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_0
    const/4 v7, 0x2

    const-string/jumbo v2, "mscoebtnEtm"

    const-string v2, "emEmuctnost"

    const/4 v7, 0x0

    const-string v2, "emvstnutcoE"

    const-string v2, "customEvent"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/c;->getType()Lcom/tencent/android/tpush/stat/event/EventType;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    if-eqz v1, :cond_1

    const/4 v6, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x3

    const-string/jumbo v2, "te"

    const-string v2, "et"

    const/4 v7, 0x3

    const-string/jumbo v2, "te"

    const-string v2, "et"

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v1}, Lcom/tencent/android/tpush/stat/event/EventType;->GetIntValue()I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x3

    const-string/jumbo v1, "rsVikdopes"

    const-string/jumbo v1, "sdkVersion"

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string v2, "9q..143"

    const-string v2, "1.4.3.9"

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const-string v1, "eoskt"

    const-string/jumbo v1, "kteoo"

    const/4 v7, 0x0

    const-string/jumbo v1, "token"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    invoke-static {v2}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string v1, "dIcmeasc"

    const-string/jumbo v1, "sdcecbaI"

    const/4 v7, 0x7

    const-string/jumbo v1, "sIecocsd"

    const-string v1, "accessId"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v2}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-string/jumbo v1, "iteumbmtp"

    const-string/jumbo v1, "tampeiutm"

    const/4 v7, 0x7

    const-string/jumbo v1, "ptetsaumi"

    const-string/jumbo v1, "timestamp"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x7

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x5

    div-long/2addr v2, v4

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string/jumbo v1, "ixd"

    const-string/jumbo v1, "xdi"

    const/4 v7, 0x5

    const-string v1, "dxi"

    const-string/jumbo v1, "idx"

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/b/b;->a()I

    move-result v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x7

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-string v1, "e:ttrvnpsECotp rr mosnJEo"

    const-string/jumbo v1, "ntnJsEtp o CousermrvE:ort"

    const/4 v7, 0x1

    const-string v1, "esuroJ:nqott EtConsrEr mv"

    const-string v1, "CustomEvent toJson Error:"

    const/4 v6, 0x5

    xor-int/2addr v7, v6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    const-string v0, ""

    const/4 v7, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/c;->toJsonString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method
