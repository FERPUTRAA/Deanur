.class public Lcom/tencent/android/tpush/stat/event/MQTTEvent;
.super Lcom/tencent/android/tpush/stat/event/Event;


# instance fields
.field public accessid:J

.field public appVersion:Ljava/lang/String;

.field public appkey:Ljava/lang/String;

.field public eventId:Ljava/lang/String;

.field public msgBusiId:J

.field public msgId:J

.field public msgType:J

.field public nGroupId:Ljava/lang/String;

.field public prop:Lorg/json/JSONObject;

.field public pushAction:I

.field public pushChannel:I

.field public pushtime:J

.field public sdkVersion:Ljava/lang/String;

.field public source:J

.field public targetType:J

.field public templateId:Ljava/lang/String;

.field public timestamp:J

.field public token:Ljava/lang/String;

.field public traceId:Ljava/lang/String;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-direct {p0, p1, v0, v1, v2}, Lcom/tencent/android/tpush/stat/event/Event;-><init>(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v0, 0x0

    const/4 v6, 0x5

    const/4 v5, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->appkey:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x4

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    iput-wide v1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->accessid:J

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->appVersion:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->sdkVersion:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->token:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v6, 0x4

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    iput-wide v3, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgId:J

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    iput-wide v3, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgType:J

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v3, -0x1

    const/4 v6, 0x2

    iput v3, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->pushAction:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->nGroupId:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x5

    iput-wide v1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->targetType:J

    const/4 v6, 0x4

    const/4 v5, 0x0

    iput-wide v1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->source:J

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->eventId:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->prop:Lorg/json/JSONObject;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->templateId:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->traceId:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->appkey:Ljava/lang/String;

    const/4 v6, 0x3

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->accessid:J

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;J)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0, p1, v0, p2, p3}, Lcom/tencent/android/tpush/stat/event/MQTTEvent;-><init>(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;JLcom/tencent/android/tpush/message/PushMessageManager;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2, p3}, Lcom/tencent/android/tpush/stat/event/MQTTEvent;-><init>(Landroid/content/Context;J)V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0, p4}, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->a(Lcom/tencent/android/tpush/message/PushMessageManager;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;J)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/android/tpush/stat/event/Event;-><init>(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 p1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->appVersion:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->sdkVersion:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->token:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgId:J

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgType:J

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v0, -0x2

    const/4 v0, -0x1

    const/4 v3, 0x4

    iput v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->pushAction:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->nGroupId:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->targetType:J

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->source:J

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->eventId:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->prop:Lorg/json/JSONObject;

    const/4 v3, 0x2

    const-string p1, ""

    const-string p1, ""

    const/4 v3, 0x7

    const-string p1, ""

    const/4 v3, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->templateId:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->traceId:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->appkey:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-wide p3, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->accessid:J

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void
.end method

.method private a(Lcom/tencent/android/tpush/message/PushMessageManager;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@cs~~ ~@ om~M@~d@ @~@a- yi@@ ~ti@ou~  l~bi v S~/ ~@~o @o/f@ ~rb .@l~4Kn1 ~~~@o~ s~o@@b@~ @@@~f~t"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getBusiMsgId()J

    move-result-wide v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgBusiId:J

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const/4 v5, 0x6

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const/4 v4, 0x0

    const/4 v4, 0x3

    div-long/2addr v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->timestamp:J

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getTimestamps()J

    move-result-wide v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    div-long/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->pushtime:J

    const/4 v5, 0x3

    iget v0, p1, Lcom/tencent/android/tpush/message/PushMessageManager;->pushChannel:I

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->pushChannel:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/b/b;->c(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->appVersion:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v0, "..9m341"

    const-string v0, ".4s93.1"

    const/4 v5, 0x6

    const-string v0, ".39.o4."

    const-string v0, "1.4.3.9"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->sdkVersion:Ljava/lang/String;

    const/4 v4, 0x4

    shl-int/2addr v5, v4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->token:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgId:J

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getType()J

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgType:J

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getGroupId()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->nGroupId:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getTargetType()J

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->targetType:J

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getSource()J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->source:J

    const/4 v5, 0x2

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 8

    const/4 v7, 0x0

    const/4 v0, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-ne p0, p1, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    return v0

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz p1, :cond_3

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-eq v2, v3, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto/16 :goto_1

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    check-cast p1, Lcom/tencent/android/tpush/stat/event/MQTTEvent;

    :try_start_0
    const/4 v6, 0x4

    move v7, v6

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->accessid:J

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-wide v4, p1, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->accessid:J

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    cmp-long v2, v2, v4

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-nez v2, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->timestamp:J

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-wide v4, p1, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->timestamp:J

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    cmp-long v2, v2, v4

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-nez v2, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgType:J

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-wide v4, p1, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgType:J

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    cmp-long v2, v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-nez v2, :cond_2

    const/4 v6, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->pushAction:I

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget v3, p1, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->pushAction:I

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-ne v2, v3, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgId:J

    const/4 v6, 0x6

    move v7, v6

    iget-wide v4, p1, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgId:J

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    cmp-long v2, v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    if-nez v2, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->appVersion:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-object v3, p1, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->appVersion:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eqz v2, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->token:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v3, p1, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->token:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-eqz v2, :cond_2

    const/4 v7, 0x6

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->targetType:J

    const/4 v7, 0x1

    const/4 v6, 0x3

    iget-wide v4, p1, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->targetType:J

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    cmp-long v2, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-nez v2, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->source:J

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-wide v4, p1, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->source:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    move v7, v6

    cmp-long p1, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-nez p1, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    goto :goto_0

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x5

    move v0, v1

    move v0, v1

    const/4 v7, 0x6

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    return v0

    :catchall_0
    move-exception p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-string/jumbo v0, "nurmE aTEQ oqtsevre:Mrl"

    const/4 v7, 0x2

    const-string/jumbo v0, "raQeEbTsMru tTv qEernol"

    const-string v0, "MQTTEvent equals Error:"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    return v1
.end method

.method public getAccessid()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->accessid:J

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-wide v0
.end method

.method public getAppkey()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->appkey:Ljava/lang/String;

    const/4 v2, 0x6

    return-object v0
.end method

.method public getType()Lcom/tencent/android/tpush/stat/event/EventType;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-super {p0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public onEncode(Lorg/json/JSONObject;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    const/4 p1, 0x1

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    return p1
.end method

.method public setAccessid(J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    iput-wide p1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->accessid:J

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method public setAppkey(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->appkey:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public toJsonString()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-string v0, "dugms"

    const-string/jumbo v0, "msgId"

    const/4 v7, 0x6

    const/4 v6, 0x0

    new-instance v1, Lorg/json/JSONObject;

    const/4 v6, 0x6

    move v7, v6

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    const-string v2, "decsscop"

    const-string v2, "Iecsodcs"

    const/4 v7, 0x2

    const-string/jumbo v2, "qIacsces"

    const-string v2, "accessId"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-wide v3, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->accessid:J

    const/4 v7, 0x0

    invoke-virtual {v1, v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string/jumbo v2, "itpohbsucn"

    const/4 v7, 0x0

    const-string/jumbo v2, "tAscsuponh"

    const-string/jumbo v2, "pushAction"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget v3, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->pushAction:I

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgId:J

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v1, v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v6, 0x4

    and-int/2addr v7, v6

    const-string v2, "geTmsyu"

    const-string v2, "esypgTu"

    const/4 v7, 0x5

    const-string v2, "Tepsogy"

    const-string/jumbo v2, "msgType"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-wide v3, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgType:J

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v1, v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->msgId:J

    const/4 v7, 0x2

    invoke-virtual {v1, v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v0, "thpsubie"

    const-string/jumbo v0, "stuihepp"

    const/4 v7, 0x0

    const-string/jumbo v0, "sphuimue"

    const-string/jumbo v0, "pushtime"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->pushtime:J

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v1, v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string/jumbo v0, "mtmiqtape"

    const-string v0, "emtimsatq"

    const/4 v7, 0x3

    const-string/jumbo v0, "psiamtteq"

    const-string/jumbo v0, "timestamp"

    const/4 v6, 0x3

    xor-int/2addr v7, v6

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->timestamp:J

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v1, v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v0, "dpselttseI"

    const-string/jumbo v0, "tesdptIela"

    const/4 v7, 0x6

    const-string/jumbo v0, "tlamdIemtp"

    const-string/jumbo v0, "templateId"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->templateId:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string v0, "cmaeotI"

    const-string/jumbo v0, "taemcIr"

    const/4 v7, 0x7

    const-string/jumbo v0, "rtecabd"

    const-string/jumbo v0, "traceId"

    const/4 v7, 0x5

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->traceId:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x3

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->token:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz v0, :cond_0

    const/4 v7, 0x3

    const-string/jumbo v2, "kunoo"

    const-string/jumbo v2, "ntoko"

    const/4 v7, 0x1

    const-string v2, "eopnt"

    const-string/jumbo v2, "token"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->appkey:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    if-eqz v0, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    const-string v2, "cKyaebseq"

    const-string v2, "eaysKbces"

    const/4 v7, 0x7

    const-string/jumbo v2, "ssscceaye"

    const-string v2, "accessKey"

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_1
    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->appVersion:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    if-eqz v0, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const-string/jumbo v2, "pasmrpneiV"

    const-string v2, "appVersion"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->sdkVersion:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-eqz v0, :cond_3

    const/4 v6, 0x1

    move v7, v6

    const-string/jumbo v2, "ndeVouskio"

    const-string v2, "Vsdokeuinr"

    const/4 v7, 0x7

    const-string/jumbo v2, "soekibdsrV"

    const-string/jumbo v2, "sdkVersion"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->nGroupId:Ljava/lang/String;

    const/4 v6, 0x0

    move v7, v6

    if-eqz v0, :cond_4

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string/jumbo v2, "ppgdIuu"

    const-string/jumbo v2, "prugpdI"

    const/4 v7, 0x7

    const-string/jumbo v2, "pgdIorp"

    const-string v2, "groupId"

    const/4 v6, 0x7

    shr-int/2addr v7, v6

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo v0, "pnhCaulnqsq"

    const-string v0, "aCpnheulqsn"

    const/4 v7, 0x5

    const-string v0, "hussehnanlp"

    const-string/jumbo v0, "pushChannel"

    const/4 v6, 0x0

    and-int/2addr v7, v6

    iget v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->pushChannel:I

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v1, v0, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->targetType:J

    const/4 v6, 0x5

    and-int/2addr v7, v6

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x3

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    cmp-long v0, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-lez v0, :cond_5

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string v0, "Ttrmpseyta"

    const-string v0, "Tgsttrpyae"

    const/4 v7, 0x4

    const-string v0, "eTrpottgya"

    const-string/jumbo v0, "targetType"

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v1, v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    :cond_5
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->source:J

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    cmp-long v0, v2, v4

    const/4 v7, 0x2

    if-lez v0, :cond_6

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    const-string/jumbo v0, "smcoeb"

    const-string v0, "csemro"

    const-string/jumbo v0, "uersuo"

    const-string/jumbo v0, "source"

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v1, v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    :cond_6
    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->eventId:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz v0, :cond_8

    const/4 v6, 0x6

    move v7, v6

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-nez v0, :cond_8

    const/4 v7, 0x2

    new-instance v0, Lorg/json/JSONObject;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo v2, "petednv"

    const-string v2, "evndote"

    const-string/jumbo v2, "tqdevIn"

    const-string v2, "eventId"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->eventId:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->prop:Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v2, :cond_7

    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v2}, Lorg/json/JSONObject;->length()I

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    if-eqz v2, :cond_7

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string/jumbo v2, "kv"

    const/4 v7, 0x4

    const-string/jumbo v2, "vk"

    const-string/jumbo v2, "kv"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->prop:Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_7
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string v2, "Essmbtonctu"

    const-string/jumbo v2, "ntoeubtsmEc"

    const/4 v7, 0x7

    const-string/jumbo v2, "mtvmtueEsco"

    const-string v2, "customEvent"

    const/4 v7, 0x0

    invoke-virtual {v1, v2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_8
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const-string v1, "gStEoioEnrnJr:TnsevoMro TtQt "

    const-string v1, "MQTTEvent toJsonString Error:"

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    const/4 v0, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/MQTTEvent;->toJsonString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object v0
.end method
