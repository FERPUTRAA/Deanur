.class public Lcom/tencent/android/tpush/stat/event/e;
.super Lcom/tencent/android/tpush/stat/event/Event;


# instance fields
.field private a:I

.field private b:I

.field private l:J


# direct methods
.method public constructor <init>(Landroid/content/Context;IIJ)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/stat/event/Event;-><init>(Landroid/content/Context;)V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput p2, p0, Lcom/tencent/android/tpush/stat/event/e;->a:I

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput p3, p0, Lcom/tencent/android/tpush/stat/event/e;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    iput-wide p4, p0, Lcom/tencent/android/tpush/stat/event/e;->l:J

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public getType()Lcom/tencent/android/tpush/stat/event/EventType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "b s~s 4oi y~d 1-@~   ~i@@@t@ ~@~m~@f@~i~ta bK@~uol~@@~~Sn  ~l.~M@~/@@ f~o/ @~oo c~ ~@b@ @~@~r@ v"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    sget-object v0, Lcom/tencent/android/tpush/stat/event/EventType;->LAUNCH:Lcom/tencent/android/tpush/stat/event/EventType;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public onEncode(Lorg/json/JSONObject;)Z
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    return p1
.end method

.method public toJsonString()Ljava/lang/String;
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    new-instance v0, Lorg/json/JSONObject;

    const/4 v6, 0x4

    move v7, v6

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/e;->getType()Lcom/tencent/android/tpush/stat/event/EventType;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-eqz v1, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const-string/jumbo v2, "te"

    const-string/jumbo v2, "te"

    const/4 v7, 0x4

    const-string/jumbo v2, "te"

    const-string v2, "et"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v1}, Lcom/tencent/android/tpush/stat/event/EventType;->GetIntValue()I

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    :cond_0
    const/4 v7, 0x5

    const-string/jumbo v1, "senmpclyhT"

    const-string v1, "Thslaeypcn"

    const/4 v7, 0x6

    const-string v1, "hTucoaynel"

    const-string/jumbo v1, "launchType"

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget v2, p0, Lcom/tencent/android/tpush/stat/event/e;->a:I

    const/4 v6, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    const-string/jumbo v1, "mrkdsbnise"

    const-string v1, "erkmsoisnd"

    const/4 v7, 0x2

    const-string/jumbo v1, "sdkVersion"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string v2, ".4.19.u"

    const-string v2, "1.4.o9."

    const-string/jumbo v2, "p3.914."

    const-string v2, "1.4.3.9"

    const/4 v7, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string/jumbo v1, "tnkqo"

    const-string/jumbo v1, "token"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v7, 0x7

    invoke-virtual {v2}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    invoke-static {v2}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const-string v1, "dbssIeac"

    const-string v1, "caessbdI"

    const/4 v7, 0x0

    const-string/jumbo v1, "scImcdes"

    const-string v1, "accessId"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v7, 0x2

    const/4 v6, 0x1

    invoke-static {v2}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v6, 0x0

    move v7, v6

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string/jumbo v1, "ppyuok"

    const-string/jumbo v1, "uppkya"

    const/4 v7, 0x2

    const-string/jumbo v1, "kpayeb"

    const-string v1, "appkey"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v2}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    const-string/jumbo v1, "petipsuma"

    const-string/jumbo v1, "tsitepmpa"

    const/4 v7, 0x6

    const-string/jumbo v1, "miteaptps"

    const-string/jumbo v1, "timestamp"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x2

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    div-long/2addr v2, v4

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const-string v1, "dix"

    const-string/jumbo v1, "ixd"

    const/4 v7, 0x4

    const-string/jumbo v1, "ixd"

    const-string/jumbo v1, "idx"

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/stat/b/b;->a()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string/jumbo v1, "natiuqhcqsf"

    const-string/jumbo v1, "unhaLtcsqfi"

    const/4 v7, 0x3

    const-string/jumbo v1, "nhsiacLufst"

    const-string v1, "firstLaunch"

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget v2, p0, Lcom/tencent/android/tpush/stat/event/e;->b:I

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/stat/event/e;->a:I

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    const/4 v2, 0x3

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-ne v1, v2, :cond_1

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string/jumbo v1, "ussmpI"

    const-string/jumbo v1, "sIsphu"

    const/4 v7, 0x3

    const-string v1, "hsIdou"

    const-string/jumbo v1, "pushId"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/e;->l:J

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v1, "nE aobouro ELsrJhtv:ecnrn"

    const-string v1, "cohmnnt EvJoaEo :surrenrL"

    const-string/jumbo v1, "oooEJru nr tsnL:enErvauch"

    const-string v1, "LaunchEvent toJson Error:"

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/e;->toJsonString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    return-object v0
.end method
