.class public Lcom/tencent/android/tpush/stat/event/d;
.super Lcom/tencent/android/tpush/stat/event/Event;


# static fields
.field private static a:Lcom/tencent/tpns/baseapi/base/logger/DeviceInfo;


# instance fields
.field private b:Ljava/lang/String;

.field private l:Lorg/json/JSONArray;

.field private m:I

.field private n:Ljava/lang/Thread;

.field private o:Ljava/lang/String;

.field private p:J

.field private q:Ljava/lang/String;

.field private r:Ljava/lang/String;

.field private s:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;IILorg/json/JSONArray;J)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x3

    const/4 p2, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2, p5, p6}, Lcom/tencent/android/tpush/stat/event/Event;-><init>(Landroid/content/Context;IJ)V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    const/4 p1, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/d;->n:Ljava/lang/Thread;

    const/4 v0, 0x2

    move v1, v0

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/d;->o:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    const-wide/16 p5, -0x1

    const-wide/16 p5, -0x1

    const/4 v1, 0x3

    const-wide/16 p5, -0x1

    const-wide/16 p5, -0x1

    const/4 v1, 0x5

    const/4 v0, 0x1

    iput-wide p5, p0, Lcom/tencent/android/tpush/stat/event/d;->p:J

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/d;->q:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/d;->r:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/d;->s:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput p3, p0, Lcom/tencent/android/tpush/stat/event/d;->m:I

    const/4 v1, 0x1

    iput-object p4, p0, Lcom/tencent/android/tpush/stat/event/d;->l:Lorg/json/JSONArray;

    const/4 v1, 0x1

    return-void
.end method

.method private a(Ljava/lang/Thread;)Lorg/json/JSONObject;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "4~s  ~~K ~mll~ocon~ob~@f/tob@~@ @~i~y@ ~ ~@b @@~~@@t .@~@u ~@SrvM~-@ ~so@ o i~@@ ~d f ~@ i~1 @@a"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v6, 0x7

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz p1, :cond_0

    const/4 v6, 0x0

    const-string v1, "id"

    const-string v1, "id"

    const/4 v6, 0x3

    const-string v1, "id"

    const-string v1, "id"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {p1}, Ljava/lang/Thread;->getId()J

    move-result-wide v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v5, 0x6

    move v6, v5

    const-string/jumbo v1, "nema"

    const-string v1, "amne"

    const/4 v6, 0x1

    const-string/jumbo v1, "neam"

    const-string/jumbo v1, "name"

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v1, "pr"

    const-string/jumbo v1, "pr"

    const-string/jumbo v1, "pr"

    const-string/jumbo v1, "pr"

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1}, Ljava/lang/Thread;->getPriority()I

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-wide v1, p0, Lcom/tencent/android/tpush/stat/event/d;->p:J

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v6, 0x4

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v5, 0x6

    move v6, v5

    cmp-long p1, v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-lez p1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string/jumbo p1, "thng"

    const-string/jumbo p1, "ngth"

    const/4 v6, 0x6

    const-string/jumbo p1, "tngh"

    const-string p1, "gthn"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v0, p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    return-object v0
.end method

.method private a(Lorg/json/JSONObject;)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/d;->b:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/b/b;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo v1, "m5d"

    const-string/jumbo v1, "md5"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const-string v0, "ct"

    const-string v0, "ct"

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget v1, p0, Lcom/tencent/android/tpush/stat/event/d;->m:I

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v5, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string v1, "bdi"

    const-string/jumbo v1, "idb"

    const/4 v5, 0x4

    const-string/jumbo v1, "idb"

    const-string v1, "bid"

    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const/4 v5, 0x2

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const/4 v5, 0x4

    const/4 v4, 0x1

    div-long/2addr v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v2, "td"

    const-string/jumbo v2, "td"

    const/4 v5, 0x0

    const-string v2, "dt"

    const-string v2, "dt"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p1, v2, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void
.end method

.method private b(Lorg/json/JSONObject;)V
    .locals 9

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/d;->n:Ljava/lang/Thread;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-direct {p0, v0}, Lcom/tencent/android/tpush/stat/event/d;->a(Ljava/lang/Thread;)Lorg/json/JSONObject;

    move-result-object v0

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    sget-object v1, Lcom/tencent/android/tpush/stat/event/d;->a:Lcom/tencent/tpns/baseapi/base/logger/DeviceInfo;

    const/4 v8, 0x7

    if-nez v1, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    new-instance v1, Lcom/tencent/tpns/baseapi/base/logger/DeviceInfo;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-direct {v1, v2}, Lcom/tencent/tpns/baseapi/base/logger/DeviceInfo;-><init>(Landroid/content/Context;)V

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    sput-object v1, Lcom/tencent/android/tpush/stat/event/d;->a:Lcom/tencent/tpns/baseapi/base/logger/DeviceInfo;

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string/jumbo v1, "nocmfeIesv"

    const-string/jumbo v1, "ncsofeeIdv"

    const/4 v8, 0x0

    const-string/jumbo v1, "ifeoodIcev"

    const-string v1, "deviceInfo"

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x4

    sget-object v2, Lcom/tencent/android/tpush/stat/event/d;->a:Lcom/tencent/tpns/baseapi/base/logger/DeviceInfo;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    goto :goto_0

    :catchall_0
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    const-string/jumbo v1, "rEmrvbrnoe"

    const-string/jumbo v1, "rrnmveEEor"

    const/4 v8, 0x1

    const-string/jumbo v1, "rotEnruevr"

    const-string v1, "ErrorEvent"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string v2, "eerortxppee nrhcChdcoT dsfouadae"

    const-string v2, "drCrohsrhxn eoeopTe aatdefedeucc"

    const/4 v8, 0x5

    const-string v2, "ddsuhorxqda heeefCnrrtpcoeneT ea"

    const-string/jumbo v2, "unexpected for encodeCrashThread"

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/d;->l:Lorg/json/JSONArray;

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-string/jumbo v2, "rgfa"

    const-string v2, "frag"

    const/4 v8, 0x0

    const-string v2, "afgr"

    const-string v2, "gfra"

    const/4 v7, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v8, 0x4

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    const-string v5, "abstc"

    const-string v5, "bcats"

    const/4 v8, 0x7

    const-string/jumbo v5, "stkmc"

    const-string/jumbo v5, "stack"

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-eqz v1, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {v0, v5, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    iget-wide v5, p0, Lcom/tencent/android/tpush/stat/event/d;->p:J

    const/4 v8, 0x1

    cmp-long v1, v5, v3

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x7

    if-lez v1, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/d;->l:Lorg/json/JSONArray;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    goto :goto_1

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/d;->b:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {v0, v5, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x3

    iget-wide v5, p0, Lcom/tencent/android/tpush/stat/event/d;->p:J

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    cmp-long v1, v5, v3

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-lez v1, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/d;->b:Ljava/lang/String;

    const/4 v8, 0x0

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_2
    :goto_1
    const/4 v8, 0x7

    const-string v1, "hct"

    const/4 v8, 0x5

    const-string/jumbo v1, "tch"

    const-string v1, "cth"

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x1

    iget p1, p0, Lcom/tencent/android/tpush/stat/event/d;->m:I

    const/4 v7, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    const/4 v1, 0x3

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    if-ne p1, v1, :cond_3

    const/4 v7, 0x0

    move v8, v7

    const-string p1, "afrn"

    const-string/jumbo p1, "rnaf"

    const/4 v8, 0x2

    const-string p1, "afnr"

    const-string/jumbo p1, "nfra"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/d;->s:Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v0, p1, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_3
    const/4 v8, 0x3

    const/4 v7, 0x1

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/d;->o:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method

.method public a()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/d;->l:Lorg/json/JSONArray;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/d;->b:Ljava/lang/String;

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string v1, "coreododtunmt.ph.nc.sine.a"

    const-string v1, ".pndoduatntnschetrc.em..oi"

    const/4 v3, 0x7

    const-string/jumbo v1, "mstncbtdc.inheu..proatnedo"

    const-string v1, "com.tencent.android.tpush."

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v2, 0x7

    move v3, v2

    if-nez v1, :cond_2

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v1, ".pas.duoem.ntpenontrtcdic"

    const-string/jumbo v1, "otatr..pimnddcenep.ctnnos"

    const/4 v3, 0x3

    const-string v1, ".nn.tstpccap.ree.nmodtdin"

    const-string v1, "com.tencent.android.tpns."

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez v1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    const-string/jumbo v1, "t.ntnotpqcnee.csm"

    const/4 v3, 0x2

    const-string/jumbo v1, "tosctp.eq.cnenmn."

    const-string v1, "com.tencent.tpns."

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    goto :goto_1

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    goto :goto_2

    :cond_2
    :goto_1
    const/4 v2, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x1

    :goto_2
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    return v0
.end method

.method public equals(Ljava/lang/Object;)Z
    .locals 8
    .param p1    # Ljava/lang/Object;
        .annotation build Landroidx/annotation/q0;
        .end annotation
    .end param

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    const/4 v0, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-ne p0, p1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    return v0

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz p1, :cond_3

    const/4 v6, 0x5

    move v7, v6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eq v2, v3, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    goto/16 :goto_1

    :cond_1
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    check-cast p1, Lcom/tencent/android/tpush/stat/event/d;

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-wide v4, p1, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    cmp-long v2, v2, v4

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-nez v2, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/d;->q:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v3, p1, Lcom/tencent/android/tpush/stat/event/d;->q:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-eqz v2, :cond_2

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/d;->r:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v3, p1, Lcom/tencent/android/tpush/stat/event/d;->r:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x7

    if-eqz v2, :cond_2

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/d;->l:Lorg/json/JSONArray;

    const/4 v7, 0x0

    const/4 v6, 0x7

    invoke-virtual {v2}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object p1, p1, Lcom/tencent/android/tpush/stat/event/d;->l:Lorg/json/JSONArray;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p1}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-eqz p1, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto :goto_0

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    move v0, v1

    move v0, v1

    const/4 v7, 0x5

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x7

    return v0

    :catchall_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string/jumbo p1, "orsErvEnse"

    const-string/jumbo p1, "vosEnrerrE"

    const-string/jumbo p1, "rEnmrvEort"

    const-string p1, "ErrorEvent"

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string/jumbo v0, "luxeo mpecersoaunftqe"

    const-string v0, "esamuercxpq e nfoulte"

    const/4 v7, 0x1

    const-string v0, "e etpbndlfe aeuosruxq"

    const-string/jumbo v0, "unexpected for equals"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    return v1
.end method

.method public getType()Lcom/tencent/android/tpush/stat/event/EventType;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/android/tpush/stat/event/EventType;->ERROR:Lcom/tencent/android/tpush/stat/event/EventType;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-super {p0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public onEncode(Lorg/json/JSONObject;)Z
    .locals 6

    const/4 v5, 0x5

    const-string/jumbo v0, "oudmc"

    const-string v0, "edcmo"

    const/4 v5, 0x5

    const-string v0, "cmode"

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/4 v1, 0x2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v0, "ae"

    const/4 v5, 0x1

    const-string v0, "ae"

    const-string v0, "ea"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget v1, p0, Lcom/tencent/android/tpush/stat/event/d;->m:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v0, "rpcp"

    const-string/jumbo v0, "rppc"

    const/4 v5, 0x1

    const-string/jumbo v0, "rppc"

    const-string/jumbo v0, "prcp"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v0, "tpcr"

    const-string v0, "ctrp"

    const/4 v5, 0x0

    const-string/jumbo v0, "rcpt"

    const-string/jumbo v0, "prct"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {}, Landroid/os/Process;->myTid()I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v0, Lcom/tencent/android/tpush/stat/b/a;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-direct {v0, v1, v2, v3}, Lcom/tencent/android/tpush/stat/b/a;-><init>(Landroid/content/Context;J)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/d;->n:Ljava/lang/Thread;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, p1, v1}, Lcom/tencent/android/tpush/stat/b/a;->a(Lorg/json/JSONObject;Ljava/lang/Thread;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/stat/event/d;->b(Lorg/json/JSONObject;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/stat/event/d;->a(Lorg/json/JSONObject;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 p1, 0x1

    const/4 v5, 0x7

    return p1
.end method

.method public toJsonString()Ljava/lang/String;
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance v0, Lorg/json/JSONObject;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const-string v1, "acseIbsc"

    const/4 v5, 0x1

    const-string v1, "dIassccp"

    const-string v1, "accessId"

    const/4 v5, 0x4

    const/4 v4, 0x4

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v1, "piaemtumt"

    const/4 v5, 0x6

    const-string/jumbo v1, "titsmepmq"

    const-string/jumbo v1, "timestamp"

    const/4 v5, 0x6

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->e:J

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/d;->q:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eqz v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v2, "teskp"

    const-string/jumbo v2, "knpet"

    const/4 v5, 0x7

    const-string v2, "eonmk"

    const-string/jumbo v2, "token"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/Event;->c:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const-string/jumbo v2, "sKycceasq"

    const/4 v5, 0x4

    const-string v2, "cyecoaess"

    const-string v2, "accessKey"

    const/4 v4, 0x2

    or-int/2addr v5, v4

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_1
    const/4 v5, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/d;->r:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo v2, "kiroebsVds"

    const-string/jumbo v2, "ossridesVk"

    const/4 v5, 0x1

    const-string/jumbo v2, "sdkVersion"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_2
    const/4 v5, 0x2

    const-string v1, "et"

    const-string v1, "et"

    const/4 v5, 0x3

    const-string v1, "et"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/d;->getType()Lcom/tencent/android/tpush/stat/event/EventType;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/stat/event/EventType;->GetIntValue()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {p0, v0}, Lcom/tencent/android/tpush/stat/event/d;->b(Lorg/json/JSONObject;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-object v0

    :catchall_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string v0, "ErrmrvnEeo"

    const/4 v5, 0x1

    const-string/jumbo v0, "vrrEneuoEt"

    const-string v0, "ErrorEvent"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo v1, "potienopenru g nxettJdorsof"

    const-string v1, "SreJoodruegfipoeoxt ntts nn"

    const/4 v5, 0x7

    const-string/jumbo v1, "s urn pfqodotntcirnSgxeJote"

    const-string/jumbo v1, "unexpected for toJsonString"

    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v0, 0x0

    const/4 v5, 0x4

    shl-int/2addr v4, v0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/d;->toJsonString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    return-object v0
.end method
