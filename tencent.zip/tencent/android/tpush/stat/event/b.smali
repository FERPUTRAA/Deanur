.class public Lcom/tencent/android/tpush/stat/event/b;
.super Lcom/tencent/android/tpush/stat/event/Event;


# instance fields
.field public a:Ljava/lang/String;

.field public b:J

.field private l:Ljava/lang/String;

.field private m:Ljava/lang/String;

.field private n:Ljava/lang/String;

.field private o:J

.field private p:I


# direct methods
.method public constructor <init>(Landroid/content/Context;JI)V
    .locals 5

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p0, p1, v0, v1, v2}, Lcom/tencent/android/tpush/stat/event/Event;-><init>(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-wide/16 v0, 0x0

    const/4 v4, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/b;->b:J

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iput-object v2, p0, Lcom/tencent/android/tpush/stat/event/b;->l:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/stat/event/b;->m:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/stat/event/b;->n:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/b;->o:J

    const/4 v0, 0x6

    const/4 v0, 0x2

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput v0, p0, Lcom/tencent/android/tpush/stat/event/b;->p:I

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->c:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/b;->l:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v0, "s4s.1.9"

    const-string v0, "91s43.."

    const-string v0, "49.m.13"

    const-string v0, "1.4.3.9"

    const/4 v3, 0x4

    move v4, v3

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/b;->m:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/common/AppInfos;->getCurAppVersion(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/b;->n:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput-wide p2, p0, Lcom/tencent/android/tpush/stat/event/b;->o:J

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput p4, p0, Lcom/tencent/android/tpush/stat/event/b;->p:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, " yd~o@~ ~ @~~~n @@u@ @t~o@i@b~  @c~os~@r@1 i~~~ ~~fK4~~lbao@~ @/l~- ~o@.@ @@~S@m@ti bo ~o/f   @M"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x3

    const/4 v0, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-ne p0, p1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    return v0

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x3

    if-eqz p1, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v3

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eq v2, v3, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    goto/16 :goto_1

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    check-cast p1, Lcom/tencent/android/tpush/stat/event/b;

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v7, 0x1

    iget-wide v4, p1, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v7, 0x4

    cmp-long v2, v2, v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    if-nez v2, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->e:J

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-wide v4, p1, Lcom/tencent/android/tpush/stat/event/Event;->e:J

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    cmp-long v2, v2, v4

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-nez v2, :cond_2

    const/4 v6, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/b;->l:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v3, p1, Lcom/tencent/android/tpush/stat/event/b;->l:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz v2, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/b;->m:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v3, p1, Lcom/tencent/android/tpush/stat/event/b;->m:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    if-eqz v2, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/b;->a:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v3, p1, Lcom/tencent/android/tpush/stat/event/b;->a:Ljava/lang/String;

    const/4 v7, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    if-eqz v2, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/b;->b:J

    const/4 v6, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-wide v4, p1, Lcom/tencent/android/tpush/stat/event/b;->b:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x4

    cmp-long p1, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-nez p1, :cond_2

    const/4 v7, 0x0

    goto :goto_0

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    move v0, v1

    move v0, v1

    const/4 v7, 0x2

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    return v0

    :catchall_0
    move-exception p1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string/jumbo v0, "leuarbo: orEtsedrEqln Cv"

    const-string v0, "CloudEvent equals Error:"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x1

    return v1
.end method

.method public getAccessid()J
    .locals 4

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget-wide v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-wide v0
.end method

.method public getType()Lcom/tencent/android/tpush/stat/event/EventType;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0
.end method

.method public hashCode()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-super {p0}, Ljava/lang/Object;->hashCode()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public onEncode(Lorg/json/JSONObject;)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x5

    const/4 p1, 0x1

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    return p1
.end method

.method public setAccessid(J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-wide p1, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-void
.end method

.method public toJsonString()Ljava/lang/String;
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v0, Lorg/json/JSONObject;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v1, "caImdcse"

    const/4 v6, 0x4

    const-string v1, "dcIaseus"

    const-string v1, "accessId"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v1, "tmotmespa"

    const-string/jumbo v1, "mtseoimta"

    const/4 v6, 0x4

    const-string v1, "epmmastiq"

    const-string/jumbo v1, "timestamp"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-wide v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->e:J

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/b;->l:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string/jumbo v2, "onseb"

    const-string v2, "btone"

    const/4 v6, 0x4

    const-string/jumbo v2, "kntme"

    const-string/jumbo v2, "token"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/Event;->c:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-eqz v1, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string v2, "eKcuosyea"

    const-string v2, "ceaKscuye"

    const/4 v6, 0x5

    const-string v2, "accessKey"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_1
    const/4 v5, 0x0

    move v6, v5

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/b;->m:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eqz v1, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string v2, "dnsksbpVer"

    const-string v2, "endVksipsr"

    const/4 v6, 0x7

    const-string/jumbo v2, "kiorsVudse"

    const-string/jumbo v2, "sdkVersion"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/b;->n:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v1, :cond_3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    const-string/jumbo v2, "sVpparipoq"

    const-string/jumbo v2, "repipaVoqs"

    const/4 v6, 0x4

    const-string/jumbo v2, "insparVoqe"

    const-string v2, "appVersion"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_3
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string/jumbo v1, "te"

    const-string v1, "et"

    const/4 v6, 0x0

    const-string v1, "et"

    const-string v1, "et"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v2, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string/jumbo v1, "ndsksoNseremiV"

    const/4 v6, 0x6

    const-string/jumbo v1, "kdsNoanirsmsVe"

    const-string/jumbo v1, "sdkVersionName"

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    sget-object v2, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x7

    new-instance v1, Lorg/json/JSONObject;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string v2, "ecimoudlVnmr"

    const-string v2, "dicmronsuVel"

    const/4 v6, 0x3

    const-string v2, "eiosooVcldun"

    const-string v2, "cloudVersion"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-wide v3, p0, Lcom/tencent/android/tpush/stat/event/b;->o:J

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v1, v2, v3, v4}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo v2, "odnorbutlceotCR"

    const-string/jumbo v2, "tlCrodenotcoluR"

    const/4 v6, 0x4

    const-string/jumbo v2, "noelrRuodlcotut"

    const-string v2, "cloudControlRet"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v3, p0, Lcom/tencent/android/tpush/stat/event/b;->p:I

    const/4 v6, 0x6

    invoke-virtual {v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v6, 0x7

    const-string v2, "doMsgbcu"

    const/4 v6, 0x5

    const-string v2, "Moscgdlp"

    const-string v2, "cloudMsg"

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string v1, "ECJune tqr dousl:rtoovor"

    const-string/jumbo v1, "renJEdu tvsrortC:o ouolE"

    const-string v1, "dssCJrroooEnuvo :rEln tt"

    const-string v1, "CloudEvent toJson Error:"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v0, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/b;->toJsonString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method
