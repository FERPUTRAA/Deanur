.class public abstract Lcom/tencent/android/tpush/stat/event/Event;
.super Ljava/lang/Object;


# static fields
.field public static channel:Ljava/lang/String; = "xgsdk"

.field protected static h:Ljava/lang/String;

.field protected static i:J


# instance fields
.field protected c:Ljava/lang/String;

.field protected d:J

.field protected e:J

.field protected f:I

.field protected g:Ljava/lang/String;

.field protected j:J

.field protected k:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x0

    xor-int/2addr v3, v0

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->c:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-wide/16 v1, 0x0

    const/4 v4, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x1

    iput-wide v1, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->g:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput-wide v1, p0, Lcom/tencent/android/tpush/stat/event/Event;->j:J

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-direct {p0, p1, v0, v1, v2}, Lcom/tencent/android/tpush/stat/event/Event;->a(Landroid/content/Context;IJ)V

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;IJ)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->c:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-wide v1, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->g:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput-wide v1, p0, Lcom/tencent/android/tpush/stat/event/Event;->j:J

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo v1, "xgA"

    const-string/jumbo v1, "xAg"

    const/4 v4, 0x5

    const-string v1, "gxA"

    const-string v1, "Axg"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, p3, p4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->c:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/android/tpush/stat/event/Event;->a(Landroid/content/Context;IJ)V

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->g:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->j:J

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/stat/event/Event;->c:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 p2, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-direct {p0, p1, p2, v0, v1}, Lcom/tencent/android/tpush/stat/event/Event;->a(Landroid/content/Context;IJ)V

    const/4 v4, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Ljava/lang/String;J)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->g:Ljava/lang/String;

    const/4 v3, 0x3

    move v4, v3

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->j:J

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object p2, p0, Lcom/tencent/android/tpush/stat/event/Event;->c:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    const/4 p2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/android/tpush/stat/event/Event;->a(Landroid/content/Context;IJ)V

    const/4 v3, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void
.end method

.method private a(Landroid/content/Context;IJ)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~~sc@ o 4@lio~ s b@@~~@n   -@fma~~~uod@SK.@@~~~l v~ @@ ~@/@@@~@f  /M~~~1  ~b@r ot~yo @~ot~~@@ii "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v5, 0x1

    iput-wide p3, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const/4 v5, 0x1

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const/4 v5, 0x6

    const/4 v4, 0x3

    div-long/2addr v0, v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->e:J

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    iput p2, p0, Lcom/tencent/android/tpush/stat/event/Event;->f:I

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p1, p3, p4}, Lcom/tencent/android/tpush/stat/b/b;->b(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/stat/event/Event;->g:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    sget-object p2, Lcom/tencent/android/tpush/stat/event/Event;->h:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz p2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p2}, Ljava/lang/String;->length()I

    move-result p2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/16 p3, 0x28

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-ge p2, p3, :cond_1

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/XGPushConfig;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    sput-object p1, Lcom/tencent/android/tpush/stat/event/Event;->h:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/stat/b/b;->c(Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-nez p1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string p1, "0"

    const-string p1, "0"

    const/4 v5, 0x1

    const-string p1, "0"

    const-string p1, "0"

    const/4 v4, 0x6

    const/4 v5, 0x4

    sput-object p1, Lcom/tencent/android/tpush/stat/event/Event;->h:Ljava/lang/String;

    :cond_1
    const/4 v4, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    sget-wide p1, Lcom/tencent/android/tpush/stat/event/Event;->i:J

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-wide/16 p3, 0x0

    const-wide/16 p3, 0x0

    const/4 v5, 0x0

    const-wide/16 p3, 0x0

    const-wide/16 p3, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    cmp-long p1, p1, p3

    const/4 v5, 0x7

    const/4 v4, 0x0

    if-nez p1, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/Event;->getContext()Landroid/content/Context;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/service/cache/CacheManager;->getGuid(Landroid/content/Context;)J

    move-result-wide p1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    sput-wide p1, Lcom/tencent/android/tpush/stat/event/Event;->i:J

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-void
.end method


# virtual methods
.method public decode(Lorg/json/JSONObject;)Z
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    const/4 p1, 0x1

    const/4 v0, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    return p1
.end method

.method public encode(Lorg/json/JSONObject;)Z
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    const/4 v0, 0x0

    :try_start_0
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-string/jumbo v1, "ky"

    const-string/jumbo v1, "ky"

    const/4 v9, 0x7

    const-string/jumbo v1, "ky"

    const-string/jumbo v1, "ky"

    const/4 v8, 0x3

    xor-int/2addr v9, v8

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->c:Ljava/lang/String;

    const/4 v9, 0x6

    invoke-static {p1, v1, v2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/Event;->getType()Lcom/tencent/android/tpush/stat/event/EventType;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    if-eqz v1, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    const-string/jumbo v2, "te"

    const-string v2, "et"

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpush/stat/event/EventType;->GetIntValue()I

    move-result v1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {p1, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x7

    const-string/jumbo v1, "ui"

    const-string/jumbo v1, "ui"

    const/4 v9, 0x5

    const-string/jumbo v1, "ui"

    const-string/jumbo v1, "ui"

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v2}, Lcom/tencent/android/tpush/stat/b/e;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string/jumbo v1, "mc"

    const-string v1, "cm"

    const/4 v9, 0x2

    const-string v1, "cm"

    const-string/jumbo v1, "mc"

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v9, 0x0

    const/4 v8, 0x1

    invoke-static {v2}, Lcom/tencent/tpns/dataacquisition/CustomDeviceInfos;->getFacilityMacAddr(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {p1, v1, v2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string/jumbo v1, "tu"

    const/4 v9, 0x5

    const-string/jumbo v1, "tu"

    const-string/jumbo v1, "ut"

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x6

    const/4 v2, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/Event;->getType()Lcom/tencent/android/tpush/stat/event/EventType;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    sget-object v2, Lcom/tencent/android/tpush/stat/event/EventType;->SESSION_ENV:Lcom/tencent/android/tpush/stat/event/EventType;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-eq v1, v2, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string/jumbo v1, "va"

    const-string v1, "av"

    const/4 v9, 0x5

    const-string v1, "av"

    const-string v1, "av"

    const/4 v9, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->g:Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p1, v1, v2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string v1, "hc"

    const-string v1, "hc"

    const/4 v9, 0x5

    const-string v1, "hc"

    const-string v1, "ch"

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    sget-object v2, Lcom/tencent/android/tpush/stat/event/Event;->channel:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {p1, v1, v2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string/jumbo v1, "mdi"

    const-string v1, "dmi"

    const/4 v9, 0x1

    const-string/jumbo v1, "imd"

    const-string/jumbo v1, "mid"

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    sget-object v2, Lcom/tencent/android/tpush/stat/event/Event;->h:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {p1, v1, v2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    const-string/jumbo v1, "is"

    const-string/jumbo v1, "si"

    const/4 v9, 0x2

    const-string/jumbo v1, "is"

    const-string/jumbo v1, "si"

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x3

    iget v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->f:I

    const/4 v9, 0x1

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/Event;->getType()Lcom/tencent/android/tpush/stat/event/EventType;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    sget-object v2, Lcom/tencent/android/tpush/stat/event/EventType;->CUSTOM:Lcom/tencent/android/tpush/stat/event/EventType;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-string/jumbo v3, "st"

    const-string/jumbo v3, "st"

    const/4 v9, 0x3

    const-string/jumbo v3, "st"

    const-string/jumbo v3, "ts"

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    if-ne v1, v2, :cond_3

    :try_start_1
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string/jumbo v1, "stc"

    const-string v1, "cst"

    const/4 v9, 0x1

    const-string v1, "cts"

    const-string v1, "cts"

    const/4 v9, 0x6

    iget-wide v4, p0, Lcom/tencent/android/tpush/stat/event/Event;->e:J

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {p1, v1, v4, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-wide v1, p0, Lcom/tencent/android/tpush/stat/event/Event;->j:J

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x3

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x0

    cmp-long v6, v1, v4

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-nez v6, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-wide v6, p0, Lcom/tencent/android/tpush/stat/event/Event;->e:J

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    cmp-long v4, v6, v4

    const/4 v9, 0x5

    const/4 v8, 0x4

    if-eqz v4, :cond_2

    const/4 v9, 0x5

    invoke-virtual {p1, v3, v6, v7}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    goto :goto_0

    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p1, v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    goto :goto_0

    :cond_3
    const/4 v9, 0x0

    const/4 v8, 0x0

    iget-wide v1, p0, Lcom/tencent/android/tpush/stat/event/Event;->e:J

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p1, v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string v1, "0"

    const-string v1, "0"

    const/4 v9, 0x2

    const-string v1, "0"

    const-string v1, "0"

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    iget-wide v3, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {v2, v3, v4}, Lcom/tencent/android/tpush/stat/b/b;->a(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string/jumbo v2, "vs"

    const-string/jumbo v2, "vs"

    const/4 v9, 0x6

    const-string/jumbo v2, "sv"

    const-string/jumbo v2, "sv"

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v1, :cond_4

    :try_start_2
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {v1}, Lcom/tencent/android/tpush/stat/b/b;->a(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {p1, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    goto :goto_1

    :cond_4
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    iget-wide v3, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-static {v1, v3, v4}, Lcom/tencent/android/tpush/stat/b/b;->a(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {p1, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :goto_1
    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string v1, "diug"

    const-string v1, "gidu"

    const/4 v9, 0x7

    const-string v1, "guid"

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    sget-wide v2, Lcom/tencent/android/tpush/stat/event/Event;->i:J

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    const-string/jumbo v1, "std"

    const-string/jumbo v1, "std"

    const/4 v9, 0x4

    const-string/jumbo v1, "tds"

    const-string v1, "dts"

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v9, 0x6

    const/4 v8, 0x5

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/stat/b/b;->a(Landroid/content/Context;Z)I

    move-result v2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/event/Event;->onEncode(Lorg/json/JSONObject;)Z

    move-result p1
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x7

    return p1

    :catchall_0
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    return v0
.end method

.method public getAccessid()J
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-wide v0
.end method

.method public getAppkey()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->c:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public getContext()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->k:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-object v0
.end method

.method public getMsgTimeSec()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->j:J

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-wide v0
.end method

.method public getTimestamp()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-wide v0, p0, Lcom/tencent/android/tpush/stat/event/Event;->e:J

    const/4 v3, 0x6

    const/4 v2, 0x0

    return-wide v0
.end method

.method public abstract getType()Lcom/tencent/android/tpush/stat/event/EventType;
.end method

.method public abstract onEncode(Lorg/json/JSONObject;)Z
.end method

.method public setAccessid(J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-wide p1, p0, Lcom/tencent/android/tpush/stat/event/Event;->d:J

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public setAppkey(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/Event;->c:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public setMsgTimeSec(J)V
    .locals 2

    const/4 v0, 0x2

    move v1, v0

    iput-wide p1, p0, Lcom/tencent/android/tpush/stat/event/Event;->j:J

    const/4 v1, 0x0

    const/4 v0, 0x3

    return-void
.end method

.method public toJsonString()Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpush/stat/event/Event;->encode(Lorg/json/JSONObject;)Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    return-object v0

    :catchall_0
    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string v0, ""

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/Event;->toJsonString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x3

    return-object v0
.end method
