.class public Lcom/tencent/android/tpush/stat/event/a;
.super Lcom/tencent/android/tpush/stat/event/f;


# static fields
.field private static o:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;IDJ)V
    .locals 9

    const/4 v2, 0x0

    const/4 v3, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move-object v1, p1

    move v4, p2

    move v4, p2

    move v4, p2

    move v4, p2

    move-wide v5, p3

    move-wide v7, p5

    invoke-direct/range {v0 .. v8}, Lcom/tencent/android/tpush/stat/event/f;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;IDJ)V

    sget p2, Lcom/tencent/android/tpush/stat/event/a;->o:I

    const-string/jumbo p3, "v_snkbecaixed"

    const-string p3, "eis_v_bcxadek"

    const-string p3, "back_ev_index"

    if-nez p2, :cond_0

    const/4 p2, 0x0

    invoke-static {p1, p3, p2}, Lcom/tencent/android/tpush/stat/b/d;->a(Landroid/content/Context;Ljava/lang/String;I)I

    move-result p4

    sput p4, Lcom/tencent/android/tpush/stat/event/a;->o:I

    const p5, 0x7ffe795f

    if-le p4, p5, :cond_0

    sput p2, Lcom/tencent/android/tpush/stat/event/a;->o:I

    :cond_0
    sget p2, Lcom/tencent/android/tpush/stat/event/a;->o:I

    add-int/lit8 p2, p2, 0x1

    sput p2, Lcom/tencent/android/tpush/stat/event/a;->o:I

    invoke-static {p1, p3, p2}, Lcom/tencent/android/tpush/stat/b/d;->b(Landroid/content/Context;Ljava/lang/String;I)V

    return-void
.end method


# virtual methods
.method public getType()Lcom/tencent/android/tpush/stat/event/EventType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ~@m@@ @4b~a~s~ tm~o@~@v~@~ Ko~o@b ~y~i~@~~@1~o f @cl@~t/d o f~.~/ ru @~iSl  @@ @bn~-i  @o @@~@M"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/stat/event/EventType;->BACKGROUND:Lcom/tencent/android/tpush/stat/event/EventType;

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public onEncode(Lorg/json/JSONObject;)Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string v0, "cb"

    const-string v0, "cb"

    const/4 v3, 0x2

    const-string v0, "bc"

    const-string v0, "bc"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    sget v1, Lcom/tencent/android/tpush/stat/event/a;->o:I

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v0, "tf"

    const-string/jumbo v0, "tf"

    const/4 v3, 0x2

    const-string v0, "ft"

    const-string v0, "ft"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v3, 0x1

    invoke-super {p0, p1}, Lcom/tencent/android/tpush/stat/event/f;->onEncode(Lorg/json/JSONObject;)Z

    move-result p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    return p1
.end method
