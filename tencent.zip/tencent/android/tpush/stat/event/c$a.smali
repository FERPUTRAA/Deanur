.class public Lcom/tencent/android/tpush/stat/event/c$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/stat/event/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public a:Ljava/lang/String;

.field public b:Lorg/json/JSONArray;

.field public c:Lorg/json/JSONObject;

.field public d:Z


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/c$a;->c:Lorg/json/JSONObject;

    const/4 v1, 0x1

    or-int/2addr v2, v1

    const/4 v0, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    iput-boolean v0, p0, Lcom/tencent/android/tpush/stat/event/c$a;->d:Z

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;[Ljava/lang/String;Ljava/util/Properties;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/event/c$a;->c:Lorg/json/JSONObject;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    iput-boolean v0, p0, Lcom/tencent/android/tpush/stat/event/c$a;->d:Z

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/c$a;->a:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eqz p3, :cond_0

    const/4 v2, 0x0

    move v3, v2

    new-instance p1, Lorg/json/JSONObject;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {p1, p3}, Lorg/json/JSONObject;-><init>(Ljava/util/Map;)V

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/c$a;->c:Lorg/json/JSONObject;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    goto :goto_1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-eqz p2, :cond_1

    const/4 v2, 0x1

    move v3, v2

    new-instance p1, Lorg/json/JSONArray;

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    invoke-direct {p1}, Lorg/json/JSONArray;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/c$a;->b:Lorg/json/JSONArray;

    const/4 v3, 0x0

    const/4 v2, 0x1

    array-length p1, p2

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-ge v0, p1, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    aget-object p3, p2, v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/c$a;->b:Lorg/json/JSONArray;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v1, p3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v3, 0x7

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance p1, Lorg/json/JSONObject;

    const/4 v3, 0x6

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/event/c$a;->c:Lorg/json/JSONObject;

    :cond_2
    :goto_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method


# virtual methods
.method public equals(Ljava/lang/Object;)Z
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "b@s  @ S i~~@@@b@@4 a~ ~f @ ~ f~o~@~    o@l@M orcv- /~~1~o~ @si~~@@iuot@@td/K~~~yl@n~. ~~o~~@bm@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x7

    or-int/2addr v3, v2

    if-nez p1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x2

    if-ne p0, p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    return p1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    instance-of v1, p1, Lcom/tencent/android/tpush/stat/event/c$a;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-eqz v1, :cond_2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    check-cast p1, Lcom/tencent/android/tpush/stat/event/c$a;

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/c$a;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpush/stat/event/c$a;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    return p1

    :cond_2
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    return v0
.end method

.method public hashCode()I
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/event/c$a;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/16 v1, 0x20

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(I)V

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/c$a;->a:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const-string v1, ","

    const-string v1, ","

    const/4 v3, 0x3

    const-string v1, ","

    const-string v1, ","

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/c$a;->b:Lorg/json/JSONArray;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v1}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/event/c$a;->c:Lorg/json/JSONObject;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0
.end method
