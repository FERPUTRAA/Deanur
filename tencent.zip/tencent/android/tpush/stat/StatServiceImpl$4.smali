.class Lcom/tencent/android/tpush/stat/StatServiceImpl$4;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Landroid/content/Context;Ljava/lang/String;JJJ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:J

.field final synthetic d:J

.field final synthetic e:J


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;JJJ)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->a:Ljava/lang/String;

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->b:Landroid/content/Context;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-wide p3, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->c:J

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-wide p5, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->d:J

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-wide p7, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->e:J

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public run()V
    .locals 15

    :try_start_0
    const-string v14, " ~s/t~ @ b@ o-@i~ ~vfo~~@@  K@@@o@@@~ Su~@y~@oM1 ~i./l~t  @~ ~n@ a~ 4~f~~~si@b@dmbo cl~~~@o@r~ @"

    const-string v14, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g()Ljava/util/Map;

    move-result-object v0

    const/4 v14, 0x4

    monitor-enter v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v14, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->g()Ljava/util/Map;

    move-result-object v1

    const/4 v14, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->a:Ljava/lang/String;

    const/4 v14, 0x2

    invoke-interface {v1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    check-cast v1, Ljava/lang/Long;

    const/4 v14, 0x2

    monitor-exit v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v14, 0x5

    if-eqz v1, :cond_5

    :try_start_2
    const/4 v14, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v14, 0x4

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v14, 0x7

    sub-long/2addr v2, v0

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const-wide/16 v0, 0x3e8

    const/4 v14, 0x5

    div-long/2addr v2, v0

    const/4 v14, 0x7

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v14, 0x6

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v14, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v14, 0x2

    cmp-long v1, v1, v3

    const/4 v14, 0x5

    if-gtz v1, :cond_0

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const-wide/16 v0, 0x1

    const/4 v14, 0x1

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    :cond_0
    const/4 v14, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->i()Ljava/lang/String;

    move-result-object v1

    const/4 v14, 0x1

    if-eqz v1, :cond_1

    const/4 v14, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->a:Ljava/lang/String;

    const/4 v14, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v14, 0x4

    if-eqz v2, :cond_1

    const/4 v14, 0x7

    const-string v1, "-"

    const-string v1, "-"

    const-string v1, "-"

    const-string v1, "-"

    :cond_1
    move-object v7, v1

    move-object v7, v1

    move-object v7, v1

    move-object v7, v1

    const/4 v14, 0x1

    new-instance v1, Lcom/tencent/android/tpush/stat/event/f;

    const/4 v14, 0x7

    iget-object v6, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->b:Landroid/content/Context;

    const/4 v14, 0x6

    iget-object v8, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->a:Ljava/lang/String;

    const/4 v14, 0x4

    iget-wide v9, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->c:J

    invoke-static {v6, v9, v10}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Landroid/content/Context;J)I

    move-result v9

    const/4 v14, 0x3

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v10

    const/4 v14, 0x3

    long-to-double v10, v10

    const/4 v14, 0x6

    iget-wide v12, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->c:J

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    move-object v5, v1

    const/4 v14, 0x4

    invoke-direct/range {v5 .. v13}, Lcom/tencent/android/tpush/stat/event/f;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;IDJ)V

    const/4 v14, 0x7

    iget-wide v5, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->d:J

    cmp-long v0, v5, v3

    const/4 v14, 0x7

    if-lez v0, :cond_2

    const/4 v14, 0x5

    iput-wide v5, v1, Lcom/tencent/android/tpush/stat/event/f;->a:J

    :cond_2
    const/4 v14, 0x5

    iget-wide v5, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->e:J

    const/4 v14, 0x4

    cmp-long v0, v5, v3

    const/4 v14, 0x5

    if-lez v0, :cond_3

    const/4 v14, 0x4

    iput-wide v5, v1, Lcom/tencent/android/tpush/stat/event/f;->a:J

    :cond_3
    const/4 v14, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->a:Ljava/lang/String;

    const/4 v14, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->h()Ljava/lang/String;

    move-result-object v2

    const/4 v14, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v14, 0x7

    if-nez v0, :cond_4

    const/4 v14, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v0

    const/4 v14, 0x5

    const-string v2, "emvmft  ncide nc  vooiofgIa.ia senieopinduivnRre ssopalu"

    const-string/jumbo v2, "vssisfniaomipon n epfuvo lddg neiasIrcau. et eociRneiov "

    const-string v2, "Invalid invocation since previous onResume on diff page."

    const/4 v14, 0x2

    invoke-virtual {v0, v2}, Lcom/tencent/android/tpush/stat/b/c;->c(Ljava/lang/Object;)V

    :cond_4
    const/4 v14, 0x2

    new-instance v0, Ljava/util/ArrayList;

    const/4 v14, 0x2

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v14, 0x1

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v14, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Ljava/util/List;)V

    const/4 v14, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->a:Ljava/lang/String;

    const/4 v14, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c(Ljava/lang/String;)Ljava/lang/String;

    goto :goto_0

    :cond_5
    const/4 v14, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v0

    const/4 v14, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v14, 0x7

    const-string/jumbo v2, "ormaotfSgei Drm:tIPt "

    const-string/jumbo v2, "ieImmroDtta:t fgePrS "

    const-string v2, "S mtobtfegIeaDtrri:a "

    const-string v2, "Starttime for PageID:"

    const/4 v14, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$4;->a:Ljava/lang/String;

    const/4 v14, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v2, "oRoo)duu moet ,eu ss tlonn(n"

    const-string v2, "R eoo msud  )snole(ft,onuont"

    const-string v2, "?o e ,npdme)s(oo ot lRuntnfu"

    const-string v2, " not found, lost onResume()?"

    const/4 v14, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v14, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/stat/b/c;->f(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    return-void

    :catchall_0
    move-exception v1

    :try_start_3
    const/4 v14, 0x7

    monitor-exit v0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    :try_start_4
    const/4 v14, 0x5

    throw v1
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :catchall_1
    move-exception v0

    const/4 v14, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v1

    const/4 v14, 0x0

    invoke-virtual {v1, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v14, 0x2

    return-void
.end method
