.class public Lcom/tencent/android/tpush/stat/b;
.super Ljava/lang/Object;


# static fields
.field private static volatile a:Lcom/tencent/android/tpush/stat/b;


# instance fields
.field private volatile b:I

.field private volatile c:Ljava/lang/String;

.field private volatile d:Lorg/apache/http/HttpHost;

.field private e:Landroid/content/Context;

.field private f:Lcom/tencent/android/tpush/stat/b/c;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v0, 0x2

    move v2, v0

    const/4 v1, 0x6

    move v2, v1

    iput v0, p0, Lcom/tencent/android/tpush/stat/b;->b:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b;->c:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b;->d:Lorg/apache/http/HttpHost;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b;->e:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b;->f:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b;->e:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/stat/f;->a(Landroid/content/Context;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/stat/b/b;->b()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/b;->f:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {p0}, Lcom/tencent/android/tpush/stat/b;->f()V

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/b;->d()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/b;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ s~ @l/@t.@~f ~K~~o@@r~i~~~bnbif4~bs  y~1 u t~i~oa@~~o~@ ~@ooo@ @M@@@-l  ~@d @m/~@~   c @~ Sv@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/stat/b;->a:Lcom/tencent/android/tpush/stat/b;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-class v0, Lcom/tencent/android/tpush/stat/b;

    const-class v0, Lcom/tencent/android/tpush/stat/b;

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x1

    sget-object v1, Lcom/tencent/android/tpush/stat/b;->a:Lcom/tencent/android/tpush/stat/b;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v1, Lcom/tencent/android/tpush/stat/b;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/stat/b;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    sput-object v1, Lcom/tencent/android/tpush/stat/b;->a:Lcom/tencent/android/tpush/stat/b;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    sget-object p0, Lcom/tencent/android/tpush/stat/b;->a:Lcom/tencent/android/tpush/stat/b;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-object p0
.end method

.method private f()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    iput v0, p0, Lcom/tencent/android/tpush/stat/b;->b:I

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b;->d:Lorg/apache/http/HttpHost;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b;->c:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b;->c:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object v0
.end method

.method public b()Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iget v0, p0, Lcom/tencent/android/tpush/stat/b;->b:I

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    const/4 v1, 0x1

    const/4 v3, 0x3

    if-ne v0, v1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    return v1
.end method

.method public c()Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/stat/b;->b:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v0, 0x1

    xor-int/2addr v2, v0

    xor-int/2addr v1, v0

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method d()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b;->e:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/tencent/tpns/dataacquisition/DeviceInfos;->isNetworkAvailable(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b;->e:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/tencent/tpns/dataacquisition/DeviceInfos;->getLinkedWay(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b;->c:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->b()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b;->f:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string v2, " TsEKRan:eWNO"

    const-string/jumbo v2, "mN mEan:TKeRW"

    const-string v2, "NETWORK name:"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/b;->c:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Object;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b;->c:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/b/b;->c(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz v0, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x4

    const-string v0, "IWIF"

    const-string v0, "FWII"

    const/4 v4, 0x5

    const-string v0, "FIWI"

    const-string v0, "WIFI"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/b;->c:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v0, 0x1

    move v4, v0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput v0, p0, Lcom/tencent/android/tpush/stat/b;->b:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x6

    const/4 v0, 0x2

    const/4 v4, 0x1

    move v3, v0

    move v3, v0

    iput v0, p0, Lcom/tencent/android/tpush/stat/b;->b:I

    :goto_0
    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b;->e:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/b/b;->b(Landroid/content/Context;)Lorg/apache/http/HttpHost;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b;->d:Lorg/apache/http/HttpHost;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    goto :goto_1

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->b()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz v0, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b;->f:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v1, "oTOeoYociWmTtr E kPlK:nEwsR  sN"

    const-string v1, " RPm sl KTOTEYr NWwoc:eiEenktos"

    const/4 v4, 0x3

    const-string v1, " leEwbt s:so.ne ETiTR YPKrWkcoN"

    const-string v1, "NETWORK TYPE: network is close."

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Object;)V

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/tencent/android/tpush/stat/b;->f()V

    :cond_4
    :goto_1
    const/4 v4, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method public e()V
    .locals 6
    .annotation build Lcom/jg/JgMethodChecked;
        author = 0x1
        fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
        lastDate = "20150316"
        reviewer = 0x3
        vComment = {
            .enum Lcom/jg/EType;->RECEIVERCHECK:Lcom/jg/EType;
        }
    .end annotation

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance v0, Lcom/tencent/android/tpush/stat/b$1;

    const/4 v5, 0x4

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/stat/b$1;-><init>(Lcom/tencent/android/tpush/stat/b;)V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/16 v2, 0x21

    const/4 v5, 0x5

    const-string/jumbo v3, "oCHNGnudaVe.tO_TY.E.oondrEATNCNniIcn"

    const-string v3, "TnndooAGE_CNcHIENCiYT...eNVoaIOntrdn"

    const/4 v5, 0x2

    const-string v3, "CTircoCpHeE.tNTdOnEYoA_INVndNIn.aGn."

    const-string v3, "android.net.conn.CONNECTIVITY_CHANGE"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-lt v1, v2, :cond_0

    :try_start_1
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/b;->e:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    new-instance v2, Landroid/content/IntentFilter;

    const/4 v5, 0x0

    invoke-direct {v2, v3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v3, 0x4

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v1, v0, v2, v3}, Ld3/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/4 v5, 0x2

    const/4 v4, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/b;->e:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v2, Landroid/content/IntentFilter;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v2, v3}, Landroid/content/IntentFilter;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {v1, v0, v2}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string v1, "aarbrrtsqoiBtgcds"

    const-string v1, "edrsobstgBriaratc"

    const/4 v5, 0x1

    const-string/jumbo v1, "trsestsacaroBgdre"

    const-string/jumbo v1, "registerBroadcast"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-void
.end method
