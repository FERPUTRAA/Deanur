.class Lcom/tencent/android/tpush/stat/StatServiceImpl$6;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/stat/lifecycle/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/app/Application;J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J


# direct methods
.method constructor <init>(J)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-wide p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$6;->a:J

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a(Landroid/app/Activity;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@@s//S@s ~i@ @ K~oid~b-a ~@o@~ ~@~b  ~ ~y ti~fo~f ol  @.c~@4~@r ~~m@~@u~@ b1@ n~@ v@~o~@ M~t~@ol"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    return-void
.end method

.method public a(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public b(Landroid/app/Activity;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method

.method public b(Landroid/app/Activity;Landroid/os/Bundle;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method

.method public c(Landroid/app/Activity;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/tencent/android/tpush/stat/b/b;->h(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$6;->a:J

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p1, v0, v1, v2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->inerTrackBeginPage(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    const/4 p1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Z)Z

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->j()Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    xor-int/2addr p1, v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Z)Z

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->k()Ljava/lang/Runnable;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->l()Landroid/os/Handler;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->k()Ljava/lang/Runnable;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-eqz p1, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo v0, "tosnodgenfre ru"

    const/4 v4, 0x5

    const-string/jumbo v0, "nndmtuowegroref"

    const-string/jumbo v0, "went foreground"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(J)J

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->m()Ljava/util/List;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {p1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p1

    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-interface {p1}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-eqz v0, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-interface {p1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    check-cast v0, Lcom/tencent/android/tpush/stat/c;

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-interface {v0}, Lcom/tencent/android/tpush/stat/c;->a()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    goto :goto_0

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string/jumbo v0, "mlirooontdslr eg"

    const-string/jumbo v0, "trimngfoldlseo r"

    const/4 v4, 0x2

    const-string v0, "fdlo bruorgsenlt"

    const-string/jumbo v0, "still foreground"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Object;)V

    :cond_3
    const/4 v4, 0x7

    return-void
.end method

.method public d(Landroid/app/Activity;)V
    .locals 11

    const/4 v10, 0x3

    const/4 v9, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->c()Z

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-nez v0, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x4

    return-void

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/stat/b/b;->h(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    iget-wide v3, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$6;->a:J

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v10, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x4

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x4

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    move-object v1, p1

    move-object v1, p1

    const/4 v10, 0x5

    const/4 v9, 0x4

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/Context;Ljava/lang/String;JJJ)V

    const/4 v10, 0x0

    const/4 p1, 0x3

    const/4 v10, 0x6

    const/4 p1, 0x1

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Z)Z

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->k()Ljava/lang/Runnable;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-eqz p1, :cond_1

    const/4 v10, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->l()Landroid/os/Handler;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->k()Ljava/lang/Runnable;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {p1, v0}, Landroid/os/Handler;->removeCallbacks(Ljava/lang/Runnable;)V

    :cond_1
    const/4 v10, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->l()Landroid/os/Handler;

    move-result-object p1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x5

    new-instance v0, Lcom/tencent/android/tpush/stat/StatServiceImpl$6$1;

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl$6$1;-><init>(Lcom/tencent/android/tpush/stat/StatServiceImpl$6;)V

    const/4 v9, 0x6

    move v10, v9

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Ljava/lang/Runnable;)Ljava/lang/Runnable;

    move-result-object v0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->o()J

    move-result-wide v1

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    return-void
.end method

.method public e(Landroid/app/Activity;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method
