.class Lcom/tencent/android/tpush/stat/StatServiceImpl$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl;->init(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$1;->a:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x4

    const-string v0, "."

    const-string v0, "."

    const/4 v7, 0x5

    const-string v0, "."

    const-string v0, "."

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c()Landroid/content/Context;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v1}, Lcom/tencent/android/tpush/stat/b;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/b;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {v1}, Lcom/tencent/android/tpush/stat/b;->e()V

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$1;->a:Landroid/content/Context;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v2, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x5

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/stat/b/b;->a(Landroid/content/Context;Z)I

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$1;->a:Landroid/content/Context;

    const/4 v7, 0x4

    const/4 v6, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpush/stat/f;->b(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/f;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->a()Lcom/tencent/android/tpush/stat/StatReportStrategy;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x0

    sget-object v2, Lcom/tencent/android/tpush/stat/StatReportStrategy;->APP_LAUNCH:Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-ne v1, v2, :cond_0

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$1;->a:Landroid/content/Context;

    const/4 v6, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v2, -0x1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->commitEvents(Landroid/content/Context;I)Z

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->b()Z

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v1, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string v2, "Issr ie ctstvusATncS.tsiS eeM"

    const-string v2, "ITsi Stvess tsM nSciucrceA.te"

    const/4 v7, 0x7

    const-string/jumbo v2, "ir mnt SecseAsesutIS.i tacMvc"

    const-string v2, "Init MTA StatService success."

    const/4 v6, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v1, v2}, Lcom/tencent/android/tpush/stat/b/c;->h(Ljava/lang/Object;)V

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c()Landroid/content/Context;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {v1}, Lcom/tencent/android/tpush/stat/b/b;->d(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v1, :cond_2

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-nez v2, :cond_3

    :cond_2
    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string v1, "ealmtfd"

    const/4 v7, 0x7

    const-string v1, "eafuold"

    const-string v1, "default"

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    move v7, v6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    move v7, v6

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string v1, ".g.sabtx."

    const-string v1, ".xg.stat."

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$1;->a:Landroid/content/Context;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    const/4 v4, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v2, v3, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {v2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Landroid/content/SharedPreferences;)Landroid/content/SharedPreferences;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$1;->a:Landroid/content/Context;

    const/4 v7, 0x0

    const/4 v6, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string/jumbo v5, "ruoe."

    const-string v5, "..ero"

    const/4 v7, 0x3

    const-string v5, "..prr"

    const-string v5, ".err."

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v2, v3, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x4

    invoke-static {v2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c(Landroid/content/SharedPreferences;)Landroid/content/SharedPreferences;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$1;->a:Landroid/content/Context;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string/jumbo v0, "qc.mo.bs"

    const-string/jumbo v0, "m.osub.c"

    const/4 v7, 0x2

    const-string v0, "c.sumtso"

    const-string v0, ".custom."

    const/4 v6, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v2, v0, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d(Landroid/content/SharedPreferences;)Landroid/content/SharedPreferences;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v2, "orrm u:tttsriie "

    const-string/jumbo v2, "tte:o uar irsirt"

    const/4 v7, 0x5

    const-string/jumbo v2, "sontoir :trireta"

    const-string/jumbo v2, "stat init error:"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v1, v2}, Lcom/tencent/android/tpush/stat/b/c;->f(Ljava/lang/Object;)V

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v1, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    return-void
.end method
