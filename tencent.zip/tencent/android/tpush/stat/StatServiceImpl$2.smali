.class Lcom/tencent/android/tpush/stat/StatServiceImpl$2;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/stat/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Ljava/util/List;Ljava/util/List;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/util/List;


# direct methods
.method constructor <init>(Ljava/util/List;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$2;->a:Ljava/util/List;

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "i@s~  @@~/@@~@vom/nl@~o ~od~Kt~i@a.f~fb@ @  o y~@4 ~ @@  ~~-1~@iSM~ b ~@l~ ~c oost@@@u  @~b~r~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$2;->a:Ljava/util/List;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->c(Ljava/util/List;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public b()V
    .locals 3

    const/4 v1, 0x1

    move v2, v1

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$2;->a:Ljava/util/List;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d(Ljava/util/List;)V

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method
