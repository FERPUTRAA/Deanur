.class Lcom/tencent/android/tpush/stat/StatServiceImpl$16;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/stat/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Lcom/tencent/android/tpush/stat/event/Event;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/stat/event/Event;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/stat/event/Event;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$16;->a:Lcom/tencent/android/tpush/stat/event/Event;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o@sK.cl /@u~ta @b@ @~  @ ~~no@M~f@- ~@@i ~so~@ l~S y@r~@1o4~ fv~~o@~i~  o ~~ ~@@mb~t@i~~~/ @b@@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->e()Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method public b()V
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->e()Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0}, Ljava/util/concurrent/atomic/AtomicInteger;->getAndIncrement()I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->f()Ljava/lang/Integer;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-ge v0, v1, :cond_0

    const/4 v7, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    new-instance v1, Lcom/tencent/android/tpush/stat/StatServiceImpl$16$1;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/stat/StatServiceImpl$16$1;-><init>(Lcom/tencent/android/tpush/stat/StatServiceImpl$16;)V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->e()Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v2}, Ljava/util/concurrent/atomic/AtomicInteger;->get()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    int-to-long v2, v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x1

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    mul-long/2addr v2, v4

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2, v3}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;J)Z

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->e()Ljava/util/concurrent/atomic/AtomicInteger;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    const/4 v1, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/util/concurrent/atomic/AtomicInteger;->set(I)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    const/4 v0, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-array v0, v0, [Lcom/tencent/android/tpush/stat/event/Event;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$16;->a:Lcom/tencent/android/tpush/stat/event/Event;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    aput-object v2, v0, v1

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {v0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Ljava/util/List;)V

    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    return-void
.end method
