.class public final Lcom/tencent/android/tpush/stat/a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Thread$UncaughtExceptionHandler;


# static fields
.field private static a:Lcom/tencent/android/tpush/stat/b/c;

.field private static volatile b:Lcom/tencent/android/tpush/stat/a;

.field private static c:Ljava/lang/Thread$UncaughtExceptionHandler;


# instance fields
.field private d:Z

.field private e:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/stat/b/b;->b()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    sput-object v0, Lcom/tencent/android/tpush/stat/a;->a:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    sput-object v0, Lcom/tencent/android/tpush/stat/a;->b:Lcom/tencent/android/tpush/stat/a;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    sput-object v0, Lcom/tencent/android/tpush/stat/a;->c:Ljava/lang/Thread$UncaughtExceptionHandler;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-boolean v0, p0, Lcom/tencent/android/tpush/stat/a;->d:Z

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/a;->e:Landroid/content/Context;

    const/4 v2, 0x0

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/a;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " csy@ 4 ~~~@l~ bi@Sf ~@ @~@ofn~@@d.ov~@~   ~@/@ r@ -oK~ ob@o~bis~~~m~t @~ @~M~@1 @i~/@~t@a@o u~l"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/stat/a;->b:Lcom/tencent/android/tpush/stat/a;

    const/4 v3, 0x2

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-class v0, Lcom/tencent/android/tpush/stat/a;

    const-class v0, Lcom/tencent/android/tpush/stat/a;

    const/4 v3, 0x2

    const-class v0, Lcom/tencent/android/tpush/stat/a;

    const-class v0, Lcom/tencent/android/tpush/stat/a;

    const/4 v3, 0x3

    monitor-enter v0

    :try_start_0
    sget-object v1, Lcom/tencent/android/tpush/stat/a;->b:Lcom/tencent/android/tpush/stat/a;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    new-instance v1, Lcom/tencent/android/tpush/stat/a;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/stat/a;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    sput-object v1, Lcom/tencent/android/tpush/stat/a;->b:Lcom/tencent/android/tpush/stat/a;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x6

    const/4 v2, 0x3

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x2

    sget-object p0, Lcom/tencent/android/tpush/stat/a;->b:Lcom/tencent/android/tpush/stat/a;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0
.end method


# virtual methods
.method public a()V
    .locals 5

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/stat/a;->c:Ljava/lang/Thread$UncaughtExceptionHandler;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {}, Ljava/lang/Thread;->getDefaultUncaughtExceptionHandler()Ljava/lang/Thread$UncaughtExceptionHandler;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    sput-object v0, Lcom/tencent/android/tpush/stat/a;->c:Ljava/lang/Thread$UncaughtExceptionHandler;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v0, Lcom/tencent/android/tpush/stat/a;->b:Lcom/tencent/android/tpush/stat/a;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {v0}, Ljava/lang/Thread;->setDefaultUncaughtExceptionHandler(Ljava/lang/Thread$UncaughtExceptionHandler;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/stat/a;->a:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string v2, "el mjuers pnvatahadc rh:as"

    const-string v2, " aspter:ench dh aau sljvra"

    const/4 v4, 0x0

    const-string/jumbo v2, "teh oa snd:evarucras lpja "

    const-string/jumbo v2, "set up java crash handler:"

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    sget-object v2, Lcom/tencent/android/tpush/stat/a;->b:Lcom/tencent/android/tpush/stat/a;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/stat/b/c;->h(Ljava/lang/Object;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-void
.end method

.method public uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-boolean v0, p0, Lcom/tencent/android/tpush/stat/a;->d:Z

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    sget-object p1, Lcom/tencent/android/tpush/stat/a;->a:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string/jumbo v1, "lire btudpcxun:t hm eeanlhaotneeghyda "

    const-string/jumbo v1, "xtlmn ochrh: ee dgtnuitaehau edaapneyl"

    const/4 v3, 0x5

    const-string v1, "gaxueeuo euntrteinldpahlae ahh tccy:n "

    const-string v1, "already handle the uncaugth exception:"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1, p2}, Lcom/tencent/android/tpush/stat/b/c;->f(Ljava/lang/Object;)V

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v2, 0x6

    move v3, v2

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-boolean v0, p0, Lcom/tencent/android/tpush/stat/a;->d:Z

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/android/tpush/stat/a;->a:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v1, "shpcohtpcaaac r"

    const-string v1, "arpaah pcthcsc "

    const-string v1, "catch app crash"

    const/4 v3, 0x3

    const/4 v2, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/stat/b/c;->h(Ljava/lang/Object;)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/a;->e:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Landroid/content/Context;Ljava/lang/Throwable;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/stat/a;->c:Ljava/lang/Thread$UncaughtExceptionHandler;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/stat/a;->a:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, "duCir xiqlaghbtlhouenecrenaph  tn aatl.coln g"

    const-string v1, " .lncbproagiudChtnohrl ea t cxlenunih egtelaa"

    const/4 v3, 0x5

    const-string v1, " lshctl.aahnpundtilen o aCheelnruig aieortgxc"

    const-string v1, "Call the original uncaught exception handler."

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/stat/b/c;->h(Ljava/lang/Object;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object v0, Lcom/tencent/android/tpush/stat/a;->c:Ljava/lang/Thread$UncaughtExceptionHandler;

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x7

    instance-of v1, v0, Lcom/tencent/android/tpush/stat/a;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-nez v1, :cond_1

    const/4 v3, 0x7

    invoke-interface {v0, p1, p2}, Ljava/lang/Thread$UncaughtExceptionHandler;->uncaughtException(Ljava/lang/Thread;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x1

    return-void
.end method
