.class Lcom/tencent/android/tpush/stat/d$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/stat/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field a:I

.field b:Lorg/json/JSONObject;

.field c:Ljava/lang/String;

.field d:I


# direct methods
.method constructor <init>(I)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lorg/json/JSONObject;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/d$a;->b:Lorg/json/JSONObject;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/d$a;->c:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput v0, p0, Lcom/tencent/android/tpush/stat/d$a;->d:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput p1, p0, Lcom/tencent/android/tpush/stat/d$a;->a:I

    const/4 v2, 0x3

    return-void
.end method
