.class Lcom/tencent/android/tpush/stat/StatServiceImpl$16$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl$16;->b()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/stat/StatServiceImpl$16;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/stat/StatServiceImpl$16;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$16$1;->a:Lcom/tencent/android/tpush/stat/StatServiceImpl$16;

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " rs@~@Mfu @ t ~@. n@oa~~~v@@~i@/@b ~@l ~~~@b~ools~@ f -/i~4~@@~1 ~ d@o~tK@@o~o  ~S~yb@ ~~@   mi@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$16$1;->a:Lcom/tencent/android/tpush/stat/StatServiceImpl$16;

    const/4 v2, 0x0

    const/4 v1, 0x5

    iget-object v0, v0, Lcom/tencent/android/tpush/stat/StatServiceImpl$16;->a:Lcom/tencent/android/tpush/stat/event/Event;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Lcom/tencent/android/tpush/stat/event/Event;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-void
.end method
