.class public final Lcom/tencent/android/tpush/stat/b/c;
.super Ljava/lang/Object;


# instance fields
.field private a:Ljava/lang/String;

.field private b:Z

.field private c:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string/jumbo v0, "lssaued"

    const-string v0, "easdutl"

    const/4 v2, 0x6

    const-string/jumbo v0, "ldamtfu"

    const-string v0, "default"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b/c;->a:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-boolean v0, p0, Lcom/tencent/android/tpush/stat/b/c;->b:Z

    const/4 v2, 0x4

    const/4 v0, 0x2

    move v1, v0

    move v1, v0

    const/4 v2, 0x7

    iput v0, p0, Lcom/tencent/android/tpush/stat/b/c;->c:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    const/4 v0, 0x1

    const/4 v2, 0x0

    iput-boolean v0, p0, Lcom/tencent/android/tpush/stat/b/c;->b:Z

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x2

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput v0, p0, Lcom/tencent/android/tpush/stat/b/c;->c:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/b/c;->a:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method private b()Ljava/lang/String;
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, " b~@o1v ou @.i~@o ~~m bb- @~/ofy t/@cs4lS~tr@l@~ @@@io@~ ~~of @~~o@~M@~a@  n~~@K~i@  ~@~ d~ @~@ "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x4

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/Thread;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    const/4 v1, 0x0

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    if-nez v0, :cond_0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    return-object v1

    :cond_0
    const/4 v8, 0x6

    array-length v2, v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/4 v3, 0x0

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-ge v3, v2, :cond_4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    aget-object v4, v0, v3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->isNativeMethod()Z

    move-result v5

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-eqz v5, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    goto :goto_1

    :cond_1
    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x1

    const/4 v7, 0x3

    const-class v6, Ljava/lang/Thread;

    const-class v6, Ljava/lang/Thread;

    const/4 v8, 0x5

    const-class v6, Ljava/lang/Thread;

    const-class v6, Ljava/lang/Thread;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v6}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x0

    const/4 v7, 0x1

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x0

    if-eqz v5, :cond_2

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    goto :goto_1

    :cond_2
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->getClassName()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-class v6, Lcom/tencent/android/tpush/stat/b/c;

    const-class v6, Lcom/tencent/android/tpush/stat/b/c;

    const/4 v8, 0x2

    const-class v6, Lcom/tencent/android/tpush/stat/b/c;

    const-class v6, Lcom/tencent/android/tpush/stat/b/c;

    const/4 v8, 0x6

    const/4 v7, 0x2

    invoke-virtual {v6}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-eqz v5, :cond_3

    :goto_1
    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x3

    goto :goto_0

    :cond_3
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const-string v1, "["

    const-string v1, "["

    const/4 v8, 0x7

    const-string v1, "["

    const-string v1, "["

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-virtual {v1}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    const-string v1, "("

    const-string v1, "("

    const/4 v8, 0x0

    const-string v1, "("

    const-string v1, "("

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-static {}, Ljava/lang/Thread;->currentThread()Ljava/lang/Thread;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v1}, Ljava/lang/Thread;->getId()J

    move-result-wide v1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v1, ": )"

    const-string v1, " :)"

    const/4 v8, 0x3

    const-string v1, "): "

    const-string v1, "): "

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->getFileName()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const-string v1, ":"

    const-string v1, ":"

    const/4 v8, 0x7

    const-string v1, ":"

    const-string v1, ":"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {v4}, Ljava/lang/StackTraceElement;->getLineNumber()I

    move-result v1

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    const-string v1, "]"

    const-string v1, "]"

    const/4 v8, 0x6

    const-string v1, "]"

    const-string v1, "]"

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x3

    return-object v0

    :cond_4
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    return-object v1
.end method


# virtual methods
.method public a(Ljava/lang/Object;)V
    .locals 4

    iget v0, p0, Lcom/tencent/android/tpush/stat/b/c;->c:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 v1, 0x4

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-gt v0, v1, :cond_1

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpush/stat/b/c;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string v0, "-  "

    const-string v0, "  -"

    const/4 v3, 0x6

    const-string v0, " - "

    const-string v0, " - "

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/c;->a:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v3, 0x5

    return-void
.end method

.method public a(Ljava/lang/Throwable;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/android/tpush/stat/b/c;->c:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    or-int/2addr v3, v2

    if-gt v0, v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/c;->a:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string v1, ""

    const/4 v3, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void
.end method

.method public a(Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-boolean p1, p0, Lcom/tencent/android/tpush/stat/b/c;->b:Z

    const/4 v1, 0x6

    const/4 v0, 0x2

    return-void
.end method

.method public a()Z
    .locals 3

    const/4 v1, 0x3

    const/4 v2, 0x6

    iget-boolean v0, p0, Lcom/tencent/android/tpush/stat/b/c;->b:Z

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x3

    return v0
.end method

.method public b(Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/b/c;->a()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->a(Ljava/lang/Object;)V

    :cond_0
    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public b(Ljava/lang/Throwable;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/b/c;->a()Z

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->a(Ljava/lang/Throwable;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public c(Ljava/lang/Object;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget v0, p0, Lcom/tencent/android/tpush/stat/b/c;->c:I

    const/4 v2, 0x5

    move v3, v2

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-gt v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/stat/b/c;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string v0, "  -"

    const/4 v3, 0x5

    const-string v0, "-  "

    const-string v0, " - "

    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/c;->a:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method

.method public d(Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/b/c;->a()Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->c(Ljava/lang/Object;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method public e(Ljava/lang/Object;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    iget v0, p0, Lcom/tencent/android/tpush/stat/b/c;->c:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-gt v0, v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/stat/b/c;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v0, " - "

    const-string v0, " - "

    const/4 v3, 0x0

    const-string v0, "-  "

    const-string v0, " - "

    const/4 v3, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/c;->a:Ljava/lang/String;

    const/4 v3, 0x1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method public f(Ljava/lang/Object;)V
    .locals 3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/b/c;->a()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->e(Ljava/lang/Object;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public g(Ljava/lang/Object;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/stat/b/c;->c:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x3

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-gt v0, v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpush/stat/b/c;->b()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string v0, " - "

    const-string v0, " - "

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :goto_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/c;->a:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-void
.end method

.method public h(Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Lcom/tencent/android/tpush/stat/b/c;->a()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->g(Ljava/lang/Object;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-void
.end method
