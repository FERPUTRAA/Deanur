.class Lcom/tencent/android/tpush/stat/b/a$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/stat/b/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field a:Ljava/lang/String;

.field b:Landroid/util/DisplayMetrics;

.field c:I

.field d:Ljava/lang/String;

.field e:Ljava/lang/String;

.field f:Ljava/lang/String;

.field g:Ljava/lang/String;

.field h:Ljava/lang/String;

.field i:I

.field j:Ljava/lang/String;

.field k:Landroid/content/Context;

.field l:J

.field private m:Ljava/lang/String;

.field private n:Ljava/lang/String;


# direct methods
.method private constructor <init>(Landroid/content/Context;J)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    iput v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->c:I

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    sget-object v0, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->d:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/util/Locale;->getLanguage()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->e:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->i:I

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x7

    xor-int/2addr v2, v0

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->j:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->m:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->n:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->l:J

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/tencent/tpns/dataacquisition/DeviceInfos;->getDisplayMetrics(Landroid/content/Context;)Landroid/util/DisplayMetrics;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->b:Landroid/util/DisplayMetrics;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p1, p2, p3}, Lcom/tencent/android/tpush/stat/b/b;->b(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->a:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v3, 0x6

    invoke-static {p1}, Lcom/tencent/tpns/dataacquisition/CustomDeviceInfos;->getSimOperator(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->f:Ljava/lang/String;

    const/4 v3, 0x3

    invoke-static {}, Ljava/util/TimeZone;->getDefault()Ljava/util/TimeZone;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/util/TimeZone;->getID()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->g:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/tencent/tpns/dataacquisition/DeviceInfos;->getExternalStorageInfo(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->h:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->j:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/tencent/tpns/dataacquisition/DeviceInfos;->getSystemMemory(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->m:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/tpns/dataacquisition/DeviceInfos;->getRomMemory()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->n:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    iput-wide p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->l:J

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-void
.end method

.method synthetic constructor <init>(Landroid/content/Context;JLcom/tencent/android/tpush/stat/b/a$1;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0, p1, p2, p3}, Lcom/tencent/android/tpush/stat/b/a$a;-><init>(Landroid/content/Context;J)V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method a(Lorg/json/JSONObject;Ljava/lang/Thread;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~msr~ l~ ~~~f@l@@ bd@@ n~@S  o~ b4~i~~o ~M~b@@ ~@@ tu@@~i~o v .@o@asf~  1~@i c/K~ ty@o/@~o@~-@@~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    if-nez p2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->b:Landroid/util/DisplayMetrics;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz p2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->b:Landroid/util/DisplayMetrics;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    iget v0, v0, Landroid/util/DisplayMetrics;->widthPixels:I

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    const-string v0, "*"

    const-string v0, "*"

    const-string v0, "*"

    const-string v0, "*"

    const/4 v5, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->b:Landroid/util/DisplayMetrics;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget v1, v1, Landroid/util/DisplayMetrics;->heightPixels:I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const-string/jumbo v1, "rs"

    const-string/jumbo v1, "rs"

    const/4 v5, 0x3

    const-string/jumbo v1, "rs"

    const-string/jumbo v1, "sr"

    const/4 v4, 0x0

    or-int/2addr v5, v4

    invoke-virtual {p1, v1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/b/a$a;->b:Landroid/util/DisplayMetrics;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget v1, v1, Landroid/util/DisplayMetrics;->xdpi:F

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->b:Landroid/util/DisplayMetrics;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget v0, v0, Landroid/util/DisplayMetrics;->ydpi:F

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(F)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo v0, "pid"

    const-string v0, "dip"

    const/4 v5, 0x1

    const-string/jumbo v0, "pid"

    const-string v0, "dpi"

    const/4 v4, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p1, v0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x3

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-static {p2}, Lcom/tencent/android/tpush/stat/b;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/b;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p2}, Lcom/tencent/android/tpush/stat/b;->b()Z

    move-result p2

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-eqz p2, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance p2, Lorg/json/JSONObject;

    const/4 v5, 0x1

    const/4 v4, 0x3

    invoke-direct {p2}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x2

    or-int/2addr v5, v4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    invoke-static {v0}, Lcom/tencent/tpns/dataacquisition/CustomDeviceInfos;->getWiFiBBSID(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string/jumbo v1, "sb"

    const-string v1, "bs"

    const/4 v5, 0x6

    const-string v1, "bs"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {p2, v1, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/tencent/tpns/dataacquisition/CustomDeviceInfos;->getWiFiSSID(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const-string/jumbo v1, "ss"

    const-string/jumbo v1, "ss"

    const/4 v5, 0x4

    const-string/jumbo v1, "ss"

    const-string/jumbo v1, "ss"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p2, v1, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p2}, Lorg/json/JSONObject;->length()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    if-lez v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo v0, "wf"

    const/4 v5, 0x6

    const-string v0, "fw"

    const-string/jumbo v0, "wf"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p2}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {p1, v0, p2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/16 v0, 0xa

    const/4 v5, 0x5

    invoke-static {p2, v0}, Lcom/tencent/tpns/dataacquisition/CustomDeviceInfos;->getWifiTopN(Landroid/content/Context;I)Lorg/json/JSONArray;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz p2, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p2}, Lorg/json/JSONArray;->length()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-lez v0, :cond_5

    const/4 v5, 0x2

    const-string/jumbo v0, "iwsfsl"

    const/4 v5, 0x5

    const-string/jumbo v0, "iwtmfl"

    const-string/jumbo v0, "wflist"

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    invoke-virtual {p2}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x3

    invoke-static {p1, v0, p2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    goto/16 :goto_0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string/jumbo v0, "tnh"

    const-string/jumbo v0, "tnh"

    const/4 v5, 0x6

    const-string/jumbo v0, "thn"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p2}, Ljava/lang/Thread;->getName()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p1, v0, p2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->m:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {p2}, Lcom/tencent/android/tpush/stat/b/b;->c(Ljava/lang/String;)Z

    move-result p2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v0, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    const/4 v1, 0x2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v2, "/"

    const-string v2, "/"

    const/4 v5, 0x4

    const-string v2, "/"

    const-string v2, "/"

    const/4 v4, 0x2

    move v5, v4

    if-eqz p2, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->m:Ljava/lang/String;

    const/4 v5, 0x5

    invoke-virtual {p2, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    array-length p2, p2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-ne p2, v1, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->m:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p2, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    aget-object p2, p2, v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string/jumbo v3, "rmfa"

    const-string v3, "farm"

    const/4 v5, 0x0

    const-string v3, "fmar"

    const-string v3, "fram"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {p1, v3, p2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->n:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {p2}, Lcom/tencent/android/tpush/stat/b/b;->c(Ljava/lang/String;)Z

    move-result p2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-eqz p2, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->n:Ljava/lang/String;

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {p2, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x1

    array-length p2, p2

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    if-ne p2, v1, :cond_4

    const/4 v5, 0x1

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->n:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p2, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    aget-object p2, p2, v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v0, "omrf"

    const-string/jumbo v0, "omfr"

    const-string/jumbo v0, "mrof"

    const-string v0, "from"

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p1, v0, p2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-static {p2}, Lcom/tencent/tpns/dataacquisition/CustomDeviceInfos;->getFacilityIdentity(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v0, "iu"

    const-string/jumbo v0, "iu"

    const/4 v5, 0x6

    const-string/jumbo v0, "iu"

    const-string/jumbo v0, "ui"

    const/4 v5, 0x0

    invoke-virtual {p1, v0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p2}, Lcom/tencent/android/tpush/XGPushConfig;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string/jumbo v0, "imd"

    const-string/jumbo v0, "imd"

    const/4 v5, 0x5

    const-string/jumbo v0, "mdi"

    const-string/jumbo v0, "mid"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {p1, v0, p2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x2

    invoke-static {p2}, Lcom/tencent/android/tpush/stat/b/b;->d(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v0, "pnc"

    const-string/jumbo v0, "npc"

    const/4 v5, 0x2

    const-string/jumbo v0, "pcn"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {p1, v0, p2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string/jumbo p2, "son"

    const/4 v5, 0x4

    const-string/jumbo p2, "son"

    const-string/jumbo p2, "osn"

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    sget-object v0, Landroid/os/Build$VERSION;->RELEASE:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const-string p2, "av"

    const-string p2, "av"

    const/4 v5, 0x7

    const-string/jumbo p2, "va"

    const-string p2, "av"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->a:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string p2, "ch"

    const-string p2, "ch"

    const/4 v5, 0x5

    const-string p2, "ch"

    const-string p2, "ch"

    const/4 v5, 0x5

    const/4 v4, 0x1

    sget-object v0, Lcom/tencent/android/tpush/stat/event/Event;->channel:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo p2, "mf"

    const-string/jumbo p2, "mf"

    const/4 v5, 0x6

    const-string/jumbo p2, "mf"

    const-string/jumbo p2, "mf"

    const/4 v5, 0x6

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->d:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-wide v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->l:J

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    cmp-long p2, v0, v2

    const/4 v4, 0x0

    move v5, v4

    if-lez p2, :cond_6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->k:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p2, v0, v1}, Lcom/tencent/android/tpush/stat/b/b;->a(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo v0, "vs"

    const-string/jumbo v0, "sv"

    const/4 v5, 0x6

    const-string/jumbo v0, "sv"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {p1, v0, p2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    :cond_6
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo p2, "sod"

    const-string/jumbo p2, "osd"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    sget-object v0, Landroid/os/Build;->DISPLAY:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo p2, "ropd"

    const-string p2, "dorp"

    const/4 v5, 0x4

    const-string/jumbo p2, "prdo"

    const-string/jumbo p2, "prod"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    sget-object v0, Landroid/os/Build;->PRODUCT:Ljava/lang/String;

    const/4 v5, 0x4

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string p2, "asgt"

    const-string p2, "gsta"

    const/4 v5, 0x1

    const-string/jumbo p2, "tgas"

    const-string/jumbo p2, "tags"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    sget-object v0, Landroid/os/Build;->TAGS:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string p2, "di"

    const-string p2, "id"

    const-string p2, "di"

    const-string p2, "id"

    const/4 v4, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v0, Landroid/os/Build;->ID:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    shl-int/2addr v5, v4

    const-string p2, "fng"

    const-string p2, "gnf"

    const/4 v5, 0x6

    const-string/jumbo p2, "ngf"

    const-string p2, "fng"

    const/4 v5, 0x7

    sget-object v0, Landroid/os/Build;->FINGERPRINT:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    iget p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->c:I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {p2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo v0, "ov"

    const-string/jumbo v0, "vo"

    const/4 v5, 0x4

    const-string/jumbo v0, "ov"

    const-string/jumbo v0, "ov"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p1, v0, p2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo p2, "os"

    const/4 v4, 0x3

    move v5, v4

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {p1, p2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo p2, "op"

    const-string/jumbo p2, "op"

    const/4 v5, 0x2

    const-string/jumbo p2, "po"

    const-string/jumbo p2, "op"

    const/4 v4, 0x4

    and-int/2addr v5, v4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->f:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const-string/jumbo p2, "lg"

    const-string/jumbo p2, "lg"

    const/4 v5, 0x1

    const-string/jumbo p2, "lg"

    const-string/jumbo p2, "lg"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->e:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo p2, "tz"

    const-string/jumbo p2, "tz"

    const/4 v5, 0x2

    const-string/jumbo p2, "zt"

    const-string/jumbo p2, "tz"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->g:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    iget p2, p0, Lcom/tencent/android/tpush/stat/b/a$a;->i:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-eqz p2, :cond_7

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo v0, "jb"

    const-string/jumbo v0, "jb"

    const/4 v5, 0x5

    const-string/jumbo v0, "jb"

    const-string/jumbo v0, "jb"

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p1, v0, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    :cond_7
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string p2, "ds"

    const-string/jumbo p2, "sd"

    const/4 v5, 0x6

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->h:Ljava/lang/String;

    const/4 v4, 0x2

    move v5, v4

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string p2, "abi"

    const-string p2, "abi"

    const/4 v5, 0x6

    const-string p2, "abi"

    const-string p2, "abi"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-object v0, Landroid/os/Build;->CPU_ABI:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string p2, "arm"

    const-string/jumbo p2, "ram"

    const/4 v5, 0x2

    const/4 v4, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->m:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo p2, "rom"

    const-string/jumbo p2, "orm"

    const-string/jumbo p2, "rom"

    const-string/jumbo p2, "rom"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/b/a$a;->n:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    shl-int/2addr v5, v4

    return-void
.end method
