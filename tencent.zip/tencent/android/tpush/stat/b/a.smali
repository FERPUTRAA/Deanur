.class public Lcom/tencent/android/tpush/stat/b/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/stat/b/a$a;
    }
.end annotation


# static fields
.field static a:Lcom/tencent/android/tpush/stat/b/a$a;

.field private static d:Lcom/tencent/android/tpush/stat/b/c;

.field private static e:Lorg/json/JSONObject;


# instance fields
.field b:Ljava/lang/Integer;

.field c:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/stat/b/b;->b()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    sput-object v0, Lcom/tencent/android/tpush/stat/b/a;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/android/tpush/stat/b/a;->e:Lorg/json/JSONObject;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;J)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b/a;->b:Ljava/lang/Integer;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/stat/b/a;->c:Ljava/lang/String;

    :try_start_0
    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p1, p2, p3}, Lcom/tencent/android/tpush/stat/b/a;->a(Landroid/content/Context;J)Lcom/tencent/android/tpush/stat/b/a$a;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p2}, Lcom/tencent/tpns/dataacquisition/DeviceInfos;->getTelephonyNetworkType(Landroid/content/Context;)Ljava/lang/Integer;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpush/stat/b/a;->b:Ljava/lang/Integer;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/stat/b;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/stat/b;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/stat/b;->a()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/b/a;->c:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object p2, Lcom/tencent/android/tpush/stat/b/a;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {p2, p1}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method static declared-synchronized a(Landroid/content/Context;J)Lcom/tencent/android/tpush/stat/b/a$a;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~us~b~@~@~lv@@~o ~o@~./~MS~1  ~~ a~@Kf~o @sc~o  ~ i-i@  @@ft@t ~@o@n~4@@d~~~/l @o@y r@m@i ~ b @ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x2

    const-class v0, Lcom/tencent/android/tpush/stat/b/a;

    const-class v0, Lcom/tencent/android/tpush/stat/b/a;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    sget-object v1, Lcom/tencent/android/tpush/stat/b/a;->a:Lcom/tencent/android/tpush/stat/b/a$a;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v1, Lcom/tencent/android/tpush/stat/b/a$a;

    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-direct {v1, p0, p1, p2, v2}, Lcom/tencent/android/tpush/stat/b/a$a;-><init>(Landroid/content/Context;JLcom/tencent/android/tpush/stat/b/a$1;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    sput-object v1, Lcom/tencent/android/tpush/stat/b/a;->a:Lcom/tencent/android/tpush/stat/b/a$a;

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    sget-object p0, Lcom/tencent/android/tpush/stat/b/a;->a:Lcom/tencent/android/tpush/stat/b/a$a;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    monitor-exit v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    throw p0
.end method


# virtual methods
.method public a(Lorg/json/JSONObject;Ljava/lang/Thread;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    sget-object v1, Lcom/tencent/android/tpush/stat/b/a;->a:Lcom/tencent/android/tpush/stat/b/a$a;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    invoke-virtual {v1, v0, p2}, Lcom/tencent/android/tpush/stat/b/a$a;->a(Lorg/json/JSONObject;Ljava/lang/Thread;)V

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo v1, "nc"

    const-string v1, "cn"

    const/4 v4, 0x0

    const-string/jumbo v1, "nc"

    const-string v1, "cn"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/b/a;->c:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {v0, v1, v2}, Lcom/tencent/android/tpush/stat/b/e;->a(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/b/a;->b:Ljava/lang/Integer;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v1, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo v2, "nt"

    const-string/jumbo v2, "tn"

    const-string/jumbo v2, "tn"

    const-string/jumbo v2, "tn"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez p2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo p2, "ve"

    const/4 v4, 0x5

    const-string/jumbo p2, "ve"

    const-string p2, "ev"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1, p2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    goto :goto_0

    :cond_2
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo p2, "rskmr"

    const-string/jumbo p2, "rksre"

    const/4 v4, 0x3

    const-string/jumbo p2, "vrkro"

    const-string p2, "errkv"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1, p2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :goto_0
    const/4 v4, 0x5

    sget-object p2, Lcom/tencent/android/tpush/stat/b/a;->e:Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    if-eqz p2, :cond_3

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p2}, Lorg/json/JSONObject;->length()I

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-lez p2, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string p2, "eav"

    const-string p2, "eva"

    const/4 v4, 0x1

    const-string p2, "ave"

    const-string p2, "eva"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    sget-object v0, Lcom/tencent/android/tpush/stat/b/a;->e:Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p1, p2, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_1

    :catchall_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    sget-object p2, Lcom/tencent/android/tpush/stat/b/a;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p2, p1}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :cond_3
    :goto_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-void
.end method
