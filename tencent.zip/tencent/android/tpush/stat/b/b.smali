.class public Lcom/tencent/android/tpush/stat/b/b;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/String;

.field private static b:Ljava/lang/String;

.field private static c:Ljava/lang/String;

.field private static d:Ljava/util/Random;

.field private static e:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Long;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static f:Ljava/lang/String;

.field private static g:Lcom/tencent/android/tpush/stat/b/c;

.field private static h:Ljava/lang/String;

.field private static i:J

.field private static j:I

.field private static k:Ljava/lang/String;

.field private static l:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/16 v1, 0xa

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    sput-object v0, Lcom/tencent/android/tpush/stat/b/b;->e:Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v0, ""

    const/4 v3, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    sput-object v0, Lcom/tencent/android/tpush/stat/b/b;->f:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    sput-object v0, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    sput-object v0, Lcom/tencent/android/tpush/stat/b/b;->h:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x2

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    sput-wide v0, Lcom/tencent/android/tpush/stat/b/b;->i:J

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    sput v0, Lcom/tencent/android/tpush/stat/b/b;->j:I

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v0, "ATs_sRV_EFSAAMITTC__T_"

    const-string v0, "AFs_SAE_I_T_MRTTI_TCAV"

    const/4 v3, 0x3

    const-string v0, "I__mTITVC_RFAE_TS_MATA"

    const-string v0, "__MTA_FIRST_ACTIVATE__"

    const/4 v2, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    sput-object v0, Lcom/tencent/android/tpush/stat/b/b;->k:Ljava/lang/String;

    const/4 v2, 0x7

    xor-int/2addr v3, v2

    const/4 v0, -0x1

    const/4 v3, 0x0

    sput v0, Lcom/tencent/android/tpush/stat/b/b;->l:I

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-void
.end method

.method public static a()I
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "m~nlo~M~@cd y@~.i~~ ~@4 ~@~otfoo@v ~@o@@ /@~ ~silo@@@ S~~~ ~i u~~K  ba@r @@1/o @@~ @  ~b~@bt~@ f"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/b/b;->d()Ljava/util/Random;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const v1, 0x7fffffff

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/util/Random;->nextInt(I)I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    return v0
.end method

.method public static a(Landroid/content/Context;Z)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    if-eqz p1, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/b/b;->g(Landroid/content/Context;)I

    move-result p0

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x6

    sput p0, Lcom/tencent/android/tpush/stat/b/b;->j:I

    :cond_0
    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    sget p0, Lcom/tencent/android/tpush/stat/b/b;->j:I

    const/4 v1, 0x6

    return p0
.end method

.method public static a(Ljava/lang/String;Ljava/lang/String;IILjava/lang/Long;)Ljava/lang/Long;
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x3

    if-eqz p0, :cond_4

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    if-nez p1, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    goto/16 :goto_1

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x2

    const-string v0, "."

    const-string v0, "."

    const/4 v9, 0x2

    const-string v0, "."

    const-string v0, "."

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    const/4 v1, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x1

    if-nez v0, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-string/jumbo v0, "|"

    const-string/jumbo v0, "|"

    const/4 v9, 0x1

    const-string/jumbo v0, "|"

    const-string/jumbo v0, "|"

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-eqz v0, :cond_2

    :cond_1
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 v0, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    new-array v0, v0, [Ljava/lang/Object;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    aput-object p1, v0, v1

    const/4 v9, 0x7

    const/4 v8, 0x3

    const-string/jumbo p1, "s/%/"

    const-string p1, "/s/%"

    const/4 v9, 0x4

    const-string p1, "/%s/"

    const-string p1, "\\%s"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {p1, v0}, Ljava/lang/String;->format(Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    :cond_2
    const/4 v9, 0x2

    const/4 v8, 0x6

    invoke-virtual {p0, p1}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    array-length p1, p0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-ne p1, p3, :cond_4

    const/4 v8, 0x1

    move v9, v8

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    :try_start_0
    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    array-length p3, p0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-ge v1, p3, :cond_3

    const/4 v9, 0x7

    const/4 v8, 0x6

    int-to-long v2, p2

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v4

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x2

    aget-object p1, p0, v1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static {p1}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p1

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {p1}, Ljava/lang/Long;->longValue()J

    move-result-wide v6

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    add-long/2addr v4, v6

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    mul-long/2addr v2, v4

    const/4 v9, 0x7

    const/4 v8, 0x1

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    goto :goto_0

    :cond_3
    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x6

    return-object p1

    :catch_0
    :cond_4
    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    return-object p4
.end method

.method public static a(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const-string p0, ".4.1mb3"

    const-string p0, "43.m..1"

    const/4 v2, 0x0

    const-string p0, ".4391.u"

    const-string p0, "1.4.3.9"
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string p0, "0"

    const-string p0, "0"

    const-string p0, "0"

    const-string p0, "0"

    const/4 v2, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method public static a(Landroid/content/Context;J)Ljava/lang/String;
    .locals 5

    :try_start_0
    const/4 v3, 0x4

    move v4, v3

    sget-object v0, Lcom/tencent/android/tpush/stat/b/b;->e:Ljava/util/Map;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    sget-object p0, Lcom/tencent/android/tpush/stat/b/b;->e:Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-interface {p0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    check-cast p0, Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object p0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz p0, :cond_2

    const/4 v4, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/g;->a(Landroid/content/Context;)Ljava/util/List;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz p0, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v0, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    check-cast v0, Landroid/content/pm/ResolveInfo;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v0, v0, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v0, v0, Landroid/content/pm/ActivityInfo;->packageName:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/service/cache/CacheManager;->getRegisterInfoByPkgName(Ljava/lang/String;)Lcom/tencent/android/tpush/data/RegisterEntity;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    iget-wide v1, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->accessId:J

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    cmp-long v1, v1, p1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-nez v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object p1, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->xgSDKVersion:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string p1, ""

    const-string p1, ""

    const/4 v4, 0x0

    const-string p1, ""

    const-string p1, ""

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    sget-object p1, Lcom/tencent/android/tpush/stat/b/b;->e:Ljava/util/Map;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-wide v0, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->accessId:J

    const/4 v4, 0x6

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-interface {p1, p2, p0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    sget-object p1, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string p0, "0"

    const-string p0, "0"

    const/4 v4, 0x3

    const-string p0, "0"

    const-string p0, "0"

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object p0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->d()Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-eqz v0, :cond_1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/stat/b/b;->h:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/b/b;->d(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    sput-object p0, Lcom/tencent/android/tpush/stat/b/b;->h:Ljava/lang/String;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    sget-object p0, Lcom/tencent/android/tpush/stat/b/b;->h:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-eqz p0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string p1, "_"

    const-string p1, "_"

    const/4 v2, 0x4

    const-string p1, "_"

    const-string p1, "_"

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    sget-object p1, Lcom/tencent/android/tpush/stat/b/b;->h:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    or-int/2addr v2, v1

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/base/util/Util;->getKey(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object p0
.end method

.method public static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string v0, "0"

    const-string v0, "0"

    const/4 v6, 0x1

    const-string v0, "0"

    const-string v0, "0"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-nez p0, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    return-object v0

    :cond_0
    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v1, "M5D"

    const-string v1, "5MD"

    const/4 v6, 0x2

    const-string v1, "5DM"

    const-string v1, "MD5"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v1, p0}, Ljava/security/MessageDigest;->update([B)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    array-length v3, p0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-ge v2, v3, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    aget-byte v3, p0, v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    const/16 v4, 0x10

    const/4 v6, 0x1

    if-ge v3, v4, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x2

    move v6, v5

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    sget-object v1, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x5

    shl-int/2addr v6, v5

    invoke-virtual {v1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    return-object v0
.end method

.method public static a(Ljava/lang/Throwable;)Lorg/json/JSONArray;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Lorg/json/JSONArray;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->getStackTrace()[Ljava/lang/StackTraceElement;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/stat/b/b;->a(Lorg/json/JSONArray;[Ljava/lang/StackTraceElement;)Lorg/json/JSONArray;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object v0
.end method

.method public static a(Lorg/json/JSONArray;[Ljava/lang/StackTraceElement;)Lorg/json/JSONArray;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const/4 v4, 0x6

    array-length v0, p1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-ge v1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    aget-object v2, p1, v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/lang/StackTraceElement;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v4, 0x3

    const/4 v3, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    return-object p0
.end method

.method public static a(Landroid/content/Context;I)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x7

    sput p1, Lcom/tencent/android/tpush/stat/b/b;->j:I

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x7

    const-string/jumbo v0, "itmadceptfoqqmf.omi"

    const-string v0, "ffmco.qmmediqotait."

    const/4 v2, 0x7

    const-string/jumbo v0, "mettim.aqioqfqd..cm"

    const-string/jumbo v0, "mta.qq.com.difftime"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p0, v0, p1}, Lcom/tencent/android/tpush/stat/b/d;->b(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public static a([B)[B
    .locals 8

    const/4 v6, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    new-instance v0, Ljava/io/ByteArrayInputStream;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-direct {v0, p0}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    new-instance p0, Ljava/io/ByteArrayOutputStream;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-direct {p0}, Ljava/io/ByteArrayOutputStream;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v1, 0x0

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    new-instance v2, Ljava/util/zip/GZIPInputStream;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-direct {v2, v0}, Ljava/util/zip/GZIPInputStream;-><init>(Ljava/io/InputStream;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/16 v3, 0x400

    :try_start_1
    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    new-array v3, v3, [B

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v2, v3}, Ljava/io/InputStream;->read([B)I

    move-result v4

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    const/4 v5, -0x1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eq v4, v5, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x0

    move v7, v5

    const/4 v6, 0x1

    move v7, v6

    invoke-virtual {p0, v3, v5, v4}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    const/4 v6, 0x7

    shl-int/2addr v7, v6

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_2
    .catch Ljava/io/IOException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_1

    :catch_0
    move-exception v0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    sget-object v3, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v3, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_1
    :try_start_3
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v2}, Ljava/util/zip/GZIPInputStream;->close()V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    goto :goto_2

    :catch_1
    move-exception v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    sget-object v2, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v7, 0x3

    invoke-virtual {v2, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_2
    :try_start_4
    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    goto :goto_6

    :catch_2
    move-exception p0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    sget-object v0, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v0, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    goto :goto_6

    :catchall_0
    move-exception v3

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    goto :goto_3

    :catchall_1
    move-exception v3

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    :goto_3
    :try_start_5
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    sget-object v4, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v7, 0x5

    invoke-virtual {v4, v3}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :try_start_6
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v0}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_6
    .catch Ljava/io/IOException; {:try_start_6 .. :try_end_6} :catch_3

    const/4 v7, 0x1

    const/4 v6, 0x3

    goto :goto_4

    :catch_3
    move-exception v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    sget-object v3, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v7, 0x4

    invoke-virtual {v3, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_4
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v2, :cond_1

    :try_start_7
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/util/zip/GZIPInputStream;->close()V
    :try_end_7
    .catch Ljava/io/IOException; {:try_start_7 .. :try_end_7} :catch_4

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto :goto_5

    :catch_4
    move-exception v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    sget-object v2, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v6, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v2, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :cond_1
    :goto_5
    :try_start_8
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_2

    :goto_6
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-object v1

    :catchall_2
    move-exception v1

    :try_start_9
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/io/ByteArrayInputStream;->close()V
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_5

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_7

    :catch_5
    move-exception v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    sget-object v3, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v7, 0x5

    const/4 v6, 0x2

    invoke-virtual {v3, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_7
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-eqz v2, :cond_2

    :try_start_a
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v2}, Ljava/util/zip/GZIPInputStream;->close()V
    :try_end_a
    .catch Ljava/io/IOException; {:try_start_a .. :try_end_a} :catch_6

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x3

    goto :goto_8

    :catch_6
    move-exception v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    sget-object v2, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v2, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :cond_2
    :goto_8
    :try_start_b
    const/4 v6, 0x4

    invoke-virtual {p0}, Ljava/io/ByteArrayOutputStream;->close()V
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_7

    const/4 v7, 0x3

    const/4 v6, 0x2

    goto :goto_9

    :catch_7
    move-exception p0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    sget-object v0, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_9
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    throw v1
.end method

.method public static b(Ljava/lang/String;)J
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v1, "."

    const-string v1, "."

    const-string v1, "."

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    const/16 v2, 0x64

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v3, 0x3

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-static {p0, v1, v2, v3, v0}, Lcom/tencent/android/tpush/stat/b/b;->a(Ljava/lang/String;Ljava/lang/String;IILjava/lang/Long;)Ljava/lang/Long;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-wide v0
.end method

.method public static declared-synchronized b()Lcom/tencent/android/tpush/stat/b/c;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-class v0, Lcom/tencent/android/tpush/stat/b/b;

    const-class v0, Lcom/tencent/android/tpush/stat/b/b;

    const/4 v4, 0x3

    const-class v0, Lcom/tencent/android/tpush/stat/b/b;

    const-class v0, Lcom/tencent/android/tpush/stat/b/b;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    sget-object v1, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v1, Lcom/tencent/android/tpush/stat/b/c;

    const/4 v4, 0x1

    const-string v2, "SastgX"

    const-string v2, "XSgtab"

    const/4 v4, 0x6

    const-string v2, "SXgmta"

    const-string v2, "XgStat"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v1, v2}, Lcom/tencent/android/tpush/stat/b/c;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    move v4, v3

    sput-object v1, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    invoke-virtual {v1, v2}, Lcom/tencent/android/tpush/stat/b/c;->a(Z)V

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    sget-object v1, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    monitor-exit v0

    const/4 v4, 0x7

    throw v1
.end method

.method public static b(Landroid/content/Context;J)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/service/util/d;

    move-result-object p0

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2}, Lcom/tencent/android/tpush/service/util/d;->a(J)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method

.method public static b(Landroid/content/Context;)Lorg/apache/http/HttpHost;
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-nez p0, :cond_0

    const/4 v5, 0x0

    return-object v0

    :cond_0
    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string v2, "E_e.o.iTRA_rNCTKirnWdopnoSASOmidEETsSCs"

    const-string v2, "WnSCSouri.T_ATsEesAToO_iRSdiEdEKCmnpr.N"

    const/4 v5, 0x1

    const-string/jumbo v2, "rmEnKbSEoC_AopSrTAEiaR..Si_snsdOeCTWNTd"

    const-string v2, "android.permission.ACCESS_NETWORK_STATE"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->checkPermission(Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-object v0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo v1, "ncopieuvcyni"

    const-string v1, "eviitonpcync"

    const/4 v5, 0x0

    const-string v1, "entyvicpintc"

    const-string v1, "connectivity"

    const/4 v5, 0x3

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    check-cast p0, Landroid/net/ConnectivityManager;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/net/ConnectivityManager;->getActiveNetworkInfo()Landroid/net/NetworkInfo;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-nez p0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-object v0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getTypeName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    if-eqz v1, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/net/NetworkInfo;->getTypeName()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v1, "WFII"

    const-string v1, "IIFW"

    const-string v1, "IFIW"

    const-string v1, "WIFI"

    const/4 v5, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result p0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz p0, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-object v0

    :cond_3
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-static {}, Landroid/net/Proxy;->getDefaultHost()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz p0, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-lez v1, :cond_4

    const/4 v5, 0x5

    invoke-static {}, Landroid/net/Proxy;->getDefaultPort()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    new-instance v2, Lorg/apache/http/HttpHost;

    const/4 v4, 0x6

    shr-int/2addr v5, v4

    invoke-direct {v2, p0, v1}, Lorg/apache/http/HttpHost;-><init>(Ljava/lang/String;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    return-object v2

    :catchall_0
    move-exception p0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v1, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :cond_4
    const/4 v5, 0x0

    return-object v0
.end method

.method public static c()J
    .locals 7

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-wide/32 v0, 0x5265c00

    const-wide/32 v0, 0x5265c00

    const/4 v6, 0x4

    const-wide/32 v0, 0x5265c00

    const-wide/32 v0, 0x5265c00

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/16 v3, 0xb

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x6

    invoke-virtual {v2, v3, v4}, Ljava/util/Calendar;->set(II)V

    const/4 v6, 0x5

    const/16 v3, 0xc

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v2, v3, v4}, Ljava/util/Calendar;->set(II)V

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/16 v3, 0xd

    const/4 v6, 0x1

    invoke-virtual {v2, v3, v4}, Ljava/util/Calendar;->set(II)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    const/16 v3, 0xe

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2, v3, v4}, Ljava/util/Calendar;->set(II)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    invoke-virtual {v2}, Ljava/util/Calendar;->getTimeInMillis()J

    move-result-wide v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    add-long/2addr v2, v0

    const/4 v5, 0x0

    shr-int/2addr v6, v5

    return-wide v2

    :catchall_0
    move-exception v2

    const/4 v5, 0x3

    const/4 v6, 0x7

    sget-object v3, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v3, v2}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v2

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    add-long/2addr v2, v0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    return-wide v2
.end method

.method public static c(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/stat/b/b;->f:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/b/b;->c(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object p0, Lcom/tencent/android/tpush/stat/b/b;->f:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object p0

    :cond_0
    :try_start_0
    const/4 v2, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, p0, v1}, Landroid/content/pm/PackageManager;->getPackageInfo(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x5

    iget-object p0, p0, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    sput-object p0, Lcom/tencent/android/tpush/stat/b/b;->f:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz p0, :cond_1

    const/4 v2, 0x4

    or-int/2addr v3, v2

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-nez p0, :cond_2

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo p0, "wqunnkn"

    const-string/jumbo p0, "nqnwknu"

    const/4 v3, 0x1

    const-string/jumbo p0, "unknown"
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/android/tpush/stat/b/b;->g:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    sget-object p0, Lcom/tencent/android/tpush/stat/b/b;->f:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-object p0
.end method

.method public static c(Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    if-eqz p0, :cond_1

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    if-nez p0, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    goto :goto_0

    :cond_0
    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    const/4 p0, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    return p0

    :cond_1
    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    const/4 p0, 0x0

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return p0
.end method

.method public static d(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/Util;->getCurProcessName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method

.method private static declared-synchronized d()Ljava/util/Random;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-class v0, Lcom/tencent/android/tpush/stat/b/b;

    const/4 v3, 0x0

    const-class v0, Lcom/tencent/android/tpush/stat/b/b;

    const-class v0, Lcom/tencent/android/tpush/stat/b/b;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    sget-object v1, Lcom/tencent/android/tpush/stat/b/b;->d:Ljava/util/Random;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance v1, Ljava/util/Random;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-direct {v1}, Ljava/util/Random;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    sput-object v1, Lcom/tencent/android/tpush/stat/b/b;->d:Ljava/util/Random;

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    sget-object v1, Lcom/tencent/android/tpush/stat/b/b;->d:Ljava/util/Random;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x5

    throw v1
.end method

.method public static e(Landroid/content/Context;)Z
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    sget-wide v0, Lcom/tencent/android/tpush/stat/b/b;->i:J

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x0

    cmp-long v0, v0, v2

    const/4 v4, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-gez v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v0, ".hso.eqmcsmcttcaiqk."

    const-string v0, "a.smqtmoqem.chtc.cki"

    const/4 v5, 0x3

    const-string/jumbo v0, "qtomhmc.mtqka.imec.e"

    const-string/jumbo v0, "mta.qq.com.checktime"

    const/4 v5, 0x0

    const/4 v4, 0x7

    invoke-static {p0, v0, v2, v3}, Lcom/tencent/android/tpush/stat/b/d;->a(Landroid/content/Context;Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x6

    sput-wide v0, Lcom/tencent/android/tpush/stat/b/b;->i:J

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    sget-wide v2, Lcom/tencent/android/tpush/stat/b/b;->i:J

    const/4 v5, 0x4

    const/4 v4, 0x5

    sub-long/2addr v0, v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {v0, v1}, Ljava/lang/Math;->abs(J)J

    move-result-wide v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-wide/32 v2, 0x5265c00

    const/4 v5, 0x1

    const-wide/32 v2, 0x5265c00

    const-wide/32 v2, 0x5265c00

    const/4 v4, 0x0

    shr-int/2addr v5, v4

    cmp-long p0, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    if-lez p0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    const/4 p0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 p0, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    return p0
.end method

.method public static f(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    sput-wide v0, Lcom/tencent/android/tpush/stat/b/b;->i:J

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v2, "qo..okemheamccmcmqi."

    const-string/jumbo v2, "mmqme.qe.c.kactohcim"

    const/4 v4, 0x5

    const-string/jumbo v2, "qeqo.baim.mthktm.ecc"

    const-string/jumbo v2, "mta.qq.com.checktime"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p0, v2, v0, v1}, Lcom/tencent/android/tpush/stat/b/d;->b(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v4, 0x3

    const/4 v3, 0x4

    return-void
.end method

.method public static g(Landroid/content/Context;)I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v0, "fefi.qudmc.itmm.toa"

    const-string/jumbo v0, "t.cmoedofqt.i.immaf"

    const/4 v3, 0x5

    const-string v0, "d..qqtmpfeciaimmo.f"

    const-string/jumbo v0, "mta.qq.com.difftime"

    const/4 v3, 0x3

    const/4 v1, 0x7

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x5

    invoke-static {p0, v0, v1}, Lcom/tencent/android/tpush/stat/b/d;->a(Landroid/content/Context;Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x2

    return p0
.end method

.method public static h(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    if-nez p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 p0, 0x5

    const/4 p0, 0x0

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-object p0

    :cond_0
    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-object p0
.end method
