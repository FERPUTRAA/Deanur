.class Lcom/tencent/android/tpush/stat/StatServiceImpl$12;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl;->trackCustomKVEvent(Landroid/content/Context;Ljava/lang/String;Ljava/util/Properties;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lcom/tencent/android/tpush/stat/event/c$a;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/stat/event/c$a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$12;->a:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$12;->b:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$12;->c:Lcom/tencent/android/tpush/stat/event/c$a;

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public run()V
    .locals 11

    :try_start_0
    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "~~s~@@t-@ @tyb @i~o~@m ~S  i/ .@@@@ nb~ @  o4~Mlu~s K bi~f ~@~@@~~  ~or~~fo~@@o@d1c@a~@l~ /o~v~@"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$12;->a:Landroid/content/Context;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v5

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x3

    new-instance v0, Lcom/tencent/android/tpush/stat/event/c;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$12;->a:Landroid/content/Context;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x0

    const/4 v3, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$12;->b:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    move-object v1, v0

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-direct/range {v1 .. v8}, Lcom/tencent/android/tpush/stat/event/c;-><init>(Landroid/content/Context;ILjava/lang/String;JJ)V

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpush/stat/event/c;->a()Lcom/tencent/android/tpush/stat/event/c$a;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$12;->c:Lcom/tencent/android/tpush/stat/event/c$a;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x7

    iget-object v2, v2, Lcom/tencent/android/tpush/stat/event/c$a;->c:Lorg/json/JSONObject;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x6

    iput-object v2, v1, Lcom/tencent/android/tpush/stat/event/c$a;->c:Lorg/json/JSONObject;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Lcom/tencent/android/tpush/stat/event/Event;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v1

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-virtual {v1, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x7

    return-void
.end method
