.class public Lcom/tencent/android/tpush/stat/d;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/stat/d$a;
    }
.end annotation


# static fields
.field static a:Lcom/tencent/android/tpush/stat/d$a;

.field static b:Lcom/tencent/android/tpush/stat/d$a;

.field static c:Ljava/lang/String;

.field private static d:Lcom/tencent/android/tpush/stat/b/c;

.field private static e:Lcom/tencent/android/tpush/stat/StatReportStrategy;

.field private static f:Z

.field private static g:Z

.field private static h:Z

.field private static i:S

.field private static j:I

.field private static k:I

.field private static l:I

.field private static m:I


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/b/b;->b()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    sput-object v0, Lcom/tencent/android/tpush/stat/d;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v3, 0x7

    const/4 v2, 0x4

    new-instance v0, Lcom/tencent/android/tpush/stat/d$a;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, 0x2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/tencent/android/tpush/stat/d$a;-><init>(I)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    sput-object v0, Lcom/tencent/android/tpush/stat/d;->a:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/android/tpush/stat/d$a;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v1, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Lcom/tencent/android/tpush/stat/d$a;-><init>(I)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    sput-object v0, Lcom/tencent/android/tpush/stat/d;->b:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v3, 0x6

    sget-object v0, Lcom/tencent/android/tpush/stat/StatReportStrategy;->APP_LAUNCH:Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    sput-object v0, Lcom/tencent/android/tpush/stat/d;->e:Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    sput-boolean v1, Lcom/tencent/android/tpush/stat/d;->f:Z

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    sput-boolean v1, Lcom/tencent/android/tpush/stat/d;->g:Z

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-string v0, "ETs_BE_RNI_A_"

    const-string v0, "ITsA__R_B_EEN"

    const/4 v3, 0x3

    const-string v0, "__NmBTERAI__H"

    const-string v0, "__HIBERNATE__"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    sput-object v0, Lcom/tencent/android/tpush/stat/d;->c:Ljava/lang/String;

    const/4 v2, 0x0

    and-int/2addr v3, v2

    const/4 v0, 0x0

    move v3, v0

    sput-boolean v0, Lcom/tencent/android/tpush/stat/d;->h:Z

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v1, 0x6

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    sput-short v1, Lcom/tencent/android/tpush/stat/d;->i:S

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/16 v1, 0x400

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    sput v1, Lcom/tencent/android/tpush/stat/d;->j:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/16 v1, 0x7530

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    sput v1, Lcom/tencent/android/tpush/stat/d;->k:I

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    sput v0, Lcom/tencent/android/tpush/stat/d;->l:I

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const/16 v0, 0x14

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    sput v0, Lcom/tencent/android/tpush/stat/d;->m:I

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    return-void
.end method

.method public static a()Lcom/tencent/android/tpush/stat/StatReportStrategy;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/stat/d;->e:Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method static a(J)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/f;->a()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x3

    sget-object v1, Lcom/tencent/android/tpush/stat/d;->c:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-static {v0, v1, p0, p1}, Lcom/tencent/android/tpush/stat/b/d;->b(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    const/4 p0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/d;->b(Z)V

    const/4 v2, 0x6

    move v3, v2

    sget-object p0, Lcom/tencent/android/tpush/stat/d;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string/jumbo p1, "iunm enaoelr d sibotD rv cKefTsArs rSM"

    const/4 v3, 0x4

    const-string p1, " ofnoicreav  ri tesDiosr KbdrlTnMSAuse"

    const-string p1, "MTA is disable for current SDK version"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/stat/b/c;->c(Ljava/lang/Object;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method static a(Landroid/content/Context;Lcom/tencent/android/tpush/stat/d$a;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget p0, p1, Lcom/tencent/android/tpush/stat/d$a;->a:I

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/stat/d;->b:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, v0, Lcom/tencent/android/tpush/stat/d$a;->a:I

    const/4 v2, 0x2

    if-ne p0, v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x4

    sput-object p1, Lcom/tencent/android/tpush/stat/d;->b:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object p0, p1, Lcom/tencent/android/tpush/stat/d$a;->b:Lorg/json/JSONObject;

    const/4 v1, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/d;->a(Lorg/json/JSONObject;)V

    const/4 v1, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/stat/d;->a:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v2, 0x0

    const/4 v1, 0x7

    iget v0, v0, Lcom/tencent/android/tpush/stat/d$a;->a:I

    const/4 v2, 0x2

    const/4 v1, 0x1

    if-ne p0, v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    sput-object p1, Lcom/tencent/android/tpush/stat/d;->a:Lcom/tencent/android/tpush/stat/d$a;

    :cond_1
    :goto_0
    const/4 v2, 0x2

    return-void
.end method

.method static a(Landroid/content/Context;Lcom/tencent/android/tpush/stat/d$a;Lorg/json/JSONObject;)V
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v0, "m"

    const-string/jumbo v0, "m"

    const/4 v7, 0x4

    const-string/jumbo v0, "m"

    const-string/jumbo v0, "m"

    const/4 v6, 0x1

    move v7, v6

    const-string v1, "c"

    const-string v1, "c"

    const/4 v7, 0x0

    const-string v1, "c"

    const-string v1, "c"

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p2}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    const/4 v3, 0x0

    :cond_0
    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-eqz v4, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    check-cast v4, Ljava/lang/String;

    const/4 v7, 0x6

    const-string/jumbo v5, "v"

    const-string/jumbo v5, "v"

    const/4 v7, 0x0

    const-string/jumbo v5, "v"

    const-string/jumbo v5, "v"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v4, v5}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz v5, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {p2, v4}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget v5, p1, Lcom/tencent/android/tpush/stat/d$a;->d:I

    const/4 v6, 0x3

    move v7, v6

    if-eq v5, v4, :cond_1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/4 v3, 0x1

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    iput v4, p1, Lcom/tencent/android/tpush/stat/d$a;->d:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    goto :goto_0

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v4, v1}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v5

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v5, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p2, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v4}, Ljava/lang/String;->length()I

    move-result v5

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-lez v5, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    new-instance v5, Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x5

    invoke-direct {v5, v4}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    iput-object v5, p1, Lcom/tencent/android/tpush/stat/d$a;->b:Lorg/json/JSONObject;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto :goto_0

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v4, v0}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v4

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-eqz v4, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p2, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    iput-object v4, p1, Lcom/tencent/android/tpush/stat/d$a;->c:Ljava/lang/String;

    const/4 v7, 0x1

    goto/16 :goto_0

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-eqz v3, :cond_5

    const/4 v7, 0x6

    iget p2, p1, Lcom/tencent/android/tpush/stat/d$a;->a:I

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    sget-object v0, Lcom/tencent/android/tpush/stat/d;->b:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget v0, v0, Lcom/tencent/android/tpush/stat/d$a;->a:I

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-ne p2, v0, :cond_5

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object p2, p1, Lcom/tencent/android/tpush/stat/d$a;->b:Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {p2}, Lcom/tencent/android/tpush/stat/d;->a(Lorg/json/JSONObject;)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object p2, p1, Lcom/tencent/android/tpush/stat/d$a;->b:Lorg/json/JSONObject;

    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {p2}, Lcom/tencent/android/tpush/stat/d;->b(Lorg/json/JSONObject;)V

    :cond_5
    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/stat/d;->a(Landroid/content/Context;Lcom/tencent/android/tpush/stat/d$a;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    sget-object p1, Lcom/tencent/android/tpush/stat/d;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {p1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    goto :goto_1

    :catch_0
    move-exception p0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    sget-object p1, Lcom/tencent/android/tpush/stat/d;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {p1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_1
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    return-void
.end method

.method static a(Landroid/content/Context;Lorg/json/JSONObject;)V
    .locals 5

    :try_start_0
    const/4 v4, 0x7

    invoke-virtual {p1}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eqz v1, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    check-cast v1, Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    sget-object v2, Lcom/tencent/android/tpush/stat/d;->b:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget v2, v2, Lcom/tencent/android/tpush/stat/d$a;->a:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-eqz v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget-object v2, Lcom/tencent/android/tpush/stat/d;->b:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p0, v2, v1}, Lcom/tencent/android/tpush/stat/d;->a(Landroid/content/Context;Lcom/tencent/android/tpush/stat/d$a;Lorg/json/JSONObject;)V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget-object v2, Lcom/tencent/android/tpush/stat/d;->a:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v4, 0x4

    iget v2, v2, Lcom/tencent/android/tpush/stat/d$a;->a:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    invoke-static {v2}, Ljava/lang/Integer;->toString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    sget-object v2, Lcom/tencent/android/tpush/stat/d;->a:Lcom/tencent/android/tpush/stat/d$a;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p0, v2, v1}, Lcom/tencent/android/tpush/stat/d;->a(Landroid/content/Context;Lcom/tencent/android/tpush/stat/d$a;Lorg/json/JSONObject;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x2

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    sget-object p1, Lcom/tencent/android/tpush/stat/d;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1, p0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method

.method public static a(Lcom/tencent/android/tpush/stat/StatReportStrategy;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    sput-object p0, Lcom/tencent/android/tpush/stat/d;->e:Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->b()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    sget-object v0, Lcom/tencent/android/tpush/stat/d;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string/jumbo v2, "te: obay CtnSteash dgtraoSgn"

    const-string v2, "atnaot CsdSttn:agthS  eyergo"

    const/4 v4, 0x7

    const-string/jumbo v2, "ngaSe ug :hrSdentsotttetaaC "

    const-string v2, "Change to statSendStrategy: "

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0, p0}, Lcom/tencent/android/tpush/stat/b/c;->h(Ljava/lang/Object;)V

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    return-void
.end method

.method static a(Lorg/json/JSONObject;)V
    .locals 3

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string/jumbo v0, "rs"

    const-string/jumbo v0, "rs"

    const/4 v2, 0x3

    const-string/jumbo v0, "rs"

    const-string/jumbo v0, "rs"

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/StatReportStrategy;->getStatReportStrategy(I)Lcom/tencent/android/tpush/stat/StatReportStrategy;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-eqz p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/d;->a(Lcom/tencent/android/tpush/stat/StatReportStrategy;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    goto :goto_0

    :catch_0
    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->b()Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    sget-object p0, Lcom/tencent/android/tpush/stat/d;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v1, 0x3

    move v2, v1

    const-string v0, ".oto rfpnn ub"

    const-string/jumbo v0, "nft.nbrdouo  "

    const-string v0, "dtu snr qonof"

    const-string/jumbo v0, "rs not found."

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Object;)V

    :cond_0
    :goto_0
    const/4 v2, 0x4

    return-void
.end method

.method public static a(Z)V
    .locals 3

    const/4 v2, 0x5

    sput-boolean p0, Lcom/tencent/android/tpush/stat/d;->f:Z

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/stat/b/b;->b()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0, p0}, Lcom/tencent/android/tpush/stat/b/c;->a(Z)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method static b(Lorg/json/JSONObject;)V
    .locals 6

    const/4 v4, 0x3

    if-eqz p0, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p0}, Lorg/json/JSONObject;->length()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v0, :cond_0

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x3

    goto/16 :goto_0

    :cond_0
    :try_start_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    sget-object v0, Lcom/tencent/android/tpush/stat/d;->c:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {p0, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/stat/d;->b()Z

    move-result v0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v1, "..s6u"

    const-string v1, ".u0.6"

    const/4 v5, 0x1

    const-string v1, "20.m6"

    const-string v1, "2.0.6"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    :try_start_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    sget-object v0, Lcom/tencent/android/tpush/stat/d;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const-string v3, "eab:oirVhneep"

    const-string/jumbo v3, "ntVree:pabhie"

    const/4 v5, 0x2

    const-string/jumbo v3, "rVtanbeb:ehre"

    const-string v3, "hibernateVer:"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string v3, "erqt euiuvsonc :nr"

    const-string/jumbo v3, "us nrroiqetc nv:er"

    const/4 v5, 0x6

    const-string/jumbo v3, "nv eourpr,n:seric "

    const-string v3, ", current version:"

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v0, v2}, Lcom/tencent/android/tpush/stat/b/c;->h(Ljava/lang/Object;)V

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/b/b;->b(Ljava/lang/String;)J

    move-result-wide v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-static {v1}, Lcom/tencent/android/tpush/stat/b/b;->b(Ljava/lang/String;)J

    move-result-wide v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    cmp-long p0, v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    if-gtz p0, :cond_2

    const/4 v4, 0x6

    and-int/2addr v5, v4

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/stat/d;->a(J)V
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :catch_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object p0, Lcom/tencent/android/tpush/stat/d;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string v0, "ATd_s.tnq _RNoEu_BnEIoHf"

    const-string v0, "E_s EN_A_uodnBT.oInRfHt "

    const/4 v5, 0x2

    const-string/jumbo v0, "uos f__I.ToA_dR EH_tnnEN"

    const-string v0, "__HIBERNATE__ not found."

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpush/stat/b/c;->h(Ljava/lang/Object;)V

    :cond_2
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    return-void
.end method

.method public static b(Z)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    sput-boolean p0, Lcom/tencent/android/tpush/stat/d;->g:Z

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object p0, Lcom/tencent/android/tpush/stat/d;->d:Lcom/tencent/android/tpush/stat/b/c;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    const-string v0, "e!!ma dn!TladMi!As!mrb !bcSiea !!ee! !e!Shttv"

    const-string/jumbo v0, "s!!m! !r ve TS!anaShebtaeb!!i!Aedcd!e!!i! tlM"

    const/4 v2, 0x5

    const-string v0, "ea no!!viAe!sTcMb!!!tt  e!! ib!!dS!adSeahres!"

    const-string v0, "!!!!!!MTA StatService has been disabled!!!!!!"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpush/stat/b/c;->c(Ljava/lang/Object;)V

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public static b()Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    sget-boolean v0, Lcom/tencent/android/tpush/stat/d;->f:Z

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public static c(Z)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    sput-boolean p0, Lcom/tencent/android/tpush/stat/d;->h:Z

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static c()Z
    .locals 5

    const/4 v3, 0x7

    move v4, v3

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-nez v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/service/XGVipPushService;->a()Landroid/app/Service;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    return v1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/service/XGVipPushService;->a()Landroid/app/Service;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    :cond_1
    const/4 v4, 0x3

    if-eqz v0, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    sget-boolean v2, Lcom/tencent/android/tpush/stat/d;->g:Z

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    if-eqz v2, :cond_2

    const/4 v4, 0x6

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/service/a/a;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/service/a/a;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget v0, v0, Lcom/tencent/android/tpush/service/a/a;->B:I

    const/4 v4, 0x0

    const/4 v2, 0x1

    const/4 v4, 0x6

    shl-int/2addr v3, v2

    const/4 v4, 0x6

    if-ne v0, v2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    move v1, v2

    move v1, v2

    move v1, v2

    move v1, v2

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x0

    return v1

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-boolean v0, Lcom/tencent/android/tpush/stat/d;->g:Z

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    return v0
.end method

.method public static d()Z
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-boolean v0, Lcom/tencent/android/tpush/stat/d;->h:Z

    const/4 v2, 0x6

    const/4 v1, 0x2

    return v0
.end method

.method public static e()S
    .locals 3

    const/4 v1, 0x6

    sget-short v0, Lcom/tencent/android/tpush/stat/d;->i:S

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return v0
.end method

.method public static f()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    sget v0, Lcom/tencent/android/tpush/stat/d;->j:I

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method
