.class Lcom/tencent/android/tpush/stat/StatServiceImpl$11;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl;->trackLaunchEvent(Landroid/content/Context;IIJ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:I

.field final synthetic c:I

.field final synthetic d:J


# direct methods
.method constructor <init>(Landroid/content/Context;IIJ)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$11;->a:Landroid/content/Context;

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$11;->b:I

    const/4 v0, 0x3

    const/4 v0, 0x5

    iput p3, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$11;->c:I

    const/4 v0, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-wide p4, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$11;->d:J

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public run()V
    .locals 9

    :try_start_0
    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "oMs~@c i~ ~ @~~~@fodl@~r~~~~y@tun@S .@~i@@@a~~so@ @v @i@ 4//ob@ ~ b o~1~@~l-@~@~f Kmb@t~  ~   o@"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x3

    new-instance v6, Lcom/tencent/android/tpush/stat/event/e;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$11;->a:Landroid/content/Context;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x6

    iget v2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$11;->b:I

    const/4 v8, 0x3

    const/4 v7, 0x6

    iget v3, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$11;->c:I

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget-wide v4, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$11;->d:J

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    move-object v0, v6

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/tencent/android/tpush/stat/event/e;-><init>(Landroid/content/Context;IIJ)V

    const/4 v8, 0x4

    invoke-static {v6}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Lcom/tencent/android/tpush/stat/event/Event;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v1, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    return-void
.end method
