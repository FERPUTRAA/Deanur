.class Lcom/tencent/android/tpush/stat/StatServiceImpl$6$1;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl$6;->d(Landroid/app/Activity;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/stat/StatServiceImpl$6;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/stat/StatServiceImpl$6;)V
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$6$1;->a:Lcom/tencent/android/tpush/stat/StatServiceImpl$6;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public run()V
    .locals 5

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "ous@ ~o b-S~@ ~~f@@. @ /@yo~l~~~b  4v@~@M~ @@@~K@ ~t~i im fdo @l~1@ @o/~~@~@scrn~~~~ bo@i@~@  at"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->j()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->n()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string v1, "eb mcuantrdwnks"

    const-string v1, "ces ubdwnaktnro"

    const/4 v4, 0x5

    const-string v1, "b uaowrgocdknet"

    const-string/jumbo v1, "went background"

    const/4 v3, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Object;)V

    const/4 v4, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->m()Ljava/util/List;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    check-cast v1, Lcom/tencent/android/tpush/stat/c;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-interface {v1}, Lcom/tencent/android/tpush/stat/c;->b()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    goto :goto_0

    :catchall_0
    move-exception v1

    :try_start_2
    const/4 v4, 0x3

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v2, v1}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Z)Z

    const/4 v4, 0x7

    goto :goto_1

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const-string v1, "eru obtifrnsmold"

    const-string/jumbo v1, "st mdroneugriofl"

    const/4 v4, 0x7

    const-string/jumbo v1, "ufrl eusoolitndg"

    const-string/jumbo v1, "still foreground"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Object;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto :goto_1

    :catchall_1
    move-exception v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v1, v0}, Lcom/tencent/android/tpush/stat/b/c;->b(Ljava/lang/Throwable;)V

    :goto_1
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    return-void
.end method
