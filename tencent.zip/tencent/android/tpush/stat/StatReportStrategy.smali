.class public final enum Lcom/tencent/android/tpush/stat/StatReportStrategy;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/tencent/android/tpush/stat/StatReportStrategy;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/tencent/android/tpush/stat/StatReportStrategy;

.field public static final enum APP_LAUNCH:Lcom/tencent/android/tpush/stat/StatReportStrategy;

.field public static final enum BATCH:Lcom/tencent/android/tpush/stat/StatReportStrategy;

.field public static final enum DEVELOPER:Lcom/tencent/android/tpush/stat/StatReportStrategy;

.field public static final enum INSTANT:Lcom/tencent/android/tpush/stat/StatReportStrategy;

.field public static final enum ONLY_WIFI:Lcom/tencent/android/tpush/stat/StatReportStrategy;

.field public static final enum ONLY_WIFI_NO_CACHE:Lcom/tencent/android/tpush/stat/StatReportStrategy;

.field public static final enum PERIOD:Lcom/tencent/android/tpush/stat/StatReportStrategy;


# instance fields
.field v:I


# direct methods
.method static constructor <clinit>()V
    .locals 16

    new-instance v0, Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const-string v1, "NssITAN"

    const-string v1, "TNsSNIA"

    const-string v1, "SANmTNT"

    const-string v1, "INSTANT"

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v1, v2, v3}, Lcom/tencent/android/tpush/stat/StatReportStrategy;-><init>(Ljava/lang/String;II)V

    sput-object v0, Lcom/tencent/android/tpush/stat/StatReportStrategy;->INSTANT:Lcom/tencent/android/tpush/stat/StatReportStrategy;

    new-instance v1, Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const-string v4, "YOI_omLWI"

    const-string v4, "YOWmILF_I"

    const-string v4, "OIYFLb_WI"

    const-string v4, "ONLY_WIFI"

    const/4 v5, 0x2

    invoke-direct {v1, v4, v3, v5}, Lcom/tencent/android/tpush/stat/StatReportStrategy;-><init>(Ljava/lang/String;II)V

    sput-object v1, Lcom/tencent/android/tpush/stat/StatReportStrategy;->ONLY_WIFI:Lcom/tencent/android/tpush/stat/StatReportStrategy;

    new-instance v4, Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const-string v6, "TuoHC"

    const-string v6, "CTHBo"

    const-string v6, "BApTH"

    const-string v6, "BATCH"

    const/4 v7, 0x3

    invoke-direct {v4, v6, v5, v7}, Lcom/tencent/android/tpush/stat/StatReportStrategy;-><init>(Ljava/lang/String;II)V

    sput-object v4, Lcom/tencent/android/tpush/stat/StatReportStrategy;->BATCH:Lcom/tencent/android/tpush/stat/StatReportStrategy;

    new-instance v6, Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const-string v8, "PAb_AUCPqH"

    const-string v8, "AAPLPbHUC_"

    const-string v8, "ALs_PPNUCH"

    const-string v8, "APP_LAUNCH"

    const/4 v9, 0x4

    invoke-direct {v6, v8, v7, v9}, Lcom/tencent/android/tpush/stat/StatReportStrategy;-><init>(Ljava/lang/String;II)V

    sput-object v6, Lcom/tencent/android/tpush/stat/StatReportStrategy;->APP_LAUNCH:Lcom/tencent/android/tpush/stat/StatReportStrategy;

    new-instance v8, Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const-string v10, "EOumREPEV"

    const-string v10, "EREEODuPV"

    const-string v10, "EEDRoPLEV"

    const-string v10, "DEVELOPER"

    const/4 v11, 0x5

    invoke-direct {v8, v10, v9, v11}, Lcom/tencent/android/tpush/stat/StatReportStrategy;-><init>(Ljava/lang/String;II)V

    sput-object v8, Lcom/tencent/android/tpush/stat/StatReportStrategy;->DEVELOPER:Lcom/tencent/android/tpush/stat/StatReportStrategy;

    new-instance v10, Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const-string v12, "DPRIEb"

    const-string v12, "RpIDEP"

    const-string/jumbo v12, "uDEIRO"

    const-string v12, "PERIOD"

    const/4 v13, 0x6

    invoke-direct {v10, v12, v11, v13}, Lcom/tencent/android/tpush/stat/StatReportStrategy;-><init>(Ljava/lang/String;II)V

    sput-object v10, Lcom/tencent/android/tpush/stat/StatReportStrategy;->PERIOD:Lcom/tencent/android/tpush/stat/StatReportStrategy;

    new-instance v12, Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const-string v14, "OEI_NWIpA_OqCHNYL_"

    const-string v14, "OIFIONACqH_N__EYWL"

    const-string v14, "_EYACWLCqOI_NIOFN_"

    const-string v14, "ONLY_WIFI_NO_CACHE"

    const/4 v15, 0x7

    invoke-direct {v12, v14, v13, v15}, Lcom/tencent/android/tpush/stat/StatReportStrategy;-><init>(Ljava/lang/String;II)V

    sput-object v12, Lcom/tencent/android/tpush/stat/StatReportStrategy;->ONLY_WIFI_NO_CACHE:Lcom/tencent/android/tpush/stat/StatReportStrategy;

    new-array v14, v15, [Lcom/tencent/android/tpush/stat/StatReportStrategy;

    aput-object v0, v14, v2

    aput-object v1, v14, v3

    aput-object v4, v14, v5

    aput-object v6, v14, v7

    aput-object v8, v14, v9

    aput-object v10, v14, v11

    aput-object v12, v14, v13

    sput-object v14, Lcom/tencent/android/tpush/stat/StatReportStrategy;->$VALUES:[Lcom/tencent/android/tpush/stat/StatReportStrategy;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;II)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I)V"
        }
    .end annotation

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput p3, p0, Lcom/tencent/android/tpush/stat/StatReportStrategy;->v:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method

.method public static getStatReportStrategy(I)Lcom/tencent/android/tpush/stat/StatReportStrategy;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " ~sb@~@~-  s/~ob~.by/@~v@S~@1oi~@i@~ro@ f~KM@4~~ otd@  c~@u~a~ @~fl~t@o ~ @~@n~  ~@@@ m i o@~ @ "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatReportStrategy;->values()[Lcom/tencent/android/tpush/stat/StatReportStrategy;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    array-length v1, v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-ge v2, v1, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    aget-object v3, v0, v2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v3}, Lcom/tencent/android/tpush/stat/StatReportStrategy;->getIntValue()I

    move-result v4

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-ne p0, v4, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-object v3

    :cond_0
    const/4 v5, 0x0

    move v6, v5

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x4

    const/4 p0, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    return-object p0
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/tencent/android/tpush/stat/StatReportStrategy;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-class v0, Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const-class v0, Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const/4 v2, 0x6

    const-class v0, Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const-class v0, Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    check-cast p0, Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const/4 v1, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p0
.end method

.method public static values()[Lcom/tencent/android/tpush/stat/StatReportStrategy;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/stat/StatReportStrategy;->$VALUES:[Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const/4 v2, 0x7

    invoke-virtual {v0}, [Lcom/tencent/android/tpush/stat/StatReportStrategy;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    check-cast v0, [Lcom/tencent/android/tpush/stat/StatReportStrategy;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public getIntValue()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/stat/StatReportStrategy;->v:I

    const/4 v2, 0x6

    const/4 v1, 0x0

    return v0
.end method
