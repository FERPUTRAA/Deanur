.class public interface abstract Lcom/tencent/android/tpush/stat/c;
.super Ljava/lang/Object;


# virtual methods
.method public abstract a()V
.end method

.method public abstract b()V
.end method
