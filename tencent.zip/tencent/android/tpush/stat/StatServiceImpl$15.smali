.class Lcom/tencent/android/tpush/stat/StatServiceImpl$15;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/stat/e;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/stat/StatServiceImpl;->a(Ljava/util/List;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/util/List;


# direct methods
.method constructor <init>(Ljava/util/List;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$15;->a:Ljava/util/List;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public a()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~/sMi  ~~b@ o@~~ @@ @s@@b@@i @@dof~~@b.@~ ll ~@ot@ ~uviS /on@@1 -~omyo~ @K@t~~@4~~~~~r ~ ac~~  f"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    return-void
.end method

.method public b()V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->d()Lcom/tencent/android/tpush/stat/b/c;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string v2, "avLmtshFsneapcs ueitiiserDoietzlnsnt:"

    const-string/jumbo v2, "tsssirvhnezeuDns taEltctiiisLenFa:epo"

    const-string/jumbo v2, "onDispatchFailure sentEventList size:"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$15;->a:Ljava/util/List;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-interface {v2}, Ljava/util/List;->size()I

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/stat/b/c;->f(Ljava/lang/Object;)V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/stat/StatServiceImpl$15;->a:Ljava/util/List;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/stat/StatServiceImpl;->b(Ljava/util/List;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-void
.end method
