.class Lcom/tencent/android/tpush/stat/ServiceStat$a;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/stat/ServiceStat;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# direct methods
.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/android/tpush/stat/ServiceStat$1;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpush/stat/ServiceStat$a;-><init>()V

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    if-eqz p2, :cond_4

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    if-eqz p1, :cond_4

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v1, "aIssC.YdCrEE.CiANTnT.GdNnoNcnIn_tVHe"

    const-string v1, "dYsTnGeEo.nnCiHcaNVIrCEtnNT.dNC_.IoA"

    const/4 v5, 0x2

    const-string/jumbo v1, "tNGmndCcoOVdTIHNCTo.Er.eY.NCn_EnaAnI"

    const-string v1, "android.net.conn.CONNECTIVITY_CHANGE"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v0, :cond_4

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v0, "efnoowrkomI"

    const-string/jumbo v0, "onrmIwofekt"

    const/4 v5, 0x4

    const-string/jumbo v0, "oenkrboItfw"

    const-string/jumbo v0, "networkInfo"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    check-cast v0, Landroid/net/NetworkInfo;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v2, "rdt -nun e ckaec  treg tCwNRieontec-setivoo enha"

    const-string v2, "NetworkReceiver - Connection state changed to - "

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0}, Landroid/net/NetworkInfo;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string v2, "eattorcpiSe"

    const-string v2, "eSiaoretSct"

    const/4 v5, 0x3

    const-string v2, "ServiceStat"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string/jumbo v1, "tcbvCitoqynnne"

    const-string/jumbo v1, "iyCvnbienttcon"

    const/4 v5, 0x3

    const-string/jumbo v1, "noConnectivity"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p2, v1, v3}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz p2, :cond_1

    const/4 v5, 0x2

    const-string/jumbo p1, "nosu toantesies kwdis dCertt"

    const-string/jumbo p1, "nrse cuwCedii nttk staostdoe"

    const/4 v5, 0x6

    const-string p1, "dn mrndnticotate ieetCwsos k"

    const-string/jumbo p1, "stat network is disConnected"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v4, 0x7

    goto/16 :goto_0

    :cond_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    sget-object p2, Landroid/net/NetworkInfo$State;->CONNECTED:Landroid/net/NetworkInfo$State;

    const/4 v5, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getState()Landroid/net/NetworkInfo$State;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-ne p2, v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string p2, "do eodnttaa tla5anl  sop sLwktne ogocs Mnctnrrdenes"

    const-string p2, "atnwontpkctnel  e5Mrtdalsoocngeetn s  nsoLa redasd "

    const/4 v5, 0x5

    const-string p2, " sceebonotdnnkca5doa ao rMtnsards  cLttelstew e lng"

    const-string/jumbo p2, "stat network connected and sendLocalMsg on 5s later"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {v2, p2}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    new-instance v0, Lcom/tencent/android/tpush/stat/ServiceStat$a$1;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {v0, p0, p1}, Lcom/tencent/android/tpush/stat/ServiceStat$a$1;-><init>(Lcom/tencent/android/tpush/stat/ServiceStat$a;Landroid/content/Context;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-wide/16 v1, 0x1388

    const-wide/16 v1, 0x1388

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p2, v0, v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;J)Z

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    goto :goto_0

    :cond_2
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-object p1, Landroid/net/NetworkInfo$State;->DISCONNECTED:Landroid/net/NetworkInfo$State;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getState()Landroid/net/NetworkInfo$State;

    move-result-object p2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-ne p1, p2, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo p1, "wdoseteNqn ck .roiidtnce"

    const/4 v5, 0x1

    const-string p1, ".stkNou ni ideecdeocrwst"

    const-string p1, "Network is disconnected."

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-static {v2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    goto :goto_0

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string/jumbo p2, "stnttewp s o e-koeh rr"

    const-string/jumbo p2, "o snt ekertthoet rw s-"

    const/4 v5, 0x4

    const-string p2, " ht-awe qenr ktt eroso"

    const-string/jumbo p2, "other network state - "

    const/4 v5, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/net/NetworkInfo;->getState()Landroid/net/NetworkInfo$State;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string p2, "hnsDtg.m o.in"

    const-string p2, "hgDmo ..nt ni"

    const/4 v5, 0x7

    const-string/jumbo p2, "t.hmgn nDo i."

    const-string p2, ". Do nothing."

    const/4 v5, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x3

    invoke-static {v2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-void
.end method
