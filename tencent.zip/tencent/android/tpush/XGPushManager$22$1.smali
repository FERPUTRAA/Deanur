.class Lcom/tencent/android/tpush/XGPushManager$22$1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/XGIOperateCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager$22;->TRun()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/XGPushManager$22;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGPushManager$22;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$22$1;->a:Lcom/tencent/android/tpush/XGPushManager$22;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onFail(Ljava/lang/Object;ILjava/lang/String;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "o@s@@o~o ~ lm r-f 4/@~~  s@dbfo~@@~vo ~@an~~~  @~@@t1i~/iy@ i@ o@.@K~b  ~bu ~@~@~ ~t@clS ~@M ~@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v1, "eedmDvielRf:esntneecw4stenriik Noela ar,g"

    const-string v1, "drsfgs 4Doleei,eeeeiwe:eakRcbt ntnarNnlvi"

    const/4 v3, 0x5

    const-string/jumbo v1, "igrnonRe efiw4:keeet,nledlceuivNerotaDbas"

    const-string/jumbo v1, "registerRunnable4NewDevice failed, token:"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo p1, "mee:Cbrrd"

    const-string p1, "erCm,:edr"

    const/4 v3, 0x0

    const-string p1, "C:,errudo"

    const-string p1, ",errCode:"

    const/4 v3, 0x6

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string p1, ",:gso"

    const/4 v3, 0x0

    const-string p1, ",spm:"

    const-string p1, ",msg:"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo p1, "llabeli,qd:yM"

    const-string p1, "Mlylibd:ela,i"

    const/4 v3, 0x7

    const-string p1, ",isyslidlaeMl"

    const-string p1, ",delayMillis:"

    const/4 v2, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$22$1;->a:Lcom/tencent/android/tpush/XGPushManager$22;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    iget-wide p1, p1, Lcom/tencent/android/tpush/XGPushManager$22;->a:J

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string/jumbo p2, "seGmgrauXMhaP"

    const-string p2, "XGPushManager"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-void
.end method

.method public onSuccess(Ljava/lang/Object;I)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v0, "bvaresuNw,unln ogsscDreeike nescReceutt:4i"

    const/4 v3, 0x5

    const-string/jumbo v0, "registerRunnable4NewDevice success, token:"

    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string p1, "dlyiop,il:Mal"

    const-string/jumbo p1, "lsillyapid:M,"

    const/4 v3, 0x7

    const-string p1, ",yaslbidile:l"

    const-string p1, ",delayMillis:"

    const/4 v3, 0x2

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    move v3, v2

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$22$1;->a:Lcom/tencent/android/tpush/XGPushManager$22;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    iget-wide v0, p1, Lcom/tencent/android/tpush/XGPushManager$22;->a:J

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string p2, "arPhgauquGeMX"

    const-string p2, "GgPXManhqraue"

    const-string/jumbo p2, "nahrsuGpMgeXP"

    const-string p2, "XGPushManager"

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    return-void
.end method
