.class Lcom/tencent/android/tpush/XGPushManager$c;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/XGPushManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "c"
.end annotation


# instance fields
.field a:Landroid/content/Context;

.field b:Landroid/content/Intent;

.field c:Lcom/tencent/android/tpush/XGIOperateCallback;

.field d:I


# direct methods
.method constructor <init>(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$c;->a:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$c;->b:Landroid/content/Intent;

    const/4 v0, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPushManager$c;->c:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x2

    iput p4, p0, Lcom/tencent/android/tpush/XGPushManager$c;->d:I

    const/4 v0, 0x6

    shl-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~4s.o~cb a@@~Sot M@d~@~@@i~~~f b~~//@@@ ~o~@   mu@ ~ ~Ki o-@@~v@t n@bi ~sf~l~ ~ @~1@ @yr~l @o@~o"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    const-string v0, "PMsureasGgahn"

    const/4 v6, 0x5

    const-string/jumbo v0, "uaMmPerGhansX"

    const-string v0, "XGPushManager"

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->d()Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/Map;->keySet()Ljava/util/Set;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    const/4 v2, 0x0

    :cond_0
    :goto_0
    const/4 v6, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    if-eqz v3, :cond_1

    const/4 v6, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    check-cast v3, Lcom/tencent/android/tpush/XGPushManager$b;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->d()Ljava/util/Map;

    move-result-object v4

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-interface {v4, v3}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v6, 0x5

    const/4 v5, 0x3

    if-ne p0, v4, :cond_0

    move-object v2, v3

    move-object v2, v3

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz v2, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$c;->a:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;)Z

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->d()Ljava/util/Map;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-interface {v1, v2}, Ljava/util/Map;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string v1, "eu moassirocagebsr mueuinreTe nmcts endteulvn"

    const-string/jumbo v1, "octmiseeuanregeunmRe ts ev n erTuinsadsbrcmlu"

    const/4 v6, 0x4

    const-string/jumbo v1, "n eenbvnmirouecdcoTtsuegnrt r emlseassibuaRue"

    const-string v1, "TimeoutRunnable unregister and remove success"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto :goto_1

    :catchall_0
    move-exception v1

    :try_start_1
    const/4 v6, 0x0

    const/4 v5, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string/jumbo v3, "ruiegnuonarf m niore: ut  eorRbT,unelsotddaevileeerm"

    const-string/jumbo v3, "nTueobv aouloRerreruoaeiir  d reenemt:d rntsgf,lemni"

    const/4 v6, 0x3

    const-string v3, "fe a rap,nr olmemeRaoeiegtrevri: bnT dunleniudetuors"

    const-string v3, "TimeoutRunnable unregister and remove failed, error:"

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string v2, "a T bs oqaipRTptma lp:ueonitnore,ebteywuteu"

    const-string/jumbo v2, "uneesbT :ut neoimRuaboia,tprp wlttoee ampyT"

    const/4 v6, 0x6

    const-string v2, ":aspproi awTmbn,u aeupseuetto ntToRmle oyit"

    const-string v2, "TimeoutRunnable optera was timeout, opType:"

    const/4 v5, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    iget v2, p0, Lcom/tencent/android/tpush/XGPushManager$c;->d:I

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    new-instance v2, Lcom/tencent/android/tpush/XGPushManager$c$1;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-direct {v2, p0}, Lcom/tencent/android/tpush/XGPushManager$c$1;-><init>(Lcom/tencent/android/tpush/XGPushManager$c;)V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    goto :goto_2

    :catchall_1
    move-exception v1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v2, "gRomTbnor mtirusiueeu eeRnrre nutl"

    const-string/jumbo v2, "nR eeiuainoesbg tnTRrul terrmuoeru"

    const/4 v6, 0x2

    const-string/jumbo v2, "uRrtoenTirbegeRmuaos inrleror ten "

    const-string v2, " RegisterTimeoutRunnable run error"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_2
    const/4 v5, 0x2

    const/4 v6, 0x7

    return-void
.end method
