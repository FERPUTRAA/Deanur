.class Lcom/tencent/android/tpush/XGPush4Msdk$12;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPush4Msdk;->deleteTags(Landroid/content/Context;Ljava/lang/String;Ljava/util/Set;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Ljava/util/Set;


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;Ljava/util/Set;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$12;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$12;->b:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$12;->c:Ljava/util/Set;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v10, "u~so~vm~@~~~@@t@@ t4or@~@1o~~ ~~c@l  f~@~@ @ @o ~ .y@  ~b is/bia@-KSi~  d~n~o@/~b@ M l@~~~ f@@ @"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x7

    sget-boolean v0, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x7

    const-string/jumbo v1, "sX4mshGMPsk"

    const-string v1, "Xss4GsPkMuh"

    const/4 v11, 0x7

    const-string/jumbo v1, "shk4osuPGdX"

    const-string v1, "XGPush4Msdk"

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x5

    if-eqz v0, :cond_0

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    const-string v2, "esam:tmpdNeel tgaare=Teo"

    const/4 v11, 0x7

    const-string v2, "aeT:dbet=emersgetpNoal e"

    const-string v2, "deleteTags: operateName="

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    move v11, v10

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$12;->a:Ljava/lang/String;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    const-string/jumbo v2, "qi,pqAu=d"

    const-string/jumbo v2, "pdq=oA,iq"

    const/4 v11, 0x7

    const-string v2, ",A=pdiqpq"

    const-string v2, ",qqAppid="

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/XGPush4Msdk;->c()J

    move-result-wide v2

    const/4 v11, 0x4

    const/4 v10, 0x7

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x6

    const-string v2, ",cs_g=csqdeia"

    const-string v2, "dsc=abg,icse_"

    const/4 v11, 0x7

    const-string v2, ",=ssacxesdcgi"

    const-string v2, ",xg_accessid="

    const/4 v11, 0x6

    const/4 v10, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$12;->b:Landroid/content/Context;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v10, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$12;->b:Landroid/content/Context;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-eqz v0, :cond_4

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$12;->c:Ljava/util/Set;

    const/4 v10, 0x6

    or-int/2addr v11, v10

    if-eqz v0, :cond_4

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-interface {v0}, Ljava/util/Set;->isEmpty()Z

    move-result v0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x5

    if-eqz v0, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    goto/16 :goto_0

    :cond_1
    const/4 v10, 0x3

    move v11, v10

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$12;->c:Ljava/util/Set;

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    const-string v2, "eaTmtlusee"

    const-string v2, "geTeesutla"

    const-string v2, "deaeoTtsge"

    const-string v2, "deleteTags"

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/XGPushManager;->a(Ljava/util/Set;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x7

    if-nez v4, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    const-string v0, "e!n tblrtlTSausem!Te -detout>pe !rnagglgreF"

    const-string v0, " otasngptarr!le tleuTmnergS!gFee >l e!-tduT"

    const/4 v11, 0x0

    const-string/jumbo v0, "tegeT-ug!esulrgaredlt!sFtln r S!teueT>mnao "

    const-string v0, "deleteTags -> getTagsFromSet return null!!!"

    const/4 v10, 0x5

    xor-int/2addr v11, v10

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x4

    return-void

    :cond_2
    const/4 v11, 0x2

    const/4 v10, 0x5

    sget-boolean v0, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x3

    if-eqz v0, :cond_3

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-string v2, "h  aastps> -eleeqwgdsg= tTl  i aTtgetl"

    const-string/jumbo v2, "tTttdg>eq seg  ahisesw alltaeT s gl -="

    const/4 v11, 0x5

    const-string v2, "aTias shqwglt Teaalet g =tsg-l>e ts e "

    const-string v2, "deleteTags -> setTags with all tags = "

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x0

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$12;->b:Landroid/content/Context;

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    const/4 v5, 0x7

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-static {v3}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v6

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$12;->b:Landroid/content/Context;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAppKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x6

    iget-object v9, p0, Lcom/tencent/android/tpush/XGPush4Msdk$12;->a:Ljava/lang/String;

    const/4 v11, 0x4

    const/4 v10, 0x0

    invoke-static/range {v3 .. v9}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    return-void

    :cond_4
    :goto_0
    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string/jumbo v0, "rnsat f se txa athpTovce mgitetddoe onl. et lresiaasgri"

    const-string/jumbo v0, "the parameter context or tags of deleteTags is invalid."

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x7

    const/4 v10, 0x5

    return-void
.end method
