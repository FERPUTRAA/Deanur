.class Lcom/tencent/android/tpush/XGPushManager$27;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->uploadLogFile(Landroid/content/Context;Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;


# direct methods
.method constructor <init>(Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$27;->a:Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;

    const/4 v1, 0x7

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, ".Ks /~@b@ir  @o ~iuo~@ ~@~1~@@Mool~t@f~@t@-y @~@@~@~~~ l  v~@ 4~@i~no  fabS ~~cd@/b~@m  @o~ ~s @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x1

    const-string p2, "aaGmsuhMPsXrg"

    const-string p2, "ghsraPMXnGaus"

    const/4 v2, 0x7

    const-string/jumbo p2, "rgseoaauhXPMn"

    const-string p2, "XGPushManager"

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string/jumbo v0, "ieR-dbalsvmhFnrecnoocei   ens"

    const-string/jumbo v0, "ncemonher- is ceiR vtonFldsae"

    const/4 v2, 0x0

    const-string v0, "action - sendFlush onReceiver"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;)Z

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    const/16 v0, 0x1a

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p2, v0}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->remove(I)V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$27;->a:Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-static {p1, p2}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->uploadLogFile(Landroid/content/Context;Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;)V

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-void
.end method
