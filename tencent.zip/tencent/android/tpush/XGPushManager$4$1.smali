.class Lcom/tencent/android/tpush/XGPushManager$4$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager$4;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Lcom/tencent/android/tpush/XGPushManager$4;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGPushManager$4;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$4$1;->b:Lcom/tencent/android/tpush/XGPushManager$4;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$4$1;->a:Landroid/content/Intent;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$4$1;->a:Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const-string/jumbo v1, "pisnsaoer"

    const-string/jumbo v1, "ptsoenari"

    const/4 v6, 0x2

    const-string/jumbo v1, "pnameoitr"

    const-string/jumbo v1, "operation"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    const/4 v2, -0x1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$4$1;->a:Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v3, "atad"

    const-string v3, "aatd"

    const-string v3, "aatd"

    const-string v3, "data"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v1, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-nez v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v6, 0x3

    const-string v1, ""

    const-string v1, ""

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v0, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v3, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eq v0, v3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$4$1;->b:Lcom/tencent/android/tpush/XGPushManager$4;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v0, v0, Lcom/tencent/android/tpush/XGPushManager$4;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$4$1;->a:Landroid/content/Intent;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo v4, "oedc"

    const-string v4, "dceo"

    const/4 v6, 0x1

    const-string/jumbo v4, "ocde"

    const-string v4, "code"

    const/4 v6, 0x7

    invoke-virtual {v3, v4, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$4$1;->a:Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string v4, "gms"

    const-string/jumbo v4, "msg"

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v3, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {v0, v1, v2, v3}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$4$1;->b:Lcom/tencent/android/tpush/XGPushManager$4;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v0, v0, Lcom/tencent/android/tpush/XGPushManager$4;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$4$1;->a:Landroid/content/Intent;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string v4, "glaf"

    const-string/jumbo v4, "lgfa"

    const/4 v6, 0x7

    const-string v4, "fgal"

    const-string v4, "flag"

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v3, v4, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-interface {v0, v1, v2}, Lcom/tencent/android/tpush/XGIOperateCallback;->onSuccess(Ljava/lang/Object;I)V

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    return-void
.end method
