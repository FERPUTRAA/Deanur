.class Lcom/tencent/android/tpush/InnerTpnsActivity$6;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/InnerTpnsActivity;->a(ILandroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Lcom/tencent/android/tpush/InnerTpnsActivity;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$6;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v1, 0x5

    const/4 v0, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$6;->a:Landroid/content/Intent;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@is@@ ~~l~M ~@@@.@@o  l@ octn~~f 1ot@@~@~-S@bu~/@~ sK ~@~ @o~@~v4@o~~rmba~ o ~~ ii ~f d@/~~ b@y "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$6;->a:Landroid/content/Intent;

    const/4 v1, 0x5

    const/4 v2, 0x6

    sget-object p2, Lcom/tencent/android/tpush/NotificationAction;->open:Lcom/tencent/android/tpush/NotificationAction;

    invoke-virtual {p2}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x2

    const-string/jumbo v0, "otnmsa"

    const-string v0, "ctsona"

    const/4 v2, 0x0

    const-string v0, "aiocot"

    const-string v0, "action"

    const/4 v1, 0x3

    move v2, v1

    invoke-virtual {p1, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v1, 0x6

    xor-int/2addr v2, v1

    iget-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$6;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object p2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$6;->a:Landroid/content/Intent;

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$6;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object p2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$6;->a:Landroid/content/Intent;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Landroid/content/ActivityNotFoundException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$6;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    return-void
.end method
