.class public Lcom/tencent/android/tpush/XGPushReceiver;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20150316"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->RECEIVERCHECK:Lcom/jg/EType;
    }
.end annotation


# instance fields
.field private a:Landroid/content/Context;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ss  ~Md @~ fv Kof ~@~@@ly@~4b @u~@ctoi@~~  ~~o - bnml ~~~@b~o r.S~@@@i i~@~ @@@~1~@~@ /t~@~/o@o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    const-string/jumbo p2, "rsvmGuseXieheR"

    const-string/jumbo p2, "uesXreRhvsPGei"

    const/4 v2, 0x4

    const-string/jumbo p2, "vhGPoieRXscuee"

    const-string p2, "XGPushReceiver"

    const/4 v2, 0x6

    const-string v0, " flrgbnMmgema irnampao"

    const-string/jumbo v0, "npgmafiearrgla mon rmM"

    const/4 v2, 0x5

    const-string/jumbo v0, "ragelMunpnamgo rriamf "

    const-string/jumbo v0, "ping from alarmManager"

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/base/util/Util;->getWakeCpu(Landroid/content/Context;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object p1, p1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const/4 p2, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Lcom/tencent/android/tpush/c/a$a;->b(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method

.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5

    const/4 v4, 0x5

    if-eqz p1, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    if-nez p2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    goto/16 :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v4, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushReceiver;->a:Landroid/content/Context;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    if-nez v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-void

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpush/service/b;->b(Landroid/content/Context;)V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    sget-boolean v1, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v1, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v2, "cce ieupr devPveRehsro"

    const-string v2, "esdio eervvceucPeh reR"

    const/4 v4, 0x3

    const-string/jumbo v2, "scrveereqicihe eRPvdu "

    const-string v2, "PushReceiver received "

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v2, "  @@"

    const/4 v4, 0x5

    const-string v2, "@ @ "

    const-string v2, " @@ "

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v2, "viseGscePXRubr"

    const-string v2, "huGecbiRsrXevP"

    const-string v2, "XGPushReceiver"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    new-instance v2, Lcom/tencent/android/tpush/XGPushReceiver$1;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {v2, p0, p1, v0, p2}, Lcom/tencent/android/tpush/XGPushReceiver$1;-><init>(Lcom/tencent/android/tpush/XGPushReceiver;Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v4, 0x1

    const/4 v3, 0x7

    return-void

    :cond_3
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/base/util/Util;->killPushProcess(Landroid/content/Context;)V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    return-void
.end method
