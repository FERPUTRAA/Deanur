.class Lcom/tencent/android/tpush/TpnsActivity$2;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/TpnsActivity;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:I

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:Lcom/tencent/android/tpush/TpnsActivity;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/TpnsActivity;Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/TpnsActivity$2;->e:Lcom/tencent/android/tpush/TpnsActivity;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpush/TpnsActivity$2;->a:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput p3, p0, Lcom/tencent/android/tpush/TpnsActivity$2;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p4, p0, Lcom/tencent/android/tpush/TpnsActivity$2;->c:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x5

    iput-object p5, p0, Lcom/tencent/android/tpush/TpnsActivity$2;->d:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~ st@v@ ~ l@o~o@ @@@@m K@~~~~~t~  ~o@a~@/1~l@~ i  r@S~~ i-b~@@ @y@/f4bfo@ obc  ~@M.ds nu~~~i o~@"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/TpnsActivity$2;->e:Lcom/tencent/android/tpush/TpnsActivity;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-lez v0, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string/jumbo v0, "vysmTitsAcni"

    const-string v0, "iTsnytsvitcA"

    const/4 v9, 0x0

    const-string/jumbo v0, "sivtonyTciAp"

    const-string v0, "TpnsActivity"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x7

    const-string v1, "emloibnealeeitb apfeGtnarilLinnholdhC "

    const-string v1, "daem inpl enonelehhinlarkLlCbfitGioeat"

    const/4 v9, 0x4

    const-string/jumbo v1, "nenietuknaafihalntpoLlhoeb ellriDCdiG "

    const-string/jumbo v1, "otherChannelDeepLink initGlobal failed"

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/TpnsActivity$2;->a:Landroid/content/Context;

    const/4 v9, 0x0

    iget v3, p0, Lcom/tencent/android/tpush/TpnsActivity$2;->b:I

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpush/TpnsActivity$2;->c:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/TpnsActivity$2;->d:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {v0}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v5

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-string/jumbo v7, "nnpor"

    const-string/jumbo v7, "nnreo"

    const/4 v9, 0x2

    const-string/jumbo v7, "renqi"

    const-string/jumbo v7, "inner"

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static/range {v2 .. v7}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    const/4 v8, 0x1

    move v9, v8

    return-void
.end method
