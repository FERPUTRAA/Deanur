.class public abstract Lcom/tencent/android/tpush/XGPushNotificationBuilder;
.super Ljava/lang/Object;


# static fields
.field public static final BASIC_NOTIFICATION_BUILDER_TYPE:Ljava/lang/String; = "basic"

.field public static final CUSTOM_NOTIFICATION_BUILDER_TYPE:Ljava/lang/String; = "custom"


# instance fields
.field protected A:Ljava/lang/String;

.field protected B:Ljava/lang/Integer;

.field protected C:Landroid/graphics/Bitmap;

.field protected D:Ljava/lang/Integer;

.field protected E:Ljava/lang/String;

.field private F:Ljava/lang/String;

.field private G:Z

.field protected a:Ljava/lang/String;

.field protected b:Ljava/lang/String;

.field protected c:Ljava/lang/Integer;

.field protected d:Landroid/app/PendingIntent;

.field protected e:Landroid/widget/RemoteViews;

.field protected f:Landroid/widget/RemoteViews;

.field protected g:I

.field protected h:I

.field protected i:Ljava/lang/Integer;

.field public isSupportNotificationGroup:Ljava/lang/Boolean;

.field protected j:Landroid/app/PendingIntent;

.field protected k:Ljava/lang/Integer;

.field protected l:Ljava/lang/Integer;

.field protected m:Ljava/lang/Integer;

.field protected n:Ljava/lang/Integer;

.field protected o:Ljava/lang/Integer;

.field protected p:Ljava/lang/Integer;

.field protected q:Ljava/lang/Integer;

.field protected r:Landroid/net/Uri;

.field protected s:Ljava/lang/CharSequence;

.field protected t:[J

.field protected u:Ljava/lang/Long;

.field protected v:Ljava/lang/Integer;

.field protected w:Landroid/graphics/Bitmap;

.field protected x:Ljava/lang/Integer;

.field protected y:Ljava/lang/String;

.field protected z:I


# direct methods
.method public constructor <init>()V
    .locals 6

    const/4 v5, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v0, "-xsn-lcdagish"

    const-string v0, "hasndnxi-gc-l"

    const/4 v5, 0x4

    const-string v0, "-cxmlendaihg-"

    const-string/jumbo v0, "xg-channle-id"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->a:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string/jumbo v1, "meseomg"

    const-string v1, "gsemsem"

    const/4 v5, 0x2

    const-string v1, "emgseba"

    const-string/jumbo v1, "message"

    const/4 v5, 0x6

    const/4 v4, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->b:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v1, 0x0

    shr-int/2addr v5, v1

    const/4 v4, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->c:Ljava/lang/Integer;

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->d:Landroid/app/PendingIntent;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->e:Landroid/widget/RemoteViews;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->f:Landroid/widget/RemoteViews;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->h:I

    const/4 v5, 0x1

    const/4 v4, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->j:Landroid/app/PendingIntent;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->k:Ljava/lang/Integer;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x7

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->l:Ljava/lang/Integer;

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->m:Ljava/lang/Integer;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->n:Ljava/lang/Integer;

    const/4 v5, 0x2

    const/4 v4, 0x0

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->o:Ljava/lang/Integer;

    const/4 v5, 0x2

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->p:Ljava/lang/Integer;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->q:Ljava/lang/Integer;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->r:Landroid/net/Uri;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->s:Ljava/lang/CharSequence;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->t:[J

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->u:Ljava/lang/Long;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->v:Ljava/lang/Integer;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->w:Landroid/graphics/Bitmap;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->x:Ljava/lang/Integer;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    iput-object v3, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v3, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput v3, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->z:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->B:Ljava/lang/Integer;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->C:Landroid/graphics/Bitmap;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->D:Ljava/lang/Integer;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->E:Ljava/lang/String;

    const/4 v4, 0x3

    xor-int/2addr v5, v4

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->F:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    iput-boolean v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->G:Z

    const/4 v5, 0x4

    return-void
.end method

.method private a(Landroid/app/Notification$Builder;Landroid/content/Context;)Ljava/lang/Object;
    .locals 21

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    move-object/from16 v3, p2

    const-string/jumbo v0, "ndgoheun-lcxa"

    const-string/jumbo v0, "nxg-oc-deanhl"

    const-string v0, "c-d-halpexnng"

    const-string/jumbo v0, "xg-channle-id"

    const-string/jumbo v4, "rBiXcuebqlsNoatndotiGuifh"

    const-string v4, "dtGBnbiNiutsarcieofulhPXo"

    const-string/jumbo v4, "uGsPhBftNtsiadlicenuooiir"

    const-string v4, "XGPushNotificationBuilder"

    :try_start_0
    invoke-virtual {v1, v3}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getChannelId(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    iget v7, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->z:I

    const/4 v8, -0x1

    if-ne v7, v8, :cond_0

    const/4 v7, 0x4

    :cond_0
    invoke-virtual {v6, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v8
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_6

    const-string v10, "hgsmnaetlLiu"

    const-string v10, "eahgnLutslbi"

    const-string v10, "enableLights"

    const-string v11, "blonoaitianebpe"

    const-string v11, "eoenaibpantbril"

    const-string/jumbo v11, "inbrobtaaieenVl"

    const-string v11, "enableVibration"

    const-class v12, Landroid/net/Uri;

    const-class v12, Landroid/net/Uri;

    const-class v12, Landroid/net/Uri;

    const-class v12, Landroid/net/Uri;

    const-string v13, "dqSueoun"

    const-string/jumbo v13, "queotnSd"

    const-string/jumbo v13, "nSsteuop"

    const-string/jumbo v13, "setSound"

    const-class v14, Ljava/lang/CharSequence;

    const-class v14, Ljava/lang/CharSequence;

    const-string/jumbo v15, "inficanhqneNdarp.oC.pnsatoaiotl"

    const-string/jumbo v15, "tfsnriintlnahaocCdn..iiapooepaN"

    const-string v15, "ens.noiaidfhrapaoidci.poCtnlnaN"

    const-string v15, "android.app.NotificationChannel"

    const-string v16, "ddumrbadtmAsAi.inao.eoetiiurm"

    const-string/jumbo v16, "udamdenum.t.sAordidtAriaibioe"

    const-string/jumbo v16, "ur.AoAoaiaedntuboddte.imrtisd"

    const-string v16, "android.media.AudioAttributes"

    const-string v9, "dstehbolaneI"

    const-string v9, "CltsoaehdenI"

    const-string v9, "IneedlushaCt"

    const-string/jumbo v9, "setChannelId"

    const-class v17, Ljava/lang/String;

    const-class v17, Ljava/lang/String;

    const-class v17, Ljava/lang/String;

    const-class v17, Ljava/lang/String;

    const/16 v18, 0x0

    if-eqz v8, :cond_5

    :try_start_1
    invoke-static/range {v16 .. v16}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v8

    invoke-static {v15}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v15

    move-object/from16 v19, v0

    move-object/from16 v19, v0

    move-object/from16 v19, v0

    move-object/from16 v19, v0

    const/4 v5, 0x3

    new-array v0, v5, [Ljava/lang/Class;

    aput-object v17, v0, v18

    const/4 v5, 0x1

    aput-object v14, v0, v5

    sget-object v5, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v14, 0x2

    aput-object v5, v0, v14

    invoke-virtual {v15, v0}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v0

    iget-object v5, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    if-nez v5, :cond_1

    invoke-static/range {v18 .. v18}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    iput-object v5, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    :cond_1
    iget-object v5, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    packed-switch v5, :pswitch_data_0

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    goto :goto_0

    :pswitch_0
    move-object/from16 v5, v19

    move-object/from16 v5, v19

    move-object/from16 v5, v19

    move-object/from16 v5, v19

    goto :goto_0

    :pswitch_1
    const-string v5, "hvinegnpc-ad--l-x"

    const-string/jumbo v5, "xg-l-v-channle-id"

    goto :goto_0

    :pswitch_2
    const-string/jumbo v5, "nhil-bg-xl-nsae-d"

    const-string/jumbo v5, "xg-s-l-channle-id"

    goto :goto_0

    :pswitch_3
    const-string v5, "gdcenl-lqniu--h"

    const-string v5, "-c-h-xudglnieln"

    const-string/jumbo v5, "lnsdexn-cgi--ah"

    const-string/jumbo v5, "xg-l-channle-id"

    goto :goto_0

    :pswitch_4
    const-string v5, "g-enh-dp-cnsxvila"

    const-string v5, "-sxmd-l-vngnecah-"

    const-string/jumbo v5, "xg-s-v-channle-id"

    goto :goto_0

    :pswitch_5
    const-string/jumbo v5, "ldnqoe-cxai-nh-"

    const-string/jumbo v5, "x-a-cihnq-dnleg"

    const-string/jumbo v5, "ignxhba-levnc--"

    const-string/jumbo v5, "xg-v-channle-id"

    goto :goto_0

    :pswitch_6
    const-string/jumbo v5, "xngesludscnh-i-"

    const-string v5, "-cs--hsngxlendi"

    const-string v5, "dxl-ihcpsnane-g"

    const-string/jumbo v5, "xg-s-channle-id"

    goto :goto_0

    :pswitch_7
    const-string/jumbo v5, "nlx-cd-mqneha-g"

    const-string v5, "-ndm-lnnaghx-ce"

    const-string v5, "-ns-endaihlgncx"

    const-string/jumbo v5, "xg-n-channle-id"

    :goto_0
    iget-object v6, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->r:Landroid/net/Uri;

    if-eqz v6, :cond_3

    invoke-static {v3, v6}, Lcom/tencent/android/tpush/service/util/c;->a(Landroid/content/Context;Landroid/net/Uri;)Ljava/lang/String;

    move-result-object v5

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v14, "ognmce  elnsaiht te"

    const-string v14, "ea eole gnn:tcthi s"

    const-string/jumbo v14, "n n ol :ecehtisgexa"

    const-string v14, "get exist channel: "

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v14, "sn  tbwi hdu"

    const-string/jumbo v14, "nd ihb usw t"

    const-string/jumbo v14, "nows tu dhiu"

    const-string v14, " with sound "

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v14, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->r:Landroid/net/Uri;

    invoke-virtual {v14}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_2

    goto :goto_1

    :cond_2
    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v1, v3}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getChannelId(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v6, "-"

    const-string v6, "-"

    const-string v6, "-"

    const-string v6, "-"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-direct {v1, v3}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->b(Landroid/content/Context;)I

    move-result v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    :cond_3
    :goto_1
    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v14, ",i:tn opPltenhXuancttuafhnnciliieoiinIocNnafcdetGChsr eaa"

    const-string/jumbo v14, "n ati:uniehlenntd,hosttoon efifacIacPaNeChniictiluGnrcaX "

    const-string v14, "ia ,onleqoiaGadhPncfIihanntecNtotrnce ttoilsiXhn :iCneauf"

    const-string v14, "XGPushNotification create notificationChannle, channelId:"

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, "a saecNe,m:hnl"

    const-string v14, ", channelName:"

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getChannelName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v14, "e, mnmpcripat"

    const-string/jumbo v14, "te,m:r papnic"

    const-string/jumbo v14, "oa con,iermt:"

    const-string v14, ", importance:"

    invoke-virtual {v6, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v4, v6}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    new-array v6, v6, [Ljava/lang/Object;

    aput-object v5, v6, v18

    invoke-virtual {v1, v3}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getChannelName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v14, 0x1

    aput-object v3, v6, v14

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v7, 0x2

    aput-object v3, v6, v7

    invoke-virtual {v0, v6}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :try_start_2
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    new-array v6, v7, [Ljava/lang/Class;

    aput-object v12, v6, v18

    const/4 v7, 0x1

    aput-object v8, v6, v7

    invoke-virtual {v0, v13, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    new-array v8, v7, [Ljava/lang/Class;

    sget-object v7, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v7, v8, v18

    invoke-virtual {v6, v11, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v6

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v8

    const/4 v11, 0x1

    new-array v12, v11, [Ljava/lang/Class;

    aput-object v7, v12, v18

    invoke-virtual {v8, v10, v12}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v7

    iget-object v8, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    packed-switch v8, :pswitch_data_1

    goto/16 :goto_2

    :pswitch_8
    const/4 v8, 0x1

    new-array v10, v8, [Ljava/lang/Object;

    sget-object v11, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    aput-object v11, v10, v18

    invoke-virtual {v6, v3, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v6, v8, [Ljava/lang/Object;

    aput-object v11, v6, v18

    invoke-virtual {v7, v3, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_2

    :pswitch_9
    const/4 v8, 0x2

    new-array v10, v8, [Ljava/lang/Object;

    const/4 v8, 0x0

    aput-object v8, v10, v18

    const/4 v11, 0x1

    aput-object v8, v10, v11

    invoke-virtual {v0, v3, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v8, v11, [Ljava/lang/Object;

    sget-object v10, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    aput-object v10, v8, v18

    invoke-virtual {v6, v3, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v6, v11, [Ljava/lang/Object;

    aput-object v10, v6, v18

    invoke-virtual {v7, v3, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_2

    :pswitch_a
    const/4 v8, 0x1

    new-array v10, v8, [Ljava/lang/Object;

    sget-object v11, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    aput-object v11, v10, v18

    invoke-virtual {v6, v3, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v6, v8, [Ljava/lang/Object;

    sget-object v8, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    aput-object v8, v6, v18

    invoke-virtual {v7, v3, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto/16 :goto_2

    :pswitch_b
    const/4 v8, 0x2

    new-array v10, v8, [Ljava/lang/Object;

    const/4 v8, 0x0

    aput-object v8, v10, v18

    const/4 v11, 0x1

    aput-object v8, v10, v11

    invoke-virtual {v0, v3, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v8, v11, [Ljava/lang/Object;

    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    aput-object v10, v8, v18

    invoke-virtual {v6, v3, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v6, v11, [Ljava/lang/Object;

    sget-object v8, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    aput-object v8, v6, v18

    invoke-virtual {v7, v3, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    :pswitch_c
    const/4 v8, 0x1

    new-array v10, v8, [Ljava/lang/Object;

    sget-object v11, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    aput-object v11, v10, v18

    invoke-virtual {v6, v3, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v6, v8, [Ljava/lang/Object;

    sget-object v8, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    aput-object v8, v6, v18

    invoke-virtual {v7, v3, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    :pswitch_d
    const/4 v8, 0x2

    new-array v10, v8, [Ljava/lang/Object;

    const/4 v8, 0x0

    aput-object v8, v10, v18

    const/4 v11, 0x1

    aput-object v8, v10, v11

    invoke-virtual {v0, v3, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v8, v11, [Ljava/lang/Object;

    sget-object v10, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    aput-object v10, v8, v18

    invoke-virtual {v6, v3, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v6, v11, [Ljava/lang/Object;

    sget-object v8, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    aput-object v8, v6, v18

    invoke-virtual {v7, v3, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    :pswitch_e
    const/4 v8, 0x1

    new-array v10, v8, [Ljava/lang/Object;

    sget-object v11, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    aput-object v11, v10, v18

    invoke-virtual {v6, v3, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v6, v8, [Ljava/lang/Object;

    aput-object v11, v6, v18

    invoke-virtual {v7, v3, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_2

    :pswitch_f
    const/4 v8, 0x2

    new-array v10, v8, [Ljava/lang/Object;

    const/4 v8, 0x0

    aput-object v8, v10, v18

    const/4 v11, 0x1

    aput-object v8, v10, v11

    invoke-virtual {v0, v3, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v8, v11, [Ljava/lang/Object;

    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    aput-object v10, v8, v18

    invoke-virtual {v6, v3, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v6, v11, [Ljava/lang/Object;

    aput-object v10, v6, v18

    invoke-virtual {v7, v3, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :goto_2
    iget-object v6, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->r:Landroid/net/Uri;

    if-eqz v6, :cond_4

    const/4 v7, 0x2

    new-array v7, v7, [Ljava/lang/Object;

    aput-object v6, v7, v18

    const/4 v6, 0x1

    const/4 v8, 0x0

    aput-object v8, v7, v6

    invoke-virtual {v0, v3, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_4
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v6, 0x1

    new-array v7, v6, [Ljava/lang/Class;

    aput-object v17, v7, v18

    invoke-virtual {v0, v9, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-array v6, v6, [Ljava/lang/Object;

    aput-object v5, v6, v18

    invoke-virtual {v0, v2, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    iput-object v5, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->F:Ljava/lang/String;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_4

    goto/16 :goto_8

    :catchall_0
    move-exception v0

    const/4 v5, 0x0

    goto/16 :goto_7

    :cond_5
    :try_start_3
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "oiancbhi:canlthencniifsatCNtGPoueXaaqthcsnloIi hoeideafn  n "

    const-string v5, "hinaoactqlaaoNn: neecneC iuidts PofGntliaoacfXIicntn ithhhse"

    const-string/jumbo v5, "ntisi ucaGfdotahneecnCilIatn ithhfaonitoPn io auaXrNehcencl:"

    const-string v5, "XGPushNotification create notificationChannel has channelId:"

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_6

    :try_start_4
    const-string v0, "icansitpfnio"

    const-string v0, "cistnfniiaoo"

    const-string v0, "aiinofttqico"

    const-string/jumbo v0, "notification"

    invoke-virtual {v3, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroid/app/NotificationManager;

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    const-string/jumbo v8, "ogemiciNenafitatCotnnh"

    const-string v8, "ctslietinhenfoigtnoNCa"

    const-string v8, "getNotificationChannel"
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    move-object/from16 v19, v10

    move-object/from16 v19, v10

    move-object/from16 v19, v10

    move-object/from16 v19, v10

    move-object/from16 v20, v11

    move-object/from16 v20, v11

    move-object/from16 v20, v11

    move-object/from16 v20, v11

    const/4 v10, 0x1

    :try_start_5
    new-array v11, v10, [Ljava/lang/Class;

    aput-object v17, v11, v18

    invoke-virtual {v5, v8, v11}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    new-array v8, v10, [Ljava/lang/Object;

    aput-object v6, v8, v18

    invoke-virtual {v5, v0, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :try_start_6
    iput-object v6, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->F:Ljava/lang/String;

    if-eqz v5, :cond_6

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v8, "htdm:odonaionclf oUnC  leiesnit"

    const-string v8, "cnnoodditilUahtni lsne e iCo:fo"

    const-string v8, " n:hotadsni CceUfledin toiooinl"

    const-string v8, "Use old notificationChannel id:"

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v4, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v8, 0x1

    new-array v10, v8, [Ljava/lang/Class;

    aput-object v17, v10, v18

    invoke-virtual {v0, v9, v10}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-array v10, v8, [Ljava/lang/Object;

    aput-object v6, v10, v18

    invoke-virtual {v0, v2, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    return-object v5

    :catchall_1
    move-exception v0

    goto :goto_4

    :catchall_2
    move-exception v0

    goto :goto_3

    :catchall_3
    move-exception v0

    move-object/from16 v19, v10

    move-object/from16 v19, v10

    move-object/from16 v19, v10

    move-object/from16 v19, v10

    move-object/from16 v20, v11

    move-object/from16 v20, v11

    move-object/from16 v20, v11

    move-object/from16 v20, v11

    :goto_3
    const/4 v5, 0x0

    :goto_4
    :try_start_7
    new-instance v8, Ljava/lang/StringBuilder;

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const-string v10, "NueosbnEfieba  rior:t ngohGiirtohlfctiitXanctPnCa"

    const-string/jumbo v10, "ioaNXber :  GrnioiglsfnoctiotcrhfniuCEithnatoetaP"

    const-string v10, "XGPushNotification getNotificationChannel Error: "

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v10

    invoke-virtual {v8, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-static {v4, v8}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_6
    invoke-static/range {v16 .. v16}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    invoke-static {v15}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v8

    const/4 v10, 0x3

    new-array v11, v10, [Ljava/lang/Class;

    aput-object v17, v11, v18

    const/4 v10, 0x1

    aput-object v14, v11, v10

    sget-object v10, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v14, 0x2

    aput-object v10, v11, v14

    invoke-virtual {v8, v11}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    move-result-object v8

    const/4 v10, 0x3

    new-array v10, v10, [Ljava/lang/Object;

    aput-object v6, v10, v18

    invoke-virtual {v1, v3}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getChannelName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x1

    aput-object v3, v10, v11

    invoke-static {v7}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v7, 0x2

    aput-object v3, v10, v7

    invoke-virtual {v8, v10}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_5

    :try_start_8
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    new-array v8, v7, [Ljava/lang/Class;

    aput-object v12, v8, v18

    const/4 v7, 0x1

    aput-object v0, v8, v7

    invoke-virtual {v5, v13, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v5

    new-array v8, v7, [Ljava/lang/Class;

    sget-object v7, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    aput-object v7, v8, v18

    move-object/from16 v10, v20

    move-object/from16 v10, v20

    move-object/from16 v10, v20

    move-object/from16 v10, v20

    invoke-virtual {v5, v10, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v8

    const/4 v10, 0x1

    new-array v11, v10, [Ljava/lang/Class;

    aput-object v7, v11, v18

    move-object/from16 v7, v19

    move-object/from16 v7, v19

    move-object/from16 v7, v19

    move-object/from16 v7, v19

    invoke-virtual {v8, v7, v11}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v7

    iget-object v8, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    if-eqz v8, :cond_a

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    const/4 v10, 0x1

    and-int/2addr v8, v10

    if-eq v8, v10, :cond_7

    const/4 v8, 0x2

    new-array v11, v8, [Ljava/lang/Object;

    const/4 v8, 0x0

    aput-object v8, v11, v18

    aput-object v8, v11, v10

    invoke-virtual {v0, v3, v11}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_7
    iget-object v8, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    const/4 v10, 0x2

    and-int/2addr v8, v10

    if-ne v8, v10, :cond_8

    const/4 v8, 0x1

    new-array v10, v8, [Ljava/lang/Object;

    sget-object v8, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    aput-object v8, v10, v18

    invoke-virtual {v5, v3, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_5

    :cond_8
    const/4 v8, 0x1

    new-array v10, v8, [Ljava/lang/Object;

    sget-object v8, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    aput-object v8, v10, v18

    invoke-virtual {v5, v3, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :goto_5
    iget-object v5, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v8, 0x4

    and-int/2addr v5, v8

    if-ne v5, v8, :cond_9

    const/4 v5, 0x1

    new-array v8, v5, [Ljava/lang/Object;

    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    aput-object v5, v8, v18

    invoke-virtual {v7, v3, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_6

    :cond_9
    const/4 v5, 0x1

    new-array v8, v5, [Ljava/lang/Object;

    sget-object v5, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    aput-object v5, v8, v18

    invoke-virtual {v7, v3, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    goto :goto_6

    :cond_a
    const/4 v8, 0x2

    new-array v10, v8, [Ljava/lang/Object;

    const/4 v8, 0x0

    aput-object v8, v10, v18

    const/4 v11, 0x1

    aput-object v8, v10, v11

    invoke-virtual {v0, v3, v10}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v8, v11, [Ljava/lang/Object;

    sget-object v10, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    aput-object v10, v8, v18

    invoke-virtual {v5, v3, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    new-array v5, v11, [Ljava/lang/Object;

    aput-object v10, v5, v18

    invoke-virtual {v7, v3, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :goto_6
    iget-object v5, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->k:Ljava/lang/Integer;

    if-eqz v5, :cond_b

    const/4 v5, 0x1

    new-array v8, v5, [Ljava/lang/Object;

    sget-object v5, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    aput-object v5, v8, v18

    invoke-virtual {v7, v3, v8}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_b
    iget-object v5, v1, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->r:Landroid/net/Uri;

    if-eqz v5, :cond_c

    const/4 v7, 0x2

    new-array v7, v7, [Ljava/lang/Object;

    aput-object v5, v7, v18

    const/4 v5, 0x1

    const/4 v8, 0x0

    aput-object v8, v7, v5

    invoke-virtual {v0, v3, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    :cond_c
    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v0

    const/4 v5, 0x1

    new-array v7, v5, [Ljava/lang/Class;

    aput-object v17, v7, v18

    invoke-virtual {v0, v9, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    new-array v5, v5, [Ljava/lang/Object;

    aput-object v6, v5, v18

    invoke-virtual {v0, v2, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    goto :goto_8

    :catchall_4
    move-exception v0

    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    goto :goto_7

    :catchall_5
    move-exception v0

    goto :goto_7

    :catchall_6
    move-exception v0

    const/4 v8, 0x0

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    :goto_7
    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "tocnesuEeaour:rrl cihGatNXiciu ota hP nnf"

    const-string v3, "hrPeftuchalrto iEGcenaitnon:riXo  Nuces a"

    const-string v3, "eourciNprEhol iXfatnePcrGneo ctara: ishn "

    const-string v3, "XGPushNotification create channel Error: "

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-static {v4, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual {v0}, Ljava/lang/Throwable;->printStackTrace()V

    move-object v3, v5

    move-object v3, v5

    move-object v3, v5

    move-object v3, v5

    :goto_8
    return-object v3

    nop

    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch

    :pswitch_data_1
    .packed-switch 0x0
        :pswitch_f
        :pswitch_e
        :pswitch_d
        :pswitch_c
        :pswitch_b
        :pswitch_a
        :pswitch_9
        :pswitch_8
    .end packed-switch
.end method

.method private b(Landroid/content/Context;)I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~@@~fosq@ b@Mn vi~~i~~ l~t ly~@4c~ @t   o @@u @.@@do@@b@boiS~ -    o~ @r~K~/~~@~o1m~ ~f~/a@@~@~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string/jumbo v1, "nosuhtscppauhndn.utsclen."

    const-string/jumbo v1, "nudtpnepshhulcn.u.a.stocn"

    const/4 v4, 0x2

    const-string v1, "h.emunnuu.hsdtcnla.tsonop"

    const-string/jumbo v1, "tpush.sound.channel.count"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p1, v1, v0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->getInt(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    add-int/lit8 v2, v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p1, v1, v2}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setInt(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    return v0
.end method

.method private c(Landroid/content/Context;)Landroid/app/Notification;
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    new-instance v0, Landroidx/core/app/x1$g;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {v0, p1}, Landroidx/core/app/x1$g;-><init>(Landroid/content/Context;)V

    const/4 v7, 0x2

    const/4 v6, 0x6

    new-instance v1, Landroidx/core/app/x1$e;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-direct {v1}, Landroidx/core/app/x1$e;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->v:Ljava/lang/Integer;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz v2, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v0, v2}, Landroidx/core/app/x1$g;->t0(I)Landroidx/core/app/x1$g;

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->D:Ljava/lang/Integer;

    const/4 v7, 0x3

    const/4 v6, 0x5

    if-eqz v2, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0, v2}, Landroidx/core/app/x1$g;->J(I)Landroidx/core/app/x1$g;

    :cond_1
    const/4 v7, 0x2

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->x:Ljava/lang/Integer;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string v3, "ciNnoiuuliBtqoPftdhoirXse"

    const-string v3, "deBiaXnuqcriNtoosPuhifilt"

    const/4 v7, 0x6

    const-string v3, "XGPushNotificationBuilder"

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-eqz v2, :cond_2

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    iget v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v7, 0x6

    const/4 v6, 0x1

    if-gtz v2, :cond_2

    const/4 v6, 0x7

    move v7, v6

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->x:Ljava/lang/Integer;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v2, v4}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Landroidx/core/app/x1$g;->c0(Landroid/graphics/Bitmap;)Landroidx/core/app/x1$g;
    :try_end_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_0

    :catch_0
    move-exception v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v5, "leIo biao eicnoC gapsrieoarettBtsonmgmcsudfiL tote"

    const-string/jumbo v5, "iosonltCagim c taetgitemtoroaLoco sfendes prBuierI"

    const/4 v7, 0x2

    const-string v5, "atmturucoagge CiiemensBprreIfoNo oostL  dointtlace"

    const-string v5, "getNotificationCompatBuilder setLargeIcon res oom "

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->w:Landroid/graphics/Bitmap;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v2, :cond_3

    const/4 v6, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget v4, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    if-gtz v4, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v2}, Landroidx/core/app/x1$g;->c0(Landroid/graphics/Bitmap;)Landroidx/core/app/x1$g;

    :cond_3
    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->A:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-nez v2, :cond_4

    const/4 v7, 0x0

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getTitle(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->A:Ljava/lang/String;

    const/4 v7, 0x5

    goto :goto_1

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0, v2}, Landroidx/core/app/x1$g;->P(Ljava/lang/CharSequence;)Landroidx/core/app/x1$g;

    :goto_1
    const/4 v7, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->s:Ljava/lang/CharSequence;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    if-eqz p1, :cond_5

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->e:Landroid/widget/RemoteViews;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-nez v2, :cond_5

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v1, p1}, Landroidx/core/app/x1$e;->A(Ljava/lang/CharSequence;)Landroidx/core/app/x1$e;

    const/4 v7, 0x0

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Landroidx/core/app/x1$g;->z0(Landroidx/core/app/x1$q;)Landroidx/core/app/x1$g;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->s:Ljava/lang/CharSequence;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0, p1}, Landroidx/core/app/x1$g;->O(Ljava/lang/CharSequence;)Landroidx/core/app/x1$g;

    const/4 v6, 0x2

    move v7, v6

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->s:Ljava/lang/CharSequence;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0, p1}, Landroidx/core/app/x1$g;->B0(Ljava/lang/CharSequence;)Landroidx/core/app/x1$g;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    goto :goto_2

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v0, p1}, Landroidx/core/app/x1$g;->O(Ljava/lang/CharSequence;)Landroidx/core/app/x1$g;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->s:Ljava/lang/CharSequence;

    const/4 v7, 0x1

    const/4 v6, 0x3

    invoke-virtual {v0, p1}, Landroidx/core/app/x1$g;->B0(Ljava/lang/CharSequence;)Landroidx/core/app/x1$g;

    :goto_2
    const/4 v7, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->C:Landroid/graphics/Bitmap;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-eqz p1, :cond_6

    :try_start_1
    const/4 v6, 0x0

    const/4 v7, 0x4

    new-instance p1, Landroidx/core/app/x1$d;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-direct {p1}, Landroidx/core/app/x1$d;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->C:Landroid/graphics/Bitmap;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {p1, v1}, Landroidx/core/app/x1$d;->C(Landroid/graphics/Bitmap;)Landroidx/core/app/x1$d;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, p1}, Landroidx/core/app/x1$g;->z0(Landroidx/core/app/x1$q;)Landroidx/core/app/x1$g;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x2

    goto :goto_3

    :catchall_0
    move-exception p1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string/jumbo v2, "ots ognpameNfuotSlpteiBitrtreyiemcad ieCo tl"

    const-string v2, "BC mpuclntfmterootiitaaiNesroySreei tgedo tl"

    const-string/jumbo v2, "tCicey rqlreogNemrafrtdSetloeaittu tBoin spi"

    const-string v2, "getNotificationCompatBuilder setStyle error "

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_6
    :goto_3
    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    const/4 v1, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-lez p1, :cond_8

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->h:I

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    if-eq p1, v1, :cond_7

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v7, 0x3

    const/16 v2, 0x1f

    const/4 v6, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-ge p1, v2, :cond_7

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHuaWei()Z

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    if-nez p1, :cond_7

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHonor()Z

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz p1, :cond_8

    :cond_7
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    new-instance p1, Landroidx/core/app/x1$i;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-direct {p1}, Landroidx/core/app/x1$i;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v0, p1}, Landroidx/core/app/x1$g;->z0(Landroidx/core/app/x1$q;)Landroidx/core/app/x1$g;

    :cond_8
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->E:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz p1, :cond_a

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    sget p1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/16 v2, 0x18

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-lt p1, v2, :cond_a

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/d/d;->j()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x7

    const-string/jumbo v2, "popo"

    const-string/jumbo v2, "oppo"

    const/4 v7, 0x3

    const-string/jumbo v2, "popo"

    const-string/jumbo v2, "oppo"

    const/4 v6, 0x6

    xor-int/2addr v7, v6

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-nez v2, :cond_a

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v6, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-lez v2, :cond_9

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v2, "oviv"

    const-string/jumbo v2, "ivvo"

    const/4 v7, 0x4

    const-string/jumbo v2, "vovi"

    const-string/jumbo v2, "vivo"

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-nez p1, :cond_a

    :cond_9
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v2, 0x3

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eq p1, v2, :cond_a

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->E:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v0, p1}, Landroidx/core/app/x1$g;->Z(Ljava/lang/String;)Landroidx/core/app/x1$g;

    :cond_a
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Landroidx/core/app/x1$g;->r0(Z)Landroidx/core/app/x1$g;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-eqz p1, :cond_b

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    if-nez p1, :cond_b

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v0, p1}, Landroidx/core/app/x1$g;->G(Ljava/lang/String;)Landroidx/core/app/x1$g;

    :cond_b
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Landroidx/core/app/x1$g;->G0(I)Landroidx/core/app/x1$g;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v0}, Landroidx/core/app/x1$g;->h()Landroid/app/Notification;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    return-object p1
.end method

.method public static createNotificationChannel(Landroid/content/Context;Ljava/lang/Object;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V
    .locals 10

    const/4 v9, 0x2

    const/4 v8, 0x6

    const-string v0, "fituonohilBsoeGXPNuratidc"

    const/4 v9, 0x3

    const-string/jumbo v0, "nosBuiXituPtieildhoascfGN"

    const-string v0, "XGPushNotificationBuilder"

    const/4 v9, 0x2

    const/4 v8, 0x2

    const-string v1, "hanmeeoctiiroflatitNacbeC"

    const-string v1, "eootrbitneNCcilcaatnhfaei"

    const/4 v9, 0x4

    const-string v1, "CfleorocintaotiNhncitenea"

    const-string v1, "createNotificationChannel"

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x1

    if-eqz p1, :cond_2

    :try_start_0
    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string/jumbo v2, "ncitubfeionaooiapnainrdNp.tdClh"

    const-string/jumbo v2, "naretnuonicto.odpifCNalnpihdiaa"

    const/4 v9, 0x3

    const-string v2, "iCifdNuaolrcoaontpnphd.nieian.a"

    const-string v2, "android.app.NotificationChannel"

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v2}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v3, -0x1

    const/4 v9, 0x0

    const/4 v4, 0x1

    const/4 v9, 0x5

    const/4 v4, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x2

    const/4 v5, 0x1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-eqz p2, :cond_0

    :try_start_1
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {p2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getNotificationImportance()I

    move-result p2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    goto :goto_0

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x2

    move p2, v3

    move p2, v3

    move p2, v3

    move p2, v3

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eq p2, v3, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    const-string v6, "iNocoeipmptnlirfne,cheacoCr ttnenp:ata"

    const-string/jumbo v6, "peeCoaopnttnrct,N:canrtlceanhiioif mei"

    const/4 v9, 0x1

    const-string/jumbo v6, "nr: tntpqoaeoNc,nlCohrineieiaictmcftea"

    const-string v6, "createNotificationChannel, importance:"

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static {v0, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    const-string v3, "aeserqnmsItop"

    const-string/jumbo v3, "ptomasIcqrene"

    const/4 v9, 0x1

    const-string/jumbo v3, "pmomeecraItns"

    const-string/jumbo v3, "setImportance"

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-array v6, v5, [Ljava/lang/Class;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    sget-object v7, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    aput-object v7, v6, v4

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v2, v3, v6}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    new-array v6, v5, [Ljava/lang/Object;

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-static {p2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p2

    const/4 v9, 0x6

    const/4 v8, 0x7

    aput-object p2, v6, v4

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {v3, p1, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :cond_1
    :try_start_2
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string p2, "iaftosioonni"

    const-string/jumbo p2, "iosnaointcif"

    const/4 v9, 0x2

    const-string/jumbo p2, "iotnfbniacti"

    const-string/jumbo p2, "notification"

    const/4 v8, 0x4

    move v9, v8

    invoke-virtual {p0, p2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    check-cast p0, Landroid/app/NotificationManager;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p2

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    new-array v3, v5, [Ljava/lang/Class;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    aput-object v2, v3, v4

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p2, v1, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p2

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    new-array v1, v5, [Ljava/lang/Object;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    aput-object p1, v1, v4

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {p2, p0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    goto :goto_1

    :catchall_1
    move-exception p0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string p1, " hCicXu iNrrteaio:uGoemnnNt fcloroanitftaeEicsionrta"

    const-string p1, "C emfirnacrohaooXor etafcriniPuNsneNtlnoGEct:i itita"

    const/4 v9, 0x1

    const-string/jumbo p1, "nGcfi PptnontrnENt iatfhricotirsiar: CeNeoiochuoaela"

    const-string p1, "XGPushNotification createNotificationChannel Error: "

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {v0, p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_2
    :goto_1
    const/4 v9, 0x4

    return-void
.end method


# virtual methods
.method protected a(Landroid/content/Context;)Landroid/util/Pair;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Landroid/util/Pair<",
            "Landroid/app/Notification;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->B:Ljava/lang/Integer;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-nez v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->B:Ljava/lang/Integer;

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v1, "BXadsoTDqlcSG.ufihKIiN nottiVP :INON_R.iuS"

    const-string/jumbo v1, "nNaiou. oitoOBSGc uNSDIi_XRtT.lis:PfhKNIVd"

    const/4 v4, 0x5

    const-string v1, "_osBosciKRGn.uSa SONldtNfIXt ViNihIiTD.EPu"

    const-string v1, "XGPushNotification Build.VERSION.SDK_INT: "

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v2, "t ,mDargKteS"

    const-string v2, ", targetSDK:"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v2, v2, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    const/4 v4, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v2, "cBuPoubenNftlaXidrtiGohos"

    const-string v2, "GoPuXbfcBstNeildahoitnriu"

    const/4 v4, 0x7

    const-string v2, "NhXutbsnoiudiioBeGrcliaPt"

    const-string v2, "XGPushNotificationBuilder"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/16 v0, 0x1a

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-lt v1, v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    iget v1, v1, Landroid/content/pm/ApplicationInfo;->targetSdkVersion:I

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-ge v1, v0, :cond_1

    const/4 v4, 0x1

    iget-boolean v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->G:Z

    const/4 v4, 0x0

    if-eqz v0, :cond_2

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getChannelNotification(Landroid/content/Context;)Landroid/util/Pair;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v0, p1, Landroid/util/Pair;->first:Ljava/lang/Object;

    const/4 v3, 0x2

    move v4, v3

    check-cast v0, Landroid/app/Notification;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget-object p1, p1, Landroid/util/Pair;->second:Ljava/lang/Object;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    goto :goto_0

    :cond_2
    const/4 v3, 0x4

    move v4, v3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->c(Landroid/content/Context;)Landroid/app/Notification;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->c:Ljava/lang/Integer;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz v1, :cond_3

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    iput v1, v0, Landroid/app/Notification;->audioStreamType:I

    :cond_3
    const/4 v3, 0x4

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->d:Landroid/app/PendingIntent;

    const/4 v3, 0x2

    shl-int/2addr v4, v3

    if-eqz v1, :cond_4

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-object v1, v0, Landroid/app/Notification;->contentIntent:Landroid/app/PendingIntent;

    :cond_4
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->f:Landroid/widget/RemoteViews;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v1, :cond_5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-object v1, v0, Landroid/app/Notification;->bigContentView:Landroid/widget/RemoteViews;

    :cond_5
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->e:Landroid/widget/RemoteViews;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-eqz v1, :cond_6

    const/4 v3, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput-object v1, v0, Landroid/app/Notification;->contentView:Landroid/widget/RemoteViews;

    :cond_6
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v1, :cond_7

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput v1, v0, Landroid/app/Notification;->defaults:I

    :cond_7
    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->l:Ljava/lang/Integer;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-eqz v1, :cond_8

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput v1, v0, Landroid/app/Notification;->icon:I

    :cond_8
    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->j:Landroid/app/PendingIntent;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    if-eqz v1, :cond_9

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput-object v1, v0, Landroid/app/Notification;->deleteIntent:Landroid/app/PendingIntent;

    :cond_9
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->k:Ljava/lang/Integer;

    const/4 v4, 0x0

    const/4 v3, 0x3

    if-eqz v1, :cond_a

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput v1, v0, Landroid/app/Notification;->flags:I

    const/4 v4, 0x3

    goto :goto_1

    :cond_a
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/16 v1, 0x10

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput v1, v0, Landroid/app/Notification;->flags:I

    :goto_1
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->m:Ljava/lang/Integer;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v1, :cond_b

    const/4 v3, 0x2

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput v1, v0, Landroid/app/Notification;->iconLevel:I

    :cond_b
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->n:Ljava/lang/Integer;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz v1, :cond_c

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    iput v1, v0, Landroid/app/Notification;->ledARGB:I

    :cond_c
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->o:Ljava/lang/Integer;

    const/4 v3, 0x3

    move v4, v3

    if-eqz v1, :cond_d

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput v1, v0, Landroid/app/Notification;->ledOffMS:I

    :cond_d
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->p:Ljava/lang/Integer;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v1, :cond_e

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput v1, v0, Landroid/app/Notification;->ledOnMS:I

    :cond_e
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->q:Ljava/lang/Integer;

    const/4 v3, 0x3

    const/4 v4, 0x6

    if-eqz v1, :cond_f

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput v1, v0, Landroid/app/Notification;->number:I

    :cond_f
    const/4 v4, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->r:Landroid/net/Uri;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v1, :cond_10

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput-object v1, v0, Landroid/app/Notification;->sound:Landroid/net/Uri;

    :cond_10
    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->t:[J

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz v1, :cond_11

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    iput-object v1, v0, Landroid/app/Notification;->vibrate:[J

    :cond_11
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->u:Ljava/lang/Long;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-eqz v1, :cond_12

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput-wide v1, v0, Landroid/app/Notification;->when:J

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_2

    :cond_12
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-wide v1, v0, Landroid/app/Notification;->when:J

    :goto_2
    const/4 v4, 0x2

    new-instance v1, Landroid/util/Pair;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-direct {v1, v0, p1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object v1
.end method

.method protected abstract a(Lorg/json/JSONObject;)V
.end method

.method protected abstract b(Lorg/json/JSONObject;)V
.end method

.method public abstract buildNotification(Landroid/content/Context;)Landroid/util/Pair;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Landroid/util/Pair<",
            "Landroid/app/Notification;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end method

.method public decode(Ljava/lang/String;)V
    .locals 9

    const/4 v7, 0x6

    const/4 v7, 0x3

    new-instance v0, Lorg/json/JSONObject;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p0, v0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->b(Lorg/json/JSONObject;)V

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string p1, "TpduuauoSrityeg"

    const-string/jumbo p1, "udriipuSygeTtoa"

    const/4 v8, 0x1

    const-string p1, "TpogdyipruatniS"

    const-string p1, "audioStringType"

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/4 v1, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    check-cast p1, Ljava/lang/Integer;

    const/4 v7, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->c:Ljava/lang/Integer;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string/jumbo p1, "qeapdusf"

    const-string/jumbo p1, "ufstedap"

    const/4 v8, 0x7

    const-string p1, "efsluasd"

    const-string p1, "defaults"

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x5

    check-cast p1, Ljava/lang/Integer;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string/jumbo p1, "sqgmf"

    const-string p1, "gsfqa"

    const-string p1, "galfo"

    const-string p1, "flags"

    const/4 v8, 0x6

    const/4 v7, 0x5

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x1

    check-cast p1, Ljava/lang/Integer;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->k:Ljava/lang/Integer;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    const-string p1, "cino"

    const-string/jumbo p1, "noci"

    const/4 v8, 0x0

    const-string/jumbo p1, "onic"

    const-string p1, "icon"

    const/4 v8, 0x0

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    check-cast p1, Ljava/lang/Integer;

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->l:Ljava/lang/Integer;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const-string/jumbo p1, "vseioblLc"

    const-string p1, "Liscvoeel"

    const/4 v8, 0x3

    const-string/jumbo p1, "oncelvuei"

    const-string p1, "iconLevel"

    const/4 v8, 0x3

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    check-cast p1, Ljava/lang/Integer;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->m:Ljava/lang/Integer;

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string/jumbo p1, "pBdmeRG"

    const-string p1, "ReGmdlB"

    const/4 v8, 0x7

    const-string p1, "AqlBRde"

    const-string/jumbo p1, "ledARGB"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x6

    check-cast p1, Ljava/lang/Integer;

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->n:Ljava/lang/Integer;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x1

    const-string/jumbo p1, "ldsSeOfo"

    const-string p1, "MdeSoOfl"

    const/4 v8, 0x5

    const-string/jumbo p1, "lfOmdfSe"

    const-string/jumbo p1, "ledOffMS"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    check-cast p1, Ljava/lang/Integer;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->o:Ljava/lang/Integer;

    const/4 v7, 0x0

    and-int/2addr v8, v7

    const-string p1, "bnOSodM"

    const-string p1, "dnOlMbS"

    const/4 v8, 0x0

    const-string/jumbo p1, "ldMnObS"

    const-string/jumbo p1, "ledOnMS"

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    check-cast p1, Ljava/lang/Integer;

    const/4 v8, 0x7

    const/4 v7, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->p:Ljava/lang/Integer;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x3

    const-string/jumbo p1, "umbuue"

    const-string/jumbo p1, "unbmeu"

    const/4 v8, 0x1

    const-string/jumbo p1, "nprebu"

    const-string/jumbo p1, "number"

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    check-cast p1, Ljava/lang/Integer;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->q:Ljava/lang/Integer;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    const-string/jumbo p1, "ponqd"

    const-string/jumbo p1, "uopnd"

    const/4 v8, 0x0

    const-string/jumbo p1, "sound"

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    check-cast p1, Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string v2, "clsmoanqI"

    const-string v2, "Ilnomclaq"

    const/4 v8, 0x4

    const-string/jumbo v2, "nalmsIlmo"

    const-string/jumbo v2, "smallIcon"

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-static {v0, v2, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    check-cast v2, Ljava/lang/Integer;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->v:Ljava/lang/Integer;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string/jumbo v2, "nfcoonLtrncioagtiosia"

    const-string/jumbo v2, "oasiocginfcnteLntiaor"

    const/4 v8, 0x7

    const-string/jumbo v2, "notificationLargeIcon"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {v0, v2, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x7

    check-cast v2, Ljava/lang/Integer;

    const/4 v7, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x0

    iput-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->x:Ljava/lang/Integer;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    if-eqz p1, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {p1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object p1

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->r:Landroid/net/Uri;

    :cond_0
    const/4 v8, 0x6

    const-string p1, "atierbb"

    const-string/jumbo p1, "vibrate"

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x3

    check-cast p1, Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eqz p1, :cond_1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const-string v2, ","

    const-string v2, ","

    const/4 v8, 0x2

    const-string v2, ","

    const-string v2, ","

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p1, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    array-length v2, p1

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-array v3, v2, [J

    const/4 v7, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    iput-object v3, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->t:[J

    const/4 v8, 0x3

    const/4 v3, 0x0

    const/4 v8, 0x2

    move v7, v3

    move v7, v3

    :goto_0
    const/4 v8, 0x2

    if-ge v3, v2, :cond_1

    :try_start_0
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->t:[J

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x1

    aget-object v5, p1, v3

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {v5}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v5

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v5}, Ljava/lang/Long;->longValue()J

    move-result-wide v5

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    aput-wide v5, v4, v3
    :try_end_0
    .catch Ljava/lang/NumberFormatException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x3

    goto :goto_1

    :catch_0
    move-exception v4

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x6

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x4

    const-string/jumbo v6, "v orsruib reamrst prate "

    const-string/jumbo v6, "r rmiaasvprbse eo r rttr"

    const-string/jumbo v6, "irrr tep  rorsba seeparv"

    const-string/jumbo v6, "parse vibrate str error "

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v4}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x2

    const/4 v7, 0x0

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string/jumbo v5, "tiroisheqiPnocGuBfuoiXdlN"

    const-string v5, "aiolouXhuiicGfPNrtdoieBsn"

    const/4 v8, 0x4

    const-string/jumbo v5, "onsieastXNoiGudiPBchtiurl"

    const-string v5, "XGPushNotificationBuilder"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {v5, v4}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    add-int/lit8 v3, v3, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    goto :goto_0

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string p1, "aifmoicndInibt"

    const-string p1, "anifdbinitIoct"

    const/4 v8, 0x5

    const-string p1, "aionofcnidtiIo"

    const-string/jumbo p1, "notificationId"

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x7

    check-cast p1, Ljava/lang/Integer;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->B:Ljava/lang/Integer;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string p1, "_diuebaht"

    const-string p1, "_athriude"

    const/4 v8, 0x3

    const-string p1, "drteihu_a"

    const-string/jumbo p1, "thread_id"

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x3

    check-cast p1, Ljava/lang/String;

    const/4 v8, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->E:Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string p1, "ergntaypC"

    const/4 v8, 0x5

    const-string p1, "atryConpe"

    const-string/jumbo p1, "nCategory"

    const/4 v8, 0x4

    invoke-static {v0, p1, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    check-cast p1, Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    const/4 p1, -0x1

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string v1, "etannmIpqcr"

    const-string/jumbo v1, "nImportance"

    const/4 v7, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-static {v0, v1, p1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonGet(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x5

    check-cast p1, Ljava/lang/Integer;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p1}, Ljava/lang/Integer;->intValue()I

    move-result p1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x2

    iput p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->z:I

    const/4 v8, 0x0

    return-void
.end method

.method public encode(Lorg/json/JSONObject;)V
    .locals 7

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->a(Lorg/json/JSONObject;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string v0, "TpsSyuqieioartn"

    const-string v0, "airSoyneqpiuTtg"

    const/4 v6, 0x3

    const-string/jumbo v0, "rtimTnoiSgeuady"

    const-string v0, "audioStringType"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->c:Ljava/lang/Integer;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo v0, "satlouds"

    const-string/jumbo v0, "lssuadft"

    const/4 v6, 0x6

    const-string/jumbo v0, "usdetbal"

    const-string v0, "defaults"

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x2

    const-string/jumbo v0, "musfa"

    const-string v0, "agsmf"

    const/4 v6, 0x4

    const-string/jumbo v0, "sfplg"

    const-string v0, "flags"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->k:Ljava/lang/Integer;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x6

    const-string v0, "icno"

    const-string v0, "icon"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->l:Ljava/lang/Integer;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x4

    const-string v0, "Llceooivn"

    const/4 v6, 0x5

    const-string/jumbo v0, "nclveoeiq"

    const-string v0, "iconLevel"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->m:Ljava/lang/Integer;

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string v0, "besBAlR"

    const-string v0, "eAlGRbB"

    const/4 v6, 0x4

    const-string/jumbo v0, "ledARGB"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->n:Ljava/lang/Integer;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x7

    const-string v0, "dOfmulef"

    const-string v0, "OfflSeud"

    const/4 v6, 0x3

    const-string v0, "MlfeoSfd"

    const-string/jumbo v0, "ledOffMS"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->o:Ljava/lang/Integer;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v5, 0x1

    move v6, v5

    const-string v0, "dOpenbM"

    const-string/jumbo v0, "pMSOdne"

    const/4 v6, 0x1

    const-string/jumbo v0, "nOSlMeu"

    const-string/jumbo v0, "ledOnMS"

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->p:Ljava/lang/Integer;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string v0, "epubmn"

    const-string/jumbo v0, "number"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->q:Ljava/lang/Integer;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo v0, "qusqd"

    const-string/jumbo v0, "sdnqu"

    const/4 v6, 0x7

    const-string/jumbo v0, "nosus"

    const-string/jumbo v0, "sound"

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->r:Landroid/net/Uri;

    const/4 v5, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x6

    const-string/jumbo v0, "sslmIanol"

    const-string v0, "Imsnlosla"

    const/4 v6, 0x0

    const-string v0, "clnIolsma"

    const-string/jumbo v0, "smallIcon"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->v:Ljava/lang/Integer;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string v0, "ateaLbrnciictignIofom"

    const-string v0, "LIfmcigcaoinaoeittnnr"

    const/4 v6, 0x4

    const-string/jumbo v0, "notificationLargeIcon"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->x:Ljava/lang/Integer;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->t:[J

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v0, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->t:[J

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    array-length v3, v2

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-ge v1, v3, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    aget-wide v3, v2, v1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v3, v4}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->t:[J

    const/4 v6, 0x7

    array-length v2, v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    add-int/lit8 v2, v2, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eq v1, v2, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string v2, ","

    const-string v2, ","

    const/4 v6, 0x5

    const-string v2, ","

    const-string v2, ","

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x1

    const-string/jumbo v1, "veobrtu"

    const-string/jumbo v1, "vbeaort"

    const/4 v6, 0x4

    const-string/jumbo v1, "pirtbae"

    const-string/jumbo v1, "vibrate"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {p1, v1, v0}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x4

    const-string v0, "cofdaIbnqttiin"

    const-string v0, "aItciboiindnft"

    const/4 v6, 0x5

    const-string v0, "aosdofcinttIin"

    const-string/jumbo v0, "notificationId"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->B:Ljava/lang/Integer;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x5

    const/4 v5, 0x7

    const-string v0, "du_mtriah"

    const-string v0, "ateih_udr"

    const/4 v6, 0x1

    const-string v0, "iadeohrdt"

    const-string/jumbo v0, "thread_id"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->E:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string/jumbo v0, "ntCrgeypa"

    const/4 v6, 0x0

    const-string/jumbo v0, "ngCoabret"

    const-string/jumbo v0, "nCategory"

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {p1, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->z:I

    const/4 v6, 0x5

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string/jumbo v1, "menpIauqtcn"

    const-string/jumbo v1, "rntcmpaeqnI"

    const/4 v6, 0x6

    const-string v1, "Iatconepprn"

    const-string/jumbo v1, "nImportance"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {p1, v1, v0}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    return-void
.end method

.method public getApplicationIcon(Landroid/content/Context;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    iget p1, p1, Landroid/content/pm/ApplicationInfo;->icon:I

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    return p1
.end method

.method public getAudioStringType()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->c:Ljava/lang/Integer;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    return v0
.end method

.method public getChannelId(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->a:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string v1, "dxsn-ah-qcleg"

    const-string v1, "-xs-hcalnegnd"

    const/4 v3, 0x0

    const-string/jumbo v1, "lcsnixna-gh-e"

    const-string/jumbo v1, "xg-channle-id"

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/XGPushConfig;->getNotificationChannelID(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x1

    return-object p1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->a:Ljava/lang/String;

    const/4 v2, 0x6

    move v3, v2

    return-object p1
.end method

.method public getChannelName(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->b:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v1, "memmsae"

    const-string/jumbo v1, "seemsma"

    const/4 v3, 0x2

    const-string v1, "assmoge"

    const-string/jumbo v1, "message"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/XGPushConfig;->getNotificationChannelName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-object p1

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->b:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-object p1
.end method

.method public getChannelNotification(Landroid/content/Context;)Landroid/util/Pair;
    .locals 8
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi"
        }
    .end annotation

    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Landroid/util/Pair<",
            "Landroid/app/Notification;",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    new-instance v0, Landroid/app/Notification$Builder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    invoke-direct {v0, p1}, Landroid/app/Notification$Builder;-><init>(Landroid/content/Context;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x7

    new-instance v1, Landroid/app/Notification$BigTextStyle;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v1}, Landroid/app/Notification$BigTextStyle;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->v:Ljava/lang/Integer;

    const/4 v6, 0x3

    move v7, v6

    if-eqz v2, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0, v2}, Landroid/app/Notification$Builder;->setSmallIcon(I)Landroid/app/Notification$Builder;

    :cond_0
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->D:Ljava/lang/Integer;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eqz v2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x0

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0, v2}, Landroid/app/Notification$Builder;->setColor(I)Landroid/app/Notification$Builder;

    :cond_1
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->x:Ljava/lang/Integer;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string/jumbo v3, "otNuibfiutcrlioanBeGdhosP"

    const-string/jumbo v3, "isctoBrPXuniGeofhauiNlotd"

    const/4 v7, 0x7

    const-string/jumbo v3, "ufcrNuulhiGsiieXPontBiadt"

    const-string v3, "XGPushNotificationBuilder"

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-eqz v2, :cond_2

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-gtz v2, :cond_2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->x:Ljava/lang/Integer;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v2, v4}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, v2}, Landroid/app/Notification$Builder;->setLargeIcon(Landroid/graphics/Bitmap;)Landroid/app/Notification$Builder;
    :try_end_0
    .catch Ljava/lang/OutOfMemoryError; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    goto :goto_0

    :catch_0
    move-exception v2

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x6

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string/jumbo v5, "trmagC pston sfno LiIogaoNoai rilhteecctenee"

    const-string v5, "getChannelNotification setLargeIcon res oom "

    const/4 v7, 0x7

    const/4 v6, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v7, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->w:Landroid/graphics/Bitmap;

    const/4 v6, 0x6

    move v7, v6

    if-eqz v2, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget v4, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    if-gtz v4, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0, v2}, Landroid/app/Notification$Builder;->setLargeIcon(Landroid/graphics/Bitmap;)Landroid/app/Notification$Builder;

    :cond_3
    const/4 v6, 0x2

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->A:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x4

    if-nez v2, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getTitle(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->A:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    goto :goto_1

    :cond_4
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0, v2}, Landroid/app/Notification$Builder;->setContentTitle(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    :goto_1
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->s:Ljava/lang/CharSequence;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz v2, :cond_5

    const/4 v7, 0x3

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->e:Landroid/widget/RemoteViews;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-nez v4, :cond_5

    const/4 v6, 0x2

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Landroid/app/Notification$BigTextStyle;->bigText(Ljava/lang/CharSequence;)Landroid/app/Notification$BigTextStyle;

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setStyle(Landroid/app/Notification$Style;)Landroid/app/Notification$Builder;

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->s:Ljava/lang/CharSequence;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->s:Ljava/lang/CharSequence;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setTicker(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    goto :goto_2

    :cond_5
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0, v2}, Landroid/app/Notification$Builder;->setContentText(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->s:Ljava/lang/CharSequence;

    const/4 v6, 0x4

    or-int/2addr v7, v6

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setTicker(Ljava/lang/CharSequence;)Landroid/app/Notification$Builder;

    :goto_2
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->C:Landroid/graphics/Bitmap;

    const/4 v7, 0x5

    if-eqz v1, :cond_6

    :try_start_1
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    new-instance v1, Landroid/app/Notification$BigPictureStyle;

    const/4 v7, 0x2

    invoke-direct {v1}, Landroid/app/Notification$BigPictureStyle;-><init>()V

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->C:Landroid/graphics/Bitmap;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v1, v2}, Landroid/app/Notification$BigPictureStyle;->bigPicture(Landroid/graphics/Bitmap;)Landroid/app/Notification$BigPictureStyle;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setStyle(Landroid/app/Notification$Style;)Landroid/app/Notification$Builder;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto :goto_3

    :catchall_0
    move-exception v1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string v4, "getChannelNotification setStyle error "

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_6
    :goto_3
    const/4 v6, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    iget v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    const/4 v2, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-lez v1, :cond_8

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->h:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    if-eq v1, v2, :cond_7

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x3

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    const/16 v3, 0x1f

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-ge v1, v3, :cond_7

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHuaWei()Z

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-nez v1, :cond_7

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHonor()Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    if-eqz v1, :cond_8

    :cond_7
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {}, Landroidx/core/app/b2;->a()Landroid/app/Notification$DecoratedCustomViewStyle;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setStyle(Landroid/app/Notification$Style;)Landroid/app/Notification$Builder;

    :cond_8
    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->E:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v1, :cond_a

    const/4 v7, 0x3

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/d/d;->j()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string/jumbo v3, "ppoo"

    const-string/jumbo v3, "oppo"

    const/4 v7, 0x6

    const-string/jumbo v3, "opop"

    const-string/jumbo v3, "oppo"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    if-nez v3, :cond_a

    const/4 v7, 0x3

    iget v3, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v7, 0x6

    const/4 v6, 0x4

    if-lez v3, :cond_9

    const/4 v7, 0x4

    const/4 v6, 0x4

    const-string/jumbo v3, "iovv"

    const-string/jumbo v3, "iovv"

    const/4 v7, 0x6

    const-string/jumbo v3, "vvoi"

    const-string/jumbo v3, "vivo"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v3, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x5

    if-nez v1, :cond_a

    :cond_9
    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v3, 0x3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    if-eq v1, v3, :cond_a

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->E:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setGroup(Ljava/lang/String;)Landroid/app/Notification$Builder;

    :cond_a
    const/4 v7, 0x4

    invoke-virtual {v0, v2}, Landroid/app/Notification$Builder;->setShowWhen(Z)Landroid/app/Notification$Builder;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-eqz v1, :cond_b

    const/4 v7, 0x4

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-nez v1, :cond_b

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Landroid/app/Notification$Builder;->setCategory(Ljava/lang/String;)Landroid/app/Notification$Builder;

    :cond_b
    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v0, v2}, Landroid/app/Notification$Builder;->setVisibility(I)Landroid/app/Notification$Builder;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-direct {p0, v0, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->a(Landroid/app/Notification$Builder;Landroid/content/Context;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    new-instance v1, Landroid/util/Pair;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v0}, Landroid/app/Notification$Builder;->build()Landroid/app/Notification;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {v1, v0, p1}, Landroid/util/Pair;-><init>(Ljava/lang/Object;Ljava/lang/Object;)V

    const/4 v6, 0x6

    move v7, v6

    return-object v1
.end method

.method public getColor()Ljava/lang/Integer;
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->D:Ljava/lang/Integer;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    return-object v0
.end method

.method public getContentIntent()Landroid/app/PendingIntent;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->d:Landroid/app/PendingIntent;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-object v0
.end method

.method public getCurrentChannelId()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x0

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->F:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-lez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->F:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string/jumbo v0, "x-ealbn-cdhgi"

    const/4 v2, 0x1

    const-string/jumbo v0, "xg-channle-id"

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public getCustomLayoutType()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    return v0
.end method

.method public getDefaults()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return v0
.end method

.method public getFlags()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->k:Ljava/lang/Integer;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return v0
.end method

.method public getIcon()Ljava/lang/Integer;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->l:Ljava/lang/Integer;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method public getIconLevel()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->m:Ljava/lang/Integer;

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v1, 0x2

    move v2, v1

    return v0
.end method

.method public getLargeIcon()Landroid/graphics/Bitmap;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->w:Landroid/graphics/Bitmap;

    const/4 v2, 0x5

    return-object v0
.end method

.method public getLedARGB()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->n:Ljava/lang/Integer;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public getLedOffMS()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->o:Ljava/lang/Integer;

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    return v0
.end method

.method public getLedOnMS()I
    .locals 3

    const/4 v1, 0x6

    move v2, v1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->p:Ljava/lang/Integer;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    return v0
.end method

.method public getNotificationCategory()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v1, 0x0

    and-int/2addr v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public getNotificationImportance()I
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    iget v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->z:I

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-ltz v0, :cond_0

    const/4 v1, 0x5

    shl-int/2addr v3, v1

    and-int/2addr v2, v1

    const/4 v3, 0x0

    if-gt v0, v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v0, -0x1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v0
.end method

.method public getNotificationLargeIcon()Ljava/lang/Integer;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->x:Ljava/lang/Integer;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public getNumber()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->q:Ljava/lang/Integer;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return v0
.end method

.method public getRichIcon()Landroid/graphics/Bitmap;
    .locals 3

    const/4 v1, 0x5

    move v2, v1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->C:Landroid/graphics/Bitmap;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public getSmallIcon()Ljava/lang/Integer;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->v:Ljava/lang/Integer;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public getSound()Landroid/net/Uri;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->r:Landroid/net/Uri;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-object v0
.end method

.method public getThread_id()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->E:Ljava/lang/String;

    const/4 v1, 0x2

    shl-int/2addr v2, v1

    return-object v0
.end method

.method public getTickerText()Ljava/lang/CharSequence;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->s:Ljava/lang/CharSequence;

    const/4 v1, 0x5

    move v2, v1

    return-object v0
.end method

.method public getTitle(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->A:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Landroid/content/pm/PackageManager;->getApplicationLabel(Landroid/content/pm/ApplicationInfo;)Ljava/lang/CharSequence;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    check-cast p1, Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->A:Ljava/lang/String;

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->A:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object p1
.end method

.method public abstract getType()Ljava/lang/String;
.end method

.method public getVibrate()[J
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->t:[J

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public getWhen()J
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->u:Ljava/lang/Long;

    const/4 v3, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-wide v0
.end method

.method public isRecommandNotification()Z
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v2, 0x5

    or-int/2addr v3, v2

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v3, 0x1

    const-string/jumbo v1, "rdaonimmqnocee"

    const-string/jumbo v1, "recommendation"

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string/jumbo v1, "olsusa"

    const-string/jumbo v1, "uiolsa"

    const/4 v3, 0x2

    const-string/jumbo v1, "iosmla"

    const-string/jumbo v1, "social"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const-string/jumbo v1, "opopo"

    const-string/jumbo v1, "popmo"

    const/4 v3, 0x0

    const-string v1, "bpmoo"

    const-string/jumbo v1, "promo"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    :cond_0
    const/4 v3, 0x4

    const/4 v0, 0x1

    const/4 v3, 0x3

    move v2, v0

    move v2, v0

    const/4 v3, 0x5

    return v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    return v0
.end method

.method public isSupportNotificationGroup(Landroid/content/Context;)Z
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->isSupportNotificationGroup:Ljava/lang/Boolean;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x4

    return p1

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {p1}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x5

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x0

    cmp-long p1, v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x3

    const-string v2, ""

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz p1, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {p1, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string p1, "501"

    const-string p1, "150"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x2

    move v5, v4

    const-string v3, "fdoNehauqtitcXPnirGsuBiio"

    const-string/jumbo v3, "ufiltiuiadXnutrPcBNsoihGo"

    const-string v3, "XGPushNotificationBuilder"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-nez p1, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x0

    const-string p1, "851"

    const-string p1, "158"

    const/4 v5, 0x6

    const-string p1, "851"

    const-string p1, "158"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-nez p1, :cond_3

    const/4 v4, 0x2

    move v5, v4

    const-string p1, "159"

    const/4 v5, 0x7

    const-string p1, "519"

    const-string p1, "159"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz p1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_0

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v2, "refscospi :gacdne"

    const-string v2, "foreign accessid:"

    const/4 v5, 0x4

    const/4 v4, 0x0

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {p1, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string/jumbo v0, "rtfarc cqieuaoNapG o icetn tso"

    const-string/jumbo v0, "tcsiai ctoNp enfonatcG reoa ur"

    const/4 v5, 0x6

    const-string/jumbo v0, "rascnr toucpt  ftieeGnaoi oacN"

    const-string v0, " can create Notification Group"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    goto :goto_1

    :cond_3
    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/common/g;->e()Z

    move-result p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->isRecommandNotification()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz p1, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eqz v2, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v2, "ie/mumfcldfesaac1annits+"

    const-string v2, "1timiaar/scns+ffuceladne"

    const-string v2, "cridon lseai/u+saecftf1a"

    const-string/jumbo v2, "internal accessid\uff1a+"

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p1, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v0, "r tpobt rpoccvi e.rne/ e uv O /So  iptoa0iN hro4ouiu fmtceaGon,itsroaehi detwda"

    const-string v0, "eiseor  ovcoSO hoGaicat,r/i e e4unra d rot i/ n opt yi .tuouavNeedprwohpmftcti0"

    const/4 v5, 0x0

    const-string v0, ".a vfoue tp rrocit oywapt4O nt /noo eer0 e,tS duoicar dsupchtae oiirhui/ nGmvNi"

    const-string v0, " , over huawei harmony 4.0 OS device don\'t support create Notitification Group"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget-object p1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->isSupportNotificationGroup:Ljava/lang/Boolean;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    return p1

    :cond_4
    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    sget-object p1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->isSupportNotificationGroup:Ljava/lang/Boolean;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string p1, "i i aafptauetncpNeoitrnricbtGco"

    const-string/jumbo p1, "tien bcaotGiiat eiunNtcora rfpc"

    const/4 v5, 0x0

    const-string/jumbo p1, "r t feGiquea Nonpctcattiironcia"

    const-string p1, "can create Notitification Group"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->isSupportNotificationGroup:Ljava/lang/Boolean;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    return p1
.end method

.method public needAutoFilterNotification(Landroid/content/Context;)Z
    .locals 4

    const/4 v2, 0x2

    const/4 v3, 0x4

    sget-boolean p1, Lcom/tencent/android/tpush/XGPushConfig;->autoFilterHuaweiPublicNotification:Z

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v1, "iGsthcaXrnuietsuolPBidoiN"

    const-string v1, "XGPushNotificationBuilder"

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const-string/jumbo p1, "tliuiruiboHwtigNtoei elfacel  tnafitnaoPuuFasco "

    const/4 v3, 0x7

    const-string p1, " not set autoFilterHuaweiPublicNotification flag"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    return v0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/common/g;->e()Z

    move-result p1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-nez p1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo p1, "twougoOpmairnn a4SeHh "

    const/4 v3, 0x3

    const-string p1, " not huawei HarmongOS4"

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    return v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-eqz p1, :cond_3

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    if-nez p1, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->isRecommandNotification()Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz p1, :cond_2

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    return v0

    :cond_3
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string p1, "aaOmtfina ofcenoi4 it yncl nohnitqscrtouaroN.h mioitamo iib ucrn0nS feptwiui"

    const-string/jumbo p1, "oiisaih.qiiOrutci oa0  tcocranuNpahie tinnicnniuSa 4fonmt boomrofw yt lnifet"

    const/4 v3, 0x6

    const-string p1, "ataooaScnhriin i cniniibueiomt ro och y0utpitocNieai4inwm s.tftOfrlnu  afnoo"

    const-string p1, "current notification is huawei harmonyOS 4.0 public information Notification"

    const/4 v3, 0x6

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    const/4 p1, 0x1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return p1
.end method

.method public setAudioStringType(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->c:Ljava/lang/Integer;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method public setChannelId(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->a:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method public setChannelName(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->b:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method public setColor(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->D:Ljava/lang/Integer;

    const/4 v1, 0x2

    const/4 v0, 0x1

    return-object p0
.end method

.method public setContentIntent(Landroid/app/PendingIntent;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->d:Landroid/app/PendingIntent;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-object p0
.end method

.method public setContentView(Landroid/widget/RemoteViews;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->e:Landroid/widget/RemoteViews;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method

.method public setCustomLayoutType(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->g:I

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method public setDefaults(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    const/4 v2, 0x6

    const/4 v1, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    goto :goto_0

    :cond_0
    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x2

    or-int/2addr p1, v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->i:Ljava/lang/Integer;

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p0
.end method

.method public setFlags(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->k:Ljava/lang/Integer;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->k:Ljava/lang/Integer;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    or-int/2addr p1, v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->k:Ljava/lang/Integer;

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p0
.end method

.method public setIcon(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->l:Ljava/lang/Integer;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-object p0
.end method

.method public setIconLevel(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->m:Ljava/lang/Integer;

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method public setLargeIcon(Landroid/graphics/Bitmap;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->w:Landroid/graphics/Bitmap;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-object p0
.end method

.method public setLedARGB(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->n:Ljava/lang/Integer;

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-object p0
.end method

.method public setLedOffMS(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->o:Ljava/lang/Integer;

    const/4 v0, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-object p0
.end method

.method public setLedOnMS(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->p:Ljava/lang/Integer;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-object p0
.end method

.method public setNotificationCategory(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->y:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public setNotificationImportance(I)Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-lez p1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    const/4 v0, 0x5

    const/4 v3, 0x1

    if-le p1, v0, :cond_0

    const/4 v2, 0x6

    move v3, v2

    goto :goto_0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->z:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 p1, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    return p1

    :cond_1
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v1, ":aencbap,roisoocntn to tpiinnvi Ifmra aoimenattidtoiicfnc"

    const-string/jumbo v1, "r:s oatnm,caltnvotoeaniti indaieopof tfImncnoipactcn iiir"

    const/4 v3, 0x4

    const-string v1, "i:,adpu in aoctetIttnoocoeatfift ooainiavmririinniccnpm n"

    const-string/jumbo v1, "invalid notification importance , notificationImportance:"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x7

    const-string/jumbo v0, "iuctfoepNtusaGhrlnoiidBPm"

    const-string v0, "dunmXhGoiiBitrNluPsefatoc"

    const/4 v3, 0x7

    const-string/jumbo v0, "sNiieoutqdPrhcnifXloGtaiB"

    const-string v0, "XGPushNotificationBuilder"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    const/4 p1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    return p1
.end method

.method public setNotificationLargeIcon(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->x:Ljava/lang/Integer;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-object p0
.end method

.method public setNumber(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->q:Ljava/lang/Integer;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p0
.end method

.method public setRichIcon(Landroid/graphics/Bitmap;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->C:Landroid/graphics/Bitmap;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method

.method public setRunAsSysAndAndBuildSdk26(Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-boolean p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->G:Z

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public setSmallIcon(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->v:Ljava/lang/Integer;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-object p0
.end method

.method public setSound(Landroid/net/Uri;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->r:Landroid/net/Uri;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method public setThread_id(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->E:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public setTickerText(Ljava/lang/CharSequence;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->s:Ljava/lang/CharSequence;

    const/4 v0, 0x3

    move v1, v0

    return-object p0
.end method

.method public setTitle(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->A:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method public setUseStdStyle(I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    iput p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->h:I

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public setVibrate([J)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->t:[J

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-object p0
.end method

.method public setWhen(J)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->u:Ljava/lang/Long;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-object p0
.end method

.method public setbigContentView(Landroid/widget/RemoteViews;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->f:Landroid/widget/RemoteViews;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-object p0
.end method
