.class public Lcom/tencent/android/tpush/XGSysNotifaction;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20150316"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->RECEIVERCHECK:Lcom/jg/EType;,
        .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;
    }
.end annotation


# instance fields
.field private a:I

.field private b:Landroid/app/Notification;

.field private c:Ljava/lang/String;

.field private d:Landroid/content/Intent;

.field private e:I

.field private f:Ljava/lang/Object;


# direct methods
.method public constructor <init>(Ljava/lang/String;ILandroid/app/Notification;Landroid/content/Intent;ILjava/lang/Object;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGSysNotifaction;->c:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p2, p0, Lcom/tencent/android/tpush/XGSysNotifaction;->a:I

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p3, p0, Lcom/tencent/android/tpush/XGSysNotifaction;->b:Landroid/app/Notification;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p4, p0, Lcom/tencent/android/tpush/XGSysNotifaction;->d:Landroid/content/Intent;

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p5, p0, Lcom/tencent/android/tpush/XGSysNotifaction;->e:I

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p6, p0, Lcom/tencent/android/tpush/XGSysNotifaction;->f:Ljava/lang/Object;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public getAppPkg()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@s@@~rmMd4b @ @u.~ai  @o~~o ~ ~ voS~it~~b  ~@l ~~@~  ~i1~o @~f-@@@/@ot~~ynb/@@~~Ko sl~fc@ ~@@  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGSysNotifaction;->c:Ljava/lang/String;

    const/4 v2, 0x0

    return-object v0
.end method

.method public getNotifaction()Landroid/app/Notification;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGSysNotifaction;->b:Landroid/app/Notification;

    const/4 v2, 0x7

    const/4 v1, 0x6

    return-object v0
.end method

.method public getNotificationChannle()Ljava/lang/Object;
    .locals 3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGSysNotifaction;->f:Ljava/lang/Object;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object v0
.end method

.method public getNotifyId()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/XGSysNotifaction;->a:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public getPendintIntent()Landroid/content/Intent;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGSysNotifaction;->d:Landroid/content/Intent;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-object v0
.end method

.method public getPendintIntentFlag()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/android/tpush/XGSysNotifaction;->e:I

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    return v0
.end method
