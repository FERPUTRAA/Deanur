.class public Lcom/tencent/android/tpush/XGPushConfig;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20150316"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->RECEIVERCHECK:Lcom/jg/EType;,
        .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/XGPushConfig$Build;
    }
.end annotation


# static fields
.field public static final TPUSH_ACCESS_CHANNAL:Ljava/lang/String; = "XG_V4_CHANNEL_ID"

.field public static final TPUSH_ACCESS_ID:Ljava/lang/String; = "XG_V2_ACCESS_ID"

.field public static final TPUSH_ACCESS_KEY:Ljava/lang/String; = "XG_V2_ACCESS_KEY"

.field public static final TPUSH_IS_FOREIGINPUSH:Ljava/lang/String; = "TPUSH_IS_FOREIGINPUSH"

.field public static _isHuaweiDebug:Z = false

.field private static a:Ljava/lang/String; = ""

.field public static autoFilterHuaweiPublicNotification:Z = false

.field public static autoInit:Z = true

.field private static b:Ljava/lang/String; = ""

.field private static c:Z = true

.field private static d:Ljava/lang/String; = ""

.field private static e:J = -0x1L

.field public static enableActivityWindowSecFlag:Z

.field public static enableApplist:Ljava/lang/Boolean;

.field public static enableDebug:Z

.field public static enableLocation:Ljava/lang/Boolean;

.field public static enableNotification:Ljava/lang/Boolean;

.field private static f:Ljava/lang/Boolean;

.field public static fcmIsSuccess:Ljava/lang/Boolean;

.field private static g:Ljava/lang/Boolean;

.field private static h:Ljava/lang/Boolean;

.field private static i:Ljava/lang/Boolean;

.field public static isUsedFcmPush:Ljava/lang/Boolean;

.field public static isUsedOtherPush:Ljava/lang/Boolean;

.field private static j:Ljava/lang/Boolean;

.field private static k:Ljava/lang/Boolean;

.field private static l:Landroid/content/SharedPreferences;

.field public static notificationChannelID:Ljava/lang/String;

.field public static notificationChannelName:Ljava/lang/String;

.field public static useFcmFirst:Ljava/lang/Boolean;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    return-void
.end method

.method private static a(Landroid/content/Context;Z)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "ybs~vK~~~i4o~~d@@~u t  @-iiln~@~~o~@oo@~  ~SM@ @@@~~~a@of@@ t1bo @@   @/~f@m~@b  sc/. r~  @@ ~l~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    if-nez p0, :cond_0

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lcom/tencent/tpns/mqttchannel/api/MqttConfig;->enableAlarmManager(Landroid/content/Context;Z)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x0

    if-nez p1, :cond_1

    const/4 v0, 0x3

    const/4 v0, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/g;->f(Landroid/content/Context;)V

    :cond_1
    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public static changeHuaweiBadgeNum(Landroid/content/Context;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/c;->a(Landroid/content/Context;I)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public static clearAllCache(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const-string v0, "iGPmsCXshfno"

    const-string v0, "PoshXngfGsiC"

    const/4 v3, 0x6

    const-string/jumbo v0, "suonoPCXiGhg"

    const-string v0, "XGPushConfig"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string v1, "enc ebtclmlh plarsa "

    const-string v1, " lsmc pchrlelaA eatn"

    const/4 v3, 0x7

    const-string/jumbo v1, "rChlsluaca p Ale tec"

    const-string v1, "clear All tpns Cache"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/XGPushConfig$4;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/XGPushConfig$4;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    return-void
.end method

.method public static enableAutoStart(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string/jumbo v1, "o btt:apnuolteSaA"

    const-string/jumbo v1, "tteroaan:Sblu toA"

    const/4 v3, 0x3

    const-string v1, "Aube :toqelSanatt"

    const-string v1, "enableAutoStart: "

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v1, "CXsnibuGofsg"

    const-string v1, "fXCnGbigouhs"

    const/4 v3, 0x6

    const-string/jumbo v1, "oGnmhufiPgXC"

    const-string v1, "XGPushConfig"

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->a(Landroid/content/Context;Z)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method public static enableDebug(Landroid/content/Context;Z)V
    .locals 4

    const/4 v2, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x0

    sput-boolean p1, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v2, 0x5

    shr-int/2addr v3, v2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v1, Lcom/tencent/android/tpush/XGPushConfig$1;

    const/4 v3, 0x0

    const/4 v2, 0x6

    invoke-direct {v1, p0, p1}, Lcom/tencent/android/tpush/XGPushConfig$1;-><init>(Landroid/content/Context;Z)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method

.method public static enableFcmPush(Landroid/content/Context;Z)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedFcmPush:Ljava/lang/Boolean;

    const/4 v4, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eq v0, p1, :cond_2

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedFcmPush:Ljava/lang/Boolean;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const/4 v0, 0x1

    const/4 v4, 0x2

    new-array v0, v0, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->d()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    aput-object v1, v0, v2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->setNotTryFcm(Landroid/content/Context;Z)V

    :cond_2
    const/4 v4, 0x3

    return-void
.end method

.method public static enableHttpAccountOperate(Landroid/content/Context;Z)V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    if-nez p0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    return-void

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->g:Ljava/lang/Boolean;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eq v0, p1, :cond_2

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->g:Ljava/lang/Boolean;

    const/4 v4, 0x2

    move v5, v4

    const/4 v0, 0x1

    move v5, v0

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-array v0, v0, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v2, ""

    const/4 v5, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/tencent/android/tpush/e/b/a;->c(Ljava/lang/String;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v1, p1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    aput-object p1, v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    invoke-static {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    return-void
.end method

.method public static enableHuaweiV3Update(Landroid/content/Context;Z)V
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x0

    if-nez p1, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x4

    return-void

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-nez p0, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    return-void

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    instance-of p1, p0, Landroid/app/Activity;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v0, "PnhXosoCuugi"

    const-string v0, "CPosXnuhgGui"

    const/4 v7, 0x7

    const-string/jumbo v0, "nosifbhuXGCP"

    const-string v0, "XGPushConfig"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-nez p1, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string/jumbo p0, "oitV iuneUdw o,avnpecpeutlitdo ntynp e3tdtulu Ha tanwxecft Aeeaianbtoo"

    const-string p0, "ap wnttpdo nAo oai co taxHVeitpdelouewnytifdtlntnt ieesa3e ,nuvtUbeauc"

    const/4 v7, 0x4

    const-string p0, "exeavpepotut3uUtac tiitidnteedfe wbd,cooauHipnncl a  nwVest ltatnonoAy"

    const-string p0, "enableHuaweiV3Update context not instanceof Activity, would not update"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    move v7, v6

    return-void

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHuaWei()Z

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-nez p1, :cond_4

    const/4 v6, 0x7

    const/4 v6, 0x5

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandHonor()Z

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-eqz p1, :cond_3

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_0

    :cond_3
    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string/jumbo p0, "leiieUn qeHp ueunVdea3icebwtode avwaqH"

    const-string/jumbo p0, "veii aeiqHUeepVHdwbualeun3eoec  dntawa"

    const/4 v7, 0x3

    const-string/jumbo p0, "vtsHeewwpatoee anuHlbUdeeVa iiiacd 3en"

    const-string p0, "enableHuaweiV3Update not Huawei device"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    goto :goto_1

    :cond_4
    :goto_0
    :try_start_0
    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string p1, "cmwm.dnIsimHi.aaasecntIe.oams.hdu"

    const-string p1, "icsash.mdHdhmsue.a.man.niecIoIwta"

    const/4 v7, 0x0

    const-string p1, "eadmooumInI.hasdsHacn..cmitahse.w"

    const-string p1, "com.huawei.hms.aaid.HmsInstanceId"

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {p1}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object p1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string v1, "Iegttbnaemn"

    const-string v1, "Isemanttgen"

    const/4 v7, 0x0

    const-string/jumbo v1, "nstagIucnet"

    const-string v1, "getInstance"

    const/4 v7, 0x1

    const/4 v2, 0x1

    const/4 v7, 0x4

    move v6, v2

    move v6, v2

    const/4 v7, 0x6

    new-array v3, v2, [Ljava/lang/Class;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    const-class v4, Landroid/content/Context;

    const/4 v7, 0x4

    const-class v4, Landroid/content/Context;

    const-class v4, Landroid/content/Context;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    const/4 v5, 0x0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x5

    aput-object v4, v3, v5

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {p1, v1, v3}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    new-array v2, v2, [Ljava/lang/Object;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    aput-object p0, v2, v5

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v1, p1, v2}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string/jumbo p1, "t,tmb eprodkn So e 3HUapwsrl aHinaiVuVo3freded "

    const-string/jumbo p1, "p S o bf,dinoVastrHlkrue  eidHwVrte eaedm3Ua3on"

    const/4 v7, 0x3

    const-string p1, "aiesfoapqnonearduedHn,e tmtkr  b33Vw lHUd ir VS"

    const-string p1, "enableHuaweiV3Update error, not find Hms V3 Sdk"

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {v0, p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_1
    const/4 v7, 0x5

    return-void
.end method

.method public static enableNotificationSound(Landroid/content/Context;ZLjava/lang/String;Ljava/lang/String;)V
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x7

    if-nez p0, :cond_0

    const/4 v8, 0x5

    and-int/2addr v9, v8

    return-void

    :cond_0
    const/4 v8, 0x4

    const/4 v9, 0x7

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->i:Ljava/lang/Boolean;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-eqz v0, :cond_1

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-eq v0, p1, :cond_5

    :cond_1
    const/4 v9, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x1

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->i:Ljava/lang/Boolean;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x4

    const/4 v0, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x6

    new-array v0, v0, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->i()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x3

    const/4 v2, 0x0

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    aput-object v1, v0, v2

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-static {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string v0, "foiCXbngGhus"

    const/4 v9, 0x3

    const-string/jumbo v0, "nosGPXsgCfuh"

    const-string v0, "XGPushConfig"

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-nez p1, :cond_4

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    if-nez p1, :cond_3

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-eqz p1, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    goto :goto_0

    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x2

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string/jumbo v1, "lnbmaiteSf to noIewlfcdlNnsiau udctna :hinehoi"

    const-string/jumbo v1, "laifo u fIoih sdtolninl tatSeec:Nwhincbnadneua"

    const/4 v9, 0x3

    const-string v1, "iS cofhltt:aauciidin b heldIal otoaNenfwnnnseo"

    const-string v1, "enableNotificationSound false with channelId: "

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-string v1, "henlmb Na n:c anae"

    const-string v1, " and channelName: "

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x3

    const/4 v8, 0x6

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/4 v4, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    const/4 v5, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    const/4 v6, 0x0

    const/4 v9, 0x4

    const/4 v7, 0x6

    const/4 v9, 0x2

    const/4 v7, 0x0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    move-object v3, p3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static/range {v1 .. v7}, Lcom/tencent/android/tpush/XGPushManager;->createNotificationChannel(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;ZZZLandroid/net/Uri;)V

    const/4 v9, 0x1

    invoke-static {p0, p2}, Lcom/tencent/android/tpush/XGPushConfig;->setNotificationChannelID(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-static {p0, p3}, Lcom/tencent/android/tpush/XGPushConfig;->setNotificationChannelName(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v9, 0x1

    goto :goto_1

    :cond_3
    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-string p0, " r a nuiiihocnaSnsnimhin eolt dpoone agso ntu cllcftNc bidadseaanna.iIeueafaisatlfehoa Nnodfp"

    const-string p0, "fadaN npetuieboie sclccndpfis iaa h.eaaoafdcnioneoiigm lnn uarltlhNn fdlno oo asentt SaIhinas"

    const/4 v9, 0x6

    const-string p0, "icol  lpiiiataa  taocrS opa cgcnIsidilfed salNno uensedNmodnoenfli.o ahfnnnhttnenen ahusifaab"

    const-string p0, "enableNotificationSound false should assign a pair of notification channelId and channelName."

    const/4 v9, 0x7

    const/4 v8, 0x4

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    goto :goto_1

    :cond_4
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string p1, " nbotNleqdtauftiaiSciouneonq"

    const-string/jumbo p1, "onetifutqoeuibnntcoN Srdiaal"

    const-string p1, "NrsdtSiin eiufanbluetocooaen"

    const-string p1, "enableNotificationSound true"

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    const/4 p1, 0x0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->setNotificationChannelID(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->setNotificationChannelName(Landroid/content/Context;Ljava/lang/String;)V

    :cond_5
    :goto_1
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    return-void
.end method

.method public static enableOppoNotification(Landroid/content/Context;Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;Z)V

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public static enableOtherPush(Landroid/content/Context;Z)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-nez p0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush:Ljava/lang/Boolean;

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz v0, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-eq v0, p1, :cond_2

    :cond_1
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush:Ljava/lang/Boolean;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-array v0, v0, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v4, 0x7

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->c()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    aput-object v1, v0, v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->enableFcmPush(Landroid/content/Context;Z)V

    :cond_2
    const/4 v4, 0x3

    return-void
.end method

.method public static enablePullUpOtherApp(Landroid/content/Context;Z)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string v0, "gnPmXihufoGs"

    const-string/jumbo v0, "ohsXnfuPgGis"

    const/4 v4, 0x3

    const-string v0, "hgsPoGfuionC"

    const-string v0, "XGPushConfig"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-nez p0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string p0, " ot nblxulsitmc"

    const-string/jumbo p0, "osxmtl ietucl n"

    const-string/jumbo p0, "x tstoulnnicle "

    const-string p0, "context is null"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    return-void

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    sget-object v1, Lcom/tencent/android/tpush/XGPushConfig;->f:Ljava/lang/Boolean;

    const/4 v4, 0x4

    if-eqz v1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-eq p1, v1, :cond_2

    :cond_1
    const/4 v4, 0x3

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    sput-object v1, Lcom/tencent/android/tpush/XGPushConfig;->f:Ljava/lang/Boolean;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const-string v2, "UPpn ocpale itOpnlbpuehl-to:ra"

    const-string v2, " pe-oaclhlbPpuaontU:iOrnleAp t"

    const/4 v4, 0x6

    const-string/jumbo v2, "pe:t-tpUqeicp  barllaOlenoAuhP"

    const-string v2, "action - enablePullUpOtherApp:"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v0, "oesbapurt.plpulp."

    const-string/jumbo v0, "lp.rubpoept.l.apu"

    const/4 v4, 0x0

    const-string v0, "e.umptophl..ruppl"

    const-string/jumbo v0, "pull.up.other.app"

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p0, v0, p1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putBoolean(Landroid/content/Context;Ljava/lang/String;Z)V

    :cond_2
    const/4 v4, 0x7

    return-void
.end method

.method public static enableShowInMsg(Landroid/content/Context;Z)V
    .locals 4

    const/4 v2, 0x0

    const/4 v3, 0x7

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->j:Ljava/lang/Boolean;

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eq v0, p1, :cond_2

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->j:Ljava/lang/Boolean;

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x4

    and-int/2addr v2, v0

    const/4 v3, 0x5

    new-array v0, v0, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->g()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v1, p1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    move v3, v2

    aput-object p1, v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method public static enableTpnsChannel(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->h:Ljava/lang/Boolean;

    const/4 v3, 0x5

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    or-int/2addr v3, v2

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eq v0, p1, :cond_2

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->h:Ljava/lang/Boolean;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-array v0, v0, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->h()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v1, p1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    aput-object p1, v0, v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-void
.end method

.method public static declared-synchronized getAccessId(Landroid/content/Context;)J
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-class v0, Lcom/tencent/android/tpush/XGPushConfig;

    const-class v0, Lcom/tencent/android/tpush/XGPushConfig;

    const/4 v4, 0x6

    const-class v0, Lcom/tencent/android/tpush/XGPushConfig;

    const-class v0, Lcom/tencent/android/tpush/XGPushConfig;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    monitor-exit v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-wide v1

    :catchall_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    monitor-exit v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    throw p0
.end method

.method public static declared-synchronized getAccessKey(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-class v0, Lcom/tencent/android/tpush/XGPushConfig;

    const/4 v2, 0x1

    const-class v0, Lcom/tencent/android/tpush/XGPushConfig;

    const-class v0, Lcom/tencent/android/tpush/XGPushConfig;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    monitor-enter v0

    :try_start_0
    const/4 v1, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/XGApiConfig;->getAccessKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    monitor-exit v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    monitor-exit v0

    const/4 v1, 0x1

    move v2, v1

    throw p0
.end method

.method public static getAccessidList(Landroid/content/Context;)Ljava/util/List;
    .locals 8
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    const/4 v7, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v1, 0x2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-direct {v0, v1}, Ljava/util/ArrayList;-><init>(I)V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x6

    if-nez p0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-object v0

    :cond_0
    const/4 v7, 0x4

    const/4 v6, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v7, 0x3

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    cmp-long v5, v1, v3

    const/4 v7, 0x2

    const/4 v6, 0x2

    if-lez v5, :cond_1

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    cmp-long v3, v1, v3

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    if-lez v3, :cond_2

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string v1, "VDEGouSCXCS_A_I"

    const-string v1, "A2ISE_uGCSVCXD_"

    const-string v1, "EXGSCbSAVCD__I_"

    const-string v1, "XG_V2_ACCESS_ID"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    const/4 v2, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-static {p0, v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    if-eqz p0, :cond_3

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-static {p0}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v7, 0x2

    const/4 v6, 0x6

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-nez p0, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string v1, "CpPiofuXGshn"

    const-string v1, "XPCGihnpsfgo"

    const/4 v7, 0x2

    const-string v1, "hGnuisfpCoPg"

    const-string v1, "XGPushConfig"

    const/4 v7, 0x3

    const-string v2, " :sftdteqaamfla et aocIqcDse et Mgiadg"

    const-string v2, "cIi tMtgqo d smeec leaat:ffargtd saDea"

    const/4 v7, 0x6

    const-string/jumbo v2, "tes dlosge tetd aMascam iafgDrateI: ef"

    const-string v2, "get accessId from getMetaData failed: "

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_3
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    return-object v0
.end method

.method public static declared-synchronized getChannelId(Landroid/content/Context;)J
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x1

    const-class v0, Lcom/tencent/android/tpush/XGPushConfig;

    const-class v0, Lcom/tencent/android/tpush/XGPushConfig;

    const/4 v6, 0x2

    move v7, v6

    monitor-enter v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    if-nez p0, :cond_0

    :try_start_0
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    sget-wide v1, Lcom/tencent/android/tpush/XGPushConfig;->e:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    monitor-exit v0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x7

    return-wide v1

    :cond_0
    :try_start_1
    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x7

    sget-wide v1, Lcom/tencent/android/tpush/XGPushConfig;->e:J
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v7, 0x3

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    cmp-long v5, v1, v3

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-eqz v5, :cond_1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x5

    monitor-exit v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    return-wide v1

    :cond_1
    :try_start_2
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/security/Security;->checkTpnsSecurityLibSo(Landroid/content/Context;)Z

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-nez v1, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    sget-wide v1, Lcom/tencent/android/tpush/XGPushConfig;->e:J
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v7, 0x6

    const/4 v6, 0x5

    monitor-exit v0

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x6

    return-wide v1

    :cond_2
    :try_start_3
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    sget-wide v1, Lcom/tencent/android/tpush/XGPushConfig;->e:J

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    cmp-long v1, v1, v3

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-nez v1, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v1, "_XNmsLDV_CAIGEH4"

    const-string v1, "VLsEN_C4IAX_D_HG"

    const/4 v7, 0x2

    const-string v1, "LX__o_G4VINHNDCE"

    const-string v1, "XG_V4_CHANNEL_ID"

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {p0, v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz p0, :cond_3

    :try_start_4
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-static {p0}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object p0

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    sput-wide v1, Lcom/tencent/android/tpush/XGPushConfig;->e:J
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x5

    goto :goto_0

    :catchall_0
    move-exception p0

    :try_start_5
    const/4 v7, 0x2

    const/4 v6, 0x5

    const-string/jumbo v1, "isPgobGhCfXu"

    const-string v1, "XGPushConfig"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string/jumbo v2, "o Ielfu:nam  deachadim atDrele nagtetMg"

    const-string/jumbo v2, "lgamdaeetta ratmg eedD iane Iclnto:fM h"

    const/4 v7, 0x5

    const-string/jumbo v2, "niaac:opae hren  MtleldmtdeftegIg a tDa"

    const-string v2, "get channelId from getMetaData failed: "

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    sput-wide v3, Lcom/tencent/android/tpush/XGPushConfig;->e:J

    :cond_3
    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    sget-wide v1, Lcom/tencent/android/tpush/XGPushConfig;->e:J

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    cmp-long p0, v1, v3

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    if-nez p0, :cond_4

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x6

    const-string/jumbo p0, "ogXnsGufqoCP"

    const-string p0, "XGCPogonusif"

    const/4 v7, 0x0

    const-string p0, "PCsihonusgGX"

    const-string p0, "XGPushConfig"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x2

    const-string v1, "bodmi p eenaIhlmnyntts"

    const-string v1, "caenibnhd ltyepInmos t"

    const/4 v7, 0x0

    const-string v1, "aIpho to sen timldencn"

    const-string v1, "channelId is not empty"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-static {p0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x5

    sget-wide v1, Lcom/tencent/android/tpush/XGPushConfig;->e:J
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    monitor-exit v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    return-wide v1

    :catchall_1
    move-exception p0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    monitor-exit v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    throw p0
.end method

.method public static getFacilityImei(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x1

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->d:Ljava/lang/String;

    const/4 v1, 0x5

    return-object p0
.end method

.method public static getGameServer(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x4

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->b:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    return-object p0
.end method

.method public static getInstallChannel(Landroid/content/Context;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x5

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->a:Ljava/lang/String;

    const/4 v0, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-object p0
.end method

.method public static getNotificationChannelID(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz p0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->notificationChannelID:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    and-int/2addr v3, v2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->notificationChannelID:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v1, "f.atcbiolithInonannceDi"

    const-string/jumbo v1, "oIfiahuniniecnDtcaot.ln"

    const/4 v3, 0x4

    const-string v1, "Di.Iiauofcnhl.tontnecni"

    const-string v1, ".notification.channelID"

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->notificationChannelID:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object p0

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-object p0
.end method

.method public static getNotificationChannelName(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz p0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->notificationChannelName:Ljava/lang/String;

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x2

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->notificationChannelName:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object p0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    xor-int/2addr v3, v2

    const-string/jumbo v1, "oecttphpoc..nfailnNiiaamn"

    const-string v1, "a.altN.ptinhconnnfiomicae"

    const-string v1, "eniatnNoqncfaihlin.eomt.a"

    const-string v1, ".notification.channelName"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v1, ""

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->notificationChannelName:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object p0
.end method

.method public static getOtherPushErrCode(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez p0, :cond_0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string p0, "  s ut t=qM1ne,grcdlee r no-:rxr: Coes =l"

    const-string p0, "c 1rr lMq u2nr otl r:: xdnt=o,-e Cse eg=e"

    const/4 v3, 0x0

    const-string/jumbo p0, "ttom:xcn r: oe,rdn CrM0=gre1 u2ls -e le  "

    const-string p0, "errCode : -102 , errMsg : context == null"

    const/4 v3, 0x6

    const/4 v2, 0x4

    return-object p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush(Landroid/content/Context;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x1

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush:Ljava/lang/Boolean;

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo p0, "rC,eoonMrc h dadngnr:e 1p1M:   atrfru t- eo nueolcr0eees ssi"

    const-string p0, "C sp tud rnongs:11 dirl eateru-ne aefsren:0r h c eMonr,o ceM"

    const-string p0, " aurnb1anM f:er ,nrede0r Mceeos:t lgnpu r -e1ioer  c hCtsnoa"

    const-string p0, "errCode : -101 , errMsg : Manufacturer channel is not opened"

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object p0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v0, "_hert_ueomoepsdrourch"

    const-string/jumbo v0, "sehm_err_u_eocohprotd"

    const/4 v3, 0x1

    const-string/jumbo v0, "rsodhrrpehue_oe_c_opt"

    const-string/jumbo v0, "other_push_error_code"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo v1, "rk srge1qoMw: Cd, n-oe en:rr0u0  "

    const-string v1, "errCode : -100 , errMsg : unknown"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p0, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x5

    const-string v1, "ersregrEur  srhedCto:oPhort"

    const-string/jumbo v1, "us hog PdrtC:tererrheoreEro"

    const/4 v3, 0x1

    const-string v1, "Poemgerr sr: tehedohErOturC"

    const-string v1, "getOtherPushErrCode error: "

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v0, "uGCXogbosniP"

    const-string/jumbo v0, "uPinCbGgfXso"

    const/4 v3, 0x3

    const-string v0, "hiCgfbPuGons"

    const-string v0, "XGPushConfig"

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const-string p0, ""

    const/4 v3, 0x1

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object p0
.end method

.method public static getOtherPushToken(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/d/d;->f()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string/jumbo v0, "uXnoiguCuPfs"

    const-string v0, "XgniPuusCofG"

    const/4 v3, 0x7

    const-string/jumbo v0, "ufsioghpGCPn"

    const-string v0, "XGPushConfig"

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string/jumbo v1, "netTksetqpohreOhu"

    const-string/jumbo v1, "ktsOtTPpehohrnuee"

    const/4 v3, 0x5

    const-string v1, "essTPheerhOtnuktg"

    const-string v1, "getOtherPushToken"

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    return-object p0
.end method

.method public static getOtherPushType(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/tencent/android/tpush/d/d;->k()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v0, "uPomCsXqngfi"

    const-string v0, "PuhiXnosqCgf"

    const/4 v3, 0x2

    const-string v0, "XihoonuCPGgs"

    const-string v0, "XGPushConfig"

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v1, "uthnebrTgsPtsehoO"

    const-string/jumbo v1, "uTstoteesrPgenhOh"

    const/4 v3, 0x1

    const-string v1, "eTuhteuseOtPkohng"

    const-string v1, "getOtherPushToken"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 p0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-object p0
.end method

.method public static getReportDebugMode(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const-string/jumbo v1, "oer..oppemmt"

    const-string v1, ".etmpre.rmoo"

    const/4 v3, 0x7

    const-string v1, ".edorrt.qeop"

    const-string v1, ".report.mode"

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getInt(Landroid/content/Context;Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    const/4 v1, 0x1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return v1
.end method

.method public static getServerIpList(Landroid/content/Context;)Lcom/tencent/android/tpush/XGServerInfo;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v1, "posi.odn.cp.eaac.do.ocmt.nilulcvsslcgtoomtnte.ita.rix"

    const-string/jumbo v1, "igdooucstle.it.xnmt.ctcsinnlcaovtlpn.aedcoo.morpai..."

    const-string/jumbo v1, "omcmo..tvmudctnc.rai.alonixs.td..cnnteaplilesiitoocpg"

    const-string v1, "com.tencent.android.xg.vip.action.custom.iplist.local"

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {p0, v1, v0}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    new-instance v0, Lcom/tencent/android/tpush/XGServerInfo;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/XGServerInfo;-><init>(Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0
.end method

.method public static getStatAutoPage(Landroid/content/Context;)Z
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    sget-boolean p0, Lcom/tencent/android/tpush/XGPushConfig;->c:Z

    const/4 v1, 0x0

    return p0
.end method

.method public static getToken(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-nez p0, :cond_0

    const/4 v1, 0x5

    move v2, v1

    const-string p0, "GbCgoofPiuns"

    const-string p0, "fihnsbPuGgCo"

    const/4 v2, 0x6

    const-string/jumbo p0, "niuCsbXoPhgG"

    const-string p0, "XGPushConfig"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string/jumbo v0, "tloncuut enx"

    const-string/jumbo v0, "null context"

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 p0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/service/cache/CacheManager;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p0
.end method

.method public static init(Landroid/content/Context;)Lcom/tencent/android/tpush/XGPushConfig$Build;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-nez p0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string p0, "hXuuofPpCing"

    const-string/jumbo p0, "ofngXiuPuhCs"

    const/4 v2, 0x7

    const-string p0, "PnCfiosXquGg"

    const-string p0, "XGPushConfig"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    const-string/jumbo v0, "niseuttls opcx "

    const-string/jumbo v0, "xiouc  pttlnnse"

    const/4 v2, 0x2

    const-string/jumbo v0, "nt mx nilstlceu"

    const-string v0, "context is null"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    const/4 p0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    return-object p0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance v0, Lcom/tencent/android/tpush/XGPushConfig$Build;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/XGPushConfig$Build;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    return-object v0
.end method

.method public static isEnableDebug(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string v1, "caodoeen.nhtdebm.ugo.tq.cr,npiud"

    const-string v1, "boonu..rq.muedpeiscd.e,htntandcg"

    const/4 v3, 0x2

    const-string/jumbo v1, "ongrabm.odtusec.cp.nn.tu,dhbteed"

    const-string v1, "com.tencent.android.tpush.debug,"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getInt(Landroid/content/Context;Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    or-int/2addr v3, v2

    const/4 v1, 0x7

    const/4 v1, 0x1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    return v1
.end method

.method public static isEnableNotificationSound(Landroid/content/Context;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez p0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 p0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x1

    return p0

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->i:Ljava/lang/Boolean;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    if-nez v0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->i()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast p0, Ljava/lang/Boolean;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->i:Ljava/lang/Boolean;

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->i:Ljava/lang/Boolean;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    if-nez p0, :cond_2

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string p0, "iGfsXCugPnho"

    const-string p0, "XGPushConfig"

    const/4 v2, 0x3

    const-string v0, " ciigaipeNdrdfmI  trssfnnohdiou nafEiogblr,el nefesgne ikoo nairaobSlcoacnct "

    const-string/jumbo v0, "misgoncisdiootErfosilc gaif rcfo bleeIrnn lNe  bnofoutSana nik nerecddan,hgai"

    const/4 v2, 0x5

    const-string/jumbo v0, "idnsaEnrqoc afSaebmnuecI olsolegnrffid o  notNiec erilda cak gonfnonrightiibn"

    const-string/jumbo v0, "isEnableNotificationSound false, ignore channelId or ring config from backend"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->i:Ljava/lang/Boolean;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    return p0
.end method

.method public static isEnableShowInMsg(Landroid/content/Context;)Z
    .locals 3

    const/4 v2, 0x5

    if-nez p0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x3

    const/4 p0, 0x0

    const/4 v1, 0x4

    move v2, v1

    return p0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->j:Ljava/lang/Boolean;

    const/4 v1, 0x0

    xor-int/2addr v2, v1

    if-nez v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->g()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x3

    check-cast p0, Ljava/lang/Boolean;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->j:Ljava/lang/Boolean;

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->j:Ljava/lang/Boolean;

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x7

    return p0
.end method

.method public static isForeiginPush(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->k:Ljava/lang/Boolean;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x6

    if-nez v0, :cond_2

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string v0, "PSsHIEOPISmGTHU__RSIF"

    const-string v0, "ESIm_RPSHGIFTNI_SUPOH"

    const/4 v3, 0x6

    const-string v0, "SIUmFGTR_PISNSEIOPH_H"

    const-string v0, "TPUSH_IS_FOREIGINPUSH"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez p0, :cond_0

    const/4 v3, 0x2

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x2

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->k:Ljava/lang/Boolean;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x7

    return p0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string/jumbo v0, "retu"

    const-string/jumbo v0, "ture"

    const/4 v3, 0x3

    const-string/jumbo v0, "uetr"

    const-string/jumbo v0, "true"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz p0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget-object p0, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->k:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->k:Ljava/lang/Boolean;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :catchall_0
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    sget-object p0, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->k:Ljava/lang/Boolean;

    :cond_2
    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->k:Ljava/lang/Boolean;

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    return p0
.end method

.method public static isHuaweiDebug()Z
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    sget-boolean v0, Lcom/tencent/android/tpush/XGPushConfig;->_isHuaweiDebug:Z

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return v0
.end method

.method public static isLocationEnable(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->enableLocation:Ljava/lang/Boolean;

    const/4 v3, 0x1

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    const-string/jumbo v1, "labtoeo..o._cnnnrmehtldip.etaeucntooi,cson"

    const-string v1, ".oceoe_ianroielt,dbhn.adconct.tpoum.nnslet"

    const/4 v3, 0x1

    const-string v1, "c.ooebc,seutntcenlebltm.iaaanort..dhiodn_p"

    const-string v1, "com.tencent.android.tpush.enable_location,"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p0, v0, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getInt(Landroid/content/Context;Ljava/lang/String;I)I

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    invoke-static {v1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->enableLocation:Ljava/lang/Boolean;

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x1

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->enableLocation:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x3

    return p0
.end method

.method public static isNotTryFcm(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v0, 0x0

    move v3, v0

    const/4 v2, 0x2

    const/4 v2, 0x1

    if-nez p0, :cond_0

    const/4 v2, 0x7

    move v3, v2

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    sget-object v1, Lcom/tencent/android/tpush/XGPushConfig;->fcmIsSuccess:Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v1, :cond_2

    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->e()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {p0, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    check-cast p0, Ljava/lang/Integer;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    if-eqz p0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x1

    :cond_1
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->fcmIsSuccess:Ljava/lang/Boolean;

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->fcmIsSuccess:Ljava/lang/Boolean;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    return p0
.end method

.method public static isNotificationShowEnable(Landroid/content/Context;)Z
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v0, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p0, :cond_1

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    sget-object v1, Lcom/tencent/android/tpush/XGPushConfig;->l:Landroid/content/SharedPreferences;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-nez v1, :cond_0

    const/4 v4, 0x7

    const-string/jumbo v1, "pphrb.upaeax.pse.frig"

    const-string/jumbo v1, "peaxsbrvpgpf.ia.prhe."

    const/4 v4, 0x5

    const-string v1, "evfpeghpa.pprsirp.s.x"

    const-string/jumbo v1, "xg.vip.app.shareprefs"

    const/4 v4, 0x5

    const/4 v2, 0x3

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->l:Landroid/content/SharedPreferences;

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->l:Landroid/content/SharedPreferences;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v1, "NWSItp_Nqemrha.ncAnIOduOocTa_bIdFCuTetH.n.s.ntOeio"

    const-string/jumbo v1, "ndOtmpue_IWTrtC.FieduTcNlenHOh.SatcNbnOa.n_AooI.Is"

    const/4 v4, 0x1

    const-string v1, "etsC.c.a.OdSdnOTI_brlnc.eFnNnWIsNpaOt_etioeuHoThIm"

    const-string v1, "com.tencent.android.tpush.enable_SHOW_NOTIFICATION"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {v1}, Lcom/tencent/tpns/baseapi/base/util/Util;->getKey(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-interface {p0, v1, v0}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    return p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v1, "XGPushConfig"

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    const-string v2, "NeomitciaitpfnSbEnoolahs"

    const-string/jumbo v2, "oStEonapNnsebicitfioihla"

    const/4 v4, 0x6

    const-string v2, "heEaoowfasotclNnbiniStii"

    const-string/jumbo v2, "isNotificationShowEnable"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    return v0
.end method

.method public static isReportApplistEnable(Landroid/content/Context;)Z
    .locals 6

    const/4 v5, 0x0

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->enableApplist:Ljava/lang/Boolean;

    const/4 v4, 0x7

    shr-int/2addr v5, v4

    const/4 v1, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v3, ".ndd.buc,ei.tap_asqhl.teprtaeobinnmcpteol"

    const-string v3, ".tlpeppoqutdeh_aei.rcnn.mabtil,dcsntesa.o"

    const/4 v5, 0x7

    const-string/jumbo v3, "nnpolaut.haltsd.e.nceeias.imdnb,toupprt_c"

    const-string v3, "com.tencent.android.tpush.enable_applist,"

    const/4 v4, 0x5

    and-int/2addr v5, v4

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {p0, v0, v2}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getInt(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x7

    move v0, v2

    const/4 v5, 0x2

    move v0, v2

    move v0, v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x0

    move v0, v1

    move v0, v1

    const/4 v5, 0x4

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->enableApplist:Ljava/lang/Boolean;

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/service/a/a;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/service/a/a;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    iget v0, v0, Lcom/tencent/android/tpush/service/a/a;->F:I

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/4 v3, -0x1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-ne v0, v3, :cond_2

    const/4 v5, 0x7

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->enableApplist:Ljava/lang/Boolean;

    const/4 v4, 0x3

    or-int/2addr v5, v4

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    return p0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/service/a/a;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/service/a/a;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget p0, p0, Lcom/tencent/android/tpush/service/a/a;->F:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    if-ne p0, v2, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    return v2

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    return v1
.end method

.method public static isReportNotificationStatusEnable(Landroid/content/Context;)Z
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->enableNotification:Ljava/lang/Boolean;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    const/4 v2, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-nez v0, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v3, "_osndoOhTIN,.npatrme.telb.sAeI.neicaICctONdnu"

    const/4 v5, 0x0

    const-string v3, "dNreCcepnmitIA.tlN_.oIbpIunnosd,eOc.nT.OtheTa"

    const-string v3, "com.tencent.android.tpush.enable_NOTIICATION,"

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {p0, v0, v2}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getInt(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x7

    move v0, v2

    move v0, v2

    const/4 v5, 0x3

    move v0, v2

    move v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    move v0, v1

    move v0, v1

    const/4 v5, 0x5

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x0

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->enableNotification:Ljava/lang/Boolean;

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/service/a/a;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/service/a/a;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget v0, v0, Lcom/tencent/android/tpush/service/a/a;->G:I

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v3, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-ne v0, v3, :cond_2

    const/4 v5, 0x2

    const/4 v4, 0x5

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->enableNotification:Ljava/lang/Boolean;

    const/4 v4, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    return p0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/service/a/a;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/service/a/a;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget p0, p0, Lcom/tencent/android/tpush/service/a/a;->G:I

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-ne p0, v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    return v2

    :cond_3
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    return v1
.end method

.method public static isUseFcmFirst(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object v1, Lcom/tencent/android/tpush/XGPushConfig;->useFcmFirst:Ljava/lang/Boolean;

    const/4 v3, 0x6

    if-nez v1, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->f()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p0, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    check-cast p0, Ljava/lang/Integer;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x3

    if-eqz p0, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v0, 0x1

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->useFcmFirst:Ljava/lang/Boolean;

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->useFcmFirst:Ljava/lang/Boolean;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    return p0
.end method

.method public static isUsedFcmPush(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    return v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x0

    sget-object v1, Lcom/tencent/android/tpush/XGPushConfig;->isUsedFcmPush:Ljava/lang/Boolean;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-nez v1, :cond_2

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->d()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p0, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    check-cast p0, Ljava/lang/Integer;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    if-eqz p0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedFcmPush:Ljava/lang/Boolean;

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedFcmPush:Ljava/lang/Boolean;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    return p0
.end method

.method public static isUsedHttpAccountOperate(Landroid/content/Context;)Z
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x5

    const/4 v0, 0x0

    const/4 v6, 0x5

    if-nez p0, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    return v0

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedTpnsChannel(Landroid/content/Context;)Z

    move-result v1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-nez v1, :cond_1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    sput-object v1, Lcom/tencent/android/tpush/XGPushConfig;->g:Ljava/lang/Boolean;

    :cond_1
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x2

    sget-object v1, Lcom/tencent/android/tpush/XGPushConfig;->g:Ljava/lang/Boolean;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v2, "PiXsmhGgqnof"

    const-string v2, "gsnmGCfihPoX"

    const-string v2, "XGPushConfig"

    const/4 v6, 0x0

    if-nez v1, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v1}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->useHttp()I

    move-result v1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v4, " osalHne:tugfrnooBdayomupccrca tt"

    const-string v4, "dnaBoclocr rac ptt:Hugomfntoa uye"

    const/4 v6, 0x4

    const-string v4, "a: mdt olMBrfcuyng eaocptatmnoHcr"

    const-string v4, "accountManagerByHttp from cloud: "

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-nez v1, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v3

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v1, ""

    const/4 v6, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/e/b/a;->c(Ljava/lang/String;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-static {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    check-cast p0, Ljava/lang/Boolean;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x4

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->g:Ljava/lang/Boolean;

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x4

    goto :goto_0

    :cond_2
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/4 p0, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-ne v1, p0, :cond_3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    move v0, p0

    move v0, p0

    const/4 v6, 0x5

    move v0, p0

    move v0, p0

    :cond_3
    const/4 v6, 0x3

    const/4 v5, 0x6

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->g:Ljava/lang/Boolean;

    :cond_4
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    const-string/jumbo v0, "oUtpoHunA ces:etcieObdtsar"

    const-string/jumbo v0, "uecirbetpp:aosH tUsAnctdOe"

    const/4 v6, 0x7

    const-string/jumbo v0, "tucHebdt sAscOntoirap:Upet"

    const-string/jumbo v0, "isUsedHttpAccountOperate: "

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->g:Ljava/lang/Boolean;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->g:Ljava/lang/Boolean;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x3

    return p0
.end method

.method public static isUsedOtherPush(Landroid/content/Context;)Z
    .locals 4

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x0

    move v2, v0

    move v2, v0

    const/4 v3, 0x4

    if-nez p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    return v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    sget-object v1, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush:Ljava/lang/Boolean;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v1, :cond_3

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->c()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p0, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast v1, Ljava/lang/Integer;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz v1, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v0, 0x1

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x5

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush:Ljava/lang/Boolean;

    const/4 v3, 0x2

    const/4 v2, 0x0

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v0, :cond_2

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/d/d;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpush/d/d;->b()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush:Ljava/lang/Boolean;

    :cond_2
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush:Ljava/lang/Boolean;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v0, :cond_3

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->o(Landroid/content/Context;)Z

    move-result p0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {p0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush:Ljava/lang/Boolean;

    :cond_3
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    shr-int/2addr v3, v2

    const-string/jumbo v0, "te:hUsuePOuuhisr"

    const-string v0, "OerPthuh:sesduiU"

    const/4 v3, 0x2

    const-string v0, ":PshsdOpUusehirt"

    const-string/jumbo v0, "isUsedOtherPush:"

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush:Ljava/lang/Boolean;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo v0, "nogGCuipqsfh"

    const-string v0, "GniuCXopsgfh"

    const/4 v3, 0x3

    const-string v0, "XgsoGfCsniuP"

    const-string v0, "XGPushConfig"

    const/4 v3, 0x3

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->isUsedOtherPush:Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    return p0
.end method

.method public static isUsedTpnsChannel(Landroid/content/Context;)Z
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    const/4 v0, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-nez p0, :cond_0

    const/4 v6, 0x7

    return v0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    sget-object v1, Lcom/tencent/android/tpush/XGPushConfig;->h:Ljava/lang/Boolean;

    const/4 v6, 0x2

    const-string/jumbo v2, "nogmfGqhPisX"

    const-string v2, "gshoinfGqXPC"

    const/4 v6, 0x6

    const-string v2, "hfGuooiPXnCg"

    const-string v2, "XGPushConfig"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-nez v1, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {v1}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->useTpnsChannel()I

    move-result v1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string/jumbo v4, "uher bnns sl :pCldTfncomseu"

    const-string/jumbo v4, "scsTnn musd:hloarneeflC u p"

    const/4 v6, 0x0

    const-string/jumbo v4, "ln r  uoesCuhsl:ofamTndpcue"

    const-string/jumbo v4, "useTpnsChannel from cloud: "

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez v1, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->h()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    check-cast p0, Ljava/lang/Boolean;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->h:Ljava/lang/Boolean;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    goto :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    const/4 p0, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x5

    if-ne v1, p0, :cond_2

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    move v0, p0

    move v0, p0

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v0}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x1

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->h:Ljava/lang/Boolean;

    :cond_3
    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string v0, ":alpisUpnsmheTsnC e"

    const-string v0, "enTmsCUsinashpen l:"

    const/4 v6, 0x4

    const-string v0, "CessdannqlT:eUspihn"

    const-string/jumbo v0, "isUsedTpnsChannel: "

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->h:Ljava/lang/Boolean;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->h:Ljava/lang/Boolean;

    const/4 v5, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {p0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result p0

    const/4 v6, 0x3

    const/4 v5, 0x0

    return p0
.end method

.method public static resetBadgeNum(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/common/c;->b(Landroid/content/Context;)V

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public static resetHuaweiBadgeNum(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/common/c;->a(Landroid/content/Context;)V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method

.method public static setAccessId(Landroid/content/Context;J)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    cmp-long v0, p1, v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v0, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    new-array v0, v0, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->b()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x6

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    aput-object v1, v0, v2

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x2

    invoke-static {p0, p1, p2}, Lcom/tencent/tpns/baseapi/XGApiConfig;->setAccessId(Landroid/content/Context;J)V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    return-void
.end method

.method public static setAccessKey(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->setAccessKey(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public static setAutoFilterHuaweiPublicNotificationFlag(Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x2

    sput-boolean p0, Lcom/tencent/android/tpush/XGPushConfig;->autoFilterHuaweiPublicNotification:Z

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method public static setAutoInit(Z)V
    .locals 2

    const/4 v1, 0x6

    sput-boolean p0, Lcom/tencent/android/tpush/XGPushConfig;->autoInit:Z

    const/4 v1, 0x1

    const/4 v0, 0x5

    return-void
.end method

.method public static setBadgeNum(Landroid/content/Context;I)V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/c;->c(Landroid/content/Context;I)V

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public static setEnableActivityWindowSecFlag(Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    sput-boolean p0, Lcom/tencent/android/tpush/XGPushConfig;->enableActivityWindowSecFlag:Z

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method public static setForeiginPushEnable(Landroid/content/Context;Z)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-void
.end method

.method public static setForeignWeakAlarmMode(Landroid/content/Context;Z)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lcom/tencent/tpns/mqttchannel/api/MqttConfig;->setForeignWeakAlarmMode(Landroid/content/Context;Z)V

    const/4 v1, 0x1

    return-void
.end method

.method public static setGameServer(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    if-eqz p0, :cond_1

    const/4 v0, 0x7

    move v1, v0

    if-eqz p1, :cond_1

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    if-nez p0, :cond_0

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    sput-object p1, Lcom/tencent/android/tpush/XGPushConfig;->b:Ljava/lang/String;

    :cond_1
    :goto_0
    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public static setHeartbeatInterval(Landroid/content/Context;I)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/16 v0, 0xa

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-lt p1, v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x4

    const v0, 0x8ca0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-ge p1, v0, :cond_0

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    invoke-static {p0, p1}, Lcom/tencent/tpns/mqttchannel/api/MqttConfig;->setKeepAliveInterval(Landroid/content/Context;I)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/XGPushConfig$2;

    const/4 v3, 0x4

    invoke-direct {v1, p0, p1}, Lcom/tencent/android/tpush/XGPushConfig$2;-><init>(Landroid/content/Context;I)V

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string p1, "XCsifuohPGng"

    const-string p1, "XGPushConfig"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-string/jumbo v0, "tavroarnIHttleteebes"

    const/4 v3, 0x0

    const-string v0, "ebsmvttHeratlIrneeaa"

    const-string/jumbo v0, "setHeartbeatInterval"

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p1, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-void
.end method

.method public static setHeartbeatIntervalMs(Landroid/content/Context;I)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    div-int/lit16 p1, p1, 0x3e8

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->setHeartbeatInterval(Landroid/content/Context;I)V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public static setHuaweiBadgeNum(Landroid/content/Context;I)V
    .locals 2

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/c;->b(Landroid/content/Context;I)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public static setHuaweiDebug(Z)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x7

    sput-boolean p0, Lcom/tencent/android/tpush/XGPushConfig;->_isHuaweiDebug:Z

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public static setImei(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x7

    move v1, v0

    sput-object p1, Lcom/tencent/android/tpush/XGPushConfig;->d:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public static setInstallChannel(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x1

    if-eqz p0, :cond_1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    if-eqz p1, :cond_1

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-virtual {p1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    if-nez p0, :cond_0

    const/4 v1, 0x4

    const/4 v0, 0x3

    goto :goto_0

    :cond_0
    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x3

    sput-object p1, Lcom/tencent/android/tpush/XGPushConfig;->a:Ljava/lang/String;

    :cond_1
    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x0

    return-void
.end method

.method public static setLocationEnable(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->enableLocation:Ljava/lang/Boolean;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-eqz v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-eq v0, p1, :cond_1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x1

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->enableLocation:Ljava/lang/Boolean;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string v1, "acodtb.latr,nopuindce._.heocnlnstbetmna.ie"

    const/4 v3, 0x7

    const-string/jumbo v1, "paacoso_nedtomrlit.nucbnon.ndi.,o.cahtetel"

    const-string v1, "com.tencent.android.tpush.enable_location,"

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, v0, p1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putInt(Landroid/content/Context;Ljava/lang/String;I)V

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method public static setMiPushAppId(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/d/d;->a(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method

.method public static setMiPushAppKey(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/d/d;->b(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x5

    return-void
.end method

.method public static setMzPushAppId(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/d/d;->c(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method public static setMzPushAppKey(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/d/d;->d(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    return-void
.end method

.method public static setNotTryFcm(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-nez p0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->fcmIsSuccess:Ljava/lang/Boolean;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eq v0, p1, :cond_2

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x6

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v3, 0x5

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->fcmIsSuccess:Ljava/lang/Boolean;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x0

    const/4 v0, 0x1

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    new-array v0, v0, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v3, 0x6

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->e()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v1, p1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object p1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v1, 0x0

    and-int/2addr v3, v1

    const/4 v2, 0x1

    move v3, v2

    aput-object p1, v0, v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    :cond_2
    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method

.method public static setNotificationChannelID(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    const/4 v3, 0x6

    sput-object p1, Lcom/tencent/android/tpush/XGPushConfig;->notificationChannelID:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string/jumbo v1, "ofnlnbithieiDuaIn..ancc"

    const-string/jumbo v1, "nnelttuinfIhn.i.Doacaci"

    const/4 v3, 0x7

    const-string/jumbo v1, "o.nDotuncntcii.hainIlef"

    const-string v1, ".notification.channelID"

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {p0, v0, p1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public static setNotificationChannelName(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    sput-object p1, Lcom/tencent/android/tpush/XGPushConfig;->notificationChannelName:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string/jumbo v1, "natoacnpp.ahcefinilm.etNi"

    const-string/jumbo v1, "nttom.ipl.fnaaieNccniehao"

    const/4 v3, 0x2

    const-string/jumbo v1, "ooaannnnq.N.fitecchietlai"

    const-string v1, ".notification.channelName"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-static {p0, v0, p1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-void
.end method

.method public static setNotificationShowEnable(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x7

    if-eqz p0, :cond_1

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->l:Landroid/content/SharedPreferences;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const-string/jumbo v0, "shsgaap.v.epeixpfs.rq"

    const-string/jumbo v0, "rse.pxfrqsgpap.vi.aeh"

    const/4 v3, 0x7

    const-string v0, "e..masrhfxire.asgpppp"

    const-string/jumbo v0, "xg.vip.app.shareprefs"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    sput-object p0, Lcom/tencent/android/tpush/XGPushConfig;->l:Landroid/content/SharedPreferences;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    sget-object p0, Lcom/tencent/android/tpush/XGPushConfig;->l:Landroid/content/SharedPreferences;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v0, "d_etoOlson.T._aOFWaoN.hmeIHcnpibuetCT.cIsrOIeSnNnt"

    const-string v0, "H_sNncpeIOtscOdneCO.eneWothmt.b.naSdTTFluoI_iarI.N"

    const-string v0, "NOITnbnOb_tnOoccohS.IesIpameHreiTC.F.tddNe._AWluta"

    const-string v0, "com.tencent.android.tpush.enable_SHOW_NOTIFICATION"

    const/4 v2, 0x6

    move v3, v2

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/base/util/Util;->getKey(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string/jumbo p1, "unfXoGusmghP"

    const-string p1, "gXimhsoGPfnu"

    const/4 v3, 0x7

    const-string p1, "PXfinosphgGu"

    const-string p1, "XGPushConfig"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string v0, "aeotioosqNStEwhiicelabnnt"

    const-string/jumbo v0, "iesfonnoahciitEtewSNlotab"

    const/4 v3, 0x1

    const-string v0, "cSsaontieoEtahsflNtinowie"

    const-string/jumbo v0, "setNotificationShowEnable"

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {p1, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x4

    return-void
.end method

.method public static setOPPOBadgeNum(Landroid/content/Context;I)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x0

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/c;->d(Landroid/content/Context;I)V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static setOppoPushAppId(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x1

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/d/d;->e(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method

.method public static setOppoPushAppKey(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/d/d;->f(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public static setPowerSaveMode(Landroid/content/Context;Z)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-static {p0, p1}, Lcom/tencent/tpns/baseapi/XGApiConfig;->setPowerSaveMode(Landroid/content/Context;Z)V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public static setReportApplistEnable(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->enableApplist:Ljava/lang/Boolean;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-eq v0, p1, :cond_1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->enableApplist:Ljava/lang/Boolean;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const-string/jumbo v1, "nhpmede.tidl.,stc.uleaonsrantibtancep_mpo"

    const-string v1, "com.tencent.android.tpush.enable_applist,"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p0, v0, p1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putInt(Landroid/content/Context;Ljava/lang/String;I)V

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x7

    return-void
.end method

.method public static setReportDebugMode(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x6

    if-eqz p0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string v1, ".tororemde.b"

    const-string/jumbo v1, "treerboo..md"

    const/4 v3, 0x2

    const-string/jumbo v1, "o.rtdbeprome"

    const-string v1, ".report.mode"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p0, v0, p1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putInt(Landroid/content/Context;Ljava/lang/String;I)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method public static setReportNotificationStatusEnable(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->enableNotification:Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    if-eq v0, p1, :cond_1

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    sput-object v0, Lcom/tencent/android/tpush/XGPushConfig;->enableNotification:Ljava/lang/Boolean;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v1, "aTCep_ubAstanI,o.OnIudri.lnneNht.dTINecucOetm"

    const-string v1, "edutTiuenOIa,T.oAtImpcrsnIeb._dlntNCanO..heNc"

    const/4 v3, 0x6

    const-string/jumbo v1, "toi.n.npeNO,dbutaTedl.onpcsOChmten.NcIeT_AraI"

    const-string v1, "com.tencent.android.tpush.enable_NOTIICATION,"

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p0, v0, p1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putInt(Landroid/content/Context;Ljava/lang/String;I)V

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method

.method public static setRequestProxy(Lcom/tencent/android/tpush/XGPushProxy;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    if-nez p0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string/jumbo p0, "siugnhofqXCP"

    const-string p0, "XGPushConfig"

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x3

    const-string v0, "eosxtr tl lrli,yasx yunRsqs Pouwfaep"

    const-string v0, "ar alusp, fxiertsyRylqotxlpewns u oP"

    const/4 v2, 0x2

    const-string/jumbo v0, "psemxyur,lqonxatiewlrePfs a  lytouR "

    const-string/jumbo v0, "setRequestProxy fail, proxy was null"

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/common/i;->a()Lcom/tencent/android/tpush/common/i;

    move-result-object v0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0, p0}, Lcom/tencent/android/tpush/common/i;->a(Lcom/tencent/android/tpush/XGPushProxy;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-void
.end method

.method public static setServerIpList(Landroid/content/Context;Lcom/tencent/android/tpush/XGServerInfo;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    if-eqz p0, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-virtual {p1}, Lcom/tencent/android/tpush/XGServerInfo;->getIpArray()Lorg/json/JSONArray;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string/jumbo v0, "rootoiotcmnnam.ctalxv.a.neliticu.cceod..odpig.pslti.n"

    const-string/jumbo v0, "ivn.n.icq.ntd.eloectx.ico...cdmnltotguraplsciaooptmai"

    const/4 v2, 0x6

    const-string v0, "dcettbp.nc.umnsin.vocnooottlpome.aiiaigalccd.tx.r.i.l"

    const-string v0, "com.tencent.android.xg.vip.action.custom.iplist.local"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p0, v0, p1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method

.method public static setStatAutoPage(Landroid/content/Context;Z)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    sput-boolean p1, Lcom/tencent/android/tpush/XGPushConfig;->c:Z

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public static setTPushLogger(Lcom/tencent/tpns/baseapi/base/logger/LoggerInterface;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->setLogger(Lcom/tencent/tpns/baseapi/base/logger/LoggerInterface;)V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    return-void
.end method

.method public static setUseFcmFirst(Landroid/content/Context;Z)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez p0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    sget-object v0, Lcom/tencent/android/tpush/XGPushConfig;->useFcmFirst:Ljava/lang/Boolean;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    if-eq v0, p1, :cond_2

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    sput-object p1, Lcom/tencent/android/tpush/XGPushConfig;->useFcmFirst:Ljava/lang/Boolean;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x0

    const/4 p1, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    new-array p1, p1, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->f()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    sget-object v1, Lcom/tencent/android/tpush/XGPushConfig;->useFcmFirst:Ljava/lang/Boolean;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v1}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    aput-object v0, p1, v1

    const/4 v2, 0x3

    move v3, v2

    invoke-static {p0, p1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    new-instance v0, Lcom/tencent/android/tpush/XGPushConfig$3;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/XGPushConfig$3;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {p1, v0}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :cond_2
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method

.method public static setVivoBadgeNum(Landroid/content/Context;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/common/c;->e(Landroid/content/Context;I)V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method public static setfcmSenderId(Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/d/a;->b(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x4

    return-void
.end method
