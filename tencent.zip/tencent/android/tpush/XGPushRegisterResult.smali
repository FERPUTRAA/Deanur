.class public Lcom/tencent/android/tpush/XGPushRegisterResult;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/XGIResult;


# instance fields
.field a:J

.field b:Ljava/lang/String;

.field c:Ljava/lang/String;

.field d:Ljava/lang/String;

.field e:S

.field f:Ljava/lang/String;

.field g:Ljava/lang/String;

.field h:I


# direct methods
.method constructor <init>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->a:J

    const/4 v2, 0x7

    move v3, v2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->b:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->c:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->d:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x1

    move v2, v1

    move v2, v1

    const/4 v3, 0x2

    iput-short v1, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->e:S

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->f:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->g:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    const/16 v0, 0x64

    const/4 v3, 0x2

    const/4 v2, 0x0

    iput v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->h:I

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method


# virtual methods
.method public getAccessId()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, ".asi@@i~i@l~r-@@fol~~vmu/ @K~@/t n @~M@~ t ~d@ s~o ~~@ ~~4~~ob~1b~b~oo@ o@@ @ @~ ~~y~  c @@f@  @"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-wide v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->a:J

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    return-wide v0
.end method

.method public getAccount()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->c:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0
.end method

.method public getFacilityIdentity()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->b:Ljava/lang/String;

    const/4 v2, 0x5

    return-object v0
.end method

.method public getOtherPushToken()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->g:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public getPushChannel()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->h:I

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return v0
.end method

.method public getTicket()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->d:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-object v0
.end method

.method public getTicketType()S
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-short v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->e:S

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public getToken()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->f:Ljava/lang/String;

    const/4 v1, 0x1

    shl-int/2addr v2, v1

    return-object v0
.end method

.method public parseIntent(Landroid/content/Intent;)V
    .locals 5

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v0, "Isdma"

    const-string v0, "dcsaI"

    const-string v0, "aIdco"

    const-string v0, "accId"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x3

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v1, v2}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->a:J

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v0, "iddcmbee"

    const-string v0, "idImdece"

    const/4 v4, 0x4

    const-string/jumbo v0, "ievIdeud"

    const-string v0, "deviceId"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->b:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo v0, "pocuanc"

    const-string/jumbo v0, "uacoocn"

    const/4 v4, 0x7

    const-string v0, "account"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->c:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v0, "teqcit"

    const-string v0, "cteitb"

    const/4 v4, 0x3

    const-string/jumbo v0, "ttskie"

    const-string/jumbo v0, "ticket"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->d:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v0, "eukmiytpTc"

    const-string v0, "Tiekpcutty"

    const/4 v4, 0x4

    const-string/jumbo v0, "ieytokptec"

    const-string/jumbo v0, "ticketType"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getShortExtra(Ljava/lang/String;S)S

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-short v0, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->e:S

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v0, "bontk"

    const-string/jumbo v0, "nkpot"

    const/4 v4, 0x1

    const-string/jumbo v0, "token"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->f:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    goto :goto_0

    :catchall_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string p1, "eRhlsXuPGrsgutieuseR"

    const-string p1, "XGPushRegisterResult"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v0, " nprredpnceeItenqxatoft sp"

    const-string/jumbo v0, "reerodtnqextc aeeptfsn pIn"

    const/4 v4, 0x6

    const-string v0, " xrIcretqtundefeoean pnpet"

    const-string/jumbo v0, "unexpected for parseIntent"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x1

    return-void
.end method

.method public toJson()Lorg/json/JSONObject;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v4, 0x0

    const-string/jumbo v1, "ntscaos"

    const-string/jumbo v1, "nasuoct"

    const/4 v4, 0x2

    const-string v1, "actmouc"

    const-string v1, "account"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->c:Ljava/lang/String;

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo v1, "ttekom"

    const-string v1, "ettmik"

    const/4 v4, 0x0

    const-string/jumbo v1, "kitteb"

    const-string/jumbo v1, "ticket"

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->d:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const-string v1, "icoddIuv"

    const-string/jumbo v1, "veIdodic"

    const/4 v4, 0x3

    const-string v1, "idIeevcp"

    const-string v1, "deviceId"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->b:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v1, "ktctbyieqT"

    const-string/jumbo v1, "tecTybkite"

    const/4 v4, 0x2

    const-string v1, "ctspteeyki"

    const-string/jumbo v1, "ticketType"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-short v2, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->e:S

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v1, "knemo"

    const-string/jumbo v1, "token"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->f:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    goto :goto_0

    :catchall_0
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string v1, "PtseoGeRRglurusuXeht"

    const-string/jumbo v1, "theiRruXtgPGRsuselue"

    const/4 v4, 0x7

    const-string/jumbo v1, "leguXbssetiesrhRGutP"

    const-string v1, "XGPushRegisterResult"

    const/4 v4, 0x4

    const-string/jumbo v2, "ouoJe utpsx cpnreofet"

    const-string v2, "Jsefuoepnt enxrpcto o"

    const/4 v4, 0x0

    const-string/jumbo v2, "t nr dopxfscetJuenoeo"

    const-string/jumbo v2, "unexpected for toJson"

    const/4 v4, 0x2

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v1, "cssiPeTgqs=qIuRecgsesdsteMaae[r"

    const-string v1, "Isctee eqPRsTsigdrsag=ssa[ueMec"

    const/4 v4, 0x2

    const-string v1, "RascugisM=essgITeacte [Pseershd"

    const-string v1, "TPushRegisterMessage [accessId="

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->a:J

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v1, "didmec= Iv,"

    const-string v1, " vscI=,dide"

    const/4 v4, 0x0

    const-string v1, ",=ddoce veI"

    const-string v1, ", deviceId="

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->b:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string/jumbo v1, "o, ncbaumt"

    const-string v1, "cu,moactn "

    const/4 v4, 0x6

    const-string v1, ", account="

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->c:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v1, "to=kecu,t"

    const-string v1, "ec kot,=t"

    const/4 v4, 0x0

    const-string/jumbo v1, "tc=ke tp,"

    const-string v1, ", ticket="

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->d:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v1, "bcke py=qt,ei"

    const-string v1, "cypitbk,T e=e"

    const/4 v4, 0x7

    const-string v1, ",ysetptk=eic "

    const-string v1, ", ticketType="

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-short v1, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->e:S

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo v1, "nt, o=uk"

    const/4 v4, 0x4

    const-string v1, "en mk,=t"

    const-string v1, ", token="

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->f:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const-string v1, "elshopaph nu=n"

    const-string v1, ",u=e shppahlnn"

    const/4 v4, 0x0

    const-string/jumbo v1, "n=ahCbsuep,n h"

    const-string v1, ", pushChannel="

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget v1, p0, Lcom/tencent/android/tpush/XGPushRegisterResult;->h:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x6

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object v0
.end method
