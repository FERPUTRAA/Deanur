.class Lcom/tencent/android/tpush/InnerTpnsActivity$5;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/InnerTpnsActivity;->a(ILandroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Lcom/tencent/android/tpush/InnerTpnsActivity;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$5;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$5;->a:Landroid/content/Intent;

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s@@~@yl b@u~. @~i@@~@@~ lo     o~b r~S~@ K~~@~ M~/@~~ob~cofiinsm@ -@o ~@~4~a to ~@1f @v@t/ @~d"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    iget-object p2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$5;->a:Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->open_cancel:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo v1, "nosmci"

    const-string v1, "icsona"

    const/4 v3, 0x6

    const-string/jumbo v1, "noacot"

    const-string v1, "action"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-virtual {p2, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x3

    iget-object p2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$5;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$5;->a:Landroid/content/Intent;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-interface {p1}, Landroid/content/DialogInterface;->dismiss()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$5;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-void
.end method
