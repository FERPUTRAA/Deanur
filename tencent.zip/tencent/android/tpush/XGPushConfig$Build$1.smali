.class Lcom/tencent/android/tpush/XGPushConfig$Build$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushConfig$Build;->setLogLevel(I)Lcom/tencent/android/tpush/XGPushConfig$Build;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:I

.field final synthetic b:Lcom/tencent/android/tpush/XGPushConfig$Build;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGPushConfig$Build;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushConfig$Build$1;->b:Lcom/tencent/android/tpush/XGPushConfig$Build;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput p2, p0, Lcom/tencent/android/tpush/XGPushConfig$Build$1;->a:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v0, 0x3

    shr-int/2addr v1, v0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~~s.@oo@~o@@~~~@oK@i@bnbdl@ @s@-~ ~~~t~rf@u  v@i M1@o t~b~ /@c~ /~~@  @4@fo ~   ~yaSim@@  ~~@~ ~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$Build$1;->b:Lcom/tencent/android/tpush/XGPushConfig$Build;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushConfig$Build;->access$000(Lcom/tencent/android/tpush/XGPushConfig$Build;)Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v2, "ednmndglioa.vceh_omctnoltrtsuees,..."

    const-string/jumbo v2, "tvsemonor..a.nleec_tcsngdt.pldheu,oi"

    const/4 v4, 0x7

    const-string v2, ".hptoluteoamddo..e_l.tvenecclno,rnig"

    const-string v2, "com.tencent.android.tpush.log_level,"

    const/4 v4, 0x5

    const/4 v3, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushConfig$Build$1;->b:Lcom/tencent/android/tpush/XGPushConfig$Build;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPushConfig$Build;->access$000(Lcom/tencent/android/tpush/XGPushConfig$Build;)Landroid/content/Context;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget v2, p0, Lcom/tencent/android/tpush/XGPushConfig$Build$1;->a:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v0, v1, v2}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putInt(Landroid/content/Context;Ljava/lang/String;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string v2, "iaorPb.CterXoPm rgiu gp ee.sLhs llsrGhdBoeLvuudtne"

    const-string/jumbo v2, "rLpmPd hionfBuPvsotalgetesirXelhL o.dGe.r s eugrCu"

    const/4 v4, 0x7

    const-string v2, "g rdunuro opfPLeiriluGvthheCeL.gfru eeXsdsB oa.tsP"

    const-string v2, "XGPushConfig.Build.setLogLevel sharedPf put error "

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v1, "nsCGoohuigfP"

    const/4 v4, 0x3

    const-string v1, "fiuPhgGpXCsn"

    const-string v1, "XGPushConfig"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    return-void
.end method
