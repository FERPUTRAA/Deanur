.class public Lcom/tencent/android/tpush/XGPushProvider;
.super Landroid/content/ContentProvider;


# static fields
.field public static AUTH_PRIX:Ljava/lang/String; = ".XGVIP_PUSH_AUTH"

.field public static final TAG:Ljava/lang/String; = "XGPushProvider"

.field private static a:Landroid/content/Context;

.field private static c:Landroid/content/UriMatcher;

.field private static d:I


# instance fields
.field private b:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    new-instance v0, Landroid/content/UriMatcher;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Landroid/content/UriMatcher;-><init>(I)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    sput-object v0, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-direct {p0}, Landroid/content/ContentProvider;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushProvider;->b:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method static synthetic a()Landroid/content/Context;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " os~@ @@~~@  al~@ K~~~t@b~  @1 n~/@mM rvo. o~~~@~@4@of~~ o ~ ~~ @u@iSt y@cb@~@~sdl@@i-/bfi@~~ @o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/tencent/android/tpush/XGPushProvider;->a:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object v0
.end method

.method private b()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    if-nez v0, :cond_0

    sget-object v0, Lcom/tencent/android/tpush/XGPushProvider;->a:Landroid/content/Context;

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushManager;->setContext(Landroid/content/Context;)V

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    if-nez v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/XGPushProvider;->a:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/service/b;->b(Landroid/content/Context;)V

    :cond_1
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-void
.end method

.method private c()V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/content/ContentProvider;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    sput-object v0, Lcom/tencent/android/tpush/XGPushProvider;->a:Landroid/content/Context;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpush/XGPushProvider;->b()V

    const/4 v5, 0x7

    const/4 v4, 0x1

    sget-object v0, Lcom/tencent/android/tpush/XGPushProvider;->a:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushProvider;->fetchProviderAuthorities(Landroid/content/Context;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget-object v0, Lcom/tencent/android/tpush/XGPushProvider;->a:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushProvider;->b:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushProvider;->b:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->AUTH_PRIX:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string/jumbo v2, "n hmi astu"

    const-string v2, "atsunh i i"

    const/4 v5, 0x4

    const-string/jumbo v2, "in hoait u"

    const-string/jumbo v2, "init auth "

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const-string/jumbo v2, "ovemubdXPhisGr"

    const-string v2, "PXGmuirodsrhve"

    const/4 v5, 0x1

    const-string v2, "PXeohiurdrGsvP"

    const-string v2, "XGPushProvider"

    const/4 v4, 0x7

    move v5, v4

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->config:Lcom/tencent/android/tpush/TypeStr;

    const/4 v5, 0x6

    const/4 v4, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->config_all:Lcom/tencent/android/tpush/TypeStr;

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v5, 0x0

    const/4 v4, 0x4

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->msg:Lcom/tencent/android/tpush/TypeStr;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x3

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x5

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->msg_all:Lcom/tencent/android/tpush/TypeStr;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->hearbeat:Lcom/tencent/android/tpush/TypeStr;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x1

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v5, 0x0

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->hearbeat_all:Lcom/tencent/android/tpush/TypeStr;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x5

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->feedback:Lcom/tencent/android/tpush/TypeStr;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->feedback_all:Lcom/tencent/android/tpush/TypeStr;

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->token:Lcom/tencent/android/tpush/TypeStr;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->register:Lcom/tencent/android/tpush/TypeStr;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->insert_mid_new:Lcom/tencent/android/tpush/TypeStr;

    const/4 v5, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->insert_mid_old:Lcom/tencent/android/tpush/TypeStr;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x5

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->pullupxg:Lcom/tencent/android/tpush/TypeStr;

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    sget-object v1, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget-object v2, Lcom/tencent/android/tpush/TypeStr;->hearbeat_cyclecheck:Lcom/tencent/android/tpush/TypeStr;

    const/4 v4, 0x0

    xor-int/2addr v5, v4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/tencent/android/tpush/TypeStr;->getType()I

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v1, v0, v3, v2}, Landroid/content/UriMatcher;->addURI(Ljava/lang/String;Ljava/lang/String;I)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance v1, Lcom/tencent/android/tpush/XGPushProvider$1;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/XGPushProvider$1;-><init>(Lcom/tencent/android/tpush/XGPushProvider;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-void
.end method

.method public static fetchProviderAuthorities(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string/jumbo v0, "sreGidopuoXhvr"

    const-string v0, "esGvoorhXdPrui"

    const/4 v5, 0x4

    const-string/jumbo v0, "ruroeiPdqhvPXs"

    const-string v0, "XGPushProvider"

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    new-instance v2, Landroid/content/ComponentName;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    const-class v3, Lcom/tencent/android/tpush/XGPushProvider;

    const-class v3, Lcom/tencent/android/tpush/XGPushProvider;

    const/4 v5, 0x2

    const-class v3, Lcom/tencent/android/tpush/XGPushProvider;

    const-class v3, Lcom/tencent/android/tpush/XGPushProvider;

    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-virtual {v3}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v2, v1, v3}, Landroid/content/ComponentName;-><init>(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v3, 0x3

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0, v2, v3}, Landroid/content/pm/PackageManager;->getProviderInfo(Landroid/content/ComponentName;I)Landroid/content/pm/ProviderInfo;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v2, p0, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2, v1, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    sput-object v1, Lcom/tencent/android/tpush/XGPushProvider;->AUTH_PRIX:Ljava/lang/String;

    const/4 v5, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string v2, "bms:a"

    const-string v2, "bema:"

    const/4 v5, 0x4

    const-string v2, "anemm"

    const-string/jumbo v2, "name:"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget-object v2, p0, Landroid/content/pm/ProviderInfo;->name:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v2, "o:u otrat,iu"

    const-string/jumbo v2, "uo,r:aut hti"

    const/4 v5, 0x2

    const-string v2, "hoytab:ui ,t"

    const-string v2, ", authority:"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    iget-object p0, p0, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string p0, "PRIXAUTp:H, "

    const/4 v5, 0x7

    const-string p0, "R_P IHu:XTUA"

    const-string p0, ", AUTH_PRIX:"

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    sget-object p0, Lcom/tencent/android/tpush/XGPushProvider;->AUTH_PRIX:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v5, 0x5

    const-string/jumbo v1, "tuouhidp xrtePqftnA ceoiesdpcrothreirve"

    const-string v1, "e xierroqttscetPihopA hdrueudeftrocienv"

    const/4 v5, 0x6

    const-string v1, "icv ureeqeodroePrnuesihteio xtfphdtAfct"

    const-string/jumbo v1, "unexpected for fetchProviderAuthorities"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v5, 0x5

    return-void
.end method

.method public static getProviderAuthority(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x6

    if-eqz p0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x4

    sget-object p0, Lcom/tencent/android/tpush/XGPushProvider;->AUTH_PRIX:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x0

    const-string p0, ""

    const-string p0, ""

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method public static getProviderPid()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    sget v0, Lcom/tencent/android/tpush/XGPushProvider;->d:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    return v0
.end method


# virtual methods
.method public delete(Landroid/net/Uri;Ljava/lang/String;[Ljava/lang/String;)I
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v1, "lesesrduiet"

    const-string v1, "ees ildutre"

    const/4 v3, 0x6

    const-string/jumbo v1, "tl meudier:"

    const-string v1, "delete uri:"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    shr-int/2addr v3, v2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string p1, "etoeomi:c,n"

    const-string p1, "elnm,:ciote"

    const/4 v3, 0x7

    const-string p1, "estcebinl:o"

    const-string p1, ",selection:"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string p1, "Asot,nul:escoei"

    const-string/jumbo p1, "nlesos:oce,gtiA"

    const/4 v3, 0x7

    const-string p1, "crtoieepsAg,lns"

    const-string p1, ",selectionArgs:"

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-static {p3}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x0

    const-string p2, "hduGPbeoqirvXr"

    const-string/jumbo p2, "irrPebGXohPduv"

    const/4 v3, 0x3

    const-string p2, "hdsreouXPirsGv"

    const-string p2, "XGPushProvider"

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 p1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    return p1
.end method

.method public getType(Landroid/net/Uri;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v4, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, p1}, Landroid/content/UriMatcher;->match(Landroid/net/Uri;)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v2, "tuumey :ipre"

    const-string v2, "ey:r uuitpeT"

    const/4 v4, 0x5

    const-string/jumbo v2, "t epoegiT:yu"

    const-string v2, "getType uri:"

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo p1, "mpca,bh"

    const-string/jumbo p1, "pm,htca"

    const/4 v4, 0x5

    const-string/jumbo p1, "tch:amu"

    const-string p1, ",match:"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v1, "iuohqedprsvPXr"

    const-string/jumbo v1, "veXuriGPqhrosd"

    const/4 v4, 0x7

    const-string v1, "iXrPoPdsquevrG"

    const-string v1, "XGPushProvider"

    const/4 v4, 0x7

    const/4 v3, 0x4

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/TypeStr;->getTypeStr(I)Lcom/tencent/android/tpush/TypeStr;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-nez p1, :cond_0

    const/4 v3, 0x3

    move v4, v3

    return-object v0

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x6

    sget-object v2, Lcom/tencent/android/tpush/XGPushProvider$2;->a:[I

    const/4 v3, 0x1

    move v4, v3

    invoke-virtual {p1}, Ljava/lang/Enum;->ordinal()I

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    aget p1, v2, p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    packed-switch p1, :pswitch_data_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-object v0

    :pswitch_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    sget-object p1, Lcom/tencent/android/tpush/XGPushProvider;->a:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/service/cache/CacheManager;->getCurrentAppRegisterEntity(Landroid/content/Context;)Lcom/tencent/android/tpush/data/RegisterEntity;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v2, " rsiitg:ettnsReEgey"

    const-string/jumbo v2, "sesy:tn gRigEtretei"

    const-string/jumbo v2, "yitmeisengtrt gR:tE"

    const-string v2, "get RegisterEntity:"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/data/RegisterEntity;->encode(Lcom/tencent/android/tpush/data/RegisterEntity;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object p1

    :pswitch_1
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x0

    sget-object p1, Lcom/tencent/android/tpush/XGPushProvider;->a:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    return-object p1

    :pswitch_2
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string p1, "ALAToEETABmH_"

    const-string p1, "TETm_RAAEHABL"

    const/4 v4, 0x1

    const-string p1, "RBEA_bLLEHAAT"

    const-string p1, "HEARTBEAT_ALL"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-object p1

    :pswitch_3
    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo p1, "rSr b uoveGadoyvXeiepcrrt t"

    const-string p1, "i cvote rSt orayrvbpeGdreXi"

    const/4 v4, 0x6

    const-string/jumbo p1, "iitbte peerS daXSocyrGrvvr "

    const-string p1, "Start XGService by provider"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    sget-object p1, Lcom/tencent/android/tpush/XGPushProvider;->a:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/service/b;->a(Landroid/content/Context;)V

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x2

    return-object v0

    :pswitch_4
    const/4 v3, 0x0

    const/4 v3, 0x4

    sget-object p1, Lcom/tencent/android/tpush/XGPushProvider;->a:Landroid/content/Context;

    const/4 v3, 0x7

    move v4, v3

    const/4 v1, 0x1

    move v4, v1

    const/4 v3, 0x1

    move v4, v3

    invoke-static {p1, v1}, Lcom/tencent/android/tpush/service/util/c;->a(Landroid/content/Context;Z)V

    :pswitch_5
    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object p1, Lcom/tencent/android/tpush/XGPushProvider;->a:Landroid/content/Context;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/message/e;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/message/e;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, v1}, Lcom/tencent/android/tpush/message/e;->a(Z)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object v0

    :pswitch_6
    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string p1, "NLCGFb_OqA"

    const-string p1, "COALIbG_FN"

    const/4 v4, 0x1

    const-string p1, "_CsLLIANOG"

    const-string p1, "CONFIG_ALL"

    const/4 v4, 0x3

    const/4 v3, 0x2

    return-object p1

    :pswitch_7
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo p1, "uCImNG"

    const-string/jumbo p1, "uNIFGC"

    const/4 v4, 0x6

    const-string p1, "GNOCoI"

    const-string p1, "CONFIG"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object p1

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_7
        :pswitch_6
        :pswitch_4
        :pswitch_5
        :pswitch_3
        :pswitch_2
        :pswitch_1
        :pswitch_0
    .end packed-switch
.end method

.method public insert(Landroid/net/Uri;Landroid/content/ContentValues;)Landroid/net/Uri;
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    sget-object v0, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v0, p1}, Landroid/content/UriMatcher;->match(Landroid/net/Uri;)I

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/TypeStr;->getTypeStr(I)Lcom/tencent/android/tpush/TypeStr;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-nez v1, :cond_0

    const/4 v6, 0x6

    or-int/2addr v7, v6

    return-object v2

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v4, " rtnubipi:r"

    const-string v4, " t:nuiiprre"

    const/4 v7, 0x2

    const-string/jumbo v4, "insert uri:"

    const/4 v7, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string p1, "aqmt:hu"

    const-string p1, "aqm:htc"

    const/4 v7, 0x1

    const-string/jumbo p1, "pamh:t,"

    const-string p1, ",match:"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string/jumbo p1, "qua:lsvs"

    const-string/jumbo p1, "vusl:sae"

    const/4 v7, 0x0

    const-string p1, ",:sasveu"

    const-string p1, ",values:"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string/jumbo v0, "uPdmhroesXPimv"

    const-string v0, "heumPoirrdPXvs"

    const/4 v7, 0x5

    const-string/jumbo v0, "rXrvooPePisGuh"

    const-string v0, "XGPushProvider"

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x1

    sget-object p1, Lcom/tencent/android/tpush/XGPushProvider$2;->a:[I

    const/4 v6, 0x5

    shl-int/2addr v7, v6

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result v1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    aget p1, p1, v1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    const/16 v1, 0x9

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eq p1, v1, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    return-object v2

    :cond_1
    :try_start_0
    const/4 v6, 0x1

    move v7, v6

    const-string/jumbo p1, "kye"

    const-string/jumbo p1, "kye"

    const/4 v7, 0x3

    const-string/jumbo p1, "key"

    const-string/jumbo p1, "key"

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p2, p1}, Landroid/content/ContentValues;->getAsString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    if-nez p1, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string p1, " lekybnliso"

    const-string/jumbo p1, "yulnoieks l"

    const/4 v7, 0x6

    const-string/jumbo p1, "ls yueuk nl"

    const-string/jumbo p1, "key is null"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    return-object v2

    :cond_2
    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 p2, 0x0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {p1, p2}, Landroid/content/Intent;->parseUri(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v1, "dt.BntRpLWAcryBaneo.iOSeargtEbnoi"

    const-string v1, "enRyAbgiratrtLWnBcaEdtoSdioOeB.n."

    const/4 v7, 0x4

    const-string/jumbo v1, "noRAdEaWqd.LrcBaOy.Set.ietoriBgtn"

    const-string v1, "android.intent.category.BROWSABLE"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {p1, v1}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1, v2}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;
    :try_end_0
    .catch Ljava/net/URISyntaxException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    const/4 v1, 0x1

    :try_start_1
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    new-array v3, v1, [Ljava/lang/Class;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const-class v4, Landroid/content/Intent;

    const-class v4, Landroid/content/Intent;

    const/4 v7, 0x3

    const-class v4, Landroid/content/Intent;

    const-class v4, Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    aput-object v4, v3, p2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string/jumbo v5, "ocerStusetl"

    const/4 v7, 0x4

    const-string/jumbo v5, "tcseseeroSt"

    const-string/jumbo v5, "setSelector"

    const/4 v7, 0x6

    const/4 v6, 0x0

    invoke-virtual {v4, v5, v3}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-array v1, v1, [Ljava/lang/Object;

    const/4 v6, 0x6

    move v7, v6

    aput-object v2, v1, p2

    const/4 v7, 0x3

    invoke-virtual {v3, p1, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x0

    const/4 v7, 0x7

    goto :goto_0

    :catchall_0
    move-exception p2

    :try_start_2
    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string/jumbo v1, "n.omkitn vem Ceon.tsrrinoneoerepp"

    const-string/jumbo v1, "nek.s npim.noe eorneipnreCotrttvo"

    const/4 v7, 0x3

    const-string/jumbo v1, "neototnrntkn  tinreroeo.ivsp.eCeo"

    const-string/jumbo v1, "invoke intent.setComponent error."

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v0, v1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    sget-object p2, Lcom/tencent/android/tpush/XGPushProvider;->a:Landroid/content/Context;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-static {p2}, Lcom/tencent/android/tpush/message/e;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/message/e;

    move-result-object p2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p2, p1}, Lcom/tencent/android/tpush/message/e;->b(Landroid/content/Intent;)V
    :try_end_2
    .catch Ljava/net/URISyntaxException; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto :goto_1

    :catch_0
    move-exception p1

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x6

    return-object v2
.end method

.method public onCreate()Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo v0, "vqXPubdorPriGe"

    const-string v0, "ehruPXiGqodrvP"

    const/4 v3, 0x7

    const-string/jumbo v0, "vhXPGouesiurPd"

    const-string v0, "XGPushProvider"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string v1, "hrXePnep atvuisoPeorrGd"

    const-string v1, "XGPushProvider onCreate"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    sput v0, Lcom/tencent/android/tpush/XGPushProvider;->d:I

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0}, Lcom/tencent/android/tpush/XGPushProvider;->c()V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    return v0
.end method

.method public query(Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v1, "iqurur :qe"

    const-string/jumbo v1, "query uri:"

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const-string/jumbo p1, "resso,o:inpc"

    const-string/jumbo p1, "opstroi,en:c"

    const/4 v3, 0x5

    const-string/jumbo p1, "itompceo,:jr"

    const-string p1, ",projection:"

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p2}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    const-string/jumbo p1, "m,ino:otsle"

    const-string p1, "c:emolinst,"

    const/4 v3, 0x2

    const-string p1, ":tneobec,si"

    const-string p1, ",selection:"

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string/jumbo p1, "ssn,ooectA:giel"

    const/4 v3, 0x1

    const-string p1, "A:,sonuctisegel"

    const-string p1, ",selectionArgs:"

    const/4 v2, 0x3

    move v3, v2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p4}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo p1, "seOrdorptr:"

    const-string p1, ",sortOrder:"

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    invoke-virtual {v0, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const-string/jumbo p2, "sPeovXhrqPbrGu"

    const-string/jumbo p2, "orPPebGsvhuirX"

    const/4 v3, 0x6

    const-string p2, "GisurdvXoehPrs"

    const-string p2, "XGPushProvider"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 p1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-object p1
.end method

.method public update(Landroid/net/Uri;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I
    .locals 7

    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x4

    sget-object v0, Lcom/tencent/android/tpush/XGPushProvider;->c:Landroid/content/UriMatcher;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v0, p1}, Landroid/content/UriMatcher;->match(Landroid/net/Uri;)I

    move-result v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/TypeStr;->getTypeStr(I)Lcom/tencent/android/tpush/TypeStr;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    const/4 v2, 0x0

    const/4 v6, 0x4

    if-nez v1, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x0

    return v2

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    const-string v4, ":iame rupdu"

    const-string v4, "ei rudup:au"

    const/4 v6, 0x2

    const-string v4, "au roiuet:d"

    const-string/jumbo v4, "update uri:"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const-string p1, "apve:bls"

    const-string p1, ":avse,lp"

    const/4 v6, 0x4

    const-string p1, ":ulaseuv"

    const-string p1, ",values:"

    const/4 v6, 0x0

    const/4 v5, 0x2

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string p1, ",:tielepqco"

    const-string p1, ":cot,islqee"

    const/4 v6, 0x4

    const-string/jumbo p1, "sec,t:elqin"

    const-string p1, ",selection:"

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-virtual {v3, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    const-string/jumbo p1, "trsnlgs:e,essoA"

    const-string p1, "eAstrns,s:gloec"

    const/4 v6, 0x5

    const-string p1, ":n,meAcrsslotig"

    const-string p1, ",selectionArgs:"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p4}, Ljava/util/Arrays;->toString([Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string p1, "c,mtoam"

    const-string p1, "a:tm,cm"

    const/4 v6, 0x2

    const-string p1, ",:tambh"

    const-string p1, ",match:"

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string/jumbo p3, "resoPiuouvdhrX"

    const-string p3, "hPsPoorrXeuivd"

    const/4 v6, 0x6

    const-string/jumbo p3, "rhXiePPprGsudo"

    const-string p3, "XGPushProvider"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {p3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    sget-object p1, Lcom/tencent/android/tpush/XGPushProvider$2;->a:[I

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/Enum;->ordinal()I

    move-result p4

    const/4 v5, 0x5

    move v6, v5

    aget p1, p1, p4

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    const/16 p4, 0xb

    const/4 v5, 0x0

    move v6, v5

    if-eq p1, p4, :cond_1

    const/4 v6, 0x3

    return v2

    :cond_1
    const/4 v6, 0x0

    const-string/jumbo p1, "qbceafbd"

    const-string p1, "ecfdebab"

    const/4 v6, 0x1

    const-string p1, "feedback"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {p2, p1}, Landroid/content/ContentValues;->getAsString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x4

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x0

    const-string p4, ":ksufbcea"

    const-string p4, "fkb cau:e"

    const/4 v6, 0x0

    const-string p4, "fecme k:b"

    const-string p4, "feeback: "

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {p2, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {p3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    return v2
.end method
