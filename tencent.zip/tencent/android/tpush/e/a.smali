.class public Lcom/tencent/android/tpush/e/a;
.super Ljava/lang/Object;


# static fields
.field private static a:J = 0x0L

.field private static b:J = 0xa4cb800L

.field private static c:Lcom/tencent/android/tpush/e/a/a;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-void
.end method

.method public static a(Landroid/content/Context;)Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "K s ~f. o@ f o@@@oo@o@~@ll@y~/ ~nbi@  @@  -@~~~~@v S ~c ~~M~~a ~i4@~d @is@@~~@o~~b/~mrtu~@ b1 t~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    const-string v0, "enfmranaIaoseMgeMg"

    const-string v0, "gesnMeIfgneoMsaraa"

    const/4 v5, 0x0

    const-string v0, "aMgMoIersenofnaase"

    const-string v0, "MessageInfoManager"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v1, 0x0

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/e/a;->d(Landroid/content/Context;)Lcom/tencent/android/tpush/e/a/a;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string/jumbo v2, "ssagmbmhwosee"

    const-string/jumbo v2, "tegmaemssowsh"

    const/4 v5, 0x6

    const-string/jumbo v2, "metahsugwssoe"

    const-string/jumbo v2, "messagetoshow"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p0, v2, v3, v3}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    if-gtz v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string/jumbo v2, "leelc bp est asnssodgu aamoeAhMidgg nbl"

    const-string v2, "a enoo gdMnsleAahlsCclig eau dsg temsbb"

    const/4 v5, 0x1

    const-string v2, "gugsgd bq   ea iseecsltmoMlAnbsleaehCda"

    const-string v2, "delAllCacheMessage but no mssgage in db"

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    move v2, v1

    move v2, v1

    const/4 v5, 0x6

    move v2, v1

    move v2, v1

    const/4 v4, 0x3

    shl-int/2addr v5, v4

    goto :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v5, 0x0

    const/4 v2, 0x1

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteClosable;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    return v2

    :catchall_0
    move-exception p0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string/jumbo v3, "orseCEh!ealsM gsleaAerdrbc"

    const-string v3, "g leMbcAerslehdlsar!ECraeo"

    const/4 v5, 0x1

    const-string/jumbo v3, "rermcaslgd le!ACosa rMeelE"

    const-string v3, "delAllCacheMessage Error! "

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    return v1
.end method

.method public static a(Landroid/content/Context;J)Z
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/e/a;->e(Landroid/content/Context;)Z

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x4

    const/4 v0, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p0, p1, p2, v0}, Lcom/tencent/android/tpush/e/a;->a(Landroid/content/Context;JI)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    return p0
.end method

.method private static a(Landroid/content/Context;JI)Z
    .locals 11

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string v0, "MMugoseeraIoanfaeg"

    const-string v0, "MaMfaaunneseIrgoge"

    const/4 v10, 0x7

    const-string v0, "MrsegbeseaaoagIfMn"

    const-string v0, "MessageInfoManager"

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    new-instance v1, Landroid/content/ContentValues;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-direct {v1}, Landroid/content/ContentValues;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    const/4 v2, 0x1

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eq p3, v2, :cond_0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x4

    const/4 v3, 0x2

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x4

    if-ne p3, v3, :cond_1

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-static {v3, v4}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v3

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    const-string v4, "eoimtsudwh"

    const-string/jumbo v4, "showedtime"

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-virtual {v1, v4, v3}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-string/jumbo v3, "tpsutp"

    const-string/jumbo v3, "uptsst"

    const/4 v10, 0x2

    const-string/jumbo v3, "taqssu"

    const-string/jumbo v3, "status"

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-static {p3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v1, v3, v4}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v3, 0x0

    shr-int/2addr v10, v3

    :try_start_0
    const/4 v9, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/e/a;->d(Landroid/content/Context;)Lcom/tencent/android/tpush/e/a/a;

    move-result-object p0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-string/jumbo v4, "sosesmswoqehg"

    const-string/jumbo v4, "owssaesoqghem"

    const/4 v10, 0x1

    const-string/jumbo v4, "omgmhseasoewt"

    const-string/jumbo v4, "messagetoshow"

    const/4 v10, 0x0

    const-string/jumbo v5, "sg?=omi"

    const-string v5, "gss?mi="

    const/4 v10, 0x3

    const-string v5, "=idm?bs"

    const-string/jumbo v5, "msgid=?"

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x0

    new-array v6, v2, [Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {v7, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    const-string v8, ""

    const/4 v10, 0x1

    const-string v8, ""

    const-string v8, ""

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    aput-object v7, v6, v3

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x2

    invoke-virtual {p0, v4, v1, v5, v6}, Landroid/database/sqlite/SQLiteDatabase;->update(Ljava/lang/String;Landroid/content/ContentValues;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v1

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    int-to-long v4, v1

    const/4 v10, 0x6

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v10, 0x0

    const-wide/16 v6, 0x0

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x6

    cmp-long v1, v4, v6

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    if-gtz v1, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    const-string v2, "e:aos uCsEuadgtm!racrmersdhgMpeI"

    const-string v2, "csameeEsrCe dsdpurrtoMhma!gga:Ie"

    const/4 v10, 0x5

    const-string v2, " :erIarphra dpedCcmseeuagssgE!Mt"

    const-string/jumbo v2, "updateCacheMessage Error! msgId:"

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    move v10, v9

    invoke-virtual {v1, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-string/jumbo p1, "u:atot, q"

    const-string p1, ", u:ottsa"

    const-string p1, ",ts sutsa"

    const-string p1, ", status:"

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    move v2, v3

    move v2, v3

    move v2, v3

    move v2, v3

    :cond_2
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteClosable;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x3

    return v2

    :catchall_0
    move-exception p0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-string p2, "gs!robr eCtecspeae udMarEh"

    const/4 v10, 0x3

    const-string p2, "eermp a !tEessduraoegMcrCa"

    const-string/jumbo p2, "updateCacheMessage Error! "

    const/4 v10, 0x4

    const/4 v9, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x7

    return v3
.end method

.method public static a(Landroid/content/Context;Landroid/content/Intent;)Z
    .locals 10

    const/4 v9, 0x5

    const-string v0, "ergfouMasMnaesgnIa"

    const-string v0, "grIaMauneMgassfeen"

    const/4 v9, 0x0

    const-string v0, "gMegsbIeMfaeraosan"

    const-string v0, "MessageInfoManager"

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string v1, "dugpI"

    const-string v1, "gspId"

    const/4 v9, 0x2

    const-string/jumbo v1, "mdpsI"

    const-string/jumbo v1, "msgId"

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v9, 0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p1, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    new-instance v3, Landroid/content/ContentValues;

    const/4 v9, 0x7

    invoke-direct {v3}, Landroid/content/ContentValues;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-string/jumbo v4, "qsdqg"

    const-string/jumbo v4, "msdqg"

    const/4 v9, 0x3

    const-string v4, "disms"

    const-string/jumbo v4, "msgid"

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-virtual {v3, v4, v1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v1, 0x1

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {p1, v1}, Landroid/content/Intent;->toUri(I)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x0

    invoke-static {v2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    const-string/jumbo v4, "smemegs"

    const-string v4, "eessagm"

    const/4 v9, 0x2

    const-string v4, "esagoem"

    const-string/jumbo v4, "message"

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {v3, v4, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v8, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/g;->b(Landroid/content/Intent;)J

    move-result-wide v4

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string v4, "eitm"

    const-string/jumbo v4, "teim"

    const/4 v9, 0x7

    const-string/jumbo v4, "ietm"

    const-string/jumbo v4, "time"

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v3, v4, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string v2, "dbIMubims"

    const-string/jumbo v2, "sdumisMbI"

    const/4 v9, 0x5

    const-string v2, "dMbgIsuis"

    const-string v2, "busiMsgId"

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x1

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x6

    const/4 v8, 0x2

    invoke-virtual {p1, v2, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v9, 0x5

    const/4 v8, 0x2

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-string/jumbo v2, "ipsbdu"

    const-string/jumbo v2, "uibsod"

    const/4 v9, 0x1

    const-string/jumbo v2, "udqibs"

    const-string v2, "busiid"

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v3, v2, p1}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Long;)V

    const/4 p1, 0x0

    const/4 v9, 0x0

    move v8, p1

    move v8, p1

    const/4 v9, 0x5

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string v6, "ebsmseodti"

    const-string v6, "eioetbshmd"

    const/4 v9, 0x4

    const-string v6, "dhsmotieew"

    const-string/jumbo v6, "showedtime"

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v3, v6, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    const/4 v9, 0x0

    const-string/jumbo v6, "uutaos"

    const-string/jumbo v6, "utauts"

    const/4 v9, 0x5

    const-string v6, "asttsb"

    const-string/jumbo v6, "status"

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v3, v6, v2}, Landroid/content/ContentValues;->put(Ljava/lang/String;Ljava/lang/Integer;)V

    :try_start_0
    const/4 v8, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/e/a;->d(Landroid/content/Context;)Lcom/tencent/android/tpush/e/a/a;

    move-result-object p0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string/jumbo v2, "sswtgeupsamoe"

    const-string/jumbo v2, "sesaoegpmwsot"

    const/4 v9, 0x2

    const-string v2, "eastsgepowhsm"

    const-string/jumbo v2, "messagetoshow"

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    const/4 v6, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-virtual {p0, v2, v6, v3}, Landroid/database/sqlite/SQLiteDatabase;->insert(Ljava/lang/String;Ljava/lang/String;Landroid/content/ContentValues;)J

    move-result-wide v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    cmp-long v2, v2, v4

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-gtz v2, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string v1, "d!sMrcr qeeaq goeEdhCrs"

    const-string/jumbo v1, "srsrMcrdqoaeg!hC  edaeE"

    const/4 v9, 0x3

    const-string v1, "ahsE edoMcears gsC!erda"

    const-string v1, "addCacheMessage Error! "

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    move v1, p1

    move v1, p1

    const/4 v9, 0x5

    move v1, p1

    move v1, p1

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteClosable;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x3

    const/4 v8, 0x7

    return v1

    :catchall_0
    move-exception p0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string/jumbo v2, "sc ms gMeeeahwdraora!drECs"

    const-string v2, "desoswsraNaech ra!dErMCg e"

    const/4 v9, 0x1

    const-string v2, "addNewCacheMessage Error! "

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x7

    return p1
.end method

.method public static b(Landroid/content/Context;)Z
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string/jumbo v0, "r dIoaeteensMCtlhtcl!gonelcrAmolELr "

    const-string/jumbo v0, "lenmAsg!hrtMltco erE eoLlaICtlrendec"

    const/4 v7, 0x4

    const-string v0, "d leabronnceAcrsLlI CteElatrethMeo!l"

    const-string v0, "deleteAllLocalCacheMsgIntent Error! "

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v1, "aMIgaeusenMrgfanso"

    const-string v1, "fneeoasMIgrganMosa"

    const/4 v7, 0x5

    const-string v1, "gnosraMpIaasegfMee"

    const-string v1, "MessageInfoManager"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    const/4 v2, 0x0

    :try_start_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/e/a;->d(Landroid/content/Context;)Lcom/tencent/android/tpush/e/a/a;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    const-string/jumbo v3, "msobaetgqohsw"

    const-string v3, "esaesbogtohmw"

    const/4 v7, 0x5

    const-string/jumbo v3, "tgssswmeoahso"

    const-string/jumbo v3, "messagetoshow"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string v4, "0s md i<m"

    const-string v4, "d ims0u <"

    const-string v4, "dm 0osi< "

    const-string/jumbo v4, "msgid < 0"

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x0

    const/4 v5, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {p0, v3, v4, v5}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    if-gtz v3, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    move v3, v2

    move v3, v2

    const/4 v7, 0x2

    move v3, v2

    move v3, v2

    const/4 v7, 0x3

    const/4 v6, 0x3

    goto :goto_0

    :cond_0
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v3, 0x1

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteClosable;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    return v3

    :catchall_0
    move-exception p0

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    move v7, v6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x2

    return v2
.end method

.method public static b(Landroid/content/Context;J)Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/e/a;->e(Landroid/content/Context;)Z

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x0

    const/4 v0, 0x2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-static {p0, p1, p2, v0}, Lcom/tencent/android/tpush/e/a;->a(Landroid/content/Context;JI)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    return p0
.end method

.method public static c(Landroid/content/Context;)Ljava/util/ArrayList;
    .locals 14
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/ArrayList<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x7

    const-string/jumbo v0, "pafMMboagIgeeansrs"

    const-string/jumbo v0, "ofeMgrapsaeManIsgn"

    const/4 v13, 0x3

    const-string/jumbo v0, "nneofauraseeMsMIga"

    const-string v0, "MessageInfoManager"

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x7

    new-instance v1, Ljava/util/ArrayList;

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x1

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    :try_start_0
    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/e/a;->d(Landroid/content/Context;)Lcom/tencent/android/tpush/e/a/a;

    move-result-object p0

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x1

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x7

    new-instance v2, Landroid/database/sqlite/SQLiteQueryBuilder;

    const/4 v13, 0x7

    const/4 v12, 0x0

    const/4 v13, 0x5

    invoke-direct {v2}, Landroid/database/sqlite/SQLiteQueryBuilder;-><init>()V

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x2

    const-string/jumbo v3, "wsheasogqomts"

    const/4 v13, 0x5

    const-string/jumbo v3, "meowgstpaeohs"

    const-string/jumbo v3, "messagetoshow"

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x3

    invoke-virtual {v2, v3}, Landroid/database/sqlite/SQLiteQueryBuilder;->setTables(Ljava/lang/String;)V

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x7

    const/4 v10, 0x1

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x5

    new-array v4, v10, [Ljava/lang/String;

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x6

    const-string v3, "aqsmges"

    const-string/jumbo v3, "message"

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x5

    const/4 v11, 0x0

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x2

    aput-object v3, v4, v11

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x0

    const-string/jumbo v5, "utssts=a"

    const-string/jumbo v5, "status=0"

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x0

    const/4 v6, 0x0

    const/4 v13, 0x6

    const/4 v12, 0x6

    const/4 v13, 0x1

    const/4 v7, 0x0

    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x7

    const/4 v8, 0x0

    const/4 v13, 0x6

    const/4 v9, 0x0

    const/4 v13, 0x5

    shr-int/2addr v12, v9

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    const/4 v12, 0x0

    const/4 v13, 0x6

    invoke-virtual/range {v2 .. v9}, Landroid/database/sqlite/SQLiteQueryBuilder;->query(Landroid/database/sqlite/SQLiteDatabase;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object v2

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x3

    if-eqz v2, :cond_1

    :goto_0
    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x6

    invoke-interface {v2}, Landroid/database/Cursor;->moveToNext()Z

    move-result v3
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x1

    if-eqz v3, :cond_0

    :try_start_1
    const/4 v13, 0x6

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-interface {v2, v11}, Landroid/database/Cursor;->getString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x4

    invoke-static {v3}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x1

    invoke-static {v3, v10}, Landroid/content/Intent;->parseUri(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object v3

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x7

    const-string v4, "gySmL.Bie.naitactnEWO.onrBdetrdRA"

    const-string/jumbo v4, "rasoanidLyB.AntSeintceREgrB.Wtd.O"

    const/4 v13, 0x5

    const-string v4, "OeiBoR.EtigdBAeoa.dayWocrtnt.SrLn"

    const-string v4, "android.intent.category.BROWSABLE"

    const/4 v13, 0x5

    const/4 v12, 0x0

    invoke-virtual {v3, v4}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x6

    const/4 v4, 0x0

    const/4 v13, 0x7

    invoke-virtual {v3, v4}, Landroid/content/Intent;->setComponent(Landroid/content/ComponentName;)Landroid/content/Intent;
    :try_end_1
    .catch Ljava/net/URISyntaxException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :try_start_2
    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x1

    new-array v5, v10, [Ljava/lang/Class;

    const/4 v12, 0x6

    move v13, v12

    const-class v6, Landroid/content/Intent;

    const-class v6, Landroid/content/Intent;

    const/4 v13, 0x1

    const-class v6, Landroid/content/Intent;

    const-class v6, Landroid/content/Intent;

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x2

    aput-object v6, v5, v11

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x1

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v6

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x7

    const-string/jumbo v7, "teeteboSrlc"

    const-string/jumbo v7, "setSelector"

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-virtual {v6, v7, v5}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    const/4 v13, 0x6

    const/4 v12, 0x3

    const/4 v13, 0x4

    new-array v6, v10, [Ljava/lang/Object;

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x5

    aput-object v4, v6, v11

    const/4 v12, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x1

    invoke-virtual {v5, v3, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x7

    goto :goto_1

    :catchall_0
    move-exception v4

    :try_start_3
    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x0

    const-string/jumbo v5, "ms em unnnrtontooCrtv.riteee.eiko"

    const-string/jumbo v5, "ttemiroevo.eni  oCnmr.ttkoerenpns"

    const/4 v13, 0x5

    const-string/jumbo v5, "oneivneprk.roeospntt iemetnCnt or"

    const-string/jumbo v5, "invoke intent.setComponent error."

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x6

    invoke-static {v0, v5, v4}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_1
    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z
    :try_end_3
    .catch Ljava/net/URISyntaxException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v13, 0x4

    const/4 v12, 0x6

    const/4 v13, 0x6

    goto/16 :goto_0

    :catch_0
    move-exception v3

    :try_start_4
    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x0

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x7

    const-string/jumbo v5, "oeceeCrsqratsrehso:  MgE"

    const-string/jumbo v5, "tsEMoe:geraeoeac rr hsCs"

    const/4 v13, 0x6

    const-string/jumbo v5, "sEsahsoerecCee  M:rtgars"

    const-string v5, "getCacheMessages Error: "

    const/4 v13, 0x6

    const/4 v12, 0x1

    const/4 v13, 0x3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x5

    invoke-static {v0, v3}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x2

    xor-int/2addr v13, v12

    goto/16 :goto_0

    :cond_0
    invoke-interface {v2}, Landroid/database/Cursor;->close()V

    :cond_1
    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x1

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteClosable;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v13, 0x3

    goto :goto_2

    :catchall_1
    move-exception p0

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x5

    const-string v3, " wNmerM!hssbae cegCtrsEaeoe"

    const-string/jumbo v3, "ws stbNeera!gcsoCgE Mareehe"

    const/4 v13, 0x4

    const-string/jumbo v3, "owgeoENss a egraechMs!reCte"

    const-string v3, "getNewCacheMessages Error! "

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_2
    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x7

    return-object v1
.end method

.method public static c(Landroid/content/Context;J)Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v0, 0x3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-static {p0, p1, p2, v0}, Lcom/tencent/android/tpush/e/a;->a(Landroid/content/Context;JI)Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return p0
.end method

.method private static d(Landroid/content/Context;)Lcom/tencent/android/tpush/e/a/a;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/android/tpush/e/a;->c:Lcom/tencent/android/tpush/e/a/a;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-nez v0, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const-class v0, Lcom/tencent/android/tpush/e/a;

    const-class v0, Lcom/tencent/android/tpush/e/a;

    const/4 v3, 0x6

    const-class v0, Lcom/tencent/android/tpush/e/a;

    const-class v0, Lcom/tencent/android/tpush/e/a;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    sget-object v1, Lcom/tencent/android/tpush/e/a;->c:Lcom/tencent/android/tpush/e/a/a;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/e/a/a;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/e/a/a;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x6

    sput-object v1, Lcom/tencent/android/tpush/e/a;->c:Lcom/tencent/android/tpush/e/a/a;

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    monitor-exit v0

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x2

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    sget-object p0, Lcom/tencent/android/tpush/e/a;->c:Lcom/tencent/android/tpush/e/a/a;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-object p0
.end method

.method public static d(Landroid/content/Context;J)Z
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x4

    move v2, v0

    invoke-static {p0, p1, p2, v0}, Lcom/tencent/android/tpush/e/a;->a(Landroid/content/Context;JI)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    return p0
.end method

.method private static e(Landroid/content/Context;)Z
    .locals 12

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x2

    const-string v0, "IeasobgrfeeauMangM"

    const-string/jumbo v0, "nsaMgruoefIsegaeMa"

    const/4 v11, 0x2

    const-string v0, "gfMIseuaMgoneasren"

    const-string v0, "MessageInfoManager"

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x7

    sget-wide v3, Lcom/tencent/android/tpush/e/a;->a:J

    const/4 v10, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v11, 0x2

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x4

    cmp-long v5, v3, v5

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x7

    const/4 v6, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-eqz v5, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x4

    sub-long v3, v1, v3

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-wide/32 v7, 0x5265c00

    const-wide/32 v7, 0x5265c00

    const/4 v11, 0x0

    const-wide/32 v7, 0x5265c00

    const-wide/32 v7, 0x5265c00

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x0

    cmp-long v3, v3, v7

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x5

    if-lez v3, :cond_2

    :cond_0
    const/4 v11, 0x1

    const/4 v10, 0x7

    sput-wide v1, Lcom/tencent/android/tpush/e/a;->a:J

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x1

    sget-wide v3, Lcom/tencent/android/tpush/e/a;->b:J

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x3

    sub-long/2addr v1, v3

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    const/4 v3, 0x0

    :try_start_0
    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/e/a;->d(Landroid/content/Context;)Lcom/tencent/android/tpush/e/a/a;

    move-result-object p0

    const/4 v11, 0x6

    const/4 v10, 0x4

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x1

    const-string v4, "hmpoesgpwaoes"

    const-string/jumbo v4, "mehgaewpoosss"

    const/4 v11, 0x6

    const-string v4, "hwoesoegqasts"

    const-string/jumbo v4, "messagetoshow"

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-string v5, ">wsee q?  <=os   tDs? AuhsNttai"

    const-string/jumbo v5, "sesui?o>q  Dt wt dst?A  Na e=<h"

    const/4 v11, 0x1

    const-string v5, "=d metss DAt u?e<  >Nmw ?aihs t"

    const-string/jumbo v5, "status >= ? AND showedtime < ? "

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    const/4 v7, 0x2

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    new-array v7, v7, [Ljava/lang/String;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    const-string v8, "1"

    const-string v8, "1"

    const/4 v11, 0x7

    const-string v8, "1"

    const-string v8, "1"

    const/4 v11, 0x1

    const/4 v10, 0x0

    aput-object v8, v7, v3

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x1

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {v8, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x5

    const-string v9, ""

    const-string v9, ""

    const/4 v11, 0x1

    const-string v9, ""

    const-string v9, ""

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x1

    aput-object v8, v7, v6

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {p0, v4, v5, v7}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v4

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    if-gtz v4, :cond_1

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x3

    const-string v5, "demoorsOigeDo eCseelMal asdhEreocrw:lT he!d"

    const-string/jumbo v5, "lDsaed dTlo:awrtseoeeheecosilmhdreC!rE  MOg"

    const/4 v11, 0x7

    const-string v5, "SEhwtbremoreTgdsdaDre ahil eeso!ldOl:ec oeM"

    const-string v5, "delOldShowedCacheMessage Error! toDelTime: "

    const/4 v11, 0x4

    const/4 v10, 0x3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v4, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    move v6, v3

    move v6, v3

    const/4 v11, 0x3

    move v6, v3

    move v6, v3

    :cond_1
    const/4 v10, 0x4

    const/4 v11, 0x2

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteClosable;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x2

    return v6

    :catchall_0
    move-exception p0

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x7

    const-string/jumbo v2, "woMhecude CErSeldge aOdoems!rhlr"

    const-string v2, "d gms loCeOd!sehwhroaeEecSMrlder"

    const/4 v11, 0x4

    const-string v2, "e!esrdMpdldgawEhoeoOSralsh erec "

    const-string v2, "delOldShowedCacheMessage Error! "

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x6

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    return v3
.end method

.method public static e(Landroid/content/Context;J)Z
    .locals 12

    const/4 v11, 0x6

    const-string/jumbo v0, "roereteiqha  ads! loEeege :CorsdMlgdem t"

    const-string v0, "iaecorggsdoEsr!taeee Cletrdmhde e  : loM"

    const/4 v11, 0x1

    const-string v0, " gsldaiertstCd ae seegErme:!sdheoloM c r"

    const-string v0, "delCacheMessage Error! msgid to delete: "

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    const-string v1, "begm lo MuoC rrohs eaen retsecferapdbedsedcecx"

    const-string/jumbo v1, "uer lberrcdes efp,eroCseean eetxcgbMddahscoo  "

    const/4 v11, 0x0

    const-string/jumbo v1, "xrh oredrag,dedCp eecat leerne cs osuoeolescfb"

    const-string/jumbo v1, "unexpected for delCacheMessage, db close error"

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-string/jumbo v2, "oraeubfeMagseganns"

    const-string/jumbo v2, "naeeaMufeogMsgnrsa"

    const/4 v11, 0x0

    const-string/jumbo v2, "onerMfueaIaaesggsM"

    const-string v2, "MessageInfoManager"

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x5

    const/4 v3, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x1

    const/4 v4, 0x0

    :try_start_0
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/e/a;->d(Landroid/content/Context;)Lcom/tencent/android/tpush/e/a/a;

    move-result-object p0

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object v4

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    const-string p0, "eshtsmeppwogs"

    const-string/jumbo p0, "mohsaegpwtsse"

    const-string/jumbo p0, "messagetoshow"

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    const-string v5, "=q?igdq"

    const-string/jumbo v5, "iq=?dmg"

    const/4 v11, 0x2

    const-string/jumbo v5, "mss=?id"

    const-string/jumbo v5, "msgid=?"

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    const/4 v6, 0x1

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    new-array v7, v6, [Ljava/lang/String;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x6

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {v8, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-string v9, ""

    const/4 v11, 0x3

    const-string v9, ""

    const-string v9, ""

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x1

    aput-object v8, v7, v3

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {v4, p0, v5, v7}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result p0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    if-gtz p0, :cond_0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x1

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {p0, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x1

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x1

    const/4 v10, 0x3

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {v4}, Landroid/database/sqlite/SQLiteClosable;->close()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    goto :goto_0

    :catchall_0
    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x1

    return v3

    :cond_0
    :try_start_2
    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v4}, Landroid/database/sqlite/SQLiteClosable;->close()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x7

    goto :goto_1

    :catchall_1
    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x5

    return v6

    :catchall_2
    move-exception p0

    :try_start_3
    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x6

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    move v11, v10

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    invoke-virtual {v5, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {v5, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_4

    const/4 v11, 0x3

    const/4 v10, 0x3

    if-eqz v4, :cond_1

    :try_start_4
    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-virtual {v4}, Landroid/database/sqlite/SQLiteClosable;->close()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_3

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x3

    goto :goto_2

    :catchall_3
    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_2
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    return v3

    :catchall_4
    move-exception p0

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-eqz v4, :cond_2

    :try_start_5
    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-virtual {v4}, Landroid/database/sqlite/SQLiteClosable;->close()V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    const/4 v11, 0x2

    const/4 v10, 0x2

    goto :goto_3

    :catchall_5
    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_3
    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    throw p0
.end method

.method public static f(Landroid/content/Context;J)Z
    .locals 10

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-string/jumbo v0, "resmfIaeMansMgsega"

    const-string v0, "MasraseIegnegsMafn"

    const-string v0, "esIeoMgneMaaargnof"

    const-string v0, "MessageInfoManager"

    const/4 v8, 0x1

    move v9, v8

    const/4 v1, 0x0

    and-int/2addr v9, v1

    :try_start_0
    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/e/a;->d(Landroid/content/Context;)Lcom/tencent/android/tpush/e/a/a;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x1

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getWritableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string v2, "esmoabgowetss"

    const-string/jumbo v2, "sogmtmeesawos"

    const/4 v9, 0x1

    const-string/jumbo v2, "swhaemuegsots"

    const-string/jumbo v2, "messagetoshow"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-string/jumbo v3, "io?subip"

    const-string/jumbo v3, "isb?oidu"

    const/4 v9, 0x2

    const-string/jumbo v3, "qbud?si="

    const-string v3, "busiid=?"

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    const/4 v4, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    new-array v5, v4, [Ljava/lang/String;

    const/4 v8, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v6, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string v7, ""

    const/4 v9, 0x0

    const-string v7, ""

    const-string v7, ""

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    aput-object v6, v5, v1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p0, v2, v3, v5}, Landroid/database/sqlite/SQLiteDatabase;->delete(Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;)I

    move-result v2

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-gtz v2, :cond_0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string v3, "hss! yeaiBdedrdocmsM lthtai= riergoBEuegee IIdb:wbselCid  uc  s "

    const-string v3, "es gobgrIiti rae:e=Bd s yddmIe s!ilhMcedeuoCcuha s be  tdBsEiwrl"

    const/4 v9, 0x1

    const-string v3, "C im edsaesMrgamuuBsIehi  deedc ciswhBId ttEiog =:hlerds!orbe l "

    const-string v3, "delCacheMessageByBusiId Error! msgid to delete which busiId = : "

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v2, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    move v4, v1

    move v4, v1

    const/4 v9, 0x4

    move v4, v1

    move v4, v1

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteClosable;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    return v4

    :catchall_0
    move-exception p0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string/jumbo p2, "odeuoeCBsdBuih s!lMreIgacrreyEa"

    const-string/jumbo p2, "ss!EauurIaereg l diceCrByBdohMe"

    const/4 v9, 0x0

    const-string/jumbo p2, "rasIcbadir sEsdeuolegM!CryBeehB"

    const-string p2, "delCacheMessageByBusiId Error! "

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    return v1
.end method

.method public static g(Landroid/content/Context;J)Z
    .locals 11

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x7

    const/4 v0, 0x0

    :try_start_0
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/e/a;->d(Landroid/content/Context;)Lcom/tencent/android/tpush/e/a/a;

    move-result-object p0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteOpenHelper;->getReadableDatabase()Landroid/database/sqlite/SQLiteDatabase;

    move-result-object p0

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    new-instance v1, Landroid/database/sqlite/SQLiteQueryBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    invoke-direct {v1}, Landroid/database/sqlite/SQLiteQueryBuilder;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x2

    const-string v2, "amwshgepootes"

    const/4 v10, 0x0

    const-string v2, "hooaeeussgwst"

    const-string/jumbo v2, "messagetoshow"

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {v1, v2}, Landroid/database/sqlite/SQLiteQueryBuilder;->setTables(Ljava/lang/String;)V

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x2

    const/4 v2, 0x1

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    new-array v3, v2, [Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const-string/jumbo v4, "psgeeam"

    const-string/jumbo v4, "message"

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x3

    aput-object v4, v3, v0

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-string v4, "gq=q?is"

    const-string/jumbo v4, "sqgd?i="

    const/4 v10, 0x0

    const-string v4, "=ism?sg"

    const-string/jumbo v4, "msgid=?"

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x0

    new-array v5, v2, [Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-virtual {v2, p1, p2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x3

    const-string p1, ""

    const-string p1, ""

    const-string p1, ""

    const-string p1, ""

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x4

    aput-object p1, v5, v0

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x4

    const/4 v6, 0x0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/4 v8, 0x6

    const/4 v10, 0x0

    const/4 v8, 0x0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v10, 0x5

    const/4 v9, 0x1

    invoke-virtual/range {v1 .. v8}, Landroid/database/sqlite/SQLiteQueryBuilder;->query(Landroid/database/sqlite/SQLiteDatabase;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)Landroid/database/Cursor;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz p1, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-interface {p1}, Landroid/database/Cursor;->moveToFirst()Z

    move-result v0

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-interface {p1}, Landroid/database/Cursor;->close()V

    :cond_0
    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-virtual {p0}, Landroid/database/sqlite/SQLiteClosable;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    const-string p2, "asrme og!srMchraECss id"

    const-string p2, "grsah!drCseMoc eia rssE"

    const-string p2, "ich osree dao!ssECMrgae"

    const-string/jumbo p2, "isMessageCached Error! "

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const-string p1, "enIMaborsegManmgfe"

    const-string p1, "IgamMensraenaegfMo"

    const/4 v10, 0x5

    const-string p1, "agseMnurfaMnegoeaI"

    const-string p1, "MessageInfoManager"

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v10, 0x0

    return v0
.end method
