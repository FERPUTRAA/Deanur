.class public Lcom/tencent/android/tpush/e/b/a;
.super Ljava/lang/Object;


# direct methods
.method public static a()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " 4s@/a~ ~@~i @o~ tond~-@t@@r~ ~u. @~vo ~ol@@ ~@1@Mf~ ~ ~@ ~~/~@@i~~b@~  @s@~b l @im Kb~c y@oS@fo"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    new-instance v0, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string v1, "QITmEEEGDE_sRR"

    const-string v1, "IRsEDEER_QEGST"

    const-string v1, "IRERo_TREGQESE"

    const-string v1, "REGISTERED_REQ"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo v3, "srihsbspmb.aveusferpthu."

    const-string v3, "bs.m.rsphpsehtfaviurspue"

    const-string v3, "fspubpu.s.vphiertr.hseua"

    const-string/jumbo v3, "tpush.vip.shareprefs.sub"

    const/4 v5, 0x2

    const/4 v4, 0x7

    invoke-direct {v0, v3, v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x4

    move v5, v4

    return-object v0
.end method

.method public static a(Ljava/lang/String;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v0, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const-string/jumbo p0, "prhooseph"

    const-string/jumbo p0, "tsheophro"

    const/4 v4, 0x2

    const-string p0, "eushhrptq"

    const-string/jumbo p0, "otherpush"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x6

    move v4, v3

    const-string v2, ".bse.shsraf.peirbupsstup"

    const-string/jumbo v2, "tpsi.ba.sbhu.eeufspprvsr"

    const/4 v4, 0x0

    const-string/jumbo v2, "tpush.vip.shareprefs.sub"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-direct {v0, v2, p0, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-object v0
.end method

.method public static b()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance v0, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v1, "ERDmSST_ERGIEP"

    const-string v1, "EIRERSu_ESDPTG"

    const/4 v5, 0x5

    const-string v1, "SPDEoRS_EIGRET"

    const-string v1, "REGISTERED_RSP"

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v3, "htsrubp.psibupeah.f.rspe"

    const-string v3, "er.ahssp.uruftiss.epppbh"

    const/4 v5, 0x7

    const-string/jumbo v3, "tpush.vip.shareprefs.sub"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {v0, v3, v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-object v0
.end method

.method public static b(Ljava/lang/String;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x4

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v3, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo p0, "utptqsueohh"

    const-string/jumbo p0, "stheopurqht"

    const/4 v4, 0x5

    const-string/jumbo p0, "ruthsotpehs"

    const-string/jumbo p0, "otherpushts"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-static {v1, v2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v2, "resfuvisqtehubsr.apps.ph"

    const-string/jumbo v2, "p.sape.suisvhrfhsrtpu.be"

    const/4 v4, 0x5

    const-string v2, "fus.parpe.htpus.ihvbesss"

    const-string/jumbo v2, "tpush.vip.shareprefs.sub"

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v0, v2, p0, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-object v0
.end method

.method public static c()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    new-instance v0, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x6

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string v2, "iasmfshprp.se.uerbvpuhst"

    const-string/jumbo v2, "tpush.vip.shareprefs.sub"

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string/jumbo v3, "mih.oonuet.cntdhroepehpnotcsrmst.u.a"

    const-string v3, "cpnmehdtuda.nmeturospocroe.hsi.n.htt"

    const/4 v5, 0x5

    const-string v3, ".pntrbccteshahpuud.ntot.dr.meoiesnh."

    const-string v3, "com.tencent.android.tpush.other.push"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-direct {v0, v2, v3, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x1

    const/4 v4, 0x4

    return-object v0
.end method

.method public static c(Ljava/lang/String;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/lang/String;",
            ")",
            "Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x0

    new-instance v0, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string p0, "UTCNo_PCOSETTH_U"

    const/4 v4, 0x7

    const-string p0, "_SCHTTuA_NOEUUCP"

    const-string p0, "USE_HTTP_ACCOUNT"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    sget-object v1, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string/jumbo v2, "pfh.birpapsbstuepsev.ur."

    const-string v2, ".pr.vbars.bupstufphseise"

    const/4 v4, 0x3

    const-string/jumbo v2, "psrsipeuqvfsue.hp.h.rtba"

    const-string/jumbo v2, "tpush.vip.shareprefs.sub"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v0, v2, p0, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-object v0
.end method

.method public static d()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    new-instance v0, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v2, "russsrsph.ehu.pivfetsab."

    const-string v2, ".ipefsuhsveta.psrhp.srbu"

    const/4 v5, 0x2

    const-string v2, "essmrpahv.fsuh.berip.tup"

    const-string/jumbo v2, "tpush.vip.shareprefs.sub"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v3, "nhimorcfcpntd.eeoc.ttoun.s.ad"

    const-string v3, "coeoniep.u.n.p.rhcfdatmndctts"

    const/4 v5, 0x7

    const-string/jumbo v3, "scicmbmn.c..readnfhtdpue.ttno"

    const-string v3, "com.tencent.android.tpush.fcm"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {v0, v2, v3, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object v0
.end method

.method public static e()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v0, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const-string v2, "essppturspfae.vsbqh.u.rh"

    const-string/jumbo v2, "tsrifp.sqeahsevbrup.psh."

    const/4 v5, 0x2

    const-string/jumbo v2, "tpush.vip.shareprefs.sub"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string v3, "htcstcepa.csnsnserd.odi.mcuntp.s.femc"

    const-string v3, "c.ssd.nucccscnoesnim..fared.omsttehpt"

    const/4 v5, 0x4

    const-string v3, "fdseoedsqcns.crnhao.e.cncsucup.tt.mmi"

    const-string v3, "com.tencent.android.tpush.fcm.success"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {v0, v2, v3, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-object v0
.end method

.method public static f()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key<",
            "Ljava/lang/Integer;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x6

    new-instance v0, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo v2, "s.s.mpshauieehtpsu.rspfb"

    const-string/jumbo v2, "ie.mssrrssahbetuh.pupf.p"

    const/4 v5, 0x1

    const-string/jumbo v2, "repmvrpeh.ss.pfsi.asutub"

    const-string/jumbo v2, "tpush.vip.shareprefs.sub"

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo v3, "onftorapo.tiefo.rtmc.enc.seducsu.mind.h"

    const-string/jumbo v3, "itunonipco.d.ne.tdmecsatm.freuf.s.htrco"

    const/4 v5, 0x2

    const-string/jumbo v3, "nr.chbifpcs.ron.tcaese.dfsunmemu..ottid"

    const-string v3, "com.tencent.android.tpush.fcm.use.first"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v0, v2, v3, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v4, 0x7

    move v5, v4

    return-object v0
.end method

.method public static g()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    new-instance v0, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string v1, "gsainludutiotnhb.coete..a.neprdnsecbn."

    const-string/jumbo v1, "mteeibtetss.ncdunhod.alna.erpcgoi.nb.n"

    const/4 v5, 0x3

    const-string/jumbo v1, "igcnd.ppusoaa.nednohnremebnli.c..esttt"

    const-string v1, "com.tencent.android.tpush.inmsg.enable"

    const/4 v5, 0x0

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v3, "stip.h.rqbfpuarusehssuvp"

    const-string/jumbo v3, "rfursaupsepi.usbhphv.tse"

    const/4 v5, 0x7

    const-string/jumbo v3, "phsptrs.bvprhfessse..iau"

    const-string/jumbo v3, "tpush.vip.shareprefs.sub"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-direct {v0, v3, v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    return-object v0
.end method

.method public static h()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x2

    new-instance v0, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string v1, "T_ImSECVCHES_ENERSNPUpL_"

    const-string v1, "CLSPESEpSN_U_CHIE_NRVTEN"

    const/4 v5, 0x4

    const-string v1, "PCLEoNSEAEETC_NIUH_S_NSR"

    const-string v1, "USE_TPNS_CHANNEL_SERVICE"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string v3, "eeqbvbshufpp.ta.srp.rish"

    const-string v3, ".stprshsqbp..afureiehsvp"

    const-string/jumbo v3, "ssrr.uu..ehtvseppspabhif"

    const-string/jumbo v3, "tpush.vip.shareprefs.sub"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v0, v3, v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    return-object v0
.end method

.method public static i()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key<",
            "Ljava/lang/Boolean;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    new-instance v0, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string v1, "ENDNULTpI_AOSC_TINFOEONIB"

    const-string v1, "ENABLE_NOTIFICATION_SOUND"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    sget-object v2, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const-string v3, "..rs.uphqvpbsspftsheurea"

    const-string/jumbo v3, "rtsh.preesv.psubhpss.afu"

    const/4 v5, 0x1

    const-string/jumbo v3, "tpush.vip.shareprefs.sub"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {v0, v3, v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;-><init>(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Object;)V

    const/4 v5, 0x3

    return-object v0
.end method
