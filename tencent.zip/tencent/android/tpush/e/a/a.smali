.class public Lcom/tencent/android/tpush/e/a/a;
.super Landroid/database/sqlite/SQLiteOpenHelper;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v1, 0x1

    move v4, v1

    const/4 v3, 0x1

    move v4, v3

    const-string/jumbo v2, "mssebd_eigapgsvx."

    const-string/jumbo v2, "ipsvgxebas_.demg_"

    const/4 v4, 0x4

    const-string/jumbo v2, "sm_mi.bg_pexsgdea"

    const-string/jumbo v2, "xg_message_vip.db"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {p0, p1, v2, v0, v1}, Landroid/database/sqlite/SQLiteOpenHelper;-><init>(Landroid/content/Context;Ljava/lang/String;Landroid/database/sqlite/SQLiteDatabase$CursorFactory;I)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    return-void
.end method

.method private a(Landroid/database/sqlite/SQLiteDatabase;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~f~~oSov/@@ @n s~  @i@@f~by~ o@t b~mc~@Ka~@il Mu  @ ~ ~b@~@ @  ~@~od-~ @lo ~@o4~@i~ t~r~~@@@~o./"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " EIKTbhEstERgGtT)(Ra,EEGRE uIAaNC,BIs EIoTU RENRE gL,eNo EICRI I E eGm,isEt ;LmOeh iaEiTses NRdGA IgT)s( sTEM o dGt,gEQOGYETeNuNd  mAPTUMEmTCFmC,IINiRiG EINEEw N_eNERNbA sw sOTme tTdTX, iOmRiRUsYTs"

    const-string v0, "EiImmMAEmTimIEsLaRG ET(iYGesNCTEmEC CmGe RoN  ,dgtaTITOIEE  ) s TRRtEtTERO FI,NCegIgI ,dENEdEN EeO ERNiANUeKsigE,NA;RRIsR t sNsOTdAw,aTG e)_EU(UsN  EGsE GB,uMIiem o,TdPTGoIu IQXTRwEhRL s  bYtTiEshN"

    const/4 v2, 0x7

    const-string v0, "ETt,RIuR R g E T  IUONetGE aEE eAmATm,XRG sedTiAOeEIGwRE;G u(NTERN _,GeEsLsINmNUsCdEN GIid,ee  M OYEYEIgTEaTIAomEoKL Fi ) EitCREgNNwOahTEs Es s,(ioEdNRgITTM) NssItRT NTGhCEIsUIiBRb  EQmu,,mCNtdsiRT"

    const-string v0, "CREATE TABLE messagetoshow (_id INTEGER PRIMARY KEY AUTOINCREMENT, msgid INTEGER, message TEXT, time INTEGER, busiid INTEGER, showedtime INTEGER, status INTEGER, UNIQUE (msgid) ON CONFLICT IGNORE);"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p1, v0}, Landroid/database/sqlite/SQLiteDatabase;->execSQL(Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public onCreate(Landroid/database/sqlite/SQLiteDatabase;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    const-string v0, "IeeMelgpofeopsDHBrs"

    const-string v0, "HDesoBeIpMfsgeraelo"

    const/4 v3, 0x1

    const-string/jumbo v0, "slBsfeDnqMegoearpeI"

    const-string v0, "MessageInfoDBHelper"

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v1, "eesbia t-n aotrcn"

    const-string v1, " Ccetb oir-naetna"

    const/4 v3, 0x6

    const-string v1, "entma-cCa rntioe "

    const-string v1, "action - onCreate"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/e/a/a;->a(Landroid/database/sqlite/SQLiteDatabase;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    return-void
.end method

.method public onUpgrade(Landroid/database/sqlite/SQLiteDatabase;II)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    const-string/jumbo p1, "neosorlDMeuaHegpfBs"

    const-string p1, "aHfoelugeIBsDnMrpes"

    const/4 v1, 0x7

    const-string p1, "BDHfgbMesoeepesnrIl"

    const-string p1, "MessageInfoDBHelper"

    const/4 v1, 0x2

    const-string p2, "acon-guprdao eUi n"

    const-string p2, "action - onUpgrade"

    const/4 v1, 0x5

    const/4 v0, 0x1

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method
