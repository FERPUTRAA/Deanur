.class Lcom/tencent/android/tpush/XGPushConfig$4;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushConfig;->clearAllCache(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushConfig$4;->a:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "1us@ /~@  fcb lto~~~ @o~v~K  ~~ @yin @~~4~~f@a.~o~ mt~o  b s@i@~/r-@@ ~@@i~@d @@@ @~M~S@@ol~o@ ~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    const-string v0, "hnumoPXssfiC"

    const-string v0, "CussonGhifXP"

    const/4 v6, 0x2

    const-string/jumbo v0, "ngihoPuGXsCf"

    const-string v0, "XGPushConfig"

    :try_start_0
    const/4 v6, 0x2

    const-string v1, "eae xbcutnstec perl alcClAh"

    const-string v1, " lcmClctcearutl pnexAhese a"

    const-string v1, "e slu utl acxlpAea enhrtCcc"

    const-string v1, "excute clear All tpns Cache"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushConfig$4;->a:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->d(Landroid/content/Context;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushConfig$4;->a:Landroid/content/Context;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-array v2, v2, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->b()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x2

    invoke-virtual {v3, v4}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x0

    aput-object v3, v2, v4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushConfig$4;->a:Landroid/content/Context;

    const/4 v6, 0x7

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->clearGuidInfo(Landroid/content/Context;)V

    const/4 v6, 0x5

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushConfig$4;->a:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string/jumbo v2, "ipdv._opeivce"

    const-string v2, "epvco.i_evddi"

    const/4 v6, 0x0

    const-string v2, "i.ed_ivdqpvec"

    const-string v2, "device_id.vip"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1, v2, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushConfig$4;->a:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string/jumbo v2, "ilsxb.t.vsxeptgmg..n"

    const-string/jumbo v2, "vm.nlbxggisipt..xe.t"

    const/4 v6, 0x4

    const-string v2, ".stmelt.xni.gvisgpx."

    const-string v2, ".xg.vip.settings.xml"

    const/4 v6, 0x0

    invoke-virtual {v1, v2, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v5, 0x5

    move v6, v5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushConfig$4;->a:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string/jumbo v2, "vuraoessrpth.siuh.fe"

    const-string v2, "eips..uvshrhearpstuf"

    const/4 v6, 0x5

    const-string/jumbo v2, "p.sa.bevhfurpisrsphe"

    const-string/jumbo v2, "tpush.vip.shareprefs"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {v1, v2, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushConfig$4;->a:Landroid/content/Context;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string/jumbo v2, "phrpsvuphub.saep.fti.seu"

    const-string/jumbo v2, "rvh.tebpsefp.pssu.sihuap"

    const/4 v6, 0x2

    const-string/jumbo v2, "spbeppip..sa.ssvftuhrheu"

    const-string/jumbo v2, "tpush.vip.shareprefs.sub"

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1, v2, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushConfig$4;->a:Landroid/content/Context;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string/jumbo v2, "sfrpea.vqspirevreuhceqhit..s"

    const-string v2, "ah.rveesqprissuvc.ptrehfeis."

    const/4 v6, 0x0

    const-string v2, "chsr.vspepreisespf..aivtruhs"

    const-string/jumbo v2, "tpush.vip.service.shareprefs"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v1, v2, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v5, 0x5

    move v6, v5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushConfig$4;->a:Landroid/content/Context;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string v2, "gfsehsr.appp.sex.viap"

    const/4 v6, 0x7

    const-string/jumbo v2, "xg.vip.app.shareprefs"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v1, v2, v4}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->clear()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string v1, "aeemlcelecetu xruApnct chCs  s slcs"

    const/4 v6, 0x1

    const-string/jumbo v1, "tesm caCx  seeAplac rcctnhueelcusl "

    const-string v1, "excute clear All tpns Cache success"

    const/4 v6, 0x5

    const/4 v5, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v3, "cur oafner ehoXohglerAsGc olirPCa"

    const-string/jumbo v3, "uariolehhfcgeoCr XlenArarP Go slc"

    const/4 v6, 0x1

    const-string/jumbo v3, "niuXrbocgeh alcs earPArClfo CheGr"

    const-string v3, "XGPushConfig clearAllCache error "

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    shr-int/2addr v6, v5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x5

    return-void
.end method
