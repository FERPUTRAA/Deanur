.class Lcom/tencent/android/tpush/InnerTpnsActivity$7;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnCancelListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/InnerTpnsActivity;->a(ILandroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Lcom/tencent/android/tpush/InnerTpnsActivity;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$7;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$7;->a:Landroid/content/Intent;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onCancel(Landroid/content/DialogInterface;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s~~  @f~4ov~@~~@~ ~-/ @~c@~oafsr@@~@~~yMo~@ @l@@ Sl~@K  ~@  @~u b ~md~i~~. t1@ o bi@@@/@ibntoo"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$7;->a:Landroid/content/Intent;

    const/4 v2, 0x4

    move v3, v2

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->open_cancel:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x6

    const-string v1, "ctimsn"

    const-string v1, "icstna"

    const/4 v3, 0x5

    const-string/jumbo v1, "oitaoc"

    const-string v1, "action"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p1, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v3, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$7;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$7;->a:Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$7;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    return-void
.end method
