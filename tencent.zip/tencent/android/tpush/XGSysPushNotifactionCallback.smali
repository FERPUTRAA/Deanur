.class public interface abstract Lcom/tencent/android/tpush/XGSysPushNotifactionCallback;
.super Ljava/lang/Object;


# virtual methods
.method public abstract handleNotify(Lcom/tencent/android/tpush/XGSysNotifaction;)V
.end method
