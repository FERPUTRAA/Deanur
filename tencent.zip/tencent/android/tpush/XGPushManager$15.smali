.class Lcom/tencent/android/tpush/XGPushManager$15;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->addLocalNotificationList(Landroid/content/Context;Ljava/util/ArrayList;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/XGLocalMessage;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGLocalMessage;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$15;->a:Landroid/content/Context;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$15;->b:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$15;->a:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$15;->b:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x7

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {v0, v1, v2, v3}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Lcom/tencent/android/tpush/XGLocalMessage;J)J

    move-result-wide v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo v3, "r:ste"

    const-string v3, "etsr:"

    const/4 v5, 0x3

    const-string/jumbo v3, "ret :"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string v0, ":,gmDmm"

    const-string v0, ":Dgmm,s"

    const/4 v5, 0x4

    const-string v0, "D,Iso:m"

    const-string v0, ",msgID:"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$15;->b:Lcom/tencent/android/tpush/XGLocalMessage;

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpush/XGLocalMessage;->getMsgId()J

    move-result-wide v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v2, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string v1, "agoGPbMaXheus"

    const-string v1, "GrMsoaaPeXuhg"

    const/4 v5, 0x5

    const-string/jumbo v1, "uMPhaXurensgG"

    const-string v1, "XGPushManager"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void
.end method
