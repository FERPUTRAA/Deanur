.class Lcom/tencent/android/tpush/XGPushManager$31;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/XGIOperateCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->upsertAccounts(Landroid/content/Context;Ljava/lang/String;I)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$31;->a:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onFail(Ljava/lang/Object;ILjava/lang/String;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ssm@ ~ @d @.ci~~ ~o~ou l@@4@~@S @@~@~@~ ~aK- l /@~@t ~n~ft~/ri@~~~ov~ ~ob @@~io@y bb f~ 1@o@M~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    const-string v0, " u mcSctPndAeoTnsaN"

    const-string v0, "N s tSncenuTodAPacp"

    const/4 v2, 0x7

    const-string/jumbo v0, "tATNo c napdpeSncuP"

    const-string v0, "TPNS appendAccount "

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    shr-int/2addr v2, v1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$31;->a:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string v0, " ,e ebre d=omfaCid l"

    const-string v0, " orm  aeedfdCr ,=ile"

    const/4 v2, 0x4

    const-string v0, " =dfieueolC  rr d ea"

    const-string v0, " failed, errCode =  "

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string p2, " o sg ,p"

    const-string/jumbo p2, "sgm,o   "

    const/4 v2, 0x7

    const-string/jumbo p2, "q   mgs,"

    const-string p2, ", msg = "

    const/4 v2, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string p2, "aasbPXgMhernG"

    const-string p2, "gMPGsbhnaXear"

    const-string p2, "hGsmuagnMePaX"

    const-string p2, "XGPushManager"

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    return-void
.end method

.method public onSuccess(Ljava/lang/Object;I)V
    .locals 2

    const/4 v1, 0x0

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x0

    const-string p2, "aNnuocopetP uS ncTp"

    const-string/jumbo p2, "nSP cauopc TnpANteu"

    const/4 v1, 0x7

    const-string p2, "dpSnAbeauc  octNpnP"

    const-string p2, "TPNS appendAccount "

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x2

    iget-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$31;->a:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x0

    const-string p2, " spuscue"

    const-string p2, " suecssp"

    const/4 v1, 0x5

    const-string/jumbo p2, "sc esscp"

    const-string p2, " success"

    const/4 v1, 0x2

    const/4 v0, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x4

    const-string p2, "MqhsagaPqueGX"

    const-string p2, "agXhauMGqPres"

    const/4 v1, 0x0

    const-string p2, "hgsXaeaGMPrns"

    const-string p2, "XGPushManager"

    const/4 v0, 0x3

    move v1, v0

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method
