.class Lcom/tencent/android/tpush/XGPush4Msdk$5;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPush4Msdk;->setPushNotificationBuilder(Landroid/content/Context;ILcom/tencent/android/tpush/XGPushNotificationBuilder;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:I

.field final synthetic c:Lcom/tencent/android/tpush/XGPushNotificationBuilder;


# direct methods
.method constructor <init>(Landroid/content/Context;ILcom/tencent/android/tpush/XGPushNotificationBuilder;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$5;->a:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput p2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$5;->b:I

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$5;->c:Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "tas@MK f@@b~4 lf@@ @ry @m~d~~ u~@@  i-n~b co~ ~~~vt~./~@o~o@~~s@~ o o~i@i~@ / @@~bo@  1~~@~ S l@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$5;->a:Landroid/content/Context;

    const/4 v4, 0x4

    iget v1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$5;->b:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$5;->c:Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {v0, v1, v2}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;ILcom/tencent/android/tpush/XGPushNotificationBuilder;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x7

    return-void
.end method
