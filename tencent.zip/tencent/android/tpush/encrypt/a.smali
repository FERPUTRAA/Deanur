.class public Lcom/tencent/android/tpush/encrypt/a;
.super Ljava/lang/Object;


# direct methods
.method public static a([B)Ljava/lang/String;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " lsolr@@ucK ~@@  ~@@i~~-4 ~ifv@s1@@~~~~  o @o@/ /m@n  t@ @oS@~~@.@~y~~~a~  obdbb~ @of~ M~~i@@ ~~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-nez p0, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    return-object v0

    :cond_0
    :try_start_0
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v1, "DM5"

    const-string v1, "DM5"

    const-string v1, "D5M"

    const-string v1, "MD5"

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-static {v1}, Ljava/security/MessageDigest;->getInstance(Ljava/lang/String;)Ljava/security/MessageDigest;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v1, p0}, Ljava/security/MessageDigest;->update([B)V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v1}, Ljava/security/MessageDigest;->digest()[B

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    array-length v3, p0

    const/4 v6, 0x4

    if-ge v2, v3, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    aget-byte v3, p0, v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x0

    and-int/lit16 v3, v3, 0xff

    const/4 v6, 0x6

    const/16 v4, 0x10

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-ge v3, v4, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string v4, "0"

    const-string v4, "0"

    const/4 v6, 0x1

    const-string v4, "0"

    const-string v4, "0"

    const/4 v5, 0x2

    shr-int/2addr v6, v5

    invoke-virtual {v1, v4}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v3}, Ljava/lang/Integer;->toHexString(I)Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto :goto_0

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    return-object p0

    :catchall_0
    const/4 v5, 0x5

    move v6, v5

    return-object v0
.end method
