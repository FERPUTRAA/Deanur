.class public Lcom/tencent/android/tpush/encrypt/Rijndael;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public static decrypt(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  so@ys@4~@t@ @i ~dr~@ai-fo@@b  ~~ot ~~@ll m@@Soo@@~. o@@@~c /K @b/~~~~~@f ~~ ~~n@ M@~~v~biu 1  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    if-nez v0, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->oiSymmetryDecrypt2(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v2, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-ge v1, v2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v2, "daimfe"

    const-string v2, "fesdia"

    const/4 v4, 0x0

    const-string v2, "fealoi"

    const-string v2, "failed"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x6

    const/4 v3, 0x3

    if-eqz v2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->oiSymmetryDecrypt2(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x2

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object v0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    return-object p0
.end method

.method public static encrypt(Ljava/lang/String;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-nez v0, :cond_1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->oiSymmetryEncrypt2(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v2, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-ge v1, v2, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v2, "lmafdb"

    const-string/jumbo v2, "lfdmai"

    const/4 v4, 0x7

    const-string/jumbo v2, "uelifd"

    const-string v2, "failed"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-eqz v2, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->oiSymmetryEncrypt2(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    add-int/lit8 v1, v1, 0x1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    return-object v0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string p0, ""

    const-string p0, ""

    const/4 v4, 0x3

    const-string p0, ""

    const-string p0, ""

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object p0
.end method
