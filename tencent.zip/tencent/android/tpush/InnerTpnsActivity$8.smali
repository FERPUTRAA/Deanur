.class Lcom/tencent/android/tpush/InnerTpnsActivity$8;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/DialogInterface$OnClickListener;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/InnerTpnsActivity;->b(ILandroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Lcom/tencent/android/tpush/InnerTpnsActivity;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$8;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$8;->a:Landroid/content/Intent;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public onClick(Landroid/content/DialogInterface;I)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@os~~ @~nv~ a@o~@l M /Ko @/~ i~@ot@@@  lS @@~~.~ b1 rs@~yb~~@~b~~~ ic@~dt @  f fouo@ -~m@~i@@~~4"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object p2, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$8;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$8;->a:Landroid/content/Intent;

    const/4 v2, 0x7

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/InnerTpnsActivity;->a(Lcom/tencent/android/tpush/InnerTpnsActivity;Landroid/content/Intent;)V

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    invoke-interface {p1}, Landroid/content/DialogInterface;->cancel()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpush/InnerTpnsActivity$8;->b:Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p1}, Landroid/app/Activity;->finish()V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method
