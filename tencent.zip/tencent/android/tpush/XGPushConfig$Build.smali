.class public Lcom/tencent/android/tpush/XGPushConfig$Build;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/XGPushConfig;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "Build"
.end annotation


# instance fields
.field private context:Landroid/content/Context;


# direct methods
.method public constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushConfig$Build;->context:Landroid/content/Context;

    const/4 v0, 0x2

    and-int/2addr v1, v0

    return-void
.end method

.method static synthetic access$000(Lcom/tencent/android/tpush/XGPushConfig$Build;)Landroid/content/Context;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@~s~~ioo~nf@sa@@r- i@~blu@~b4 @ Sf~o ~~@@1@  ~@~@@t@~d~  ~ m@M~.oc ~@o yvb~ ~~/~~ t / oi~@@ @lK@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/tencent/android/tpush/XGPushConfig$Build;->context:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-object p0
.end method


# virtual methods
.method public enableDebug(Z)Lcom/tencent/android/tpush/XGPushConfig$Build;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$Build;->context:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug(Landroid/content/Context;Z)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0
.end method

.method public enableFcmPush(Z)Lcom/tencent/android/tpush/XGPushConfig$Build;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$Build;->context:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->enableOtherPush(Landroid/content/Context;Z)V

    const/4 v2, 0x1

    return-object p0
.end method

.method public enableOtherPush(Z)Lcom/tencent/android/tpush/XGPushConfig$Build;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$Build;->context:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->enableOtherPush(Landroid/content/Context;Z)V

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p0
.end method

.method public setHuaweiDebug(Z)Lcom/tencent/android/tpush/XGPushConfig$Build;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/XGPushConfig;->setHuaweiDebug(Z)V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-object p0
.end method

.method public setLogLevel(I)Lcom/tencent/android/tpush/XGPushConfig$Build;
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->setDebugLevel(I)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v1, Lcom/tencent/android/tpush/XGPushConfig$Build$1;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v1, p0, p1}, Lcom/tencent/android/tpush/XGPushConfig$Build$1;-><init>(Lcom/tencent/android/tpush/XGPushConfig$Build;I)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-object p0
.end method

.method public setMiPushAppId(Ljava/lang/String;)Lcom/tencent/android/tpush/XGPushConfig$Build;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$Build;->context:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->setMiPushAppId(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p0
.end method

.method public setMiPushAppKey(Ljava/lang/String;)Lcom/tencent/android/tpush/XGPushConfig$Build;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$Build;->context:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->setMiPushAppKey(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    return-object p0
.end method

.method public setMzPushAppId(Ljava/lang/String;)Lcom/tencent/android/tpush/XGPushConfig$Build;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$Build;->context:Landroid/content/Context;

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->setMzPushAppId(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method public setMzPushAppKey(Ljava/lang/String;)Lcom/tencent/android/tpush/XGPushConfig$Build;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$Build;->context:Landroid/content/Context;

    const/4 v2, 0x0

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->setMzPushAppKey(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x7

    return-object p0
.end method

.method public setOppoPushAppId(Ljava/lang/String;)Lcom/tencent/android/tpush/XGPushConfig$Build;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$Build;->context:Landroid/content/Context;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->setOppoPushAppId(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x2

    return-object p0
.end method

.method public setOppoPushAppKey(Ljava/lang/String;)Lcom/tencent/android/tpush/XGPushConfig$Build;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$Build;->context:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/XGPushConfig;->setOppoPushAppKey(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p0
.end method
