.class Lcom/tencent/android/tpush/XGPush4Msdk$13;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPush4Msdk;->cleanTags(Landroid/content/Context;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/content/Context;


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$13;->a:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$13;->b:Landroid/content/Context;

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "~/s~io~~~i@ 1@@@@ olol@ K~~~t.fbn @ av-~b @sc@@~/@4 u ~~@ @b@y@o M~mS@~ ~odo~@~t    @f~~ @@~r~~i"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x0

    sget-boolean v0, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-string v1, "MsXmGdusPsk"

    const-string v1, "GssXsPudk4M"

    const/4 v10, 0x4

    const-string v1, "4MshoGuXkPs"

    const-string v1, "XGPush4Msdk"

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x0

    if-eqz v0, :cond_0

    const/4 v10, 0x7

    const/4 v9, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const-string v2, "gep=obarl:Tnmeamaee aNc"

    const-string v2, "egnmTelmac=oN aeaarpse:"

    const/4 v10, 0x4

    const-string v2, "aelT tuc=sepe:aaeNrgona"

    const-string v2, "cleanTags: operateName="

    const/4 v10, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$13;->a:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x2

    const-string v2, ",Aippoqpd"

    const-string v2, "Apqqodip,"

    const-string/jumbo v2, "ip=,qpAqq"

    const-string v2, ",qqAppid="

    const/4 v9, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/XGPush4Msdk;->c()J

    move-result-wide v2

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x6

    const-string v2, "c_sic=a,xbesd"

    const-string v2, "c=cigbd,x_aes"

    const-string v2, "=c_m,xassgdci"

    const-string v2, ",xg_accessid="

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$13;->b:Landroid/content/Context;

    const/4 v9, 0x6

    move v10, v9

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-virtual {v0, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$13;->b:Landroid/content/Context;

    const/4 v9, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x0

    if-nez v0, :cond_1

    const/4 v9, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    const-string v0, "eertonrpvcgf ettxl actia enioa lsh saeiTum nd"

    const-string v0, "a evetufnsit ctenh  lmrspgroaiTe eona tadcxil"

    const/4 v10, 0x4

    const-string v0, " hixrbi taeslneleotcfptamnanves  cidrtgaT oa "

    const-string/jumbo v0, "the parameter context of cleanTags is invalid"

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x5

    return-void

    :cond_1
    const/4 v9, 0x5

    const/4 v10, 0x7

    sget-boolean v0, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-eqz v0, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x6

    const-string v0, "cceia op >TatgsA-nn"

    const/4 v10, 0x5

    const-string/jumbo v0, "oieTAlucnas > gt-na"

    const-string v0, "Action -> cleanTags"

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$13;->b:Landroid/content/Context;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x6

    const-string v3, "*"

    const-string v3, "*"

    const/4 v10, 0x4

    const-string v3, "*"

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x3

    const/16 v4, 0x8

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v5

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$13;->b:Landroid/content/Context;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAppKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    iget-object v8, p0, Lcom/tencent/android/tpush/XGPush4Msdk$13;->a:Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x3

    invoke-static/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x2

    return-void
.end method
