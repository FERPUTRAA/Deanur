.class Lcom/tencent/android/tpush/XGPushManager$26;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->g(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/XGIOperateCallback;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$26;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v10, "s@so@b~@4@@ M~ o  ~/~t~i@@~~~oo~~@ bo  ~~1~c~@@@l@iff@i .S n-m @/~K@ l@~  @ @tr~ d@ ~vy~ b~~o~ua"

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v11, 0x4

    const-string v0, "auMmPnhrasgXG"

    const-string v0, "XasuMrnPGashg"

    const/4 v11, 0x6

    const-string v0, "egMsoGaXrPanh"

    const-string v0, "XGPushManager"

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;)Z

    :try_start_0
    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v1

    const/4 v10, 0x5

    const/4 v10, 0x6

    new-instance v2, Lcom/tencent/android/tpush/XGPushManager$26$1;

    const/4 v11, 0x0

    invoke-direct {v2, p0, p1}, Lcom/tencent/android/tpush/XGPushManager$26$1;-><init>(Lcom/tencent/android/tpush/XGPushManager$26;Landroid/content/Context;)V

    const/4 v11, 0x1

    const/4 v10, 0x5

    invoke-virtual {v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x2

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v11, 0x3

    const-string v3, " h kobcrrohlalrnrsshmrrb ieau  ugtadeetecPn"

    const-string/jumbo v3, "raamrlker  anbhcsge ducreohrlt seioltruhPn "

    const/4 v11, 0x5

    const-string v3, "e Pls un bourshorgrenrilturaa r dtcealekceh"

    const-string/jumbo v3, "unregister otherPush handle callback error "

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    invoke-virtual {v1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$26;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x4

    if-eqz v1, :cond_0

    :try_start_1
    const/4 v11, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    new-instance v9, Lcom/tencent/android/tpush/XGPushManager$a;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$26;->a:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x7

    const/4 v6, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x7

    const/4 v7, 0x1

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x0

    const/4 v8, 0x0

    move-object v2, v9

    move-object v2, v9

    move-object v2, v9

    move-object v2, v9

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    move-object v5, p2

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-direct/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager$a;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;Landroid/content/Context;Landroid/content/Intent;IIZ)V

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {v1, v9}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v11, 0x1

    goto :goto_1

    :catchall_1
    move-exception p1

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x1

    move v11, v10

    const-string v1, "arbelngpe rades richneo rrotc alu"

    const-string/jumbo v1, "re nor oanhe gdarckucrbrsaell tei"

    const/4 v11, 0x3

    const-string/jumbo v1, "racealn qlrtrlebrndghuoa ee sikr "

    const-string/jumbo v1, "unregister handle callback error "

    const/4 v10, 0x0

    move v11, v10

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {p1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_1
    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    return-void
.end method
