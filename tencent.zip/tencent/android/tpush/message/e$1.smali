.class Lcom/tencent/android/tpush/message/e$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/message/e;->c(Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Lcom/tencent/android/tpush/message/e;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/message/e;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/message/e$1;->b:Lcom/tencent/android/tpush/message/e;

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpush/message/e$1;->a:Landroid/content/Intent;

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "b.smo Kl~@ i~~@~ ~f~tiv@~ ~~  @@  b~@cosl@~n~y~tf@ @4o~ @@~~iS do@ab~~o@@  @o/~@~- r@@u/@@M  ~~ "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$1;->a:Landroid/content/Intent;

    const/4 v7, 0x4

    const-string/jumbo v1, "ptey"

    const-string/jumbo v1, "type"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v7, 0x5

    const-wide/16 v2, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-wide/16 v4, 0x7

    const-wide/16 v4, 0x7

    const/4 v7, 0x0

    const-wide/16 v4, 0x7

    const-wide/16 v4, 0x7

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    cmp-long v0, v0, v4

    const/4 v7, 0x7

    const-string v1, "elssMussadnaHrPeeh"

    const/4 v7, 0x6

    const-string/jumbo v1, "ueHmsnsaeshredaMlP"

    const-string v1, "PushMessageHandler"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    if-nez v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$1;->b:Lcom/tencent/android/tpush/message/e;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/message/e;->a(Lcom/tencent/android/tpush/message/e;)Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushConfig;->isEnableShowInMsg(Landroid/content/Context;)Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-nez v0, :cond_0

    const/4 v7, 0x0

    const/4 v6, 0x1

    const-string v0, "aonnoe  aegtlsumshh elisesMddo agMnp"

    const-string v0, "e im Msoelnd ngnsdgelh saaoMwhusetpa"

    const/4 v7, 0x3

    const-string v0, "hgn abeMgislsnwdudoeea pe ahos Mlnlt"

    const-string v0, "handle pushMessage inMsg not allowed"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$1;->b:Lcom/tencent/android/tpush/message/e;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/message/e;->a(Lcom/tencent/android/tpush/message/e;)Landroid/content/Context;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/message/e$1;->a:Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/stat/ServiceStat;->appReportInMsgUserDisabled(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x3

    return-void

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$1;->a:Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string v4, "eadt"

    const-string v4, "daet"

    const/4 v7, 0x0

    const-string/jumbo v4, "tdae"

    const-string v4, "date"

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v4, p0, Lcom/tencent/android/tpush/message/e$1;->a:Landroid/content/Intent;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string v5, "duomg"

    const-string/jumbo v5, "mdsgo"

    const/4 v7, 0x7

    const-string/jumbo v5, "smpdg"

    const-string/jumbo v5, "msgId"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v4, v5, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v2

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v7, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v6, 0x4

    move v7, v6

    cmp-long v2, v2, v4

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-gez v2, :cond_5

    :try_start_0
    const/4 v7, 0x6

    new-instance v2, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string/jumbo v3, "qMdybMdy"

    const-string/jumbo v3, "yyMMybdd"

    const/4 v7, 0x0

    const-string v3, "dysdyMyM"

    const-string/jumbo v3, "yyyyMMdd"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-direct {v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-nez v3, :cond_3

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-nez v3, :cond_1

    const/4 v7, 0x4

    invoke-virtual {v2, v0}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance v4, Ljava/util/Date;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {v4}, Ljava/util/Date;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v2, v4}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v2, v4}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v3, v4}, Ljava/util/Date;->compareTo(Ljava/util/Date;)I

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-nez v3, :cond_1

    const/4 v7, 0x3

    goto :goto_0

    :cond_1
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-nez v3, :cond_2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v2, v0}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    new-instance v3, Ljava/util/Date;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-direct {v3}, Ljava/util/Date;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v2, v3}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v2, v3}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0, v2}, Ljava/util/Date;->compareTo(Ljava/util/Date;)I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-gez v0, :cond_2

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$1;->b:Lcom/tencent/android/tpush/message/e;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/message/e$1;->a:Landroid/content/Intent;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0, v2}, Lcom/tencent/android/tpush/message/e;->a(Landroid/content/Intent;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    goto/16 :goto_1

    :cond_2
    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string/jumbo v0, "ltgmsa  hhmaede eesehb aaecnn dnoauo scteu l l tateo"

    const-string v0, "clatehuhe noecaattfdudb ee mtan g ea lholsse  e ason"

    const/4 v7, 0x6

    const-string/jumbo v0, "nneaotdectu t haethh obg acc fe lee a asmodoslelens "

    const-string v0, "can not handle the local message because of the date"

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x3

    goto/16 :goto_1

    :cond_3
    :goto_0
    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$1;->a:Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/service/util/g;->a(Landroid/content/Intent;)Z

    move-result v0

    const/4 v6, 0x6

    move v7, v6

    if-eqz v0, :cond_4

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$1;->b:Lcom/tencent/android/tpush/message/e;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/message/e$1;->a:Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, v2}, Lcom/tencent/android/tpush/message/e;->a(Landroid/content/Intent;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    goto/16 :goto_1

    :cond_4
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    const-string/jumbo v0, "tcsf bmoe lel eaesptdatheoengacn  etei suobm acnlhh "

    const-string v0, " taedinpaehs len lamo  tcstmegbnlofaho  hcetse eueac"

    const/4 v7, 0x4

    const-string v0, "eds  eummghceaeleth sfe   anaoctheb outi nselnl oata"

    const-string v0, "can not handle the local message because of the time"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Ljava/text/ParseException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x1

    goto :goto_1

    :catch_0
    move-exception v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string v3, "a tassrp gq hE tacrnosh,PdyeerM  sulpet:oPibxeue"

    const-string/jumbo v3, "p srarsuqdiaa lysMrbghPehe P: tEon  tteesctoexu,"

    const/4 v7, 0x7

    const-string/jumbo v3, "nsE,esteqaPexn elPtcu:g yss erttadoourpb a hMh i"

    const-string/jumbo v3, "try to handlerPushMessage, but ParseException : "

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    goto :goto_1

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$1;->a:Landroid/content/Intent;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/service/util/g;->a(Landroid/content/Intent;)Z

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    if-eqz v0, :cond_6

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$1;->b:Lcom/tencent/android/tpush/message/e;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/message/e$1;->a:Landroid/content/Intent;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/message/e;->a(Landroid/content/Intent;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    goto :goto_1

    :cond_6
    const/4 v7, 0x6

    const/4 v6, 0x5

    const-string v0, "buseset on timesanhatn mgl dhae  eecost fheasc"

    const-string/jumbo v0, "thsstahedhn e eu b m acston tcae so feagneeilm"

    const/4 v7, 0x0

    const-string v0, "ao mteaedtibacs he  agfesu ntlhcoehnet smm en "

    const-string v0, "can not handle the message because of the time"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x1

    return-void
.end method
