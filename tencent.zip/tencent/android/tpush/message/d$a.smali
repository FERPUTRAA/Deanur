.class public Lcom/tencent/android/tpush/message/d$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/message/d;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/message/d$a$a;
    }
.end annotation


# instance fields
.field public a:I

.field public b:Ljava/lang/String;

.field public c:Lcom/tencent/android/tpush/message/d$a$a;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:I

.field public h:Ljava/lang/String;

.field public i:Ljava/lang/String;

.field public j:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    iput v0, p0, Lcom/tencent/android/tpush/message/d$a;->a:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d$a;->b:Ljava/lang/String;

    const/4 v3, 0x5

    new-instance v1, Lcom/tencent/android/tpush/message/d$a$a;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v1}, Lcom/tencent/android/tpush/message/d$a$a;-><init>()V

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d$a;->c:Lcom/tencent/android/tpush/message/d$a$a;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d$a;->d:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d$a;->e:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d$a;->f:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    iput v1, p0, Lcom/tencent/android/tpush/message/d$a;->g:I

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d$a;->h:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d$a;->i:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d$a;->j:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public a(Ljava/lang/String;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "ods@@@o1@bo-fK@~ @b~i @/ y4/~l @bm~t @l~~@SMi~n~v ~@@i @@@o@ o~~t~u @@ ~~~.af~~cs  @~ ~r@o   ~ ~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    new-instance v0, Lorg/json/JSONObject;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string/jumbo p1, "nyimtpacseo"

    const-string p1, "_istnoapecy"

    const/4 v5, 0x3

    const-string p1, "action_type"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-nez v1, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput p1, p0, Lcom/tencent/android/tpush/message/d$a;->a:I

    :cond_0
    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string p1, "cvayotit"

    const-string p1, "cvimtaty"

    const/4 v5, 0x6

    const-string p1, "atiivbyc"

    const-string p1, "activity"

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez v1, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/message/d$a;->b:Ljava/lang/String;

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string/jumbo p1, "ryoataut"

    const-string p1, "attyotra"

    const/4 v5, 0x7

    const-string/jumbo p1, "rattay_p"

    const-string p1, "aty_attr"

    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-nez v1, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-nez v1, :cond_2

    :try_start_0
    const/4 v5, 0x5

    new-instance v1, Lorg/json/JSONObject;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {v1, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/message/d$a;->c:Lcom/tencent/android/tpush/message/d$a$a;

    const/4 v5, 0x1

    const-string/jumbo v2, "if"

    const-string/jumbo v2, "if"

    const/4 v5, 0x2

    const-string v2, "fi"

    const-string/jumbo v2, "if"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput v2, p1, Lcom/tencent/android/tpush/message/d$a$a;->a:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/message/d$a;->c:Lcom/tencent/android/tpush/message/d$a$a;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string/jumbo v2, "pf"

    const-string/jumbo v2, "pf"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput v1, p1, Lcom/tencent/android/tpush/message/d$a$a;->b:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v1, "esAbinetqMuogPacs"

    const-string v1, "ePacnbMesstiguAso"

    const-string/jumbo v1, "stsAhMnecePugoasi"

    const-string v1, "PushMessageAction"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string v2, "etymurtobaiitt uerriederAotccd"

    const-string v2, " erteiuibceritrdetyotatovdcrAu"

    const/4 v5, 0x0

    const-string/jumbo v2, "ieauo itodAyicreteett bdorrvct"

    const-string v2, "decode activityAttribute error"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v1, v2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_2
    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo p1, "ptnneb"

    const-string/jumbo p1, "tpnent"

    const/4 v5, 0x0

    const-string/jumbo p1, "untint"

    const-string/jumbo p1, "intent"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-nez v1, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/message/d$a;->d:Ljava/lang/String;

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo p1, "prsbqeo"

    const-string p1, "eqrosrb"

    const/4 v5, 0x7

    const-string/jumbo p1, "rqreowb"

    const-string p1, "browser"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v2, "mrscsnf"

    const-string/jumbo v2, "imsfnrc"

    const/4 v5, 0x2

    const-string/jumbo v2, "orcmmif"

    const-string v2, "confirm"

    const/4 v5, 0x7

    if-nez v1, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/message/d$a;->e:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance p1, Lorg/json/JSONObject;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/message/d$a;->e:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {p1, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v1, "lru"

    const-string/jumbo v1, "rlu"

    const/4 v5, 0x4

    const-string/jumbo v1, "rul"

    const-string/jumbo v1, "url"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-nez v3, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d$a;->f:Ljava/lang/String;

    :cond_4
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-nez v1, :cond_5

    const/4 v5, 0x6

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput p1, p0, Lcom/tencent/android/tpush/message/d$a;->g:I

    :cond_5
    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string p1, "aaekoammcgp_"

    const-string p1, "acpm_gaeknam"

    const/4 v5, 0x3

    const-string p1, "cgpeaba_naek"

    const-string/jumbo p1, "package_name"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-nez v1, :cond_8

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/message/d$a;->i:Ljava/lang/String;

    const/4 v4, 0x1

    move v5, v4

    new-instance p1, Lorg/json/JSONObject;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d$a;->i:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {p1, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x6

    const-string/jumbo v0, "koelocugDaUoapladw"

    const-string v0, "awdnoDpaeaollcUokg"

    const/4 v5, 0x2

    const-string/jumbo v0, "packageDownloadUrl"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez v1, :cond_6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d$a;->j:Ljava/lang/String;

    :cond_6
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string v0, "eagcbmappke"

    const-string/jumbo v0, "paeNmbkecga"

    const/4 v5, 0x7

    const-string/jumbo v0, "kgaemaNpqce"

    const-string/jumbo v0, "packageName"

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-nez v1, :cond_7

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d$a;->h:Ljava/lang/String;

    :cond_7
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez v0, :cond_8

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-virtual {p1, v2}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    iput p1, p0, Lcom/tencent/android/tpush/message/d$a;->g:I

    :cond_8
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    return-void
.end method
