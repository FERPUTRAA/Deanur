.class Lcom/tencent/android/tpush/message/e$a;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/message/e;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/message/e;

.field private b:Landroid/content/Context;

.field private c:Landroid/content/Intent;

.field private d:Lcom/tencent/android/tpush/XGIOperateCallback;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/message/e;Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/message/e$a;->a:Lcom/tencent/android/tpush/message/e;

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p2, p0, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p4, p0, Lcom/tencent/android/tpush/message/e$a;->d:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x3

    const/4 v0, 0x4

    return-void
.end method

.method private a()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~ s@@t v~@~i@ob~@~c@u n~f  ~ i1~o~~~   lM ~t~do@ s@o iSr~~~ l~-@m ~@b@@o~@b@ @y 4 o~.K@/~@@@fa@/"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo v1, "niemEPxdnci.ogoenv.snSp.GcAS.mdUMt_aaS.oiHtcrE"

    const-string/jumbo v1, "t.siEnH.eeocMxanoi_podStgtncrvS.GPEcmaSUdiA..n"

    const/4 v5, 0x7

    const-string v1, "GgU.o..iSpAonv.e.aEtHoecdintm._ianxrdctonPMcSE"

    const-string v1, "com.tencent.android.xg.vip.action.PUSH_MESSAGE"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/f/a;->a(Landroid/content/Context;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const/4 v5, 0x4

    const-string v2, "dpp_abprnmamegthi"

    const-string v2, "aigm_amdpnpphe_tr"

    const/4 v5, 0x2

    const-string/jumbo v2, "taidapuhkp_gmpre_"

    const-string/jumbo v2, "third_app_pkgname"

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-nez v2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string/jumbo v3, "pUoCA_Ap>_SShGEHeOt -N SIpoTrPEA"

    const-string/jumbo v3, "rpS oSoptEeA_AhCSI T>U-HG_ENPOA "

    const/4 v5, 0x2

    const-string v3, "AHS_PTA_qC>EE oArS tpUNph eIS-GM"

    const-string v3, "ACTION_PUSH_MESSAGE otherApp -> "

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string/jumbo v3, "sMsslnahePuabRsgueb"

    const-string v3, "eugPnbbauelsMaRessh"

    const/4 v5, 0x2

    const-string/jumbo v3, "lngmhesssPuaanMeReu"

    const-string v3, "PushMessageRunnable"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Landroid/content/Context;->sendBroadcast(Landroid/content/Intent;)V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_0

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    :goto_0
    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v1, "NgsroPaevm"

    const-string/jumbo v1, "svrPkgName"

    const/4 v4, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez v1, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    new-instance v1, Landroid/content/Intent;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const-string/jumbo v3, "ugtosbaxtprd.vkirnncc..ocdenvaidm.ikce.42oan..t."

    const-string/jumbo v3, "tvaidtusc2ickoxcrpdcr4.des.ktvo.a.manoin.nneg..."

    const-string v3, "icg2..usnt.aecai..crvv.oerkdxtnpokn..aisVddmntoc"

    const-string v3, "com.tencent.android.xg.vip.action.ack.sdk2srv.V4"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v1, v0}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 22

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    iget-object v2, v1, Lcom/tencent/android/tpush/message/e$a;->a:Lcom/tencent/android/tpush/message/e;

    monitor-enter v2

    :try_start_0
    sget-boolean v3, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    if-eqz v3, :cond_0

    const-string v3, "eesabMspaspueRPunnl"

    const-string v3, "elsMssepPhebuRanuna"

    const-string v3, "eblueMhRqgnssnPuesa"

    const-string v3, "PushMessageRunnable"

    const-string v4, "AlsrhaMeu> qiegdsenot scs-Ph"

    const-string v4, "ediMtshnqAsuahePl c r-neos>g"

    const-string/jumbo v4, "slamrhaog->dMeA hniscn tPeeu"

    const-string v4, "Action -> handlerPushMessage"

    invoke-static {v3, v4}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :cond_0
    const/4 v3, 0x0

    :try_start_1
    iget-object v4, v1, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const-string/jumbo v5, "smgIo"

    const-string/jumbo v5, "mssIg"

    const-string v5, "bdsgI"

    const-string/jumbo v5, "msgId"

    const-wide/16 v6, -0x1

    const-wide/16 v6, -0x1

    const-wide/16 v6, -0x1

    invoke-virtual {v4, v5, v6, v7}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v14

    iget-object v4, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    iget-object v5, v1, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    invoke-static {v4, v5}, Lcom/tencent/android/tpush/message/PushMessageManager;->getInstance(Landroid/content/Context;Landroid/content/Intent;)Lcom/tencent/android/tpush/message/PushMessageManager;

    move-result-object v4

    iget-object v5, v1, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const-string/jumbo v8, "rmiteeuxie_"

    const-string/jumbo v8, "tirm_eixmee"

    const-string/jumbo v8, "rx_teippeei"

    const-string v8, "expire_time"

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    invoke-virtual {v5, v8, v9, v10}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v11

    iget-object v5, v1, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const-string/jumbo v8, "ltt"

    const-string/jumbo v8, "tlt"

    const-string/jumbo v8, "ttl"

    const-string/jumbo v8, "ttl"

    invoke-virtual {v5, v8, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v5

    const-string/jumbo v8, "uPaoeasRqlnnehugsbe"

    const-string v8, "MuuRoeghePslbnnseaa"

    const-string v8, "anshbulusegnsRaMPse"

    const-string v8, "PushMessageRunnable"

    new-instance v13, Ljava/lang/StringBuilder;

    invoke-direct {v13}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, " snm pbmeetemtteInggtrixe_i"

    const-string/jumbo v3, "xetieb_tieene tgInmmsr p tg"

    const-string/jumbo v3, "t tsonnix_:mtetem rpgeieIe "

    const-string v3, "get msgIntent expire_time: "

    invoke-virtual {v13, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v13, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo v3, "t:,u bt"

    const-string v3, ",t:  tu"

    const-string v3, " ,tt: u"

    const-string v3, ", ttl: "

    invoke-virtual {v13, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    int-to-long v6, v5

    const-wide/16 v18, 0x3e8

    const-wide/16 v18, 0x3e8

    const-wide/16 v18, 0x3e8

    const-wide/16 v18, 0x3e8

    mul-long v6, v6, v18

    invoke-virtual {v13, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v13}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v8, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v9

    add-long/2addr v6, v9

    const-wide/16 v20, 0x7530

    const-wide/16 v20, 0x7530

    const-wide/16 v20, 0x7530

    add-long v6, v6, v20

    cmp-long v3, v6, v11

    if-gez v3, :cond_1

    const-string v3, "eglPnsnpesbRhMusaue"

    const-string v3, "ebRnneapsPMhsaesluu"

    const-string v3, "PushMessageRunnable"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "tgnn q dq,cpg  d ishtm  rreuiTholl ainptc ixe teiv al=eereamlttsmu_iruo"

    const-string v6, " e,thtp qvc nrh silrrT tnlgur=i etaunoel_ urde ltisapmao  tmxeidm egcii"

    const-string v6, "i=st  t Trpr ueoia,cu esmdii hlhgeaeuronemvtdpigxnlr ttrt  _n lisce mml"

    const-string/jumbo v6, "invalid expire_time larger than currentTime plus ttl too much, msgid = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v6, "cuTmrn,mserie t"

    const-string/jumbo v6, "tesnrTe m rcui,"

    const-string v6, " ut:oTir cmenre"

    const-string v6, ", currentTime: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v5}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v3

    iget-object v5, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-virtual {v3, v5, v14, v15}, Lcom/tencent/android/tpush/message/MessageManager;->deleteCachedMsgIntent(Landroid/content/Context;J)V

    iget-object v3, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-static {v3, v4}, Lcom/tencent/android/tpush/XGPushManager;->msgAck(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_1 .. :try_end_1} :catch_0
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    :try_start_2
    monitor-exit v2
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    return-void

    :cond_1
    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    cmp-long v3, v11, v6

    if-gtz v3, :cond_5

    :try_start_3
    iget-object v3, v1, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const-string/jumbo v6, "reesmbvi_et"

    const-string v6, "eeimvt_rsre"

    const-string/jumbo v6, "tsmreeurevi"

    const-string/jumbo v6, "server_time"

    move-wide/from16 v20, v11

    const-wide/16 v7, -0x1

    const-wide/16 v7, -0x1

    const-wide/16 v7, -0x1

    const-wide/16 v7, -0x1

    invoke-virtual {v3, v6, v7, v8}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v11

    const-string v3, "egnPheopuusRbassMan"

    const-string/jumbo v3, "lRnsosPuubseMneaagh"

    const-string/jumbo v3, "lRnaegMbqssPaeuseuh"

    const-string v3, "PushMessageRunnable"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string v7, "eesT:ti trge evnmsI mtgens"

    const-string v7, "envm bersgt mteesnT I:tige"

    const-string v7, "eetmTirIrs n t ggmsev:metn"

    const-string v7, "get msgIntent serverTime: "

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-static {v3, v6}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_3
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_3} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_3 .. :try_end_3} :catch_0
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    cmp-long v3, v11, v6

    if-lez v3, :cond_6

    if-gtz v5, :cond_2

    const v5, 0x3f480

    :cond_2
    :try_start_4
    invoke-static {v11, v12}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    invoke-static {v6, v7}, Ljava/lang/String;->valueOf(J)Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v7

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v8

    sub-int/2addr v7, v8

    const/4 v8, 0x3

    if-ne v7, v8, :cond_3

    mul-long v11, v11, v18

    goto :goto_0

    :cond_3
    invoke-virtual {v6}, Ljava/lang/String;->length()I

    move-result v6

    invoke-virtual {v3}, Ljava/lang/String;->length()I

    move-result v3

    sub-int/2addr v6, v3

    const/4 v3, -0x3

    if-ne v6, v3, :cond_4

    div-long v11, v11, v18
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    :try_start_5
    const-string/jumbo v6, "sueaoPsndguarslMhe"

    const-string/jumbo v6, "udanrsuePsaseeMlhg"

    const-string/jumbo v6, "sHsrabeMlePdeugnsh"

    const-string v6, "PushMessageHandler"

    const-string v7, ""

    const-string v7, ""

    const-string v7, ""

    const-string v7, ""

    invoke-static {v6, v7, v3}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_4
    :goto_0
    mul-int/lit16 v5, v5, 0x3e8

    int-to-long v5, v5

    add-long/2addr v11, v5

    const-string/jumbo v3, "ssuMPnunabRgeelupha"

    const-string v3, "PusRanepubeaMlhgnse"

    const-string/jumbo v3, "nPnRsslpgaehausebue"

    const-string v3, "PushMessageRunnable"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "tcei_uxiqe :qxperem e"

    const-string v6, "etiee eiqxcpex_ur :me"

    const-string v6, "icstpeiemtx_ue ree :x"

    const-string v6, "execute expire_time: "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v5}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_1

    :cond_5
    move-wide/from16 v20, v11

    :cond_6
    move-wide/from16 v11, v20

    :goto_1
    iget-object v3, v1, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    invoke-virtual {v3}, Landroid/content/Intent;->getPackage()Ljava/lang/String;

    move-result-object v3

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "@"

    const-string v6, "@"

    const-string v6, "@"

    const-string v6, "@"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v3, "@"

    const-string v3, "@"

    const-string v3, "@"

    const-string v3, "@"

    invoke-virtual {v5, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    iget-object v5, v1, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const-string v6, "cacms"

    const-string v6, "ccsIa"

    const-string v6, "aIcco"

    const-string v6, "accId"

    const-wide/16 v7, -0x1

    const-wide/16 v7, -0x1

    const-wide/16 v7, -0x1

    const-wide/16 v7, -0x1

    invoke-virtual {v5, v6, v7, v8}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v5

    iget-object v7, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-static {v7, v5, v6}, Lcom/tencent/android/tpush/message/MessageManager;->getNotifiedMsgIds(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v4}, Lcom/tencent/android/tpush/message/PushMessageManager;->getType()J

    move-result-wide v16

    const-wide/16 v18, 0x7

    const-wide/16 v18, 0x7

    const-wide/16 v18, 0x7

    const-wide/16 v18, 0x7

    cmp-long v8, v16, v18

    if-nez v8, :cond_8

    invoke-virtual {v7, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v3

    if-nez v3, :cond_7

    invoke-virtual {v4}, Lcom/tencent/android/tpush/message/PushMessageManager;->getInMsg()Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_7

    iget-object v3, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-static {v3, v4}, Lcom/tencent/android/tpush/b/a;->a(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V
    :try_end_5
    .catch Lorg/json/JSONException; {:try_start_5 .. :try_end_5} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :cond_7
    :try_start_6
    monitor-exit v2
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_3

    return-void

    :cond_8
    const-wide/16 v16, 0x0

    const-wide/16 v16, 0x0

    const-wide/16 v16, 0x0

    const-wide/16 v16, 0x0

    cmp-long v8, v11, v16

    if-lez v8, :cond_9

    cmp-long v8, v9, v11

    if-lez v8, :cond_9

    :try_start_7
    const-string v3, "PmasgbsHnuasdeereM"

    const-string/jumbo v3, "ndemaeuerMslsHsPga"

    const-string v3, "PHMdhluaenseeursas"

    const-string v3, "PushMessageHandler"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "lr=lg cpeiexsr,tsii emTMpueidnor m"

    const-string/jumbo v6, "lcrioitedlm pms,gr Tixsen =ueMieir"

    const-string v6, " emssuplqxsTtinemirlceeMr= i rdg,i"

    const-string/jumbo v6, "msg is expired, currentTimeMillis="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v9, v10}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string/jumbo v6, "irstix,pme_b ="

    const-string/jumbo v6, "p _xrbeit,e=mi"

    const-string v6, ",=_mxpeeietrm "

    const-string v6, ", expire_time="

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v6, "=sm.oi u  "

    const-string/jumbo v6, "s=  giu .m"

    const-string/jumbo v6, "igm= bs . "

    const-string v6, ". msgid = "

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5, v14, v15}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v5}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v3

    iget-object v5, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-virtual {v3, v5, v14, v15}, Lcom/tencent/android/tpush/message/MessageManager;->deleteCachedMsgIntent(Landroid/content/Context;J)V

    iget-object v3, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-static {v3, v4}, Lcom/tencent/android/tpush/XGPushManager;->msgAck(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V
    :try_end_7
    .catch Lorg/json/JSONException; {:try_start_7 .. :try_end_7} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_7 .. :try_end_7} :catch_0
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    :try_start_8
    monitor-exit v2
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_3

    return-void

    :cond_9
    :try_start_9
    invoke-static {v14, v15}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v8

    invoke-static {v8}, Lcom/tencent/android/tpush/message/e;->a(Ljava/lang/Long;)Z

    move-result v8

    if-nez v8, :cond_a

    iget-object v3, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-static {v3, v4}, Lcom/tencent/android/tpush/XGPushManager;->msgAck(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V
    :try_end_9
    .catch Lorg/json/JSONException; {:try_start_9 .. :try_end_9} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_9 .. :try_end_9} :catch_0
    .catchall {:try_start_9 .. :try_end_9} :catchall_2

    :try_start_a
    monitor-exit v2
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    return-void

    :cond_a
    :try_start_b
    iget-object v8, v1, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const-string v9, "dbisIuuMg"

    const-string v9, "MgidsIupb"

    const-string v9, "IdugbsipM"

    const-string v9, "busiMsgId"

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    const-wide/16 v10, 0x0

    invoke-virtual {v8, v9, v10, v11}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v12

    iget-object v8, v1, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const-string/jumbo v9, "mqteapmsqt"

    const-string/jumbo v9, "memasptiqt"

    const-string/jumbo v9, "passtmmets"

    const-string/jumbo v9, "timestamps"

    invoke-virtual {v8, v9, v10, v11}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v10

    iget-object v8, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-static {v8}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessidList(Landroid/content/Context;)Ljava/util/List;

    move-result-object v8

    iget-object v9, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-static {v9}, Lcom/tencent/android/tpush/f/a;->a(Landroid/content/Context;)Z

    move-result v9

    if-nez v9, :cond_b

    if-eqz v8, :cond_b

    invoke-interface {v8}, Ljava/util/List;->size()I

    move-result v9

    if-lez v9, :cond_b

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v9

    invoke-interface {v8, v9}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v9

    if-nez v9, :cond_b

    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const-string v9, "Ie m a :edtssseuea caba hicadlarfsegscamsh amMecssn,dscPuddee psocsRIelun"

    const-string v9, "PlsaaasendeahuRsIacMg uc fertcio:d  aasdsssesemlms apedIdbecs hcsen euec,"

    const-string v9, "PushMessageRunnable match accessId failed, message droped cause accessId:"

    invoke-virtual {v7, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v5, "  nmooin"

    const-string v5, " ntm ino"

    const-string/jumbo v5, "toni bn "

    const-string v5, " not in "

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v5, "gId o ums"

    const-string v5, "gId o sm "

    const-string v5, "=gId s p "

    const-string v5, " msgId = "

    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v5, "uasheanbqMPeRgnsles"

    const-string/jumbo v5, "ssRnhbesgPlebnMeaua"

    const-string v5, "gaseesaMnulsehPuRns"

    const-string v5, "PushMessageRunnable"

    invoke-static {v5, v3}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v3

    iget-object v5, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-virtual {v3, v5, v14, v15}, Lcom/tencent/android/tpush/message/MessageManager;->deleteCachedMsgIntent(Landroid/content/Context;J)V

    iget-object v3, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-static {v3, v4}, Lcom/tencent/android/tpush/XGPushManager;->msgAck(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V
    :try_end_b
    .catch Lorg/json/JSONException; {:try_start_b .. :try_end_b} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_b .. :try_end_b} :catch_0
    .catchall {:try_start_b .. :try_end_b} :catchall_2

    :try_start_c
    monitor-exit v2
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_3

    return-void

    :cond_b
    :try_start_d
    invoke-virtual {v7, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result v8

    const/4 v9, 0x0

    if-nez v8, :cond_11

    iget-object v8, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-static {v8, v5, v6, v3, v7}, Lcom/tencent/android/tpush/message/MessageManager;->setNotifiedMsgIds(Landroid/content/Context;JLjava/lang/String;Ljava/lang/String;)Z

    move-result v3
    :try_end_d
    .catch Lorg/json/JSONException; {:try_start_d .. :try_end_d} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_d .. :try_end_d} :catch_0
    .catchall {:try_start_d .. :try_end_d} :catchall_2

    if-nez v3, :cond_c

    :try_start_e
    monitor-exit v2
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_3

    return-void

    :cond_c
    :try_start_f
    const-string v3, "MPnmasnleuaueheRsgb"

    const-string v3, "annMususselgebPeRah"

    const-string v3, "eeMaoulPsgnRsnusahb"

    const-string v3, "PushMessageRunnable"

    new-instance v5, Ljava/lang/StringBuilder;

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v6, "vf:irb momRe e eec servsrp"

    const-string/jumbo v6, "r Re rmpve oc rims:vsereef"

    const-string/jumbo v6, "mvoeivueesfe g: rrs Rmrce "

    const-string v6, "Receiver msg from server :"

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Lcom/tencent/android/tpush/message/PushMessageManager;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    invoke-static {v3, v5}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v3, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-static {v3, v4}, Lcom/tencent/android/tpush/XGPushManager;->msgAck(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V

    iget-object v3, v1, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    const-string/jumbo v5, "masergvPqk"

    const-string/jumbo v5, "svrPkgName"

    invoke-virtual {v3, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    iget-object v5, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-virtual {v5}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v5, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    if-nez v5, :cond_d

    const-string v5, "esbanMepenssagRsPuu"

    const-string v5, "aMsshesRengnPseauub"

    const-string v5, "enhnsRsaqaguMlesueP"

    const-string v5, "PushMessageRunnable"

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "pesor mrc hga r stfeomRpee vm"

    const-string/jumbo v7, "romm erpaftpmh sgvc e iRoeer "

    const-string v7, "fecmppgo tRveoe    emrisahr:m"

    const-string v7, "Receiver msg from other app :"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v5, v3}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v3, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    iget-object v5, v1, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    invoke-static {v3, v5}, Lcom/tencent/android/tpush/stat/ServiceStat;->appReportPullupAck(Landroid/content/Context;Landroid/content/Intent;)V

    :cond_d
    invoke-virtual {v4}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMessageHolder()Lcom/tencent/android/tpush/message/a;

    move-result-object v3

    if-eqz v3, :cond_f

    invoke-virtual {v4}, Lcom/tencent/android/tpush/message/PushMessageManager;->getContent()Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v5
    :try_end_f
    .catch Lorg/json/JSONException; {:try_start_f .. :try_end_f} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_f .. :try_end_f} :catch_0
    .catchall {:try_start_f .. :try_end_f} :catchall_2

    if-nez v5, :cond_f

    :try_start_10
    new-instance v8, Lcom/tencent/android/tpush/message/c;

    iget-object v5, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    iget-object v6, v1, Lcom/tencent/android/tpush/message/e$a;->c:Landroid/content/Intent;

    invoke-direct {v8, v5, v6}, Lcom/tencent/android/tpush/message/c;-><init>(Landroid/content/Context;Landroid/content/Intent;)V

    move-object v5, v9

    move-object v5, v9

    move-object v5, v9

    move-object v5, v9

    move-object v9, v4

    move-object v9, v4

    invoke-virtual/range {v8 .. v15}, Lcom/tencent/android/tpush/message/c;->a(Lcom/tencent/android/tpush/message/PushMessageManager;JJJ)Z

    move-result v6

    if-eqz v6, :cond_e

    invoke-direct/range {p0 .. p0}, Lcom/tencent/android/tpush/message/e$a;->a()V

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v6

    iget-object v7, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-virtual {v4}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v8

    invoke-virtual {v6, v7, v8, v9}, Lcom/tencent/android/tpush/message/MessageManager;->updateCachedMsgIntentToShowed(Landroid/content/Context;J)V

    invoke-virtual {v3}, Lcom/tencent/android/tpush/message/a;->b()I

    move-result v3

    const/4 v6, 0x1

    if-ne v3, v6, :cond_10

    invoke-virtual {v4}, Lcom/tencent/android/tpush/message/PushMessageManager;->showNotifacition()V

    goto :goto_2

    :cond_e
    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v3

    iget-object v6, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-virtual {v4}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v7

    invoke-virtual {v3, v6, v7, v8}, Lcom/tencent/android/tpush/message/MessageManager;->updateCachedMsgIntentToVerifyErr(Landroid/content/Context;J)V
    :try_end_10
    .catchall {:try_start_10 .. :try_end_10} :catchall_1

    goto :goto_2

    :catchall_1
    move-exception v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    :try_start_11
    const-string v5, "hesaosMlnRbagsunePe"

    const-string v5, "PushMessageRunnable"

    const-string/jumbo v6, "o nnoerokrruw"

    const-string/jumbo v6, "uornrbownrnk "

    const-string/jumbo v6, "unknown error"

    invoke-static {v5, v6, v3}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v5

    iget-object v6, v1, Lcom/tencent/android/tpush/message/e$a;->b:Landroid/content/Context;

    invoke-virtual {v4}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v7

    invoke-virtual {v5, v6, v7, v8}, Lcom/tencent/android/tpush/message/MessageManager;->updateCachedMsgIntentToVerifyErr(Landroid/content/Context;J)V

    move-object v9, v3

    move-object v9, v3

    move-object v9, v3

    move-object v9, v3

    goto :goto_3

    :cond_f
    move-object v5, v9

    move-object v5, v9

    move-object v5, v9

    move-object v5, v9

    :cond_10
    :goto_2
    move-object v9, v5

    move-object v9, v5

    move-object v9, v5

    move-object v9, v5

    goto :goto_3

    :cond_11
    move-object v5, v9

    move-object v5, v9

    move-object v5, v9

    move-object v5, v9

    iput-object v5, v1, Lcom/tencent/android/tpush/message/e$a;->d:Lcom/tencent/android/tpush/XGIOperateCallback;
    :try_end_11
    .catch Lorg/json/JSONException; {:try_start_11 .. :try_end_11} :catch_1
    .catch Ljava/lang/IllegalArgumentException; {:try_start_11 .. :try_end_11} :catch_0
    .catchall {:try_start_11 .. :try_end_11} :catchall_2

    goto :goto_2

    :catchall_2
    move-exception v0

    move-object v9, v0

    :try_start_12
    const-string v3, "PbnhRuuMgbeaeusssna"

    const-string/jumbo v3, "snlbPbaunRMegssauhe"

    const-string/jumbo v3, "uenahnRplssegubPaMe"

    const-string v3, "PushMessageRunnable"

    const-string/jumbo v4, "rennnur qouwo"

    const-string/jumbo v4, "rrnknnuo woue"

    const-string/jumbo v4, "wksnonuorrenr"

    const-string/jumbo v4, "unknown error"

    invoke-static {v3, v4, v9}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_3

    :catch_0
    move-exception v0

    move-object v9, v0

    move-object v9, v0

    move-object v9, v0

    move-object v9, v0

    const-string/jumbo v3, "plPmgauhReebuMasnes"

    const-string v3, "ahelgsspPeasunMbRue"

    const-string/jumbo v3, "ueRhouPbesnealnsMsg"

    const-string v3, "PushMessageRunnable"

    const-string/jumbo v4, "po p bsr eqhrurteyg"

    const-string/jumbo v4, "prpsheu qts ye gorr"

    const-string v4, "gtu rrushyoe srm pe"

    const-string/jumbo v4, "push msg type error"

    invoke-static {v3, v4, v9}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    goto :goto_3

    :catch_1
    move-exception v0

    move-object v9, v0

    move-object v9, v0

    move-object v9, v0

    move-object v9, v0

    const-string/jumbo v3, "uhbPulepgseMRasnssn"

    const-string v3, "MssRgeuhePnbaslesun"

    const-string v3, "PushMessageRunnable"

    const-string/jumbo v4, "rrs pshmq epruea"

    const-string/jumbo v4, "srsmr phr eeupao"

    const-string/jumbo v4, "shsprrreoe uas p"

    const-string/jumbo v4, "push parse error"

    invoke-static {v3, v4, v9}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_3
    iget-object v3, v1, Lcom/tencent/android/tpush/message/e$a;->d:Lcom/tencent/android/tpush/XGIOperateCallback;

    if-eqz v3, :cond_13

    if-eqz v9, :cond_12

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    invoke-virtual {v9}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v6, -0x1

    invoke-interface {v3, v4, v6, v5}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    goto :goto_4

    :cond_12
    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const/4 v5, 0x0

    invoke-interface {v3, v4, v5}, Lcom/tencent/android/tpush/XGIOperateCallback;->onSuccess(Ljava/lang/Object;I)V

    :cond_13
    :goto_4
    monitor-exit v2

    return-void

    :catchall_3
    move-exception v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    move-object v3, v0

    monitor-exit v2
    :try_end_12
    .catchall {:try_start_12 .. :try_end_12} :catchall_3

    throw v3
.end method
