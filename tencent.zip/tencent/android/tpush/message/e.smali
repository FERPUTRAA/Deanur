.class public Lcom/tencent/android/tpush/message/e;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/message/e$a;
    }
.end annotation


# static fields
.field static a:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field

.field private static volatile b:Lcom/tencent/android/tpush/message/e;

.field private static c:J


# instance fields
.field private d:Landroid/content/Context;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/message/e;->d:Landroid/content/Context;

    const/4 v1, 0x3

    move v2, v1

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/message/e;)Landroid/content/Context;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "n~soo@@4 /@S  ~~~~~~i i ~ /ti ~@ ~@@@ ol~r @oof~~l~@  @~usK ymv@f1- ~@@  a~@b~oc@~ b@db@.~@t~M@~"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/tencent/android/tpush/message/e;->d:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x2

    return-object p0
.end method

.method public static a(Landroid/content/Context;)Lcom/tencent/android/tpush/message/e;
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    sget-object v0, Lcom/tencent/android/tpush/message/e;->b:Lcom/tencent/android/tpush/message/e;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const-class v0, Lcom/tencent/android/tpush/message/e;

    const/4 v3, 0x0

    const-class v0, Lcom/tencent/android/tpush/message/e;

    const-class v0, Lcom/tencent/android/tpush/message/e;

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    sget-object v1, Lcom/tencent/android/tpush/message/e;->b:Lcom/tencent/android/tpush/message/e;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    new-instance v1, Lcom/tencent/android/tpush/message/e;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-direct {v1}, Lcom/tencent/android/tpush/message/e;-><init>()V

    const/4 v3, 0x3

    sput-object v1, Lcom/tencent/android/tpush/message/e;->b:Lcom/tencent/android/tpush/message/e;

    const/4 v3, 0x7

    sget-object v1, Lcom/tencent/android/tpush/message/e;->b:Lcom/tencent/android/tpush/message/e;

    const/4 v3, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-object p0, v1, Lcom/tencent/android/tpush/message/e;->d:Landroid/content/Context;

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    sget-object p0, Lcom/tencent/android/tpush/message/e;->b:Lcom/tencent/android/tpush/message/e;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-object p0, p0, Lcom/tencent/android/tpush/message/e;->d:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/service/b;->b(Landroid/content/Context;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget-object p0, Lcom/tencent/android/tpush/message/e;->b:Lcom/tencent/android/tpush/message/e;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    return-object p0
.end method

.method static synthetic a(Lcom/tencent/android/tpush/message/e;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/message/e;->c(Landroid/content/Intent;)V

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method protected static declared-synchronized a(Ljava/lang/Long;)Z
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-class v0, Lcom/tencent/android/tpush/message/e;

    const-class v0, Lcom/tencent/android/tpush/message/e;

    const/4 v6, 0x2

    const-class v0, Lcom/tencent/android/tpush/message/e;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    monitor-enter v0

    :try_start_0
    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    sget-object v1, Lcom/tencent/android/tpush/message/e;->a:Ljava/util/ArrayList;

    const/4 v6, 0x4

    if-nez v1, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    new-instance v1, Ljava/util/ArrayList;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    sput-object v1, Lcom/tencent/android/tpush/message/e;->a:Ljava/util/ArrayList;

    :cond_0
    const/4 v5, 0x4

    const/4 v6, 0x5

    sget-object v1, Lcom/tencent/android/tpush/message/e;->a:Ljava/util/ArrayList;

    const/4 v6, 0x3

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    if-eqz v1, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    monitor-exit v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    return v2

    :cond_1
    :try_start_1
    const/4 v5, 0x6

    const/4 v6, 0x1

    sget-object v1, Lcom/tencent/android/tpush/message/e;->a:Ljava/util/ArrayList;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    sget-object v1, Lcom/tencent/android/tpush/message/e;->a:Ljava/util/ArrayList;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    const/16 v3, 0xc8

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-le v1, v3, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x2

    sget-object v1, Lcom/tencent/android/tpush/message/e;->a:Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_0

    :catchall_0
    move-exception v1

    :try_start_2
    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v2, "MdseesasnHreuaglhs"

    const/4 v6, 0x7

    const-string/jumbo v2, "nesmraHehaPMdseuls"

    const-string v2, "PushMessageHandler"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v4, "Igmso dhmaaCDdc"

    const-string/jumbo v4, "mdcmdhgIDasCea "

    const/4 v6, 0x4

    const-string v4, "dmCagbDsaId hcd"

    const-string v4, "addCachedmsgID "

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-static {v2, p0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :cond_2
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    monitor-exit v0

    const/4 v5, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    const/4 p0, 0x1

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    return p0

    :catchall_1
    move-exception p0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x6

    monitor-exit v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    throw p0
.end method

.method private c(Landroid/content/Intent;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v1, Lcom/tencent/android/tpush/message/e$1;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v1, p0, p1}, Lcom/tencent/android/tpush/message/e$1;-><init>(Lcom/tencent/android/tpush/message/e;Landroid/content/Intent;)V

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Intent;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    new-instance v1, Lcom/tencent/android/tpush/message/e$a;

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/message/e;->d:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-direct {v1, p0, v2, p1, v3}, Lcom/tencent/android/tpush/message/e$a;-><init>(Lcom/tencent/android/tpush/message/e;Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    return-void
.end method

.method public declared-synchronized a(Z)V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v7, 0x1

    const/4 v6, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x4

    sget-wide v2, Lcom/tencent/android/tpush/message/e;->c:J
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    sub-long v2, v0, v2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-wide/32 v4, 0x1d4c0

    const-wide/32 v4, 0x1d4c0

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x6

    cmp-long v2, v2, v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    if-gtz v2, :cond_0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    if-nez p1, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    monitor-exit p0

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    return-void

    :cond_0
    :try_start_1
    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    sput-wide v0, Lcom/tencent/android/tpush/message/e;->c:J

    const/4 v7, 0x2

    const/4 v6, 0x5

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    new-instance v0, Lcom/tencent/android/tpush/message/e$3;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/message/e$3;-><init>(Lcom/tencent/android/tpush/message/e;)V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {p1, v0}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    monitor-exit p0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x6

    return-void

    :catchall_0
    move-exception p1

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    monitor-exit p0

    const/4 v7, 0x3

    const/4 v6, 0x1

    throw p1
.end method

.method public b(Landroid/content/Intent;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/message/e$2;

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-direct {v1, p0, p1}, Lcom/tencent/android/tpush/message/e$2;-><init>(Lcom/tencent/android/tpush/message/e;Landroid/content/Intent;)V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method
