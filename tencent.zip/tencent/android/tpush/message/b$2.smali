.class Lcom/tencent/android/tpush/message/b$2;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v1, "rgsdus_rsaiemusic_xd_eao"

    const-string/jumbo v1, "irsx_dgrma_sdoocuse_iuae"

    const/4 v4, 0x5

    const-string v1, "_demi_eeuximrgosdarsuoa_"

    const-string/jumbo v1, "xg_media_audio_resources"

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {p2, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string v2, "_DPSoALPPMEA.._UYHIm"

    const-string v2, "PMEm_IAY.SDHL.A_PAUP"

    const/4 v4, 0x6

    const-string v2, "SMAP_bYAAIEP.P.D_PHU"

    const-string v2, ".APP_PUSH_MEDIA.PLAY"

    const/4 v4, 0x2

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    if-eqz v1, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez v1, :cond_1

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/message/b;->a()Landroid/media/MediaPlayer;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    if-nez p1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    new-instance p1, Landroid/media/MediaPlayer;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-direct {p1}, Landroid/media/MediaPlayer;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/message/b;->a(Landroid/media/MediaPlayer;)Landroid/media/MediaPlayer;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/message/b;->a()Landroid/media/MediaPlayer;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v0, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Landroid/media/MediaPlayer;->setAudioStreamType(I)V

    :cond_0
    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/message/b;->a()Landroid/media/MediaPlayer;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->reset()V

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/message/b;->a()Landroid/media/MediaPlayer;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, p2}, Landroid/media/MediaPlayer;->setDataSource(Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/message/b;->a()Landroid/media/MediaPlayer;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->prepare()V

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/message/b;->a()Landroid/media/MediaPlayer;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->start()V
    :try_end_0
    .catch Ljava/lang/IllegalArgumentException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/lang/IllegalStateException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    goto/16 :goto_0

    :catch_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v3, 0x3

    goto/16 :goto_0

    :catch_1
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x7

    const/4 v3, 0x6

    goto :goto_0

    :catch_2
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    goto :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string p1, "I_AUoPTSMDO_PSE.PH.A"

    const/4 v4, 0x2

    const-string p1, "_HSTS.uO_UM.EIDAPAPP"

    const-string p1, ".APP_PUSH_MEDIA.STOP"

    const/4 v4, 0x6

    const/4 v3, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz p1, :cond_2

    :try_start_1
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/message/b;->a()Landroid/media/MediaPlayer;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    if-eqz p1, :cond_2

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/message/b;->a()Landroid/media/MediaPlayer;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->stop()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/message/b;->a()Landroid/media/MediaPlayer;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/media/MediaPlayer;->release()V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/message/b;->a(Landroid/media/MediaPlayer;)Landroid/media/MediaPlayer;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v4, 0x7

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_2
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void
.end method
