.class public Lcom/tencent/android/tpush/message/b;
.super Ljava/lang/Object;


# static fields
.field private static volatile a:Landroid/content/BroadcastReceiver;

.field private static volatile b:Landroid/content/BroadcastReceiver;

.field private static c:Landroid/media/MediaPlayer;

.field private static d:Landroid/graphics/Bitmap;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x7

    return-void
.end method

.method private static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Integer;Ljava/lang/String;)Landroid/app/Notification;
    .locals 7

    new-instance v0, Landroidx/core/app/x1$g;

    invoke-direct {v0, p0}, Landroidx/core/app/x1$g;-><init>(Landroid/content/Context;)V

    invoke-virtual {v0, p3}, Landroidx/core/app/x1$g;->Z(Ljava/lang/String;)Landroidx/core/app/x1$g;

    move-result-object p3

    const/4 v1, 0x1

    invoke-virtual {p3, v1}, Landroidx/core/app/x1$g;->b0(Z)Landroidx/core/app/x1$g;

    move-result-object p3

    invoke-virtual {p3, v1}, Landroidx/core/app/x1$g;->D(Z)Landroidx/core/app/x1$g;

    sget p3, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    const-string v3, "aesgsHssplree"

    const-string v3, "eMseaspglrHse"

    const-string v3, "MHemaspeleegs"

    const-string v3, "MessageHelper"

    if-lt p3, v2, :cond_0

    :try_start_0
    const-class p3, Landroidx/core/app/x1$g;

    const-class p3, Landroidx/core/app/x1$g;

    const-class p3, Landroidx/core/app/x1$g;

    const-class p3, Landroidx/core/app/x1$g;

    const-string/jumbo v2, "lsadoInenheC"

    const-string/jumbo v2, "setChannelId"

    new-array v4, v1, [Ljava/lang/Class;

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const-class v5, Ljava/lang/String;

    const/4 v6, 0x0

    aput-object v5, v4, v6

    invoke-virtual {p3, v2, v4}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object p3

    new-array v1, v1, [Ljava/lang/Object;

    aput-object p2, v1, v6

    invoke-virtual {p3, v0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p2

    const-string p3, "efoiobriNredatn hrpn eulCosGrtanIcit"

    const-string p3, "NotificationGroup setChannelId error"

    invoke-static {v3, p3, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    if-lez p5, :cond_1

    invoke-virtual {v0, p5}, Landroidx/core/app/x1$g;->t0(I)Landroidx/core/app/x1$g;

    goto :goto_1

    :cond_1
    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->icon:I

    invoke-virtual {v0, p0}, Landroidx/core/app/x1$g;->t0(I)Landroidx/core/app/x1$g;

    :goto_1
    if-eqz p6, :cond_2

    invoke-virtual {p6}, Ljava/lang/Integer;->intValue()I

    move-result p0

    invoke-virtual {v0, p0}, Landroidx/core/app/x1$g;->J(I)Landroidx/core/app/x1$g;

    :cond_2
    invoke-static {p4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    if-nez p0, :cond_3

    new-instance p0, Landroidx/core/app/x1$e;

    invoke-direct {p0}, Landroidx/core/app/x1$e;-><init>()V

    invoke-virtual {p0, p4}, Landroidx/core/app/x1$e;->C(Ljava/lang/CharSequence;)Landroidx/core/app/x1$e;

    move-result-object p0

    invoke-virtual {v0, p0}, Landroidx/core/app/x1$g;->z0(Landroidx/core/app/x1$q;)Landroidx/core/app/x1$g;

    :cond_3
    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isBrandBlackShark()Z

    move-result p0

    if-eqz p0, :cond_5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    if-nez p0, :cond_4

    invoke-virtual {v0, p1}, Landroidx/core/app/x1$g;->P(Ljava/lang/CharSequence;)Landroidx/core/app/x1$g;

    goto :goto_2

    :cond_4
    const-string p0, " "

    const-string p0, " "

    const-string p0, " "

    const-string p0, " "

    invoke-virtual {v0, p0}, Landroidx/core/app/x1$g;->P(Ljava/lang/CharSequence;)Landroidx/core/app/x1$g;

    :cond_5
    :goto_2
    new-instance p0, Ljava/lang/StringBuilder;

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo p1, "mBiteruegoalyydN rf:poruigou"

    const-string/jumbo p1, "ioumtugytreBpfNor gyi:draeol"

    const-string p1, "groupNotifyBuilder category:"

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0, p7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    if-eqz p7, :cond_6

    invoke-virtual {p7}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    if-nez p0, :cond_6

    invoke-virtual {v0, p7}, Landroidx/core/app/x1$g;->G(Ljava/lang/String;)Landroidx/core/app/x1$g;

    :cond_6
    invoke-virtual {v0}, Landroidx/core/app/x1$g;->h()Landroid/app/Notification;

    move-result-object p0

    return-object p0
.end method

.method public static a(Landroid/content/Context;Lcom/tencent/android/tpush/message/d$a;ZLcom/tencent/android/tpush/message/PushMessageManager;Z)Landroid/content/Intent;
    .locals 10

    const-string v9, "@y@@@~op~@.@@o~1~@ ~l ~l  r~4i@@i@b ta ~ o/~~@@-  ~ ~n @@@i/coum~~ ~b ~~@~fo  K @~fst~MvSbo~~ @d"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget p2, p1, Lcom/tencent/android/tpush/message/d$a;->a:I

    const/4 v9, 0x5

    invoke-static {p2}, Lcom/tencent/android/tpush/NotificationAction;->getNotificationAction(I)Lcom/tencent/android/tpush/NotificationAction;

    move-result-object p2

    const/4 v9, 0x4

    const/4 v0, 0x0

    const/4 v9, 0x3

    if-nez p2, :cond_0

    return-object v0

    :cond_0
    const/4 v9, 0x2

    sget-object v1, Lcom/tencent/android/tpush/message/b$3;->a:[I

    const/4 v9, 0x6

    invoke-virtual {p2}, Ljava/lang/Enum;->ordinal()I

    move-result p2

    const/4 v9, 0x2

    aget p2, v1, p2

    const/4 v9, 0x7

    const/4 v1, 0x1

    const/4 v9, 0x6

    const/high16 v2, 0x4000000

    const/4 v9, 0x3

    const-class v3, Lcom/tencent/android/tpush/InnerTpnsActivity;

    const-class v3, Lcom/tencent/android/tpush/InnerTpnsActivity;

    const-class v3, Lcom/tencent/android/tpush/InnerTpnsActivity;

    const-class v3, Lcom/tencent/android/tpush/InnerTpnsActivity;

    const/4 v9, 0x5

    const-string v4, "E.oHSNHPqALC"

    const-string v4, "HHN.oPNCESLA"

    const-string v4, "AHsHN.SCUEPN"

    const-string v4, "PUSH.CHANNEL"

    const/4 v9, 0x6

    const-string v5, "aceminbtpo_"

    const-string/jumbo v5, "n_ipabtceto"

    const-string/jumbo v5, "oncyoieapt_"

    const-string v5, "action_type"

    const/4 v9, 0x5

    const-string/jumbo v6, "vititbyu"

    const-string/jumbo v6, "vtiiyaut"

    const-string/jumbo v6, "yvctiaut"

    const-string v6, "activity"

    const/4 v9, 0x4

    const-string/jumbo v7, "nTaH.atpv.IcU.MGpoReNxniS_pNPnLc.d_EEAd.rio.eiSEcgntmoA"

    const-string/jumbo v7, "pT_E.tepg.xa.RePn_SGASLcINcoEidirHSoo.UAiM.tnca.mNvdEnn"

    const-string v7, "ecPiAMciqHaGn.eIttEo.EaiN_ASnxd.dLntoogSUTNmER.._rncSv."

    const-string v7, "com.tencent.android.xg.vip.action.INTERNAL_PUSH_MESSAGE"

    const/4 v9, 0x7

    const-string/jumbo v8, "npsqTyatnfeoiioticnoAt"

    const-string v8, "enntnitoqTpAoyatiifioc"

    const-string/jumbo v8, "notificationActionType"

    const/4 v9, 0x4

    if-eq p2, v1, :cond_6

    const/4 v9, 0x4

    const/4 v1, 0x2

    const/4 v9, 0x1

    if-eq p2, v1, :cond_5

    const/4 v9, 0x4

    const/4 v1, 0x3

    const/4 v9, 0x7

    if-eq p2, v1, :cond_3

    const/4 v9, 0x6

    const/4 v1, 0x4

    if-eq p2, v1, :cond_3

    const/4 v9, 0x1

    const/4 v1, 0x5

    const/4 v9, 0x0

    if-eq p2, v1, :cond_1

    const/4 v9, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const-string/jumbo v1, "tutmBonntnppI_ tnnwnnes:e ioTp eykcytaeeg"

    const-string/jumbo v1, "oestepn gcpnIwnetnnieOp_Bt ttyneoy a:Tknu"

    const-string/jumbo v1, "ntenonpteeenyTB O ko_yptptcuon:gIntn awie"

    const-string v1, "getIntentByOpenType unknown action_type: "

    const/4 v9, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    iget v1, p1, Lcom/tencent/android/tpush/message/d$a;->a:I

    const/4 v9, 0x1

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x7

    const-string v1, "HelsebMpersam"

    const-string v1, "HapmeregsseMl"

    const-string v1, "MessageHelper"

    const/4 v9, 0x4

    invoke-static {v1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    goto/16 :goto_3

    :cond_1
    new-instance v0, Landroid/content/Intent;

    const/4 v9, 0x2

    invoke-direct {v0, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    iget-object p2, p1, Lcom/tencent/android/tpush/message/d$a;->h:Ljava/lang/String;

    const/4 v9, 0x2

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x5

    if-eqz v1, :cond_2

    const/4 v9, 0x2

    return-object v0

    :cond_2
    const/4 v9, 0x1

    iget v1, p1, Lcom/tencent/android/tpush/message/d$a;->a:I

    const/4 v9, 0x5

    invoke-virtual {v0, v5, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x1

    const-string/jumbo v1, "lDrkdlupaaeooawnco"

    const-string/jumbo v1, "kaapolncogwrdelDao"

    const-string v1, "gaDaoelpkUaorcpwdl"

    const-string/jumbo v1, "packageDownloadUrl"

    const/4 v9, 0x6

    iget-object v5, p1, Lcom/tencent/android/tpush/message/d$a;->j:Ljava/lang/String;

    const/4 v9, 0x6

    invoke-virtual {v0, v1, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x7

    const-string v1, "gapbmceaqka"

    const-string v1, "Nmkaabeacpg"

    const-string v1, "aNsekmegcap"

    const-string/jumbo v1, "packageName"

    const/4 v9, 0x7

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x1

    invoke-virtual {v0, v6, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x6

    sget-object p2, Lcom/tencent/android/tpush/NotificationAction;->action_package:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v9, 0x6

    invoke-virtual {p2}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result p2

    const/4 v9, 0x5

    invoke-virtual {v0, v8, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x2

    iget p2, p3, Lcom/tencent/android/tpush/message/PushMessageManager;->pushChannel:I

    const/4 v9, 0x0

    invoke-virtual {v0, v4, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x1

    invoke-virtual {v0, p0, v3}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    const/4 v9, 0x6

    goto/16 :goto_3

    :cond_3
    const/4 v9, 0x0

    new-instance v0, Landroid/content/Intent;

    const/4 v9, 0x1

    invoke-direct {v0, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    iget-object p2, p1, Lcom/tencent/android/tpush/message/d$a;->d:Ljava/lang/String;

    const/4 v9, 0x7

    invoke-virtual {v0, v6, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x2

    iget p2, p1, Lcom/tencent/android/tpush/message/d$a;->a:I

    const/4 v9, 0x4

    invoke-virtual {v0, v5, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x0

    iget p2, p1, Lcom/tencent/android/tpush/message/d$a;->a:I

    const/4 v9, 0x1

    sget-object v1, Lcom/tencent/android/tpush/NotificationAction;->intent_with_action:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v9, 0x1

    invoke-virtual {v1}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v5

    const/4 v9, 0x0

    if-ne p2, v5, :cond_4

    invoke-virtual {v1}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result p2

    const/4 v9, 0x3

    invoke-virtual {v0, v8, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x0

    goto :goto_0

    :cond_4
    const/4 v9, 0x4

    sget-object p2, Lcom/tencent/android/tpush/NotificationAction;->intent:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v9, 0x3

    invoke-virtual {p2}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result p2

    const/4 v9, 0x5

    invoke-virtual {v0, v8, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    :goto_0
    const/4 v9, 0x7

    iget p2, p3, Lcom/tencent/android/tpush/message/PushMessageManager;->pushChannel:I

    const/4 v9, 0x0

    invoke-virtual {v0, v4, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    invoke-virtual {v0, p0, v3}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    const/4 v9, 0x6

    goto/16 :goto_3

    :cond_5
    const/4 v9, 0x3

    new-instance v0, Landroid/content/Intent;

    invoke-direct {v0, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x1

    iget-object p2, p1, Lcom/tencent/android/tpush/message/d$a;->f:Ljava/lang/String;

    const/4 v9, 0x1

    invoke-virtual {v0, v6, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x6

    iget p2, p1, Lcom/tencent/android/tpush/message/d$a;->a:I

    const/4 v9, 0x2

    invoke-virtual {v0, v5, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x1

    sget-object p2, Lcom/tencent/android/tpush/NotificationAction;->url:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v9, 0x3

    invoke-virtual {p2}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result p2

    const/4 v9, 0x2

    invoke-virtual {v0, v8, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x4

    iget p2, p3, Lcom/tencent/android/tpush/message/PushMessageManager;->pushChannel:I

    const/4 v9, 0x0

    invoke-virtual {v0, v4, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x0

    invoke-virtual {v0, p0, v3}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    const/4 v9, 0x0

    goto :goto_3

    :cond_6
    const/4 v9, 0x2

    new-instance v0, Landroid/content/Intent;

    const/4 v9, 0x1

    invoke-direct {v0, v7}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x5

    iget-object p2, p1, Lcom/tencent/android/tpush/message/d$a;->b:Ljava/lang/String;

    const/4 v9, 0x6

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x1

    if-eqz v1, :cond_7

    const/4 v9, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/message/b;->b(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p2

    :cond_7
    const/4 v9, 0x0

    iget-object v1, p1, Lcom/tencent/android/tpush/message/d$a;->c:Lcom/tencent/android/tpush/message/d$a$a;

    const/4 v9, 0x0

    if-eqz v1, :cond_9

    const/4 v9, 0x2

    iget v1, v1, Lcom/tencent/android/tpush/message/d$a$a;->a:I

    const/4 v9, 0x0

    if-gtz v1, :cond_8

    const/4 v9, 0x5

    goto :goto_1

    :cond_8
    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v9, 0x3

    goto :goto_2

    :cond_9
    :goto_1
    const/4 v9, 0x4

    invoke-virtual {v0, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    :goto_2
    const/4 v9, 0x6

    invoke-virtual {v0, v6, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x2

    sget-object p2, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v9, 0x3

    invoke-virtual {p2}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v1

    const/4 v9, 0x0

    invoke-virtual {v0, v8, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x6

    invoke-virtual {p2}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result p2

    const/4 v9, 0x5

    invoke-virtual {v0, v5, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x3

    iget p2, p3, Lcom/tencent/android/tpush/message/PushMessageManager;->pushChannel:I

    invoke-virtual {v0, v4, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x4

    invoke-virtual {v0, p0, v3}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    :goto_3
    if-eqz v0, :cond_c

    const/4 v9, 0x1

    const-string p2, "_otmfoccinrain"

    const-string p2, "action_confirm"

    const/4 v9, 0x7

    iget v1, p1, Lcom/tencent/android/tpush/message/d$a;->g:I

    const/4 v9, 0x1

    invoke-virtual {v0, p2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x5

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v3

    const/4 v9, 0x2

    const-string/jumbo p2, "udmIo"

    const-string/jumbo p2, "mugdI"

    const-string p2, "bsdmg"

    const-string/jumbo p2, "msgId"

    const/4 v9, 0x7

    invoke-virtual {v0, p2, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getBusiMsgId()J

    move-result-wide v3

    const/4 v9, 0x3

    const-string v1, "gbupisudI"

    const-string v1, "IbsMuigpd"

    const-string v1, "bgisIdupM"

    const-string v1, "busiMsgId"

    const/4 v9, 0x3

    invoke-virtual {v0, v1, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v9, 0x6

    const-string/jumbo v3, "qTiusehp"

    const-string/jumbo v3, "qieuThps"

    const-string v3, "ehspuiTm"

    const-string/jumbo v3, "pushTime"

    const/4 v9, 0x3

    iget-wide v4, p3, Lcom/tencent/android/tpush/message/PushMessageManager;->pushTime:J

    const/4 v9, 0x3

    invoke-virtual {v0, v3, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v9, 0x2

    const-string/jumbo v3, "ulamhpsseCh"

    const-string v3, "anslCespuhh"

    const-string v3, "hheaoupCnln"

    const-string/jumbo v3, "pushChannel"

    const/4 v9, 0x3

    iget v4, p3, Lcom/tencent/android/tpush/message/PushMessageManager;->pushChannel:I

    const/4 v9, 0x2

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x7

    const-string/jumbo v3, "upIorbm"

    const-string v3, "Iopmurd"

    const-string v3, "Iopguru"

    const-string v3, "groupId"

    const/4 v9, 0x6

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getGroupId()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x1

    invoke-virtual {v0, v3, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x0

    const-string v3, "egyotTppet"

    const-string v3, "epeyogtrTt"

    const-string/jumbo v3, "trtyegaeqT"

    const-string/jumbo v3, "targetType"

    const/4 v9, 0x7

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getTargetType()J

    move-result-wide v4

    const/4 v9, 0x6

    invoke-virtual {v0, v3, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v9, 0x1

    const-string/jumbo v3, "rcseus"

    const-string/jumbo v3, "source"

    const/4 v9, 0x2

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getSource()J

    move-result-wide v4

    const/4 v9, 0x4

    invoke-virtual {v0, v3, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMessageHolder()Lcom/tencent/android/tpush/message/a;

    move-result-object v3

    const/4 v9, 0x7

    check-cast v3, Lcom/tencent/android/tpush/message/d;

    const/4 v9, 0x3

    const-string/jumbo v4, "paMmhb.tgSG.s"

    const-string v4, "as.tGbgMhpS.t"

    const-string v4, "StuhoGapt..gs"

    const-string/jumbo v4, "tag.tpush.MSG"

    const/4 v9, 0x1

    const-string/jumbo v5, "utre"

    const-string/jumbo v5, "uret"

    const-string/jumbo v5, "rute"

    const-string/jumbo v5, "true"

    const/4 v9, 0x4

    invoke-virtual {v0, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x6

    invoke-virtual {v3}, Lcom/tencent/android/tpush/message/a;->d()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x5

    invoke-static {v4}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x1

    const-string v5, "bltue"

    const-string v5, "euitl"

    const-string/jumbo v5, "tulti"

    const-string/jumbo v5, "title"

    const/4 v9, 0x6

    invoke-virtual {v0, v5, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x5

    invoke-virtual {v3}, Lcom/tencent/android/tpush/message/a;->e()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x6

    invoke-static {v4}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x7

    const-string/jumbo v5, "pncneop"

    const-string/jumbo v5, "pnocnet"

    const-string v5, "cqteotn"

    const-string v5, "content"

    const/4 v9, 0x1

    invoke-virtual {v0, v5, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x0

    invoke-virtual {v3}, Lcom/tencent/android/tpush/message/a;->f()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x2

    if-eqz v4, :cond_a

    const/4 v9, 0x0

    invoke-virtual {v3}, Lcom/tencent/android/tpush/message/a;->f()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x2

    invoke-static {v4}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x6

    const-string v5, "eosuqmntcncsto"

    const-string/jumbo v5, "tn_euntcqoomcs"

    const-string/jumbo v5, "otomcnenu_mstc"

    const-string v5, "custom_content"

    const/4 v9, 0x4

    invoke-virtual {v0, v5, v4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_a
    const/4 v9, 0x6

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v4

    const/4 v9, 0x2

    invoke-virtual {v0, p2, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string p2, "csdao"

    const-string p2, "acscd"

    const-string p2, "bIdac"

    const-string p2, "accId"

    const/4 v9, 0x7

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getAccessId()J

    move-result-wide v4

    const/4 v9, 0x5

    invoke-virtual {v0, p2, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getBusiMsgId()J

    move-result-wide v4

    const/4 v9, 0x3

    invoke-virtual {v0, v1, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v9, 0x2

    const-string p2, "etsipmusmt"

    const-string/jumbo p2, "imempsmtst"

    const-string p2, "esaspitpmt"

    const-string/jumbo p2, "timestamps"

    const/4 v9, 0x7

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getTimestamps()J

    move-result-wide v4

    const/4 v9, 0x1

    invoke-virtual {v0, p2, v4, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v9, 0x4

    const-string/jumbo p2, "qprdugio"

    const-string p2, "group_id"

    const/4 v9, 0x4

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getGroupId()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x6

    invoke-virtual {v0, p2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x3

    const-string/jumbo p2, "temdoapetI"

    const-string/jumbo p2, "lestdametI"

    const-string/jumbo p2, "templateId"

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getTemplateId()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x3

    invoke-virtual {v0, p2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x3

    const-string p2, "cetmbIa"

    const-string/jumbo p2, "retaIbc"

    const-string/jumbo p2, "rIdaoct"

    const-string/jumbo p2, "traceId"

    const/4 v9, 0x6

    invoke-virtual {p3}, Lcom/tencent/android/tpush/message/PushMessageManager;->getTraceId()Ljava/lang/String;

    move-result-object p3

    const/4 v9, 0x0

    invoke-virtual {v0, p2, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p2

    const/4 v9, 0x2

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const-wide/16 v4, 0x3e8

    const/4 v9, 0x3

    sub-long/2addr p2, v4

    const/4 v9, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const/4 v9, 0x7

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    invoke-virtual {v1, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x3

    invoke-static {p2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x0

    const-string/jumbo p3, "ottcebp"

    const-string/jumbo p3, "otepctu"

    const-string/jumbo p3, "roctepu"

    const-string/jumbo p3, "protect"

    const/4 v9, 0x6

    invoke-virtual {v0, p3, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x7

    invoke-virtual {v3}, Lcom/tencent/android/tpush/message/d;->k()I

    move-result p2

    const/4 v9, 0x1

    if-gtz p2, :cond_b

    const/4 v9, 0x5

    invoke-virtual {v3}, Lcom/tencent/android/tpush/message/d;->g()I

    move-result p2

    const/4 v9, 0x6

    invoke-static {p0, p2}, Lcom/tencent/android/tpush/message/b;->b(Landroid/content/Context;I)I

    move-result p2

    :cond_b
    const/4 v9, 0x5

    const-string/jumbo p0, "ii_onitpdtacno"

    const-string/jumbo p0, "idtnotnp_iocia"

    const-string/jumbo p0, "notifaction_id"

    const/4 v9, 0x1

    invoke-virtual {v0, p0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    :cond_c
    const/4 v9, 0x1

    if-eqz v0, :cond_f

    const/4 v9, 0x3

    if-eqz p4, :cond_f

    const/4 v9, 0x2

    iget-object p0, p1, Lcom/tencent/android/tpush/message/d$a;->c:Lcom/tencent/android/tpush/message/d$a$a;

    const/4 v9, 0x7

    if-eqz p0, :cond_e

    const/4 v9, 0x2

    iget p0, p0, Lcom/tencent/android/tpush/message/d$a$a;->a:I

    const/4 v9, 0x2

    if-gtz p0, :cond_d

    const/4 v9, 0x0

    goto :goto_4

    :cond_d
    const/4 v9, 0x1

    invoke-virtual {v0, p0}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v9, 0x4

    goto :goto_5

    :cond_e
    :goto_4
    invoke-virtual {v0, v2}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    :cond_f
    :goto_5
    const/4 v9, 0x1

    return-object v0
.end method

.method private static a(Ljava/lang/String;)Landroid/graphics/Bitmap;
    .locals 12

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x6

    const/4 v11, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    const-string v1, "Iatedoamq eeogqm"

    const-string v1, "aegteamoqdmReIo "

    const/4 v11, 0x5

    const-string/jumbo v1, "loadRemoteImage "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x2

    const-string/jumbo v2, "rssHpMeglesee"

    const/4 v11, 0x0

    const-string/jumbo v2, "prsesMgeelHae"

    const-string v2, "MessageHelper"

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    new-instance v3, Ljava/net/URL;

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-direct {v3, p0}, Ljava/net/URL;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v3}, Ljava/net/URL;->getProtocol()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v4}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v4

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-string/jumbo v5, "pthms"

    const-string v5, "https"

    const/4 v11, 0x3

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x4

    if-eqz v4, :cond_0

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    check-cast v3, Ljavax/net/ssl/HttpsURLConnection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_3

    :try_start_1
    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x4

    sget-object v4, Lorg/apache/http/conn/ssl/SSLSocketFactory;->STRICT_HOSTNAME_VERIFIER:Lorg/apache/http/conn/ssl/X509HostnameVerifier;

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v3, v4}, Ljavax/net/ssl/HttpsURLConnection;->setHostnameVerifier(Ljavax/net/ssl/HostnameVerifier;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_2

    const/4 v11, 0x3

    goto :goto_0

    :cond_0
    :try_start_2
    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v3}, Ljava/net/URL;->openConnection()Ljava/net/URLConnection;

    move-result-object v3

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    check-cast v3, Ljava/net/HttpURLConnection;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    :goto_0
    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x4

    const/16 v4, 0x4e20

    :try_start_3
    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v3, v4}, Ljava/net/URLConnection;->setConnectTimeout(I)V

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x5

    invoke-virtual {v3, v4}, Ljava/net/URLConnection;->setReadTimeout(I)V

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-string v4, "GET"

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v3, v4}, Ljava/net/HttpURLConnection;->setRequestMethod(Ljava/lang/String;)V

    const/4 v11, 0x6

    const-string/jumbo v4, "srthome"

    const-string v4, "athmers"

    const/4 v11, 0x3

    const-string/jumbo v4, "rcaehbs"

    const-string v4, "charset"

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x2

    const-string/jumbo v5, "ouUT8"

    const-string v5, "TU-8o"

    const/4 v11, 0x0

    const-string v5, "-TpUF"

    const-string v5, "UTF-8"

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x0

    invoke-virtual {v3, v4, v5}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x5

    const/4 v4, 0x1

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v3, v4}, Ljava/net/URLConnection;->setDoInput(Z)V

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    const/4 v4, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x0

    invoke-virtual {v3, v4}, Ljava/net/URLConnection;->setUseCaches(Z)V

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    const-string v5, "conenbCito"

    const-string/jumbo v5, "tenonnciqo"

    const-string v5, "Connection"

    const/4 v11, 0x1

    const/4 v10, 0x2

    const-string/jumbo v6, "vAslKepi-e"

    const-string v6, "Keep-Alive"

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x7

    invoke-virtual {v3, v5, v6}, Ljava/net/URLConnection;->setRequestProperty(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->getResponseCode()I

    move-result v5
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/16 v6, 0xc8

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x6

    if-eq v5, v6, :cond_1

    :try_start_4
    const/4 v11, 0x1

    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_4
    .catch Ljava/io/IOException; {:try_start_4 .. :try_end_4} :catch_0

    :catch_0
    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x5

    return-object v0

    :cond_1
    :try_start_5
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v3}, Ljava/net/URLConnection;->getInputStream()Ljava/io/InputStream;

    move-result-object v5
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    const/4 v11, 0x7

    const/4 v10, 0x6

    if-eqz v5, :cond_3

    :try_start_6
    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    new-instance v6, Ljava/io/ByteArrayOutputStream;

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-direct {v6}, Ljava/io/ByteArrayOutputStream;-><init>()V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_1

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x6

    const/16 v7, 0x400

    :try_start_7
    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x4

    new-array v7, v7, [B

    :goto_1
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v5, v7}, Ljava/io/InputStream;->read([B)I

    move-result v8

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v9, -0x1

    move v11, v9

    const/4 v10, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x1

    if-eq v8, v9, :cond_2

    const/4 v10, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {v6, v7, v4, v8}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    goto :goto_1

    :cond_2
    const/4 v11, 0x0

    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v7

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object v8

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x4

    array-length v8, v8

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-static {v7, v4, v8}, Landroid/graphics/BitmapFactory;->decodeByteArray([BII)Landroid/graphics/Bitmap;

    move-result-object p0
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_0

    :try_start_8
    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v11, 0x4

    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_8
    .catch Ljava/io/IOException; {:try_start_8 .. :try_end_8} :catch_1

    return-object p0

    :catch_1
    const/4 v10, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x3

    return-object v0

    :catchall_0
    move-exception v4

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x7

    goto :goto_3

    :catchall_1
    move-exception v4

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    move-object v6, v0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    goto :goto_3

    :cond_3
    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x2

    if-eqz v5, :cond_4

    :try_start_9
    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    :cond_4
    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x5

    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_2

    :catch_2
    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x1

    return-object v0

    :catchall_2
    move-exception v4

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x6

    goto :goto_2

    :catchall_3
    move-exception v4

    move-object v3, v0

    move-object v3, v0

    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    move-object v5, v3

    :goto_2
    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    move-object v6, v5

    :goto_3
    :try_start_a
    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x2

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x5

    or-int/2addr v11, v10

    invoke-virtual {v7, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string/jumbo p0, "ro:m uer"

    const-string p0, " :rroeur"

    const/4 v11, 0x1

    const-string p0, " r eor:r"

    const-string p0, " error: "

    const/4 v11, 0x1

    const/4 v10, 0x2

    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-virtual {v4}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v7, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_4

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-eqz v5, :cond_5

    :try_start_b
    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    :cond_5
    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x6

    if-eqz v6, :cond_6

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x5

    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->close()V

    :cond_6
    const/4 v10, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x4

    if-eqz v3, :cond_7

    const/4 v10, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_b
    .catch Ljava/io/IOException; {:try_start_b .. :try_end_b} :catch_3

    nop

    :catch_3
    :cond_7
    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    return-object v0

    :catchall_4
    move-exception p0

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    if-eqz v5, :cond_8

    :try_start_c
    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {v5}, Ljava/io/InputStream;->close()V

    :cond_8
    const/4 v10, 0x6

    if-eqz v6, :cond_9

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-virtual {v6}, Ljava/io/ByteArrayOutputStream;->close()V

    :cond_9
    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    if-eqz v3, :cond_a

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v3}, Ljava/net/HttpURLConnection;->disconnect()V
    :try_end_c
    .catch Ljava/io/IOException; {:try_start_c .. :try_end_c} :catch_4

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x5

    goto :goto_4

    :catch_4
    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x3

    return-object v0

    :cond_a
    :goto_4
    const/4 v10, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    throw p0
.end method

.method static synthetic a()Landroid/media/MediaPlayer;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/message/b;->c:Landroid/media/MediaPlayer;

    const/4 v2, 0x1

    return-object v0
.end method

.method static synthetic a(Landroid/media/MediaPlayer;)Landroid/media/MediaPlayer;
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    sput-object p0, Lcom/tencent/android/tpush/message/b;->c:Landroid/media/MediaPlayer;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-object p0
.end method

.method private static a(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;Lcom/tencent/android/tpush/message/d;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)Landroid/widget/RemoteViews;
    .locals 19

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    const-string v2, "di"

    const-string v2, "id"

    const-string v2, "di"

    const-string v2, "id"

    const-string v3, "epaelbHMespre"

    const-string v3, "eespHrapMegle"

    const-string v3, "esMeesugeHlrp"

    const-string v3, "MessageHelper"

    const/4 v4, 0x0

    :try_start_0
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/d;->D()I

    move-result v6

    if-gtz v6, :cond_0

    const-string v0, "apstmycp nottv uyo qo dalel"

    const-string/jumbo v0, "yuntvateq ami  cyoot ldlops"

    const-string v0, " olt  acqipay utvmodsotleun"

    const-string/jumbo v0, "no valid custom layout type"

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    return-object v4

    :cond_0
    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/d;->C()Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_1

    return-object v4

    :cond_1
    new-instance v7, Lorg/json/JSONObject;

    invoke-direct {v7, v0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v8, "ltsaoyp romta:suma uc"

    const-string v8, "aosal:mtutoc u aymrps"

    const-string/jumbo v8, "uc mpylmot uaoa ms:rt"

    const-string v8, "custom layout param: "

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const-string/jumbo v8, "ttmootcumu_i_oatsoonyifcli"

    const-string/jumbo v8, "itnmclminoio_toatf_cuoyust"

    const-string v8, "cctn_b_iutifaonttosuaylmio"

    const-string v8, "custom_notification_layout"

    const-string/jumbo v9, "uaouyt"

    const-string v9, "aotuoy"

    const-string v9, "aptylu"

    const-string/jumbo v9, "layout"

    invoke-virtual {v0, v8, v9, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v8

    if-nez v8, :cond_2

    const-string/jumbo v0, "utcsai_tqitftoioonnnlb couyma"

    const-string/jumbo v0, "uctonbsootmtac_nifi tu_aniylo"

    const-string/jumbo v0, "ttsnmsfiot_oila you_ioctannco"

    const-string/jumbo v0, "no custom_notification_layout"

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    return-object v4

    :cond_2
    const-string v0, "coumlxtt_r"

    const-string/jumbo v0, "r_exctulto"

    const-string/jumbo v0, "ret_oootlx"

    const-string/jumbo v0, "text_color"

    invoke-virtual {v7, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    if-nez v0, :cond_3

    :try_start_1
    invoke-static {v9}, Landroid/graphics/Color;->parseColor(Ljava/lang/String;)I

    move-result v0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    move-object v11, v0

    move-object v11, v0

    move-object v11, v0

    move-object v11, v0

    :try_start_2
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v12, "S /ptb/crrolgp asrnio"

    const-string/jumbo v12, "sr  a/gpiolprS o/tcnr"

    const-string v12, "gr/oi urtn aSlpceos r"

    const-string/jumbo v12, "parse color String \""

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v9, ": rrr/ eq/"

    const-string/jumbo v9, "r/o r rp/e"

    const-string v9, "\" error: "

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v9

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v0, 0x0

    :goto_0
    new-instance v9, Landroid/widget/RemoteViews;

    invoke-direct {v9, v5, v8}, Landroid/widget/RemoteViews;-><init>(Ljava/lang/String;I)V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v8

    const-string/jumbo v11, "om_tsgbtqsaluuc_"

    const-string/jumbo v11, "t_sus_atmulcobgy"

    const-string/jumbo v11, "o_sbgaslmut_tuoc"

    const-string v11, "custom_layout_bg"

    invoke-virtual {v8, v11, v2, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v8

    if-nez v8, :cond_4

    return-object v4

    :cond_4
    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/a;->d()Ljava/lang/String;

    move-result-object v11

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/a;->e()Ljava/lang/String;

    move-result-object v12

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/d;->n()Ljava/lang/String;

    move-result-object v13

    invoke-static {v13}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v14

    if-eqz v14, :cond_5

    return-object v4

    :cond_5
    invoke-static {v13}, Lcom/tencent/android/tpush/message/b;->a(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v13

    if-nez v13, :cond_6

    const-string v0, "f dmoacetgauod  lydaiumlbmrsotalnuk "

    const-string/jumbo v0, "ydnmurib eckoulaafg tlu aaom sldoodt"

    const-string/jumbo v0, "n cuofi gt adroa aumsodduclaoellktoy"

    const-string v0, "custom layout load background failed"

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    return-object v4

    :cond_6
    const-string/jumbo v14, "teeosbne"

    const-string/jumbo v14, "nestomee"

    const-string v14, "eleetnum"

    const-string v14, "elements"

    const-string v15, "iMxbesgpehat"

    const-string v15, "iatexbhsetMg"

    const-string/jumbo v15, "xHseMgiaqett"

    const-string/jumbo v15, "setMaxHeight"

    const-string v10, "brsu_g"

    const-string/jumbo v10, "ubgur_"

    const-string v10, "g_umlr"

    const-string v10, "bg_url"

    const/4 v4, 0x1

    if-eq v6, v4, :cond_14

    const/4 v11, 0x2

    if-eq v6, v11, :cond_13

    const/4 v11, 0x3

    if-eq v6, v11, :cond_7

    const/4 v6, 0x0

    return-object v6

    :cond_7
    :try_start_3
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    const-string v11, "giblos_mtycuuo__otupotahtrt_no"

    const-string/jumbo v11, "phtmaoipuulbcutootg_r_oytns_t_"

    const-string v11, "_mocubbot_tottt_autgurns_lihop"

    const-string v11, "custom_layout_top_right_button"

    invoke-virtual {v6, v11, v2, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v6

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v11

    const-string v15, "_cnsocut__ootphy_lgutqiumoti"

    const-string/jumbo v15, "p_yt_oihqnl_tcstruio_otmucgo"

    const-string/jumbo v15, "tmcshlipgoo_ucatypnioout_r_t"

    const-string v15, "custom_layout_top_right_icon"

    invoke-virtual {v11, v15, v2, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v11

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v15

    const-string/jumbo v4, "t_c_ttotqnmbto_smntcouuaoelo"

    const-string v4, "__sabtcotnmc_stutuotoemootln"

    const-string/jumbo v4, "ltsomneatmuo__oubotoctnt_stc"

    const-string v4, "custom_layout_bottom_content"

    invoke-virtual {v15, v4, v2, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v15

    move/from16 v17, v8

    move/from16 v17, v8

    move/from16 v17, v8

    move/from16 v17, v8

    const-string/jumbo v8, "yitm_mmt__eumasolcaostotbomtpu"

    const-string/jumbo v8, "olamcetpoam_tmt_bu_ttusyotmiso"

    const-string v8, "custom_layout_bottom_timestamp"

    invoke-virtual {v15, v8, v2, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v8

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v15

    move-object/from16 v18, v13

    move-object/from16 v18, v13

    move-object/from16 v18, v13

    move-object/from16 v18, v13

    const-string/jumbo v13, "yuoroltsmnu_cbamoa_i3__ato"

    const-string/jumbo v13, "tc_soo_lt_o_baradna3muumoy"

    const-string v13, "custom_layout_main_board_3"

    invoke-virtual {v15, v13, v2, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    if-eqz v6, :cond_12

    if-eqz v11, :cond_12

    if-eqz v4, :cond_12

    if-eqz v8, :cond_12

    if-nez v2, :cond_8

    goto/16 :goto_4

    :cond_8
    invoke-static {v12}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_9

    const-string v0, "  setby3nunbctoeb luu oclon pltumy tt"

    const-string/jumbo v0, "nn ccbtue eolo3s um lb pyntulatoy utt"

    const-string v0, " ulctnuomust olyte upcnauo3t ntt yl b"

    const-string v0, "custom layout type 3 but null content"

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x0

    return-object v1

    :cond_9
    invoke-virtual {v7, v14}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    if-eqz v5, :cond_10

    const-string v7, "bou_ttuhnoipr_tg"

    const-string/jumbo v7, "top_right_button"

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    if-eqz v5, :cond_10

    const-string/jumbo v7, "txte"

    const-string/jumbo v7, "xett"

    const-string/jumbo v7, "xtte"

    const-string/jumbo v7, "text"

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const-string/jumbo v13, "ippnao"

    const-string/jumbo v13, "opcnia"

    const-string v13, "action"

    invoke-virtual {v5, v13}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v13

    invoke-static {v7}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v14

    if-nez v14, :cond_f

    if-nez v13, :cond_a

    goto/16 :goto_2

    :cond_a
    new-instance v14, Lcom/tencent/android/tpush/message/d$a;

    invoke-direct {v14}, Lcom/tencent/android/tpush/message/d$a;-><init>()V

    invoke-virtual {v13}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v14, v13}, Lcom/tencent/android/tpush/message/d$a;->a(Ljava/lang/String;)V

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    move-object/from16 v13, p1

    const/4 v15, 0x0

    invoke-static {v1, v14, v15, v13, v15}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;Lcom/tencent/android/tpush/message/d$a;ZLcom/tencent/android/tpush/message/PushMessageManager;Z)Landroid/content/Intent;

    move-result-object v13

    if-nez v13, :cond_b

    const-string v1, "ci ttdtuqctl uiatu nnt rgqxhnp iooneplnnoet bt"

    const-string v1, "c oeutrtqn ietietgcint npthtnlo u dbxt ponluan"

    const-string v1, "exshc otteodittcppuuenligr  bntitaultnen n o n"

    const-string/jumbo v1, "unexpected action top right button intent null"

    invoke-static {v3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_3

    :cond_b
    const/4 v15, 0x0

    invoke-virtual {v9, v6, v15}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    invoke-virtual {v9, v6, v7}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    if-eqz v0, :cond_c

    invoke-virtual {v9, v6, v0}, Landroid/widget/RemoteViews;->setTextColor(II)V

    :cond_c
    const-string/jumbo v7, "iusmsuttmsLoao"

    const-string/jumbo v7, "sLsaoostytuuim"

    const-string/jumbo v7, "yoCuoaoLisustt"

    const-string/jumbo v7, "isCustomLayout"

    const/4 v15, 0x1

    invoke-virtual {v13, v7, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const-string v7, "LltumbyotsiBnCtnscCtoaukIui"

    const-string/jumbo v7, "isButtonClickInCustomLayout"

    invoke-virtual {v13, v7, v15}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    iget-object v7, v14, Lcom/tencent/android/tpush/message/d$a;->c:Lcom/tencent/android/tpush/message/d$a$a;

    if-eqz v7, :cond_d

    iget v7, v7, Lcom/tencent/android/tpush/message/d$a$a;->b:I

    if-lez v7, :cond_d

    goto :goto_1

    :cond_d
    const/high16 v7, 0x8000000

    :goto_1
    sget v14, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v15, 0x1f

    if-lt v14, v15, :cond_e

    const/high16 v14, 0x2000000

    or-int/2addr v7, v14

    :cond_e
    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/d;->k()I

    move-result v14

    const/4 v15, 0x0

    invoke-virtual {v13, v15}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    invoke-static {v1, v14, v13, v7}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    invoke-virtual {v9, v6, v1}, Landroid/widget/RemoteViews;->setOnClickPendingIntent(ILandroid/app/PendingIntent;)V

    invoke-virtual {v5, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v6

    if-nez v6, :cond_10

    invoke-static {v5}, Lcom/tencent/android/tpush/message/b;->a(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v5

    if-eqz v5, :cond_10

    const/4 v6, 0x0

    invoke-virtual {v9, v11, v6}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    invoke-virtual {v9, v11, v5}, Landroid/widget/RemoteViews;->setImageViewBitmap(ILandroid/graphics/Bitmap;)V

    invoke-virtual {v9, v11, v1}, Landroid/widget/RemoteViews;->setOnClickPendingIntent(ILandroid/app/PendingIntent;)V

    goto :goto_3

    :cond_f
    :goto_2
    const-string v1, " tutotuuoulubmlictsmoht b yui t ngarn3 ont p tlepf "

    const-string/jumbo v1, "tuomb f loolmsonuceyh g 3itt ntuptr u tylabntp tiu "

    const-string v1, " bontc puut insotyrmteuullipnolagu  ohtpt   yo3btt "

    const-string v1, "custom layout type 3 but null top right button info"

    invoke-static {v3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_10
    :goto_3
    new-instance v1, Ljava/text/SimpleDateFormat;

    const-string/jumbo v5, "qamohm :"

    const-string v5, "aha:omm "

    const-string v5, "hasmamh "

    const-string v5, "hh:mm aa"

    invoke-direct {v1, v5}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    new-instance v5, Ljava/util/Date;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    invoke-direct {v5, v6, v7}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v5}, Ljava/util/Date;->getTime()J

    move-result-wide v5

    invoke-static {v5, v6}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v5

    invoke-virtual {v1, v5}, Ljava/text/Format;->format(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v4, v12}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    invoke-virtual {v9, v8, v1}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    if-eqz v0, :cond_11

    invoke-virtual {v9, v4, v0}, Landroid/widget/RemoteViews;->setTextColor(II)V

    invoke-virtual {v9, v8, v0}, Landroid/widget/RemoteViews;->setTextColor(II)V

    :cond_11
    move/from16 v4, v17

    move/from16 v4, v17

    move/from16 v4, v17

    move/from16 v4, v17

    move-object/from16 v6, v18

    move-object/from16 v6, v18

    invoke-virtual {v9, v4, v6}, Landroid/widget/RemoteViews;->setImageViewBitmap(ILandroid/graphics/Bitmap;)V

    const/4 v1, 0x0

    invoke-virtual {v9, v2, v1}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    return-object v9

    :cond_12
    :goto_4
    const/4 v1, 0x0

    return-object v1

    :cond_13
    move v4, v8

    move v4, v8

    move v4, v8

    move v4, v8

    move-object v6, v13

    move-object v6, v13

    move-object v6, v13

    move-object v6, v13

    const/16 v0, 0x78

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v0

    invoke-virtual {v9, v4, v15, v0}, Landroid/widget/RemoteViews;->setInt(ILjava/lang/String;I)V

    invoke-virtual {v9, v4, v6}, Landroid/widget/RemoteViews;->setImageViewBitmap(ILandroid/graphics/Bitmap;)V

    return-object v9

    :cond_14
    move v4, v8

    move v4, v8

    move v4, v8

    move-object v6, v13

    move-object v6, v13

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v8

    const-string/jumbo v13, "tlomul_csu_yeottmit"

    const-string v13, "custom_layout_title"

    invoke-virtual {v8, v13, v2, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v8

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v13

    move-object/from16 v16, v15

    move-object/from16 v16, v15

    move-object/from16 v16, v15

    move-object/from16 v16, v15

    const-string/jumbo v15, "moy_otlsnt_etcoatuunc"

    const-string v15, "custom_layout_content"

    invoke-virtual {v13, v15, v2, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v13

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v15

    const-string/jumbo v1, "t__tebnocutollucfaiom_s"

    const-string v1, "afotybutteo_slmi__nuloc"

    const-string v1, "custom_layout_icon_left"

    invoke-virtual {v15, v1, v2, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v15

    move/from16 v17, v4

    move/from16 v17, v4

    move/from16 v17, v4

    const-string v4, "cusoatuygltimon_uri_hc_u"

    const-string/jumbo v4, "mlnatcucg__t_uosouyitirh"

    const-string/jumbo v4, "tu_iogypcucnalsr_iomo_th"

    const-string v4, "custom_layout_icon_right"

    invoke-virtual {v15, v4, v2, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v15

    move-object/from16 v18, v6

    move-object/from16 v18, v6

    move-object/from16 v18, v6

    move-object/from16 v18, v6

    const-string v6, "_bpumtayqo_mc_dtsinarloo"

    const-string/jumbo v6, "u_yn_d_pirauootcolbsammt"

    const-string/jumbo v6, "ilsyuua_nmoo_tbadatrcsom"

    const-string v6, "custom_layout_main_board"

    invoke-virtual {v15, v6, v2, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v2

    if-eqz v8, :cond_20

    if-eqz v13, :cond_20

    if-eqz v1, :cond_20

    if-eqz v4, :cond_20

    if-nez v2, :cond_15

    goto/16 :goto_7

    :cond_15
    invoke-static {v11}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_16

    invoke-static {v12}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    if-eqz v5, :cond_16

    const-string v0, "cy mlteu t tt u1tnpdeybuslati emonqa  conltotu "

    const-string v0, "cttyct iqatao um upoel ntnye o ntsunutblt  1edl"

    const-string/jumbo v0, "ttiuontu1nol d tclaoetou bsp tlcm u yt a enyenl"

    const-string v0, "custom layout type 1 but null title and content"

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x0

    return-object v1

    :cond_16
    invoke-virtual {v7, v14}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const-string v6, ""

    const-string v6, ""

    const-string v6, ""

    const-string v6, ""

    if-eqz v5, :cond_19

    :try_start_4
    const-string/jumbo v7, "ti_cebofn"

    const-string/jumbo v7, "left_icon"

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v7

    if-eqz v7, :cond_17

    invoke-virtual {v7, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    goto :goto_5

    :cond_17
    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    move-object v7, v6

    :goto_5
    const-string v11, "cntsoguhr_"

    const-string v11, "icsr_gtnho"

    const-string v11, "gcirtonpi_"

    const-string/jumbo v11, "right_icon"

    invoke-virtual {v5, v11}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v5

    if-eqz v5, :cond_18

    invoke-virtual {v5, v10}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :cond_18
    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    move-object v6, v7

    goto :goto_6

    :cond_19
    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    move-object v5, v6

    :goto_6
    invoke-static {v6}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v7

    if-eqz v7, :cond_1a

    const/4 v7, 0x0

    return-object v7

    :cond_1a
    const/4 v7, 0x0

    invoke-static {v6}, Lcom/tencent/android/tpush/message/b;->a(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v6

    if-nez v6, :cond_1b

    const-string v0, "ccdyfm oqalloeu  mnulei satto aflot"

    const-string v0, "adtmodlln  camltueoi o uytsffaloce "

    const-string/jumbo v0, "lcseoaduotctyolafl a n lotdmuiis f "

    const-string v0, "custom layout load left icon failed"

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    return-object v7

    :cond_1b
    invoke-virtual {v9, v1, v6}, Landroid/widget/RemoteViews;->setImageViewBitmap(ILandroid/graphics/Bitmap;)V

    invoke-static {v5}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-nez v1, :cond_1c

    invoke-static {v5}, Lcom/tencent/android/tpush/message/b;->a(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v1

    if-eqz v1, :cond_1c

    invoke-virtual {v9, v4, v1}, Landroid/widget/RemoteViews;->setImageViewBitmap(ILandroid/graphics/Bitmap;)V

    :cond_1c
    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/a;->d()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/16 v4, 0x8

    if-eqz v1, :cond_1d

    invoke-virtual {v9, v8, v4}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    :cond_1d
    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/a;->e()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_1e

    invoke-virtual {v9, v13, v4}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    :cond_1e
    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/a;->d()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v8, v1}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/a;->e()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v9, v13, v1}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    if-eqz v0, :cond_1f

    invoke-virtual {v9, v8, v0}, Landroid/widget/RemoteViews;->setTextColor(II)V

    invoke-virtual {v9, v13, v0}, Landroid/widget/RemoteViews;->setTextColor(II)V

    :cond_1f
    move/from16 v0, v17

    move/from16 v0, v17

    move/from16 v0, v17

    move-object/from16 v1, v18

    move-object/from16 v1, v18

    move-object/from16 v1, v18

    move-object/from16 v1, v18

    invoke-virtual {v9, v0, v1}, Landroid/widget/RemoteViews;->setImageViewBitmap(ILandroid/graphics/Bitmap;)V

    const/16 v1, 0x50

    move-object/from16 v4, p0

    move-object/from16 v4, p0

    invoke-static {v4, v1}, Lcom/tencent/android/tpush/inappmessage/SizeUtil;->dpToPx(Landroid/content/Context;I)I

    move-result v1

    move-object/from16 v4, v16

    move-object/from16 v4, v16

    move-object/from16 v4, v16

    invoke-virtual {v9, v0, v4, v1}, Landroid/widget/RemoteViews;->setInt(ILjava/lang/String;I)V

    const/4 v1, 0x0

    invoke-virtual {v9, v2, v1}, Landroid/widget/RemoteViews;->setViewVisibility(II)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    return-object v9

    :cond_20
    :goto_7
    const/4 v1, 0x0

    return-object v1

    :catchall_1
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v2, "oeVmo:sCutmorwe tmsRe eroers"

    const-string v2, "Rrerotwrem:V useCitosom seoe"

    const-string/jumbo v2, "setCustomRemoteViews error: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x0

    return-object v1
.end method

.method public static declared-synchronized a(Landroid/content/Context;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 4

    const/4 v3, 0x1

    const-class p0, Lcom/tencent/android/tpush/message/b;

    const-class p0, Lcom/tencent/android/tpush/message/b;

    const/4 v3, 0x0

    const-class p0, Lcom/tencent/android/tpush/message/b;

    const-class p0, Lcom/tencent/android/tpush/message/b;

    const/4 v3, 0x5

    const/4 v2, 0x7

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x4

    new-instance v0, Lcom/tencent/android/tpush/XGBasicPushNotificationBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGBasicPushNotificationBuilder;-><init>()V

    const/4 v3, 0x4

    const/16 v1, 0x10

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setFlags(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x4

    monitor-exit p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    return-object v0

    :catchall_0
    move-exception v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    monitor-exit p0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    throw v0
.end method

.method public static a(Landroid/content/Context;I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string/jumbo v0, "tosmob"

    const-string/jumbo v0, "tocsmb"

    const-string/jumbo v0, "ocmsub"

    const-string v0, "custom"

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo v1, "suabc"

    const/4 v5, 0x1

    const-string v1, "auicb"

    const-string v1, "basic"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v2, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x7

    if-nez p0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-object v2

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/message/b;->a(I)Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p0, v3, v2}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v3, "lgeHaeMpeepsr"

    const-string v3, "aegesslpHreeM"

    const/4 v5, 0x5

    const-string/jumbo v3, "seeHraeeqlpsM"

    const-string v3, "MessageHelper"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz p0, :cond_3

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance p1, Lorg/json/JSONObject;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {p1, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x4

    if-eqz p0, :cond_1

    const/4 v5, 0x3

    new-instance p0, Lcom/tencent/android/tpush/XGBasicPushNotificationBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpush/XGBasicPushNotificationBuilder;-><init>()V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_1

    :try_start_1
    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_1
    .catch Lorg/json/JSONException; {:try_start_1 .. :try_end_1} :catch_0

    :goto_0
    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto :goto_1

    :catch_0
    move-exception p1

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    move-object v2, p0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    goto :goto_2

    :cond_1
    :try_start_2
    const/4 v5, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->has(Ljava/lang/String;)Z

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x5

    if-eqz p0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance p0, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;-><init>()V
    :try_end_2
    .catch Lorg/json/JSONException; {:try_start_2 .. :try_end_2} :catch_1

    :try_start_3
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1
    :try_end_3
    .catch Lorg/json/JSONException; {:try_start_3 .. :try_end_3} :catch_0

    const/4 v5, 0x4

    const/4 v4, 0x7

    goto :goto_0

    :goto_1
    :try_start_4
    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->decode(Ljava/lang/String;)V
    :try_end_4
    .catch Lorg/json/JSONException; {:try_start_4 .. :try_end_4} :catch_1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    goto :goto_3

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    return-object v2

    :catch_1
    move-exception p1

    :goto_2
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-string/jumbo p0, "rnsu etilqdntcigiex fiftNeecopBroduta"

    const-string/jumbo p0, "nttantelqBfiitiie gfx ooedopucurNcerd"

    const/4 v5, 0x0

    const-string/jumbo p0, "oNtm e xulatdgtfcriBeedoeuointirpncie"

    const-string/jumbo p0, "unexpected for getNotificationBuilder"

    const/4 v4, 0x1

    move v5, v4

    invoke-static {v3, p0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    goto :goto_3

    :cond_3
    const/4 v4, 0x4

    move v5, v4

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v0, "cuttohnoiiPaunounBef :tsorlNsiidf o"

    const-string v0, " csidl uatBio:oNonrsiu fuiefnoPhtnt"

    const/4 v5, 0x4

    const-string/jumbo v0, "tiantbnnPo edrhouNfi:olBtdcui fosiu"

    const-string v0, "PushNotificationBuilder not found :"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    :goto_3
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-object v2
.end method

.method private static a(I)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string v1, "IDUSHUuPI__LTDB_OTFm"

    const-string v1, "FLImSUO__ITHIDBUPDT_"

    const/4 v3, 0x1

    const-string v1, "NHID__PpTBISOUTDUIL_"

    const-string v1, "TPUSH_NOTIF_BUILDID_"

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {p0}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-object p0
.end method

.method public static a(Landroid/content/Context;ILcom/tencent/android/tpush/XGPushNotificationBuilder;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/message/b;->a(I)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x7

    new-instance v0, Lorg/json/JSONObject;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p2, v0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->encode(Lorg/json/JSONObject;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-instance v1, Lorg/json/JSONObject;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {p2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getType()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {v1, p2, v0}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->jsonPut(Lorg/json/JSONObject;Ljava/lang/String;Ljava/lang/Object;)Z

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {v1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p0, p1, p2}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method

.method public static a(Landroid/content/Context;Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V
    .locals 23
    .annotation build Lcom/jg/JgMethodChecked;
        author = 0x1
        fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
        lastDate = "20150316"
        reviewer = 0x3
        vComment = {
            .enum Lcom/jg/EType;->RECEIVERCHECK:Lcom/jg/EType;,
            .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;
        }
    .end annotation

    move-object/from16 v9, p0

    move-object/from16 v9, p0

    move-object/from16 v9, p0

    const/4 v0, 0x1

    if-nez p1, :cond_0

    move-object v7, v9

    move-object v7, v9

    move-object v7, v9

    move-object v7, v9

    const/4 v8, 0x0

    goto :goto_0

    :cond_0
    move-object/from16 v7, p1

    move-object/from16 v7, p1

    move-object/from16 v7, p1

    move-object/from16 v7, p1

    move v8, v0

    move v8, v0

    move v8, v0

    move v8, v0

    :goto_0
    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMessageHolder()Lcom/tencent/android/tpush/message/a;

    move-result-object v1

    move-object v11, v1

    move-object v11, v1

    move-object v11, v1

    move-object v11, v1

    check-cast v11, Lcom/tencent/android/tpush/message/d;

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/d;->l()Lcom/tencent/android/tpush/message/d$a;

    move-result-object v1

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/d;->g()I

    move-result v2

    invoke-static {v9, v2}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    move-result-object v2

    if-eqz v2, :cond_1

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/d;->u()I

    move-result v3

    if-ne v3, v0, :cond_2

    :cond_1
    invoke-static {v9, v11, v2}, Lcom/tencent/android/tpush/message/b;->b(Landroid/content/Context;Lcom/tencent/android/tpush/message/d;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    move-result-object v2

    :cond_2
    move-object v12, v2

    move-object v12, v2

    move-object v12, v2

    move-object v12, v2

    invoke-static {v9, v11, v12}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;Lcom/tencent/android/tpush/message/d;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/a;->f()Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_3

    const-string/jumbo v3, "{}"

    const-string/jumbo v3, "}{"

    const-string/jumbo v3, "{}"

    invoke-virtual {v3, v2}, Ljava/lang/String;->equalsIgnoreCase(Ljava/lang/String;)Z

    move-result v2

    if-nez v2, :cond_3

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move v3, v0

    move v3, v0

    move v3, v0

    move v3, v0

    goto :goto_1

    :cond_3
    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    const/4 v3, 0x0

    :goto_1
    invoke-static {v9, v1, v3, v2, v8}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;Lcom/tencent/android/tpush/message/d$a;ZLcom/tencent/android/tpush/message/PushMessageManager;Z)Landroid/content/Intent;

    move-result-object v15

    const-string/jumbo v13, "peelaosgqMser"

    const-string/jumbo v13, "slMaoesgpeere"

    const-string v13, "gesHeaesrlpMs"

    const-string v13, "MessageHelper"

    if-nez v15, :cond_4

    const-string v0, "bx mutoichnnnA det,Nre aeieeiittcl- cmtospt lcoutitawftnenoo na>i n"

    const-string v0, "eanonbleu,>tNcu encriixafnn eda owttlecptoi oc nstio nttiitei A-thm"

    const-string v0, ",wntorf>eos  iin-tde n oimtacueleinnctoAacititnNeuclxt tphte i oaon"

    const-string/jumbo v0, "unexpected action intent null, Action -> showNotification terminate"

    invoke-static {v13, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_4
    const-string/jumbo v3, "iinoabconitu"

    const-string/jumbo v3, "nniiicuoatot"

    const-string/jumbo v3, "onitocutfnii"

    const-string/jumbo v3, "notification"

    invoke-virtual {v9, v3}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v3

    move-object v14, v3

    move-object v14, v3

    check-cast v14, Landroid/app/NotificationManager;

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/d;->k()I

    move-result v6

    const/4 v3, -0x1

    if-ne v6, v3, :cond_5

    invoke-virtual {v14}, Landroid/app/NotificationManager;->cancelAll()V

    :cond_5
    iget-object v1, v1, Lcom/tencent/android/tpush/message/d$a;->c:Lcom/tencent/android/tpush/message/d$a$a;

    if-eqz v1, :cond_6

    iget v1, v1, Lcom/tencent/android/tpush/message/d$a$a;->b:I

    if-lez v1, :cond_6

    goto :goto_2

    :cond_6
    const/high16 v1, 0x8000000

    :goto_2
    const/high16 v3, 0x2000000

    or-int v5, v1, v3

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object/from16 v2, p2

    move-object v3, v11

    move-object v3, v11

    move-object v3, v11

    move-object v3, v11

    move-object v4, v12

    move-object v4, v12

    move-object v4, v12

    move-object v4, v12

    move/from16 p1, v5

    move/from16 p1, v5

    move/from16 p1, v5

    move/from16 p1, v5

    move v5, v6

    move v5, v6

    move v10, v6

    move v10, v6

    move v10, v6

    move/from16 v6, p1

    move/from16 v6, p1

    move/from16 v6, p1

    move/from16 v6, p1

    invoke-static/range {v1 .. v6}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;Lcom/tencent/android/tpush/message/d;Lcom/tencent/android/tpush/XGPushNotificationBuilder;II)Z

    move-result v6

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/d;->D()I

    move-result v1

    if-lez v1, :cond_7

    if-nez v6, :cond_7

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/a;->d()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_7

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/a;->e()Ljava/lang/String;

    move-result-object v1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    if-eqz v1, :cond_7

    const-string/jumbo v0, "nllncenps luyoucnt eoutau ot tbtittad L"

    const-string v0, "customLayout but title and content null"

    invoke-static {v13, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_7
    const-string/jumbo v5, "yissomtuqCLtao"

    const-string/jumbo v5, "taystuLposCimo"

    const-string/jumbo v5, "mustuiLoCystao"

    const-string/jumbo v5, "isCustomLayout"

    invoke-virtual {v15, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    sget-object v1, Lcom/tencent/android/tpush/message/b;->a:Landroid/content/BroadcastReceiver;

    const/4 v2, 0x4

    const-string v3, "CT.mSASUq_HPE_PPULARNELCLD"

    const-string v3, "ULPLNRLDqC_PASESETPECH_AU."

    const-string v3, "RE_.oTLLUCNPAEP_SAD.LCPSHE"

    const-string v3, ".APP_PUSH_CANCELLED.RESULT"

    if-nez v1, :cond_8

    new-instance v1, Lcom/tencent/android/tpush/message/b$1;

    invoke-direct {v1}, Lcom/tencent/android/tpush/message/b$1;-><init>()V

    sput-object v1, Lcom/tencent/android/tpush/message/b;->a:Landroid/content/BroadcastReceiver;

    new-instance v1, Landroid/content/IntentFilter;

    invoke-direct {v1}, Landroid/content/IntentFilter;-><init>()V

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    sget-object v0, Lcom/tencent/android/tpush/message/b;->a:Landroid/content/BroadcastReceiver;

    invoke-static {v7, v0, v1, v2}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V

    :cond_8
    new-instance v0, Landroid/content/Intent;

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual {v7}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v1, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual {v7}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v1, "kaepmbNs"

    const-string/jumbo v1, "mksNeapa"

    const-string v1, "aepkaNum"

    const-string/jumbo v1, "packName"

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v1, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    sget-object v1, Lcom/tencent/android/tpush/NotificationAction;->delete:Lcom/tencent/android/tpush/NotificationAction;

    invoke-virtual {v1}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v1

    const-string/jumbo v3, "mpcnao"

    const-string v3, "caomni"

    const-string/jumbo v3, "tcqano"

    const-string v3, "action"

    invoke-virtual {v0, v3, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    invoke-virtual {v0, v15}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    if-nez v8, :cond_9

    move/from16 v3, p1

    move/from16 v3, p1

    move/from16 v3, p1

    invoke-static {v9, v10, v15, v3}, Landroid/app/PendingIntent;->getActivity(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v4

    invoke-virtual {v12, v4}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setContentIntent(Landroid/app/PendingIntent;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    goto :goto_3

    :cond_9
    move/from16 v3, p1

    move/from16 v3, p1

    move/from16 v3, p1

    move/from16 v3, p1

    const/16 v4, 0x1a

    if-lt v1, v4, :cond_a

    const/4 v4, 0x1

    invoke-virtual {v12, v4}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setRunAsSysAndAndBuildSdk26(Z)V

    :cond_a
    :goto_3
    sget-object v4, Lcom/tencent/android/tpush/message/b;->b:Landroid/content/BroadcastReceiver;

    if-nez v4, :cond_b

    new-instance v4, Lcom/tencent/android/tpush/message/b$2;

    invoke-direct {v4}, Lcom/tencent/android/tpush/message/b$2;-><init>()V

    sput-object v4, Lcom/tencent/android/tpush/message/b;->b:Landroid/content/BroadcastReceiver;

    new-instance v4, Landroid/content/IntentFilter;

    invoke-direct {v4}, Landroid/content/IntentFilter;-><init>()V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 p2, v5

    move-object/from16 p2, v5

    move-object/from16 p2, v5

    move-object/from16 p2, v5

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "A_P.oLP_IMD.PEAAHPYS"

    const-string v5, "PLsA_PPEI.AUMHPA.D_Y"

    const-string v5, ".APP_PUSH_MEDIA.PLAY"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v5, "TEOmUIHA.PS_.bDPP_PS"

    const-string v5, "ETHDPb_ASMISPP.U_PO."

    const-string v5, "ESAPo_OP.PMIH.UPSDTA"

    const-string v5, ".APP_PUSH_MEDIA.STOP"

    invoke-virtual {v2, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v4, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    sget-object v2, Lcom/tencent/android/tpush/message/b;->b:Landroid/content/BroadcastReceiver;

    const/4 v5, 0x4

    invoke-static {v9, v2, v4, v5}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V

    goto :goto_4

    :cond_b
    move-object/from16 p2, v5

    move-object/from16 p2, v5

    move-object/from16 p2, v5

    move-object/from16 p2, v5

    :goto_4
    invoke-virtual {v12, v9}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->buildNotification(Landroid/content/Context;)Landroid/util/Pair;

    move-result-object v2

    iget-object v4, v2, Landroid/util/Pair;->first:Ljava/lang/Object;

    move-object v5, v4

    move-object v5, v4

    move-object v5, v4

    check-cast v5, Landroid/app/Notification;

    iget-object v2, v2, Landroid/util/Pair;->second:Ljava/lang/Object;

    invoke-static {v7, v10, v0, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    iput-object v0, v5, Landroid/app/Notification;->deleteIntent:Landroid/app/PendingIntent;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    invoke-static {v7, v0}, Lcom/tencent/android/tpush/common/j;->d(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/d;->x()I

    move-result v4

    const/4 v7, 0x1

    if-ne v4, v7, :cond_c

    if-eqz v0, :cond_c

    const/4 v4, 0x1

    goto :goto_5

    :cond_c
    const/4 v4, 0x0

    :goto_5
    new-instance v7, Ljava/lang/StringBuilder;

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    move-object/from16 p1, v15

    move-object/from16 p1, v15

    move-object/from16 p1, v15

    move-object/from16 p1, v15

    const-string/jumbo v15, "yu__sbhopi:es"

    const-string v15, "h:eopiutsys__"

    const-string/jumbo v15, "ipwss_u_heot:"

    const-string/jumbo v15, "is_show_type:"

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/d;->x()I

    move-result v15

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v15, " ,eFdrrpounon:g"

    const-string v15, ", OnForeground:"

    invoke-virtual {v7, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v7, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v13, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const-string v0, "O ouppgFqrnopard"

    const-string v0, "au drpOpepFnrogo"

    const-string v0, "FrsroonapneOgdup"

    const-string v0, "appOnForeground "

    if-eqz v8, :cond_f

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getSysNotifactionCallback()Lcom/tencent/android/tpush/XGSysPushNotifactionCallback;

    move-result-object v1

    if-nez v1, :cond_d

    const-string/jumbo v0, "s bm,tkiotqar nnh foCc!uSactriEXo yls lPonGiin "

    const-string/jumbo v0, "u rastllqEotyt oCoX ckca!Grh, iinobfSni r Pnins"

    const-string v0, "fsbcoCr  rnick!io ,aolauinntnrPSX   oEiyGhtaost"

    const-string v0, "XG Sys Push init Error, no notifactionCallback!"

    invoke-static {v13, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_d
    if-eqz v4, :cond_e

    invoke-static {v13, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    goto :goto_6

    :cond_e
    new-instance v0, Lcom/tencent/android/tpush/XGSysNotifaction;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v14

    move-object v13, v0

    move-object v13, v0

    move-object v13, v0

    move-object v13, v0

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    move v15, v10

    move v15, v10

    move v15, v10

    move v15, v10

    move-object/from16 v16, v5

    move-object/from16 v16, v5

    move-object/from16 v16, v5

    move-object/from16 v16, v5

    move-object/from16 v17, v8

    move-object/from16 v17, v8

    move-object/from16 v17, v8

    move-object/from16 v17, v8

    move/from16 v18, v3

    move/from16 v18, v3

    move/from16 v18, v3

    move-object/from16 v19, v2

    move-object/from16 v19, v2

    move-object/from16 v19, v2

    move-object/from16 v19, v2

    invoke-direct/range {v13 .. v19}, Lcom/tencent/android/tpush/XGSysNotifaction;-><init>(Ljava/lang/String;ILandroid/app/Notification;Landroid/content/Intent;ILjava/lang/Object;)V

    invoke-interface {v1, v0}, Lcom/tencent/android/tpush/XGSysPushNotifactionCallback;->handleNotify(Lcom/tencent/android/tpush/XGSysNotifaction;)V

    goto :goto_6

    :cond_f
    move-object/from16 v8, p1

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    move-object/from16 v8, p1

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getNotifactionCallback()Lcom/tencent/android/tpush/XGPushNotifactionCallback;

    move-result-object v3

    if-nez v3, :cond_10

    invoke-virtual {v12, v9}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->needAutoFilterNotification(Landroid/content/Context;)Z

    move-result v7

    if-eqz v7, :cond_10

    const-string/jumbo v0, "u ptpbsnNertgbiaiaeci lshc we dfmoauios"

    const-string/jumbo v0, "iushN icpdgboriufclet witoaisp  msaaeen"

    const-string v0, "amroauu tNuin sth sdio icawclopeeiipgbf"

    const-string v0, "drop huawei public message Notification"

    invoke-static {v13, v0}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_10
    if-eqz v2, :cond_11

    invoke-static {v9, v2, v12}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->createNotificationChannel(Landroid/content/Context;Ljava/lang/Object;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V

    :cond_11
    if-eqz v4, :cond_12

    invoke-static {v13, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :goto_6
    move-object/from16 v20, p2

    move-object/from16 v20, p2

    move-object/from16 v20, p2

    move-object/from16 v20, p2

    move/from16 v21, v6

    move/from16 v21, v6

    move/from16 v21, v6

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    goto/16 :goto_a

    :cond_12
    if-nez v3, :cond_18

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/d;->y()I

    move-result v0

    const/4 v2, -0x2

    if-ne v0, v2, :cond_13

    const/4 v2, 0x1

    invoke-static {v9, v2}, Lcom/tencent/android/tpush/XGPushConfig;->changeHuaweiBadgeNum(Landroid/content/Context;I)V

    goto :goto_7

    :cond_13
    if-ltz v0, :cond_14

    invoke-static {v9, v0}, Lcom/tencent/android/tpush/XGPushConfig;->setBadgeNum(Landroid/content/Context;I)V

    :cond_14
    :goto_7
    :try_start_0
    invoke-static {}, Lcom/tencent/android/tpush/d/d;->j()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/d;->z()Ljava/lang/String;

    move-result-object v15

    invoke-static {v15}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    if-nez v2, :cond_17

    const/16 v2, 0x18

    if-lt v1, v2, :cond_17

    const-string/jumbo v1, "oopp"

    const-string/jumbo v1, "oopp"

    const-string/jumbo v1, "ppoo"

    const-string/jumbo v1, "oppo"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    if-nez v1, :cond_17

    if-eqz v6, :cond_15

    const-string/jumbo v1, "ivov"

    const-string/jumbo v1, "oivv"

    const-string/jumbo v1, "ivov"

    const-string/jumbo v1, "vivo"

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_17

    :cond_15
    if-eqz v6, :cond_16

    invoke-virtual {v12}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getCustomLayoutType()I

    move-result v0

    const/4 v1, 0x3

    if-ne v0, v1, :cond_16

    invoke-virtual {v12, v9}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->isSupportNotificationGroup(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_17

    :cond_16
    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/d;->A()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v12}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getSmallIcon()Ljava/lang/Integer;

    move-result-object v1

    invoke-virtual {v1}, Ljava/lang/Integer;->intValue()I

    move-result v7

    invoke-virtual {v12}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getColor()Ljava/lang/Integer;

    move-result-object v16

    invoke-virtual {v12}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getCurrentChannelId()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v11}, Lcom/tencent/android/tpush/message/a;->d()Ljava/lang/String;

    move-result-object v2

    invoke-virtual {v12}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getNotificationCategory()Ljava/lang/String;

    move-result-object v11
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object v4, v15

    move-object v4, v15

    move-object v4, v15

    move-object v4, v15

    move-object/from16 v20, p2

    move-object/from16 v20, p2

    move-object/from16 v20, p2

    move-object v12, v5

    move-object v12, v5

    move-object v12, v5

    move-object v12, v5

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move/from16 v21, v6

    move/from16 v21, v6

    move/from16 v21, v6

    move v6, v7

    move v6, v7

    move v6, v7

    move v6, v7

    move-object/from16 v7, v16

    move-object/from16 v7, v16

    move-object/from16 v7, v16

    move-object/from16 v7, v16

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    move-object v8, v11

    move-object v8, v11

    move-object v8, v11

    :try_start_1
    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/Integer;Ljava/lang/String;)Landroid/app/Notification;

    move-result-object v0

    invoke-virtual {v15}, Ljava/lang/String;->hashCode()I

    move-result v1

    neg-int v1, v1

    invoke-virtual {v14, v1, v0}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "ohitsnrp mpfit gwoa iuoc"

    const-string/jumbo v1, "stpmo nghfaru owiioct io"

    const-string/jumbo v1, "wt n ongquriopfcoisi tao"

    const-string/jumbo v1, "show group notification "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v15}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v13, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    goto :goto_9

    :catchall_0
    move-exception v0

    goto :goto_8

    :cond_17
    move-object/from16 v20, p2

    move-object/from16 v20, p2

    move-object v12, v5

    move-object v12, v5

    move-object v12, v5

    move-object v12, v5

    move/from16 v21, v6

    move/from16 v21, v6

    move/from16 v21, v6

    move/from16 v21, v6

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    goto :goto_9

    :catchall_1
    move-exception v0

    move-object/from16 v20, p2

    move-object/from16 v20, p2

    move-object/from16 v20, p2

    move-object/from16 v20, p2

    move-object v12, v5

    move-object v12, v5

    move-object v12, v5

    move-object v12, v5

    move/from16 v21, v6

    move/from16 v21, v6

    move/from16 v21, v6

    move/from16 v21, v6

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    :goto_8
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "hos oirrc oira:etgsof tiow nuor"

    const-string/jumbo v2, "rgoooua:niowo   iechtifrrto spr"

    const-string/jumbo v2, "rotmcrfir sir i pwahoooeun :otg"

    const-string/jumbo v2, "show group notification error: "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v13, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_9
    invoke-virtual {v14, v10, v12}, Landroid/app/NotificationManager;->notify(ILandroid/app/Notification;)V

    goto :goto_a

    :cond_18
    move-object/from16 v20, p2

    move-object/from16 v20, p2

    move-object/from16 v20, p2

    move-object/from16 v20, p2

    move-object v12, v5

    move-object v12, v5

    move-object v12, v5

    move-object v12, v5

    move/from16 v21, v6

    move/from16 v21, v6

    move/from16 v21, v6

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    move-object/from16 v22, v8

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, ":cnloooaaillcaCbiftcnatlb"

    const-string/jumbo v1, "ilCklbfaoinatb:acatncocll"

    const-string v1, "call notifactionCallback:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v12}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v13, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v0, Lcom/tencent/android/tpush/XGNotifaction;

    invoke-direct {v0, v9, v10, v12, v11}, Lcom/tencent/android/tpush/XGNotifaction;-><init>(Landroid/content/Context;ILandroid/app/Notification;Lcom/tencent/android/tpush/message/d;)V

    invoke-interface {v3, v0}, Lcom/tencent/android/tpush/XGPushNotifactionCallback;->handleNotify(Lcom/tencent/android/tpush/XGNotifaction;)V

    const-string v0, "gnOnaboropnouupt dre"

    const-string v0, "dgOao uppeFrnnurtoon"

    const-string/jumbo v0, "opOo ourF arndnegpnt"

    const-string/jumbo v0, "not appOnForeground "

    invoke-static {v13, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :goto_a
    new-instance v0, Landroid/content/Intent;

    const-string v1, "cdpntCepgnnE..in.tdEpcK..vAoaiBmoia.Ftoxrc"

    const-string v1, ".BpErnnpAitcFct.daEdDax.evmiocC..iKgt.nnoo"

    const-string v1, "AomreiEeqcopKgacx.nEiocCi.vtaD..Fn..Bnttdd"

    const-string v1, "com.tencent.android.xg.vip.action.FEEDBACK"

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const-string v1, "OCsDUEPqSRROTE."

    const-string v1, "DPSTO.REqRORCUE"

    const-string v1, "ORUmDHSRT.OREEP"

    const-string v1, "TPUSH.ERRORCODE"

    const/4 v2, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    move-object/from16 v1, v22

    move-object/from16 v1, v22

    invoke-virtual {v0, v1}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    const-string v1, "SB.HosUPAEFCDK"

    const-string v1, "TKsEAHSBPU.CFD"

    const-string v1, "KBU.PbHSCFETAD"

    const-string v1, "TPUSH.FEEDBACK"

    const/4 v2, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v1, "iinitcufo_tdmo"

    const-string/jumbo v1, "odimift_aicotn"

    const-string/jumbo v1, "nonicifpod_ati"

    const-string/jumbo v1, "notifaction_id"

    invoke-virtual {v0, v1, v10}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    move-object/from16 v2, v20

    move-object/from16 v2, v20

    move-object/from16 v2, v20

    move-object/from16 v2, v20

    move/from16 v1, v21

    move/from16 v1, v21

    move/from16 v1, v21

    move/from16 v1, v21

    invoke-virtual {v0, v2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    invoke-static {v9, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    return-void
.end method

.method public static a(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V
    .locals 5

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMessageHolder()Lcom/tencent/android/tpush/message/a;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    instance-of v0, v0, Lcom/tencent/android/tpush/message/d;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-eqz v0, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const-string/jumbo v1, "t Atsoitqincw o oNoo-nfh>ai"

    const-string/jumbo v1, "ocnioA ic oaft>iNtwsot -hon"

    const/4 v4, 0x5

    const-string/jumbo v1, "iisn- oc iwsfntAthNoac oo>t"

    const-string v1, "Action -> showNotification "

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getContent()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v1, "regmsbeeMHepa"

    const-string/jumbo v1, "peMeebHessrga"

    const/4 v4, 0x4

    const-string/jumbo v1, "raesogeMseleH"

    const-string v1, "MessageHelper"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMessageHolder()Lcom/tencent/android/tpush/message/a;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    check-cast v0, Lcom/tencent/android/tpush/message/d;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpush/message/d;->l()Lcom/tencent/android/tpush/message/d$a;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x3

    goto/16 :goto_0

    :cond_0
    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/f/a;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-eqz v0, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getAppPkgName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getAppPkgName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    or-int/2addr v4, v3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const-string v2, "htonebti: iccipoi  vfepao erratn"

    const-string/jumbo v2, "receive otehr app notification: "

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getAppPkgName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getAppPkgName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    const/4 v2, 0x3

    const/4 v4, 0x4

    invoke-virtual {p0, v0, v2}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {v0, p0, p1}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto :goto_1

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-static {p0, v0, p1}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string/jumbo p1, "iooufluias rohtNhwtn:weiTbo"

    const-string p1, "i:wtlouanhstoweofoNiriha bT"

    const/4 v4, 0x6

    const-string p1, "abtfawopwNl:cnhi ohTroeiois"

    const-string/jumbo p1, "showNotification Throwable:"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {v1, p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x7

    goto :goto_1

    :cond_2
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo p0, "nru oo (qocrtupsll tdi=ooa=e ld=entlnnA gfNe i.|lwl=hh t|)oci"

    const-string/jumbo p0, "l hh| =pooto(gos=cwNltfl|odhi  Adrioeu rulnacl = n=tenein)l.t"

    const/4 v4, 0x6

    const-string/jumbo p0, "nns =tlol.dii||w ofu(lotlhouoihligntn) el==ceAradN    oertc=h"

    const-string/jumbo p0, "showNotification holder == null || holder.getAction() == null"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method

.method private static a(Landroid/content/Context;Lcom/tencent/android/tpush/message/d;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->m()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-lez v0, :cond_0

    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->m()I

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p2, v0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setIcon(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->n()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x5

    const/4 v4, 0x4

    if-nez v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->r()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    sget-object v1, Lcom/tencent/android/tpush/message/b;->d:Landroid/graphics/Bitmap;

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/message/b;->a(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v1

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v0, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    sput-object v0, Lcom/tencent/android/tpush/message/b;->d:Landroid/graphics/Bitmap;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p2, v1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setRichIcon(Landroid/graphics/Bitmap;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getSmallIcon()Ljava/lang/Integer;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v0, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getLargeIcon()Landroid/graphics/Bitmap;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez v0, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getIcon()Ljava/lang/Integer;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    if-nez v0, :cond_4

    const/4 v5, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string v1, "ademqlrw"

    const-string/jumbo v1, "qelwdbra"

    const/4 v5, 0x1

    const-string/jumbo v1, "weraobal"

    const-string v1, "drawable"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string/jumbo v3, "oiotibtnfccosiain"

    const-string/jumbo v3, "iostofcntinoiican"

    const/4 v5, 0x2

    const-string/jumbo v3, "iintiiunaonoct_co"

    const-string/jumbo v3, "notification_icon"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {v0, v3, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    if-lez v0, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p2, v0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setSmallIcon(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x7

    goto :goto_1

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    iget v0, v0, Landroid/content/pm/ApplicationInfo;->icon:I

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p2, v0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setSmallIcon(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    :goto_1
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v1, v1, Landroid/content/pm/ApplicationInfo;->icon:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v0, v1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p2, v0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setLargeIcon(Landroid/graphics/Bitmap;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    :cond_4
    const/4 v5, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/a;->d()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p2, v0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setTitle(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/a;->e()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p2, v0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setTickerText(Ljava/lang/CharSequence;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->isEnableNotificationSound(Landroid/content/Context;)Z

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz p0, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->v()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-nez v0, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {p2, p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setChannelId(Ljava/lang/String;)V

    :cond_5
    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->w()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v5, 0x1

    const/4 v4, 0x0

    if-nez p0, :cond_6

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->w()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-virtual {p2, p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setChannelName(Ljava/lang/String;)V

    :cond_6
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->z()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-static {p0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-nez p0, :cond_7

    const/4 v5, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->z()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {p2, p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setThread_id(Ljava/lang/String;)V

    :cond_7
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-void
.end method

.method private static a(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;Lcom/tencent/android/tpush/message/d;Lcom/tencent/android/tpush/XGPushNotificationBuilder;II)Z
    .locals 16

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p3

    move-object/from16 v1, p3

    move-object/from16 v1, p3

    move-object/from16 v1, p3

    move/from16 v2, p4

    move/from16 v2, p4

    move/from16 v2, p4

    move/from16 v2, p4

    move/from16 v3, p5

    move/from16 v3, p5

    move/from16 v3, p5

    move/from16 v3, p5

    invoke-static/range {p0 .. p3}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;Lcom/tencent/android/tpush/message/d;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)Landroid/widget/RemoteViews;

    move-result-object v4

    const/4 v5, 0x1

    if-eqz v4, :cond_0

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/d;->D()I

    move-result v0

    invoke-virtual {v1, v0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setCustomLayoutType(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/d;->E()I

    move-result v0

    invoke-virtual {v1, v0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setUseStdStyle(I)V

    invoke-virtual {v1, v4}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setContentView(Landroid/widget/RemoteViews;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    invoke-virtual {v1, v4}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setbigContentView(Landroid/widget/RemoteViews;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    return v5

    :cond_0
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v4

    const-string/jumbo v6, "tpymau"

    const-string v6, "ayumlt"

    const-string/jumbo v6, "ltqaou"

    const-string/jumbo v6, "layout"

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    const-string/jumbo v8, "xg_notification"

    invoke-virtual {v4, v8, v6, v7}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v4

    const-string v6, "eossMlseepear"

    const-string/jumbo v6, "seeloMsaeeHpr"

    const-string v6, "eMgmseepalesr"

    const-string v6, "MessageHelper"

    const/4 v7, 0x0

    if-eqz v4, :cond_6

    const-string v8, "g_icoab tfiatnonhu aiosoxl"

    const-string/jumbo v8, "snic batoixfaouigothal _tn"

    const-string v8, "_c g bauxtfhnaolsayotoitni"

    const-string v8, "has xg_notification layout"

    invoke-static {v6, v8}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v6

    const-string v8, "aioctnuicxgf_n_itnuo"

    const-string/jumbo v8, "iica_gu_noicnxtofnto"

    const-string/jumbo v8, "nco_niiptato_ngxifco"

    const-string/jumbo v8, "xg_notification_icon"

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    const-string v10, "di"

    const-string v10, "id"

    const-string v10, "di"

    const-string v10, "id"

    invoke-virtual {v6, v8, v10, v9}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v6

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v8

    const-string/jumbo v9, "tetno_o_qceaxtn_ltlpsifitii"

    const-string/jumbo v9, "tiinoeoplsi_tlfeitctg__nxat"

    const-string v9, "clsi_yttsltoieftxainoe_tgi_"

    const-string/jumbo v9, "xg_notification_style_title"

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v8, v9, v10, v11}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v8

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v9

    const-string/jumbo v11, "qiomttfo_n_nxiaaeigc"

    const-string v11, "aetntn_fq_ootiigxcai"

    const-string/jumbo v11, "ittgoxtn_ideiofo_nca"

    const-string/jumbo v11, "xg_notification_date"

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v12

    invoke-virtual {v9, v11, v10, v12}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v9

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v11

    const-string/jumbo v12, "ling_bet_nfn_caiocooyttitexts"

    const-string/jumbo v12, "xg_notification_style_content"

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v13

    invoke-virtual {v11, v12, v10, v13}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v11

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v12

    const-string v13, "dnaytouift_ioaunxolgiascp_"

    const-string/jumbo v13, "xisgaouiiaoyt_idlanpnt_ofc"

    const-string v13, "ianidi_pxgoic_yupaato_nftl"

    const-string/jumbo v13, "xg_notification_audio_play"

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v14

    invoke-virtual {v12, v13, v10, v14}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v12

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v13

    const-string/jumbo v14, "uonitidoqnt_a_sai_fgptxico"

    const-string/jumbo v14, "xg_notification_audio_stop"

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v15

    invoke-virtual {v13, v14, v10, v15}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v10

    new-instance v13, Landroid/widget/RemoteViews;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v14

    invoke-direct {v13, v14, v4}, Landroid/widget/RemoteViews;-><init>(Ljava/lang/String;I)V

    if-eqz v6, :cond_3

    if-eqz v8, :cond_3

    if-eqz v11, :cond_3

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/a;->d()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v13, v8, v4}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/a;->e()Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v13, v11, v4}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/d;->r()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_2

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/d;->r()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/tencent/android/tpush/message/b;->a(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v4

    if-nez v4, :cond_1

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v4

    iget v4, v4, Landroid/content/pm/ApplicationInfo;->icon:I

    invoke-virtual {v13, v6, v4}, Landroid/widget/RemoteViews;->setImageViewResource(II)V

    goto :goto_0

    :cond_1
    invoke-virtual {v13, v6, v4}, Landroid/widget/RemoteViews;->setImageViewBitmap(ILandroid/graphics/Bitmap;)V

    goto :goto_0

    :cond_2
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v4

    iget v4, v4, Landroid/content/pm/ApplicationInfo;->icon:I

    invoke-virtual {v13, v6, v4}, Landroid/widget/RemoteViews;->setImageViewResource(II)V

    :cond_3
    :goto_0
    if-eqz v9, :cond_4

    new-instance v4, Ljava/text/SimpleDateFormat;

    const-string v6, ":msHH"

    const-string v6, ":HmmH"

    const-string v6, "HmHmm"

    const-string v6, "HH:mm"

    invoke-direct {v4, v6}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    new-instance v6, Ljava/util/Date;

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v14

    invoke-direct {v6, v14, v15}, Ljava/util/Date;-><init>(J)V

    invoke-virtual {v4, v6}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Ljava/lang/String;->valueOf(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v4

    invoke-virtual {v13, v9, v4}, Landroid/widget/RemoteViews;->setTextViewText(ILjava/lang/CharSequence;)V

    :cond_4
    if-eqz v12, :cond_5

    if-eqz v10, :cond_5

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/d;->o()Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v4

    if-nez v4, :cond_5

    invoke-virtual {v13, v12, v7}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    invoke-virtual {v13, v10, v7}, Landroid/widget/RemoteViews;->setViewVisibility(II)V

    new-instance v4, Landroid/content/Intent;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v7

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v7, "L.UAo_SM_oPIPYDAPA.E"

    const-string v7, "_ADPoM.PEPSYPAAL_UI."

    const-string v7, "M.A.UbPHSPALYI_P_DAP"

    const-string v7, ".APP_PUSH_MEDIA.PLAY"

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v6

    const-string/jumbo v8, "mudgb"

    const-string v8, "bdIgm"

    const-string v8, "Igpsd"

    const-string/jumbo v8, "msgId"

    invoke-virtual {v4, v8, v6, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/d;->o()Ljava/lang/String;

    move-result-object v6

    const-string v7, "d__mogcaqiree_sruesaoxuu"

    const-string/jumbo v7, "su__o_ueeuegimaorcdrsaxi"

    const-string v7, "eis_soorerdacidxg_umua_s"

    const-string/jumbo v7, "xg_media_audio_resources"

    invoke-virtual {v4, v7, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    const-string v9, "aepmNkmc"

    const-string/jumbo v9, "packName"

    invoke-virtual {v4, v9, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-static {v0, v2, v4, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v4

    invoke-virtual {v13, v12, v4}, Landroid/widget/RemoteViews;->setOnClickPendingIntent(ILandroid/app/PendingIntent;)V

    new-instance v4, Landroid/content/Intent;

    new-instance v6, Ljava/lang/StringBuilder;

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v11, "pI.ToHMOSP_PDSPAEAU_"

    const-string v11, "AHPTIOSpPAPP_EM.U_DS"

    const-string v11, "P.TP_bASIAEHSDPUPO.M"

    const-string v11, ".APP_PUSH_MEDIA.STOP"

    invoke-virtual {v6, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    invoke-direct {v4, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    invoke-virtual/range {p1 .. p1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v11

    invoke-virtual {v4, v8, v11, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    invoke-virtual/range {p2 .. p2}, Lcom/tencent/android/tpush/message/d;->o()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v7, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    invoke-virtual {v4, v9, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-static {v0, v2, v4, v3}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v0

    invoke-virtual {v13, v10, v0}, Landroid/widget/RemoteViews;->setOnClickPendingIntent(ILandroid/app/PendingIntent;)V

    :cond_5
    invoke-virtual {v1, v13}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setContentView(Landroid/widget/RemoteViews;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    return v5

    :cond_6
    const-string/jumbo v0, "uiot_otoqai i ntflxaogncy"

    const-string/jumbo v0, "tiltoau ygo_finuxoo inatn"

    const-string/jumbo v0, "no xg_notification layout"

    invoke-static {v6, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    return v7
.end method

.method private static declared-synchronized b(Landroid/content/Context;I)I
    .locals 6

    const/4 v4, 0x0

    move v5, v4

    const-class v0, Lcom/tencent/android/tpush/message/b;

    const-class v0, Lcom/tencent/android/tpush/message/b;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x4

    monitor-enter v0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v1, 0x0

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v3, "I_FOGBEpN_M_EsUI_TNN"

    const-string v3, "OEsFN_XBNTNIE__GI_UM"

    const/4 v5, 0x4

    const-string v3, "_XINGE_NOTIF_NUMBER_"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-static {p1}, Ljava/lang/String;->valueOf(I)Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x3

    const/4 v4, 0x7

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-static {p0, p1, v1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getInt(Landroid/content/Context;Ljava/lang/String;I)I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    const v3, 0x7ffffffe

    const/4 v5, 0x7

    const/4 v4, 0x0

    if-lt v2, v3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    move v1, v2

    move v1, v2

    const/4 v5, 0x1

    move v1, v2

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x1

    add-int/lit8 v2, v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {p0, p1, v2}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putInt(Landroid/content/Context;Ljava/lang/String;I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_1

    :catchall_0
    move-exception p0

    :try_start_1
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x1

    const-string/jumbo p1, "lsrmeeMpqeeag"

    const-string/jumbo p1, "seempageerlsM"

    const/4 v5, 0x0

    const-string/jumbo p1, "resMeHslesgae"

    const-string p1, "MessageHelper"

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x6

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x4

    invoke-static {p1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    monitor-exit v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    return v1

    :catchall_1
    move-exception p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    monitor-exit v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    throw p0
.end method

.method private static b(Landroid/content/Context;Lcom/tencent/android/tpush/message/d;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    .locals 9

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string/jumbo v0, "sgpmeelMsHero"

    const-string v0, "apeloMHsgeser"

    const/4 v8, 0x2

    const-string/jumbo v0, "seMgopHaseree"

    const-string v0, "MessageHelper"

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-nez p2, :cond_0

    const/4 v8, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushManager;->getDefaultNotificationBuilder(Landroid/content/Context;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    move-result-object p2

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x0

    if-nez p2, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    move-result-object p2

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->j()I

    move-result v1

    const/4 v8, 0x5

    const/4 v7, 0x7

    if-eqz v1, :cond_2

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x2

    const/16 v1, 0x10

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p2, v1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setFlags(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    :cond_2
    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->isEnableNotificationSound(Landroid/content/Context;)Z

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/4 v2, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    if-eqz v1, :cond_5

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->h()I

    move-result v1

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x3

    if-eqz v1, :cond_5

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->q()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x4

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-nez v1, :cond_4

    const/4 v8, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->q()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x1

    const/4 v7, 0x3

    const-string/jumbo v4, "rwa"

    const-string/jumbo v4, "rwa"

    const/4 v8, 0x1

    const-string/jumbo v4, "rwa"

    const-string/jumbo v4, "raw"

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v1, v3, v4, v5}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-lez v1, :cond_3

    const/4 v8, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x1

    const-string v4, "ao/:ibdroc/sd.rrune"

    const-string v4, "android.resource://"

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x1

    const-string v4, "/"

    const-string v4, "/"

    const/4 v8, 0x4

    const-string v4, "/"

    const-string v4, "/"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p2, v1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setSound(Landroid/net/Uri;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    goto :goto_0

    :cond_3
    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p2, v2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setDefaults(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    goto :goto_0

    :cond_4
    const/4 v7, 0x6

    move v8, v7

    invoke-virtual {p2, v2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setDefaults(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    :cond_5
    :goto_0
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->i()I

    move-result v1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x5

    if-eqz v1, :cond_6

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x3

    const/4 v1, 0x2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p2, v1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setDefaults(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    :cond_6
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->p()I

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    if-eqz v1, :cond_7

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    const/4 v1, 0x4

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-virtual {p2, v1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setDefaults(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {p2, v2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setFlags(I)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    :cond_7
    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/message/b;->c(Landroid/content/Context;Lcom/tencent/android/tpush/message/d;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V

    const/4 v8, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->t()I

    move-result v1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->r()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    instance-of v3, p2, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;

    const/4 v8, 0x3

    const/4 v4, 0x5

    const/4 v8, 0x3

    const/4 v4, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eqz v3, :cond_8

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    check-cast v3, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;

    const/4 v8, 0x2

    invoke-virtual {v3}, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->getLayoutIconId()Ljava/lang/Integer;

    move-result-object v3

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x2

    goto :goto_1

    :cond_8
    move-object v3, v4

    move-object v3, v4

    move-object v3, v4

    :goto_1
    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x6

    if-eqz v2, :cond_d

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-static {v2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v5

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-nez v5, :cond_d

    const/4 v8, 0x4

    const/4 v7, 0x6

    if-gtz v1, :cond_a

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string/jumbo v5, "ldaaebub"

    const-string v5, "aawlebbd"

    const/4 v8, 0x6

    const-string v5, "bdaewlrp"

    const-string v5, "drawable"

    const/4 v8, 0x4

    const/4 v7, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v1, v2, v5, v6}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result v1

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    if-lez v1, :cond_9

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x7

    invoke-static {v2, v1}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p2, v2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setLargeIcon(Landroid/graphics/Bitmap;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x5

    if-eqz v3, :cond_d

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x1

    check-cast v2, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-virtual {v2, v1}, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->setLayoutIconDrawableId(I)Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;

    const/4 v7, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    goto/16 :goto_2

    :cond_9
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x1

    iget v2, v2, Landroid/content/pm/ApplicationInfo;->icon:I

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v1, v2}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v1

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p2, v1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setLargeIcon(Landroid/graphics/Bitmap;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    goto :goto_2

    :cond_a
    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {v2}, Lcom/tencent/android/tpush/message/b;->a(Ljava/lang/String;)Landroid/graphics/Bitmap;

    move-result-object v1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x6

    if-nez v1, :cond_b

    const/4 v7, 0x5

    move v8, v7

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    iget v2, v2, Landroid/content/pm/ApplicationInfo;->icon:I

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    invoke-static {v1, v2}, Landroid/graphics/BitmapFactory;->decodeResource(Landroid/content/res/Resources;I)Landroid/graphics/Bitmap;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {p2, v1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setLargeIcon(Landroid/graphics/Bitmap;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x3

    goto :goto_2

    :cond_b
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p2, v1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setLargeIcon(Landroid/graphics/Bitmap;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    if-eqz v3, :cond_c

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x2

    check-cast v3, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {v3, v1}, Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;->setLayoutIconDrawableBmp(Landroid/graphics/Bitmap;)Lcom/tencent/android/tpush/XGCustomPushNotificationBuilder;

    :cond_c
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->n()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    if-eqz v2, :cond_d

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x7

    sput-object v1, Lcom/tencent/android/tpush/message/b;->d:Landroid/graphics/Bitmap;

    :cond_d
    :goto_2
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->B()I

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-lez v1, :cond_e

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    invoke-virtual {p2, v1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setColor(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    :cond_e
    const/4 v8, 0x5

    invoke-virtual {p2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getColor()Ljava/lang/Integer;

    move-result-object v1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x3

    if-nez v1, :cond_f

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string v1, "el.iticgqsioaaelbo_eonrlitfogoraineucd.nesga.gtsmff_mouc"

    const-string v1, "_mlc_sud.onfiiiaug.bsnoeaieoeaclrmgsocfetoto.ggarf.inlte"

    const-string/jumbo v1, "oasailofrn.ioeb.oetgd_si.ltag_nfcsnlmereii.foaugeotgscmc"

    const-string v1, "com.google.firebase.messaging.default_notification_color"

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {p0, v1, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v1

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x1

    if-eqz v1, :cond_f

    :try_start_0
    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    move-object v2, v1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    check-cast v2, Ljava/lang/Integer;

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string v4, "a _mn temroogp-i_ilnttodfatftm_aecctlai oedca"

    const-string v4, "i _dt_mpot oetcgidtca lefc_mf-inoeraftantaoal"

    const/4 v8, 0x7

    const-string v4, "get meta-data fcm_default_notification_color "

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {v0, v3}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-lez v2, :cond_f

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p0, v2}, Landroid/content/res/Resources;->getColor(I)I

    move-result p0

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {p2, p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setColor(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    goto :goto_3

    :catchall_0
    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x4

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const-string/jumbo v2, "oteao:uit vndotedrg c tln-ieqdoulcii ommf_a laacro iecftid__rsaeat"

    const-string v2, "catcu-: qitldeer miioer_l_fm_d eadirunotaooocti tc vftef ndasgaail"

    const/4 v8, 0x3

    const-string v2, "etnacbe_risa  i  ttgloa_inftaar mndrce:lteedmoo_-aiutivo codiulfdf"

    const-string v2, "get meta-data fcm_default_notification_color invalid resource id: "

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {p0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_f
    :goto_3
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->F()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {p2, p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setNotificationCategory(Ljava/lang/String;)V

    const/4 v8, 0x0

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->G()I

    move-result p0

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-virtual {p2, p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setNotificationImportance(I)Z

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x6

    return-object p2
.end method

.method public static b(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v0, 0x0

    :try_start_0
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    new-instance v1, Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo v2, "tie.ciuonr.A.sttnNoiaMdnnI"

    const-string/jumbo v2, "ids.oIanA.irnM.tNactinteon"

    const/4 v4, 0x0

    const-string v2, ".i..tdNpiIniAndaennotarcto"

    const-string v2, "android.intent.action.MAIN"

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {v1, v2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;Landroid/net/Uri;)V

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v2, "A.n..iLiqetadeERNHngnoyrUtamrtCd"

    const-string/jumbo v2, "oUtmrnntg.EoaHLeiC.eaAnytRNrid.d"

    const/4 v4, 0x6

    const-string v2, "Rrsdnr.tUCionNa.oyLAcitdHeaet.Eg"

    const-string v2, "android.intent.category.LAUNCHER"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v1, v2}, Landroid/content/Intent;->addCategory(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p0, v1, v2}, Landroid/content/pm/PackageManager;->queryIntentActivities(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    check-cast v1, Landroid/content/pm/ResolveInfo;

    const/4 v4, 0x4

    const/4 v3, 0x5

    iget-object v1, v1, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-eqz v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget-object p0, v1, Landroid/content/pm/ActivityInfo;->name:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v1, "sagmeeesMorlH"

    const-string v1, "HegsoleMaeers"

    const/4 v4, 0x1

    const-string/jumbo v1, "serMoeeseaHgp"

    const-string v1, "MessageHelper"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v2, " vcrrbiyttbtoAiegr"

    const-string v2, "giiotb errAtrcveyt"

    const-string/jumbo v2, "tvieA uytterogcr r"

    const-string v2, "get Activity error"

    const/4 v4, 0x7

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-object v0
.end method

.method private static c(Landroid/content/Context;Lcom/tencent/android/tpush/message/d;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string v0, "graeeHspeMspu"

    const-string v0, "eMsgHauspeerl"

    const/4 v6, 0x6

    const-string/jumbo v0, "lapseerMqesHe"

    const-string v0, "MessageHelper"

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {p1}, Lcom/tencent/android/tpush/message/d;->s()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v1, "deslwapa"

    const-string v1, "debalwap"

    const/4 v6, 0x0

    const-string v1, "brdmaeal"

    const-string v1, "drawable"

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-eqz p1, :cond_0

    const/4 v5, 0x7

    move v6, v5

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    if-nez v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x6

    invoke-virtual {v2, p1, v1, v3}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x6

    if-lez p1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {p2, p1}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setSmallIcon(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    :cond_0
    const/4 v6, 0x1

    invoke-virtual {p2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getSmallIcon()Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x2

    if-nez p1, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    const-string p1, "giu.oamteoif.bfi.noiqmggaeolltnec.nrsseeoi_sco_tfacinga"

    const-string/jumbo p1, "nsgcmegiqftcfgooatfboi.tn.ina_m..euiesligenrsocoioe_laa"

    const/4 v6, 0x4

    const-string p1, "com.google.firebase.messaging.default_notification_icon"

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    const/4 v2, 0x0

    const/4 v6, 0x7

    const/4 v5, 0x0

    invoke-static {p0, p1, v2}, Lcom/tencent/tpns/baseapi/base/util/CommonHelper;->getMetaData(Landroid/content/Context;Ljava/lang/String;Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz p1, :cond_1

    :try_start_0
    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x2

    check-cast v2, Ljava/lang/Integer;

    const/4 v5, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v4, "c tifbie_tttet coamtmn fdfagia-canenadsu_li_"

    const-string v4, "ccs_iiind_eeu igaflftoot- mmtdanftaettana _c"

    const-string v4, "i l_atuttaetmdt_ftan-oeiim  cfncaganeouiodfc"

    const-string v4, "get meta-data fcm_default_notification_icon "

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-static {v0, v3}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-lez v2, :cond_1

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p2, v2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setSmallIcon(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    goto :goto_0

    :catchall_0
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x4

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const-string/jumbo v3, "l ncimtpceetc_rd  nmdnofaf t im_eteav-oodrg_cua:dttisaienulaaio i"

    const-string v3, "ai m__eio_ra ectdiunnocoaidtta atmscid frlfutoteanm- idlfc :egnev"

    const/4 v6, 0x0

    const-string v3, "aci _aedquifini-t uttis atdacteoolrnrncdecmeg:ini   ltfom_fdeavo_"

    const-string v3, "get meta-data fcm_default_notification_icon invalid resource id: "

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x3

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p2}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->getSmallIcon()Ljava/lang/Integer;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-nez p1, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/d/d;->j()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    const-string v0, "gesool"

    const-string v0, "geoloo"

    const/4 v6, 0x3

    const-string v0, "eggmoo"

    const-string v0, "google"

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-eqz p1, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string v0, "iacoobicii_tnnfto"

    const/4 v6, 0x7

    const-string v0, "c_niotoitinaoocfn"

    const-string/jumbo v0, "notification_icon"

    const/4 v6, 0x2

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {p1, v0, v1, v2}, Landroid/content/res/Resources;->getIdentifier(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)I

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-lez p1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-static {p1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {p2, p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setSmallIcon(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    goto :goto_1

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->icon:I

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p2, p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setSmallIcon(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    goto :goto_1

    :cond_3
    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x6

    iget p0, p0, Landroid/content/pm/ApplicationInfo;->icon:I

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {p0}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object p0

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p2, p0}, Lcom/tencent/android/tpush/XGPushNotificationBuilder;->setSmallIcon(Ljava/lang/Integer;)Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    :cond_4
    :goto_1
    const/4 v6, 0x0

    const/4 v5, 0x2

    return-void
.end method
