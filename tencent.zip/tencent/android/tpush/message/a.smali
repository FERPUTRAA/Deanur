.class public abstract Lcom/tencent/android/tpush/message/a;
.super Ljava/lang/Object;


# instance fields
.field protected a:Lorg/json/JSONObject;

.field protected b:Ljava/lang/String;

.field protected c:Ljava/lang/String;

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;


# direct methods
.method protected constructor <init>(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/message/a;->c:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/message/a;->d:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/message/a;->e:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/message/a;->f:Ljava/lang/String;

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/message/a;->g:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/message/a;->b:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public a()V
    .locals 14

    const-string v13, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v12, " @so~.@M~ ~~~@ @~amslyiv @ b@t-Kn @lo~~/4@~od@1/@bi  ~ @~Sfi @co~~@rof@~ @~~o ~ b~~@ @t@~@ @  ~u"

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v13, 0x1

    const-string/jumbo v0, "mecmsatpcet"

    const-string/jumbo v0, "tcseeatcpm_"

    const/4 v13, 0x0

    const-string v0, "ia_eomcettp"

    const-string v0, "accept_time"

    const/4 v13, 0x0

    const/4 v12, 0x7

    const/4 v13, 0x7

    const-string v1, "cu_tnbctmomnst"

    const-string/jumbo v1, "tstmoceutcmn_n"

    const/4 v13, 0x2

    const-string/jumbo v1, "teocotu_unctnm"

    const-string v1, "custom_content"

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x0

    const-string/jumbo v2, "pocotne"

    const-string/jumbo v2, "oetconn"

    const/4 v13, 0x2

    const-string/jumbo v2, "nqocent"

    const-string v2, "content"

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x3

    const-string v3, " esp uxofenetedbdcdre"

    const-string v3, "ceefpbdeudr c nexoedt"

    const/4 v13, 0x1

    const-string v3, "d dmnfeeoepcexdcre uo"

    const-string/jumbo v3, "unexpected for decode"

    const/4 v13, 0x0

    const-string v4, "MgdaoosBreaesueHl"

    const-string v4, "BoadHgueeMsaleers"

    const/4 v13, 0x4

    const-string v4, "eBeodbasseMslgHer"

    const-string v4, "BaseMessageHolder"

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x2

    const-string/jumbo v5, "ltpet"

    const/4 v13, 0x3

    const-string/jumbo v5, "iulet"

    const-string/jumbo v5, "title"

    :try_start_0
    const/4 v13, 0x0

    const/4 v12, 0x6

    new-instance v6, Lorg/json/JSONObject;

    const/4 v13, 0x2

    iget-object v7, p0, Lcom/tencent/android/tpush/message/a;->b:Ljava/lang/String;

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x5

    invoke-direct {v6, v7}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x3

    const/4 v12, 0x4

    const/4 v13, 0x4

    iput-object v6, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x1

    goto/16 :goto_0

    :catchall_0
    const/4 v13, 0x2

    const/4 v12, 0x3

    const/4 v13, 0x0

    const/4 v6, 0x1

    :try_start_1
    const/4 v12, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x1

    new-instance v7, Lorg/json/JSONObject;

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x2

    iget-object v8, p0, Lcom/tencent/android/tpush/message/a;->b:Ljava/lang/String;

    const/4 v13, 0x7

    const/4 v12, 0x5

    const/4 v13, 0x5

    const-string/jumbo v9, "{"

    const-string/jumbo v9, "{"

    const-string/jumbo v9, "{"

    const-string/jumbo v9, "{"

    const/4 v12, 0x1

    xor-int/2addr v13, v12

    invoke-virtual {v8, v9}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v9

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x6

    iget-object v10, p0, Lcom/tencent/android/tpush/message/a;->b:Ljava/lang/String;

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x6

    const-string/jumbo v11, "}"

    const-string/jumbo v11, "}"

    const/4 v13, 0x1

    const-string/jumbo v11, "}"

    const-string/jumbo v11, "}"

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x5

    invoke-virtual {v10, v11}, Ljava/lang/String;->lastIndexOf(Ljava/lang/String;)I

    move-result v10

    const/4 v13, 0x0

    const/4 v12, 0x7

    add-int/2addr v10, v6

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x1

    invoke-virtual {v8, v9, v10}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v8

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x7

    invoke-direct {v7, v8}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x1

    iput-object v7, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x2

    goto :goto_0

    :catchall_1
    :try_start_2
    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x6

    new-instance v7, Lorg/json/JSONObject;

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x3

    iget-object v8, p0, Lcom/tencent/android/tpush/message/a;->b:Ljava/lang/String;

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x0

    invoke-virtual {v8, v6}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v6

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x4

    invoke-direct {v7, v6}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x7

    const/4 v12, 0x2

    const/4 v13, 0x5

    iput-object v7, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x1

    goto :goto_0

    :catchall_2
    :try_start_3
    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x6

    new-instance v6, Lorg/json/JSONObject;

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x4

    iget-object v7, p0, Lcom/tencent/android/tpush/message/a;->b:Ljava/lang/String;

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x2

    const/4 v8, 0x2

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x4

    invoke-virtual {v7, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v7

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x4

    invoke-direct {v6, v7}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x1

    iput-object v6, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_3

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x5

    goto :goto_0

    :catchall_3
    :try_start_4
    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x0

    new-instance v6, Lorg/json/JSONObject;

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x1

    iget-object v7, p0, Lcom/tencent/android/tpush/message/a;->b:Ljava/lang/String;

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x1

    const/4 v8, 0x3

    const/4 v13, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x2

    invoke-virtual {v7, v8}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v7

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x7

    invoke-direct {v6, v7}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x1

    iput-object v6, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x4

    goto :goto_0

    :catchall_4
    const/4 v12, 0x5

    invoke-static {v4, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    :try_start_5
    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x1

    iget-object v6, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v13, 0x4

    invoke-virtual {v6, v5}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v6

    const/4 v13, 0x4

    if-nez v6, :cond_0

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x7

    iget-object v6, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v13, 0x0

    invoke-virtual {v6, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x0

    iput-object v5, p0, Lcom/tencent/android/tpush/message/a;->d:Ljava/lang/String;

    :cond_0
    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x6

    iget-object v5, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v13, 0x5

    invoke-virtual {v5, v2}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v5

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x1

    if-nez v5, :cond_1

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x7

    iget-object v5, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x1

    invoke-virtual {v5, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x7

    iput-object v2, p0, Lcom/tencent/android/tpush/message/a;->e:Ljava/lang/String;

    :cond_1
    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v12, 0x5

    move v13, v12

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v2
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_5

    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x2

    const-string v5, ""

    const-string v5, ""

    const/4 v13, 0x2

    const/4 v12, 0x6

    if-nez v2, :cond_2

    :try_start_6
    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v13, 0x3

    invoke-virtual {v2, v1, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v13, 0x5

    const/4 v12, 0x0

    if-eqz v1, :cond_2

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x6

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v2

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x5

    const-string/jumbo v6, "{}"

    const-string/jumbo v6, "}{"

    const/4 v13, 0x1

    const-string/jumbo v6, "}{"

    const-string/jumbo v6, "{}"

    const/4 v13, 0x3

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v2, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v13, 0x5

    const/4 v12, 0x5

    const/4 v13, 0x5

    if-nez v2, :cond_2

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x7

    iput-object v1, p0, Lcom/tencent/android/tpush/message/a;->f:Ljava/lang/String;

    :cond_2
    const/4 v13, 0x7

    const/4 v12, 0x1

    const/4 v13, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x4

    invoke-virtual {v1, v0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v1

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x6

    if-nez v1, :cond_3

    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v12, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x7

    invoke-virtual {v1, v0, v5}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/message/a;->g:Ljava/lang/String;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_5

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x1

    goto :goto_1

    :catchall_5
    const/4 v13, 0x6

    const/4 v12, 0x7

    const/4 v13, 0x7

    invoke-static {v4, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_1
    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x1

    invoke-virtual {p0}, Lcom/tencent/android/tpush/message/a;->c()V

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->b:Ljava/lang/String;

    const/4 v13, 0x4

    const/4 v12, 0x2

    const/4 v13, 0x5

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x5

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-virtual {v0}, Ljava/lang/String;->toUpperCase()Ljava/lang/String;

    move-result-object v0

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/message/a;->c:Ljava/lang/String;

    const/4 v13, 0x6

    const/4 v12, 0x4

    const/4 v13, 0x2

    return-void
.end method

.method public abstract b()I
.end method

.method protected abstract c()V
.end method

.method public d()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->d:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x3

    return-object v0
.end method

.method public e()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x4

    move v2, v1

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->e:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public f()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->f:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v1, "gessaMesqd=gomeasHeJlnB ros"

    const/4 v3, 0x4

    const-string v1, "d eeHsrposoMagsJm=[lgnaBsee"

    const-string v1, "BaseMessageHolder [msgJson="

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v1, "SJ=s,rstq smn"

    const-string/jumbo v1, "tss=onSJ,rm s"

    const/4 v3, 0x6

    const-string v1, ",ns=rStsJmgso"

    const-string v1, ", msgJsonStr="

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/message/a;->b:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const-string v1, "=i mtlmt"

    const-string v1, " ,tm=tli"

    const-string v1, " =tiolte"

    const-string v1, ", title="

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/message/a;->d:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo v1, "ntocobtn= "

    const-string/jumbo v1, "to,not =cn"

    const/4 v3, 0x6

    const-string v1, "=nteotuc n"

    const-string v1, ", content="

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/message/a;->e:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v1, " u,=setpnctotCbm"

    const-string/jumbo v1, "notC btutnc,ems="

    const/4 v3, 0x1

    const-string/jumbo v1, "s tnomctq=tenC,o"

    const-string v1, ", customContent="

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/message/a;->f:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v1, "p,seaTeutci=m"

    const-string/jumbo v1, "mc=tieuea,cTp"

    const/4 v3, 0x5

    const-string v1, "i,=mcma eecpT"

    const-string v1, ", acceptTime="

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/message/a;->g:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string v1, "]"

    const-string v1, "]"

    const/4 v3, 0x0

    const-string v1, "]"

    const-string v1, "]"

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-object v0
.end method
