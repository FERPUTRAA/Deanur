.class public Lcom/tencent/android/tpush/message/c;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/lang/String;


# instance fields
.field private b:J

.field private c:J

.field private d:Ljava/lang/String;

.field private e:Ljava/lang/String;

.field private f:Landroid/content/Context;

.field private g:Landroid/content/Intent;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/message/c;->b:J

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/message/c;->c:J

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string v0, ""

    const/4 v3, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/message/c;->d:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/message/c;->e:Ljava/lang/String;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/message/c;->f:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/message/c;->g:Landroid/content/Intent;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/message/c;->f:Landroid/content/Context;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpush/message/c;->g:Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x5

    return-void
.end method


# virtual methods
.method public a(Lcom/tencent/android/tpush/message/PushMessageManager;JJJ)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~cs~Sl/ ~ ~i~yo@l 4bt@fro-@@~~@bmM~o@f@@ @~@io@~ d~a@~ .@~~@/~@~n@   v   ~ ~t~ sb @oi ~K~~@@ @o1"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    const/4 p1, 0x1

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return p1
.end method
