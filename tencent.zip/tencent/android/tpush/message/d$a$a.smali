.class public Lcom/tencent/android/tpush/message/d$a$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/message/d$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# instance fields
.field public a:I

.field public b:I


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput v0, p0, Lcom/tencent/android/tpush/message/d$a$a;->a:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput v0, p0, Lcom/tencent/android/tpush/message/d$a$a;->b:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    return-void
.end method
