.class Lcom/tencent/android/tpush/message/b$1$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/message/b$1;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Lcom/tencent/android/tpush/message/b$1;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/message/b$1;Landroid/content/Intent;Landroid/content/Context;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/message/b$1$1;->d:Lcom/tencent/android/tpush/message/b$1;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    iput-object p2, p0, Lcom/tencent/android/tpush/message/b$1$1;->a:Landroid/content/Intent;

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/tencent/android/tpush/message/b$1$1;->b:Landroid/content/Context;

    const/4 v0, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p4, p0, Lcom/tencent/android/tpush/message/b$1$1;->c:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "b@s@-~~  @dt / ~y@rt@v/@i ~ ~l~M~@ic~uolo@~~i4@@n ~o  @~ob~ ~ @@@s~ ~K@  of@1m~~ ao@ ~@@. @f~~S~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/message/b$1$1;->a:Landroid/content/Intent;

    const/4 v6, 0x1

    const-string/jumbo v1, "ssImg"

    const-string v1, "Igsms"

    const/4 v6, 0x2

    const-string/jumbo v1, "mIdso"

    const-string/jumbo v1, "msgId"

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v6, 0x1

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/tencent/android/tpush/message/b$1$1;->b:Landroid/content/Context;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v2, v3, v0, v1}, Lcom/tencent/android/tpush/message/MessageManager;->updateCachedMsgIntentToCancel(Landroid/content/Context;J)V

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-instance v0, Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string v1, "aDeotbocniiB.md..nCoK.crEmgtveF.Etidxn.nAa"

    const-string v1, "CB.mienicc.dxmE.o.nteE.antiaocogDAdt.rFKnv"

    const/4 v6, 0x7

    const-string v1, "com.tencent.android.xg.vip.action.FEEDBACK"

    const/4 v6, 0x1

    const/4 v5, 0x2

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/message/b$1$1;->c:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/message/b$1$1;->a:Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-string v1, "PEBEDAuHo.FCKT"

    const-string v1, "KADBoESHT.FCEP"

    const/4 v6, 0x4

    const-string v1, "FE.PECTpSHAUBD"

    const-string v1, "TPUSH.FEEDBACK"

    const/4 v5, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x1

    const/4 v2, 0x4

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/message/b$1$1;->b:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v1, "P4adEeLgqptE.aEticnRC.nS_tULe..bSm.VDr.oNCiUcALnHxn.cToodi"

    const-string v1, "AC.UcbU.eviSxPEHeTn.ri.go..dLNc_RSatniLCVEnLpoDmtEdt.4aonc"

    const-string v1, "evsd4Roe_icSnCmc.A..aroHVC.EcpLLn...TtdoUnaELxgiitPNEnU.tD"

    const-string v1, "com.tencent.android.xg.vip.action.PUSH_CANCELLED.RESULT.V4"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/message/b$1$1;->a:Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x6

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v6, 0x0

    div-long/2addr v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    const-string/jumbo v3, "lcTcmiuke"

    const-string v3, "clkmeicim"

    const-string v3, "clickTime"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {v0, v3, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/message/b$1$1;->b:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/stat/ServiceStat;->appReportNotificationCleared(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/message/b$1$1;->b:Landroid/content/Context;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-void
.end method
