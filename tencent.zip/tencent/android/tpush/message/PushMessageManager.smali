.class public Lcom/tencent/android/tpush/message/PushMessageManager;
.super Ljava/lang/Object;


# static fields
.field public static final CUSTOM_LAYOUT_TYPE_1:I = 0x1

.field public static final CUSTOM_LAYOUT_TYPE_2:I = 0x2

.field public static final CUSTOM_LAYOUT_TYPE_3:I = 0x3

.field public static final MESSAGE_TYPE_CLOUD_CTRL:I = 0x3e8

.field public static final MESSAGE_TYPE_CTRL:I = 0x3

.field public static final MESSAGE_TYPE_IN_MSG:I = 0x7

.field public static final MESSAGE_TYPE_NOTIFICATION:I = 0x1

.field public static final MESSAGE_TYPE_TEXT:I = 0x2


# instance fields
.field private a:J

.field private b:J

.field private c:J

.field private d:Ljava/lang/String;

.field private e:J

.field private f:Ljava/lang/String;

.field private g:Ljava/lang/String;

.field private h:J

.field private i:J

.field private j:Ljava/lang/String;

.field private k:Ljava/lang/String;

.field private l:Ljava/lang/String;

.field private m:Landroid/content/Context;

.field private n:Landroid/content/Intent;

.field private o:Lcom/tencent/android/tpush/message/a;

.field private p:I

.field public pushChannel:I

.field public pushTime:J

.field public source:J

.field public targetType:J


# direct methods
.method private constructor <init>(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5

    const/4 v4, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v4, 0x6

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->a:J

    const/4 v4, 0x4

    const/4 v3, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->b:J

    const/4 v3, 0x3

    const/4 v3, 0x0

    iput-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->c:J

    const/4 v4, 0x3

    const/4 v3, 0x4

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->d:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->e:J

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v2, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->f:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->g:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->h:J

    const/4 v4, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->i:J

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    iput-object v2, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->j:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->k:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput-object v2, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->l:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/16 v0, 0x64

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->pushChannel:I

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->pushTime:J

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->targetType:J

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->source:J

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x4

    move v4, v3

    iput-object v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->o:Lcom/tencent/android/tpush/message/a;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    const/4 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->p:I

    const/4 v3, 0x3

    move v4, v3

    iput-object p1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->m:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-object p2, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->n:Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void
.end method

.method public static getInstance(Landroid/content/Context;Landroid/content/Intent;)Lcom/tencent/android/tpush/message/PushMessageManager;
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x6

    new-instance v0, Lcom/tencent/android/tpush/message/PushMessageManager;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-direct {v0, p0, p1}, Lcom/tencent/android/tpush/message/PushMessageManager;-><init>(Landroid/content/Context;Landroid/content/Intent;)V

    const-string/jumbo v1, "snsctet"

    const-string v1, "ecsttno"

    const/4 v9, 0x7

    const-string v1, "content"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p1, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string/jumbo v3, "nesmetg soetrMacseanuaM:Pgh"

    const-string v3, "PushMessageManager content:"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-string v3, "hnMrosasMPaemsagee"

    const-string v3, "ansmehgPMMesarsega"

    const/4 v9, 0x7

    const-string v3, "MgushbareMeaPnssag"

    const-string v3, "PushMessageManager"

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    iput-object v1, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->f:Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    const-string/jumbo v2, "nugMi"

    const-string v2, "Mgino"

    const/4 v9, 0x6

    const-string/jumbo v2, "sgpiM"

    const-string/jumbo v2, "inMsg"

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {v2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    const-string v5, "hsgn gMiqrassMsMegaa:ePeb"

    const-string v5, "aM PsbgeengsisasMuraMeh:g"

    const/4 v9, 0x3

    const-string/jumbo v5, "sssaesgMhgnaraMuisMnP:ee "

    const-string v5, "PushMessageManager inMsg:"

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {v3, v4}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    iput-object v2, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->g:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string/jumbo v2, "sgdmI"

    const-string/jumbo v2, "msgId"

    const/4 v8, 0x1

    move v9, v8

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v9, 0x1

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {p1, v2, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    iput-wide v6, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->b:J

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-string/jumbo v6, "searosPMI:ueansags mhgdeu"

    const-string v6, "asers usmIgsdhMe:eMaagunP"

    const/4 v9, 0x3

    const-string/jumbo v6, "rmhPebdgansuMe saI:sMsgea"

    const-string v6, "PushMessageManager msgId:"

    const/4 v9, 0x0

    const/4 v8, 0x1

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    shl-int/2addr v9, v8

    iget-wide v6, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->b:J

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string v2, "audIc"

    const-string v2, "Iapdc"

    const/4 v9, 0x2

    const-string v2, "adpcc"

    const-string v2, "accId"

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {p1, v2, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    iput-wide v6, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->c:J

    const/4 v9, 0x0

    const-string v2, "ap_rndgaqekitp_ph"

    const-string/jumbo v2, "third_app_pkgname"

    const/4 v8, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    iput-object v2, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->d:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const-string/jumbo v2, "igsqduMsb"

    const-string v2, "ibudssgMq"

    const/4 v9, 0x3

    const-string v2, "bdumiIsMg"

    const-string v2, "busiMsgId"

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {p1, v2, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    iput-wide v6, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->e:J

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string v2, "di_aohcsne"

    const-string v2, "easdcnhi_n"

    const-string v2, "ecidabnlhn"

    const-string v2, "channel_id"

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {p1, v2, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    iput-wide v6, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->a:J

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string/jumbo v2, "ptmstmumei"

    const-string v2, "eammsmptit"

    const/4 v9, 0x1

    const-string v2, "aispmetpms"

    const-string/jumbo v2, "timestamps"

    const/4 v9, 0x0

    const/4 v8, 0x4

    invoke-virtual {p1, v2, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x0

    iput-wide v6, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->h:J

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    const-string/jumbo v2, "tpye"

    const-string/jumbo v2, "peyt"

    const/4 v9, 0x6

    const-string v2, "epyt"

    const-string/jumbo v2, "type"

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {p1, v2, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    iput-wide v6, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->i:J

    const/4 v9, 0x4

    const/4 v8, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    and-int/2addr v9, v8

    const-string v6, "PaeMueasqserp tn:asegogM"

    const-string v6, "aPptosneeMer sasau:gegMh"

    const/4 v9, 0x5

    const-string v6, "atsgeaeMsyu rhgpnsPeMae:"

    const-string v6, "PushMessageManager type:"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v2, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-wide v6, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->i:J

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v2, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string v2, "hlnmhnCusap"

    const-string/jumbo v2, "pushChannel"

    const/4 v8, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    const/16 v6, 0x64

    const/4 v8, 0x5

    or-int/2addr v9, v8

    invoke-virtual {p1, v2, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string v6, "ibeTomps"

    const-string/jumbo v6, "meihpbTs"

    const/4 v9, 0x6

    const-string v6, "Tuehmbpi"

    const-string/jumbo v6, "pushTime"

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {p1, v6, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x2

    iput-wide v4, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->pushTime:J

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    iput v2, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->pushChannel:I

    const/4 v9, 0x1

    const-string v2, "d_origup"

    const-string v2, "group_id"

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    iput-object v2, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->j:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    if-eqz v2, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x2

    const-string/jumbo v2, "ppgoIuu"

    const-string v2, "Iogdpuu"

    const/4 v9, 0x2

    const-string/jumbo v2, "pqodrug"

    const-string v2, "groupId"

    const/4 v8, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    iput-object v2, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->j:Ljava/lang/String;

    :cond_0
    const/4 v8, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string v2, "apsTpeetty"

    const-string v2, "gtyeTatpep"

    const/4 v9, 0x6

    const-string/jumbo v2, "rtamgeTtep"

    const-string/jumbo v2, "targetType"

    const/4 v9, 0x6

    const/4 v8, 0x2

    const-wide/16 v4, 0x0

    const/4 v9, 0x6

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v9, 0x1

    invoke-virtual {p1, v2, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x7

    iput-wide v6, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->targetType:J

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    const-string v2, "cersou"

    const-string v2, "ceqsur"

    const/4 v9, 0x3

    const-string/jumbo v2, "suoceb"

    const-string/jumbo v2, "source"

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {p1, v2, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    iput-wide v4, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->source:J

    const/4 v9, 0x1

    const/4 v8, 0x7

    const-string v2, "Ittsleudpm"

    const-string v2, "eIstpdetlm"

    const-string/jumbo v2, "templateId"

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    iput-object v2, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->k:Ljava/lang/String;

    const/4 v8, 0x1

    const/4 v9, 0x5

    const-string v2, "Idemacr"

    const/4 v9, 0x7

    const-string/jumbo v2, "ptcIare"

    const-string/jumbo v2, "traceId"

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    iput-object v2, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->l:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    iget-wide v4, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->i:J

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    long-to-int v2, v4

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    const/4 v4, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-eq v2, v4, :cond_4

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    const/4 v4, 0x2

    const/4 v9, 0x3

    const/4 v8, 0x6

    if-eq v2, v4, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    const/4 v4, 0x3

    if-eq v2, v4, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    const/4 v1, 0x7

    const/4 v8, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-eq v2, v1, :cond_2

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/16 v1, 0x3e8

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-eq v2, v1, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    const-string/jumbo v2, "ofr  ergqeprme,s   y pt:rdooirtoytase,"

    const-string/jumbo v2, "reoro,rsy oopae rfeiyst,  epg rttpd: m"

    const/4 v9, 0x4

    const-string v2, "ers oe  rret smyigfydp oaoer,: ptp,ser"

    const-string v2, "error type for message, drop it, type:"

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    move v9, v8

    iget-wide v4, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->i:J

    const/4 v8, 0x1

    and-int/2addr v9, v8

    invoke-virtual {v1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    move v9, v8

    const-string v2, ":tbmeitn"

    const-string/jumbo v2, "tnte:b,i"

    const/4 v9, 0x6

    const-string/jumbo v2, "in,to:et"

    const-string v2, ",intent:"

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {v3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/XGPushManager;->msgAck(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    goto :goto_0

    :cond_1
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v2

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {v2, p0, v1}, Lcom/tencent/android/tpush/message/MessageManager;->onCrtlMsgHandle(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/XGPushManager;->msgAck(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V

    :cond_2
    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    const/4 p0, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    goto :goto_1

    :cond_3
    const/4 v8, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    new-instance p0, Lcom/tencent/android/tpush/message/f;

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/message/f;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x3

    goto :goto_1

    :cond_4
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x1

    new-instance p0, Lcom/tencent/android/tpush/message/d;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/message/d;-><init>(Ljava/lang/String;)V

    :goto_1
    const/4 v9, 0x6

    const/4 v8, 0x5

    if-eqz p0, :cond_5

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    iput-object p0, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->o:Lcom/tencent/android/tpush/message/a;

    const/4 v8, 0x2

    move v9, v8

    invoke-virtual {p0}, Lcom/tencent/android/tpush/message/a;->a()V

    :cond_5
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-string/jumbo p0, "vIeorbke"

    const-string p0, "Irveekuo"

    const/4 v9, 0x7

    const-string/jumbo p0, "rekIdvuo"

    const-string/jumbo p0, "revokeId"

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/4 v1, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {p1, p0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    iput p0, v0, Lcom/tencent/android/tpush/message/PushMessageManager;->p:I

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    return-object v0
.end method


# virtual methods
.method public getAccessId()J
    .locals 4

    const/4 v2, 0x1

    move v3, v2

    iget-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->c:J

    const/4 v3, 0x1

    return-wide v0
.end method

.method public getAppPkgName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->d:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x7

    return-object v0
.end method

.method public getBusiMsgId()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->e:J

    const/4 v3, 0x7

    return-wide v0
.end method

.method public getChannelId()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->a:J

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-wide v0
.end method

.method public getContent()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->f:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x5

    return-object v0
.end method

.method public getContext()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->m:Landroid/content/Context;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object v0
.end method

.method public getGroupId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->j:Ljava/lang/String;

    const/4 v2, 0x1

    return-object v0
.end method

.method public getInMsg()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->g:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method

.method public getIntent()Landroid/content/Intent;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->n:Landroid/content/Intent;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x3

    return-object v0
.end method

.method public getMessageHolder()Lcom/tencent/android/tpush/message/a;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->o:Lcom/tencent/android/tpush/message/a;

    const/4 v2, 0x6

    const/4 v1, 0x4

    return-object v0
.end method

.method public getMsgId()J
    .locals 4

    const/4 v2, 0x6

    iget-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->b:J

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    return-wide v0
.end method

.method public getRevokeId()I
    .locals 3

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->p:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method

.method public getSource()J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    iget-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->source:J

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-wide v0
.end method

.method public getTargetType()J
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    iget-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->targetType:J

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    return-wide v0
.end method

.method public getTemplateId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->k:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object v0
.end method

.method public getTimestamps()J
    .locals 4

    const/4 v3, 0x2

    iget-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->h:J

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    return-wide v0
.end method

.method public getTraceId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->l:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public getType()J
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-wide v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->i:J

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-wide v0
.end method

.method public setAppPkgName(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->d:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    return-void
.end method

.method public setChannelId(J)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->a:J

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public setGroupId(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->j:Ljava/lang/String;

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method

.method public setSource(J)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-wide p1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->source:J

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method public setTargetType(J)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-wide p1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->targetType:J

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method

.method public showNotifacition()V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->o:Lcom/tencent/android/tpush/message/a;

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpush/message/a;->b()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v1, 0x1

    xor-int/2addr v3, v1

    const/4 v2, 0x3

    move v3, v2

    if-eq v0, v1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    return-void

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->m:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/message/b;->a(Landroid/content/Context;Lcom/tencent/android/tpush/message/PushMessageManager;)V

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v1, "d easaepes[hgsMPpgrgMnuIas"

    const-string v1, "eMsgaM[pedhsnPIeasa g=ursg"

    const/4 v4, 0x0

    const-string v1, " M[asam=qeMggusenegrsIhsdP"

    const-string v1, "PushMessageManager [msgId="

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->b:J

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v1, "ac Ic,edq=s"

    const/4 v4, 0x5

    const-string v1, "=sssdIe cac"

    const-string v1, ", accessId="

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-wide v1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->c:J

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v1, "iuMm,s=bIdg "

    const-string v1, ", busiMsgId="

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->e:J

    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v1, " on,oetcts"

    const-string v1, "=os ,nttce"

    const/4 v4, 0x6

    const-string v1, ",tcnobtne "

    const-string v1, ", content="

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->f:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    move v4, v3

    const-string/jumbo v1, "ipt= aummsets"

    const-string/jumbo v1, "m imsp=temats"

    const/4 v4, 0x5

    const-string/jumbo v1, "ita psmp=tsm,"

    const-string v1, ", timestamps="

    const/4 v3, 0x7

    move v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    iget-wide v1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->h:J

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string/jumbo v1, "oqpe,=y"

    const-string/jumbo v1, "y= ,oep"

    const/4 v4, 0x7

    const-string v1, ", type="

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-wide v1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->i:J

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string/jumbo v1, "tbsn=nie,"

    const-string/jumbo v1, "nnt=ebti,"

    const/4 v4, 0x2

    const-string/jumbo v1, "t,emtn= i"

    const-string v1, ", intent="

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->n:Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string v1, "elamoesHsgeur ,d"

    const-string v1, "dHrmeeusls,g= ea"

    const-string/jumbo v1, "lemosbed e,Hrag="

    const-string v1, ", messageHolder="

    const/4 v3, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->o:Lcom/tencent/android/tpush/message/a;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    move v4, v3

    const-string/jumbo v1, "mak,N=upePp p"

    const-string/jumbo v1, "p=kNpaPp,em g"

    const/4 v4, 0x5

    const-string v1, ",m=ePagp ppNa"

    const-string v1, ", appPkgName="

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->d:Ljava/lang/String;

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v1, "eov Irq=q,e"

    const-string/jumbo v1, "k e=Iv,rqeo"

    const/4 v4, 0x0

    const-string v1, "I s=dreeov,"

    const-string v1, ", revokeId="

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    iget v1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->p:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const-string v1, " p,metel=tdsa"

    const-string v1, "els =tIp,etad"

    const/4 v4, 0x3

    const-string v1, "dm aopltI,et="

    const-string v1, ", templateId="

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->k:Ljava/lang/String;

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const-string/jumbo v1, "reI,ab=c d"

    const-string v1, ", traceId="

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/message/PushMessageManager;->l:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string v1, "]"

    const/4 v4, 0x5

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    return-object v0
.end method
