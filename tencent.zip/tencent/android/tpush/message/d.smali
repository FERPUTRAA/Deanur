.class public Lcom/tencent/android/tpush/message/d;
.super Lcom/tencent/android/tpush/message/a;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/message/d$a;
    }
.end annotation


# instance fields
.field private A:I

.field private B:Ljava/lang/String;

.field private C:I

.field private D:I

.field private d:I

.field private e:I

.field private f:I

.field private g:I

.field private h:I

.field private i:I

.field private j:Ljava/lang/String;

.field private k:I

.field private l:Ljava/lang/String;

.field private m:Ljava/lang/String;

.field private n:I

.field private o:I

.field private p:Ljava/lang/String;

.field private q:Ljava/lang/String;

.field private r:Ljava/lang/String;

.field private s:I

.field private t:Ljava/lang/String;

.field private u:I

.field private v:Ljava/lang/String;

.field private w:Lcom/tencent/android/tpush/message/d$a;

.field private x:I

.field private y:Ljava/lang/String;

.field private z:Ljava/lang/String;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/message/a;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 p1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    iput p1, p0, Lcom/tencent/android/tpush/message/d;->d:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v0, 0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->e:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->f:I

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->g:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput p1, p0, Lcom/tencent/android/tpush/message/d;->h:I

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput p1, p0, Lcom/tencent/android/tpush/message/d;->i:I

    const/4 v4, 0x7

    const-string v1, ""

    const/4 v4, 0x0

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d;->j:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->k:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d;->l:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d;->m:Ljava/lang/String;

    const/4 v4, 0x4

    iput p1, p0, Lcom/tencent/android/tpush/message/d;->n:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    iput p1, p0, Lcom/tencent/android/tpush/message/d;->o:I

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d;->p:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d;->q:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d;->r:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    const/4 v0, -0x1

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->s:I

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d;->t:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    const/4 v2, 0x2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput v2, p0, Lcom/tencent/android/tpush/message/d;->u:I

    const/4 v4, 0x3

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d;->v:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    new-instance v2, Lcom/tencent/android/tpush/message/d$a;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v2}, Lcom/tencent/android/tpush/message/d$a;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/message/d;->w:Lcom/tencent/android/tpush/message/d$a;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->x:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d;->y:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d;->z:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput p1, p0, Lcom/tencent/android/tpush/message/d;->A:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpush/message/d;->B:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput p1, p0, Lcom/tencent/android/tpush/message/d;->C:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput p1, p0, Lcom/tencent/android/tpush/message/d;->D:I

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    return-void
.end method

.method private H()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@@s4b @v   r@/@ @@~cl~ @~@~o~@ oi@@a@o  @ /u.o@@1~~~st M~~lb~bS ~in t ~o@@~@~- yfm ~@~d~Kf~i~~~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x0

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v1, "ni:mo Cosyiatgtoaenitc"

    const-string v1, "f:sC tnngaiyocototaeii"

    const/4 v5, 0x4

    const-string v1, "Cci oyonfriaioto:natgt"

    const-string v1, " notificationCategory:"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/message/d;->r:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const-string v1, "c:opebntacninofmi,omI trti"

    const-string/jumbo v1, "ntimrctin:Iopftni,m caoeao"

    const/4 v5, 0x3

    const-string/jumbo v1, "tap ,nuIonca onmrte:ifitco"

    const-string v1, " , notificationImportance:"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/message/d;->s:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    const-string v1, "Naogisopantfiosceet"

    const-string v1, "eoaioeatinscgtNofis"

    const/4 v5, 0x0

    const-string/jumbo v1, "iostNsnaqaMeiofigce"

    const-string v1, "NotificationMessage"

    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->r:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->r:Ljava/lang/String;

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    const/16 v2, 0x1e

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-ge v0, v2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string v0, "afst.riindobtNa.pnooicpi"

    const-string v0, "capntbNaatioo.rifion.ipd"

    const/4 v5, 0x7

    const-string/jumbo v0, "oipmtdaipiidnoc.naf.torN"

    const-string v0, "android.app.Notification"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/message/d;->r:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/Class;->getField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x6

    const/4 v3, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    check-cast v0, Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->r:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto/16 :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v2, "iiainvuirft taogdiclaneoto nC"

    const/4 v5, 0x5

    const-string/jumbo v2, "rt yooifiC cettdniogolaaivian"

    const-string/jumbo v2, "invalid notificationCategory "

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/message/d;->r:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v2, " pttebrse  temo"

    const-string v2, "etr tmyp set eo"

    const/4 v5, 0x4

    const-string/jumbo v2, "orey tuttse p e"

    const-string v2, " reset to empty"

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->r:Ljava/lang/String;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto :goto_0

    :catchall_0
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v2, "caeoCaipotaa,ttgetngi:oc ooyC ieryqgnteinidffr altfini"

    const-string v2, "iCgonegnqdntiaor,tilaCta eoracfyaie:tocni teiiof ygtof"

    const/4 v5, 0x7

    const-string/jumbo v2, "ocyon:CeqCfoirornogio fdytat,tgliatnantt eecfiaaiigti "

    const-string v2, "get notificationCategory failed, notificationCategory:"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/message/d;->r:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->s:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-ltz v0, :cond_1

    const/4 v5, 0x7

    const/4 v2, 0x5

    const/4 v5, 0x7

    move v4, v2

    move v4, v2

    const/4 v5, 0x1

    if-le v0, v2, :cond_2

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const-string v2, "adsief/ t milvaiaucrne1vupsof"

    const-string/jumbo v2, "tis/oveuiaavmliarpaf efu cnd1"

    const-string/jumbo v2, "utrmvadn1uao ivefp mleaf/cili"

    const-string/jumbo v2, "invalid importace value\uff1a"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    iget v2, p0, Lcom/tencent/android/tpush/message/d;->s:I

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x5

    const-string/jumbo v2, "teumooe d falter "

    const-string v2, " rem ttfaludoe te"

    const/4 v5, 0x4

    const-string/jumbo v2, "te frbt suldao te"

    const-string v2, " reset to default"

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v0, -0x1

    const/4 v5, 0x5

    xor-int/2addr v4, v0

    const/4 v5, 0x6

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->s:I

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x0

    return-void
.end method


# virtual methods
.method public A()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->z:Ljava/lang/String;

    const/4 v2, 0x5

    return-object v0
.end method

.method public B()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->A:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x0

    return v0
.end method

.method public C()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->B:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-object v0
.end method

.method public D()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->C:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    return v0
.end method

.method public E()I
    .locals 3

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->D:I

    const/4 v2, 0x3

    return v0
.end method

.method public F()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->r:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->r:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x5

    return-object v0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public G()I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->s:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x0

    if-ltz v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const/4 v1, 0x5

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-gt v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    return v0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v0, -0x1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    return v0
.end method

.method public b()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method protected c()V
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v1, "eiiouluddb"

    const-string v1, "_lidodueib"

    const/4 v7, 0x2

    const-string/jumbo v1, "iiddbeupl_"

    const-string v1, "builder_id"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->d:I

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string v1, "girn"

    const-string/jumbo v1, "rnig"

    const/4 v7, 0x6

    const-string/jumbo v1, "nrgi"

    const-string/jumbo v1, "ring"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v2, 0x6

    const/4 v2, 0x1

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x3

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->e:I

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string/jumbo v1, "qirarb_n"

    const-string/jumbo v1, "rwarib_n"

    const/4 v7, 0x4

    const-string/jumbo v1, "raswr_gn"

    const-string/jumbo v1, "ring_raw"

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->l:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    const-string/jumbo v1, "nocreius"

    const/4 v7, 0x2

    const-string v1, "enomcis_"

    const-string v1, "icon_res"

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->j:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x7

    const-string/jumbo v1, "mlloopa_ic"

    const-string v1, "ac_lnlipmo"

    const/4 v7, 0x3

    const-string/jumbo v1, "loincb_mas"

    const-string/jumbo v1, "small_icon"

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->m:Ljava/lang/String;

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string v1, "gsqhti"

    const/4 v7, 0x4

    const-string/jumbo v1, "usthgl"

    const-string/jumbo v1, "lights"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->k:I

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v6, 0x4

    move v7, v6

    const-string/jumbo v1, "piverta"

    const-string/jumbo v1, "vibrate"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->f:I

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    const-string v1, "cino"

    const-string/jumbo v1, "noic"

    const/4 v7, 0x7

    const-string/jumbo v1, "nioc"

    const-string v1, "icon"

    const/4 v7, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->i:I

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string/jumbo v1, "iyecpstnq"

    const-string v1, "enstpi_cy"

    const/4 v7, 0x4

    const-string/jumbo v1, "tysine_po"

    const-string v1, "icon_type"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    const/4 v3, 0x0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x4

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->n:I

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string/jumbo v1, "ndi_"

    const-string/jumbo v1, "id_n"

    const/4 v7, 0x4

    const-string/jumbo v1, "in_d"

    const-string/jumbo v1, "n_id"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->h:I

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v1, "simme_dt"

    const-string/jumbo v1, "litmdse_"

    const/4 v7, 0x6

    const-string v1, "eysdot_l"

    const-string/jumbo v1, "style_id"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x5

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->o:I

    const/4 v7, 0x7

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    const-string v1, "dgsc_baoeeiorr_xmu"

    const-string/jumbo v1, "xeauo_mrgeoscr_dei"

    const/4 v7, 0x3

    const-string/jumbo v1, "xregdeurc_siuse_ao"

    const-string/jumbo v1, "xg_media_resources"

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x5

    const/4 v4, 0x0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v0, v1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->t:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string v1, "crexad_pbe_aiusroimugds_"

    const-string/jumbo v1, "m_sdebcaue__aeduxrsogrii"

    const/4 v7, 0x6

    const-string/jumbo v1, "ueeeuxodq_idrma_ogss_arc"

    const-string/jumbo v1, "xg_media_audio_resources"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0, v1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->v:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string/jumbo v1, "n_scui_"

    const-string v1, "i__dncu"

    const/4 v7, 0x0

    const-string/jumbo v1, "ih_mc_n"

    const-string/jumbo v1, "n_ch_id"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->p:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string v1, "he_noacp_"

    const-string v1, "an__chmpe"

    const/4 v7, 0x3

    const-string v1, "_amcnbe_h"

    const-string/jumbo v1, "n_ch_name"

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->q:Ljava/lang/String;

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v1, "n_oayguecr"

    const-string/jumbo v1, "rcae_gnyqo"

    const/4 v7, 0x1

    const-string v1, "_ogrtcnpye"

    const-string/jumbo v1, "n_category"

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-string v4, ""

    const-string v4, ""

    const/4 v7, 0x5

    const-string v4, ""

    const-string v4, ""

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v4}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->r:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-string v1, "cepantonq_sr"

    const-string v1, "aoscmtnnr_ep"

    const/4 v7, 0x1

    const-string/jumbo v1, "nrsimcetoan_"

    const-string/jumbo v1, "n_importance"

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v4, -0x1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->s:I

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {p0}, Lcom/tencent/android/tpush/message/d;->H()V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string/jumbo v1, "st_mhsypoeiw"

    const/4 v7, 0x3

    const-string/jumbo v1, "yi_mtpssoeh_"

    const-string/jumbo v1, "is_show_type"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    const/4 v5, 0x2

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v5}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x7

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->u:I

    const/4 v6, 0x1

    or-int/2addr v7, v6

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const-string/jumbo v1, "oorlo"

    const-string v1, "color"

    const/4 v6, 0x1

    xor-int/2addr v7, v6

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->A:I

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string/jumbo v1, "rlelcbaob"

    const-string/jumbo v1, "lbeaorecl"

    const/4 v7, 0x4

    const-string v1, "crleaeubl"

    const-string v1, "clearable"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez v0, :cond_0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;)I

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->g:I

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x2

    goto :goto_0

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    iput v2, p0, Lcom/tencent/android/tpush/message/d;->g:I

    :goto_0
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const-string/jumbo v1, "ipatbn"

    const-string/jumbo v1, "otinab"

    const/4 v7, 0x0

    const-string/jumbo v1, "noqcai"

    const-string v1, "action"

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-nez v0, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->w:Lcom/tencent/android/tpush/message/d$a;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v2, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/message/d$a;->a(Ljava/lang/String;)V

    :cond_1
    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v6, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string v1, "bpsg_dueea"

    const-string/jumbo v1, "yd_egaupeb"

    const/4 v7, 0x1

    const-string v1, "etempag_yd"

    const-string v1, "badge_type"

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->x:I

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string v1, "dp_iohred"

    const-string/jumbo v1, "rdtdi_hpe"

    const/4 v7, 0x7

    const-string v1, "d_athbedi"

    const-string/jumbo v1, "thread_id"

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->y:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string/jumbo v1, "metttuuhxdsr_q"

    const-string/jumbo v1, "tedetsrxq_thum"

    const/4 v7, 0x0

    const-string v1, "ertte_upsdtaxm"

    const-string/jumbo v1, "thread_sumtext"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->z:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/message/a;->a:Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string v1, "cmsostuytl_o_uoatrs_jn"

    const/4 v7, 0x2

    const-string/jumbo v1, "tyu_oo_lqtssar_cmuontj"

    const-string v1, "custom_layout_json_str"

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/message/d;->B:Ljava/lang/String;

    :try_start_0
    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    if-nez v0, :cond_2

    const/4 v6, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/message/d;->B:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-string/jumbo v1, "ypst_mtyoel"

    const-string v1, "e_tmltapyoy"

    const/4 v7, 0x2

    const-string/jumbo v1, "ytpmeualyo_"

    const-string/jumbo v1, "layout_type"

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    iput v1, p0, Lcom/tencent/android/tpush/message/d;->C:I

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-string/jumbo v1, "tdyuos__selet"

    const-string/jumbo v1, "sus_ot_eeldty"

    const-string/jumbo v1, "yestsbdtle__s"

    const-string/jumbo v1, "use_std_style"

    const/4 v7, 0x0

    invoke-virtual {v0, v1, v3}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    iput v0, p0, Lcom/tencent/android/tpush/message/d;->D:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x1

    goto :goto_1

    :catchall_0
    move-exception v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string v2, ":u turutoJmeaorsobLcsoS r nypsare"

    const-string v2, " nacobrysotserpumesSu  r:tLatoroJ"

    const/4 v7, 0x6

    const-string v2, " rsmn JpeoeLp ruttroctsryosSaauo:"

    const-string/jumbo v2, "parse customLayoutJsonStr error: "

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string/jumbo v1, "neeetdaNqsarosiufgoiHoliM"

    const-string/jumbo v1, "neiHsludfMroaacoigseeNoit"

    const/4 v7, 0x6

    const-string v1, "cNsoregaeMsottfdlnieHiaoi"

    const-string v1, "NotificationMessageHolder"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    return-void
.end method

.method public g()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->d:I

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method public h()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->e:I

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x0

    return v0
.end method

.method public i()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->f:I

    const/4 v2, 0x0

    return v0
.end method

.method public j()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->g:I

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    return v0
.end method

.method public k()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->h:I

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    return v0
.end method

.method public l()Lcom/tencent/android/tpush/message/d$a;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->w:Lcom/tencent/android/tpush/message/d$a;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method public m()I
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->i:I

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    return v0
.end method

.method public n()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->t:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method

.method public o()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->v:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-object v0
.end method

.method public p()I
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->k:I

    const/4 v2, 0x5

    return v0
.end method

.method public q()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->l:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method

.method public r()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->j:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object v0
.end method

.method public s()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->m:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public t()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->n:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    return v0
.end method

.method public u()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->o:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return v0
.end method

.method public v()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->p:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object v0
.end method

.method public w()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->q:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method public x()I
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->u:I

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    return v0
.end method

.method public y()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/message/d;->x:I

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x4

    return v0
.end method

.method public z()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/message/d;->y:Ljava/lang/String;

    const/4 v1, 0x0

    move v2, v1

    return-object v0
.end method
