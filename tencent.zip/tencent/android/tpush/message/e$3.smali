.class Lcom/tencent/android/tpush/message/e$3;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/message/e;->a(Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/message/e;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/message/e;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/message/e$3;->a:Lcom/tencent/android/tpush/message/e;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v0, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "~Ss@~Mtnoc ~@ti@~f @~ @@~  d@ouKo1l~a/ ~iyo ~@@@~v b/@~@m@ ~4@~@~  l~~s@ ~ ~bo@@~ @b@~o -~ ~rf. "

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$3;->a:Lcom/tencent/android/tpush/message/e;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/message/e;->a(Lcom/tencent/android/tpush/message/e;)Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/message/e$3;->a:Lcom/tencent/android/tpush/message/e;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/message/e;->a(Lcom/tencent/android/tpush/message/e;)Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    if-nez v0, :cond_1

    const/4 v6, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/message/e$3;->a:Lcom/tencent/android/tpush/message/e;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/message/e;->a(Lcom/tencent/android/tpush/message/e;)Landroid/content/Context;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/message/MessageManager;->getNewCachedMsgIntentList(Landroid/content/Context;)Ljava/util/ArrayList;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x2

    if-eqz v0, :cond_1

    const/4 v6, 0x4

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x7

    if-lez v1, :cond_1

    const/4 v6, 0x2

    sget-boolean v1, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string/jumbo v2, "nssmehsasHulgrePad"

    const-string v2, "hassudeeasenHlsgrP"

    const/4 v6, 0x0

    const-string v2, "duaHoasehrnPlsMsee"

    const-string v2, "PushMessageHandler"

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    if-eqz v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v3, "dw eybi n=rtMLsteicdt>z sCihmcngeSsidCMc-ohAega   a h"

    const-string v3, "LrhmSetCns>wiedtahchtz  ggy-sis a  dendCcsioi MMAc e="

    const/4 v6, 0x5

    const-string v3, "hA  gcuhhiogrdiae it=MLsdc a tn >dtySes-eiCMecC tswsn"

    const-string v3, "Action -> trySendCachedMsg with CachedMsgList size = "

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v3

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-ge v1, v3, :cond_1

    :try_start_0
    const/4 v6, 0x0

    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    check-cast v3, Landroid/content/Intent;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    iget-object v4, p0, Lcom/tencent/android/tpush/message/e$3;->a:Lcom/tencent/android/tpush/message/e;

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-static {v4, v3}, Lcom/tencent/android/tpush/message/e;->a(Lcom/tencent/android/tpush/message/e;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x1

    goto :goto_1

    :catchall_0
    move-exception v3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const-string v4, ""

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-static {v2, v4, v3}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_1
    const/4 v6, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x5

    goto :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    return-void
.end method
