.class public Lcom/tencent/android/tpush/message/f;
.super Lcom/tencent/android/tpush/message/a;


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/message/a;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method public b()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~osM~~ l@ @~~@s 1o ~@ ~o @d ~.@~v~@rin~@/~y~@m @@ ~of~Si4  t~  bb@~~~@ co@l~@bKo@ -~ @@uat/@f~i "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x1

    const/4 v0, 0x2

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    return v0
.end method

.method protected c()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    return-void
.end method
