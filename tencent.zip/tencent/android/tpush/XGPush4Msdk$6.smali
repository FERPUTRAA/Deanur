.class Lcom/tencent/android/tpush/XGPush4Msdk$6;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPush4Msdk;->setDefaultNotificationBuilder(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/XGPushNotificationBuilder;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$6;->a:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$6;->b:Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s~@~  f~ouK~1~~@itc b~M@ o4@ ~~@@a  ~S fd- ~@@i~@@s~ r@l~o@~vl ~@ o~o~@@~./ib @@y o@~nb~ /  mt"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$6;->a:Landroid/content/Context;

    const/4 v2, 0x2

    move v3, v2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$6;->b:Lcom/tencent/android/tpush/XGPushNotificationBuilder;

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/XGPushManager;->setDefaultNotificationBuilder(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushNotificationBuilder;)V

    const/4 v2, 0x7

    move v3, v2

    return-void
.end method
