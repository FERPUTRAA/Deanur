.class Lcom/tencent/android/tpush/service/b$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/b;->a(Landroid/content/Context;Ljava/lang/String;J)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "~@s ~.@@~~ u@/c  to@oafto/ ~ 4~ ~@ l~@l b@@~@o@~S @i~~o  imbds~~vM~ b@@@~~@n~o~@i@~ @K-r1 ~  ~y@"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x3

    const/4 p1, 0x1

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/service/b;->a(Z)Z

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    const-string p1, "iSPmeareecsMvnahug"

    const-string p1, "SessuengehacivarPM"

    const/4 v1, 0x4

    const-string/jumbo p1, "ureaoeaScMhgenPrvs"

    const-string p1, "PushServiceManager"

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    const-string p2, "XrdnibSoSCvceGP oecectrsiehnnemu"

    const-string/jumbo p2, "viomeucSPtrnrnGeseSdvocceXCheni "

    const/4 v1, 0x6

    const-string p2, "desneiuuPScSXroecoeennrthceGvCiv"

    const-string p2, "XGPushService onServiceConnected"

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 p1, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/service/b;->a(Z)Z

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string p1, "eaoSehPpeusgMacvrr"

    const-string/jumbo p1, "vnrcoeuaSePhgsaMer"

    const/4 v2, 0x5

    const-string p1, "PvraegaSqhnMuicree"

    const-string p1, "PushServiceManager"

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string v0, "SGsensuDbceieseXrnernhSoPvivctoedc "

    const-string v0, "etvDobcPenicsdurhec eocXnnevSsiGSer"

    const/4 v2, 0x0

    const-string v0, "dermS neievrnGnscPiecseDXvouicteohS"

    const-string v0, "XGPushService onServiceDisconnected"

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-void
.end method
