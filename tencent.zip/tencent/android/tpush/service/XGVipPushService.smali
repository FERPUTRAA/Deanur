.class public Lcom/tencent/android/tpush/service/XGVipPushService;
.super Landroid/app/Service;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20150316"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->SERVICESCHECK:Lcom/jg/EType;
    }
.end annotation


# static fields
.field private static volatile b:Ljava/lang/String; = null

.field private static c:J = 0x0L

.field private static d:Lorg/json/JSONArray; = null

.field private static e:J = 0x41eb0L

.field private static f:Landroid/app/Service;


# instance fields
.field a:Lcom/tencent/tpns/baseapi/base/util/TTask;

.field private g:Landroid/os/Handler;

.field private h:Z


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x7

    const/4 v0, 0x0

    iput-boolean v0, p0, Lcom/tencent/android/tpush/service/XGVipPushService;->h:Z

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    new-instance v0, Lcom/tencent/android/tpush/service/XGVipPushService$2;

    const/4 v2, 0x7

    const/4 v1, 0x5

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/service/XGVipPushService$2;-><init>(Lcom/tencent/android/tpush/service/XGVipPushService;)V

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/service/XGVipPushService;->a:Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method static synthetic a(J)J
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "n~s~i~rl~to~@o @ct i~~ @d~@@ ~/@s@@~@liS@~~~4  @f @@/ fo@ v~o1M@~~ m~~@~b o o -~ a @ubK~.@ @@ yb"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x2

    sput-wide p0, Lcom/tencent/android/tpush/service/XGVipPushService;->e:J

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x4

    return-wide p0
.end method

.method public static a()Landroid/app/Service;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/android/tpush/service/XGVipPushService;->f:Landroid/app/Service;

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    return-object v0
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/XGVipPushService;)Landroid/os/Handler;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/tencent/android/tpush/service/XGVipPushService;->g:Landroid/os/Handler;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-object p0
.end method

.method private declared-synchronized a(Landroid/content/Intent;Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v0, "siimseuGpPVrShve"

    const-string v0, "evscrhiGpuesSiPV"

    const-string/jumbo v0, "vhXeoeSriGucPVsi"

    const-string v0, "XGVipPushService"

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const-string v2, "cnni beHv oltddmiir:heiSe amh wtt"

    const-string/jumbo v2, "lwemhnid HetidenatSvoi thcir :m r"

    const/4 v5, 0x1

    const-string v2, " :elhdu odieaemii tthieHnrv cnwSt"

    const-string/jumbo v2, "initServiceHandler with method : "

    const/4 v5, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    :try_start_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result p2

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-lez p2, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string/jumbo p1, "sceGoeSpVXuPvihi"

    const/4 v5, 0x5

    const-string/jumbo p1, "vsrPihcpXSuVepei"

    const-string p1, "XGVipPushService"

    const/4 v5, 0x3

    const-string p2, "Grloanblqrieorti"

    const-string p2, "biarrblinteoolrG"

    const/4 v5, 0x5

    const-string/jumbo p2, "nrsoitilaGr rlbe"

    const-string/jumbo p2, "initGlobal error"

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/g;->e(Landroid/content/Context;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    monitor-exit p0

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v4, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz p1, :cond_2

    :try_start_2
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    sget-object p2, Lcom/tencent/android/tpush/service/XGVipPushService;->d:Lorg/json/JSONArray;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez p2, :cond_1

    const/4 v5, 0x6

    new-instance p2, Lorg/json/JSONArray;

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-direct {p2}, Lorg/json/JSONArray;-><init>()V

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    sput-object p2, Lcom/tencent/android/tpush/service/XGVipPushService;->d:Lorg/json/JSONArray;

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x7

    sget-object v0, Lcom/tencent/android/tpush/service/XGVipPushService;->d:Lorg/json/JSONArray;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v0, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x3

    const/16 v1, 0xa

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-ge v0, v1, :cond_2

    :try_start_3
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x7

    const-string/jumbo v0, "todm.nicotopmrcesc.untiun.anhe.a"

    const-string/jumbo v0, "maat.huocotntrinncd.p.esntueic.o"

    const/4 v5, 0x1

    const-string v0, ".neroocncadptmsio.uatntoic.ntdhe"

    const-string v0, "com.tencent.android.tpush.action"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v5, 0x4

    const/4 v4, 0x1

    invoke-virtual {p2, v0, v1}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object p2
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_0

    :catchall_0
    move-exception v0

    :try_start_4
    const/4 v5, 0x7

    const/4 v4, 0x2

    const-string v1, "VrsePbpXeiGciuph"

    const-string v1, "hVcepPspSuGeiriX"

    const/4 v5, 0x5

    const-string/jumbo v1, "iuVcpGuPeXhrevSi"

    const-string v1, "XGVipPushService"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const-string v3, "eiintc p :ltvreeaderuepoxncnrdefHq"

    const-string/jumbo v3, "ifed ntdq ecSeclvinrtpoHnuxree:rea"

    const-string/jumbo v3, "xreecteeqfounHnpcadirnSv t:eierli "

    const-string/jumbo v3, "unexpected for initServiceHandler:"

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    move v5, v4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget-object v0, Lcom/tencent/android/tpush/service/XGVipPushService;->d:Lorg/json/JSONArray;

    const/4 v5, 0x0

    invoke-virtual {v0, p2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-static {p2}, Lcom/tencent/android/tpush/service/util/b;->a(Landroid/content/Context;)V

    const/4 v4, 0x7

    or-int/2addr v5, v4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->b()Lcom/tencent/android/tpush/service/b;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p2, p1}, Lcom/tencent/android/tpush/service/b;->a(Landroid/content/Intent;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto :goto_1

    :catchall_1
    move-exception p1

    :try_start_5
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string/jumbo p2, "sGsrXcisVSPhieev"

    const-string/jumbo p2, "iusPGVcvSsrhieeX"

    const/4 v5, 0x2

    const-string p2, "hecmVGPiursSivpX"

    const-string p2, "XGVipPushService"

    const/4 v5, 0x2

    const-string/jumbo v0, "nSldotriHviamniree"

    const-string v0, "eHlmnariiirvdeentS"

    const/4 v5, 0x6

    const-string/jumbo v0, "reniebtcraeiSHdnvl"

    const-string/jumbo v0, "initServiceHandler"

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {p2, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_2

    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    monitor-exit p0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    return-void

    :catchall_2
    move-exception p1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x2

    monitor-exit p0

    const/4 v5, 0x3

    throw p1
.end method

.method static synthetic b()Landroid/app/Service;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/android/tpush/service/XGVipPushService;->f:Landroid/app/Service;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object v0
.end method

.method static synthetic c()J
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    sget-wide v0, Lcom/tencent/android/tpush/service/XGVipPushService;->e:J

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-wide v0
.end method

.method private d()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string/jumbo v0, "preiiGuhuVscXovP"

    const-string v0, "iGiPoVhvpueesrXc"

    const/4 v5, 0x1

    const-string v0, "iSepeicpXvuGVhrs"

    const-string v0, "XGVipPushService"

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v1, "Mineoc,nq aolstleak6gsnH0h dtriseC - tnircabee"

    const-string v1, "enathbndea-sMes ,ikcCr6etit0g l ncarliH eaosno"

    const/4 v5, 0x0

    const-string v1, "dssietMcenineat c- ere6o gh aa0ka, HslloCinsrt"

    const-string v1, "action - initCheckMessageHandler, on 60s later"

    const/4 v4, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    new-instance v0, Landroid/os/Handler;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-direct {v0}, Landroid/os/Handler;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/service/XGVipPushService;->g:Landroid/os/Handler;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/service/XGVipPushService;->a:Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-wide/32 v2, 0xea60

    const-wide/32 v2, 0xea60

    const/4 v5, 0x5

    const-wide/32 v2, 0xea60

    const-wide/32 v2, 0xea60

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    const/4 v4, 0x7

    or-int/2addr v5, v4

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v0, "XVemresvicpiSPuu"

    const-string v0, "ervPeiuphVcsSiXu"

    const/4 v3, 0x2

    const-string v0, "VpeiocPiveXSGhsu"

    const-string v0, "XGVipPushService"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v1, "ie)odbBSn (vircp"

    const-string v1, "cSrB v(pedi)noin"

    const/4 v3, 0x3

    const-string v1, "Bv einuScne)o(rd"

    const-string v1, "Service onBind()"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    iget-boolean v0, p0, Lcom/tencent/android/tpush/service/XGVipPushService;->h:Z

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-nez v0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    const-string/jumbo v0, "npnioB"

    const-string/jumbo v0, "oBqinn"

    const-string v0, "dnqnoB"

    const-string/jumbo v0, "onBind"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0, p1, v0}, Lcom/tencent/android/tpush/service/XGVipPushService;->a(Landroid/content/Intent;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    iput-boolean v0, p0, Lcom/tencent/android/tpush/service/XGVipPushService;->h:Z

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    iget-object v0, v0, Lcom/tencent/android/tpush/c/a;->a:Lcom/tencent/android/tpush/c/a$c;

    const/4 v3, 0x1

    invoke-virtual {v0, p1}, Lcom/tencent/tpns/mqttchannel/services/BaseMqttClientService;->onBind(Landroid/content/Intent;)Landroid/os/IBinder;

    move-result-object p1

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    return-object p1
.end method

.method public onCreate()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const/4 v3, 0x7

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/security/Security;->checkTpnsSecurityLibSo(Landroid/content/Context;)Z

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    sput-wide v0, Lcom/tencent/android/tpush/service/XGVipPushService;->c:J

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    sput-object p0, Lcom/tencent/android/tpush/service/XGVipPushService;->f:Landroid/app/Service;

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x1

    const/4 v1, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/service/util/b;->a(Landroid/content/Context;Z)Z

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/XGVipPushService;->d()V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    return-void
.end method

.method public onDestroy()V
    .locals 4

    const/4 v3, 0x3

    const-string v0, "GssucviXVPsepihr"

    const-string v0, "XusipSesvrciPVGh"

    const/4 v3, 0x4

    const-string/jumbo v0, "shGmVpPvueXieirc"

    const-string v0, "XGVipPushService"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string/jumbo v1, "onDestroy"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    new-instance v1, Lcom/tencent/android/tpush/service/XGVipPushService$1;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/service/XGVipPushService$1;-><init>(Lcom/tencent/android/tpush/service/XGVipPushService;)V

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-super {p0}, Landroid/app/Service;->onDestroy()V

    const/4 v2, 0x0

    move v3, v2

    return-void
.end method

.method public onStart(Landroid/content/Intent;I)V
    .locals 4

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    const-string/jumbo v1, "vSarom co(nie St): r"

    const-string v1, "aS)m vo  nctSeirr:e("

    const/4 v3, 0x7

    const-string v1, "S:vo bc)Snrtrat eie("

    const-string v1, "Service onStart() : "

    const/4 v2, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string v1, "eSoXhPueVpcuriGv"

    const-string/jumbo v1, "vsePoGpeuXciShVr"

    const/4 v3, 0x6

    const-string v1, "cepXveSphuPiViGs"

    const-string v1, "XGVipPushService"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-super {p0, p1, p2}, Landroid/app/Service;->onStart(Landroid/content/Intent;I)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 4
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "WrongConstant"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "r m(ocndq:rtenbtCo  am)eaSS"

    const-string/jumbo v1, "ot)  bCndSrSern a(cvtmao:me"

    const/4 v3, 0x1

    const-string v1, "e sn S(toanm)C:domvrtia cer"

    const-string v1, "Service onStartCommand() : "

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string v1, "cSpmuisVvXPGihue"

    const-string v1, "GucesvupPSVeiXhi"

    const/4 v3, 0x1

    const-string v1, "XGVipPushService"

    const/4 v2, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-super {p0, p1, p2, p3}, Landroid/app/Service;->onStartCommand(Landroid/content/Intent;II)I

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    const-string/jumbo p2, "rmpmonStodtaCa"

    const-string p2, "CaoaotSptmndrm"

    const/4 v3, 0x6

    const-string/jumbo p2, "otCorbaanmmSnt"

    const-string/jumbo p2, "onStartCommand"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/XGVipPushService;->a(Landroid/content/Intent;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 p1, 0x2

    const/4 v3, 0x6

    or-int/2addr v2, p1

    const/4 v3, 0x0

    return p1
.end method
