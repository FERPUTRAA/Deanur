.class Lcom/tencent/android/tpush/service/a$d$2;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a$d;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/service/a$d;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a$d;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$d$2;->b:Lcom/tencent/android/tpush/service/a$d;

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpush/service/a$d$2;->a:Landroid/content/Context;

    const/4 v1, 0x2

    const/4 v0, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@s@l~o~@~/@St~M~s~bf ~ @y b v@ @i~d  @ba@~ o@ 4~u~~~@ @~  .i/-tno  oi@o@1K  om~cr@~~@ f@@~l~@~@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    const-string/jumbo v0, "loHmdsicsrnhteucsdeSraavaer"

    const-string v0, "cusoeacseanBlrhrdtHsSirveda"

    const/4 v3, 0x1

    const-string v0, "esdeonrScdPaavaslrBihHrouec"

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string v1, "etCmt--ccnari-evUsrrte nresPeo een-st"

    const/4 v3, 0x5

    const-string/jumbo v1, "sRCntbPrea-tUnecrreeceotv-s  -itse-en"

    const-string v1, "--start Connect UserPresentReceiver--"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    iget-object v0, v0, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/c/a$a;->a(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    const/4 v3, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$d$2;->a:Landroid/content/Context;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/a;->b(Landroid/content/Context;)V

    const/4 v2, 0x3

    const/4 v3, 0x0

    return-void
.end method
