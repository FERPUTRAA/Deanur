.class Lcom/tencent/android/tpush/service/a$4;
.super Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a;->a(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/service/a;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$4;->b:Lcom/tencent/android/tpush/service/a;

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpush/service/a$4;->a:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public callback(ILjava/lang/String;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "/@s~4f@~~ ~  ~@ ~1~ @i~@fd~~o @~t  @vlS@~@M~. o~~mo@Kabyb@~oo@u@ ~@@t   n~o@-l/ @cb~~rs~ ~ @@ii@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v1, ".etmiHTaNAEKeocCTmd.EpOndnSCccCsaUCri.4n.RET..oi_Sx_.LTnVEogtN."

    const-string v1, ".Es..._NpEeCtTTiSV.cACHneonaOnK4cLN_gCit.ToCxTioa.rUnEtdERd.cSm"

    const-string/jumbo v1, "p..Co.CiavSoi.dEdHCTUi.tTgcnn.eoT.t._4TErECVtRKo_mASxncNOaELnNc"

    const-string v1, "com.tencent.android.xg.vip.action.CHECK_CONNECT_STATE.RESULT.V4"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x2

    const-string/jumbo v1, "neatobecncmt"

    const-string/jumbo v1, "necmcSettano"

    const/4 v4, 0x7

    const-string/jumbo v1, "ottencuScnat"

    const-string v1, "connectState"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez p1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {p2}, Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;->valueOf(Ljava/lang/String;)Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    sget-object v2, Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;->CONNECTED:Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eq p1, v2, :cond_0

    const/4 v3, 0x0

    move v4, v3

    invoke-static {p2}, Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;->valueOf(Ljava/lang/String;)Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    sget-object p2, Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;->SUBTOPICS:Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ne p1, p2, :cond_1

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    const/4 p1, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const/4 v4, 0x7

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 p1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/service/a$4;->a:Landroid/content/Context;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    return-void
.end method
