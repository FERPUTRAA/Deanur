.class Lcom/tencent/android/tpush/service/a$d$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a$d;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/a$d;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a$d;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$d$1;->a:Lcom/tencent/android/tpush/service/a$d;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "t@s@~l/o@~~  fi @@.@m ~t~@  l@uKr@@ c@S~ @ o~bobs -~~~ida~i4b ~o~ ~ M~ ~~@~@@~@@1/ fyo no ~@v~@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    const-string/jumbo v0, "rnlmcrdcatdaeviesPsSHrsouah"

    const-string v0, "HlsPitShaurvccresasearBdndo"

    const/4 v3, 0x7

    const-string/jumbo v0, "nSoeoteHvsrisrehBuPdadcalra"

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v1, "rca tbeltowetkn t ,ocIrrrndtneeens"

    const-string/jumbo v1, "naomr drerl tcnttIecntwrtneeokes ,"

    const/4 v3, 0x1

    const-string/jumbo v1, "ra Iocunerenwnse neeltttnrt,co kdt"

    const-string v1, "Internl network connected, restart"

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    iget-object v0, v0, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/c/a$a;->a(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method
