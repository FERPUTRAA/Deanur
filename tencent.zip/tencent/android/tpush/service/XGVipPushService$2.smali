.class Lcom/tencent/android/tpush/service/XGVipPushService$2;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/service/XGVipPushService;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/XGVipPushService;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/XGVipPushService;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/service/XGVipPushService$2;->a:Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~s@@@ o ~s~~/4uo i~ cb  ~f~i@~@y~@~@~m~S-@fn@ ai~@o@  @~  @ ~ @ @@ Kr ~ol~bo~Md.tvo1~~~tb@l~@/@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v1, Lcom/tencent/android/tpush/service/XGVipPushService$2$1;

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/service/XGVipPushService$2$1;-><init>(Lcom/tencent/android/tpush/service/XGVipPushService$2;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x6

    const/4 v2, 0x6

    return-void
.end method
