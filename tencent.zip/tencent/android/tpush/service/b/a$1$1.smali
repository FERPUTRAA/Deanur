.class Lcom/tencent/android/tpush/service/b/a$1$1;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/content/ServiceConnection;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/service/b/a$1;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/b/a$1;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/b/a$1;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1$1;->a:Lcom/tencent/android/tpush/service/b/a$1;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    return-void
.end method


# virtual methods
.method public onServiceConnected(Landroid/content/ComponentName;Landroid/os/IBinder;)V
    .locals 3

    :try_start_0
    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " ss@f ~~a @.@i~~~@~@K ~c~~~~@/t b@ l~~b@M4@@~-o~@@~@l  1~ @uo@  @i~~yt~@ @v@ oo~@~ mnfd  b/rSoi "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1$1;->a:Lcom/tencent/android/tpush/service/b/a$1;

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-static {p2}, Lcom/tencent/android/tpush/rpc/a$a;->a(Landroid/os/IBinder;)Lcom/tencent/android/tpush/rpc/a;

    move-result-object p2

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/service/b/a$1;->a(Lcom/tencent/android/tpush/service/b/a$1;Lcom/tencent/android/tpush/rpc/a;)Lcom/tencent/android/tpush/rpc/a;

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1$1;->a:Lcom/tencent/android/tpush/service/b/a$1;

    const/4 v2, 0x6

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/service/b/a$1;->a(Lcom/tencent/android/tpush/service/b/a$1;)Lcom/tencent/android/tpush/rpc/a;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1$1;->a:Lcom/tencent/android/tpush/service/b/a$1;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/service/b/a$1;->a(Lcom/tencent/android/tpush/service/b/a$1;)Lcom/tencent/android/tpush/rpc/a;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x7

    iget-object p2, p0, Lcom/tencent/android/tpush/service/b/a$1$1;->a:Lcom/tencent/android/tpush/service/b/a$1;

    const/4 v2, 0x1

    const/4 v1, 0x6

    iget-object p2, p2, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-virtual {p2}, Landroid/content/Intent;->toURI()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/service/b/a$1$1;->a:Lcom/tencent/android/tpush/service/b/a$1;

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/service/b/a$1;->b(Lcom/tencent/android/tpush/service/b/a$1;)Lcom/tencent/android/tpush/rpc/c;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-interface {p1, p2, v0}, Lcom/tencent/android/tpush/rpc/a;->a(Ljava/lang/String;Lcom/tencent/android/tpush/rpc/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string p2, "MesmMgneaseSrgvaa"

    const-string p2, "avsaragMeseSrgMen"

    const/4 v2, 0x7

    const-string p2, "eassoregMagSvnaMr"

    const-string p2, "SrvMessageManager"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string v0, "cCdaebRasPBBmtSnyd"

    const-string/jumbo v0, "nBemddcaatPySsCoRB"

    const-string/jumbo v0, "rydsPRutoSBnaCaecB"

    const-string v0, "SendBroadcastByRPC"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p2, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-void
.end method

.method public onServiceDisconnected(Landroid/content/ComponentName;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1$1;->a:Lcom/tencent/android/tpush/service/b/a$1;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/service/b/a$1;->a(Lcom/tencent/android/tpush/service/b/a$1;Landroid/content/ServiceConnection;)Landroid/content/ServiceConnection;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1$1;->a:Lcom/tencent/android/tpush/service/b/a$1;

    const/4 v2, 0x5

    const/4 v1, 0x7

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/service/b/a$1;->a(Lcom/tencent/android/tpush/service/b/a$1;Lcom/tencent/android/tpush/rpc/a;)Lcom/tencent/android/tpush/rpc/a;

    const/4 v2, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1$1;->a:Lcom/tencent/android/tpush/service/b/a$1;

    const/4 v2, 0x5

    const/4 v1, 0x4

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/service/b/a$1;->a(Lcom/tencent/android/tpush/service/b/a$1;Lcom/tencent/android/tpush/rpc/c;)Lcom/tencent/android/tpush/rpc/c;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method
