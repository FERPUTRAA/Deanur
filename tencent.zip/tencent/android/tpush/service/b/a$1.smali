.class Lcom/tencent/android/tpush/service/b/a$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/b/a;->a(Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Lcom/tencent/android/tpush/service/b/a;

.field private c:Lcom/tencent/android/tpush/rpc/a;

.field private d:Lcom/tencent/android/tpush/rpc/c;

.field private e:Landroid/content/ServiceConnection;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/b/a;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1;->b:Lcom/tencent/android/tpush/service/b/a;

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x4

    new-instance p1, Lcom/tencent/android/tpush/rpc/c;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p1}, Lcom/tencent/android/tpush/rpc/c;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1;->d:Lcom/tencent/android/tpush/rpc/c;

    const/4 v1, 0x1

    new-instance p1, Lcom/tencent/android/tpush/service/b/a$1$1;

    const/4 v0, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p1, p0}, Lcom/tencent/android/tpush/service/b/a$1$1;-><init>(Lcom/tencent/android/tpush/service/b/a$1;)V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1;->e:Landroid/content/ServiceConnection;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/b/a$1;Landroid/content/ServiceConnection;)Landroid/content/ServiceConnection;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "t4s ooi~s~b~~a@K~~~ i@/~@ ~  @~ ~nlb@@@oo  ~t@~ ~~ m .~ l@Sf@v/M@ry@c~@~~~~ @~ i-f1@@o@ bo@@@u d"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1;->e:Landroid/content/ServiceConnection;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/b/a$1;)Lcom/tencent/android/tpush/rpc/a;
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/tencent/android/tpush/service/b/a$1;->c:Lcom/tencent/android/tpush/rpc/a;

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    return-object p0
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/b/a$1;Lcom/tencent/android/tpush/rpc/a;)Lcom/tencent/android/tpush/rpc/a;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1;->c:Lcom/tencent/android/tpush/rpc/a;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-object p1
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/b/a$1;Lcom/tencent/android/tpush/rpc/c;)Lcom/tencent/android/tpush/rpc/c;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/service/b/a$1;->d:Lcom/tencent/android/tpush/rpc/c;

    const/4 v0, 0x3

    move v1, v0

    return-object p1
.end method

.method static synthetic b(Lcom/tencent/android/tpush/service/b/a$1;)Lcom/tencent/android/tpush/rpc/c;
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iget-object p0, p0, Lcom/tencent/android/tpush/service/b/a$1;->d:Lcom/tencent/android/tpush/rpc/c;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-object p0
.end method


# virtual methods
.method public TRun()V
    .locals 13

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x3

    const-string v0, "SMsvsrensaeggMare"

    const/4 v12, 0x2

    const-string/jumbo v0, "saMmvaggeMSrrsnae"

    const-string v0, "SrvMessageManager"

    :try_start_0
    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x2

    invoke-virtual {v3}, Landroid/content/Intent;->getPackage()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x4

    const-string v3, "S_TCoVGPUNAH.mIPO_"

    const-string v3, "PSCmTIOHGV_PAX_N.U"

    const/4 v12, 0x5

    const-string v3, "C_TS.bXNHOVAUPPGII"

    const-string v3, ".XGVIP_PUSH_ACTION"

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/b/a$1;->d:Lcom/tencent/android/tpush/rpc/c;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/service/b/a$1;->e:Landroid/content/ServiceConnection;

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-virtual {v1, v2}, Lcom/tencent/android/tpush/rpc/c;->a(Landroid/content/ServiceConnection;)V

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v1

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/service/b/a$1;->e:Landroid/content/ServiceConnection;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    const/4 v4, 0x1

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-virtual {v1, v2, v3, v4}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    move-result v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x7

    const/4 v11, 0x2

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v12, 0x2

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x3

    const-string v4, "guoIs"

    const-string v4, "Igmso"

    const/4 v12, 0x3

    const-string v4, "Impgd"

    const-string/jumbo v4, "msgId"

    const/4 v12, 0x1

    const/4 v11, 0x5

    const/4 v12, 0x7

    if-nez v1, :cond_0

    :try_start_1
    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x1

    const-string v5, " eSLei FqandDIld"

    const-string v5, "Failed Send AIDL"

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget-object v5, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x6

    const-string v5, "d s = l fma desii"

    const-string v5, " failed  msgid = "

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x4

    iget-object v5, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    invoke-virtual {v5, v4, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v2

    const/4 v12, 0x6

    const/4 v11, 0x4

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v1

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v2

    const/4 v12, 0x7

    const/4 v11, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x4

    invoke-virtual {v3}, Landroid/content/Intent;->getPackage()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget-object v4, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v11, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-virtual {v1, v2, v3, v4}, Lcom/tencent/android/tpush/message/MessageManager;->addCachedMsgIntentByPkgName(Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;)V

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v5

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    const/16 v6, -0x68

    const/4 v12, 0x1

    const/4 v11, 0x5

    const-string/jumbo v7, "laemfenimv eibscededab  uroiner rlts "

    const-string/jumbo v7, "teerabfeetcmbioens lrn isve  ua rldid"

    const/4 v12, 0x1

    const-string v7, "ed oor incaurbrldre efnteeat vmssl ei"

    const-string v7, "bind aidl remote service return false"

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x1

    const-wide/16 v8, 0x0

    const/4 v12, 0x6

    const-string v10, "bruen"

    const-string/jumbo v10, "nuner"

    const/4 v12, 0x4

    const-string/jumbo v10, "nunei"

    const-string/jumbo v10, "inner"

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-static/range {v5 .. v10}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x5

    goto/16 :goto_0

    :cond_0
    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x7

    const-string v5, " ILdAecpceudepn S"

    const-string v5, "edSeSucpILnA d ce"

    const/4 v12, 0x3

    const-string v5, "DAeSed nqLcIdS cu"

    const-string v5, "Succeed Send AIDL"

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x6

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x6

    iget-object v5, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    const-string v5, "esscgcs =s mqi s d"

    const-string v5, " u s = gqcimdscses"

    const/4 v12, 0x7

    const-string/jumbo v5, "igum m c ss=se sc "

    const-string v5, " success  msgid = "

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-virtual {v1, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x6

    iget-object v5, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-virtual {v5, v4, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v2

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x2

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    and-int/2addr v12, v11

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x1

    const/4 v11, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/service/b/a$1;->b:Lcom/tencent/android/tpush/service/b/a;

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v2

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {v1, v2, v3}, Lcom/tencent/android/tpush/service/b/a;->a(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x3

    goto/16 :goto_0

    :catchall_0
    move-exception v1

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x3

    const-string v2, "a RPo >dterrBoScedBSnisdnvsc-abiy"

    const-string v2, " isodetSinnvRadsd-yPr>SacBBceebr "

    const/4 v12, 0x1

    const-string v2, " >deSbB- eioCnPcdaBebaRcSrvrisytd"

    const-string v2, "SendBroadcastByRPC -> bindService"

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v0

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v2

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {v3}, Landroid/content/Intent;->getPackage()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpush/service/b/a$1;->a:Landroid/content/Intent;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-virtual {v0, v2, v3, v4}, Lcom/tencent/android/tpush/message/MessageManager;->addCachedMsgIntentByPkgName(Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;)V

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v5

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x5

    const/16 v6, -0x68

    const/4 v12, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x1

    const-string/jumbo v2, "m e rluvinaeobedirre tes crdi"

    const-string/jumbo v2, "rramioe r b dilncrvt deemsiee"

    const/4 v12, 0x7

    const-string v2, " everdtp:oreica sli dben mrie"

    const-string v2, "bind aidl remote service err:"

    const/4 v12, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-static {v1}, Lcom/tencent/tpns/baseapi/base/util/Util;->getThrowableToString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v7

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x5

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v12, 0x2

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    const-string/jumbo v10, "rnnqe"

    const-string/jumbo v10, "inner"

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x4

    invoke-static/range {v5 .. v10}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    :goto_0
    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x5

    return-void
.end method
