.class public Lcom/tencent/android/tpush/service/b/a;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20150316"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->INTENTSCHEMECHECK:Lcom/jg/EType;,
        .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;,
        .enum Lcom/jg/EType;->RECEIVERCHECK:Lcom/jg/EType;
    }
.end annotation


# static fields
.field private static a:Lcom/tencent/android/tpush/service/b/a;

.field private static final b:[B

.field private static c:J

.field private static volatile d:Z

.field private static volatile e:Z

.field private static volatile f:Z

.field private static volatile g:Z

.field private static h:Ljava/util/concurrent/ConcurrentHashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/concurrent/ConcurrentHashMap<",
            "Ljava/lang/Long;",
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;>;>;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x1

    new-instance v0, Lcom/tencent/android/tpush/service/b/a;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-direct {v0}, Lcom/tencent/android/tpush/service/b/a;-><init>()V

    const/4 v3, 0x1

    move v4, v3

    sput-object v0, Lcom/tencent/android/tpush/service/b/a;->a:Lcom/tencent/android/tpush/service/b/a;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v0, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    new-array v1, v0, [B

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    sput-object v1, Lcom/tencent/android/tpush/service/b/a;->b:[B

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    sput-wide v1, Lcom/tencent/android/tpush/service/b/a;->c:J

    const/4 v4, 0x5

    sput-boolean v0, Lcom/tencent/android/tpush/service/b/a;->d:Z

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    sput-boolean v0, Lcom/tencent/android/tpush/service/b/a;->e:Z

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    sput-boolean v0, Lcom/tencent/android/tpush/service/b/a;->f:Z

    const/4 v3, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    sput-boolean v0, Lcom/tencent/android/tpush/service/b/a;->g:Z

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    sput-object v0, Lcom/tencent/android/tpush/service/b/a;->h:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    return-void
.end method

.method public static a()Lcom/tencent/android/tpush/service/b/a;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "i~s~ /~a@ol lS1f~.@ @@ ~  ~o~@@ c-~@@@@ r~@~o ooni@ m@@b~M4@y@~t~/~~~K@ v ~~@ fb~~ ~b@ du ~sit@o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/service/b/a;->c()V

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/service/b/a;->a:Lcom/tencent/android/tpush/service/b/a;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-object v0
.end method

.method private a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;
    .locals 3

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/service/util/e;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/common/e;->a(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1

    :catchall_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string p2, "assMSeneesaravrgg"

    const/4 v2, 0x1

    const-string p2, "aMMmssSgnrevgeare"

    const-string p2, "SrvMessageManager"

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string/jumbo p3, "sngmeetttiS"

    const/4 v2, 0x5

    const-string/jumbo p3, "tstnogeiSgt"

    const-string p3, "getSettings"

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {p2, p3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    const/4 p1, 0x0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p1
.end method

.method private a(Landroid/content/Context;Ljava/lang/String;)Ljava/util/ArrayList;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/android/tpush/data/MessageId;",
            ">;"
        }
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x3

    if-eqz p1, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string v0, "d.dsibspsknn.os.et..m"

    const-string v0, ".nedotin.pkd.gmss..ss"

    const-string/jumbo v0, "p.gi.sude..sdnk.tsndm"

    const-string v0, ".tpns.msg.id.send.sdk"

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0, p1, p2, v0}, Lcom/tencent/android/tpush/service/b/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    if-eqz p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    check-cast p1, Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    goto :goto_0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 p1, 0x0

    :goto_0
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-nez p1, :cond_1

    const/4 v2, 0x3

    const/4 v1, 0x6

    new-instance p1, Ljava/util/ArrayList;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    :cond_1
    const/4 v2, 0x7

    return-object p1
.end method

.method private static a(Lorg/json/JSONArray;)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Lorg/json/JSONArray;",
            ")",
            "Ljava/util/List<",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz p0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {p0}, Lorg/json/JSONArray;->length()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-ge v1, v2, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0, v1}, Lorg/json/JSONArray;->getLong(I)J

    move-result-wide v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {v2, v3}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-object v0
.end method

.method private declared-synchronized a(Landroid/content/Context;Lcom/tencent/android/tpush/data/MessageId;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    monitor-enter p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x7

    monitor-exit p0

    const/4 v1, 0x3

    return-void
.end method

.method private a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "*>;)V"
        }
    .end annotation

    :try_start_0
    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p4}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x6

    const/16 v1, 0x32

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-le v0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x4

    const/16 v1, 0xa

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    invoke-virtual {p4, v0, v1}, Ljava/util/ArrayList;->subList(II)Ljava/util/List;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    invoke-interface {v0}, Ljava/util/List;->clear()V

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p4}, Lcom/tencent/android/tpush/common/e;->a(Ljava/io/Serializable;)Ljava/lang/String;

    move-result-object p4

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {p4}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p4

    const/4 v3, 0x5

    const/4 v2, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-static {p1, p2, p4}, Lcom/tencent/android/tpush/service/util/e;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string p2, "ggasrMrpnaMaeSsve"

    const-string p2, "SrvMessageManager"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string/jumbo p3, "tgiuseSbqtp"

    const-string p3, "epnttbgSisu"

    const/4 v3, 0x5

    const-string/jumbo p3, "itsetnSutpg"

    const-string/jumbo p3, "putSettings"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p2, p3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    return-void
.end method

.method private a(Lcom/tencent/android/tpush/service/protocol/j;JLcom/tencent/android/tpush/service/channel/a;)V
    .locals 23

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v1, p0

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    move-object/from16 v2, p1

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, "brDmuKt:ii 2tSde"

    const-string v3, "d:ti2SuibuKDter "

    const-string v3, "2Ss ouKttDidi:br"

    const-string v3, "distribute2SDK: "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual/range {p1 .. p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string v3, "evsgebaMMgSsarrpn"

    const-string v3, "eSeeaggprMsvsarnM"

    const-string/jumbo v3, "sanMgsurSaeegraev"

    const-string v3, "SrvMessageManager"

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v10

    new-instance v4, Landroid/content/Intent;

    const-string/jumbo v0, "tNcpcetpqSeArEESd.nNoaoMT_.vUi.iA_xndnLmR.gcEn.o.HPStGi"

    const-string/jumbo v0, "ngodecoNqrin_AdttMiGT.pmxaAo.Ne_H..ciEn.SRSIn.EPSEtvUcL"

    const-string v0, "SMAi_R.Eq._.INomGNritxAaSPcindc.cEeTtEpnnnLtgdoaeoH.vUS"

    const-string v0, "com.tencent.android.xg.vip.action.INTERNAL_PUSH_MESSAGE"

    invoke-direct {v4, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    iget-object v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    invoke-virtual {v4, v0}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v0, "sssmg"

    const-string v0, "Igsms"

    const-string v0, "dsmmg"

    const-string/jumbo v0, "msgId"

    iget-wide v5, v2, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    invoke-virtual {v4, v0, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    iget-object v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->d:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v5, "tmteo"

    const-string/jumbo v5, "tetml"

    const-string v5, "bleit"

    const-string/jumbo v5, "title"

    invoke-virtual {v4, v5, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->e:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v6, "tononeu"

    const-string v6, "cennoto"

    const-string/jumbo v6, "pentnco"

    const-string v6, "content"

    invoke-virtual {v4, v6, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v0, "atde"

    const-string v0, "dtae"

    const-string v0, "date"

    iget-object v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->j:Ljava/lang/String;

    invoke-virtual {v4, v0, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v0, "yept"

    const-string/jumbo v0, "type"

    iget-wide v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->f:J

    invoke-virtual {v4, v0, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string v0, "Iadqb"

    const-string v0, "bdaIc"

    const-string v0, "Icsac"

    const-string v0, "accId"

    iget-wide v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->b:J

    invoke-virtual {v4, v0, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string v0, "gsbmudisM"

    const-string v0, "gduibsuMs"

    const-string v0, "IubsodiMs"

    const-string v0, "busiMsgId"

    iget-wide v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->c:J

    invoke-virtual {v4, v0, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string/jumbo v0, "spsmabipte"

    const-string v0, "aitmsmspep"

    const-string v0, "aimtspuemt"

    const-string/jumbo v0, "timestamps"

    iget-wide v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->h:J

    invoke-virtual {v4, v0, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string/jumbo v0, "imtgkuPp"

    const-string/jumbo v0, "multiPkg"

    iget-wide v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->i:J

    invoke-virtual {v4, v0, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string v0, "eeqtrrisqev"

    const-string/jumbo v0, "iemrrsevqet"

    const-string v0, "evsremt_sie"

    const-string/jumbo v0, "server_time"

    iget-wide v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->k:J

    invoke-virtual {v4, v0, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string/jumbo v0, "tlt"

    const-string/jumbo v0, "tlt"

    const-string/jumbo v0, "ttl"

    const-string/jumbo v0, "ttl"

    iget v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->l:I

    invoke-virtual {v4, v0, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v0, "sdimru_p"

    const-string/jumbo v0, "upsidg_r"

    const-string/jumbo v0, "orudoig_"

    const-string v0, "group_id"

    iget-object v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->r:Ljava/lang/String;

    invoke-virtual {v4, v0, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string v0, "aetptbyTeg"

    const-string v0, "eeymtgTatp"

    const-string v0, "eegttruaTp"

    const-string/jumbo v0, "targetType"

    iget-wide v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->t:J

    invoke-virtual {v4, v0, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string/jumbo v0, "opcsue"

    const-string/jumbo v0, "uocsoe"

    const-string/jumbo v0, "ucqrso"

    const-string/jumbo v0, "source"

    iget-wide v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->u:J

    invoke-virtual {v4, v0, v7, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string v0, "eesrbkvo"

    const-string v0, "doervbek"

    const-string/jumbo v0, "revokeId"

    iget v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->v:I

    invoke-virtual {v4, v0, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const-string/jumbo v0, "mdamteepIt"

    const-string v0, "detpetumaI"

    const-string/jumbo v0, "templateId"

    iget-object v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->w:Ljava/lang/String;

    invoke-virtual {v4, v0, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v0, "prctead"

    const-string v0, "adrIotc"

    const-string/jumbo v0, "traceId"

    iget-object v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->x:Ljava/lang/String;

    invoke-virtual {v4, v0, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget-object v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->y:Ljava/lang/String;

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const-string v7, "bqnMg"

    const-string/jumbo v7, "nigqM"

    const-string v7, "gusMn"

    const-string/jumbo v7, "inMsg"

    invoke-virtual {v4, v7, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-static {v10}, Lcom/tencent/android/tpush/f/a;->a(Landroid/content/Context;)Z

    move-result v0

    const-string/jumbo v7, "pasnhehsuln"

    const-string/jumbo v7, "pushChannel"

    if-eqz v0, :cond_0

    iget-object v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    invoke-virtual {v10}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v0, v8}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_0

    invoke-static {}, Lcom/tencent/android/tpush/f/a;->a()I

    move-result v0

    invoke-virtual {v4, v7, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    goto :goto_0

    :cond_0
    const/16 v0, 0x64

    invoke-virtual {v4, v7, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    :goto_0
    const-string/jumbo v0, "pgrIodp"

    const-string v0, "groupId"

    iget-object v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->s:Ljava/lang/String;

    invoke-virtual {v4, v0, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const-string/jumbo v0, "kvqmsA"

    const-string/jumbo v0, "rskmvA"

    const-string/jumbo v0, "vrsscA"

    const-string/jumbo v0, "svrAck"

    const/4 v7, 0x1

    invoke-virtual {v4, v0, v7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    const-string/jumbo v0, "skvmPaeogm"

    const-string v0, "askNovegPm"

    const-string/jumbo v0, "svrPkgName"

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->h()Ljava/lang/String;

    move-result-object v8

    invoke-virtual {v4, v0, v8}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    iget v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->v:I

    if-lez v0, :cond_1

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v4}, Lcom/tencent/android/tpush/stat/ServiceStat;->appReportRevokeMessageServiceReceived(Landroid/content/Context;Landroid/content/Intent;)V

    goto :goto_1

    :cond_1
    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0, v4}, Lcom/tencent/android/tpush/stat/ServiceStat;->appReportServiceReceived(Landroid/content/Context;Landroid/content/Intent;)V

    :goto_1
    iget-wide v8, v2, Lcom/tencent/android/tpush/service/protocol/j;->f:J

    const-wide/16 v11, 0x7

    const-wide/16 v11, 0x7

    const-wide/16 v11, 0x7

    const-wide/16 v11, 0x7

    cmp-long v0, v8, v11

    if-nez v0, :cond_2

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/android/tpush/f/a;->a(Landroid/content/Context;)Z

    move-result v0

    if-eqz v0, :cond_2

    const-string v0, "dinSouMccghb su a edrnse , vr siPitsstiueayr"

    const-string v0, "cvidubassinM dye rnhiuS tPss ebitc,u  egsrar"

    const-string v0, "cesudbn iuy bhirets cu sMisPS d n srveatra,i"

    const-string/jumbo v0, "receive inMsg but run as SysPush, discard it"

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_2
    iget v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->l:I

    iget-wide v8, v2, Lcom/tencent/android/tpush/service/protocol/j;->k:J

    iget-wide v11, v2, Lcom/tencent/android/tpush/service/protocol/j;->h:J

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v13

    const-wide/16 v15, 0x3e8

    const-wide/16 v15, 0x3e8

    const-wide/16 v15, 0x3e8

    const-wide/16 v15, 0x3e8

    const-wide/16 v17, 0x0

    const-wide/16 v17, 0x0

    const-wide/16 v17, 0x0

    const-wide/16 v17, 0x0

    if-lez v0, :cond_3

    move-wide/from16 v19, v8

    int-to-long v7, v0

    mul-long/2addr v7, v15

    goto :goto_2

    :cond_3
    move-wide/from16 v19, v8

    iget-wide v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    cmp-long v7, v7, v17

    if-lez v7, :cond_4

    if-nez v0, :cond_4

    const-wide/16 v7, 0x7530

    const-wide/16 v7, 0x7530

    const-wide/16 v7, 0x7530

    const-wide/16 v7, 0x7530

    goto :goto_2

    :cond_4
    const-wide/32 v7, 0xf731400

    const-wide/32 v7, 0xf731400

    const-wide/32 v7, 0xf731400

    const-wide/32 v7, 0xf731400

    :goto_2
    cmp-long v0, v19, v17

    if-lez v0, :cond_5

    cmp-long v0, v11, v17

    if-lez v0, :cond_5

    div-long v21, v19, v15

    sub-long v21, v21, v11

    sub-long v11, v13, v21

    add-long/2addr v11, v7

    goto :goto_3

    :cond_5
    add-long v11, v13, v7

    :goto_3
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v7, "npsgoruee:ii ee remnfexItt m tcueT"

    const-string/jumbo v7, "me mxeuiieo ncete:eTrntftIse  gpur"

    const-string/jumbo v7, "tmxTI epmfosc:erxtig eeru ie ntpee"

    const-string v7, "execute expireTime for msgIntent: "

    invoke-virtual {v0, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v11, v12}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    div-long v8, v19, v15

    sub-long/2addr v13, v8

    const-string/jumbo v0, "qgempaip"

    const-string/jumbo v0, "timegpap"

    const-string v0, "aes_gpit"

    const-string/jumbo v0, "time_gap"

    invoke-virtual {v4, v0, v13, v14}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const-string/jumbo v0, "ptrmie_eemx"

    const-string/jumbo v0, "iexme_rtqpe"

    const-string v0, "etieo_imxpr"

    const-string v0, "expire_time"

    invoke-virtual {v4, v0, v11, v12}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    :try_start_0
    const-string v0, "esSnKbye"

    const-string v0, "KnsyeeeS"

    const-string v0, "enyteSue"

    const-string v0, "enKeySet"

    const/4 v7, 0x2

    new-array v7, v7, [Ljava/lang/String;

    const/4 v8, 0x0

    aput-object v5, v7, v8

    const/4 v5, 0x1

    aput-object v6, v7, v5

    invoke-static {v7}, Lcom/tencent/android/tpush/common/e;->a(Ljava/io/Serializable;)Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v4, v0, v5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_4

    :catchall_0
    move-exception v0

    const-string/jumbo v5, "stietDmprS2bKd"

    const-string/jumbo v5, "tsDmditeruSb2K"

    const-string/jumbo v5, "td2bsDKrqieiut"

    const-string v5, "distribute2SDK"

    invoke-static {v3, v5, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_4
    const-string/jumbo v0, "res_ptus_amxeto"

    const-string/jumbo v0, "tmu_otrsp_axeie"

    const-string v0, "extra_push_time"

    move-wide/from16 v5, p2

    invoke-virtual {v4, v0, v5, v6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    iget-wide v5, v2, Lcom/tencent/android/tpush/service/protocol/j;->i:J

    iget-wide v7, v2, Lcom/tencent/android/tpush/service/protocol/j;->b:J

    invoke-static {v10}, Lcom/tencent/android/tpush/f/a;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v9, 0x0

    if-eqz v0, :cond_7

    iget-object v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    invoke-virtual {v10}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v11

    invoke-virtual {v0, v11}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-nez v0, :cond_7

    cmp-long v0, v5, v17

    const-string v5, "aermnhapkidtmpg__"

    const-string v5, "dn_tpbk_agpamrhei"

    const-string/jumbo v5, "tpdnopr__aaegkpmi"

    const-string/jumbo v5, "third_app_pkgname"

    if-nez v0, :cond_6

    iget-wide v6, v2, Lcom/tencent/android/tpush/service/protocol/j;->b:J

    iget-object v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    invoke-static {v10, v6, v7, v0}, Lcom/tencent/android/tpush/f/a;->a(Landroid/content/Context;JLjava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_a

    iget-object v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    invoke-virtual {v4, v5, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v10}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    goto :goto_5

    :cond_6
    iget-wide v6, v2, Lcom/tencent/android/tpush/service/protocol/j;->b:J

    invoke-static {v10, v6, v7}, Lcom/tencent/android/tpush/f/a;->a(Landroid/content/Context;J)Ljava/lang/String;

    move-result-object v0

    if-eqz v0, :cond_a

    invoke-virtual {v4, v5, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    invoke-virtual {v10}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v9

    goto :goto_5

    :cond_7
    cmp-long v0, v5, v17

    if-nez v0, :cond_9

    iget-object v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    invoke-virtual {v10}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    if-eqz v0, :cond_8

    iget-object v9, v2, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    goto :goto_5

    :cond_8
    const-string v0, " tmmgbeekiainaetuvree igchas  ctnoebes  s gpa"

    const-string/jumbo v0, "receive message but package name is not right"

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    goto :goto_5

    :cond_9
    invoke-static {v7, v8}, Lcom/tencent/android/tpush/service/cache/CacheManager;->findValidPackageByAccessid(J)Ljava/lang/String;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_a

    move-object v9, v0

    move-object v9, v0

    move-object v9, v0

    move-object v9, v0

    :cond_a
    :goto_5
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "ue arDukspmitga2Npt Seub:Pi"

    const-string v5, "bat:mpuDepsa2 er gKPNtiSuki"

    const-string v5, "dmbiSKppk p:Pate2giuesrtDaN"

    const-string v5, "distribute2SDK appPkgName: "

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_1
    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v5, "sd SesrDqt  uipKggibmdstki"

    const-string v5, "DKm gsspuksiSdeipdib  rgtt"

    const-string v5, "iSskistsKd2Ds i udb pgremt"

    const-string v5, "distribute2SDK pkgs msgid "

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v5, v2, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    invoke-virtual {v0, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const-string v5, " q mgp"

    const-string v5, "  q gp"

    const-string/jumbo v5, "kg  o "

    const-string v5, "  pkg "

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v5, v2, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    invoke-static {v9}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    if-eqz v0, :cond_b

    const-string/jumbo v0, "ngsPubpsN pmelm.a!g>a k >s"

    const-string v0, "epsi>l.P guNm>mgn!ssa  apk"

    const-string/jumbo v0, "pa>NleulagP>u m  sgkminp!s"

    const-string v0, ">> msg.appPkgName is null!"

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/16 v5, -0x67

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "tI tbiipddues2s:rKmDm"

    const-string/jumbo v4, "stdmbidtDi:mSIs K2uer"

    const-string v4, "DrmedStIqigKu2bss:tdi"

    const-string v4, "distribute2SDK msgId:"

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v6, v2, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    invoke-virtual {v0, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-string/jumbo v9, "nesrn"

    const-string v9, "ennro"

    const-string v9, "enrmi"

    const-string/jumbo v9, "inner"

    move-object v4, v10

    move-object v4, v10

    move-object v4, v10

    move-object v4, v10

    invoke-static/range {v4 .. v9}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    return-void

    :cond_b
    invoke-static {v10}, Lcom/tencent/android/tpush/f/a;->a(Landroid/content/Context;)Z

    move-result v0

    if-nez v0, :cond_c

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Lcom/tencent/android/tpush/a/a;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/a/a;

    move-result-object v0

    invoke-virtual {v0, v9}, Lcom/tencent/android/tpush/a/a;->a(Ljava/lang/String;)V

    :cond_c
    invoke-static {v9}, Lcom/tencent/android/tpush/service/cache/CacheManager;->getRegisterInfoByPkgName(Ljava/lang/String;)Lcom/tencent/android/tpush/data/RegisterEntity;

    move-result-object v0

    if-nez v0, :cond_d

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v5, " s ooR lgfliunne"

    const-string v5, "RegInfo is null "

    invoke-virtual {v0, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    iget-object v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->j:Ljava/lang/String;

    invoke-virtual {v1, v0, v4, v9}, Lcom/tencent/android/tpush/service/b/a;->a(Ljava/lang/String;Landroid/content/Intent;Ljava/lang/String;)V

    return-void

    :cond_d
    iget v5, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->state:I

    if-lez v5, :cond_e

    invoke-static {}, Lcom/tencent/android/tpush/message/MessageManager;->getInstance()Lcom/tencent/android/tpush/message/MessageManager;

    move-result-object v2

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v4

    invoke-virtual {v2, v4, v9}, Lcom/tencent/android/tpush/message/MessageManager;->deleteAllCachedMsgIntentByPkgName(Landroid/content/Context;Ljava/lang/String;)V

    const/16 v5, -0x68

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v4, "ngIeobr.ettbf:"

    const-string v4, "erg:abftItoen."

    const-string v4, "ateIfouer:nst."

    const-string/jumbo v4, "regInfo.state:"

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget v0, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->state:I

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-string/jumbo v9, "nepui"

    const-string v9, "eunni"

    const-string/jumbo v9, "nneqr"

    const-string/jumbo v9, "inner"

    move-object v4, v10

    move-object v4, v10

    move-object v4, v10

    move-object v4, v10

    invoke-static/range {v4 .. v9}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    return-void

    :cond_e
    invoke-virtual {v4, v9}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v4}, Landroid/content/Intent;->getPackage()Ljava/lang/String;

    move-result-object v5

    invoke-static {v0, v5, v4}, Lcom/tencent/android/tpush/a;->a(Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;)Z

    move-result v0

    if-nez v0, :cond_f

    iget-object v0, v2, Lcom/tencent/android/tpush/service/protocol/j;->j:Ljava/lang/String;

    invoke-virtual {v1, v0, v4, v9}, Lcom/tencent/android/tpush/service/b/a;->a(Ljava/lang/String;Landroid/content/Intent;Ljava/lang/String;)V

    goto :goto_6

    :cond_f
    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    invoke-virtual {v1, v0, v4}, Lcom/tencent/android/tpush/service/b/a;->a(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    goto :goto_6

    :catchall_1
    move-exception v0

    const-string/jumbo v2, "imseagMtasspeiTeOshnp"

    const-string v2, "iTnaseipmspghscMeOtae"

    const-string v2, "ghpmntascsMmsaeOidTee"

    const-string v2, "dispatchMessageOnTime"

    invoke-static {v3, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/16 v5, -0x68

    new-instance v2, Ljava/lang/StringBuilder;

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "n:aroBNPMskg yesgmdqe"

    const-string v3, "aPn rk:yqrBemgesNMgds"

    const-string/jumbo v3, "sendMsgByPkgName err:"

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/base/util/Util;->getThrowableToString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-string v9, "bsnni"

    const-string/jumbo v9, "nisen"

    const-string/jumbo v9, "iunrn"

    const-string/jumbo v9, "inner"

    move-object v4, v10

    move-object v4, v10

    move-object v4, v10

    move-object v4, v10

    invoke-static/range {v4 .. v9}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    :goto_6
    return-void
.end method

.method private declared-synchronized a(Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x2

    monitor-enter p0

    :try_start_0
    const/4 v5, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    monitor-exit p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-void

    :cond_0
    :try_start_1
    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo p1, "tonntt_psmoeum"

    const-string/jumbo p1, "mcomnttote_nus"

    const/4 v5, 0x7

    const-string/jumbo p1, "unteoc_nqcosmt"

    const-string p1, "custom_content"

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->getJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string v0, "fosnic"

    const-string/jumbo v0, "ncofoi"

    const-string v0, "cnimfg"

    const-string v0, "config"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string/jumbo v1, "nebiovs"

    const-string/jumbo v1, "inesvbo"

    const/4 v5, 0x7

    const-string v1, "evsiobn"

    const-string/jumbo v1, "version"

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    const/4 v1, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x5

    if-eqz v0, :cond_3

    const/4 v5, 0x7

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    if-lez v2, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    move v2, v1

    move v2, v1

    const/4 v5, 0x6

    move v2, v1

    move v2, v1

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-ge v1, v3, :cond_2

    const/4 v4, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p0, v3}, Lcom/tencent/android/tpush/service/b/a;->a(Lorg/json/JSONObject;)Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x5

    move v2, v3

    move v2, v3

    const/4 v5, 0x1

    move v2, v3

    move v2, v3

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x6

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x3

    move v1, v2

    move v1, v2

    const/4 v5, 0x4

    move v1, v2

    move v1, v2

    :cond_3
    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eqz v1, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/service/b/a;->b()Lorg/json/JSONArray;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    const-string/jumbo v2, "oKfrCVuegyiuosepGiosrn"

    const-string v2, "GroupKeysConfigVersion"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-static {v1, v2, p1}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putInt(Landroid/content/Context;Ljava/lang/String;I)V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string/jumbo v1, "uooGyrCpenpnieCuflKgas"

    const-string/jumbo v1, "ihfgKluopyaoneuGCsrneC"

    const/4 v5, 0x2

    const-string v1, "KgyolpsfqCGoeaueriCnhn"

    const-string v1, "ChannelGroupKeysConfig"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    invoke-static {p1, v1, v0}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->putString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x6

    goto :goto_1

    :catchall_0
    move-exception p1

    :try_start_2
    const/4 v5, 0x2

    const/4 v4, 0x2

    const-string v0, "SMsevpsrMaggraaes"

    const-string v0, "gaesSgspaeMarrMev"

    const/4 v5, 0x6

    const-string v0, "aasmrggsvenMeSeMa"

    const-string v0, "SrvMessageManager"

    const/4 v5, 0x2

    const-string/jumbo v1, "nieeonaludsoKrhogCGyf"

    const-string v1, "handleGroupKeysConfig"

    const/4 v4, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :cond_4
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    monitor-exit p0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-void

    :catchall_1
    move-exception p1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x2

    monitor-exit p0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    throw p1
.end method

.method private declared-synchronized a(Lorg/json/JSONObject;)Z
    .locals 12

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x5

    monitor-enter p0

    :try_start_0
    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    const-string/jumbo v0, "neqcabdhI"

    const-string/jumbo v0, "nandhIecq"

    const/4 v11, 0x5

    const-string v0, "chIaeduln"

    const-string v0, "channelId"

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x7

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->getLong(Ljava/lang/String;)J

    move-result-wide v0

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x2

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v11, 0x1

    const-wide/16 v3, 0x0

    const-wide/16 v3, 0x0

    const/4 v10, 0x1

    shl-int/2addr v11, v10

    cmp-long v1, v1, v3

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    const/4 v2, 0x0

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-gtz v1, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    monitor-exit p0

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x6

    return v2

    :cond_0
    :try_start_1
    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string/jumbo v1, "snpfo"

    const-string/jumbo v1, "sosnf"

    const/4 v11, 0x7

    const-string/jumbo v1, "sniqf"

    const-string/jumbo v1, "infos"

    const/4 v11, 0x1

    const/4 v10, 0x0

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    const/4 v11, 0x2

    const/4 v10, 0x7

    const/4 v11, 0x2

    if-eqz p1, :cond_8

    const/4 v11, 0x6

    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    if-lez v1, :cond_8

    const/4 v11, 0x0

    const/4 v10, 0x7

    sget-object v1, Lcom/tencent/android/tpush/service/b/a;->h:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {v1, v0}, Ljava/util/concurrent/ConcurrentHashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x7

    if-nez v1, :cond_1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    new-instance v1, Ljava/util/HashMap;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-direct {v1}, Ljava/util/HashMap;-><init>()V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x7

    sget-object v3, Lcom/tencent/android/tpush/service/b/a;->h:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v11, 0x4

    invoke-virtual {v3, v0, v1}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_1
    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x3

    move v1, v2

    move v1, v2

    const/4 v11, 0x2

    move v1, v2

    move v1, v2

    :goto_0
    const/4 v11, 0x7

    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v3

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    if-ge v2, v3, :cond_7

    const/4 v10, 0x5

    shl-int/2addr v11, v10

    sget-object v3, Lcom/tencent/android/tpush/service/b/a;->h:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v11, 0x5

    const/4 v10, 0x2

    invoke-virtual {v3, v0}, Ljava/util/concurrent/ConcurrentHashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x7

    check-cast v3, Ljava/util/Map;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-virtual {p1, v2}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    const/4 v10, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x3

    const-string/jumbo v5, "rKsupogy"

    const-string v5, "groupKey"

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v4, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    const-string/jumbo v6, "op"

    const-string/jumbo v6, "op"

    const/4 v11, 0x5

    const-string/jumbo v6, "op"

    const-string/jumbo v6, "op"

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->getInt(Ljava/lang/String;)I

    move-result v6

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x0

    const-string/jumbo v7, "pasp"

    const-string/jumbo v7, "sapp"

    const/4 v11, 0x5

    const-string v7, "apps"

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-virtual {v4, v7}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v4

    const/4 v11, 0x3

    const/4 v10, 0x7

    if-eqz v4, :cond_6

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {v4}, Lorg/json/JSONArray;->length()I

    move-result v7

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x7

    if-lez v7, :cond_6

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x1

    invoke-interface {v3, v5}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v7

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x2

    if-nez v7, :cond_2

    const/4 v11, 0x4

    const/4 v10, 0x2

    new-instance v7, Ljava/util/ArrayList;

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-direct {v7}, Ljava/util/ArrayList;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x1

    invoke-interface {v3, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_2
    const/4 v11, 0x5

    invoke-interface {v3, v5}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v7

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x3

    check-cast v7, Ljava/util/List;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-static {v4}, Lcom/tencent/android/tpush/service/b/a;->a(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v4

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x7

    const/4 v8, 0x1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x0

    if-ne v6, v8, :cond_3

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    move-object v7, v4

    :goto_1
    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x5

    move v1, v8

    move v1, v8

    const/4 v11, 0x7

    move v1, v8

    move v1, v8

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x2

    goto :goto_2

    :cond_3
    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x1

    const/4 v9, 0x2

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x6

    if-ne v6, v9, :cond_4

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-interface {v4, v7}, Ljava/util/List;->removeAll(Ljava/util/Collection;)Z

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-interface {v7, v4}, Ljava/util/List;->addAll(Ljava/util/Collection;)Z

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x5

    goto :goto_1

    :cond_4
    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x2

    const/4 v9, 0x3

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x5

    if-ne v6, v9, :cond_5

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-interface {v7, v4}, Ljava/util/List;->removeAll(Ljava/util/Collection;)Z

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x0

    goto :goto_1

    :cond_5
    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x2

    const-string/jumbo v4, "rMnmagsSeaMmvseea"

    const-string v4, "MsgmrasaneevMrSea"

    const/4 v11, 0x4

    const-string v4, "aserorgvSaMeMseng"

    const-string v4, "SrvMessageManager"

    const/4 v11, 0x2

    const/4 v10, 0x1

    const/4 v11, 0x1

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const-string/jumbo v9, "prorrbpo t ee "

    const-string/jumbo v9, "p tro eeo pror"

    const/4 v11, 0x1

    const-string v9, "ero r u trpoep"

    const-string v9, "error op type "

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x3

    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x7

    const/4 v11, 0x5

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {v4, v6}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_2
    const/4 v11, 0x1

    invoke-interface {v3, v5, v7}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_6
    const/4 v11, 0x2

    const/4 v10, 0x2

    sget-object v4, Lcom/tencent/android/tpush/service/b/a;->h:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x0

    invoke-virtual {v4, v0, v3}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x5

    goto/16 :goto_0

    :cond_7
    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x1

    move v2, v1

    move v2, v1

    const/4 v11, 0x3

    move v2, v1

    move v2, v1

    :cond_8
    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x7

    monitor-exit p0

    const/4 v11, 0x2

    const/4 v10, 0x6

    return v2

    :catchall_0
    move-exception p1

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x6

    monitor-exit p0

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x3

    throw p1
.end method

.method private static b()Lorg/json/JSONArray;
    .locals 12

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    new-instance v0, Lorg/json/JSONArray;

    const/4 v11, 0x7

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    sget-object v1, Lcom/tencent/android/tpush/service/b/a;->h:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {v1}, Ljava/util/concurrent/ConcurrentHashMap;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v11, 0x4

    const/4 v10, 0x0

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v11, 0x6

    const/4 v10, 0x6

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v11, 0x0

    const/4 v10, 0x2

    const/4 v11, 0x7

    if-eqz v2, :cond_1

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x0

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x7

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v11, 0x4

    const/4 v10, 0x7

    const/4 v11, 0x5

    new-instance v3, Lorg/json/JSONObject;

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-direct {v3}, Lorg/json/JSONObject;-><init>()V

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x0

    sget-object v4, Ljava/lang/System;->out:Ljava/io/PrintStream;

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v11, 0x6

    const/4 v10, 0x0

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x0

    const-string v6, "epKby "

    const-string v6, "=eK yb"

    const/4 v11, 0x1

    const-string v6, " eqy ="

    const-string v6, "Key = "

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x3

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x2

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x7

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x5

    invoke-virtual {v4, v5}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-interface {v2}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x7

    check-cast v4, Ljava/util/Map;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x0

    new-instance v5, Lorg/json/JSONArray;

    const/4 v11, 0x1

    const/4 v10, 0x3

    const/4 v11, 0x4

    invoke-direct {v5}, Lorg/json/JSONArray;-><init>()V

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x5

    invoke-interface {v4}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v4

    const/4 v11, 0x6

    const/4 v10, 0x1

    invoke-interface {v4}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v4

    :goto_1
    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x2

    invoke-interface {v4}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-eqz v6, :cond_0

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-interface {v4}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    check-cast v6, Ljava/util/Map$Entry;

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x2

    new-instance v7, Lorg/json/JSONObject;

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-direct {v7}, Lorg/json/JSONObject;-><init>()V

    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x2

    new-instance v8, Lorg/json/JSONArray;

    const/4 v11, 0x0

    const/4 v10, 0x7

    const/4 v11, 0x3

    invoke-interface {v6}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v9

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x0

    check-cast v9, Ljava/util/Collection;

    const/4 v11, 0x5

    invoke-direct {v8, v9}, Lorg/json/JSONArray;-><init>(Ljava/util/Collection;)V

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-interface {v6}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x0

    check-cast v6, Ljava/lang/String;

    const/4 v11, 0x5

    const/4 v10, 0x5

    const/4 v11, 0x3

    invoke-virtual {v7, v6, v8}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v11, 0x1

    const/4 v10, 0x0

    const/4 v11, 0x6

    invoke-virtual {v5, v7}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    goto :goto_1

    :cond_0
    const/4 v10, 0x1

    move v11, v10

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    check-cast v2, Ljava/lang/Long;

    const/4 v11, 0x0

    const/4 v10, 0x1

    const/4 v11, 0x5

    invoke-virtual {v2}, Ljava/lang/Long;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x0

    invoke-virtual {v3, v2, v5}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v11, 0x7

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x7

    goto/16 :goto_0

    :cond_1
    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x4

    return-object v0
.end method

.method private b(Landroid/content/Context;Ljava/lang/String;)V
    .locals 12

    const/4 v10, 0x7

    const/4 v11, 0x5

    const-string v0, "eMsanSsvaMaeersru"

    const-string/jumbo v0, "sMegneuavrMearaSs"

    const/4 v11, 0x5

    const-string/jumbo v0, "ssamrMnegarMSvege"

    const-string v0, "SrvMessageManager"

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x6

    if-eqz p1, :cond_5

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-static {p2}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x5

    if-eqz p1, :cond_0

    const/4 v11, 0x5

    const/4 v10, 0x7

    goto/16 :goto_0

    :cond_0
    :try_start_0
    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x0

    new-instance p1, Lorg/json/JSONObject;

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x4

    invoke-direct {p1, p2}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string/jumbo p2, "seltooP"

    const-string/jumbo p2, "plPtsoe"

    const/4 v11, 0x5

    const-string p2, "Pseklbt"

    const-string/jumbo p2, "losePkt"

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v1, 0x0

    shr-int/2addr v11, v1

    const/4 v10, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {p1, p2, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result p2

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-string/jumbo v1, "rqlseouta"

    const-string/jumbo v1, "talstreoq"

    const/4 v11, 0x5

    const-string/jumbo v1, "srlottepa"

    const-string/jumbo v1, "loseStart"

    const/4 v11, 0x5

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v11, 0x2

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x0

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x3

    mul-long/2addr v4, v6

    const/4 v11, 0x0

    const/4 v10, 0x5

    const/4 v11, 0x7

    const-string/jumbo v1, "lqsnose"

    const-string/jumbo v1, "odsnels"

    const/4 v11, 0x4

    const-string/jumbo v1, "oEssdne"

    const-string/jumbo v1, "loseEnd"

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x4

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v8

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    mul-long/2addr v8, v6

    const/4 v11, 0x1

    const/4 v10, 0x6

    const/4 v11, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v6

    const/4 v11, 0x7

    const/4 v10, 0x6

    const/4 v11, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v11, 0x6

    const-string v1, "hmImocuo eekfRkc:lPft su lsd|eC"

    const-string/jumbo v1, "slemfRhde | Cfukslu:tIPccek eoo"

    const/4 v11, 0x2

    const-string/jumbo v1, "slc:oflIee ufoe|u ktocesRd Ph k"

    const-string v1, "checkIfCloudRefuse | losePkt : "

    const/4 v11, 0x0

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-string v1, " e:t;bltaooS  "

    const-string v1, " t;ao:S ot els"

    const/4 v11, 0x3

    const-string v1, "; loseStart : "

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x2

    invoke-virtual {p1, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x5

    const-string/jumbo v1, "ld :sbuo ; E"

    const-string v1, "E so;bl ed: "

    const/4 v11, 0x4

    const-string v1, " ;oEne p:dl "

    const-string v1, "; loseEnd : "

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x7

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-virtual {p1, v8, v9}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x7

    const-string/jumbo v1, "nrtu; rcqu:e"

    const-string v1, "cr u ;uten:r"

    const/4 v11, 0x2

    const-string v1, "cusnt  err :"

    const-string v1, "; current : "

    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    const/4 v10, 0x7

    invoke-virtual {p1, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x4

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v11, 0x5

    const/4 v10, 0x6

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x1

    const/4 p1, 0x1

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-ne p2, p1, :cond_5

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    cmp-long p1, v6, v8

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x7

    if-gtz p1, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x3

    cmp-long p2, v6, v4

    const/4 v10, 0x0

    const/4 v10, 0x0

    const/4 v11, 0x1

    if-gez p2, :cond_4

    :cond_1
    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x3

    cmp-long p2, v4, v2

    const/4 v11, 0x7

    const/4 v10, 0x3

    const/4 v11, 0x1

    if-nez p2, :cond_2

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    cmp-long v1, v8, v2

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    if-eqz v1, :cond_4

    :cond_2
    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    if-gtz p1, :cond_3

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x3

    if-eqz p2, :cond_4

    :cond_3
    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x5

    cmp-long p1, v6, v4

    const/4 v11, 0x6

    if-ltz p1, :cond_5

    const/4 v11, 0x1

    cmp-long p1, v8, v2

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x1

    if-nez p1, :cond_5

    :cond_4
    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object p1

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x6

    iget-object p1, p1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v11, 0x6

    const/4 v10, 0x2

    const/4 v11, 0x5

    const/4 p2, 0x0

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x4

    invoke-virtual {p1, p2}, Lcom/tencent/android/tpush/c/a$a;->c(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    const/4 v11, 0x3

    const-string p1, "hRomtCd|ceueCnusfck cpensfI ooelt"

    const-string p1, "checkIfCloudRefuse | stopConnect "

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x3

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v11, 0x7

    const/4 v10, 0x5

    const/4 v11, 0x0

    const-string/jumbo p2, "ofekRusphfeIucelcC"

    const/4 v11, 0x4

    const-string p2, "eCoRofhulkseIdfuec"

    const-string p2, "checkIfCloudRefuse"

    const/4 v11, 0x1

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {v0, p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_5
    :goto_0
    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x3

    return-void
.end method

.method private static declared-synchronized c()V
    .locals 15

    const/4 v14, 0x7

    const-class v0, Lcom/tencent/android/tpush/service/b/a;

    const-class v0, Lcom/tencent/android/tpush/service/b/a;

    const-class v0, Lcom/tencent/android/tpush/service/b/a;

    const-class v0, Lcom/tencent/android/tpush/service/b/a;

    const/4 v14, 0x6

    monitor-enter v0

    :try_start_0
    const/4 v14, 0x0

    sget-object v1, Lcom/tencent/android/tpush/service/b/a;->h:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v14, 0x6

    if-nez v1, :cond_4

    const/4 v14, 0x2

    new-instance v1, Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v14, 0x7

    invoke-direct {v1}, Ljava/util/concurrent/ConcurrentHashMap;-><init>()V

    const/4 v14, 0x3

    sput-object v1, Lcom/tencent/android/tpush/service/b/a;->h:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v14, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v1

    const/4 v14, 0x5

    const-string v2, "eqperbnyuihnoCGofglsaK"

    const-string/jumbo v2, "pCGCoKyuqohslanngireef"

    const-string v2, "efnrCeuoishuannyKpGlgo"

    const-string v2, "ChannelGroupKeysConfig"

    const/4 v14, 0x6

    const/4 v3, 0x0

    invoke-static {v1, v2, v3}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v14, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v14, 0x5

    if-nez v2, :cond_4

    const/4 v14, 0x6

    new-instance v2, Lorg/json/JSONArray;

    invoke-direct {v2, v1}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    const/4 v14, 0x4

    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v1

    const/4 v14, 0x2

    if-lez v1, :cond_4

    const/4 v1, 0x0

    move v14, v1

    move v14, v1

    move v3, v1

    move v3, v1

    move v3, v1

    move v3, v1

    :goto_0
    const/4 v14, 0x1

    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v4

    const/4 v14, 0x1

    if-ge v3, v4, :cond_4

    const/4 v14, 0x0

    invoke-virtual {v2, v3}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v4

    const/4 v14, 0x2

    invoke-virtual {v4}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v5

    :cond_0
    :goto_1
    const/4 v14, 0x3

    invoke-interface {v5}, Ljava/util/Iterator;->hasNext()Z

    move-result v6

    const/4 v14, 0x4

    if-eqz v6, :cond_3

    const/4 v14, 0x4

    invoke-interface {v5}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v6

    const/4 v14, 0x5

    check-cast v6, Ljava/lang/String;

    const/4 v14, 0x5

    invoke-static {v6}, Ljava/lang/Long;->valueOf(Ljava/lang/String;)Ljava/lang/Long;

    move-result-object v7

    const/4 v14, 0x4

    invoke-virtual {v4, v6}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v6

    const/4 v14, 0x1

    if-eqz v6, :cond_0

    const/4 v14, 0x1

    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v8

    const/4 v14, 0x1

    if-lez v8, :cond_0

    const/4 v14, 0x7

    new-instance v8, Ljava/util/HashMap;

    const/4 v14, 0x7

    invoke-direct {v8}, Ljava/util/HashMap;-><init>()V

    const/4 v14, 0x4

    move v9, v1

    move v9, v1

    move v9, v1

    move v9, v1

    :goto_2
    const/4 v14, 0x1

    invoke-virtual {v6}, Lorg/json/JSONArray;->length()I

    move-result v10

    const/4 v14, 0x2

    if-ge v9, v10, :cond_2

    const/4 v14, 0x5

    invoke-virtual {v6, v9}, Lorg/json/JSONArray;->getJSONObject(I)Lorg/json/JSONObject;

    move-result-object v10

    const/4 v14, 0x1

    invoke-virtual {v10}, Lorg/json/JSONObject;->keys()Ljava/util/Iterator;

    move-result-object v11

    :goto_3
    const/4 v14, 0x4

    invoke-interface {v11}, Ljava/util/Iterator;->hasNext()Z

    move-result v12

    const/4 v14, 0x0

    if-eqz v12, :cond_1

    const/4 v14, 0x0

    invoke-interface {v11}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v12

    const/4 v14, 0x1

    check-cast v12, Ljava/lang/String;

    const/4 v14, 0x2

    invoke-virtual {v10, v12}, Lorg/json/JSONObject;->getJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object v13

    const/4 v14, 0x5

    invoke-static {v13}, Lcom/tencent/android/tpush/service/b/a;->a(Lorg/json/JSONArray;)Ljava/util/List;

    move-result-object v13

    const/4 v14, 0x6

    invoke-interface {v8, v12, v13}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v14, 0x6

    goto :goto_3

    :cond_1
    const/4 v14, 0x6

    add-int/lit8 v9, v9, 0x1

    const/4 v14, 0x7

    goto :goto_2

    :cond_2
    const/4 v14, 0x1

    sget-object v6, Lcom/tencent/android/tpush/service/b/a;->h:Ljava/util/concurrent/ConcurrentHashMap;

    const/4 v14, 0x4

    invoke-virtual {v6, v7, v8}, Ljava/util/concurrent/ConcurrentHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v14, 0x6

    goto :goto_1

    :cond_3
    const/4 v14, 0x4

    add-int/lit8 v3, v3, 0x1

    goto/16 :goto_0

    :catchall_0
    move-exception v1

    :try_start_1
    const/4 v14, 0x0

    const-string v2, "MaaaggepSMssrsvne"

    const-string/jumbo v2, "sesaneeMMSarggasv"

    const-string/jumbo v2, "sgaaSgvnqrMMraees"

    const-string v2, "SrvMessageManager"

    const/4 v14, 0x3

    const-string/jumbo v3, "rnsaneGiuKlleCitpom"

    const-string/jumbo v3, "nulmoeeinhKClriaGpt"

    const-string/jumbo v3, "teomhCiylnlGiaenKpu"

    const-string/jumbo v3, "initChanellGroupKey"

    const/4 v14, 0x6

    invoke-static {v2, v3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :cond_4
    const/4 v14, 0x3

    monitor-exit v0

    const/4 v14, 0x5

    return-void

    :catchall_1
    move-exception v1

    const/4 v14, 0x0

    monitor-exit v0

    const/4 v14, 0x6

    throw v1
.end method


# virtual methods
.method public declared-synchronized a(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 12

    const/4 v10, 0x3

    const/4 v11, 0x6

    monitor-enter p0

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x4

    if-eqz p1, :cond_3

    const/4 v11, 0x6

    const/4 v10, 0x6

    const/4 v11, 0x3

    if-eqz p2, :cond_3

    :try_start_0
    const/4 v11, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x5

    new-instance v2, Lcom/tencent/android/tpush/data/MessageId;

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x7

    invoke-direct {v2}, Lcom/tencent/android/tpush/data/MessageId;-><init>()V

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x4

    const-string/jumbo v3, "mdogo"

    const-string v3, "Igmdo"

    const/4 v11, 0x4

    const-string v3, "bdIsg"

    const-string/jumbo v3, "msgId"

    const/4 v11, 0x3

    const/4 v10, 0x4

    const/4 v11, 0x1

    const-wide/16 v4, -0x1

    const/4 v11, 0x4

    const-wide/16 v4, -0x1

    const-wide/16 v4, -0x1

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {p2, v3, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x1

    iput-wide v6, v2, Lcom/tencent/android/tpush/data/MessageId;->id:J

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x4

    const-wide/16 v8, 0x0

    const-wide/16 v8, 0x0

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    cmp-long v3, v6, v8

    const/4 v10, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x5

    if-gez v3, :cond_0

    const/4 v11, 0x2

    const/4 v10, 0x0

    const/4 v11, 0x3

    const-string p1, "gSergsuanraeavMse"

    const-string/jumbo p1, "sagvebseMarrangeS"

    const/4 v11, 0x5

    const-string p1, "geSgneaprMsrvaaeM"

    const-string p1, "SrvMessageManager"

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x6

    const-string p2, "esd KtDdqLg@nc@gmlAkoaacs Sd:Nu SM"

    const-string/jumbo p2, "sk aomu @tleSdKcdcgasSMD:dA@ g NLn"

    const/4 v11, 0x3

    const-string p2, "aNs@mDg g tsn @sM:cLloodeSA kKcddS"

    const-string p2, "@@ msgSendSDKAck: Not add LocalMsg"

    const/4 v11, 0x7

    const/4 v10, 0x1

    const/4 v11, 0x2

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v11, 0x2

    const/4 v10, 0x3

    const/4 v11, 0x4

    monitor-exit p0

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x1

    return-void

    :cond_0
    :try_start_1
    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    const-string v3, "cdcmI"

    const-string v3, "accId"

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    invoke-virtual {p2, v3, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x3

    iput-wide v6, v2, Lcom/tencent/android/tpush/data/MessageId;->accessId:J

    const/4 v11, 0x5

    const/4 v10, 0x0

    const/4 v11, 0x2

    const-string v3, "extaor_hot"

    const-string/jumbo v3, "rxt_etapho"

    const/4 v11, 0x5

    const-string v3, "erh_xbtota"

    const-string v3, "extra_host"

    const/4 v11, 0x2

    const/4 v10, 0x5

    const/4 v11, 0x7

    invoke-virtual {p2, v3, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x5

    iput-wide v6, v2, Lcom/tencent/android/tpush/data/MessageId;->host:J

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x6

    const-string/jumbo v3, "ttaqrpuoe_"

    const-string v3, "eao_rpttqr"

    const/4 v11, 0x4

    const-string/jumbo v3, "rtp_txepao"

    const-string v3, "extra_port"

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x2

    const/4 v6, -0x1

    const/4 v11, 0x2

    const/4 v10, 0x2

    invoke-virtual {p2, v3, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v3

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x5

    iput v3, v2, Lcom/tencent/android/tpush/data/MessageId;->port:I

    const/4 v11, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string v3, "_ecapattqx"

    const-string v3, "extra_pact"

    const/4 v11, 0x4

    const/4 v10, 0x2

    const/4 v11, 0x6

    invoke-virtual {p2, v3, v6}, Landroid/content/Intent;->getByteExtra(Ljava/lang/String;B)B

    move-result v3

    const/4 v11, 0x5

    const/4 v10, 0x1

    const/4 v11, 0x5

    iput-byte v3, v2, Lcom/tencent/android/tpush/data/MessageId;->pact:B

    const/4 v11, 0x5

    const/4 v10, 0x3

    const/4 v11, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    invoke-static {v3}, Lcom/tencent/tpns/dataacquisition/DeviceInfos;->getNetworkType(Landroid/content/Context;)B

    move-result v3

    const/4 v11, 0x5

    const/4 v10, 0x7

    const/4 v11, 0x5

    iput-byte v3, v2, Lcom/tencent/android/tpush/data/MessageId;->apn:B

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v3

    const/4 v11, 0x5

    const/4 v10, 0x2

    const/4 v11, 0x4

    invoke-static {v3}, Lcom/tencent/android/tpush/common/j;->p(Landroid/content/Context;)B

    move-result v3

    const/4 v11, 0x1

    const/4 v10, 0x2

    const/4 v11, 0x2

    iput-byte v3, v2, Lcom/tencent/android/tpush/data/MessageId;->isp:B

    const/4 v11, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v3

    const/4 v11, 0x2

    const/4 v10, 0x4

    const/4 v11, 0x3

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x7

    iput-object v3, v2, Lcom/tencent/android/tpush/data/MessageId;->serviceHost:Ljava/lang/String;

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x1

    iput-wide v0, v2, Lcom/tencent/android/tpush/data/MessageId;->receivedTime:J

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x4

    invoke-virtual {p2}, Landroid/content/Intent;->getPackage()Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x6

    const/4 v11, 0x3

    iput-object v0, v2, Lcom/tencent/android/tpush/data/MessageId;->pkgName:Ljava/lang/String;

    const/4 v11, 0x7

    const/4 v10, 0x7

    const/4 v11, 0x7

    const-string/jumbo v0, "sIsbdMgsu"

    const/4 v11, 0x3

    const-string v0, "MbsgIsdsi"

    const-string v0, "busiMsgId"

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {p2, v0, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v11, 0x1

    const/4 v10, 0x5

    const/4 v11, 0x1

    iput-wide v0, v2, Lcom/tencent/android/tpush/data/MessageId;->busiMsgId:J

    const/4 v10, 0x6

    const/4 v10, 0x1

    const/4 v11, 0x7

    const-string v0, "eatmpsstmm"

    const-string/jumbo v0, "smemtspmat"

    const/4 v11, 0x0

    const-string/jumbo v0, "timestamps"

    const/4 v11, 0x1

    const/4 v10, 0x7

    const/4 v11, 0x6

    invoke-virtual {p2, v0, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v11, 0x2

    const/4 v10, 0x6

    const/4 v11, 0x1

    iput-wide v0, v2, Lcom/tencent/android/tpush/data/MessageId;->timestamp:J

    const/4 v10, 0x6

    const/4 v10, 0x5

    const-string/jumbo v0, "pyte"

    const-string/jumbo v0, "pyet"

    const/4 v11, 0x3

    const-string/jumbo v0, "yetp"

    const-string/jumbo v0, "type"

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {p2, v0, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v11, 0x3

    const/4 v10, 0x0

    const/4 v11, 0x3

    iput-wide v0, v2, Lcom/tencent/android/tpush/data/MessageId;->msgType:J

    const/4 v11, 0x5

    const/4 v10, 0x6

    const/4 v11, 0x7

    const-string/jumbo v0, "ugPoolmk"

    const-string/jumbo v0, "umPkogtl"

    const-string v0, "gtPlibuk"

    const-string/jumbo v0, "multiPkg"

    const/4 v11, 0x0

    invoke-virtual {p2, v0, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x7

    iput-wide v0, v2, Lcom/tencent/android/tpush/data/MessageId;->multiPkg:J

    const/4 v11, 0x3

    const/4 v10, 0x5

    const/4 v11, 0x0

    const-string v0, "edat"

    const-string v0, "etda"

    const/4 v11, 0x7

    const-string v0, "deta"

    const-string v0, "date"

    const/4 v11, 0x3

    const/4 v10, 0x6

    const/4 v11, 0x6

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x3

    const/4 v10, 0x3

    const/4 v11, 0x0

    iput-object v0, v2, Lcom/tencent/android/tpush/data/MessageId;->date:Ljava/lang/String;

    const/4 v11, 0x3

    const/4 v10, 0x2

    const/4 v11, 0x2

    const-string v0, "_caldnuhen"

    const-string v0, "channel_id"

    const/4 v11, 0x6

    const/4 v10, 0x5

    const/4 v11, 0x1

    invoke-virtual {p2, v0, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v11, 0x2

    const/4 v10, 0x2

    const/4 v11, 0x0

    iput-wide v0, v2, Lcom/tencent/android/tpush/data/MessageId;->channelId:J

    const/4 v11, 0x5

    const-string v0, "i_pougdp"

    const-string/jumbo v0, "uo_dibpg"

    const/4 v11, 0x6

    const-string/jumbo v0, "qp_giord"

    const-string v0, "group_id"

    const/4 v11, 0x7

    const/4 v10, 0x4

    const/4 v11, 0x6

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v11, 0x0

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v11, 0x4

    const/4 v10, 0x4

    const/4 v11, 0x5

    if-nez v1, :cond_1

    const/4 v11, 0x1

    const/4 v10, 0x4

    const/4 v11, 0x5

    iput-object v0, v2, Lcom/tencent/android/tpush/data/MessageId;->groupId:Ljava/lang/String;

    :cond_1
    const/4 v10, 0x3

    const/4 v11, 0x0

    const-string/jumbo v0, "tgsta_ta"

    const-string/jumbo v0, "tg_taaut"

    const/4 v11, 0x1

    const-string v0, "gtsm_tta"

    const-string/jumbo v0, "stat_tag"

    const/4 v11, 0x6

    const/4 v10, 0x3

    const/4 v11, 0x0

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x0

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v11, 0x4

    const/4 v10, 0x1

    const/4 v11, 0x6

    if-nez v0, :cond_2

    const/4 v11, 0x5

    const/4 v10, 0x3

    iput-object p2, v2, Lcom/tencent/android/tpush/data/MessageId;->statTag:Ljava/lang/String;

    :cond_2
    const/4 v11, 0x7

    const/4 v10, 0x0

    const/4 v11, 0x1

    const-string/jumbo p2, "lla"

    const-string/jumbo p2, "lla"

    const/4 v11, 0x0

    const-string/jumbo p2, "lal"

    const-string p2, "all"

    const/4 v11, 0x6

    const/4 v10, 0x0

    const/4 v11, 0x7

    invoke-virtual {p0, p1, p2, v2}, Lcom/tencent/android/tpush/service/b/a;->a(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/data/MessageId;)V

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x3

    invoke-direct {p0, p1, v2}, Lcom/tencent/android/tpush/service/b/a;->a(Landroid/content/Context;Lcom/tencent/android/tpush/data/MessageId;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v11, 0x4

    const/4 v10, 0x5

    const/4 v11, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    :try_start_2
    const/4 v11, 0x6

    const/4 v10, 0x4

    const/4 v11, 0x4

    const-string p2, "SrvMessageManager"

    const/4 v11, 0x4

    const/4 v10, 0x6

    const/4 v11, 0x4

    const-string v0, "SApcodKDmkneg"

    const-string v0, "KgAcskDpSdnem"

    const/4 v11, 0x6

    const-string v0, "SmKASbcknseDd"

    const-string/jumbo v0, "msgSendSDKAck"

    const/4 v11, 0x0

    invoke-static {p2, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v11, 0x3

    const/4 v10, 0x1

    const/4 v11, 0x3

    goto :goto_0

    :catchall_1
    move-exception p1

    const/4 v11, 0x4

    const/4 v10, 0x0

    const/4 v11, 0x2

    monitor-exit p0

    const/4 v11, 0x6

    const/4 v10, 0x7

    const/4 v11, 0x5

    throw p1

    :cond_3
    :goto_0
    const/4 v11, 0x4

    const/4 v10, 0x3

    const/4 v11, 0x0

    monitor-exit p0

    const/4 v11, 0x5

    const/4 v10, 0x4

    const/4 v11, 0x1

    return-void
.end method

.method public a(Landroid/content/Context;Ljava/lang/String;Lcom/tencent/android/tpush/data/MessageId;)V
    .locals 11

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x2

    sget-object v0, Lcom/tencent/android/tpush/service/b/a;->b:[B

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x2

    monitor-enter v0

    const/4 v10, 0x6

    if-eqz p1, :cond_2

    :try_start_0
    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x5

    if-nez v1, :cond_2

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x2

    if-eqz p3, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/b/a;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/util/ArrayList;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    new-instance v2, Ljava/util/ArrayList;

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x0

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x0

    const/4 v3, 0x0

    :goto_0
    const/4 v9, 0x7

    move v10, v9

    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-ge v3, v4, :cond_1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v1, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v4

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x3

    check-cast v4, Lcom/tencent/android/tpush/data/MessageId;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-wide v5, v4, Lcom/tencent/android/tpush/data/MessageId;->id:J

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-wide v7, p3, Lcom/tencent/android/tpush/data/MessageId;->id:J

    const/4 v9, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x3

    cmp-long v5, v5, v7

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-nez v5, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    add-int/lit8 v3, v3, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    goto :goto_0

    :cond_1
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->removeAll(Ljava/util/Collection;)Z

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-virtual {v1, p3}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v9, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x1

    invoke-virtual {p0, p1, p2, v1}, Lcom/tencent/android/tpush/service/b/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_2
    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    monitor-exit v0

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x7

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x6

    const/4 v9, 0x0

    throw p1
.end method

.method public a(Landroid/content/Context;Ljava/lang/String;Ljava/util/ArrayList;)V
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/android/tpush/data/MessageId;",
            ">;)V"
        }
    .end annotation

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/service/b/a;->b:[B

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    monitor-enter v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x6

    if-eqz p3, :cond_0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v1, ".ns.snutq.kgi.dpmed.s"

    const-string v1, ".dsnt.ssqd.neikm.s.gp"

    const-string/jumbo v1, "nen.s.pp.tid.dsk.sgms"

    const-string v1, ".tpns.msg.id.send.sdk"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-direct {p0, p1, p2, v1, p3}, Lcom/tencent/android/tpush/service/b/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;Ljava/util/ArrayList;)V

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x0

    throw p1
.end method

.method public a(Landroid/content/Intent;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    new-instance v1, Lcom/tencent/android/tpush/service/b/a$1;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v1, p0, p1}, Lcom/tencent/android/tpush/service/b/a$1;-><init>(Lcom/tencent/android/tpush/service/b/a;Landroid/content/Intent;)V

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v3, 0x1

    return-void
.end method

.method public a(Ljava/lang/String;Landroid/content/Intent;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    new-instance p3, Ljava/text/SimpleDateFormat;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    const-string/jumbo v0, "qydMMsyy"

    const-string v0, "MysyyydM"

    const/4 v3, 0x5

    const-string/jumbo v0, "yyyyMMdd"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {p3, v0}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_2

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p3, p1}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v1, Ljava/util/Date;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v1}, Ljava/util/Date;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p3, v1}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {p3, v1}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/util/Date;->compareTo(Ljava/util/Date;)I

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    if-nez v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    if-nez v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {p3, p1}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    new-instance v0, Ljava/util/Date;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/util/Date;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-virtual {p3, v0}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {p3, v0}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object p3

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1, p3}, Ljava/util/Date;->compareTo(Ljava/util/Date;)I

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    if-gez p1, :cond_1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-virtual {p0, p2}, Lcom/tencent/android/tpush/service/b/a;->a(Landroid/content/Intent;)V

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x6

    return-void

    :cond_2
    :goto_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p2}, Lcom/tencent/android/tpush/service/util/g;->a(Landroid/content/Intent;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz p1, :cond_3

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    const-string/jumbo p3, "nes tanrs>tcee i gn>em psd:"

    const-string p3, ">> send rpc message intent:"

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    const-string p3, "aevmgesmgseMrMarS"

    const-string p3, "aeamrssaSeggeMrvM"

    const/4 v3, 0x1

    const-string p3, "ansMoraeaggSveMrs"

    const-string p3, "SrvMessageManager"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {p0, p2}, Lcom/tencent/android/tpush/service/b/a;->a(Landroid/content/Intent;)V

    :cond_3
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public a(Ljava/util/ArrayList;JLcom/tencent/android/tpush/service/channel/a;)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/android/tpush/service/protocol/j;",
            ">;J",
            "Lcom/tencent/android/tpush/service/channel/a;",
            ")V"
        }
    .end annotation

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p0, p1, p2, p3, p4}, Lcom/tencent/android/tpush/service/b/a;->b(Ljava/util/ArrayList;JLcom/tencent/android/tpush/service/channel/a;)V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public b(Ljava/util/ArrayList;JLcom/tencent/android/tpush/service/channel/a;)V
    .locals 11
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/ArrayList<",
            "Lcom/tencent/android/tpush/service/protocol/j;",
            ">;J",
            "Lcom/tencent/android/tpush/service/channel/a;",
            ")V"
        }
    .end annotation

    const/4 v10, 0x7

    if-eqz p1, :cond_9

    const/4 v10, 0x5

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v10, 0x3

    if-lez v0, :cond_9

    const/4 v10, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v10, 0x7

    const/4 v1, 0x0

    const/4 v10, 0x3

    if-nez v0, :cond_0

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v2

    const/4 v10, 0x5

    const/16 v3, -0x67

    const/4 v10, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x6

    const-string p3, ":lmi,b igo oetltxcdsnus"

    const-string/jumbo p3, "s:mdo ,cutlg nxestil io"

    const-string/jumbo p3, "nm xilulns, euc:ttdo ig"

    const-string p3, "context is null, msgid:"

    const/4 v10, 0x6

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p1

    const/4 v10, 0x0

    check-cast p1, Lcom/tencent/android/tpush/service/protocol/j;

    const/4 v10, 0x1

    iget-wide p3, p1, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    const/4 v10, 0x1

    invoke-virtual {p2, p3, p4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x1

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const-string v7, "erpbn"

    const-string v7, "bnrie"

    const-string/jumbo v7, "inner"

    const/4 v10, 0x6

    invoke-static/range {v2 .. v7}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    const/4 v10, 0x3

    return-void

    :cond_0
    :goto_0
    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v10, 0x4

    const-string v2, "asaMMgurqvseegarS"

    const-string v2, "MeaMenusrgrasgavS"

    const-string v2, "gaseeMsSrsraneagM"

    const-string v2, "SrvMessageManager"

    const/4 v10, 0x6

    if-ge v1, v0, :cond_1

    const/4 v10, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x5

    const-string/jumbo v3, "rrgm edv  egep eI=csmmircsf svme "

    const-string v3, "=esme vpdgfe crr s voeI srmcge mi"

    const-string v3, " geeoscmIg i sicvovseferr mdr=  m"

    const-string/jumbo v3, "receive msg from service msgId = "

    const/4 v10, 0x0

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v10, 0x6

    check-cast v3, Lcom/tencent/android/tpush/service/protocol/j;

    const/4 v10, 0x3

    iget-wide v3, v3, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    const/4 v10, 0x5

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const-string/jumbo v3, "qkg pb "

    const-string/jumbo v3, "pqk g  "

    const-string v3, " pkg = "

    const/4 v10, 0x1

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v10, 0x5

    check-cast v3, Lcom/tencent/android/tpush/service/protocol/j;

    const/4 v10, 0x6

    iget-object v3, v3, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const-string v3, " yp =eut"

    const-string/jumbo v3, "t spe= y"

    const-string v3, " yp=e  p"

    const-string v3, " type = "

    invoke-virtual {v0, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    const/4 v10, 0x6

    check-cast v3, Lcom/tencent/android/tpush/service/protocol/j;

    const/4 v10, 0x1

    iget-wide v3, v3, Lcom/tencent/android/tpush/service/protocol/j;->f:J

    const/4 v10, 0x1

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x1

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x7

    add-int/lit8 v1, v1, 0x1

    const/4 v10, 0x6

    goto :goto_0

    :cond_1
    const/4 v10, 0x2

    invoke-virtual {p1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    const/4 v10, 0x2

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v10, 0x2

    if-eqz v1, :cond_9

    const/4 v10, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v10, 0x1

    check-cast v1, Lcom/tencent/android/tpush/service/protocol/j;

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x6

    const-string v4, "d oubSrtqFm=m: eivcidtsiearcr"

    const-string v4, ":ramr itS otvdcsiemrcurdbFei="

    const-string v4, "eiscediurdtmstrec rrFSb=oi v:"

    const-string v4, "distributeFromServer : accid="

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    iget-wide v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->b:J

    const/4 v10, 0x1

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const-string v4, "cenmol h,d=n"

    const-string v4, "hnldo=Ic,en "

    const-string/jumbo v4, "lne,ochIn= a"

    const-string v4, " ,channelId="

    const/4 v10, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    iget-wide v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->m:J

    const/4 v10, 0x3

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const-string v4, "b=iIsbd,"

    const-string v4, "dbiu=bIs"

    const-string v4, ",busiId="

    const/4 v10, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    iget-wide v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->c:J

    const/4 v10, 0x6

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const-string v4, ",ugp="

    const-string v4, "gu,=p"

    const-string v4, ",kpp="

    const-string v4, ",pkg="

    const/4 v10, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    iget-object v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    const/4 v10, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const-string v4, "dqI=msg"

    const-string v4, ",msgId="

    const/4 v10, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    iget-wide v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    const/4 v10, 0x0

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const-string/jumbo v4, "tpsye="

    const-string v4, "epty=p"

    const-string/jumbo v4, "ytpm,="

    const-string v4, ",type="

    const/4 v10, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    iget-wide v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->f:J

    const/4 v10, 0x0

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const-string/jumbo v4, "ts=,"

    const-string v4, "=s,t"

    const-string v4, ",ts="

    const/4 v10, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->h:J

    const/4 v10, 0x1

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const-string/jumbo v4, "tq=uom,"

    const-string/jumbo v4, "tqim,u="

    const-string v4, ",litubm"

    const-string v4, ",multi="

    const/4 v10, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    iget-wide v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->i:J

    const/4 v10, 0x2

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const-string/jumbo v4, "ues,at"

    const-string v4, ",dstea"

    const-string v4, "apt=de"

    const-string v4, ",date="

    const/4 v10, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    iget-object v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->j:Ljava/lang/String;

    const/4 v10, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const-string/jumbo v4, "resiv,T=qeem"

    const-string/jumbo v4, "srTm=eiev,em"

    const-string v4, "Tesesir,rv=e"

    const-string v4, ",serverTime="

    const/4 v10, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->k:J

    const/4 v10, 0x5

    invoke-virtual {v3, v4, v5}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const-string/jumbo v4, "ottm,"

    const-string/jumbo v4, "tt=,o"

    const-string v4, "=tlto"

    const-string v4, ",ttl="

    const/4 v10, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    iget v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->l:I

    const/4 v10, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const-string v4, "e= s bz, "

    const-string v4, "=  , bsez"

    const-string/jumbo v4, "s, i zue="

    const-string v4, ", size = "

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v10, 0x6

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    const-string v4, "=Ir,ougpup"

    const-string v4, "gp=u,duIro"

    const-string/jumbo v4, "o ,rpI=uqd"

    const-string v4, ", groupId="

    const/4 v10, 0x5

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    iget-object v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->r:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const-string v4, "I=spuor ,pg"

    const-string v4, ",Iog=duppr "

    const-string v4, "I=pm mugd,o"

    const-string v4, ", mgroupId="

    const/4 v10, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    iget-object v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->s:Ljava/lang/String;

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const-string/jumbo v4, "rod oeeI,kv"

    const-string v4, ", revokeId="

    const/4 v10, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    iget v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->v:I

    const/4 v10, 0x3

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x4

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x3

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x2

    const-string v4, "b:eoebmdFervtnerrtciniStquost"

    const-string/jumbo v4, "rtSuesbmq:tdtrneitioroerevFcn"

    const-string/jumbo v4, "mrnttsuoivbdrcr:eSneeuoFer ti"

    const-string v4, "distributeFromServer content:"

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    iget-object v4, v1, Lcom/tencent/android/tpush/service/protocol/j;->e:Ljava/lang/String;

    const/4 v10, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x6

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    iget-wide v3, v1, Lcom/tencent/android/tpush/service/protocol/j;->f:J

    const/4 v10, 0x2

    const-wide/16 v5, 0x3

    const-wide/16 v5, 0x3

    const-wide/16 v5, 0x3

    const-wide/16 v5, 0x3

    const/4 v10, 0x5

    cmp-long v5, v3, v5

    const/4 v10, 0x2

    if-nez v5, :cond_3

    :try_start_0
    const/4 v10, 0x6

    iget-object v1, v1, Lcom/tencent/android/tpush/service/protocol/j;->e:Ljava/lang/String;

    const/4 v10, 0x1

    if-nez v1, :cond_2

    return-void

    :cond_2
    const/4 v10, 0x7

    invoke-direct {p0, v1}, Lcom/tencent/android/tpush/service/b/a;->a(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x0

    goto/16 :goto_1

    :catchall_0
    move-exception v1

    const/4 v10, 0x0

    const-string/jumbo v3, "rppesIrpsetee:ibprxmAiMgi nroSudesovntFt"

    const-string/jumbo v3, "mesetx ipnvIienFbtuMscsriAogt:eoerrrdpSp"

    const-string/jumbo v3, "xitcegmSqeoptiFs enen:rrubsediIpp oAtrMr"

    const-string v3, "distributeFromServerInAppMsg exception: "

    const/4 v10, 0x7

    invoke-static {v2, v3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v10, 0x2

    goto/16 :goto_1

    :cond_3
    const/4 v10, 0x1

    const-wide/16 v5, 0x6

    const-wide/16 v5, 0x6

    const-wide/16 v5, 0x6

    const-wide/16 v5, 0x6

    const/4 v10, 0x0

    cmp-long v5, v3, v5

    const/4 v10, 0x3

    if-nez v5, :cond_5

    :try_start_1
    const/4 v10, 0x1

    iget-object v3, v1, Lcom/tencent/android/tpush/service/protocol/j;->y:Ljava/lang/String;

    const/4 v10, 0x2

    if-nez v3, :cond_4

    const/4 v10, 0x0

    return-void

    :cond_4
    const/4 v10, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v3

    const/4 v10, 0x3

    invoke-static {v3}, Lcom/tencent/android/tpush/inappmessage/g;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/inappmessage/g;

    move-result-object v3

    const/4 v10, 0x1

    invoke-virtual {v3, v1}, Lcom/tencent/android/tpush/inappmessage/g;->a(Lcom/tencent/android/tpush/service/protocol/j;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v10, 0x5

    goto/16 :goto_1

    :catchall_1
    move-exception v1

    const/4 v10, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x4

    const-string/jumbo v4, "sssitegproticMroI tArFprixn:eebeSvpudem"

    const-string v4, "AtFmerepgbiitevpseuonerx:rdMsSrIop ctim"

    const-string v4, "distributeFromServerInAppMsg exception:"

    const/4 v10, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    invoke-virtual {v1}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x6

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x0

    goto/16 :goto_1

    :cond_5
    const/4 v10, 0x2

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const/4 v10, 0x4

    cmp-long v3, v3, v5

    const/4 v10, 0x1

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v10, 0x2

    if-nez v3, :cond_7

    :try_start_2
    const/4 v10, 0x7

    iget-object v3, v1, Lcom/tencent/android/tpush/service/protocol/j;->e:Ljava/lang/String;

    const/4 v10, 0x3

    if-nez v3, :cond_6

    const/4 v10, 0x6

    return-void

    :cond_6
    const/4 v10, 0x3

    new-instance v3, Lorg/json/JSONObject;

    const/4 v10, 0x5

    iget-object v1, v1, Lcom/tencent/android/tpush/service/protocol/j;->e:Ljava/lang/String;

    const/4 v10, 0x2

    invoke-direct {v3, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v10, 0x4

    const-string/jumbo v1, "otomnnt_eostcu"

    const-string/jumbo v1, "unc_octenttoso"

    const-string/jumbo v1, "t_tcontueosmnc"

    const-string v1, "custom_content"

    const/4 v10, 0x7

    const/4 v6, 0x0

    const/4 v10, 0x6

    invoke-virtual {v3, v1, v6}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v10, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v3

    const/4 v10, 0x3

    invoke-static {v3}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object v3

    const/4 v10, 0x0

    invoke-virtual {v3, v1, v4, v5}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->parseCloudConfig(Ljava/lang/String;J)V

    const/4 v10, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v3

    const/4 v10, 0x7

    invoke-direct {p0, v3, v1}, Lcom/tencent/android/tpush/service/b/a;->b(Landroid/content/Context;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    const/4 v10, 0x3

    goto/16 :goto_1

    :catchall_2
    move-exception v1

    const/4 v10, 0x6

    const-string v3, "f0epxbte 0tru:0peyco1 bd"

    const-string/jumbo v3, "r0 :eb pn1x0dytf0upoetce"

    const-string v3, "0tenp0u0xepee:  orc1duyf"

    const-string/jumbo v3, "unexpected for type:1000"

    const/4 v10, 0x3

    invoke-static {v2, v3, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v10, 0x2

    goto/16 :goto_1

    :cond_7
    const/4 v10, 0x6

    iget-object v3, v1, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    const/4 v10, 0x4

    invoke-static {v3}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    const/4 v10, 0x4

    if-eqz v3, :cond_8

    iget-wide v6, v1, Lcom/tencent/android/tpush/service/protocol/j;->i:J

    cmp-long v3, v6, v4

    const/4 v10, 0x1

    if-nez v3, :cond_8

    const/4 v10, 0x1

    iget-wide v6, v1, Lcom/tencent/android/tpush/service/protocol/j;->m:J

    const/4 v10, 0x0

    cmp-long v3, v6, v4

    const/4 v10, 0x6

    if-gtz v3, :cond_8

    const/4 v10, 0x5

    const-string/jumbo v3, "t> te!>p Durmigepsigksp abeuP mg.lu,Nmsaeinsa"

    const-string v3, ".skgm!uPeiiaee ugtDaaui ,mep ms bsp>rsNnt>lsg"

    const-string/jumbo v3, "s niaPspqkt! >ml,eeegabemssutp> rmDaigsi N.lg"

    const-string v3, ">> messageDistribute, msg.appPkgName is null!"

    const/4 v10, 0x2

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v4

    const/4 v10, 0x7

    const/16 v5, -0x67

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v10, 0x4

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const-string v6, "I:spsm"

    const-string v6, ":pImsd"

    const-string/jumbo v6, "m:smdg"

    const-string/jumbo v6, "msgId:"

    const/4 v10, 0x7

    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    iget-wide v6, v1, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    const/4 v10, 0x1

    invoke-virtual {v3, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x7

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const-wide/16 v7, 0x0

    const/4 v10, 0x2

    const-string/jumbo v9, "rnnqo"

    const-string/jumbo v9, "nrnqi"

    const-string v9, "bnrie"

    const-string/jumbo v9, "inner"

    const/4 v10, 0x2

    invoke-static/range {v4 .. v9}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    const/4 v10, 0x1

    goto/16 :goto_1

    :cond_8
    const/4 v10, 0x2

    invoke-direct {p0, v1, p2, p3, p4}, Lcom/tencent/android/tpush/service/b/a;->a(Lcom/tencent/android/tpush/service/protocol/j;JLcom/tencent/android/tpush/service/channel/a;)V

    const/4 v10, 0x2

    goto/16 :goto_1

    :cond_9
    const/4 v10, 0x5

    return-void
.end method
