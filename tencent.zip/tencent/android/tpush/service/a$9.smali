.class Lcom/tencent/android/tpush/service/a$9;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/service/c/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a;->f(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:I

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Lcom/tencent/android/tpush/service/a;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a;JILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$9;->f:Lcom/tencent/android/tpush/service/a;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-wide p2, p0, Lcom/tencent/android/tpush/service/a$9;->a:J

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x2

    iput p4, p0, Lcom/tencent/android/tpush/service/a$9;->b:I

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x1

    iput-object p5, p0, Lcom/tencent/android/tpush/service/a$9;->c:Ljava/lang/String;

    const/4 v0, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p6, p0, Lcom/tencent/android/tpush/service/a$9;->d:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x7

    iput-object p7, p0, Lcom/tencent/android/tpush/service/a$9;->e:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "o@s~ f~ ~~@o~M  rv- b @u@~ ~c @ ~ @ ~ @ .@l~ ~i@@~~~~~4y@as/doS~1@~oi@nKo b@@~i @~@ fb~tl~t@@@mo"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x3

    const-string p2, " e m Ngt am=a"

    const-string p2, "  seNtgaa m ="

    const/4 v8, 0x4

    const-string p2, "a e o tagm N,"

    const-string p2, " , tagName = "

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    const-string/jumbo p3, "nidSlbuPcrBetHerodevrcsamhs"

    const-string p3, "PnsmeBatrudivsahHcedSelcrro"

    const/4 v8, 0x6

    const-string/jumbo p3, "toaceSuPsBaceirrrdHaulenvsh"

    const-string p3, "PushServiceBroadcastHandler"

    const/4 v8, 0x0

    const/4 v7, 0x2

    if-nez p1, :cond_0

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-string v1, "c=kIt Sp otsuasae cg ecac c[  "

    const-string v1, "c  cote cSgecsIc ata=sa s [ ku"

    const/4 v8, 0x4

    const-string v1, "[se gac=q skstd a uc Ie a ctcc"

    const-string v1, "Set tag ack success  [accId = "

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x4

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/a$9;->a:J

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    const-string/jumbo v1, "tes   =at y,p"

    const-string/jumbo v1, "tp aybte,=   "

    const-string v1, " , tagtype = "

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x1

    iget v1, p0, Lcom/tencent/android/tpush/service/a$9;->b:I

    const/4 v8, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$9;->c:Ljava/lang/String;

    const/4 v7, 0x7

    move v8, v7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string p2, " pcme =Nu ,ma"

    const-string p2, "aN  p u,=kecm"

    const/4 v8, 0x6

    const-string p2, ",N moc=apea  "

    const-string p2, ", packName = "

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$9;->d:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x3

    const-string p2, "]"

    const-string p2, "]"

    const-string p2, "]"

    const-string p2, "]"

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x0

    invoke-static {p3, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$9;->f:Lcom/tencent/android/tpush/service/a;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$9;->c:Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget v3, p0, Lcom/tencent/android/tpush/service/a$9;->b:I

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    iget-object v4, p0, Lcom/tencent/android/tpush/service/a$9;->d:Ljava/lang/String;

    const/4 v8, 0x7

    iget-object v5, p0, Lcom/tencent/android/tpush/service/a$9;->e:Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    move v1, p1

    move v1, p1

    const/4 v8, 0x4

    move v1, p1

    move v1, p1

    const/4 v8, 0x4

    invoke-static/range {v0 .. v5}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v7, 0x5

    const-string v1, "c sa b if aeoCnaheegl Sedsdt= petitokpr"

    const-string/jumbo v1, "iedl dopa h=  se eagk p tacisCretoSetfn"

    const/4 v8, 0x5

    const-string v1, "Set tag ack failed with responseCode = "

    const/4 v7, 0x0

    shl-int/2addr v8, v7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$9;->c:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-static {p3, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$9;->f:Lcom/tencent/android/tpush/service/a;

    const/4 v7, 0x7

    move v8, v7

    const-string v2, "87uuf9f9q569//5u5c5d6dfa01d6/8f00/u4du5/u//8u469168u/15/ube/u22u7/4503/u"

    const/4 v8, 0x7

    const-string v2, "5u510uuu/6/fd62d95/uf648ed/02/c1fa5/uu0/1u0d5ub4/6f/598/47/89euu6u37895/"

    const-string/jumbo v2, "\u670d\u52a1\u5668\u5904\u7406\u5931\u8d25\uff0c\u8fd4\u56de\u9519\u8bef"

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$9;->c:Ljava/lang/String;

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    iget v4, p0, Lcom/tencent/android/tpush/service/a$9;->b:I

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x4

    iget-object v5, p0, Lcom/tencent/android/tpush/service/a$9;->d:Ljava/lang/String;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x1

    iget-object v6, p0, Lcom/tencent/android/tpush/service/a$9;->e:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x1

    move v1, p1

    move v1, p1

    const/4 v8, 0x1

    move v1, p1

    move v1, p1

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x5

    invoke-static/range {v0 .. v6}, Lcom/tencent/android/tpush/service/a;->b(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x1

    return-void
.end method

.method public b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x3

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-string v0, "eeT edlpn@gS saenda a@oHergdilMsn:a"

    const-string v0, "@@ TagHandler onMessageSendFailed: "

    const/4 v9, 0x3

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string v0, ", "

    const-string v0, ", "

    const/4 v9, 0x5

    const-string v0, ", "

    const-string v0, ", "

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x4

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x1

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string/jumbo v0, "rrsiveHcquPenodStaacrasdlsh"

    const-string v0, "hSsetcrnsPdlsvriHdecaraueoa"

    const/4 v9, 0x1

    const-string v0, "aHstddsSPraorhaviBsecerluce"

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {v0, p3}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$9;->f:Lcom/tencent/android/tpush/service/a;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    iget-object v4, p0, Lcom/tencent/android/tpush/service/a$9;->c:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    iget v5, p0, Lcom/tencent/android/tpush/service/a$9;->b:I

    const/4 v9, 0x1

    const/4 v8, 0x4

    iget-object v6, p0, Lcom/tencent/android/tpush/service/a$9;->d:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget-object v7, p0, Lcom/tencent/android/tpush/service/a$9;->e:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    move v2, p1

    move v2, p1

    move v2, p1

    move v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-static/range {v1 .. v7}, Lcom/tencent/android/tpush/service/a;->b(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    xor-int/2addr v9, v8

    return-void
.end method
