.class Lcom/tencent/android/tpush/service/a$b;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20150316"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;
    }
.end annotation

.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/service/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "b"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/a;

.field private b:Landroid/content/Context;

.field private c:Landroid/content/Intent;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$b;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v1, 0x2

    iput-object p3, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v1, 0x6

    const/4 v0, 0x4

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a$b;)Landroid/content/Intent;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " ~s~d~v   t /~@bf@M~~ .@ ~@@@uo ~41o@@n~@-o o~ @r~@   @ @l~cyb@~@~S ~s~~~~i@@/~iab@o ~@olf@ imtK"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object p0, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    return-object p0
.end method

.method static synthetic b(Lcom/tencent/android/tpush/service/a$b;)Landroid/content/Context;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x1

    iget-object p0, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v0, 0x0

    xor-int/2addr v1, v0

    return-object p0
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x1

    const-string v0, "BSdmrcecoesvPaaslrsHrhietan"

    const-string v0, "BrsvcsScaaradseehiodHPtenlr"

    const/4 v6, 0x0

    const-string v0, "aeudoPanraSBocrtdscrevHhles"

    const-string v0, "PushServiceBroadcastHandler"

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v5, 0x1

    move v6, v5

    invoke-virtual {v1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-nez v1, :cond_0

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-void

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x1

    const/4 v5, 0x5

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x7

    const-string v3, ""

    const-string v3, ""

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v1, v2, v3}, Ljava/lang/String;->replace(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x7

    const-string v3, "hvctmbelRtueSnines caebrn:i tnona,P"

    const-string v3, "aShm:eviRaonbcntente  cnluPtseirna,"

    const/4 v6, 0x2

    const-string/jumbo v3, "nilc  uneRotePinsnauSi:bh,cnrteaate"

    const-string v3, "PushServiceRannable, intent action:"

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string v2, ".En_anCpOttCcoa.dCoAneiSVcdce..x..CtKvEmETi4.nNTrp_oHTNg"

    const-string v2, "com.tencent.android.xg.vip.action.CHECK_CONNECT_STATE.V4"

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    if-eqz v2, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v5, 0x1

    xor-int/2addr v6, v5

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v5, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x3

    const-string v2, "..cgnVetqaiTeooRntGIapEo.dx.EcvRinS.nm.d.cio4"

    const-string v2, "Gn.eoi.E.Vnve.aiEmto.cnxoirccITp.t4aRSdR.gdon"

    const/4 v6, 0x3

    const-string v2, ".gsntncIiromSx.td.d.pnaRoan.ivicT.EGe4t.eREoV"

    const-string v2, "com.tencent.android.xg.vip.action.REGISTER.V4"

    const/4 v5, 0x6

    and-int/2addr v6, v5

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-eqz v2, :cond_2

    const/4 v5, 0x7

    move v6, v5

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v5, 0x0

    move v6, v5

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/service/a;->b(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string v2, ".TimcbVne.aUxcSn..4avE.g.dGmIrR.oecottEpnRnioti"

    const-string v2, "ScxcEbtRtcIingindUeea.v.t....onGVpnaomr4iTo.REN"

    const/4 v6, 0x1

    const-string v2, "Iacio...TUnemnnVivtdRaer4Epn.dtcx.SGERgoctoio.."

    const-string v2, "com.tencent.android.xg.vip.action.UNREGISTER.V4"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz v2, :cond_3

    const/4 v6, 0x5

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v5, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/service/a;->c(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_3
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    const-string v2, "c..enbnmEDAiB.UenctLNtV4nx_.ddaiit.vpucG.rEoogo.E"

    const-string/jumbo v2, "tV.oe.uncmGan.ar..cDxo.LEcUtgNdEoEe_ipBn.n4tiAvid"

    const-string/jumbo v2, "otvgViudn.._a.apoAidNmBBcGe.oc4iE.nLDtUetEEn.cxnr"

    const-string v2, "com.tencent.android.xg.vip.action.ENABLE_DEBUG.V4"

    const/4 v6, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v2, :cond_4

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/service/a;->d(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x6

    const-string v2, "acetTdEptti.VAVHoI.p4aRv.p.goLnS_iixcncoe..SnmrEdTNTn"

    const-string v2, "gVoId.tpEic..vTc.nennaVtAdS.neREipc_xT.4rtNLoiHTaMmSo"

    const/4 v6, 0x0

    const-string v2, "En..VTrpq.SM.aiHS_TgcVm.aonIx4teovitenLiTocARddc.N.Et"

    const-string v2, "com.tencent.android.xg.vip.action.SET_HTINTERVALMS.V4"

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eqz v2, :cond_5

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/service/a;->e(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x4

    goto/16 :goto_0

    :cond_5
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    const-string v2, "gisxntc.dnvc4C.ian.nGde_Sa.otKiVcM.rp..Aomte"

    const-string/jumbo v2, "o4.Vt.M.qncctxnn.rvpmAdgdi.teoK_.aaC.iGecniS"

    const/4 v6, 0x2

    const-string v2, "c4nmiCK.t_.aconv.VenA.meaioidG.npdcttrxoS..g"

    const-string v2, "com.tencent.android.xg.vip.action.MSG_ACK.V4"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    if-eqz v2, :cond_6

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x2

    goto/16 :goto_0

    :cond_6
    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v2, "dNnaota.egipnoiC.t.o.eroccmd.4iOnAv.VtCxUTnc"

    const-string v2, "com.tencent.android.xg.vip.action.ACCOUNT.V4"

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    if-eqz v2, :cond_7

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/service/a;->f(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    goto/16 :goto_0

    :cond_7
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string/jumbo v2, "nVcarbeGi.otnv.4n.sTgi.mdp.o.dtxiacncot."

    const-string/jumbo v2, "ogs.ooAcTa4tapdGn.ti.cvnc.nd.niimV.r.xte"

    const/4 v6, 0x5

    const-string v2, "eGttcxuva.nVdidint4o.n.re.c.oag.npm.ciTo"

    const-string v2, "com.tencent.android.xg.vip.action.TAG.V4"

    const/4 v5, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz v2, :cond_8

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/service/a;->g(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto/16 :goto_0

    :cond_8
    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    const-string v2, "4m.aYntpiooUAape.nxT..odQc.cGV.dmnniieSgttcr.E"

    const-string v2, "aiQmnUcVSotoiRT.c.d4ncm.t.i.tA.npoxn.EYraedeGg"

    const/4 v6, 0x4

    const-string v2, "cYtvxiSoqie.TdeU.goQ4cnnV..Anra.GEdncat.tio.mp"

    const-string v2, "com.tencent.android.xg.vip.action.QUERYTAGS.V4"

    const/4 v6, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v2, :cond_9

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/service/a;->h(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_9
    const/4 v6, 0x2

    const-string v2, "edsaxvoCa.SLLdViUC.oTS.nRiUct_.n.PE..I4nnmictKt.Hcgero"

    const-string v2, "U..Uod.oc.ii.ctnKacxIS.Stv.emT4pLiE.oeCHRC_ardPgLnVtnn"

    const/4 v6, 0x3

    const-string v2, "aSvmgSr.iEncR.mptL4_noe..CccPottKH.iLni.eTdaUVIUdn.o.x"

    const-string v2, "com.tencent.android.xg.vip.action.PUSH_CLICK.RESULT.V4"

    const/4 v5, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x0

    shl-int/2addr v6, v5

    if-eqz v2, :cond_a

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_a
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    const-string/jumbo v2, "nmH.oSEocUenCi_.Tnv.At.coSntoigcxbUNLpdRLLPeDEt.dV.i4.C.ar"

    const-string v2, "VgdeEbSEiptcttidoDr...HiLaeSo.U..m.RnoELcxAPvNLnUCn_T4c.nC"

    const/4 v6, 0x2

    const-string v2, "dP.vDbSc.HT4EA_rCtLniUN.CoRcLngenE.mdStVcxLiaEeioU.onp..ta"

    const-string v2, "com.tencent.android.xg.vip.action.PUSH_CANCELLED.RESULT.V4"

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    if-eqz v2, :cond_b

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_b
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    const-string/jumbo v2, "nit.2cucxovida.ak..a4d.g.otVnnpec.iokr.mssnecvrd"

    const/4 v6, 0x7

    const-string v2, "4cccsvue.en.g.trnVrkd2mtci.a.io.t.vpk.dadooasxnn"

    const-string v2, "com.tencent.android.xg.vip.action.ack.sdk2srv.V4"

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    if-eqz v2, :cond_c

    const/4 v6, 0x3

    goto/16 :goto_0

    :cond_c
    const/4 v5, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string/jumbo v2, "voATKp_paTN4cnx.mOcHUtoPS.TddopiOEercn.iE.gUtatH.Re_V._nDiEn"

    const-string/jumbo v2, "neDEioOpccdUoUVN_..oi_Sna.Ttnadp4eEE.txOci.vgmrRtHHnAT.P_TKP"

    const/4 v6, 0x5

    const-string v2, "A.Ptc.cpq4.eoaioNn_vi.ddEEamreioKUV..TngP_HD._UnRctHOnSTEtOT"

    const-string v2, "com.tencent.android.xg.vip.action.UPDATE_OTHER_PUSH_TOKEN.V4"

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eqz v2, :cond_d

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/service/a;->i(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    goto/16 :goto_0

    :cond_d
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v2, ".Msnpo.n_.RgPxeaRO.iMotE.iidtnrtvVTccd.COocanmq4"

    const-string/jumbo v2, "n4EiRdtTqgnOOmCepi..Vte.c..vtaronnMicaodxRMPo.c_"

    const/4 v6, 0x1

    const-string v2, "anom..REcnpOdg.nT.ciimnM4VaPriotecdtC..R.e_vxtOo"

    const-string v2, "com.tencent.android.xg.vip.action.COMM_REPORT.V4"

    const/4 v6, 0x5

    const/4 v5, 0x4

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-eqz v2, :cond_e

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/service/a;->j(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    goto/16 :goto_0

    :cond_e
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    const-string/jumbo v2, "oNCToEciAEdr.CdnnCOnteanoN_T.IVH.YsG"

    const-string v2, "CCs.OTNEoCoTdeGAnE.nYtHVr.dcnINnaN_i"

    const/4 v6, 0x7

    const-string v2, "dINAtbna_iNCEenVT.GCY.ncOTnNoorCE.Hd"

    const-string v2, "android.net.conn.CONNECTIVITY_CHANGE"

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v2, :cond_13

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x4

    const-string/jumbo v2, "konwnmurtIe"

    const-string/jumbo v2, "twImfrneokn"

    const/4 v6, 0x4

    const-string v2, "fntroIwpneo"

    const-string/jumbo v2, "networkInfo"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v1, v2}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x5

    check-cast v1, Landroid/net/NetworkInfo;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-nez v1, :cond_f

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x2

    return-void

    :cond_f
    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const-string v3, "cttecsnhqgC one nai - ona--ettdo"

    const-string v3, " - aoont-g-nadoeonCtsc iht eentc"

    const/4 v6, 0x3

    const-string v3, "Cnsoott- hdat n -aen eniceoc-tgs"

    const-string v3, "Connection state changed to --- "

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1}, Landroid/net/NetworkInfo;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x2

    const-string/jumbo v3, "otnmbionetivcn"

    const-string v3, "enntybvoioitcn"

    const/4 v6, 0x3

    const-string/jumbo v3, "ncotonityCoive"

    const-string/jumbo v3, "noConnectivity"

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    const/4 v4, 0x0

    const/4 v6, 0x2

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v2

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eqz v2, :cond_10

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_10
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x3

    sget-object v2, Landroid/net/NetworkInfo$State;->CONNECTED:Landroid/net/NetworkInfo$State;

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/net/NetworkInfo;->getState()Landroid/net/NetworkInfo$State;

    move-result-object v3

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-ne v2, v3, :cond_11

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string/jumbo v1, "ucn 3be ltss cekdte t rrG tedneaanorowtSrcneia"

    const-string/jumbo v1, "neen oun  n rrwkearteeaGtotst acdslSce3r dvtci"

    const/4 v6, 0x6

    const-string v1, " nGenSu ot deaaws3ernstieetlnre a odtvrt ckrXc"

    const-string/jumbo v1, "network connected and start XGService 3s later"

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    const-wide/16 v2, 0xbb8

    const-wide/16 v2, 0xbb8

    const/4 v6, 0x1

    const-wide/16 v2, 0xbb8

    const-wide/16 v2, 0xbb8

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/service/b;->a(Landroid/content/Context;J)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x2

    goto/16 :goto_0

    :cond_11
    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    sget-object v2, Landroid/net/NetworkInfo$State;->DISCONNECTED:Landroid/net/NetworkInfo$State;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v1}, Landroid/net/NetworkInfo;->getState()Landroid/net/NetworkInfo$State;

    move-result-object v3

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-ne v2, v3, :cond_12

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo v1, "itoecdppniroetcewn  dNss"

    const-string/jumbo v1, "oticNecprtewdnd. ie snso"

    const/4 v6, 0x7

    const-string/jumbo v1, "idsertewqoN n.idnsoect c"

    const-string v1, "Network is disconnected."

    const/4 v6, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    move v6, v5

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x0

    iget-object v1, v1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x2

    const/4 v2, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Lcom/tencent/android/tpush/c/a$a;->c(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    goto/16 :goto_0

    :cond_12
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const/4 v5, 0x2

    const-string v3, "hosk tqt tne-e asteor "

    const-string v3, "hker eoaqo-t erttnt  s"

    const/4 v6, 0x0

    const-string/jumbo v3, "ooem a  -rhtr ewnsektt"

    const-string/jumbo v3, "other network state - "

    const/4 v5, 0x2

    move v6, v5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/net/NetworkInfo;->getState()Landroid/net/NetworkInfo$State;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v1, "hontoisDgn. ."

    const-string/jumbo v1, "nosthgn  D..i"

    const/4 v6, 0x7

    const-string v1, "Dnh .bonoi gt"

    const-string v1, ". Do nothing."

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto/16 :goto_0

    :cond_13
    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x7

    const-string/jumbo v2, "ieanH.uxrmiL.cmtopndodnVt4tc.c.FUoSaein..g"

    const-string v2, "agimnVpr4tmoSoa.L.ie..idx.tc.nHoedcn.UnFct"

    const/4 v6, 0x3

    const-string v2, "drtvix4p.mLacSUHV..nntcnci.po.oti.geFda.oe"

    const-string v2, "com.tencent.android.xg.vip.action.FLUSH.V4"

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    if-eqz v2, :cond_14

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x0

    new-instance v1, Lcom/tencent/android/tpush/service/a$b$1;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/service/a$b$1;-><init>(Lcom/tencent/android/tpush/service/a$b;)V

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {v1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->flush(Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger$WriteFileCallback;)V

    const/4 v6, 0x2

    goto/16 :goto_0

    :cond_14
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string v2, ".Bix..gdq.etpTorniAdI.nVncocmvta4aRoteinUE.ocT"

    const-string v2, "ImnEoor.Tn.Rdie.tctoo.TcpTtUve.V4aBigAxidc.nna"

    const/4 v6, 0x3

    const-string v2, "TdstRo4axB.V.Tgein.UvAeointrn.i.T.ccopaInt.mEd"

    const-string v2, "com.tencent.android.xg.vip.action.ATTRIBUTE.V4"

    const/4 v6, 0x6

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x3

    if-eqz v2, :cond_15

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v6, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$b;->c:Landroid/content/Intent;

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x2

    invoke-static {v1, v2, v3}, Lcom/tencent/android/tpush/service/a;->k(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    goto :goto_0

    :cond_15
    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    const-string v2, "com.tencent.android.xg.vip.action.KILLSERVICEPROCESS.V4"

    const/4 v6, 0x7

    invoke-virtual {v2, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-eqz v1, :cond_16

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-string v1, "e pmb ivkcsleoiesecr"

    const-string/jumbo v1, "kiroebcev sicee prsl"

    const/4 v6, 0x2

    const-string/jumbo v1, "ircioepessr clee vol"

    const-string/jumbo v1, "receive kill process"

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->b()Lcom/tencent/android/tpush/service/b;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/b;->c()V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b;->b:Landroid/content/Context;

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-static {v1}, Lcom/tencent/tpns/baseapi/base/util/Util;->killPushProcess(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x5

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string v2, "co.rubesiu e orreaHvrcrlnsadPdutharSBn"

    const-string v2, "eraPHrudSBrnaet.ourro icr dvnuleesahcs"

    const/4 v6, 0x0

    const-string v2, "ceSvsruianrteh eHuaorrsruea. rcroPdnBl"

    const-string v2, "PushServiceBroadcastHandler run error."

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_16
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    return-void
.end method
