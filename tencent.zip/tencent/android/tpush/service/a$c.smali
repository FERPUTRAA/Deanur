.class Lcom/tencent/android/tpush/service/a$c;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/service/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "c"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/a;


# direct methods
.method private constructor <init>(Lcom/tencent/android/tpush/service/a;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$c;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/android/tpush/service/a;Lcom/tencent/android/tpush/service/a$1;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/service/a$c;-><init>(Lcom/tencent/android/tpush/service/a;)V

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "u~s@M~@b~o  s~r@c4@~ @~n~~~@ao~  @l@@.o@f lo~y@ioof ~~~~St@@@~b bvd@i  /@@@ t ~  @i~@ /m~ 1 K~-~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    const-string/jumbo v0, "pRrm oesAvipTceuece irnRPheev"

    const-string v0, "TPushAppReceiver - onReceiver"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v1, "raaBovndussaHoecrehrSstdclP"

    const-string/jumbo v1, "sdsSvtecParhsBlnadorurHecea"

    const-string/jumbo v1, "rveasbPSloeaaurndiHdecstrhc"

    const-string v1, "PushServiceBroadcastHandler"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz p2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz p1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$c;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/service/a;->b(Lcom/tencent/android/tpush/service/a;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x5

    if-eqz v0, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-instance v1, Lcom/tencent/android/tpush/service/a$b;

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$c;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-direct {v1, v2, p1, p2}, Lcom/tencent/android/tpush/service/a$b;-><init>(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    goto/16 :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    new-instance v2, Lcom/tencent/android/tpush/service/a$c$1;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-direct {v2, p0, p1}, Lcom/tencent/android/tpush/service/a$c$1;-><init>(Lcom/tencent/android/tpush/service/a$c;Landroid/content/Context;)V

    invoke-virtual {v0, v2}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v4, 0x7

    const/4 v3, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/service/a$c;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/service/a;->c(Lcom/tencent/android/tpush/service/a;)Ljava/util/ArrayList;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/16 v0, 0xa

    const/4 v4, 0x7

    if-ge p1, v0, :cond_1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpush/service/a$c;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p1}, Lcom/tencent/android/tpush/service/a;->c(Lcom/tencent/android/tpush/service/a;)Ljava/util/ArrayList;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x6

    const-string v0, "at,dipuatenoesevnehrfTdet etPn d ncicIubtrosn:iitopRAIdnee"

    const-string v0, "TPushAppReceiver add intend to beforeInitedIntents,action:"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo p2, "pise,m "

    const-string/jumbo p2, "zisme ,"

    const/4 v4, 0x3

    const-string p2, ":qize, "

    const-string p2, ", size:"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v4, 0x5

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$c;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-static {p2}, Lcom/tencent/android/tpush/service/a;->c(Lcom/tencent/android/tpush/service/a;)Ljava/util/ArrayList;

    move-result-object p2

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    goto :goto_0

    :cond_1
    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string/jumbo p1, "o sdbiofenmirITtIosrcishnac eed. u notte"

    const-string p1, "eInto.h   fdcnodsdeoirnmieairIcetbosT tu"

    const/4 v4, 0x0

    const-string p1, "eoimbnn rti iord tteTmc.asdutcohnI Idefe"

    const-string p1, "Too much beforeInitedIntents. discard it"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x0

    return-void
.end method
