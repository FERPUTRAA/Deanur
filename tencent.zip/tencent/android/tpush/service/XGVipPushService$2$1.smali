.class Lcom/tencent/android/tpush/service/XGVipPushService$2$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/XGVipPushService$2;->TRun()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/XGVipPushService$2;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/XGVipPushService$2;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/service/XGVipPushService$2$1;->a:Lcom/tencent/android/tpush/service/XGVipPushService$2;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "S~sl/csmay/f d 4@~@otol@~K@iu~o~@@ @@@bi  ~  ~M@v@@~ @ ~~~~. o~ oi~t @@~b @b@f@~1 ~~~~ n -o@~ r~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v1, "e-tm--Cceiskvsnhim eters:l-gMa"

    const-string v1, "eCsem -iMtc-ter-skseenilahgv:-"

    const/4 v5, 0x7

    const-string v1, "c-neoe-hrmtiMCiask -gavse-el:t"

    const-string v1, "--CheckMessage--interval time:"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/XGVipPushService;->c()J

    move-result-wide v1

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string v1, "hmeiGbvXrpcVseui"

    const-string/jumbo v1, "vsemGVhiXrcSeipu"

    const/4 v5, 0x1

    const-string v1, "XeeviSuuhPscVpGr"

    const-string v1, "XGVipPushService"

    const/4 v4, 0x6

    move v5, v4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/service/XGVipPushService$2$1;->a:Lcom/tencent/android/tpush/service/XGVipPushService$2;

    const/4 v5, 0x3

    const/4 v4, 0x1

    iget-object v0, v0, Lcom/tencent/android/tpush/service/XGVipPushService$2;->a:Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/a;->c(Landroid/content/Context;)V

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/service/XGVipPushService$2$1;->a:Lcom/tencent/android/tpush/service/XGVipPushService$2;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v0, v0, Lcom/tencent/android/tpush/service/XGVipPushService$2;->a:Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/tencent/tpns/mqttchannel/core/common/config/MqttConfigImpl;->getKeepAliveInterval(Landroid/content/Context;)I

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/16 v1, 0x11d

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-lt v0, v1, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/service/XGVipPushService$2$1;->a:Lcom/tencent/android/tpush/service/XGVipPushService$2;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    iget-object v0, v0, Lcom/tencent/android/tpush/service/XGVipPushService$2;->a:Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/tencent/tpns/dataacquisition/DeviceInfos;->isScreenOn(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-eqz v0, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-wide/32 v0, 0x1d4c0

    const-wide/32 v0, 0x1d4c0

    const/4 v5, 0x3

    const-wide/32 v0, 0x1d4c0

    const-wide/32 v0, 0x1d4c0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/service/XGVipPushService;->a(J)J

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    move v5, v4

    const-wide/32 v0, 0x41eb0

    const-wide/32 v0, 0x41eb0

    const/4 v5, 0x1

    const-wide/32 v0, 0x41eb0

    const-wide/32 v0, 0x41eb0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/service/XGVipPushService;->a(J)J

    :goto_0
    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/service/XGVipPushService$2$1;->a:Lcom/tencent/android/tpush/service/XGVipPushService$2;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v0, v0, Lcom/tencent/android/tpush/service/XGVipPushService$2;->a:Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/service/XGVipPushService;->a(Lcom/tencent/android/tpush/service/XGVipPushService;)Landroid/os/Handler;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v0, :cond_1

    const/4 v5, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/service/XGVipPushService$2$1;->a:Lcom/tencent/android/tpush/service/XGVipPushService$2;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, v0, Lcom/tencent/android/tpush/service/XGVipPushService$2;->a:Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v1, v0, Lcom/tencent/android/tpush/service/XGVipPushService;->a:Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    const/4 v4, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/service/XGVipPushService;->a(Lcom/tencent/android/tpush/service/XGVipPushService;)Landroid/os/Handler;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/XGVipPushService$2$1;->a:Lcom/tencent/android/tpush/service/XGVipPushService$2;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    iget-object v1, v1, Lcom/tencent/android/tpush/service/XGVipPushService$2;->a:Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v5, 0x3

    const/4 v4, 0x6

    iget-object v1, v1, Lcom/tencent/android/tpush/service/XGVipPushService;->a:Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/XGVipPushService;->c()J

    move-result-wide v2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2, v3}, Landroid/os/Handler;->postDelayed(Ljava/lang/Runnable;J)Z

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    return-void
.end method
