.class public Lcom/tencent/android/tpush/service/b$a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/service/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation


# static fields
.field public static final a:Lcom/tencent/android/tpush/service/b;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    new-instance v0, Lcom/tencent/android/tpush/service/b;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Lcom/tencent/android/tpush/service/b;-><init>(Lcom/tencent/android/tpush/service/b$1;)V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    sput-object v0, Lcom/tencent/android/tpush/service/b$a;->a:Lcom/tencent/android/tpush/service/b;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method
