.class Lcom/tencent/android/tpush/service/a$8;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/service/c/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a;->e(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:I

.field final synthetic c:I

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Ljava/lang/String;

.field final synthetic g:Lcom/tencent/android/tpush/service/a;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a;JIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$8;->g:Lcom/tencent/android/tpush/service/a;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-wide p2, p0, Lcom/tencent/android/tpush/service/a$8;->a:J

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p4, p0, Lcom/tencent/android/tpush/service/a$8;->b:I

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput p5, p0, Lcom/tencent/android/tpush/service/a$8;->c:I

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p6, p0, Lcom/tencent/android/tpush/service/a$8;->d:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x4

    iput-object p7, p0, Lcom/tencent/android/tpush/service/a$8;->e:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p8, p0, Lcom/tencent/android/tpush/service/a$8;->f:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "@~s~@i~ft~a ~ s~~/~  tb~@@vol~ @d@ o@-y  boSi r4@~K  @@@ @ ~. Mbnm ~i~@@/c~~~@ ~@f~~o~@ 1~@u@@lo"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x4

    const-string/jumbo p3, "ircmrnhddstvSasesuHBalrePco"

    const-string/jumbo p3, "vBsreoieaadnHthulsPcsdrSrec"

    const/4 v9, 0x2

    const-string/jumbo p3, "oeuaortsesdrcPdnivHlBercSah"

    const-string p3, "PushServiceBroadcastHandler"

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-nez p1, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-string v1, "  tkmbass  =c ceIscuaceg dGcat "

    const-string v1, "aa=msGe tdsksu  c  scccac tI ge"

    const/4 v9, 0x1

    const-string v1, "Get tags ack success  [accId = "

    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/a$8;->a:J

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x7

    const-string v1, "f ,eoft=o  s"

    const/4 v9, 0x0

    const-string v1, " , offset = "

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget v1, p0, Lcom/tencent/android/tpush/service/a$8;->b:I

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    const-string v1, " bii mu =t,"

    const-string/jumbo v1, "t=i ib, m l"

    const/4 v9, 0x1

    const-string v1, "    =itpi,m"

    const-string v1, " , limit = "

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x2

    iget v1, p0, Lcom/tencent/android/tpush/service/a$8;->c:I

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-string v1, " o e,r uqs=sp"

    const-string v1, " orsp u sn=,e"

    const/4 v9, 0x5

    const-string v1, "e,s n eps or="

    const-string v1, ", response = "

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string v1, "]"

    const/4 v9, 0x3

    const-string v1, "]"

    const-string v1, "]"

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x1

    const/4 v8, 0x4

    invoke-static {p3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$8;->g:Lcom/tencent/android/tpush/service/a;

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget v3, p0, Lcom/tencent/android/tpush/service/a$8;->b:I

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    iget v4, p0, Lcom/tencent/android/tpush/service/a$8;->c:I

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-object v5, p0, Lcom/tencent/android/tpush/service/a$8;->d:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget-object v7, p0, Lcom/tencent/android/tpush/service/a$8;->e:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    move v2, p1

    move v2, p1

    const/4 v9, 0x5

    move v2, p1

    move v2, p1

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-static/range {v1 .. v7}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    goto :goto_0

    :cond_0
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string v1, "Steaadkpinle ehfett r   og isdpaocs= wC"

    const/4 v9, 0x4

    const-string/jumbo v1, "oahmegktefta=ewiaicC or   seeS  slpd tn"

    const-string v1, "Set tag ack failed with responseCode = "

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string v1, "a, Noatq=  m "

    const-string v1, "aa , e mqN=t "

    const/4 v9, 0x5

    const-string v1, " g Nmb ,taea="

    const-string v1, " , tagName = "

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$8;->f:Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-static {p3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$8;->g:Lcom/tencent/android/tpush/service/a;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    iget v3, p0, Lcom/tencent/android/tpush/service/a$8;->b:I

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x4

    iget v4, p0, Lcom/tencent/android/tpush/service/a$8;->c:I

    const/4 v8, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v5, p0, Lcom/tencent/android/tpush/service/a$8;->d:Ljava/lang/String;

    const/4 v9, 0x4

    iget-object v7, p0, Lcom/tencent/android/tpush/service/a$8;->e:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    move v2, p1

    move v2, p1

    const/4 v9, 0x3

    move v2, p1

    move v2, p1

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-static/range {v1 .. v7}, Lcom/tencent/android/tpush/service/a;->b(Lcom/tencent/android/tpush/service/a;IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x5

    return-void
.end method

.method public b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const-string v0, "QHseeFuasnlnds: oaalg gera@eiys@MdSrndTe "

    const/4 v9, 0x5

    const-string v0, "d@ edeu rglnyaaneMeenH@aagied:lQSsTsur os"

    const-string v0, "@@ QueryTagsHandler onMessageSendFailed: "

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    const-string v0, ", "

    const-string v0, ", "

    const-string v0, ", "

    const-string v0, ", "

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    const-string/jumbo v0, "seeePvdphrtmiaoBHSaculdracr"

    const-string v0, "esrmeParaaecrshuiotdHdScBlv"

    const/4 v9, 0x6

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {v0, p3}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$8;->g:Lcom/tencent/android/tpush/service/a;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget v3, p0, Lcom/tencent/android/tpush/service/a$8;->b:I

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget v4, p0, Lcom/tencent/android/tpush/service/a$8;->c:I

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    iget-object v5, p0, Lcom/tencent/android/tpush/service/a$8;->d:Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget-object v7, p0, Lcom/tencent/android/tpush/service/a$8;->e:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x7

    move v2, p1

    move v2, p1

    const/4 v9, 0x3

    move v2, p1

    move v2, p1

    move-object v6, p2

    move-object v6, p2

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static/range {v1 .. v7}, Lcom/tencent/android/tpush/service/a;->b(Lcom/tencent/android/tpush/service/a;IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x4

    return-void
.end method
