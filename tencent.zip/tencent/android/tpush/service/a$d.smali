.class Lcom/tencent/android/tpush/service/a$d;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/service/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "d"
.end annotation


# instance fields
.field a:J

.field final synthetic b:Lcom/tencent/android/tpush/service/a;


# direct methods
.method private constructor <init>(Lcom/tencent/android/tpush/service/a;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$d;->b:Lcom/tencent/android/tpush/service/a;

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/a$d;->a:J

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/android/tpush/service/a;Lcom/tencent/android/tpush/service/a$1;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/service/a$d;-><init>(Lcom/tencent/android/tpush/service/a;)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "l~sm d@~M@ @~~~~ 4aoc   -Ki foi@~o@v~1@  .bu~@@/@/sS~@~~y~@~~@f~rb~o@l o~~ @~ @i~ @tot@ ~b@@ @ n"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    if-eqz p2, :cond_5

    const/4 v5, 0x7

    if-eqz p1, :cond_5

    const/4 v4, 0x6

    shl-int/2addr v5, v4

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo v1, "tinmnIrGenNN.OAHsEVdTTo_CnY.NcaCCdoE"

    const-string v1, "NosTNAoaiEE.tYCNVTcGdH.OCI_.nnnCdenr"

    const/4 v5, 0x2

    const-string v1, "android.net.conn.CONNECTIVITY_CHANGE"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string v1, "ScedoemrsPtncdrrloBHaisaaeh"

    const-string v1, "iadmtelSaudcorehnPrrBHecssa"

    const/4 v5, 0x4

    const-string v1, "ednlcbHirssceraPdaSvoertBau"

    const-string v1, "PushServiceBroadcastHandler"

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz v0, :cond_4

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo p1, "oItnokunwfr"

    const-string/jumbo p1, "networkInfo"

    const/4 v5, 0x6

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getParcelableExtra(Ljava/lang/String;)Landroid/os/Parcelable;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    check-cast p1, Landroid/net/NetworkInfo;

    const/4 v5, 0x7

    const/4 v4, 0x3

    if-nez p1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    return-void

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string v2, "g   tadpnesita-ehntoo coencCtn"

    const-string/jumbo v2, "taC ottaecds-g ntn necoh oi en"

    const/4 v5, 0x5

    const-string/jumbo v2, "notsee  qentCa-ntgtd  oac oich"

    const-string v2, "Connection state changed to - "

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {p1}, Landroid/net/NetworkInfo;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string/jumbo v0, "nositnyncetoib"

    const-string/jumbo v0, "tennCbcyiootni"

    const/4 v5, 0x2

    const-string/jumbo v0, "niCmyncvioenot"

    const-string/jumbo v0, "noConnectivity"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x7

    const/4 v2, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-virtual {p2, v0, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p2

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eqz p2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    sget-object p2, Landroid/net/NetworkInfo$State;->CONNECTED:Landroid/net/NetworkInfo$State;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/net/NetworkInfo;->getState()Landroid/net/NetworkInfo$State;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-ne p2, v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string p1, "dk nonnnsrt.eCllotnatetelcotn nar  acle nnqcthrlendowCa eettnMt ocI ars"

    const-string p1, "Internl network connected and call MqttChannel.startConnect on 5s later"

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p1

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    new-instance p2, Lcom/tencent/android/tpush/service/a$d$1;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {p2, p0}, Lcom/tencent/android/tpush/service/a$d$1;-><init>(Lcom/tencent/android/tpush/service/a$d;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const-wide/16 v0, 0x1388

    const-wide/16 v0, 0x1388

    const/4 v5, 0x6

    const-wide/16 v0, 0x1388

    const-wide/16 v0, 0x1388

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1, p2, v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;J)Z

    const/4 v5, 0x4

    goto/16 :goto_0

    :cond_2
    const/4 v5, 0x3

    sget-object p2, Landroid/net/NetworkInfo$State;->DISCONNECTED:Landroid/net/NetworkInfo$State;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {p1}, Landroid/net/NetworkInfo;->getState()Landroid/net/NetworkInfo$State;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-ne p2, v0, :cond_3

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string p1, "d ieNbio dscnkurtotce.es"

    const-string/jumbo p1, "noccitutNdiesrs  nko.eed"

    const/4 v5, 0x3

    const-string/jumbo p1, "tkocteu enidsndw.cieor s"

    const-string p1, "Network is disconnected."

    const/4 v5, 0x6

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object p1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget-object p1, p1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 p2, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p1, p2}, Lcom/tencent/android/tpush/c/a$a;->c(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto/16 :goto_0

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v0, "-wtt  opshertnae petor"

    const-string/jumbo v0, "wr rohopn es- tea ttte"

    const/4 v5, 0x3

    const-string/jumbo v0, "n-tt w tqrhesaer  oeok"

    const-string/jumbo v0, "other network state - "

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1}, Landroid/net/NetworkInfo;->getState()Landroid/net/NetworkInfo$State;

    move-result-object p1

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo p1, "q sDn.o ti.gh"

    const-string p1, "h. nngioqt D."

    const/4 v5, 0x0

    const-string p1, "Dohmgt .nio.n"

    const-string p1, ". Do nothing."

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    goto :goto_0

    :cond_4
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string p2, "ert-orPee-Rnsecesvr--sU"

    const-string p2, "e-snUietcvesP-rrse-e-Rr"

    const/4 v5, 0x4

    const-string/jumbo p2, "r-seebeRv-rc-P-ntieeUes"

    const-string p2, "--UserPresentReceiver--"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-static {v1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x3

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/a$d;->a:J

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    sub-long/2addr v0, v2

    const/4 v5, 0x5

    const/4 v4, 0x2

    invoke-static {v0, v1}, Ljava/lang/Math;->abs(J)J

    move-result-wide v0

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-wide/16 v2, 0x1f40

    const-wide/16 v2, 0x1f40

    const/4 v5, 0x6

    const-wide/16 v2, 0x1f40

    const-wide/16 v2, 0x1f40

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    cmp-long p2, v0, v2

    const/4 v5, 0x0

    const/4 v4, 0x6

    if-lez p2, :cond_5

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p2

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    new-instance v0, Lcom/tencent/android/tpush/service/a$d$2;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-direct {v0, p0, p1}, Lcom/tencent/android/tpush/service/a$d$2;-><init>(Lcom/tencent/android/tpush/service/a$d;Landroid/content/Context;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-wide/16 v1, 0x7d0

    const-wide/16 v1, 0x7d0

    const/4 v5, 0x4

    const-wide/16 v1, 0x7d0

    const-wide/16 v1, 0x7d0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p2, v0, v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;J)Z

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide p1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    iput-wide p1, p0, Lcom/tencent/android/tpush/service/a$d;->a:J

    :cond_5
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-void
.end method
