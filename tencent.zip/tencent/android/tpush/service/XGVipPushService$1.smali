.class Lcom/tencent/android/tpush/service/XGVipPushService$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/XGVipPushService;->onDestroy()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/XGVipPushService;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/XGVipPushService;)V
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    iput-object p1, p0, Lcom/tencent/android/tpush/service/XGVipPushService$1;->a:Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~@s.it~l ~fyM~ /@a ~@v4@@K@~b@~f~@ ~@oS@m~ ~@1d~o@c/~u~b@@~@@ t@@   o ob-lor~~~   @o ~i~i ~~sn  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/logging/TLogger;->flush()V

    const/4 v1, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/XGVipPushService;->b()Landroid/app/Service;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/XGApiConfig;->isEnableService(Landroid/content/Context;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->b()Lcom/tencent/android/tpush/service/b;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpush/service/b;->c()V

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method
