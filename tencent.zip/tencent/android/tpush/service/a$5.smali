.class Lcom/tencent/android/tpush/service/a$5;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/service/c/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a;->b(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/service/protocol/m;

.field final synthetic c:Lcom/tencent/android/tpush/service/a;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Lcom/tencent/android/tpush/service/protocol/m;)V
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$5;->c:Lcom/tencent/android/tpush/service/a;

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/tencent/android/tpush/service/a$5;->a:Landroid/content/Context;

    const/4 v1, 0x7

    const/4 v0, 0x2

    iput-object p3, p0, Lcom/tencent/android/tpush/service/a$5;->b:Lcom/tencent/android/tpush/service/protocol/m;

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "@vsb~s  1o~@l~@~~M/@@ @~f ca@u4~~i~o oi@@@~@  @@~ ~ K~dt~ f~~@r@@/ o S ni @o~.o b~yb~l~t m~@~@ -"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x7

    const-string/jumbo v0, "nSsmharecBsaardeulcsPtridve"

    const-string v0, "cssadeScearnorBahureliPvtds"

    const-string/jumbo v0, "vrrPoHuodencsshSatcridaBael"

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-nez p1, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    new-instance v3, Lcom/tencent/android/tpush/service/protocol/n;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-direct {v3}, Lcom/tencent/android/tpush/service/protocol/n;-><init>()V

    :try_start_0
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    if-eqz v1, :cond_0

    const/4 v8, 0x0

    move v9, v8

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$5;->a:Landroid/content/Context;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->b()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {p2, v1}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object p2

    const/4 v9, 0x5

    const/4 v8, 0x1

    check-cast p2, Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->e(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    goto :goto_0

    :cond_0
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$5;->a:Landroid/content/Context;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    const/4 v2, 0x1

    const/4 v8, 0x2

    shl-int/2addr v9, v8

    new-array v2, v2, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->b()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->f(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x2

    const/4 v8, 0x7

    invoke-virtual {v4, v5}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    const/4 v5, 0x0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    aput-object v4, v2, v5

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-static {v1, v2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V

    :goto_0
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v3, p2}, Lcom/tencent/android/tpush/service/protocol/n;->a(Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    const-string v1, "grnmtecaoopR [R censI>   >is=ese"

    const/4 v9, 0x2

    const-string v1, " Rsaobo sIepRcd cit> rs=[ eeegn>"

    const-string v1, ">> Register onResponse [accId = "

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$5;->b:Lcom/tencent/android/tpush/service/protocol/m;

    const/4 v9, 0x7

    iget-wide v1, v1, Lcom/tencent/android/tpush/service/protocol/m;->a:J

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-virtual {p2, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string/jumbo v1, "o,:o tuk"

    const-string/jumbo v1, "t:k,o eo"

    const/4 v9, 0x2

    const-string v1, " e,k:tnp"

    const-string v1, ", token:"

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object v1, v3, Lcom/tencent/android/tpush/service/protocol/n;->b:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string/jumbo v1, "u:,T bpPeohrheys"

    const/4 v9, 0x5

    const-string v1, "eh,u oTeqh:tPprs"

    const-string v1, ", otherPushType:"

    const/4 v9, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    iget-wide v1, v3, Lcom/tencent/android/tpush/service/protocol/n;->d:J

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p2, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const-string v1, ":userooTenht,"

    const-string/jumbo v1, "nee ,Tuoot:hr"

    const/4 v9, 0x3

    const-string/jumbo v1, "renm,t:To eoh"

    const-string v1, ", otherToken:"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v1, v3, Lcom/tencent/android/tpush/service/protocol/n;->e:Ljava/lang/String;

    const/4 v9, 0x1

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x3

    const-string v1, "a c,oepkN pm a"

    const-string v1, "ac ,=N pma pke"

    const/4 v9, 0x4

    const-string v1, " a,pNbma  e= c"

    const-string v1, " , packName = "

    const/4 v8, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$5;->b:Lcom/tencent/android/tpush/service/protocol/m;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x3

    iget-object v1, v1, Lcom/tencent/android/tpush/service/protocol/m;->K:Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    move v9, v8

    const-string v1, "]"

    const-string v1, "]"

    const/4 v9, 0x3

    const-string v1, "]"

    const-string v1, "]"

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$5;->c:Lcom/tencent/android/tpush/service/a;

    move-object v4, p3

    move-object v4, p3

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x3

    check-cast v4, Lcom/tencent/android/tpush/service/protocol/m;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$5;->b:Lcom/tencent/android/tpush/service/protocol/m;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x4

    iget-object v5, p2, Lcom/tencent/android/tpush/service/protocol/m;->K:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    iget-boolean v6, p2, Lcom/tencent/android/tpush/service/protocol/m;->J:Z

    const/4 v8, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v7, p2, Lcom/tencent/android/tpush/service/protocol/m;->N:Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    move v2, p1

    move v2, p1

    const/4 v9, 0x5

    move v2, p1

    move v2, p1

    const/4 v8, 0x7

    shr-int/2addr v9, v8

    invoke-static/range {v1 .. v7}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILcom/tencent/android/tpush/service/protocol/n;Lcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;ZLjava/lang/String;)V

    const/4 v8, 0x4

    move v9, v8

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$5;->a:Landroid/content/Context;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {p2}, Lcom/tencent/tpns/baseapi/XGApiConfig;->setRegisterSuccess(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x7

    const/4 v8, 0x2

    goto/16 :goto_1

    :catchall_0
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string v1, "/ci/1uu5qu1/ug 8a6eo/suRe/9 8sdfe850e9uo 59/48l/ts>en79uRnu6be5f  i0bfd39ue65pbu/r58,f//fu"

    const-string v1, ">fn/f598q5uc/>R5esgu55ubi nf6/u4618/f88uue7,0ouf9ase  sbt6ipbe3/u99eu/Rer9ed /5/1/0/dulo8 "

    const/4 v9, 0x0

    const-string/jumbo v1, "us6edRepu8duf bu6b r55e98/9li0/5iebnu3715Ru/9/8o>u9o e18uf>59/g 5ute/npa/sf/0f,4cf s/3/6eu"

    const-string v1, ">> Register onResponse fail, \u89e3\u6790\u8fd4\u56de\u5185\u5bb9\u683c\u5f0f\u9519\u8bef "

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/service/a$5;->c:Lcom/tencent/android/tpush/service/a;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    check-cast p3, Lcom/tencent/android/tpush/service/protocol/m;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$5;->b:Lcom/tencent/android/tpush/service/protocol/m;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x7

    iget-object p2, p2, Lcom/tencent/android/tpush/service/protocol/m;->K:Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    const/16 v0, -0x65

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-string v1, "16u66/u5qab////8//seuuu999340d6/0u5/826u85uu51d/b9885f125/ud57ed7u"

    const-string v1, "2us9e3u890u566d/5/5d5/7//b8152ub/13u8/ua66/uuu/d1/edf95068u758/4u9"

    const/4 v9, 0x2

    const-string v1, "b7su4/38d5u//u//1uf8be//673du/5a8e515uu1/u/d22u5509u60/69u8596956d"

    const-string/jumbo v1, "\u89e3\u6790\u670d\u52a1\u5668\u8fd4\u56de\u5185\u5bb9\u5931\u8d25"

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {p1, v0, v1, p3, p2}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;)V

    const/4 v9, 0x6

    return-void

    :cond_1
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x5

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string/jumbo v1, "p0rm559,kn;faed813>uo415fuu 6s58b>76d/i/e/ueC5/rol5  /06R /d/=s1ue42/it f/958uu/2e,s6e946e9g/ua07uuacdd8 u"

    const-string v1, ">> Register ack fail, \u670d\u52a1\u5668\u5904\u7406\u5931\u8d25,\u8fd4\u56de\u9519\u8bef; responseCode = "

    const/4 v9, 0x0

    const/4 v8, 0x0

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    shr-int/2addr v9, v8

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$5;->c:Lcom/tencent/android/tpush/service/a;

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    check-cast p3, Lcom/tencent/android/tpush/service/protocol/m;

    const/4 v8, 0x7

    move v9, v8

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$5;->b:Lcom/tencent/android/tpush/service/protocol/m;

    const/4 v9, 0x2

    const/4 v8, 0x1

    iget-object v0, v0, Lcom/tencent/android/tpush/service/protocol/m;->K:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const-string v1, "c26uo499u93u5//1ffud//58/b05u/d7/6ud1fm7efd05u/120/45u6u/085486/uu8ae56u"

    const-string v1, "f6fm95ud/9968u4bd54018814/f221u/0eu56fuu06uc/56dad50//3e/u98u//7u5uu/75/"

    const/4 v9, 0x3

    const-string/jumbo v1, "\u670d\u52a1\u5668\u5904\u7406\u5931\u8d25\uff0c\u8fd4\u56de\u9519\u8bef"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {p2, p1, v1, p3, v0}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;)V

    :goto_1
    const/4 v9, 0x1

    const/4 v8, 0x5

    return-void
.end method

.method public b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v1, "r rs baetiMFgnSddstslg:eaei @oenee"

    const-string v1, "@@ registetr onMessageSendFailed: "

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const-string v1, ", "

    const-string v1, ", "

    const/4 v3, 0x3

    const-string v1, ", "

    const-string v1, ", "

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "voauslusdhoSPcrtneBecdHarai"

    const-string v1, "doehoiBrvrtnsacuadsrPclSaHe"

    const/4 v3, 0x0

    const-string v1, "PushServiceBroadcastHandler"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$5;->c:Lcom/tencent/android/tpush/service/a;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    check-cast p3, Lcom/tencent/android/tpush/service/protocol/m;

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$5;->b:Lcom/tencent/android/tpush/service/protocol/m;

    const/4 v3, 0x2

    iget-object v1, v1, Lcom/tencent/android/tpush/service/protocol/m;->K:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0, p1, p2, p3, v1}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method
