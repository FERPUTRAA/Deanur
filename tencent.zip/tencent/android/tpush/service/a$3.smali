.class Lcom/tencent/android/tpush/service/a$3;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/service/c/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a;->i(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Landroid/content/Intent;

.field final synthetic e:Lcom/tencent/android/tpush/service/a;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a;Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$3;->e:Lcom/tencent/android/tpush/service/a;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p2, p0, Lcom/tencent/android/tpush/service/a$3;->a:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-object p3, p0, Lcom/tencent/android/tpush/service/a$3;->b:Landroid/content/Context;

    iput-object p4, p0, Lcom/tencent/android/tpush/service/a$3;->c:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p5, p0, Lcom/tencent/android/tpush/service/a$3;->d:Landroid/content/Intent;

    const/4 v0, 0x5

    move v1, v0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~Ss@~1 @@ @i sb@ ~4oly~n~~~@o@foKm vo~@i@ b  @~ta@ ~@ .~~u~t~fo  di~ ~@~@ l-@/rM@oc/ @@ ~~~b@ ~@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    const-string/jumbo p2, "rssmvteleSPcdahrncHiBousdea"

    const-string p2, "HasualceSsrivdePrcBatohsedn"

    const-string/jumbo p2, "rclvoaaceeSotesHdsriPrdhBun"

    const-string p2, "PushServiceBroadcastHandler"

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x7

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string v0, "hn aebRooies[>emCdaMckd  w>srtcmastcem p = "

    const-string v0, "=a moem d Ieh>e>[pdswe aasiRcs nok MctcCmrt"

    const/4 v2, 0x6

    const-string/jumbo v0, "meeeisup> r[cRtd ses g>mcna ahkcMatC =o dwI"

    const-string v0, ">> sendCommReportMessage ack with [accId = "

    const/4 v2, 0x1

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$3;->a:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string v0, " so p,rp  "

    const-string v0, " p  os  r,"

    const/4 v2, 0x2

    const-string/jumbo v0, "p=   rs,q "

    const-string v0, "  , rsp = "

    const/4 v2, 0x2

    const/4 v1, 0x1

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const-string p1, "]"

    const-string p1, "]"

    const/4 v2, 0x3

    const-string p1, "]"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/service/a$3;->b:Landroid/content/Context;

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$3;->c:Ljava/lang/String;

    const/4 v2, 0x5

    iget-object p3, p0, Lcom/tencent/android/tpush/service/a$3;->d:Landroid/content/Intent;

    const/4 v2, 0x7

    const/4 v1, 0x6

    invoke-virtual {p3}, Landroid/content/Intent;->toURI()Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p1, p2, p3}, Lcom/tencent/android/tpush/a;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v2, 0x2

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x3

    const-string v0, "d sbseepgorl dpse es=o nMnaRseosfeakcartCCed>m>mi"

    const-string/jumbo v0, "oo  sbensasfr=CorpaCde mtdlRegeemsi>ckeeMdpes>na "

    const/4 v2, 0x4

    const-string/jumbo v0, "msgmi>oneekde=ldeoRsetesecersorC samCadpfM>n o  p"

    const-string v0, ">> sendCommReportMessage ack failed responseCode="

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x5

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x2

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-void
.end method

.method public b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    const-string/jumbo v0, "sFgCoonaeaemsptr iedeodMSelas Menegs ouR@mesn"

    const-string v0, "@seaeRugnoFaoeasepM s isCdnertmeMnSme d@oselg"

    const/4 v2, 0x7

    const-string/jumbo v0, "nFde bsesloe@eseoepsdoR ea tmMCrgaMSanmiedsn@"

    const-string v0, "@@ sendCommReportMessage onMessageSendFailed "

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    const-string p1, ","

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x3

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string p2, "aBadvhuSuoncrseaeptrsicdHlr"

    const-string p2, "dHncrvsplushBacoeaSieadrert"

    const/4 v2, 0x0

    const-string p2, "PushServiceBroadcastHandler"

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x0

    return-void
.end method
