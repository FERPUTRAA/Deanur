.class Lcom/tencent/android/tpush/service/a$6;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/service/c/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a;->c(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:I

.field final synthetic f:Lcom/tencent/android/tpush/service/a;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$6;->f:Lcom/tencent/android/tpush/service/a;

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-wide p2, p0, Lcom/tencent/android/tpush/service/a$6;->a:J

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p4, p0, Lcom/tencent/android/tpush/service/a$6;->b:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p5, p0, Lcom/tencent/android/tpush/service/a$6;->c:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput-object p6, p0, Lcom/tencent/android/tpush/service/a$6;->d:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput p7, p0, Lcom/tencent/android/tpush/service/a$6;->e:I

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "rus  io b~m@ ~S~o~ tt@ @@o~/~ ~@@@@l~ ~~~n~~~i~.s@bf~  @@ b~ @@@fi~v~l @doo@@co@4M ~a ~@ @~/K1 -"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x3

    const-string/jumbo p2, "scsmecdsvelrarSPaHhroBuidea"

    const-string p2, "hesvBdasencelasrirHPoSdrauc"

    const/4 v8, 0x0

    const-string/jumbo p2, "rertoasslnevdrHcdohaiaSuPeB"

    const-string p2, "PushServiceBroadcastHandler"

    const/4 v8, 0x2

    if-nez p1, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x5

    sget-boolean p3, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v8, 0x7

    const/4 v7, 0x3

    if-eqz p3, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string v0, "dnumI dec n roc[ >=Acacat>H"

    const/4 v8, 0x2

    const-string v0, " lcntbude=cInrd H [ >a>Aocc"

    const-string v0, ">> AccountHandler [accId = "

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x7

    iget-wide v0, p0, Lcom/tencent/android/tpush/service/a$6;->a:J

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-virtual {p3, v0, v1}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string v0, " eekNpuaago,cm"

    const-string v0, "gaapoe, Nkmce "

    const/4 v8, 0x0

    const-string v0, "ge ,mkepa: Npa"

    const-string v0, ", packageNme: "

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$6;->b:Ljava/lang/String;

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-string v0, "]"

    const-string v0, "]"

    const/4 v8, 0x2

    const-string v0, "]"

    const-string v0, "]"

    const/4 v8, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-static {p2, p3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$6;->f:Lcom/tencent/android/tpush/service/a;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$6;->c:Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$6;->d:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x2

    iget v4, p0, Lcom/tencent/android/tpush/service/a$6;->e:I

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    iget-object v5, p0, Lcom/tencent/android/tpush/service/a$6;->b:Ljava/lang/String;

    const/4 v7, 0x2

    shr-int/2addr v8, v7

    move v1, p1

    const/4 v8, 0x0

    move v1, p1

    move v1, p1

    const/4 v8, 0x0

    const/4 v7, 0x2

    invoke-static/range {v0 .. v5}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x1

    goto :goto_0

    :cond_1
    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x7

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    const-string/jumbo v0, "l erbcaoq>Ais = nenCf>taolda re oukdeHc ns"

    const-string v0, " Ca=fbnelckoHi crd as sp u eedta>erlno>nAo"

    const/4 v8, 0x6

    const-string/jumbo v0, "n>sds clHueArnp ceal>t Cif=ca  rdooneoks e"

    const-string v0, ">> AccountHandler ack fail responseCode = "

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {p2, p3}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$6;->f:Lcom/tencent/android/tpush/service/a;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string/jumbo v2, "uf7m65u///941udf/67uu6e1u9/59/8/cu/f550f468/udu06a/0uu03b/1u/852d5d592ue"

    const-string v2, "68f1//uba/09156uuue/u/124u5/46u39f04/5/uefd0dd58f76u55/82u759uu0/6d9cu//"

    const/4 v8, 0x6

    const-string v2, "4b6uo08d96u5fdueuu2/uua6/e8fu/5u35fu6/05d7u05//9/d/99f/446/181u2/c85701/"

    const-string/jumbo v2, "\u670d\u52a1\u5668\u5904\u7406\u5931\u8d25\uff0c\u8fd4\u56de\u9519\u8bef"

    const/4 v8, 0x5

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$6;->c:Ljava/lang/String;

    const/4 v8, 0x3

    const/4 v7, 0x0

    iget-object v4, p0, Lcom/tencent/android/tpush/service/a$6;->d:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x5

    iget v5, p0, Lcom/tencent/android/tpush/service/a$6;->e:I

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x0

    iget-object v6, p0, Lcom/tencent/android/tpush/service/a$6;->b:Ljava/lang/String;

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    move v1, p1

    move v1, p1

    move v1, p1

    move v1, p1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static/range {v0 .. v6}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    :goto_0
    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    return-void
.end method

.method public b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    or-int/2addr v9, v8

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const-string v0, "aeelMbSec@gndA n@sapnt sriuH aenodelFcd"

    const-string v0, "acAnadepsnre :lMldusteHaF ocn@eid@Sn eg"

    const-string v0, "cerge unAMd Soocneeis@tn@d:eaalnldaFH s"

    const-string v0, "@@ AccountHandler onMessageSendFailed: "

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x3

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x4

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    xor-int/2addr v9, v8

    const-string v0, ", "

    const-string v0, ", "

    const/4 v9, 0x0

    const-string v0, ", "

    const-string v0, ", "

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-string v0, "dccldPrpqstarenreSaBaiHuvho"

    const-string v0, "avarerBaqotdnuHslPdcecihrSs"

    const/4 v9, 0x4

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {v0, p3}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    and-int/2addr v9, v8

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$6;->f:Lcom/tencent/android/tpush/service/a;

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget-object v4, p0, Lcom/tencent/android/tpush/service/a$6;->c:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x1

    iget-object v5, p0, Lcom/tencent/android/tpush/service/a$6;->d:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    iget v6, p0, Lcom/tencent/android/tpush/service/a$6;->e:I

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x5

    iget-object v7, p0, Lcom/tencent/android/tpush/service/a$6;->b:Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x6

    move v2, p1

    move v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static/range {v1 .. v7}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    const/4 v8, 0x4

    move v9, v8

    return-void
.end method
