.class public Lcom/tencent/android/tpush/service/b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/service/b$a;
    }
.end annotation


# static fields
.field private static a:Landroid/content/Context; = null

.field private static b:Ljava/lang/String; = ""

.field private static c:Landroid/net/LocalServerSocket;

.field private static d:Landroid/net/LocalServerSocket;

.field private static volatile e:Z

.field private static volatile f:Z

.field private static volatile g:Z

.field private static h:Z

.field private static i:Landroid/content/ServiceConnection;


# instance fields
.field private j:Landroid/os/Handler;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/common/AppInfos;->getCurrentPackageName(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    sput-object v0, Lcom/tencent/android/tpush/service/b;->b:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/android/tpush/service/b$1;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/b;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public static a(Landroid/content/Context;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~si@o1~~lii@l~S~~-o@K~v@@~~u@  ~s~ cm~/db~@t     ~@~@f tn  o@~@@r@ /b4 @oba@@~~ @~M@of@o.~ ~y ~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    const-string v0, "i.emeamn.n.goeedvcdca..tvnescipoiilxtraoktn"

    const-string/jumbo v0, "ptsnenc..omkvaeooiiertcadtipaeginlvd.cn.xe."

    const/4 v4, 0x2

    const-string v0, ".vpaotixaeno.deaielnrn.m.cig.nootpedkvct.ie"

    const-string v0, "com.tencent.android.xg.vip.action.keepalive"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x2

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {p0, v0, v1, v2}, Lcom/tencent/android/tpush/service/b;->a(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;J)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-string/jumbo v0, "pklm.bepmdieverdxincaeoicvcgtioe.oa.ta..tnn"

    const-string/jumbo v0, "mrgmniivtto.itk.eeivo.ednxac.cpedncao.ealp."

    const/4 v2, 0x4

    const-string v0, "ea.ilvurc.pnetamdtctpkxion..eiogi.dnneca.vo"

    const-string v0, "com.tencent.android.xg.vip.action.keepalive"

    const/4 v2, 0x1

    invoke-static {p0, v0, p1, p2}, Lcom/tencent/android/tpush/service/b;->a(Landroid/content/Context;Ljava/lang/String;J)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;J)V
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    const-string/jumbo v0, "luonrrippciddocionfSiV,eb xe.taStrsle  egsvttyuo af"

    const-string/jumbo v0, "tev.oynuocodrinioetiSxtSfaegrectpabfVdsi l,rul  i s"

    const/4 v8, 0x6

    const-string v0, "axyuo.itq uines ie,riaveoSrdeofbfp.V  tlditctgnsScl"

    const-string/jumbo v0, "startService failed, libxgVipSecurity.so not found."

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    const-class v1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v8, 0x0

    const-class v1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string v3, ":rsb crSavtietast,eoc"

    const-string v3, ": aerbert,tvocistiacS"

    const/4 v8, 0x1

    const-string v3, "icrmainsaSctrvtto ,:e"

    const-string/jumbo v3, "startService, action:"

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    const-string/jumbo v3, "y u,o:ed"

    const-string v3, "e :,ydua"

    const-string v3, "eal, bdy"

    const-string v3, ", delay:"

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v7, 0x7

    invoke-virtual {v2, p2, p3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    shl-int/2addr v8, v7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    const-string/jumbo v3, "ueaarvusMSihrpncee"

    const-string/jumbo v3, "vrMeniSpheucaragse"

    const/4 v8, 0x7

    const-string v3, "PushServiceManager"

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    const/4 v7, 0x5

    const-string/jumbo v2, "qtrvcsapsreuyies__r_e"

    const-string v2, "_eracrs_qve_erybusist"

    const/4 v8, 0x1

    const-string/jumbo v2, "ieysb_rrqe_evtuascst_"

    const-string/jumbo v2, "start_service_by_user"

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x1

    const/4 v4, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x2

    invoke-static {p0, v2, v4}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getBoolean(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x4

    if-nez v2, :cond_0

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x2

    const-string p0, "eSsrrsbg,t se rcelt yiasrlsiau erheeivslP eonadrubves h"

    const-string/jumbo p0, "srsseiP esrhree inl aSelsb  ,reiblseoautv reuydghavtcrc"

    const/4 v8, 0x3

    const-string/jumbo p0, "senm ssrtevateriegcSa,hbluybh eeuevst s rPlrola  rciidr"

    const-string/jumbo p0, "startService abolish, registerPush never called by user"

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    return-void

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/XGPushConfig;->isUsedTpnsChannel(Landroid/content/Context;)Z

    move-result v2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-nez v2, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string p0, "ae iolelheusntirt r,vTec sopn cessc naeSoavthsr nb"

    const-string/jumbo p0, "startService abolish, not use Tpns channel service"

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x6

    return-void

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x7

    if-eqz p0, :cond_5

    const/4 v7, 0x2

    const/4 v8, 0x3

    const/4 v2, 0x0

    :try_start_0
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    new-instance v4, Landroid/content/Intent;

    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-direct {v4}, Landroid/content/Intent;-><init>()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v4, p0, v1}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    const/4 v8, 0x2

    invoke-virtual {v4, p1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v8, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x6

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x6

    cmp-long p1, p2, v5

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x1

    if-eqz p1, :cond_2

    const/4 v7, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    const-string p1, "aee_mbtidm"

    const-string p1, "_etmdmelia"

    const/4 v8, 0x0

    const-string/jumbo p1, "ld_teeuiya"

    const-string p1, "delay_time"

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x2

    invoke-virtual {v4, p1, p2, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    :cond_2
    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result p1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    if-gtz p1, :cond_3

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-virtual {p0, v4}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    const/4 v8, 0x4

    sget-boolean p1, Lcom/tencent/android/tpush/service/b;->h:Z

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    if-nez p1, :cond_5

    const/4 v8, 0x2

    const/4 v7, 0x6

    new-instance p1, Lcom/tencent/android/tpush/service/b$1;

    const/4 v8, 0x1

    invoke-direct {p1}, Lcom/tencent/android/tpush/service/b$1;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x3

    sput-object p1, Lcom/tencent/android/tpush/service/b;->i:Landroid/content/ServiceConnection;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 p2, 0x3

    const/4 p2, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p0, v4, p1, p2}, Landroid/content/Context;->bindService(Landroid/content/Intent;Landroid/content/ServiceConnection;I)Z

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string/jumbo p2, "vbnedi picoSe:re"

    const-string/jumbo p2, "ieieotSd:nbc erv"

    const/4 v8, 0x5

    const-string p2, "Srvc:i rqetdineb"

    const-string p2, "bindService ret:"

    const/4 v8, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    sget-boolean p2, Lcom/tencent/android/tpush/service/b;->h:Z

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    goto/16 :goto_2

    :cond_3
    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x2

    invoke-virtual {p0, v4}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x6

    goto/16 :goto_2

    :catchall_0
    move-exception p1

    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    move-object v2, v4

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x4

    goto :goto_0

    :catchall_1
    move-exception p1

    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    shr-int/2addr v8, v7

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x4

    const-string p3, ",lsaicnt iSveeet nebrdrf:tst"

    const-string/jumbo p3, "sn,fSbnee  vticea:ltiatredtr"

    const/4 v8, 0x1

    const-string/jumbo p3, "stfm viicaeetS,n rdiearetlnt"

    const-string/jumbo p3, "startService failed, intent:"

    const/4 v7, 0x5

    move v8, v7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x5

    invoke-virtual {p2, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    const-string/jumbo p3, "ux:eo"

    const-string p3, ",uex:"

    const/4 v8, 0x2

    const-string p3, "b,x :"

    const-string p3, ", ex:"

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_2
    const/4 v8, 0x0

    const/4 v7, 0x4

    new-instance p1, Landroid/content/Intent;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-direct {p1}, Landroid/content/Intent;-><init>()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_3

    :try_start_3
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {p1, p0, v1}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;)I

    move-result p2

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x6

    if-gtz p2, :cond_4

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p0, p1}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;

    const/4 v8, 0x7

    const/4 v7, 0x7

    goto :goto_2

    :cond_4
    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    invoke-virtual {p0, p1}, Landroid/content/Context;->stopService(Landroid/content/Intent;)Z
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    goto :goto_2

    :catchall_2
    move-exception p0

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    move-object v2, p1

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto :goto_1

    :catchall_3
    move-exception p0

    :goto_1
    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x3

    const-string p2, "2etp2eu,vr etdtrtlf2isSeanni ac:"

    const-string p2, "eer2ritp:t,aeif2n ets tdcSnaliv2"

    const/4 v8, 0x7

    const-string/jumbo p2, "t  sd:rpa cnf,tttriSee222aeelivi"

    const-string p2, "222 startService failed, intent:"

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v7, 0x0

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x2

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    :goto_2
    return-void
.end method

.method public static a()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    sget-boolean v0, Lcom/tencent/android/tpush/service/b;->h:Z

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    return v0
.end method

.method static synthetic a(Z)Z
    .locals 2

    const/4 v1, 0x2

    sput-boolean p0, Lcom/tencent/android/tpush/service/b;->h:Z

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    return p0
.end method

.method public static b()Lcom/tencent/android/tpush/service/b;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/service/b$a;->a:Lcom/tencent/android/tpush/service/b;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public static b(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x3

    if-eqz p0, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x7

    sput-object p0, Lcom/tencent/android/tpush/service/b;->a:Landroid/content/Context;

    const/4 v1, 0x6

    const/4 v0, 0x0

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/TGlobalHelper;->setContext(Landroid/content/Context;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x5

    sput-object p0, Lcom/tencent/android/tpush/service/b;->b:Ljava/lang/String;

    :cond_0
    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic b(Z)Z
    .locals 2

    const/4 v1, 0x4

    sput-boolean p0, Lcom/tencent/android/tpush/service/b;->e:Z

    const/4 v0, 0x3

    move v1, v0

    return p0
.end method

.method public static e()Landroid/content/Context;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/service/b;->a:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    return-object v0

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->getContext()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object v0
.end method

.method public static f()Landroid/content/ServiceConnection;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/service/b;->i:Landroid/content/ServiceConnection;

    const/4 v2, 0x5

    return-object v0
.end method

.method public static g()V
    .locals 3

    const/4 v1, 0x7

    move v2, v1

    const/4 v0, 0x0

    or-int/2addr v2, v0

    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    sput-object v0, Lcom/tencent/android/tpush/service/b;->i:Landroid/content/ServiceConnection;

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method public static h()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/android/tpush/service/b;->b:Ljava/lang/String;

    const/4 v2, 0x4

    return-object v0
.end method

.method static synthetic i()Landroid/content/Context;
    .locals 3

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/service/b;->a:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object v0
.end method

.method static synthetic j()Z
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    sget-boolean v0, Lcom/tencent/android/tpush/service/b;->e:Z

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return v0
.end method

.method private k()V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    new-instance v0, Lcom/tencent/android/tpush/service/b$2;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0, p0, v1}, Lcom/tencent/android/tpush/service/b$2;-><init>(Lcom/tencent/android/tpush/service/b;Landroid/os/Looper;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v3, 0x5

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Intent;)V
    .locals 11

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x4

    if-nez v0, :cond_0

    const/4 v10, 0x4

    const/4 v9, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/b;->k()V

    :cond_0
    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x1

    monitor-enter p0

    :try_start_0
    const/4 v9, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    sget-boolean v0, Lcom/tencent/android/tpush/service/b;->e:Z

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    const-wide/16 v1, 0x64

    const-wide/16 v1, 0x64

    const/4 v10, 0x2

    const-wide/16 v1, 0x64

    const-wide/16 v1, 0x64

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x5

    const/4 v3, 0x1

    const/4 v9, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    if-eqz v0, :cond_5

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x0

    if-eqz p1, :cond_3

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-virtual {p1}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-string/jumbo v3, "sencMaegqeqirrSauh"

    const-string v3, "eaMScguhqrenairePs"

    const/4 v10, 0x4

    const-string/jumbo v3, "sesanSPguiMearehrc"

    const-string v3, "PushServiceManager"

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x6

    new-instance v4, Ljava/lang/StringBuilder;

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x3

    const/4 v9, 0x4

    const-string/jumbo v5, "itnmia tweso c hrSSiarcett"

    const-string/jumbo v5, "vosrta hceStriaiS itncet w"

    const/4 v10, 0x6

    const-string v5, "S  cociihareivtornt eS wat"

    const-string v5, "Start Service with action "

    const/4 v10, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-static {v3, v4}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    or-int/2addr v10, v9

    if-eqz v0, :cond_4

    const/4 v10, 0x4

    const-string/jumbo v3, "iod.cbnnvco.cpatixdaemitoepiak..gevntlre.em"

    const-string v3, "iacmniv.oraeop...lenm.eticcdigottk.apvedenx"

    const/4 v10, 0x0

    const-string v3, "eeecn.u.taienddetangc.ak..mxpovipcooi.trvnl"

    const-string v3, "com.tencent.android.xg.vip.action.keepalive"

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {v3, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x1

    if-eqz v3, :cond_2

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x7

    const/4 v3, 0x2

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x1

    invoke-virtual {v0, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object v0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x0

    const-string v4, "d_eaomtpey"

    const-string/jumbo v4, "tmeeoiayd_"

    const-string/jumbo v4, "madl_eieqt"

    const-string v4, "delay_time"

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v10, 0x4

    const-wide/16 v5, 0x0

    const/4 v10, 0x7

    const/4 v9, 0x7

    invoke-virtual {p1, v4, v5, v6}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v7

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x3

    cmp-long p1, v7, v5

    const/4 v9, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x3

    if-nez p1, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p1, v3}, Landroid/os/Handler;->removeMessages(I)V

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {p1, v0, v1, v2}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    goto/16 :goto_0

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v9, 0x6

    invoke-virtual {p1, v3}, Landroid/os/Handler;->removeMessages(I)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x3

    invoke-virtual {p1, v0, v7, v8}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x6

    goto :goto_0

    :cond_2
    const/4 v10, 0x2

    const/4 v9, 0x7

    const-string p1, ".os.eabctonpieivdntrm.tpnedactont.gsnxocco.c_n"

    const-string/jumbo p1, "nncicbetp.agaxtcdto..tn.m.seccvne.dorotonoin_p"

    const/4 v10, 0x3

    const-string p1, "_nemoc.idcer.o.innnncog.teopc.mvttadtoxacpnt.s"

    const-string p1, "com.tencent.android.xg.vip.action.stop_connect"

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p1

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x1

    if-eqz p1, :cond_4

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x0

    const/4 v0, 0x3

    const/4 v9, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x7

    invoke-virtual {p1, v0}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x0

    invoke-virtual {v3, v0}, Landroid/os/Handler;->removeMessages(I)V

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v0, p1, v1, v2}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x1

    goto :goto_0

    :cond_3
    const/4 v10, 0x3

    const/4 v9, 0x7

    const-string p1, "gruroivPuMahnsaeee"

    const-string/jumbo p1, "uagMaPueShrsrenive"

    const-string p1, "PushServiceManager"

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-string v0, "i   ube  ittvattbnc ialn l srtlSlcuSptnnn iuo twihtone"

    const-string v0, "hno ne pa ioilSttnwtnu  i trvsi tieucta  lulbnSect nlt"

    const/4 v10, 0x7

    const-string v0, "iS t tunlic tutnl ebhltn uSevs inltoi ctoa t r unwinae"

    const-string v0, "Start Service with null action  but intent is not null"

    const/4 v10, 0x2

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->v(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-virtual {p1, v3}, Landroid/os/Handler;->removeMessages(I)V

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x2

    const/4 v9, 0x2

    invoke-virtual {p1, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    invoke-virtual {v0, p1, v1, v2}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    :cond_4
    :goto_0
    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x3

    monitor-exit p0

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x4

    return-void

    :cond_5
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    monitor-exit p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x7

    const-string/jumbo p1, "neevrgrpeiqcMhaaSu"

    const-string/jumbo p1, "reSMauaPqenriechgv"

    const-string p1, "PushServiceManager"

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x0

    const-string v0, "emS A10dqHWslTmS aeTavtasiTC tsnR_tIr_eo l rtn sRAaErds0EnrceSVge"

    const-string v0, "ACs1mdsRaITeHWsnsoS larVrTrTEst StS  ae nvE reacgd0R mttl_ene_0iA"

    const/4 v10, 0x0

    const-string v0, "Aesm edCta T0AalrtIsr0 ntSS emdntirnr aEHsgTRoeSleV 1aHc_RWvT_s E"

    const-string/jumbo v0, "send WHAT_SERVICE_START msg at 100ms later on serviceStartHandler"

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x3

    invoke-virtual {p1, v3}, Landroid/os/Handler;->removeMessages(I)V

    const/4 v10, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p1, v3}, Landroid/os/Handler;->obtainMessage(I)Landroid/os/Message;

    move-result-object p1

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x1

    invoke-virtual {v0, p1, v1, v2}, Landroid/os/Handler;->sendMessageDelayed(Landroid/os/Message;J)Z

    const/4 v10, 0x3

    const/4 v9, 0x3

    return-void

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v10, 0x2

    const/4 v9, 0x4

    const/4 v10, 0x2

    monitor-exit p0
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    throw p1
.end method

.method public c()V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string v0, "eesmcSianveghMaPrr"

    const-string v0, "PushServiceManager"

    :try_start_0
    const/4 v5, 0x5

    const-string/jumbo v1, "meErovxtsi)@ic( "

    const-string/jumbo v1, "ivem@xs@t(r E)ci"

    const/4 v5, 0x2

    const-string v1, " iscebi)@txr(@Ev"

    const-string v1, "@@ serviceExit()"

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/common/j;->a()V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpush/service/b;->j:Landroid/os/Handler;

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getHandler()Landroid/os/Handler;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v1, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getHandler()Landroid/os/Handler;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Landroid/os/Handler;->removeCallbacksAndMessages(Ljava/lang/Object;)V

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/service/a;->a()Lcom/tencent/android/tpush/service/a;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    sget-object v3, Lcom/tencent/android/tpush/service/b;->a:Landroid/content/Context;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-virtual {v1, v3}, Lcom/tencent/android/tpush/service/a;->c(Landroid/content/Context;)V

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v1, v1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Lcom/tencent/android/tpush/c/a$a;->c(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p0}, Lcom/tencent/android/tpush/service/b;->d()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpush/service/util/g;->e(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const-string/jumbo v3, "vsit:ru peexxcetcueeEfoinor"

    const-string v3, "evrnoriet: eexeoccspxi uftE"

    const/4 v5, 0x0

    const-string/jumbo v3, "unexpected for serviceExit:"

    const/4 v5, 0x2

    const/4 v4, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-void
.end method

.method public d()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    monitor-enter p0

    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    sget-object v0, Lcom/tencent/android/tpush/service/b;->c:Landroid/net/LocalServerSocket;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    if-eqz v0, :cond_0

    :try_start_1
    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0}, Landroid/net/LocalServerSocket;->close()V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const/4 v0, 0x0

    const/4 v4, 0x2

    sput-object v0, Lcom/tencent/android/tpush/service/b;->c:Landroid/net/LocalServerSocket;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v3, 0x6

    move v4, v3

    goto :goto_0

    :catchall_0
    move-exception v0

    :try_start_2
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo v1, "nguPMbeparrveacsSi"

    const-string/jumbo v1, "vcirsbePguSeMaanrh"

    const/4 v4, 0x0

    const-string/jumbo v1, "urvghSsMqenicPaeea"

    const-string v1, "PushServiceManager"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v2, "olysksulen tDx  ceoetcrp>caoteo>i"

    const/4 v4, 0x5

    const-string/jumbo v2, "otsy>Dnpr oixle t ckals>sct oeeoc"

    const-string v2, ">> Destroy local socket exception"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    sput-boolean v0, Lcom/tencent/android/tpush/service/b;->e:Z

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    monitor-exit p0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void

    :catchall_1
    move-exception v0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    monitor-exit p0
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    throw v0
.end method
