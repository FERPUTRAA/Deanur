.class Lcom/tencent/android/tpush/service/a$7;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/service/c/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a;->d(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:I

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Lcom/tencent/android/tpush/service/a;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a;JILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$7;->f:Lcom/tencent/android/tpush/service/a;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x7

    iput-wide p2, p0, Lcom/tencent/android/tpush/service/a$7;->a:J

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x4

    iput p4, p0, Lcom/tencent/android/tpush/service/a$7;->b:I

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p5, p0, Lcom/tencent/android/tpush/service/a$7;->c:Ljava/lang/String;

    const/4 v1, 0x2

    iput-object p6, p0, Lcom/tencent/android/tpush/service/a$7;->d:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p7, p0, Lcom/tencent/android/tpush/service/a$7;->e:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v8, "@~sv~~ @d l~~4 1 ~rb~@ni@b~@i.  ~@-K~i f~t~@~Sbm~@@~ ~c oo@@ oa@@@ @@f~ o ~~oMo@~~l@u~ @@ /  /ty"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x1

    const-string p3, "aromnuSPhesdteasairrcdlecsB"

    const-string p3, "ensahdueSrliesPHdartBsccora"

    const/4 v9, 0x2

    const-string p3, "euvsoaerScadPdeaHrolhisrcBt"

    const-string p3, "PushServiceBroadcastHandler"

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-nez p1, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    const-string v1, "eat cbcas= eskeur t m csdiacbtu ctSs "

    const-string v1, " uamersSds cau cc e=t ectb sti ksta[c"

    const/4 v9, 0x4

    const-string v1, "caesbau  cecsekt s cid trau[cs S utt="

    const-string v1, "Set attributes ack success  [accId = "

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/a$7;->a:J

    const/4 v9, 0x1

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const-string/jumbo v1, "suioyTepapr t,et=tb"

    const-string/jumbo v1, "ta,roeTeput =tsb iy"

    const/4 v9, 0x5

    const-string v1, " ,attributesType = "

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    iget v1, p0, Lcom/tencent/android/tpush/service/a$7;->b:I

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-string/jumbo v1, "iumettNeq=aat brs ,"

    const-string/jumbo v1, "tteseb,ib uaNat= rm"

    const/4 v9, 0x3

    const-string v1, "atsNi t=ar etebm, u"

    const-string v1, " ,attributesName = "

    const/4 v8, 0x5

    move v9, v8

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$7;->c:Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    const-string v1, " kmm,=  Naeca"

    const-string v1, " ,packName = "

    const/4 v9, 0x5

    const/4 v8, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$7;->d:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const-string v1, "]"

    const-string v1, "]"

    const/4 v9, 0x5

    const-string v1, "]"

    const-string v1, "]"

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    move v9, v8

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-static {p3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$7;->f:Lcom/tencent/android/tpush/service/a;

    const/4 v8, 0x6

    const/4 v8, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$7;->c:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x1

    iget v4, p0, Lcom/tencent/android/tpush/service/a$7;->b:I

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    iget-object v5, p0, Lcom/tencent/android/tpush/service/a$7;->d:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget-object v6, p0, Lcom/tencent/android/tpush/service/a$7;->e:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    move v2, p1

    move v2, p1

    move v2, p1

    move v2, p1

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    move-object v7, p2

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static/range {v1 .. v7}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    goto/16 :goto_0

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const-string/jumbo v0, "nt sod=a eirto ae raehScbtiuwileeukpo fsst t C"

    const-string v0, "el ktsuoiadi sr=S eo cntaahCiwfs rteutp  ebtee"

    const/4 v9, 0x3

    const-string v0, "bSuk bCtodr al hfepe =nao tsie tsdrits teewcia"

    const-string v0, "Set attributes ack failed with responseCode = "

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const-string v0, "=ip,tbutsraa ee   tN"

    const-string/jumbo v0, "s atittpaem  N=,e br"

    const/4 v9, 0x2

    const-string/jumbo v0, "mb e tspte,atur iaN "

    const-string v0, " , attributesName = "

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$7;->c:Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-static {p3, p2}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$7;->f:Lcom/tencent/android/tpush/service/a;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string v2, "71u681f/qa/068q5fduu95//4496u5buu0u92410/d6uue858u5dud5fcu/30/9e5//7/6/2"

    const-string v2, "f0u/91a/q5565cf9u8e98d458u67/u58/9/3u16ue0/fb50uu0f/u/226d/d71u/du56/44u"

    const/4 v9, 0x6

    const-string v2, "/8s//421/0fd9d567uu4du48d169/f7f/e053/9550uu06uf/uu8a5c2u56buu68u5////e9"

    const-string/jumbo v2, "\u670d\u52a1\u5668\u5904\u7406\u5931\u8d25\uff0c\u8fd4\u56de\u9519\u8bef"

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/service/a$7;->c:Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget v4, p0, Lcom/tencent/android/tpush/service/a$7;->b:I

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    iget-object v5, p0, Lcom/tencent/android/tpush/service/a$7;->d:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    iget-object v6, p0, Lcom/tencent/android/tpush/service/a$7;->e:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    move v1, p1

    move v1, p1

    const/4 v9, 0x3

    move v1, p1

    move v1, p1

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static/range {v0 .. v6}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    return-void
.end method

.method public b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 10

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string v0, "aes:eSrr alogF@usM iadntte dtn@edeHsesnbli"

    const/4 v9, 0x4

    const-string v0, "dHlmae  r@ndtoSrtnFbna eaaedsilieuteegs:M@"

    const-string v0, "@@ attributesHandler onMessageSendFailed: "

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x4

    const-string v0, ", "

    const-string v0, ", "

    const/4 v9, 0x2

    const-string v0, ", "

    const-string v0, ", "

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v9, 0x3

    const/4 v8, 0x5

    const-string v0, "aieBoPrtrdvHoSunarlssaemcec"

    const-string v0, "asrmsuoehanPectirlracvHBSde"

    const/4 v9, 0x4

    const-string/jumbo v0, "lrstrbdeHcuaavirdcBPsaeoSnh"

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-static {v0, p3}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$7;->f:Lcom/tencent/android/tpush/service/a;

    const/4 v9, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpush/service/a$7;->c:Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget v5, p0, Lcom/tencent/android/tpush/service/a$7;->b:I

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x3

    iget-object v6, p0, Lcom/tencent/android/tpush/service/a$7;->d:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x4

    iget-object v7, p0, Lcom/tencent/android/tpush/service/a$7;->e:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x2

    move v2, p1

    move v2, p1

    const/4 v9, 0x4

    move v2, p1

    move v2, p1

    move-object v3, p2

    move-object v3, p2

    move-object v3, p2

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static/range {v1 .. v7}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    return-void
.end method
