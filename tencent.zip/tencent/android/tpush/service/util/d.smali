.class public Lcom/tencent/android/tpush/service/util/d;
.super Ljava/lang/Object;


# static fields
.field private static volatile a:Lcom/tencent/android/tpush/service/util/d;


# instance fields
.field private b:Landroid/content/Context;

.field private c:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private d:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/Long;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x5

    move v2, v0

    move v2, v0

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/service/util/d;->b:Landroid/content/Context;

    const/4 v3, 0x6

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    const/16 v1, 0xa

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/service/util/d;->c:Ljava/util/Map;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x0

    new-instance v0, Ljava/util/HashMap;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v0, v1}, Ljava/util/HashMap;-><init>(I)V

    const/4 v2, 0x3

    shr-int/2addr v3, v2

    iput-object v0, p0, Lcom/tencent/android/tpush/service/util/d;->d:Ljava/util/Map;

    const/4 v3, 0x3

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/service/util/d;->b:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object p1, p0, Lcom/tencent/android/tpush/service/util/d;->d:Ljava/util/Map;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x6

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x3

    const-string v1, ""

    const-string v1, ""

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-interface {p1, v0, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v3, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/tencent/android/tpush/service/util/d;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~mstub b4o@~y@ So@@  ~~ @oi  ~@@~i/lo~~b~@/i daf ~@ @ t@~rn@@  @. @ ~~@~l~~s@@ ~ K-fo@~@~cov1~M~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/service/util/d;->a:Lcom/tencent/android/tpush/service/util/d;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-class v0, Lcom/tencent/android/tpush/service/util/d;

    const-class v0, Lcom/tencent/android/tpush/service/util/d;

    const/4 v3, 0x6

    const-class v0, Lcom/tencent/android/tpush/service/util/d;

    const-class v0, Lcom/tencent/android/tpush/service/util/d;

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget-object v1, Lcom/tencent/android/tpush/service/util/d;->a:Lcom/tencent/android/tpush/service/util/d;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v1, Lcom/tencent/android/tpush/service/util/d;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/service/util/d;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    sput-object v1, Lcom/tencent/android/tpush/service/util/d;->a:Lcom/tencent/android/tpush/service/util/d;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x3

    monitor-exit v0

    const/4 v3, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x0

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x5

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    sget-object p0, Lcom/tencent/android/tpush/service/util/d;->a:Lcom/tencent/android/tpush/service/util/d;

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p0
.end method


# virtual methods
.method public a(J)Ljava/lang/String;
    .locals 8

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/service/util/d;->d:Ljava/util/Map;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-interface {v0, v1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eqz v0, :cond_0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/service/util/d;->d:Ljava/util/Map;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    check-cast p1, Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    return-object p1

    :cond_0
    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/service/util/d;->b:Landroid/content/Context;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/service/cache/CacheManager;->getRegisterInfos(Landroid/content/Context;)Ljava/util/List;

    move-result-object v0

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x7

    if-eqz v0, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x7

    if-eqz v1, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x4

    check-cast v1, Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpush/service/cache/CacheManager;->getRegisterInfoByPkgName(Ljava/lang/String;)Lcom/tencent/android/tpush/data/RegisterEntity;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v2, :cond_1

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/service/util/d;->d:Ljava/util/Map;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-wide v4, v2, Lcom/tencent/android/tpush/data/RegisterEntity;->accessId:J

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-static {v4, v5}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v2

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p0, v1}, Lcom/tencent/android/tpush/service/util/d;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-interface {v3, v2, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    goto :goto_0

    :cond_2
    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/service/util/d;->d:Ljava/util/Map;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v1

    const/4 v7, 0x3

    const/4 v6, 0x2

    invoke-interface {v0, v1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-nez v0, :cond_3

    const/4 v6, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v7, 0x1

    const-string p1, ""

    const-string p1, ""

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x7

    goto :goto_1

    :cond_3
    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/service/util/d;->d:Ljava/util/Map;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {p1, p2}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object p1

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    check-cast p1, Ljava/lang/String;

    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x4

    return-object p1
.end method

.method public a(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez p1, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-object v0

    :cond_0
    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/util/d;->c:Ljava/util/Map;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-interface {v1, p1}, Ljava/util/Map;->containsKey(Ljava/lang/Object;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/service/util/d;->c:Ljava/util/Map;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    check-cast p1, Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    return-object p1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/util/d;->b:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v1}, Lcom/tencent/tpns/dataacquisition/CustomDeviceInfos;->getAppPackages(Landroid/content/Context;)Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eqz v1, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_2
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v2, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    check-cast v2, Landroid/content/pm/PackageInfo;

    const/4 v5, 0x1

    iget-object v3, v2, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-eqz v3, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/service/util/d;->c:Ljava/util/Map;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget-object v1, v2, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {v0, p1, v1}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object p1, v2, Landroid/content/pm/PackageInfo;->versionName:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-object p1

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    return-object v0
.end method
