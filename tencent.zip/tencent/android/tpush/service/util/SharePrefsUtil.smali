.class public Lcom/tencent/android/tpush/service/util/SharePrefsUtil;
.super Ljava/lang/Object;


# static fields
.field public static final SHAREPRE_WATCH_PORT:Ljava/lang/String; = "tpush_watchdog_port"

.field static a:I = 0x64

.field private static b:Landroid/content/SharedPreferences;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x6

    return-void
.end method

.method private static a(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~~s~S~~o~~~1o.o@um @ b ~ vo~@@@d@/~ibn ~@r@-M~@ @ @aK@@t~@yl@@@ciff /~ ts@    @~b~ ~~  io~~~ o4l"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    sget-object v0, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->b:Landroid/content/SharedPreferences;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez v0, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo v0, "svsmerptsa.fephishur"

    const-string/jumbo v0, "upsee.rrs.thvshfisap"

    const/4 v3, 0x0

    const-string v0, "h.eaohresu.vpsptfsrp"

    const-string/jumbo v0, "tpush.vip.shareprefs"

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x3

    sput-object p0, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->b:Landroid/content/SharedPreferences;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object p0, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->b:Landroid/content/SharedPreferences;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    return-object p0
.end method

.method private static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/Util;->getKey(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-object p0
.end method

.method public static getBoolean(Landroid/content/Context;Ljava/lang/String;Z)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    :try_start_0
    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-object p0, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->b:Landroid/content/SharedPreferences;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences;->getBoolean(Ljava/lang/String;Z)Z

    move-result p2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-string p1, "UrPlsbSfaeeitr"

    const-string p1, "SharePrefsUtil"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x2

    const-string v0, "glmoeButen"

    const-string v0, "Begmoolten"

    const/4 v2, 0x3

    const-string v0, "Beenoatpog"

    const-string v0, "getBoolean"

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p1, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    return p2
.end method

.method public static getInt(Landroid/content/Context;Ljava/lang/String;I)I
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    sget-object p0, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->b:Landroid/content/SharedPreferences;

    const/4 v0, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x7

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences;->getInt(Ljava/lang/String;I)I

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x5

    return p0
.end method

.method public static getLong(Landroid/content/Context;Ljava/lang/String;J)J
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    sget-object p0, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->b:Landroid/content/SharedPreferences;

    const/4 v1, 0x7

    const/4 v0, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-interface {p0, p1, p2, p3}, Landroid/content/SharedPreferences;->getLong(Ljava/lang/String;J)J

    move-result-wide p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-wide p0
.end method

.method public static getSeqId(Landroid/content/Context;)I
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x1

    sget p0, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a:I

    const/4 v3, 0x3

    const/4 v0, 0x3

    const/4 v3, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    add-int/2addr p0, v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    sput p0, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a:I

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    const v1, 0x7fffffff

    const/4 v3, 0x2

    if-ne p0, v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x7

    sput v0, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a:I

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x6

    const-string/jumbo v0, "qqs I od"

    const-string v0, "d=qso  I"

    const/4 v3, 0x2

    const-string/jumbo v0, "qsse=I  "

    const-string/jumbo v0, "seqId = "

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    sget v0, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a:I

    const/4 v2, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-virtual {p0, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string v0, "PlrmseharftiUS"

    const-string v0, "SharePrefsUtil"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    sget p0, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a:I

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    return p0
.end method

.method public static getString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    const/4 v0, 0x7

    move v1, v0

    sget-object p0, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->b:Landroid/content/SharedPreferences;

    const/4 v1, 0x0

    const/4 v0, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x7

    const/4 v0, 0x7

    return-object p0
.end method

.method public static setBoolean(Landroid/content/Context;Ljava/lang/String;Z)V
    .locals 2

    :try_start_0
    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putBoolean(Ljava/lang/String;Z)Landroid/content/SharedPreferences$Editor;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x0

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x1

    const-string p1, "elhiPbUretrfsS"

    const/4 v1, 0x5

    const-string p1, "iSlPoehraeftUr"

    const-string p1, "SharePrefsUtil"

    const/4 v0, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x7

    const-string p2, ""

    const-string p2, ""

    const/4 v1, 0x7

    const-string p2, ""

    const-string p2, ""

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-static {p1, p2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method public static setInt(Landroid/content/Context;Ljava/lang/String;I)V
    .locals 2

    :try_start_0
    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putInt(Ljava/lang/String;I)Landroid/content/SharedPreferences$Editor;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x6

    const-string p1, "hlirUbeusStPfe"

    const-string p1, "ahefUruPsSeitl"

    const/4 v1, 0x1

    const-string p1, "fhaSUsuierPler"

    const-string p1, "SharePrefsUtil"

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    const-string p2, ""

    const-string p2, ""

    const/4 v1, 0x1

    const-string p2, ""

    const-string p2, ""

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-static {p1, p2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method

.method public static setLong(Landroid/content/Context;Ljava/lang/String;J)V
    .locals 2

    :try_start_0
    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-interface {p0, p1, p2, p3}, Landroid/content/SharedPreferences$Editor;->putLong(Ljava/lang/String;J)Landroid/content/SharedPreferences$Editor;

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x3

    const-string p1, "arSieshprUPtep"

    const-string/jumbo p1, "rtaSPhfpreiseU"

    const/4 v1, 0x3

    const-string/jumbo p1, "ilfeerSPqtUsha"

    const-string p1, "SharePrefsUtil"

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x2

    const-string p2, ""

    const-string p2, ""

    const/4 v1, 0x7

    const-string p2, ""

    const-string p2, ""

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-static {p1, p2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    :try_start_0
    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x1

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v0, 0x7

    move v1, v0

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x4

    const-string p1, "htseUrlPiqsSar"

    const-string/jumbo p1, "terPaslrqSiheU"

    const/4 v1, 0x6

    const-string/jumbo p1, "ltPmeriasreShU"

    const-string p1, "SharePrefsUtil"

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x6

    const-string p2, ""

    const-string p2, ""

    const/4 v1, 0x5

    const-string p2, ""

    const-string p2, ""

    const/4 v0, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p1, p2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v0, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x1

    return-void
.end method
