.class public Lcom/tencent/android/tpush/service/util/h;
.super Ljava/lang/Object;


# direct methods
.method public static a(Ljava/lang/String;)Z
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " lstd@~v@  @-o~@~Kb4@ni@~@S@~/ @@~o@@f~y ~t~ @/~@ m a~ ~~~c~@o~~~ ~ flu@ b~r@.M boo ~1  i@s@~i@ "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x6

    if-eqz p0, :cond_1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x2

    if-nez p0, :cond_0

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    const/4 p0, 0x0

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x0

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    const/4 p0, 0x1

    :goto_1
    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x4

    return p0
.end method
