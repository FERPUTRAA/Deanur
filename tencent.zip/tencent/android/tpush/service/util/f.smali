.class public Lcom/tencent/android/tpush/service/util/f;
.super Ljava/lang/Object;


# static fields
.field private static a:Landroid/content/SharedPreferences;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x2

    return-void
.end method

.method static declared-synchronized a(Landroid/content/Context;)Landroid/content/SharedPreferences;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~fsu@f @o~~m~ynb@r  @c @ ~ @@ ~~o~ o~@~i-1oi~ @o ov@ @S.tb~K~@@@@~/b@~4~~l   ~~~l@ d@@@M~ti s/~a"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    const-class v0, Lcom/tencent/android/tpush/service/util/f;

    const-class v0, Lcom/tencent/android/tpush/service/util/f;

    const/4 v4, 0x1

    const-class v0, Lcom/tencent/android/tpush/service/util/f;

    const-class v0, Lcom/tencent/android/tpush/service/util/f;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    monitor-enter v0

    :try_start_0
    const/4 v4, 0x0

    sget-object v1, Lcom/tencent/android/tpush/service/util/f;->a:Landroid/content/SharedPreferences;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-nez v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v1, "pvpmisv.r.etimx.lcn.s"

    const-string v1, ".tpns.vip.service.xml"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x3

    invoke-virtual {p0, v1, v2}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    sput-object p0, Lcom/tencent/android/tpush/service/util/f;->a:Landroid/content/SharedPreferences;

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    sget-object p0, Lcom/tencent/android/tpush/service/util/f;->a:Landroid/content/SharedPreferences;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    monitor-exit v0

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    monitor-exit v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    throw p0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/f;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x6

    invoke-interface {v0, p1}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object p2

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/f;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-object p0
.end method

.method private static a(Landroid/content/SharedPreferences$Editor;)V
    .locals 2
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "NewApi"
        }
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->apply()V

    const/4 v1, 0x5

    return-void
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/f;->a(Landroid/content/Context;)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-interface {p0, p1, p2}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/4 v1, 0x0

    const/4 v0, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/f;->a(Landroid/content/SharedPreferences$Editor;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x2

    return-void
.end method
