.class Lcom/tencent/android/tpush/service/util/b$3;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/util/b;->b(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~ s @i 4@~@ ~~@~lSoor~@~M@b@  @ ~@Ko~@@@.f -i1@@ys fo~t~o@ l~ ~  ~~biud~@o @ @v~~t/@n/ b@ ca~~~~"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x3

    const-string v0, "elimromeeCsvemprSoH"

    const-string v0, "ScsiromvelHemreepCo"

    const/4 v5, 0x4

    const-string/jumbo v0, "mCleoopmreoveSHneir"

    const-string v0, "CommonServiceHelper"

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/common/AppInfos;->getAppContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x4

    invoke-static {v1}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->disableShareBugly()Z

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x1

    const-string v1, "Bb myll igla etsbsgeiifuyu hInodnr|"

    const/4 v5, 0x5

    const-string v1, "dfyegbi| ogisnllBbluybr sta eiuhaI "

    const-string/jumbo v1, "initBuglyInfo | disable share bugly"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/common/AppInfos;->getAppContext()Landroid/content/Context;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    const-string v2, "fyoonsuldgukB"

    const-string/jumbo v2, "lBngokdfuyosI"

    const/4 v5, 0x0

    const-string/jumbo v2, "oySgsnkplIBuf"

    const-string v2, "BuglySdkInfos"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-virtual {v1, v2, v3}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object v1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-interface {v1}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v2, "ab1edd42q5"

    const-string v2, "1daedb5244"

    const/4 v5, 0x6

    const-string v2, "50s42a1dd4"

    const-string v2, "42510ae4dd"

    const/4 v4, 0x2

    or-int/2addr v5, v4

    const-string v3, "4.1.93u"

    const/4 v5, 0x5

    const-string v3, "1.4.3.9"

    const/4 v5, 0x6

    invoke-interface {v1, v2, v3}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/4 v5, 0x2

    const/4 v4, 0x7

    invoke-interface {v1}, Landroid/content/SharedPreferences$Editor;->apply()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x2

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v5, 0x7

    const/4 v4, 0x5

    const-string/jumbo v2, "lpBmi:tuonfin g"

    const-string v2, "Bot:gnnp uliify"

    const/4 v5, 0x3

    const-string/jumbo v2, "ylgfoIBno :iniu"

    const-string/jumbo v2, "initBuglyInfo :"

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v5, 0x2

    return-void
.end method
