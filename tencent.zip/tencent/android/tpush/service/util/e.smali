.class public Lcom/tencent/android/tpush/service/util/e;
.super Ljava/lang/Object;


# direct methods
.method public static a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~bs~olKs@@~@o~ ~b S@@~t-4@~fft@    u~1a ~ci ~@./y @~ o@mvb~iM~@~@d@~  ~@/@ o@~~o  i@l~n~~ @ro~@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/e;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpush/service/util/f;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    const-string/jumbo p1, "s5hmedvPsIifrnMPfreueS"

    const-string/jumbo p1, "v5sirehdsSIfMufPnPereo"

    const/4 v3, 0x4

    const-string p1, "fiPIoocSerenhu5fdeMrvs"

    const-string p1, "ServicePushInfoMd5Pref"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v1, "mnteibSgr"

    const-string/jumbo v1, "ttrmeinSg"

    const/4 v3, 0x7

    const-string/jumbo v1, "ngSttiueg"

    const-string v1, "getString"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p1, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object v0
.end method

.method private static a(Ljava/lang/String;)Ljava/lang/String;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-object p0
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z
    .locals 2

    :try_start_0
    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/e;->a(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/service/util/f;->b(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x5

    const/4 p0, 0x1

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return p0

    :catchall_0
    move-exception p0

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x3

    const-string p1, "P5IhosfpnPMueeSdfriver"

    const-string/jumbo p1, "oM5voefSisPIehnefrrduP"

    const/4 v1, 0x1

    const-string p1, "MirhsrecqefdvfSuPPIo5e"

    const-string p1, "ServicePushInfoMd5Pref"

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x2

    const-string/jumbo p2, "rtsbgSpit"

    const-string/jumbo p2, "tnpirbgSt"

    const/4 v1, 0x5

    const-string/jumbo p2, "putmrSgit"

    const-string/jumbo p2, "putString"

    const/4 v1, 0x0

    invoke-static {p1, p2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x0

    const/4 p0, 0x0

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x3

    return p0
.end method
