.class Lcom/tencent/android/tpush/service/util/g$2;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/util/g;->g(Landroid/content/Context;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/service/util/g$2;->a:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~@s~1@tl~f i~a ~of~~@@blm~b~ @o~ ~oo @@~-~ oi/ S@@ @  @@~ ~ @tbd cin~o ~M.@r ~~@@s ~@ @/K~u~@@4y"

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/service/util/g$2;->a:Landroid/content/Context;

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/service/util/g;->a(Landroid/content/Context;)Ljava/util/List;

    move-result-object v0

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x5

    const-string/jumbo v1, "leSmUetirvi"

    const-string v1, "eiseilrvtUS"

    const/4 v9, 0x4

    const-string/jumbo v1, "iievotcleUr"

    const-string v1, "ServiceUtil"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x1

    if-eqz v0, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    const/4 v2, 0x0

    :cond_0
    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-eqz v3, :cond_5

    const/4 v8, 0x0

    shr-int/2addr v9, v8

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    check-cast v3, Landroid/content/pm/ResolveInfo;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    add-int/lit8 v2, v2, 0x1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/common/j;->b()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string/jumbo v5, "popo"

    const-string/jumbo v5, "oppo"

    const/4 v9, 0x0

    const-string/jumbo v5, "opop"

    const-string/jumbo v5, "oppo"

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v5, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-eqz v4, :cond_1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    const/4 v4, 0x2

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-le v2, v4, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    return-void

    :cond_1
    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x6

    const/4 v4, 0x4

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-le v2, v4, :cond_2

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    return-void

    :cond_2
    const/4 v8, 0x4

    move v9, v8

    iget-object v3, v3, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    iget-object v3, v3, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x1

    iget-object v3, v3, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    const/4 v9, 0x1

    iget-object v4, p0, Lcom/tencent/android/tpush/service/util/g$2;->a:Landroid/content/Context;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {v4, v3}, Lcom/tencent/android/tpush/service/util/g;->e(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-eqz v4, :cond_3

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    goto :goto_0

    :cond_3
    const/4 v8, 0x6

    move v9, v8

    invoke-static {v3}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-nez v4, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x7

    iget-object v4, p0, Lcom/tencent/android/tpush/service/util/g$2;->a:Landroid/content/Context;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v4}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v4, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v9, 0x5

    if-nez v4, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v4, p0, Lcom/tencent/android/tpush/service/util/g$2;->a:Landroid/content/Context;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {v4, v3}, Lcom/tencent/android/tpush/service/util/g;->b(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-nez v4, :cond_0

    const/4 v8, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    iget-object v4, p0, Lcom/tencent/android/tpush/service/util/g$2;->a:Landroid/content/Context;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {v4, v3}, Lcom/tencent/android/tpush/service/util/g;->a(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v4

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-eqz v4, :cond_0

    :try_start_0
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string/jumbo v5, "tnm/nboetc"

    const-string/jumbo v5, "ocemt:nnt/"

    const/4 v9, 0x5

    const-string v5, ":e/nntucot"

    const-string v5, "content://"

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    const-string v5, "__P.o/XUSTGAIVHUH"

    const/4 v9, 0x5

    const-string v5, "/HUAPXIpU_VP_GH.S"

    const-string v5, ".XGVIP_PUSH_AUTH/"

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    sget-object v5, Lcom/tencent/android/tpush/TypeStr;->pullupxg:Lcom/tencent/android/tpush/TypeStr;

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v5}, Lcom/tencent/android/tpush/TypeStr;->getStr()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {v4}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-direct {v6}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const-string/jumbo v7, "uu,:v eoqg iNp mkebr paplpdrbl"

    const-string/jumbo v7, "peN pbi:bg pl  kou,edmralvp ru"

    const/4 v9, 0x3

    const-string v7, " pskN  :ad,mrgllppriepuybv ueo"

    const-string/jumbo v7, "pull up by provider, pkgName: "

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v6, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-string v3, ",i mur"

    const-string v3, ", uri:"

    invoke-virtual {v6, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x3

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {v1, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/service/util/g$2;->a:Landroid/content/Context;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-static {v3, v5}, Lcom/tencent/tpns/baseapi/crosssp/ProviderMessage;->getType(Landroid/content/Context;Landroid/net/Uri;)Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x6

    const-wide/16 v3, 0xc8

    const-wide/16 v3, 0xc8

    const/4 v9, 0x7

    const-wide/16 v3, 0xc8

    const-wide/16 v3, 0xc8

    const/4 v9, 0x5

    invoke-static {v3, v4}, Ljava/lang/Thread;->sleep(J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x1

    move v9, v8

    goto/16 :goto_0

    :catchall_0
    move-exception v3

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x1

    const-string/jumbo v5, "ppdbouirr rur l rlpu eovo"

    const-string v5, "  lbvouopr iurrpdypleurr "

    const/4 v9, 0x2

    const-string v5, "ede ubryrrpo plilrovrubp "

    const-string/jumbo v5, "pull up by provider error"

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-static {v1, v3}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    goto/16 :goto_0

    :cond_4
    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x0

    const-string/jumbo v0, "lluuu uinllrett nSopXevt ncecshpi w"

    const-string/jumbo v0, "luns tepirutu XSpnc eGnloe ivwlclht"

    const/4 v9, 0x1

    const-string/jumbo v0, "ncnu Xepwuroei lve hSlitGsln puctpt"

    const-string/jumbo v0, "pullupXGServices  with null content"

    const/4 v8, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x2

    return-void
.end method
