.class public Lcom/tencent/android/tpush/service/util/c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/service/util/c$a;
    }
.end annotation


# static fields
.field public static a:I = -0x1

.field private static volatile b:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method

.method private static a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~sb @@ybo ~@@@it M@cmr@@@o@@~ @blo~ /~ ~~o~  fu1 .v  ~~~o@i~~~~@~@@do~@n~~ @@~f-S ~slK 4/ta~ i "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x7

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/16 v1, 0x1a

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v2, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    if-lt v0, v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string/jumbo v1, "oiimoifncans"

    const-string v1, "fcsiontoanii"

    const/4 v4, 0x7

    const-string/jumbo v1, "notification"

    const/4 v4, 0x2

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    check-cast p0, Landroid/app/NotificationManager;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x5

    const/16 v1, 0x1c

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    if-lt v0, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-static {p0, p1}, Landroidx/core/app/r3;->a(Landroid/app/NotificationManager;Ljava/lang/String;)Landroid/app/NotificationChannelGroup;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    if-eqz p1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p1}, Landroidx/core/app/b1;->a(Landroid/app/NotificationChannelGroup;)Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v4, 0x1

    return v2

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x1

    invoke-static {p0, p2}, Landroidx/browser/trusted/f;->a(Landroid/app/NotificationManager;Ljava/lang/String;)Landroid/app/NotificationChannel;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    if-eqz p0, :cond_1

    const/4 v3, 0x3

    xor-int/2addr v4, v3

    invoke-static {p0}, Landroidx/browser/trusted/g;->a(Landroid/app/NotificationChannel;)I

    move-result p0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x2

    return p0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    return v2
.end method

.method private static a(Landroid/content/Context;Landroid/app/NotificationChannel;)Lcom/tencent/android/tpush/service/util/c$a;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/16 v1, 0x1a

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    if-lt v0, v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p1}, Landroidx/core/app/y;->a(Landroid/app/NotificationChannel;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p1}, Landroidx/core/app/w0;->a(Landroid/app/NotificationChannel;)Ljava/lang/CharSequence;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1}, Landroidx/core/app/w;->a(Landroid/app/NotificationChannel;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-static {p0, v0, p1}, Lcom/tencent/android/tpush/service/util/c;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)I

    move-result p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Lcom/tencent/android/tpush/service/util/c$a;

    invoke-interface {v1}, Ljava/lang/CharSequence;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    invoke-direct {v0, p0, p1, v1}, Lcom/tencent/android/tpush/service/util/c$a;-><init>(ILjava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x6

    return-object v0

    :cond_0
    const/4 p0, 0x0

    move v3, p0

    const/4 v2, 0x4

    const/4 v2, 0x1

    return-object p0
.end method

.method public static a(ILjava/util/List;)Ljava/lang/String;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(I",
            "Ljava/util/List<",
            "Lcom/tencent/android/tpush/service/util/c$a;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    const/16 v1, 0x1a

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string v2, ""

    const/4 v4, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    if-lt v0, v1, :cond_0

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/c;->a(Ljava/util/List;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    :goto_0
    const/4 v3, 0x0

    move v4, v3

    return-object p0
.end method

.method public static a(Landroid/content/Context;Landroid/net/Uri;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez p0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-object v0

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz p1, :cond_3

    :try_start_0
    const/4 v4, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v1, :cond_1

    const/4 v5, 0x3

    goto/16 :goto_0

    :cond_1
    const/4 v5, 0x5

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v2, 0x1a

    const/4 v5, 0x2

    const/4 v4, 0x7

    if-lt v1, v2, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const-string v1, "aoioonfitmtn"

    const-string/jumbo v1, "tnnmaioiitfo"

    const/4 v5, 0x5

    const-string/jumbo v1, "ttninbfooaci"

    const-string/jumbo v1, "notification"

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    check-cast p0, Landroid/app/NotificationManager;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {p0}, Landroidx/core/app/s3;->a(Landroid/app/NotificationManager;)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz p0, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x2

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x4

    if-lez v1, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_2
    const/4 v5, 0x7

    const/4 v4, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {v1}, Landroidx/core/app/e1;->a(Ljava/lang/Object;)Landroid/app/NotificationChannel;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v1}, Landroidx/core/app/a0;->a(Landroid/app/NotificationChannel;)Landroid/net/Uri;

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    if-eqz v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p1}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2}, Landroid/net/Uri;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v2, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {v1}, Landroidx/core/app/w;->a(Landroid/app/NotificationChannel;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_3
    :goto_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    return-object v0
.end method

.method private static a(Ljava/util/List;)Ljava/lang/String;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Ljava/util/List<",
            "Lcom/tencent/android/tpush/service/util/c$a;",
            ">;)",
            "Ljava/lang/String;"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x1

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-eqz p0, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    if-nez v1, :cond_0

    const/4 v4, 0x0

    move v5, v4

    goto :goto_1

    :cond_0
    :try_start_0
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-static {p0}, Ljava/util/Collections;->sort(Ljava/util/List;)V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    new-instance v1, Ljava/lang/StringBuffer;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-direct {v1}, Ljava/lang/StringBuffer;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x7

    const/4 v4, 0x7

    if-eqz v2, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x5

    check-cast v2, Lcom/tencent/android/tpush/service/util/c$a;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v3, v2, Lcom/tencent/android/tpush/service/util/c$a;->b:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    iget-object v3, v2, Lcom/tencent/android/tpush/service/util/c$a;->c:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/StringBuffer;->append(Ljava/lang/String;)Ljava/lang/StringBuffer;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget v2, v2, Lcom/tencent/android/tpush/service/util/c$a;->a:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuffer;->append(I)Ljava/lang/StringBuffer;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    goto :goto_0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuffer;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    return-object p0

    :catchall_0
    :cond_3
    :goto_1
    const/4 v5, 0x7

    const/4 v4, 0x1

    return-object v0
.end method

.method public static a(Landroid/content/Context;Z)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz p0, :cond_2

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x7

    invoke-static {p0, p1, v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result p1

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    if-nez p1, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    goto :goto_1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    new-instance p1, Lcom/tencent/android/tpush/service/util/c$1;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-direct {p1, p0}, Lcom/tencent/android/tpush/service/util/c$1;-><init>(Landroid/content/Context;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-static {}, Landroid/os/Looper;->myLooper()Landroid/os/Looper;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x3

    if-ne p0, v0, :cond_1

    const/4 v1, 0x3

    move v2, v1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0, p1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    goto :goto_0

    :cond_1
    const/4 v2, 0x3

    invoke-virtual {p1}, Lcom/tencent/tpns/baseapi/base/util/TTask;->run()V

    :goto_0
    const/4 v1, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x6

    return-void

    :cond_2
    :goto_1
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string v0, ":,noneupctaoa bsuxgrdt  koc"

    const-string/jumbo v0, "oauxoopsk,ta ne :nicdbtcg r"

    const/4 v2, 0x2

    const-string v0, " atnogipe:s crucpktpxd,noab"

    const-string v0, "app is background, context:"

    const/4 v2, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string p1, "cUisbotnqliiotaftN"

    const-string/jumbo p1, "lattsbioctnUiiofNi"

    const/4 v2, 0x7

    const-string/jumbo p1, "ttsctiNlsinoiaoiUs"

    const-string p1, "NotificationsUtils"

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p1, p0}, Lcom/tencent/tpns/baseapi/base/util/Logger;->w(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x4

    return-void
.end method

.method public static a(Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo v1, "tMem5tdatdUaauplp:SodsL"

    const-string v1, "eo5ptMu:aatSpLsalrdUtdd"

    const/4 v3, 0x6

    const-string/jumbo v1, "pdplosatuo:atUt5dLeSaMr"

    const-string/jumbo v1, "updateLastUploadMd5Str:"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x2

    sget-object v1, Lcom/tencent/android/tpush/service/util/c;->b:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string v1, "bsr,p"

    const-string/jumbo v1, "r:p,s"

    const-string/jumbo v1, "surt:"

    const-string v1, ",str:"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    const-string v1, "iUoitcfpNtniolaqss"

    const-string/jumbo v1, "lcoUNiisqnsaoiiftt"

    const/4 v3, 0x4

    const-string v1, "atfiUntiqNsicooits"

    const-string v1, "NotificationsUtils"

    const/4 v3, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const-string/jumbo v0, "wos easlrnms!,sa a inupr"

    const-string v0, "ags mws!ripoaarn u,nles "

    const/4 v3, 0x0

    const-string v0, "a pmnr ,sorluwaliesm n!g"

    const-string/jumbo v0, "params was null, ingore!"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x0

    sput-object p0, Lcom/tencent/android/tpush/service/util/c;->b:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    return-void
.end method

.method public static a(Landroid/content/Context;)Z
    .locals 13

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    const-string/jumbo v0, "mtaNoUltnsooictifi"

    const-string v0, "UilmiNnisocatfotit"

    const/4 v12, 0x2

    const-string/jumbo v0, "tlUiobnsoaifNcisit"

    const-string v0, "NotificationsUtils"

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x7

    const/4 v1, 0x1

    :try_start_0
    const/4 v12, 0x0

    const/4 v11, 0x3

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object v2

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-virtual {v2}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->disableCollData()Z

    move-result v2

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x6

    if-eqz v2, :cond_0

    const/4 v12, 0x7

    const/4 v11, 0x3

    const/4 v12, 0x0

    const-string/jumbo p0, "o iaefucnonoiiittasb"

    const-string p0, "aaiionif tiolobtnces"

    const/4 v12, 0x3

    const-string p0, "doo alipitasbnnetfii"

    const-string p0, "disable notification"

    const/4 v12, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x2

    return v1

    :cond_0
    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x2

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x3

    const/16 v3, 0x1a

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x6

    if-lt v2, v3, :cond_1

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x6

    const-string/jumbo v2, "nificaniqoto"

    const-string/jumbo v2, "notification"

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-virtual {p0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x3

    check-cast v2, Landroid/app/NotificationManager;

    const/4 v11, 0x4

    xor-int/2addr v12, v11

    if-eqz v2, :cond_1

    const/4 v12, 0x1

    const/4 v11, 0x2

    invoke-static {v2}, Landroidx/core/app/y3;->a(Landroid/app/NotificationManager;)Z

    move-result p0

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    const-string/jumbo v3, "tes6,ol dO= bE oaaf>in cNainsber2S"

    const-string v3, ">ifeab6i be2it  cNorSo =aEnnOalds,"

    const/4 v12, 0x3

    const-string v3, "etcmaf2n= Oi rao6Nsibt, e nodia>lS"

    const-string v3, "OS >= 26, areNotificationsEnabled "

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v11, 0x0

    xor-int/2addr v12, v11

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-static {v0, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x1

    return p0

    :cond_1
    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    const-string/jumbo v2, "usopoa"

    const-string/jumbo v2, "uopasp"

    const/4 v12, 0x2

    const-string v2, "apppob"

    const-string v2, "appops"

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {p0, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x7

    check-cast v2, Landroid/app/AppOpsManager;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v3

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    iget v3, v3, Landroid/content/pm/ApplicationInfo;->uid:I

    const-class v4, Landroid/app/AppOpsManager;

    const-class v4, Landroid/app/AppOpsManager;

    const/4 v12, 0x3

    const-class v4, Landroid/app/AppOpsManager;

    const-class v4, Landroid/app/AppOpsManager;

    const/4 v12, 0x1

    invoke-virtual {v4}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x6

    const/4 v11, 0x7

    invoke-static {v4}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v4

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x4

    const-string/jumbo v5, "orkcOoucTNheph"

    const-string v5, "hrchNpcpekTooO"

    const/4 v12, 0x3

    const-string v5, "copOrchpkwhoTN"

    const-string v5, "checkOpNoThrow"

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x1

    const/4 v6, 0x3

    const/4 v12, 0x7

    new-array v7, v6, [Ljava/lang/Class;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x6

    sget-object v8, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x2

    const/4 v9, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x4

    aput-object v8, v7, v9

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    aput-object v8, v7, v1

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x0

    const-class v8, Ljava/lang/String;

    const-class v8, Ljava/lang/String;

    const/4 v12, 0x6

    const-class v8, Ljava/lang/String;

    const-class v8, Ljava/lang/String;

    const/4 v12, 0x6

    const/4 v10, 0x2

    move v11, v10

    move v11, v10

    const/4 v12, 0x5

    aput-object v8, v7, v10

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x1

    invoke-virtual {v4, v5, v7}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v5

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x3

    const-string v7, "__FOITOPqTINOCITAPSN"

    const-string v7, "OP_POST_NOTIFICATION"

    const/4 v11, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-virtual {v4, v7}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x7

    const-class v7, Ljava/lang/Integer;

    const-class v7, Ljava/lang/Integer;

    const/4 v12, 0x0

    const-class v7, Ljava/lang/Integer;

    const-class v7, Ljava/lang/Integer;

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x1

    invoke-virtual {v4, v7}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v4

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x5

    check-cast v4, Ljava/lang/Integer;

    const/4 v11, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {v4}, Ljava/lang/Integer;->intValue()I

    move-result v4

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x3

    new-array v6, v6, [Ljava/lang/Object;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x4

    invoke-static {v4}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v4

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x6

    aput-object v4, v6, v9

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x7

    invoke-static {v3}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v3

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x7

    aput-object v3, v6, v1

    const/4 v12, 0x1

    aput-object p0, v6, v10

    const/4 v12, 0x6

    const/4 v11, 0x7

    invoke-virtual {v5, v2, v6}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x0

    check-cast p0, Ljava/lang/Integer;

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x0

    if-nez p0, :cond_2

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x3

    goto :goto_0

    :cond_2
    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    move v1, v9

    move v1, v9

    const/4 v12, 0x0

    move v1, v9

    :goto_0
    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x3

    return v1

    :catchall_0
    move-exception p0

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x0

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x3

    return v1
.end method

.method static synthetic a(Landroid/content/Context;ILjava/util/List;)Z
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x6

    invoke-static {p0, p1, p2}, Lcom/tencent/android/tpush/service/util/c;->b(Landroid/content/Context;ILjava/util/List;)Z

    move-result p0

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x3

    return p0
.end method

.method public static b(Landroid/content/Context;)I
    .locals 13

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x5

    const-string/jumbo v0, "tostniUciislaNosit"

    const-string v0, "NotificationsUtils"

    :try_start_0
    const/4 v11, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x4

    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v12, 0x5

    const/16 v2, 0x1a

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x3

    const/4 v3, 0x2

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x5

    const/4 v4, 0x1

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    if-lt v1, v2, :cond_1

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x2

    const-string/jumbo v1, "nnfmiioacoti"

    const-string/jumbo v1, "oinonciiqtfa"

    const/4 v12, 0x6

    const-string/jumbo v1, "ncofoitition"

    const-string/jumbo v1, "notification"

    const/4 v11, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v12, 0x7

    const/4 v11, 0x0

    check-cast v1, Landroid/app/NotificationManager;

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x1

    if-eqz v1, :cond_1

    const/4 v12, 0x4

    invoke-static {v1}, Landroidx/core/app/y3;->a(Landroid/app/NotificationManager;)Z

    move-result p0

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x6

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x7

    const-string v2, ">cE ib2a l6rede=t  fSosNainisbo,nO"

    const-string v2, "Snstioa26 blsicirEO,=ad e eafnNo> "

    const/4 v12, 0x0

    const-string v2, "i alnNu2Eo>ra=nbt, doaseteif S6 iO"

    const-string v2, "OS >= 26, areNotificationsEnabled "

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v12, 0x5

    const/4 v11, 0x0

    const/4 v12, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x4

    if-eqz p0, :cond_0

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    goto :goto_0

    :cond_0
    const/4 v12, 0x6

    const/4 v11, 0x2

    move v3, v4

    move v3, v4

    const/4 v12, 0x2

    move v3, v4

    move v3, v4

    :goto_0
    const/4 v12, 0x2

    const/4 v11, 0x6

    return v3

    :cond_1
    const/4 v12, 0x7

    const/4 v11, 0x0

    const-string v1, "apmopp"

    const-string v1, "aosmpp"

    const/4 v12, 0x7

    const-string/jumbo v1, "poqspa"

    const-string v1, "appops"

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x6

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v1

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x3

    check-cast v1, Landroid/app/AppOpsManager;

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationInfo()Landroid/content/pm/ApplicationInfo;

    move-result-object v2

    const/4 v12, 0x7

    const/4 v11, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p0

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x6

    iget v2, v2, Landroid/content/pm/ApplicationInfo;->uid:I

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x5

    const-class v5, Landroid/app/AppOpsManager;

    const-class v5, Landroid/app/AppOpsManager;

    const/4 v12, 0x3

    const-class v5, Landroid/app/AppOpsManager;

    const-class v5, Landroid/app/AppOpsManager;

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-static {v5}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;

    move-result-object v5

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x5

    const-string v6, "NoshkhocoeOpTr"

    const-string/jumbo v6, "orNeohwOcopThk"

    const/4 v12, 0x6

    const-string/jumbo v6, "wNTmrhOcecohpo"

    const-string v6, "checkOpNoThrow"

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x1

    const/4 v7, 0x3

    const/4 v12, 0x2

    const/4 v11, 0x6

    new-array v8, v7, [Ljava/lang/Class;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x6

    sget-object v9, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x0

    const/4 v10, 0x0

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x5

    aput-object v9, v8, v10

    const/4 v12, 0x5

    const/4 v11, 0x1

    const/4 v12, 0x0

    aput-object v9, v8, v4

    const/4 v11, 0x6

    move v12, v11

    const-class v9, Ljava/lang/String;

    const-class v9, Ljava/lang/String;

    const/4 v12, 0x0

    const-class v9, Ljava/lang/String;

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x5

    aput-object v9, v8, v3

    const/4 v12, 0x1

    invoke-virtual {v5, v6, v8}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v6

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x5

    const-string v8, "IPNIo_TOFOI_STTbANOC"

    const-string v8, "TFTCPbONINA_I_ITOOSP"

    const/4 v12, 0x3

    const-string v8, "N_IOSbIOIPNCOPTTFTAO"

    const-string v8, "OP_POST_NOTIFICATION"

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-virtual {v5, v8}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v5

    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x6

    const-class v8, Ljava/lang/Integer;

    const-class v8, Ljava/lang/Integer;

    const/4 v12, 0x1

    const-class v8, Ljava/lang/Integer;

    const-class v8, Ljava/lang/Integer;

    const/4 v12, 0x0

    invoke-virtual {v5, v8}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v5

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x3

    check-cast v5, Ljava/lang/Integer;

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x5

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x3

    new-instance v8, Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-direct {v8}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    const-string v9, "PK PDIu1OAO >_CF_OTITNT9uS =ONNS_ ,T"

    const-string v9, "O>O NAuPO IIKT_P,_D F91OI SNT_CN=STT"

    const/4 v12, 0x2

    const-string v9, "O   _,>p=NTPKDIN TIANT9O_O1PIIOSTFC_"

    const-string v9, "SDK_INT >= 19, OP_POST_NOTIFICATION "

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x5

    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v8

    const/4 v12, 0x1

    const/4 v11, 0x2

    invoke-static {v0, v8}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x5

    const/4 v11, 0x7

    new-array v7, v7, [Ljava/lang/Object;

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v5

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x6

    aput-object v5, v7, v10

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x5

    invoke-static {v2}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x7

    aput-object v2, v7, v4

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x4

    aput-object p0, v7, v3

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {v6, v1, v7}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x6

    check-cast p0, Ljava/lang/Integer;

    const/4 v11, 0x0

    move v12, v11

    invoke-virtual {p0}, Ljava/lang/Integer;->intValue()I

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x5

    const/4 v11, 0x3

    const/4 v12, 0x6

    if-nez p0, :cond_2

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x4

    goto :goto_1

    :cond_2
    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x3

    move v3, v4

    move v3, v4

    const/4 v12, 0x6

    move v3, v4

    :goto_1
    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x3

    return v3

    :catchall_0
    move-exception p0

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v11, 0x1

    and-int/2addr v12, v11

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x2

    const/4 p0, 0x4

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x4

    return p0
.end method

.method private static b(Landroid/content/Context;ILjava/util/List;)Z
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "I",
            "Ljava/util/List<",
            "Lcom/tencent/android/tpush/service/util/c$a;",
            ">;)Z"
        }
    .end annotation

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    const-string p0, "NistUtilqpnotioscf"

    const-string/jumbo p0, "sNiontiptUsifoclti"

    const/4 v4, 0x1

    const-string/jumbo p0, "lcsiiiaiUofNsosttn"

    const-string p0, "NotificationsUtils"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v0, 0x1

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    move v4, v3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo v2, "tNsmtSl:trq"

    const-string/jumbo v2, "tltst:aSqNr"

    const/4 v4, 0x3

    const-string v2, "SrfaosNtttl"

    const-string/jumbo v2, "lastNtfStr:"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    sget-object v2, Lcom/tencent/android/tpush/service/util/c;->b:Ljava/lang/String;

    const/4 v3, 0x6

    move v4, v3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x0

    move v4, v3

    invoke-static {p0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    sget-object v1, Lcom/tencent/android/tpush/service/util/c;->b:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v1, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    sget-object v1, Lcom/tencent/android/tpush/service/util/c;->b:Ljava/lang/String;

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/service/util/c;->a(ILjava/util/List;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string/jumbo v1, "rfcrtbu:rnetNs"

    const-string v1, "ctsre:rruStNnf"

    const/4 v4, 0x4

    const-string/jumbo v1, "unrSNcurtft:tr"

    const-string v1, "currentNtfStr:"

    const/4 v4, 0x1

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x5

    invoke-static {p0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    sget-object p0, Lcom/tencent/android/tpush/service/util/c;->b:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p0, p1}, Landroid/text/TextUtils;->equals(Ljava/lang/CharSequence;Ljava/lang/CharSequence;)Z

    move-result p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    xor-int/2addr p0, v0

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x0

    return p0

    :catchall_0
    :cond_1
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    return v0
.end method

.method public static c(Landroid/content/Context;)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Lcom/tencent/android/tpush/service/util/c$a;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x7

    const-string/jumbo v0, "iiaicfnpnomt"

    const-string v0, "conmainfiiot"

    const-string/jumbo v0, "notciitfqino"

    const-string/jumbo v0, "notification"

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-nez p0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    return-object v1

    :cond_0
    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-virtual {v2}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->disableCollData()Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v2, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string/jumbo p0, "iostaoiNsslttofinc"

    const-string/jumbo p0, "inUloftssNttoiciao"

    const/4 v5, 0x6

    const-string/jumbo p0, "istmciNlftaotsiniU"

    const-string p0, "NotificationsUtils"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string/jumbo v0, "iibtoasitdictlu obatsofeann"

    const-string/jumbo v0, "sina biidot eostubntftailca"

    const/4 v5, 0x3

    const-string v0, " busfboaaitnaiti itncteldss"

    const-string v0, "disable notification status"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    return-object v1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x0

    move v5, v4

    const/16 v3, 0x1a

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-lt v2, v3, :cond_6

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x4

    check-cast v2, Landroid/app/NotificationManager;

    const/4 v4, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz v2, :cond_2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v2}, Landroidx/core/app/y3;->a(Landroid/app/NotificationManager;)Z

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v2, 0x0

    move v5, v2

    :goto_0
    const/4 v4, 0x6

    const/4 v5, 0x3

    if-nez v2, :cond_3

    const/4 v5, 0x3

    return-object v1

    :cond_3
    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    check-cast v0, Landroid/app/NotificationManager;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-static {v0}, Landroidx/core/app/s3;->a(Landroid/app/NotificationManager;)Ljava/util/List;

    move-result-object v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eqz v0, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-interface {v0}, Ljava/util/List;->size()I

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-lez v2, :cond_6

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v2, Ljava/util/ArrayList;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_4
    :goto_1
    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-eqz v3, :cond_5

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {v3}, Landroidx/core/app/e1;->a(Ljava/lang/Object;)Landroid/app/NotificationChannel;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-static {p0, v3}, Lcom/tencent/android/tpush/service/util/c;->a(Landroid/content/Context;Landroid/app/NotificationChannel;)Lcom/tencent/android/tpush/service/util/c$a;

    move-result-object v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-eqz v3, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-interface {v2, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x0

    goto :goto_1

    :cond_5
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x1

    return-object v2

    :catchall_0
    :cond_6
    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    return-object v1
.end method
