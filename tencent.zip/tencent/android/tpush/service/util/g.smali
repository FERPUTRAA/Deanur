.class public Lcom/tencent/android/tpush/service/util/g;
.super Ljava/lang/Object;


# static fields
.field static a:Ljava/util/List; = null
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private static b:J = 0x0L

.field private static c:J = 0x0L

.field private static d:I = -0x1


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x7

    sput-object v0, Lcom/tencent/android/tpush/service/util/g;->a:Ljava/util/List;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-void
.end method

.method public static a(ILjava/lang/String;I)Landroid/content/Intent;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s-~i .tb@~ s @ ~~o@fy@@b@4 m1 ~@@ ~Sl~~ @ f~u@b~ @~M@oov  ~i@~r  /~Kdna@~@/~~ c @tio l~~~~o@o@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x2

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v1, "tDom.aCrne..EKnn.Ai.tdmFeocgxoccspia.tinBd"

    const-string/jumbo v1, "t.sniEoo..d.FCdmeacDt.ipKxEcrgAeoai.ntBnnc"

    const/4 v3, 0x2

    const-string v1, ".eKaor.Fcnot.gApennoddDxcBi.vnCEt.miaiE.ct"

    const-string v1, "com.tencent.android.xg.vip.action.FEEDBACK"

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {p1}, Ljava/lang/String;->length()I

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    if-eqz v1, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0, p1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string p1, "F.UBmbEESHKDTC"

    const-string p1, "ESFmUBD.KEHATC"

    const/4 v3, 0x7

    const-string p1, "CDFKSEuEUTBAPH"

    const-string p1, "TPUSH.FEEDBACK"

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    const-string p1, "C.ROPOHpEDTUSoR"

    const-string p1, ".CUHoRDTROOESEP"

    const/4 v3, 0x5

    const-string p1, "DTECOEORqRR.HUS"

    const-string p1, "TPUSH.ERRORCODE"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, p1, p0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x6

    return-object v0
.end method

.method public static a()Ljava/util/List;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    sget-object v0, Lcom/tencent/android/tpush/service/util/g;->a:Ljava/util/List;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-interface {v0}, Ljava/util/List;->isEmpty()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/service/util/g;->a:Ljava/util/List;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const-string/jumbo v1, "n.salpdompgbgc.ijoa.n"

    const-string v1, ".gdmlbmapoao.gjnpni.c"

    const/4 v3, 0x2

    const-string v1, "com.jingdong.app.mall"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/android/tpush/service/util/g;->a:Ljava/util/List;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x4

    const-string v1, "gcmm.efnieu.on2"

    const-string v1, "cnog.iue.enfs2m"

    const/4 v3, 0x4

    const-string v1, ".enwofi.2ncesmo"

    const-string v1, "com.ifeng.news2"

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-interface {v0, v1}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/service/util/g;->a:Ljava/util/List;

    const/4 v3, 0x7

    return-object v0
.end method

.method public static a(Landroid/content/Context;)Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            ")",
            "Ljava/util/List<",
            "Landroid/content/pm/ResolveInfo;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string v0, "aP libao-gpe nnAhposttocLupsI"

    const-string v0, "Psgpcs phnnt up-eAoliaoLfIaot"

    const/4 v5, 0x1

    const-string/jumbo v0, "oIacLoufpatnAphsin su-l gtPoc"

    const-string v0, "action - getLocalPushAppsInfo"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    const-string/jumbo v1, "trSqevlpcUe"

    const-string/jumbo v1, "lvetUeirqSc"

    const/4 v5, 0x3

    const-string/jumbo v1, "lictrveiqUS"

    const-string v1, "ServiceUtil"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz p0, :cond_1

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v5, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance p0, Ljava/util/ArrayList;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {p0}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    if-eqz v2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    check-cast v2, Landroid/content/pm/ResolveInfo;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x3

    iget-object v3, v2, Landroid/content/pm/ResolveInfo;->activityInfo:Landroid/content/pm/ActivityInfo;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v3, v3, Landroid/content/pm/ActivityInfo;->applicationInfo:Landroid/content/pm/ApplicationInfo;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v3, v3, Landroid/content/pm/ApplicationInfo;->packageName:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-interface {v0, v3, v2}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-instance p0, Ljava/util/ArrayList;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-interface {v0}, Ljava/util/Map;->values()Ljava/util/Collection;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-direct {p0, v0}, Ljava/util/ArrayList;-><init>(Ljava/util/Collection;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string v0, "fhssaspAugnPctIpoLlo"

    const/4 v5, 0x6

    const-string/jumbo v0, "sPsnheApLuagIfptocls"

    const-string v0, "getLocalPushAppsInfo"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v1, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v5, 0x0

    const/4 p0, 0x0

    const/4 v5, 0x4

    move v4, p0

    move v4, p0

    const/4 v5, 0x4

    return-object p0
.end method

.method public static a(Landroid/content/Context;Lorg/json/JSONObject;)V
    .locals 9

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-nez p1, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x0

    return-void

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x0

    const-string/jumbo v0, "nmae"

    const-string/jumbo v0, "mean"

    const/4 v8, 0x0

    const-string v0, "anem"

    const-string/jumbo v0, "name"

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string v1, ""

    const/4 v8, 0x6

    const-string v1, ""

    const-string v1, ""

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    if-eqz v2, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x6

    return-void

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/service/util/g;->g(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    if-eqz v2, :cond_2

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x5

    return-void

    :cond_2
    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/service/util/g;->f(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-eqz v2, :cond_3

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x0

    return-void

    :cond_3
    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v7, 0x5

    const/4 v8, 0x5

    const-string/jumbo v3, "utvmecNv-hejd A,nilraSoetomiN ieirmaSr pcBttrvcUdytrc:AieylpOPenOOp"

    const-string/jumbo v3, "oOomrrNed lyOj:JUrrtOirv nuvmpAc,iaAyvciSaheeep citeBtniS-tdNPlptce"

    const/4 v8, 0x3

    const-string/jumbo v3, "pOSuotmc aet trAolrpiovede,rcyOveapintNrvS:BUjtiriciJ lyoOe-NhPdeAc"

    const-string v3, "action - pullUpOtherServiceByProviderAndActivityJSONOject, proName:"

    const/4 v7, 0x7

    xor-int/2addr v8, v7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x6

    const/4 v7, 0x7

    const-string v3, "iSleUboierc"

    const-string/jumbo v3, "lriSoiteecU"

    const/4 v8, 0x2

    const-string v3, "elevituirSc"

    const-string v3, "ServiceUtil"

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x7

    const-string/jumbo v2, "tptebn"

    const-string/jumbo v2, "nntetb"

    const/4 v8, 0x6

    const-string/jumbo v2, "neqtin"

    const-string/jumbo v2, "intent"

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p1, v2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v4

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    const/high16 v5, 0x10000000

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x1

    if-nez v4, :cond_4

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x3

    const/4 v8, 0x3

    new-instance v4, Landroid/content/Intent;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-direct {v4, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v7, 0x2

    shr-int/2addr v8, v7

    invoke-virtual {p0, v4}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x0

    goto/16 :goto_0

    :catchall_0
    const/4 v7, 0x5

    const/4 v7, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    const-string/jumbo v5, "vxssi trtanu:cet  cturaticff i aoepetyrod"

    const-string/jumbo v5, "iouti uepreraaoyr tvca tts cceodiff:nxt t"

    const/4 v8, 0x0

    const-string/jumbo v5, "rfvmfeoituecp :anto t intoecacsxt rita dr"

    const-string/jumbo v5, "unexpected for start activity for action:"

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x4

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    goto/16 :goto_0

    :cond_4
    const/4 v8, 0x1

    const/4 v7, 0x0

    const-string/jumbo v2, "maceos"

    const-string v2, "epmcsa"

    const/4 v8, 0x6

    const-string v2, "hcaseb"

    const-string/jumbo v2, "schema"

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-virtual {p1, v2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v4

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x6

    if-nez v4, :cond_5

    :try_start_1
    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-instance v4, Landroid/content/Intent;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const-string/jumbo v6, "tqIWtauEa.tii.cnn.ndoodrei"

    const-string/jumbo v6, "nonVneiIqaEicttadWod..ir.t"

    const-string v6, "android.intent.action.VIEW"

    const/4 v8, 0x6

    const/4 v7, 0x3

    invoke-direct {v4, v6}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x5

    invoke-static {v2}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v6

    const/4 v8, 0x4

    const/4 v7, 0x3

    invoke-virtual {v4, v6}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    invoke-virtual {v4, v5}, Landroid/content/Intent;->setFlags(I)Landroid/content/Intent;

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-virtual {p0, v4}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    goto :goto_0

    :catchall_1
    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    const-string/jumbo v5, "trdmnvhposieac eftf crate ctxs sa oei:ptr"

    const-string/jumbo v5, "t:sds mcuo ieenfaoa trhfrrceetvtpisc x at"

    const/4 v8, 0x7

    const-string v5, "h peecniq admci ec:yrt fr xtoostvftateusa"

    const-string/jumbo v5, "unexpected for start activity for schema:"

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x3

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x1

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    :goto_0
    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x6

    const-string/jumbo v2, "rul"

    const-string/jumbo v2, "ulr"

    const/4 v8, 0x7

    const-string/jumbo v2, "rlu"

    const-string/jumbo v2, "url"

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {p1, v2, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v8, 0x4

    if-nez v1, :cond_6

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v1

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x0

    new-instance v2, Lcom/tencent/android/tpush/service/util/g$1;

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-direct {v2, p0, v0, p1}, Lcom/tencent/android/tpush/service/util/g$1;-><init>(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-wide/16 p0, 0x7d0

    const-wide/16 p0, 0x7d0

    const/4 v8, 0x1

    const-wide/16 p0, 0x7d0

    const-wide/16 p0, 0x7d0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    invoke-virtual {v1, v2, p0, p1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;J)Z

    :cond_6
    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x3

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 5

    const/4 v4, 0x3

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v1, 0x0

    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p0, p1, v1}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;

    move-result-object p0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x7

    new-instance p1, Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-direct {p1, p0, v2}, Landroid/content/Intent;-><init>(Landroid/content/Context;Ljava/lang/Class;)V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, p1, v1}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-eqz p0, :cond_2

    const/4 v3, 0x2

    move v4, v3

    invoke-interface {p0}, Ljava/util/List;->isEmpty()Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    if-eqz p1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-eqz p1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    check-cast p1, Landroid/content/pm/ResolveInfo;

    const/4 v4, 0x1

    iget-object p1, p1, Landroid/content/pm/ResolveInfo;->serviceInfo:Landroid/content/pm/ServiceInfo;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget-object p1, p1, Landroid/content/pm/ServiceInfo;->processName:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string/jumbo v0, "pvsi__rsvgxeec"

    const-string/jumbo v0, "xg_vip_service"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x5

    if-eqz p1, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 p0, 0x6

    const/4 p0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    return p0

    :cond_2
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    return v1

    :catchall_0
    move-exception p0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v0, "piemxNeemar cVmfuoXsnvef:ai oesCmrrGPdegNeccytinS4B"

    const-string v0, "gtamNseeoifscpNPim enyescienVCauXrrrSdxf:4emBe ocvG"

    const/4 v4, 0x5

    const-string v0, "dSinoisessrBrm Nemeicop4ogcXVefC:eeunNroxeyt afcvaG"

    const-string/jumbo v0, "unexpected for isXGServiceV4ProcssNameConfigByName:"

    const/4 v3, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo p1, "ortelbciSev"

    const-string/jumbo p1, "tSeeocilrvi"

    const/4 v4, 0x7

    const-string/jumbo p1, "tUilevuiceS"

    const-string p1, "ServiceUtil"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    return v1
.end method

.method public static a(Landroid/content/Intent;)Z
    .locals 14

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x7

    const-string/jumbo v0, "mni"

    const/4 v13, 0x2

    const-string/jumbo v0, "mni"

    const-string/jumbo v0, "min"

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x2

    const-string/jumbo v1, "ruoh"

    const-string/jumbo v1, "rouh"

    const-string v1, "hour"

    const-string v1, "hour"

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x6

    const-string v2, "citpacmptee"

    const-string v2, "accept_time"

    const/4 v13, 0x0

    const/4 v12, 0x7

    const-string v3, "iScteUbiqvr"

    const-string v3, "cirtebvUSil"

    const/4 v13, 0x7

    const-string v3, "ServiceUtil"

    const/4 v13, 0x1

    const/4 v4, 0x1

    const/4 v13, 0x2

    or-int/2addr v12, v4

    :try_start_0
    const/4 v13, 0x3

    const-string v5, "ecstotn"

    const-string v5, "ctnoetu"

    const/4 v13, 0x0

    const-string/jumbo v5, "notmenc"

    const-string v5, "content"

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x6

    invoke-virtual {p0, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x2

    const/4 v12, 0x1

    new-instance v5, Lorg/json/JSONObject;

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x3

    invoke-direct {v5, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x2

    const/4 v12, 0x2

    const/4 v13, 0x4

    invoke-virtual {v5, v2}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result p0

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x3

    if-eqz p0, :cond_0

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x6

    return v4

    :cond_0
    const/4 v13, 0x1

    const/4 v12, 0x2

    const/4 v13, 0x7

    invoke-virtual {v5, v2}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x1

    new-instance v2, Lorg/json/JSONArray;

    const/4 v13, 0x5

    const/4 v12, 0x3

    const/4 v13, 0x2

    invoke-direct {v2, p0}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    const/4 v12, 0x3

    move v13, v12

    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v5

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x7

    if-nez v5, :cond_1

    const/4 v13, 0x4

    const/4 v12, 0x7

    const/4 v13, 0x2

    return v4

    :cond_1
    const/4 v13, 0x4

    const/4 v12, 0x4

    const/4 v13, 0x5

    invoke-static {}, Ljava/util/Calendar;->getInstance()Ljava/util/Calendar;

    move-result-object v5

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x3

    const/16 v6, 0xb

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x0

    invoke-virtual {v5, v6}, Ljava/util/Calendar;->get(I)I

    move-result v6

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x5

    mul-int/lit8 v6, v6, 0x3c

    const/4 v12, 0x4

    or-int/2addr v13, v12

    const/16 v7, 0xc

    const/4 v13, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x6

    invoke-virtual {v5, v7}, Ljava/util/Calendar;->get(I)I

    move-result v5

    const/4 v13, 0x0

    const/4 v12, 0x6

    const/4 v13, 0x3

    add-int/2addr v6, v5

    const/4 v13, 0x0

    const/4 v12, 0x3

    const/4 v13, 0x0

    const/4 v5, 0x0

    const/4 v12, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x0

    move v7, v5

    move v7, v5

    const/4 v13, 0x0

    move v7, v5

    :goto_0
    const/4 v13, 0x1

    const/4 v12, 0x1

    const/4 v13, 0x1

    invoke-virtual {v2}, Lorg/json/JSONArray;->length()I

    move-result v8

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x1

    if-ge v7, v8, :cond_3

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x0

    new-instance v8, Lorg/json/JSONObject;

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x6

    invoke-virtual {v2, v7}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x1

    invoke-direct {v8, v9}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x7

    const/4 v12, 0x1

    new-instance v9, Lorg/json/JSONObject;

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x2

    const-string/jumbo v10, "tstpo"

    const-string/jumbo v10, "srptt"

    const/4 v13, 0x4

    const-string v10, "bttrs"

    const-string/jumbo v10, "start"

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x5

    invoke-virtual {v8, v10}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/4 v13, 0x1

    const/4 v12, 0x2

    invoke-direct {v9, v10}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x0

    invoke-virtual {v9, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const/4 v13, 0x1

    const/4 v12, 0x4

    const/4 v13, 0x0

    invoke-static {v10}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v10

    const/4 v13, 0x2

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-virtual {v10}, Ljava/lang/Integer;->intValue()I

    move-result v10

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x6

    mul-int/lit8 v10, v10, 0x3c

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x5

    invoke-virtual {v9, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x7

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v9

    const/4 v13, 0x3

    const/4 v12, 0x6

    const/4 v13, 0x1

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x0

    add-int/2addr v10, v9

    const/4 v13, 0x2

    const/4 v12, 0x7

    const/4 v13, 0x1

    new-instance v9, Lorg/json/JSONObject;

    const/4 v13, 0x3

    const/4 v12, 0x5

    const/4 v13, 0x5

    const-string/jumbo v11, "ned"

    const-string/jumbo v11, "ned"

    const/4 v13, 0x7

    const-string v11, "end"

    const-string v11, "end"

    const/4 v12, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x1

    invoke-virtual {v8, v11}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x3

    invoke-direct {v9, v8}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x6

    invoke-virtual {v9, v1}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x7

    invoke-static {v8}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v8

    const/4 v13, 0x1

    const/4 v12, 0x6

    const/4 v13, 0x4

    invoke-virtual {v8}, Ljava/lang/Integer;->intValue()I

    move-result v8

    const/4 v13, 0x0

    const/4 v12, 0x2

    const/4 v13, 0x1

    mul-int/lit8 v8, v8, 0x3c

    const/4 v13, 0x5

    const/4 v12, 0x6

    const/4 v13, 0x3

    invoke-virtual {v9, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x1

    invoke-static {v9}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v9

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x6

    invoke-virtual {v9}, Ljava/lang/Integer;->intValue()I

    move-result v9

    const/4 v13, 0x0

    const/4 v12, 0x0

    const/4 v13, 0x5

    add-int/2addr v8, v9

    const/4 v13, 0x5

    const/4 v12, 0x0

    const/4 v13, 0x3

    new-instance v9, Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x2

    invoke-direct {v9}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x2

    const/4 v12, 0x0

    const/4 v13, 0x4

    const-string v11, "cq m pu:>netecec,t ci hkrtcr>u"

    const-string v11, ":>hrieccqp tc tcecn,keuetm>r  "

    const/4 v13, 0x6

    const-string/jumbo v11, "rnciatupeep , >ceetr>t cc k:hm"

    const-string v11, ">> check accept time, current:"

    const/4 v13, 0x1

    const/4 v12, 0x7

    const/4 v13, 0x6

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v12, 0x5

    const/4 v13, 0x3

    invoke-virtual {v9, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v12, 0x7

    const/4 v13, 0x6

    const-string v11, "Tett,rimq:s "

    const-string v11, "etstr,Ts mi:"

    const/4 v13, 0x2

    const-string/jumbo v11, "t:s s,reTmai"

    const-string v11, ", startTime:"

    const/4 v12, 0x5

    move v13, v12

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x2

    invoke-virtual {v9, v10}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x1

    const-string v11, "em,mTn me:"

    const-string v11, "T, mei:emn"

    const/4 v13, 0x5

    const-string v11, "e:d,oein T"

    const-string v11, ", endTime:"

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x0

    invoke-virtual {v9, v11}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x3

    invoke-virtual {v9, v8}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x5

    const/4 v12, 0x7

    const/4 v13, 0x6

    invoke-virtual {v9}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v9

    const/4 v13, 0x7

    const/4 v12, 0x4

    const/4 v13, 0x1

    invoke-static {v3, v9}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v13, 0x4

    const/4 v12, 0x1

    const/4 v13, 0x7

    if-gt v10, v6, :cond_2

    const/4 v13, 0x2

    const/4 v12, 0x6

    const/4 v13, 0x1

    if-gt v6, v8, :cond_2

    const/4 v13, 0x6

    const/4 v12, 0x0

    const/4 v13, 0x5

    return v4

    :cond_2
    const/4 v12, 0x4

    move v13, v12

    add-int/lit8 v7, v7, 0x1

    const/4 v13, 0x3

    const/4 v12, 0x2

    const/4 v13, 0x0

    goto/16 :goto_0

    :cond_3
    const/4 v13, 0x1

    const/4 v12, 0x5

    const/4 v13, 0x6

    const-string v0, "bolsi"

    const-string/jumbo v0, "lUsio"

    const/4 v13, 0x5

    const-string/jumbo v0, "lusiU"

    const-string v0, "Utils"

    const/4 v13, 0x7

    const/4 v12, 0x6

    const/4 v13, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v13, 0x6

    const/4 v12, 0x2

    const/4 v13, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "ct emcrppain etttbd= sh  c cm ti eegtaoTemipu! eodc s dd"

    const-string v2, "esc!mbdta  iiaoeonc deup   eetchpcste=gimtrmedt T    ctd"

    const/4 v13, 0x4

    const-string v2, "cceoetceq rimd  =tdcdd a gtoepetm t!Ti hiu  use p entcas"

    const-string v2, " discurd the msg due to time not accepted! acceptTime = "

    const/4 v13, 0x0

    const/4 v12, 0x5

    const/4 v13, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x3

    const/4 v13, 0x1

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x2

    const/4 v12, 0x4

    const/4 v13, 0x6

    const-string/jumbo p0, "u,srm Tiuec "

    const-string p0, "  mT eu,uirc"

    const/4 v13, 0x1

    const-string p0, "i,=mrec Tu m"

    const-string p0, " , curTime= "

    const/4 v13, 0x7

    const/4 v12, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x1

    const/4 v12, 0x4

    invoke-virtual {v1, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v13, 0x3

    const/4 v12, 0x7

    const/4 v13, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x6

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v13, 0x3

    const/4 v12, 0x1

    const/4 v13, 0x2

    return v5

    :catchall_0
    move-exception p0

    const/4 v13, 0x4

    const/4 v12, 0x0

    const/4 v13, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const/4 v12, 0x4

    const/4 v13, 0x2

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v13, 0x1

    const/4 v12, 0x0

    const/4 v13, 0x6

    const-string v1, "cchpokcTicteeem "

    const-string/jumbo v1, "mcT icppeteekhcc"

    const/4 v13, 0x7

    const-string v1, "checkAcceptTime "

    const/4 v13, 0x4

    const/4 v12, 0x3

    const/4 v13, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v13, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x5

    const/4 v12, 0x2

    const/4 v13, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v13, 0x0

    const/4 v12, 0x4

    const/4 v13, 0x0

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x0

    const/4 v12, 0x1

    const/4 v13, 0x0

    return v4
.end method

.method public static a(Ljava/lang/String;)Z
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/util/g;->a()Ljava/util/List;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-interface {v0, p0}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p0
.end method

.method public static b(Landroid/content/Intent;)J
    .locals 10

    const/4 v8, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    const-string/jumbo v0, "t_mctbaeeip"

    const-string v0, "accept_time"

    :try_start_0
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x6

    new-instance v1, Ljava/text/SimpleDateFormat;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string/jumbo v2, "yqdyyMuy"

    const-string/jumbo v2, "qydydyyM"

    const/4 v9, 0x2

    const-string v2, "MydydMyp"

    const-string/jumbo v2, "yyyyMMdd"

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {}, Ljava/util/Locale;->getDefault()Ljava/util/Locale;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-direct {v1, v2, v3}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;Ljava/util/Locale;)V

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    const-string v2, "deta"

    const-string v2, "aedt"

    const/4 v9, 0x2

    const-string v2, "eadt"

    const-string v2, "date"

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {p0, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-eqz v3, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    new-instance v2, Ljava/util/Date;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-direct {v2}, Ljava/util/Date;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {v1, v2}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v2

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {v1, v2}, Ljava/text/DateFormat;->parse(Ljava/lang/String;)Ljava/util/Date;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {v1}, Ljava/util/Date;->getTime()J

    move-result-wide v1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string/jumbo v3, "oqesttn"

    const-string/jumbo v3, "ttsecon"

    const/4 v9, 0x1

    const-string/jumbo v3, "ntsoect"

    const-string v3, "content"

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {p0, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x3

    new-instance v3, Lorg/json/JSONObject;

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-direct {v3, p0}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->isNull(Ljava/lang/String;)Z

    move-result p0

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x4

    if-eqz p0, :cond_1

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    return-wide v1

    :cond_1
    const/4 v9, 0x5

    const/4 v8, 0x1

    invoke-virtual {v3, v0}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance v0, Lorg/json/JSONArray;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-direct {v0, p0}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x6

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v3

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-nez v3, :cond_2

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    return-wide v1

    :cond_2
    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v3, 0x0

    move v9, v3

    const/4 v8, 0x4

    shl-int/2addr v9, v8

    move v4, v3

    move v4, v3

    const/4 v9, 0x0

    move v4, v3

    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x2

    if-ge v3, v5, :cond_5

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    new-instance v5, Lorg/json/JSONObject;

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v0, v3}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-direct {v5, v6}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x2

    new-instance v6, Lorg/json/JSONObject;

    const/4 v8, 0x2

    move v9, v8

    const-string/jumbo v7, "mtrmt"

    const-string/jumbo v7, "strmt"

    const/4 v9, 0x7

    const-string/jumbo v7, "tarto"

    const-string/jumbo v7, "start"

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {v5, v7}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    invoke-direct {v6, v5}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x3

    const-string v5, "hruo"

    const-string/jumbo v5, "ohur"

    const/4 v9, 0x3

    const-string v5, "hour"

    const-string v5, "hour"

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-virtual {v6, v5}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-static {v5}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v5

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {v5}, Ljava/lang/Integer;->intValue()I

    move-result v5

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    mul-int/lit8 v5, v5, 0x3c

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    const-string/jumbo v7, "imn"

    const-string/jumbo v7, "nim"

    const/4 v9, 0x6

    const-string/jumbo v7, "min"

    const-string/jumbo v7, "min"

    const/4 v9, 0x4

    invoke-virtual {v6, v7}, Lorg/json/JSONObject;->getString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static {v6}, Ljava/lang/Integer;->valueOf(Ljava/lang/String;)Ljava/lang/Integer;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-virtual {v6}, Ljava/lang/Integer;->intValue()I

    move-result v6

    const/4 v8, 0x1

    const/4 v9, 0x2

    add-int/2addr v5, v6

    const/4 v9, 0x7

    const/4 v8, 0x0

    if-lt v5, v4, :cond_3

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-nez v4, :cond_4

    :cond_3
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    move v4, v5

    move v4, v5

    const/4 v9, 0x6

    move v4, v5

    move v4, v5

    :cond_4
    const/4 v9, 0x5

    add-int/lit8 v3, v3, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    goto/16 :goto_0

    :cond_5
    const/4 v9, 0x0

    mul-int/lit8 v4, v4, 0x3c

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    int-to-long v3, v4

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const/4 v9, 0x5

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    mul-long/2addr v3, v5

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x1

    add-long/2addr v1, v3

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string/jumbo v0, "tslio"

    const/4 v9, 0x5

    const-string v0, "bUstl"

    const-string v0, "Utils"

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    const-string v4, "=icmtTuepac  btee"

    const-string/jumbo v4, "tcgTeb i=aecemt p"

    const/4 v9, 0x2

    const-string v4, "iagpt epceT=ce tm"

    const-string v4, "get acceptTime = "

    const/4 v8, 0x7

    or-int/2addr v9, v8

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const-string/jumbo p0, "nB  uaicqigetT, cpe="

    const-string p0, "cT,iBmu ctg=e epnia "

    const/4 v9, 0x4

    const-string p0, "icsnT=ctBm e geip e,"

    const-string p0, " , acceptBeginTime= "

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-virtual {v3, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x1

    move v9, v8

    invoke-virtual {v3, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x5

    return-wide v1

    :catchall_0
    move-exception p0

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string/jumbo v1, "tiecgTgpnBeeAce pmi"

    const/4 v9, 0x4

    const-string v1, "eptmTgmBcne iAicegt"

    const-string v1, "getAcceptBeginTime "

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    const-string/jumbo v0, "vUqSotcriee"

    const-string v0, "SitUicerqve"

    const/4 v9, 0x1

    const-string v0, "erliibvecUS"

    const-string v0, "ServiceUtil"

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v9, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x4

    return-wide v0
.end method

.method public static b(Landroid/content/Context;)V
    .locals 10

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    const-string v0, "/"

    const-string v0, "/"

    const-string v0, "/"

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x5

    const-string v1, " e:CgnuecoegdcxefsrSrrimslrloP vpp rUk"

    const-string/jumbo v1, "rxsPcrd v oeSre:rlrc skegpfiomeugCUpln"

    const/4 v9, 0x6

    const-string v1, "UrplSodpnCueegocecPi r rf gmxrrkvee:sp"

    const-string/jumbo v1, "pullUpServerConfigPkgs error exec cmd:"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string v2, "feSotl UqC-giniuPnp praskrglcoe"

    const-string v2, "action - pullUpServerConfigPkgs"

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string/jumbo v3, "rvsieeiStmU"

    const-string v3, "UvemeirSlti"

    const/4 v9, 0x2

    const-string/jumbo v3, "vltmiireSUc"

    const-string v3, "ServiceUtil"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/service/a/a;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/service/a/a;

    move-result-object v2

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    iget-object v2, v2, Lcom/tencent/android/tpush/service/a/a;->K:Ljava/util/Map;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-eqz v2, :cond_3

    const/4 v8, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-interface {v2}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v2

    const/4 v9, 0x2

    const/4 v8, 0x4

    invoke-interface {v2}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v4

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-eqz v4, :cond_4

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    check-cast v4, Ljava/util/Map$Entry;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v9, 0x2

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    check-cast v5, Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-static {p0, v5}, Lcom/tencent/android/tpush/service/util/g;->g(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x0

    if-eqz v5, :cond_0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    goto :goto_0

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x0

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const-string v6, "-iseoa  e voracttnr"

    const-string v6, " tsaorrt iac v-meen"

    const/4 v9, 0x0

    const-string v6, " sairbvtra -csmen e"

    const-string v6, "am startservice -n "

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    check-cast v6, Ljava/lang/String;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v6

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x1

    check-cast v6, Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v6

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-virtual {v6, v5}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object v6

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {v6}, Ljava/lang/Process;->waitFor()I

    move-result v7

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x5

    if-eqz v7, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x5

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    const-string/jumbo v6, "t- r be esaa--ivmuenc0tsr  r"

    const/4 v9, 0x6

    const-string/jumbo v6, "mv0stsu ae-rcnre -  s -ireta"

    const-string v6, "am startservice --user 0 -n "

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    invoke-interface {v4}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v6

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    check-cast v6, Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x5

    and-int/2addr v9, v8

    invoke-virtual {v5, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-interface {v4}, Ljava/util/Map$Entry;->getValue()Ljava/lang/Object;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    check-cast v4, Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string/jumbo v6, "r tseerpuasc:t"

    const-string/jumbo v6, "sva:rsuettcer "

    const/4 v9, 0x0

    const-string v6, "etrveir qs:acs"

    const-string/jumbo v6, "start service:"

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v4, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {v3, v4}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x5

    move v9, v8

    invoke-static {}, Ljava/lang/Runtime;->getRuntime()Ljava/lang/Runtime;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/Runtime;->exec(Ljava/lang/String;)Ljava/lang/Process;

    move-result-object v6

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-virtual {v6}, Ljava/lang/Process;->waitFor()I

    move-result v7

    :cond_1
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-nez v7, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x4

    goto/16 :goto_0

    :cond_2
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const-string v5, "dilx:atpue,"

    const/4 v9, 0x1

    const-string/jumbo v5, "udsa:xeiV,t"

    const-string v5, ",exitValud:"

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-virtual {v6}, Ljava/lang/Process;->exitValue()I

    move-result v5

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x2

    const/4 v8, 0x5

    invoke-static {v3, v4}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x5

    goto/16 :goto_0

    :catchall_0
    move-exception v4

    :try_start_2
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x7

    new-instance v5, Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-direct {v5}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x5

    move v9, v8

    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x3

    invoke-virtual {v5, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-static {v3, v4}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    goto/16 :goto_0

    :cond_3
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string/jumbo p0, "pqkmcsipgorpke gpuUf lulnvmogpPCe  pllrasaaeSu"

    const-string/jumbo p0, "r opucSvq peskg  msPuClpUugaakilnlpolfgneaperp"

    const/4 v9, 0x2

    const-string/jumbo p0, "kr aou  ipsnSaelfCUvpapr lPsupgkol clnueoepgpm"

    const-string/jumbo p0, "pullUpServerConfigPkgs no pull up packages map"

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {v3, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x6

    goto :goto_1

    :catchall_1
    move-exception p0

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v9, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {v3, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_4
    :goto_1
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    return-void
.end method

.method public static b(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 6

    const/4 v5, 0x4

    const-string v0, "SUseibvtire"

    const-string/jumbo v0, "tvsiriceUSe"

    const/4 v5, 0x2

    const-string v0, "ercteiuUSlv"

    const-string v0, "ServiceUtil"

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string/jumbo v1, "vitmtayp"

    const-string/jumbo v1, "taimvcyt"

    const/4 v5, 0x7

    const-string/jumbo v1, "qtcaviti"

    const-string v1, "activity"

    const/4 v5, 0x1

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x1

    const v1, 0x7fffffff

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p0, v1}, Landroid/app/ActivityManager;->getRunningServices(I)Ljava/util/List;

    move-result-object p0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    if-eqz p0, :cond_1

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-interface {p0}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x2

    if-lez v1, :cond_1

    const/4 v4, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-class v1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v5, 0x4

    const-class v1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v1, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v1}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x7

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-eqz v2, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x7

    check-cast v2, Landroid/app/ActivityManager$RunningServiceInfo;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x0

    iget v3, v2, Landroid/app/ActivityManager$RunningServiceInfo;->pid:I

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v3, :cond_0

    const/4 v4, 0x7

    move v5, v4

    iget-object v3, v2, Landroid/app/ActivityManager$RunningServiceInfo;->service:Landroid/content/ComponentName;

    const/4 v5, 0x3

    invoke-virtual {v3}, Landroid/content/ComponentName;->getClassName()Ljava/lang/String;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x1

    const/4 v4, 0x1

    if-eqz v3, :cond_0

    const/4 v5, 0x6

    const/4 v4, 0x1

    iget-object v2, v2, Landroid/app/ActivityManager$RunningServiceInfo;->service:Landroid/content/ComponentName;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v2}, Landroid/content/ComponentName;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v2}, Lcom/tencent/android/tpush/common/j;->c(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-eqz v3, :cond_0

    const/4 v4, 0x5

    move v5, v4

    invoke-virtual {v2, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v3, :cond_0

    const/4 v5, 0x0

    new-instance p0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    and-int/2addr v5, v4

    invoke-direct {p0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    const-string/jumbo p1, "issreiovkr sgvP: u"

    const-string/jumbo p1, "v:isovuvsre grkPi "

    const/4 v5, 0x1

    const-string/jumbo p1, "isSurvive srvPkg :"

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {p0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-virtual {p0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 p0, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x0

    return p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-string/jumbo p1, "nSemNynuRiecrhImginkbeeGvaBcPsXVkg"

    const-string p1, "BckIhbgeXsSVyc3eReennivgNPuanimGkr"

    const/4 v5, 0x3

    const-string p1, "BiguonXaehkIcSeniR3gGkcVyscPeNnvmr"

    const-string p1, "checkXGServiceV3IsRunningByPkgName"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {v0, p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    const/4 p0, 0x0

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    return p0
.end method

.method public static c(Landroid/content/Context;Ljava/lang/String;)Ljava/util/List;
    .locals 5
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(",
            "Landroid/content/Context;",
            "Ljava/lang/String;",
            ")",
            "Ljava/util/List<",
            "Landroid/content/pm/ResolveInfo;",
            ">;"
        }
    .end annotation

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo v0, "viutcbelrie"

    const-string/jumbo v0, "vrSileuitce"

    const/4 v4, 0x3

    const-string/jumbo v0, "teicSvulUri"

    const-string v0, "ServiceUtil"

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    const/4 v1, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-eqz p0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance v2, Landroid/content/Intent;

    const/4 v4, 0x5

    invoke-direct {v2, p1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    const/16 p1, 0x200

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {p0, v2, p1}, Landroid/content/pm/PackageManager;->queryIntentServices(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string/jumbo p1, "ocncoPipgLSlftsehrIeepvs"

    const-string p1, "cosefelpPSeovcstginrhaLI"

    const/4 v4, 0x3

    const-string/jumbo p1, "lcLSuchsqePgtonvrieIfaes"

    const-string p1, "getLocalPushServicesInfo"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v0, p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const-string p0, "eIssstonl t lcecoSci=hxPahvoLneqnuuge=t flr "

    const-string p0, "PthlLauxqthuonsnt= cr I=efotnlgcl ieoec evSs"

    const/4 v4, 0x5

    const-string p0, "cttmutn lsfoeve lhhaxluI=o=oPtn LcescigreeS "

    const-string p0, "getLocalPushServicesInfo the context == null"

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-object v1
.end method

.method public static c(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v0, "vretoSlUise"

    const-string/jumbo v0, "vtseelSiriU"

    const/4 v5, 0x7

    const-string v0, "ServiceUtil"

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v1}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getAppClsAlive()I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    const/4 v2, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-ne v1, v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string/jumbo p0, "urapsb  olpill eudpmu"

    const-string/jumbo p0, "lpamodb p euui lrspul"

    const/4 v5, 0x5

    const-string/jumbo p0, "lpadu ulbpuelig  uosr"

    const-string p0, "disable pull up group"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    return-void

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v1}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getPullupArrProviderAndActivity()Lorg/json/JSONArray;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-nez v2, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    goto :goto_1

    :cond_1
    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v1}, Lorg/json/JSONArray;->length()I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    if-ge v2, v3, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1, v2}, Lorg/json/JSONArray;->optJSONObject(I)Lorg/json/JSONObject;

    move-result-object v3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    invoke-static {p0, v3}, Lcom/tencent/android/tpush/service/util/g;->a(Landroid/content/Context;Lorg/json/JSONObject;)V

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    add-int/lit8 v2, v2, 0x1

    const/4 v5, 0x3

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x3

    const-string/jumbo p0, "yOgiiAcpuSpto PeBnrer olriorednrAcuviyeundnhtnivpv"

    const-string/jumbo p0, "veBSoervdcidrnug i ortllhiOvnPniiopnenAyprucuAetry"

    const/4 v5, 0x0

    const-string/jumbo p0, "vninvrgiqcei idAhoOrrneyrSu nneucPipdretvtutBpyAol"

    const-string/jumbo p0, "pullupOtherServiceByProviderAndActivity no running"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    goto :goto_2

    :catchall_0
    move-exception p0

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string/jumbo v2, "vtsybienBrdlterirpiPrSecOtlypvviAohucAe"

    const-string v2, "AvveybtAirlcrveuSrdretohnuctOpipiieBlPy"

    const/4 v5, 0x5

    const-string/jumbo v2, "leomPvnABildeOuedccyttrivhyitiprpAeSrrv"

    const-string/jumbo v2, "pullupOtherServiceByProviderAndActivity"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    :goto_2
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    return-void
.end method

.method public static d(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/f/a;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string/jumbo v1, "irlvouiSUtc"

    const-string/jumbo v1, "liUtveuirSc"

    const/4 v5, 0x6

    const-string v1, "ctlrSbevUii"

    const-string v1, "ServiceUtil"

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eqz v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    const-string p0, " isRopuepAsctS N,huyGepuu  Xvr eolPuSlr stn"

    const-string/jumbo p0, "uiplP  po,ou SNey uGrXutSessAhstlver  pcRhn"

    const/4 v5, 0x6

    const-string/jumbo p0, "tl uuc pheslneruoe, tipvsNr sR  oPSupSAhX G"

    const-string p0, "Run As SysPush, Not pull up other XGService"

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-void

    :cond_0
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->isServerDestroy(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v0, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string p0, "aedooesuq rrh s elr pNu vp ,epoytttlr"

    const-string/jumbo p0, "server destroy, Not pull up other app"

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    return-void

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/ChannelUtils;->isMiuiV12()Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    if-eqz v0, :cond_2

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    const-string p0, "IRsuS  eqin1 eop,e po ttArlN XucUuhrMlI 2 v"

    const/4 v5, 0x1

    const-string p0, " psehotNMe p2ruoXiItAUlR1 ve G lnu ,sSuIr c"

    const-string p0, "Run As MIUI 12, Not pull up other XGService"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-void

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->disablePullUp()Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eqz v0, :cond_3

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string p0, " G mudculocwvhlNtoeitXe i sSlruo phtep "

    const-string p0, "ScsGi re o tocXvuuilueleh  hNw lptpdot "

    const/4 v5, 0x6

    const-string/jumbo p0, "ooXpotcrGlucopil u l h wNdetur  etSvehi"

    const-string p0, " Not pull up other XGService with cloud"

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    return-void

    :cond_3
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/service/util/g;->a(Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    if-eqz v0, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string p0, "egi lbopr l mun"

    const-string p0, "giumepnr  ll po"

    const/4 v5, 0x0

    const-string p0, " prlguuen o ulp"

    const-string p0, " ignore pull up"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x3

    invoke-virtual {v0, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    return-void

    :cond_4
    const/4 v5, 0x3

    const/4 v4, 0x3

    const-string v0, "  nneorpp snigioiltpta"

    const-string/jumbo v0, "tgsnorpi il  nept noia"

    const/4 v5, 0x4

    const-string v0, " t oarinqnpnseop g ili"

    const-string/jumbo v0, "not in ignore app list"

    const/4 v5, 0x3

    const/4 v4, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string/jumbo v0, "ppsbo.lp.ur.upeta"

    const-string/jumbo v0, "rpp.ub.a.phptoeul"

    const/4 v5, 0x2

    const-string v0, "erpmt.p.l.pplohuu"

    const-string/jumbo v0, "pull.up.other.app"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-static {p0, v0, v2}, Lcom/tencent/tpns/baseapi/base/PushPreferences;->getBoolean(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    if-eqz v0, :cond_5

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string/jumbo v0, "puauoep fhlueuta  dltorlp"

    const-string v0, "f upuduplhe eluaottpa lr "

    const/4 v5, 0x3

    const-string/jumbo v0, "p pelbppuaoft ule uahrd t"

    const-string v0, "default pull up other app"

    const/4 v5, 0x5

    const/4 v4, 0x7

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/g;->g(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x2

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x3

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v3, "dpurreoprUeevlSBliiXpcGvP"

    const/4 v5, 0x1

    const-string v3, "SuUdriuoXlevGlBcPpieyvpre"

    const-string/jumbo v3, "pullUpXGServiceByProvider"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/g;->c(Landroid/content/Context;)V

    const/4 v4, 0x4

    move v5, v4

    invoke-static {p0}, Lcom/tencent/android/tpush/service/util/g;->b(Landroid/content/Context;)V

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    return-void

    :cond_5
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string p0, "dahp pip eorlq lustue bpa"

    const-string p0, "bi euouaqpr lhlptpspd a e"

    const/4 v5, 0x1

    const-string/jumbo p0, "perlptpaqeohpdisl  ulbau "

    const-string p0, "disable pull up other app"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    return-void
.end method

.method static synthetic d(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/service/util/g;->f(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v1, 0x6

    const/4 v0, 0x1

    return p0
.end method

.method public static e(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string/jumbo v0, "vcsUlrieeSt"

    const-string v0, "ServiceUtil"

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p0}, Lcom/tencent/android/tpush/stat/b/b;->d(Landroid/content/Context;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v2, "fiSmvs xec @Esaert"

    const-string v2, "ics@ iveSEarsx fte"

    const/4 v4, 0x6

    const-string v2, "eexeot vcEi@sirafS"

    const-string/jumbo v2, "serviceSafeExit @ "

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x0

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x6

    if-eqz p0, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v1, "c:vvsbri_ix_ege"

    const-string v1, "icem_:vr_xegsvi"

    const/4 v4, 0x2

    const-string/jumbo v1, "s_xrveuiep_gcv:"

    const-string v1, ":xg_vip_service"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {p0, v1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/XGVipPushService;->a()Landroid/app/Service;

    move-result-object p0

    const/4 v3, 0x1

    const/4 v3, 0x5

    invoke-virtual {p0}, Landroid/app/Service;->stopSelf()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x5

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const-string/jumbo v1, "tcereseppd vfeoarxcei EntSfeox"

    const-string/jumbo v1, "txieorspnedaf erxceeEei Sfcvot"

    const/4 v4, 0x1

    const-string/jumbo v1, "xfteEceSqxsrnearetfcove idipeu"

    const-string/jumbo v1, "unexpected for serviceSafeExit"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    return-void
.end method

.method static synthetic e(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/service/util/g;->g(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x6

    return p0
.end method

.method public static f(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string v0, "SistvilrbUe"

    const-string/jumbo v0, "irvlcbteiSU"

    const/4 v5, 0x4

    const-string/jumbo v0, "iiUmretcvle"

    const-string v0, "ServiceUtil"

    :try_start_0
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string v1, "ceacoruMPAmgarllnnnieg"

    const-string/jumbo v1, "nAalmnulcnraMPeariegcg"

    const/4 v5, 0x7

    const-string v1, "erAilbgnacnglnrPaMaema"

    const-string v1, "cancelPingAlarmManager"

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v4, 0x7

    new-instance v1, Landroid/content/Intent;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const-string v2, "ei.cd.unoIntacVtOnNopT_x.vmeDaiIE.AcrioKpSt_AEdnKEPgC."

    const-string/jumbo v2, "pE.E.nKprt.gEmitdIAn_SKoxO_tao.DeioecvcA.a.PcCTVNIndin"

    const/4 v5, 0x1

    const-string v2, "dovEAVrpaAe.CISi.LeKmndEEtn_DaonN.Op.Pc_oc.iTtIKcixtgn"

    const-string v2, "com.tencent.android.xg.vip.action.ACTION_SDK_KEEPALIVE"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x2

    const-string v2, "Psdsuo.hqnGodrnhrtevtaXqpem.eRcnii.eec.c"

    const-string v2, "ds.ptcheqeoPuReriXnnsrcdi.Ge.mttvaenco.h"

    const/4 v5, 0x5

    const-string v2, "Resci.hmndreuc.Xdseh.atntvreotuso.pcPeni"

    const-string v2, "com.tencent.android.tpush.XGPushReceiver"

    const/4 v4, 0x6

    move v5, v4

    invoke-virtual {v1, p0, v2}, Landroid/content/Intent;->setClassName(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {v1, v2}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/16 v3, 0x1f

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-lt v2, v3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x0

    const/high16 v2, 0xa000000

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const/4 v5, 0x0

    const/high16 v2, 0x8000000

    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {p0, v3, v1, v2}, Landroid/app/PendingIntent;->getBroadcast(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/TPushAlarmManager;->getAlarmManager(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/TPushAlarmManager;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p0, v1}, Lcom/tencent/tpns/baseapi/base/TPushAlarmManager;->cancal(Landroid/app/PendingIntent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string v2, "argmierrAnesg:onaa mnrealPc cr"

    const-string/jumbo v2, "lrsrgaean rma eAicrMrgo:encnaP"

    const/4 v5, 0x7

    const-string/jumbo v2, "nPoro ergaAnliarmeM lean:crgcr"

    const-string v2, "cancelPingAlarmManager error: "

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x1

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    move v5, v4

    invoke-virtual {p0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v4, 0x2

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_1
    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    return-void
.end method

.method private static f(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    const/4 v0, 0x0

    const/4 v3, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string/jumbo v1, "itymacvt"

    const/4 v3, 0x1

    const-string/jumbo v1, "ivtiabtc"

    const-string v1, "activity"

    const/4 v3, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0, v1}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    move-result-object p0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x2

    check-cast p0, Landroid/app/ActivityManager;

    const/4 v3, 0x7

    const/4 v2, 0x5

    invoke-virtual {p0}, Landroid/app/ActivityManager;->getRunningAppProcesses()Ljava/util/List;

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x7

    invoke-interface {p0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object p0

    :cond_1
    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-interface {p0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x0

    if-eqz v1, :cond_2

    const/4 v2, 0x7

    shl-int/2addr v3, v2

    invoke-interface {p0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    check-cast v1, Landroid/app/ActivityManager$RunningAppProcessInfo;

    const/4 v3, 0x5

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    iget-object v1, v1, Landroid/app/ActivityManager$RunningAppProcessInfo;->processName:Ljava/lang/String;

    const/4 v3, 0x1

    if-eqz v1, :cond_1

    const/4 v2, 0x7

    move v3, v2

    invoke-virtual {v1, p1}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x1

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 p0, 0x1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    return p0

    :cond_2
    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x5

    return v0
.end method

.method private static g(Landroid/content/Context;)V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x2

    const-string/jumbo v0, "vceUreuiilo"

    const-string v0, "eirUovceliS"

    const/4 v5, 0x4

    const-string/jumbo v0, "rciUStvplei"

    const-string v0, "ServiceUtil"

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    const-string/jumbo v1, "v uytercqsie pS blr-noXeo iBceGPt o2drravnplai"

    const-string/jumbo v1, "nsoGtbripeorlrornveSeiUi d l ce2aX vcPB ap-yut"

    const/4 v5, 0x4

    const-string/jumbo v1, "nes asUriec rpieoX yctonultaredoviSPlvG-plrB  "

    const-string v1, "action - pullUpXGServiceByProvider on 2s later"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x1

    new-instance v1, Lcom/tencent/android/tpush/service/util/g$2;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/service/util/g$2;-><init>(Landroid/content/Context;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const-wide/16 v2, 0x7d0

    const-wide/16 v2, 0x7d0

    const/4 v5, 0x4

    const-wide/16 v2, 0x7d0

    const-wide/16 v2, 0x7d0

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2, v3}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;J)Z

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-void
.end method

.method private static g(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    return v1

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {p0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getPullupBlackList()Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x4

    return v1

    :cond_1
    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    move-result p0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    return p0
.end method
