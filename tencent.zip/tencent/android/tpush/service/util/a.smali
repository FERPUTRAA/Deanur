.class public Lcom/tencent/android/tpush/service/util/a;
.super Ljava/lang/Object;


# direct methods
.method public static a()Ljava/lang/String;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "@Ss~@@u@o4mt~r~~tK1~ f  @o/a ~/@~@@  @ iM@b  @ ~y~~lb-~o~ ~~~~~ @sv n@~@oli@~.~ of@@b@ @di~@co~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string v1, "ceimIfoDve"

    const-string v1, "DeviceInfo"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    if-eqz v0, :cond_1

    :try_start_0
    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->getBusinessDeviceId(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v2
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x3

    const/4 v4, 0x6

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string v3, "IrFaor>gdtyeyi>ilesttc nt"

    const-string v3, "eisFyyldcIaeten >tgi>rttr"

    const/4 v5, 0x3

    const-string v3, ">cleFbytI tiaegyttndreri>"

    const-string v3, ">>getFacilityIdentity err"

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-static {v1, v3, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    if-eqz v2, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-virtual {v2}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0}, Ljava/lang/String;->length()I

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-nez v0, :cond_2

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const-string v2, ""

    const/4 v5, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_1

    :cond_1
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string/jumbo v0, "mn>tiyu e a>=xne u(=ttIl>iti  cF>ytngdlclet"

    const-string v0, "cItmeFytlgi e  >c>lon=xa(ti>le tdnytin tu>="

    const-string v0, "=F)e>>npcuen t>(  e>ix y dIttay=ilogtltiltn"

    const-string v0, ">>> getFacilityIdentity() > context == null"

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_1
    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x4

    return-object v2
.end method
