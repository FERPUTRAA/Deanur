.class Lcom/tencent/android/tpush/service/util/c$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/util/c;->a(Landroid/content/Context;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/service/util/c$1;->a:Landroid/content/Context;

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "oas/o@1r~ lSbm @~~  ~/ l@@@@@ df~o@@~i@ ~ y~@4t~os~f@ K~i~@nv~o~- @@@@~t ~~ c~~@   M@@b~~.b~o i "

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const-string v1, "anhm ctCiueogicrto askt:Ssitneoefrts"

    const-string v1, "gaseCtoitc :ounoitrtanier keiSstcsfh"

    const/4 v7, 0x4

    const-string v1, ":cskori tNtteitnoirchCfo aaetuegSsin"

    const-string/jumbo v1, "onCheckNotification registerStatus: "

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    sget v1, Lcom/tencent/android/tpush/service/util/c;->a:I

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    const-string/jumbo v1, "lftcUboitmisiionaN"

    const-string v1, "atomlUittcsofniiiN"

    const/4 v7, 0x6

    const-string v1, "NfiscauoUotiistnit"

    const-string v1, "NotificationsUtils"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    sget v0, Lcom/tencent/android/tpush/service/util/c;->a:I

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    const/4 v2, 0x1

    const/4 v6, 0x2

    shl-int/2addr v7, v6

    if-ne v0, v2, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/service/util/c$1;->a:Landroid/content/Context;

    const/4 v7, 0x0

    const/4 v6, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/service/util/c;->c(Landroid/content/Context;)Ljava/util/List;

    move-result-object v0

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/util/c$1;->a:Landroid/content/Context;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-static {v2}, Lcom/tencent/android/tpush/service/util/c;->b(Landroid/content/Context;)I

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpush/service/util/c$1;->a:Landroid/content/Context;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-static {v3, v2, v0}, Lcom/tencent/android/tpush/service/util/c;->a(Landroid/content/Context;ILjava/util/List;)Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/service/util/c$1;->a:Landroid/content/Context;

    const/4 v7, 0x0

    invoke-static {v3}, Lcom/tencent/tpns/baseapi/XGApiConfig;->isRegistered(Landroid/content/Context;)Z

    move-result v3

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string/jumbo v5, "krgioNepce dso: ioeRtaietiiChsoftn"

    const-string/jumbo v5, "odoeo sNieCRtnkticisainretofh:e gi"

    const/4 v7, 0x2

    const-string v5, "hdrkceeeqooCtnoic:etfsNiaRi gsit n"

    const-string/jumbo v5, "onCheckNotification isRegistered: "

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string/jumbo v3, "tesa,Sftn: "

    const-string v3, ",:aS btfnte"

    const/4 v7, 0x3

    const-string/jumbo v3, "t:nme,a fSt"

    const-string v3, " ,ntfState:"

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string/jumbo v2, "tn:ioodSh uoaatetef,caiiCngt"

    const-string v2, ":ta oauSoentae,cgtdCtiinifnh"

    const/4 v7, 0x7

    const-string v2, " fii:beahnitndteaoSc tatCgon"

    const-string v2, " , notificationStateChanged:"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    invoke-virtual {v4, v0}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    move v7, v6

    if-eqz v0, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/service/util/c$1;->a:Landroid/content/Context;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/XGApiConfig;->isRegistered(Landroid/content/Context;)Z

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string/jumbo v0, "tardtwuC aaegdeasisgchthi ntesnt  pf,iPSgghocarioeaninua"

    const-string v0, "idSshfCpngci eeega nhtasawiteiunitPatreah nctdr a,googas"

    const/4 v7, 0x7

    const-string v0, "acotgdupoPs ttiagdrgsnnehfCaneetnhshci,iawta eaaeSrng i "

    const-string/jumbo v0, "notificationStateChanged was changed, registerPush again"

    const/4 v7, 0x2

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/service/util/c$1;->a:Landroid/content/Context;

    const/4 v7, 0x0

    const/4 v6, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushManager;->registerPush(Landroid/content/Context;)V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    goto :goto_0

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string v0, "aii rte quca fooiosctoieqgrRend,hegntn nd"

    const-string v0, "g itddiaqgtoescaeeoh ,uRnr nnocnfteiior n"

    const/4 v7, 0x5

    const-string/jumbo v0, "tnstRsi f g,atdrinneoteo rcegonouacihn ei"

    const-string/jumbo v0, "notification not changed, or unRegistered"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    return-void
.end method
