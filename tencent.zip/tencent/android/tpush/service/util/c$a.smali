.class public Lcom/tencent/android/tpush/service/util/c$a;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Comparable;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/service/util/c;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Object;",
        "Ljava/lang/Comparable<",
        "Lcom/tencent/android/tpush/service/util/c$a;",
        ">;"
    }
.end annotation


# instance fields
.field a:I

.field b:Ljava/lang/String;

.field c:Ljava/lang/String;


# direct methods
.method public constructor <init>(ILjava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput p1, p0, Lcom/tencent/android/tpush/service/util/c$a;->a:I

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpush/service/util/c$a;->b:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x4

    iput-object p3, p0, Lcom/tencent/android/tpush/service/util/c$a;->c:Ljava/lang/String;

    const/4 v0, 0x0

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public a(Lcom/tencent/android/tpush/service/util/c$a;)I
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@@sb@@t~ l mrnofo l~M~  i a@~o~~u@@iof~@@@sdo  ~. bo @~ itS~~-~@@Kbc~~1 ~@@v@~y~ @~/@  @ ~~~~/4@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    if-eqz p1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x1

    move v4, v3

    iget-object v1, p1, Lcom/tencent/android/tpush/service/util/c$a;->b:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object p1, p1, Lcom/tencent/android/tpush/service/util/c$a;->c:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string p1, ""

    const-string p1, ""

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/service/util/c$a;->b:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/service/util/c$a;->c:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Ljava/lang/String;->compareTo(Ljava/lang/String;)I

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    return p1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/4 p1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    return p1
.end method

.method public a()Lorg/json/JSONObject;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v1, "easmt"

    const-string/jumbo v1, "tessa"

    const/4 v4, 0x3

    const-string/jumbo v1, "setao"

    const-string/jumbo v1, "state"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget v2, p0, Lcom/tencent/android/tpush/service/util/c$a;->a:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v1, "id"

    const-string v1, "id"

    const/4 v4, 0x2

    const-string v1, "id"

    const-string v1, "id"

    iget-object v2, p0, Lcom/tencent/android/tpush/service/util/c$a;->b:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const-string v1, "enma"

    const-string v1, "amne"

    const/4 v4, 0x4

    const-string v1, "anme"

    const-string/jumbo v1, "name"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/util/c$a;->c:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x0

    return-object v0
.end method

.method public synthetic compareTo(Ljava/lang/Object;)I
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    check-cast p1, Lcom/tencent/android/tpush/service/util/c$a;

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/service/util/c$a;->a(Lcom/tencent/android/tpush/service/util/c$a;)I

    move-result p1

    const/4 v1, 0x1

    const/4 v0, 0x7

    return p1
.end method
