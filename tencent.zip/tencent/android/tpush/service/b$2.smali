.class Lcom/tencent/android/tpush/service/b$2;
.super Landroid/os/Handler;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/b;->k()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/b;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/b;Landroid/os/Looper;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/service/b$2;->a:Lcom/tencent/android/tpush/service/b;

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-direct {p0, p2}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    const/4 v0, 0x4

    const/4 v0, 0x1

    return-void
.end method


# virtual methods
.method public handleMessage(Landroid/os/Message;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "1dsv@~@   l @-~~ @~@l~@o@@s~n~ 4o@ o@~Mm@iy~ @ @/ ~@~fc~@t~bb~fK@i~@~/~ro t.o  @~ ~@u@oS ib  ~~~"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    invoke-super {p0, p1}, Landroid/os/Handler;->handleMessage(Landroid/os/Message;)V

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-eqz p1, :cond_4

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-string v1, "Hrnmmia ,dc:dntei"

    const-string/jumbo v1, "initHandler, cmd:"

    const/4 v6, 0x5

    const/4 v5, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    iget v1, p1, Landroid/os/Message;->what:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x2

    const-string/jumbo v1, "rergohaasuiPnvMces"

    const-string v1, "aasercnehsrgMePvui"

    const/4 v6, 0x6

    const-string/jumbo v1, "racirbhPeMeSegvnsa"

    const-string v1, "PushServiceManager"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x6

    iget v0, p1, Landroid/os/Message;->what:I

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    const/4 v2, 0x1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v3, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    if-eq v0, v2, :cond_2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    if-eq v0, v2, :cond_1

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v2, 0x3

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    if-eq v0, v2, :cond_0

    const/4 v6, 0x6

    const/4 v2, 0x6

    const/4 v6, 0x4

    const/4 v2, 0x4

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x0

    if-eq v0, v2, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v2, " nrnunusklagnwe o dmmh"

    const-string v2, "erlmswnmau ndg= hn kno"

    const/4 v6, 0x3

    const-string/jumbo v2, "rhmalndpunw  k e=ngo n"

    const-string/jumbo v2, "unknown handler msg = "

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    iget p1, p1, Landroid/os/Message;->what:I

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    goto/16 :goto_0

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    iget-object p1, p1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v6, 0x0

    invoke-virtual {p1, v3}, Lcom/tencent/android/tpush/c/a$a;->c(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    const/4 v5, 0x2

    move v6, v5

    goto/16 :goto_0

    :cond_1
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object p1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object p1, p1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    invoke-virtual {p1, v3}, Lcom/tencent/android/tpush/c/a$a;->a(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    goto/16 :goto_0

    :cond_2
    const/4 v5, 0x4

    move v6, v5

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x4

    const-string v0, "grro/ Snq at/c uivenis"

    const-string v0, "cnnro /ut/are  nvSgisi"

    const/4 v6, 0x4

    const-string v0, "/ss Secrgneaun  v/iitn"

    const-string v0, "Service\'s running at "

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->i()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v0, "ensivb:or, "

    const-string v0, "ensivb:or, "

    const/4 v6, 0x7

    const-string v0, " :,mos iren"

    const-string v0, ",version : "

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const-string v0, "41.3..u"

    const/4 v6, 0x5

    const-string v0, "4.91o.3"

    const-string v0, "1.4.3.9"

    const/4 v6, 0x6

    const/4 v5, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x3

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->dd(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/common/f;->a()Z

    move-result p1

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-nez p1, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string/jumbo p1, "siermbc oskpslerdhfki i lv!ap,ceileinc"

    const-string/jumbo p1, "nshekilpp,e cmrclkifsrei!asiecilo dv e"

    const-string p1, "efp ! uresss,iailrclnikvkedlei ch come"

    const-string/jumbo p1, "permission check failed, kill service!"

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/service/b$2;->a:Lcom/tencent/android/tpush/service/b;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    invoke-virtual {p1}, Lcom/tencent/android/tpush/service/b;->d()V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/service/util/g;->e(Landroid/content/Context;)V

    :cond_3
    const/4 v6, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/a;->a()Lcom/tencent/android/tpush/service/a;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Lcom/tencent/android/tpush/service/a;->a(Landroid/content/Context;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object p1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x2

    iget-object p1, p1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {p1, v3}, Lcom/tencent/android/tpush/c/a$a;->a(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->j()Z

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-nez p1, :cond_4

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    const-string p1, " nlere poq gs raxuvpslpeuic 8st"

    const-string/jumbo p1, "s 8nv suqlp iesxtl ecaogu err p"

    const-string/jumbo p1, "unlx  rlqpver ce ltpssuois8e g "

    const-string/jumbo p1, "pull up xg services on 8s later"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x5

    new-instance v0, Lcom/tencent/android/tpush/service/b$2$1;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/service/b$2$1;-><init>(Lcom/tencent/android/tpush/service/b$2;)V

    const/4 v5, 0x4

    move v6, v5

    const-wide/16 v3, 0x1f40

    const-wide/16 v3, 0x1f40

    const/4 v6, 0x0

    const-wide/16 v3, 0x1f40

    const-wide/16 v3, 0x1f40

    const/4 v5, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-virtual {p1, v0, v3, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;J)Z

    const/4 v5, 0x4

    move v6, v5

    invoke-static {v2}, Lcom/tencent/android/tpush/service/b;->b(Z)Z

    :cond_4
    :goto_0
    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    return-void
.end method
