.class Lcom/tencent/android/tpush/service/a$2;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/service/c/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a;->h(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:Lcom/tencent/android/tpush/service/a;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$2;->e:Lcom/tencent/android/tpush/service/a;

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/service/a$2;->a:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x2

    iput-object p3, p0, Lcom/tencent/android/tpush/service/a$2;->b:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x3

    iput-object p4, p0, Lcom/tencent/android/tpush/service/a$2;->c:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p5, p0, Lcom/tencent/android/tpush/service/a$2;->d:Ljava/lang/String;

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "n~s~~@@~@ o@Sa@lmov.~@ b  yi~~@ ~@@u@@ r @~l@~tb@K~s ci@ ~~1  /~~~d/~f~ ~f~@@@t@oi -~o4 M  @ b~o"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    const-string p2, "HuhmnviaceeSParesddrsosrlBc"

    const-string p2, "ecslerBdHsraadoihaPnSsuvcer"

    const/4 v2, 0x3

    const-string p2, "ahSPoencedasriluBHrdsoarvet"

    const-string p2, "PushServiceBroadcastHandler"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    if-nez p1, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string v0, "ci[ tbdskbhes cIO>cshueeoPc hrcTmndi>a u  nks a=ets "

    const-string v0, "Psemhesa= thcc s> en d kduOsTitkrIac o[uscb>c shi ne"

    const/4 v2, 0x4

    const-string v0, "hPc>ieunat ohn cTOs>[dwkicbeud k =rhs c a ssusesIcet"

    const-string v0, ">> bind OtherPushToken success ack with [accessId = "

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$2;->a:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string/jumbo v0, "o  p =spr,"

    const-string v0, ",p  osr = "

    const/4 v2, 0x4

    const-string v0, "     ,psqr"

    const-string v0, "  , rsp = "

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const-string p1, "]  token = "

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/service/a$2;->b:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string p1, "ebst= Thpu esoh P"

    const-string p1, "eeThsbu Ptrpoh = "

    const/4 v2, 0x4

    const-string p1, "hPsmo e= puerth y"

    const-string p1, " otherPushType = "

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/service/a$2;->c:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string p1, " uthonshu= k eorTP"

    const-string p1, "  uosTunhokrht =eP"

    const/4 v2, 0x7

    const-string/jumbo p1, "s= tkbTeh oneoPhru"

    const-string p1, " otherPushToken = "

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/service/a$2;->d:Ljava/lang/String;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x5

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x7

    iget-object p1, p0, Lcom/tencent/android/tpush/service/a$2;->e:Lcom/tencent/android/tpush/service/a;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;)V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x2

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    const-string v0, "aukpsoukoali>e dces>hnPdeCeudsafoerpOtptn r= Teh"

    const-string/jumbo v0, "skOCa= p>ocsd>rlaheuTpen ifakPep sdhrntdeeeouote"

    const/4 v2, 0x6

    const-string v0, " =ksrnspd aheo Teapehkduet> OatCoPefeidnel>opusc"

    const-string v0, ">> updateOtherPushToken ack failed responseCode="

    const/4 v1, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v1, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method public b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x2

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    const-string/jumbo v0, "sgklo@e qe@u uart enneantOqeasSdeddphPFoiTMh"

    const-string v0, "MduaeF@eqgsetohPTideoar  ephknnadeust@OSsn l"

    const/4 v2, 0x7

    const-string/jumbo v0, "oesandlheueP sTnFSeaMpskreod@ta n@huetgOides"

    const-string v0, "@@ updateOtherPushToken onMessageSendFailed "

    const/4 v2, 0x6

    const/4 v1, 0x7

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string p1, ","

    const-string p1, ","

    const/4 v2, 0x6

    const-string p1, ","

    const/4 v2, 0x6

    const/4 v1, 0x4

    invoke-virtual {p3, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    const-string p2, "BctmdraohessrdlsaSeviPuaHen"

    const-string/jumbo p2, "rssBalhHdtesarScvoureindeaP"

    const/4 v2, 0x7

    const-string p2, "PushServiceBroadcastHandler"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x1

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    return-void
.end method
