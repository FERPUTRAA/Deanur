.class Lcom/tencent/android/tpush/service/a$a;
.super Landroid/content/BroadcastReceiver;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/service/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x2
    name = "a"
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/a;


# virtual methods
.method public onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@ st boSso@@4ir~@niv@~~ ~K/~~@@f@ @dlM~u~~ i@~ fc@@1 @~ ~~bb/~@ m @~@~o @@~   ~@ol. @-oo t~ay~~~"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x5

    const-string/jumbo v0, "rkCmR-eericseeacPingge a covahReene"

    const-string v0, "C-svireeRicon eseaRcgcga kneraPeehe"

    const/4 v4, 0x7

    const-string v0, "gncCorRr-cehege Peeeaan eaiciokeRsv"

    const-string v0, "PackageChangesReceiver - onReceiver"

    const-string/jumbo v1, "vPeBobeardedlmurhsSniaascrc"

    const-string/jumbo v1, "vsrmBaeSrdrPusclHicadeenaoh"

    const/4 v4, 0x1

    const-string v1, "daseHeudaPcervoSnsBrhciatur"

    const-string v1, "PushServiceBroadcastHandler"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eqz p2, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    if-eqz p1, :cond_2

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$a;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/service/a;->b(Lcom/tencent/android/tpush/service/a;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-eqz v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    new-instance v1, Lcom/tencent/android/tpush/service/a$b;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a$a;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-direct {v1, v2, p1, p2}, Lcom/tencent/android/tpush/service/a$b;-><init>(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x2

    goto/16 :goto_0

    :cond_0
    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object p1, p0, Lcom/tencent/android/tpush/service/a$a;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v3, 0x0

    move v4, v3

    invoke-static {p1}, Lcom/tencent/android/tpush/service/a;->c(Lcom/tencent/android/tpush/service/a;)Ljava/util/ArrayList;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    const/16 v0, 0xa

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-ge p1, v0, :cond_1

    const/4 v4, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpush/service/a$a;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/service/a;->c(Lcom/tencent/android/tpush/service/a;)Ljava/util/ArrayList;

    move-result-object p1

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1, p2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x7

    const-string v0, "cna  oepadeasPvrii:eItteRkbnentecnghcICinitded enfsgd n,ooearoat"

    const-string v0, "edCaodoogRevatbattdPtiniriaednoinkeefct sgn aecrnees :thcen nI,I"

    const/4 v4, 0x6

    const-string v0, ":dteniPiqcttaebkIrveReeIggestrned tecd dotic eaoh nCfn,aineasonn"

    const-string v0, "PackageChangesReceiver add intend to beforeInitedIntents,action:"

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {p2}, Landroid/content/Intent;->getAction()Ljava/lang/String;

    move-result-object p2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string p2, "eis,: z"

    const-string p2, "e: zib,"

    const/4 v4, 0x1

    const-string p2, " i,me:s"

    const-string p2, ", size:"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    shl-int/2addr v4, v3

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$a;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v3, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p2}, Lcom/tencent/android/tpush/service/a;->c(Lcom/tencent/android/tpush/service/a;)Ljava/util/ArrayList;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    move-result p2

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    goto :goto_0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo p1, "ntdeosesInTramu eiftuobiddo  tInih.tocer"

    const-string p1, "eri enusttfdonr Ihisditn TIeteuoc.dbam o"

    const/4 v4, 0x2

    const-string/jumbo p1, "sechsbec.TIdetu odt tinf eiodan rIitrbon"

    const-string p1, "Too much beforeInitedIntents. discard it"

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void
.end method
