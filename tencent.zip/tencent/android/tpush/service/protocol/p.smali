.class public Lcom/tencent/android/tpush/service/protocol/p;
.super Lcom/tencent/android/tpush/service/protocol/d;


# instance fields
.field public a:J

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:I

.field public e:J

.field public f:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/d;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/p;->a:J

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x6

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/p;->b:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/p;->c:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v3, 0x0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    iput v3, p0, Lcom/tencent/android/tpush/service/protocol/p;->d:I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/p;->e:J

    const/4 v5, 0x0

    const/4 v4, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/p;->f:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    return-void
.end method


# virtual methods
.method public a()Lcom/tencent/android/tpush/service/protocol/MessageType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l so~@4~/@@ s f ~~K@@M~@~~@@ ~b~@orb~@ a~~@~o  ~o~ 1yt ucdfbm@ @oii ov/~ ~~~.li@~@  ~-@S  @@n@~t"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/service/protocol/MessageType;->TAG_INFO:Lcom/tencent/android/tpush/service/protocol/MessageType;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object v0
.end method

.method public a(Landroid/content/Context;)Lorg/json/JSONObject;
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    new-instance p1, Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string v0, "edcmascs"

    const-string/jumbo v0, "sassdcce"

    const/4 v4, 0x0

    const-string v0, "Iceaodcs"

    const-string v0, "accessId"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/p;->a:J

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string v0, "cscyebmeK"

    const-string v0, "eycmasKec"

    const/4 v4, 0x7

    const-string v0, "ceseKsuac"

    const-string v0, "accessKey"

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/p;->b:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const-string v0, "agt"

    const-string v0, "gta"

    const/4 v4, 0x4

    const-string/jumbo v0, "tga"

    const-string/jumbo v0, "tag"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/p;->c:Ljava/lang/String;

    const/4 v4, 0x5

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v0, "gafl"

    const-string v0, "flag"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget v1, p0, Lcom/tencent/android/tpush/service/protocol/p;->d:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x4

    const-string v0, "amsotmppe"

    const-string/jumbo v0, "pmtmoesat"

    const/4 v4, 0x1

    const-string/jumbo v0, "metmtsaiq"

    const-string/jumbo v0, "timestamp"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/p;->e:J

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v3, 0x6

    move v4, v3

    const-string v0, "dssVkrobns"

    const-string/jumbo v0, "nseorbdkVs"

    const/4 v4, 0x5

    const-string/jumbo v0, "sirmnVeosk"

    const-string/jumbo v0, "sdkVersion"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/p;->f:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    return-object p1
.end method
