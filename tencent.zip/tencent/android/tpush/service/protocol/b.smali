.class public Lcom/tencent/android/tpush/service/protocol/b;
.super Lcom/tencent/android/tpush/service/protocol/d;


# instance fields
.field public a:J

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:I

.field public e:J

.field public f:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x3

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/d;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/b;->a:J

    const/4 v5, 0x6

    const/4 v4, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x6

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/b;->b:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/b;->c:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    const/4 v3, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x5

    iput v3, p0, Lcom/tencent/android/tpush/service/protocol/b;->d:I

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/b;->e:J

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/b;->f:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x3

    return-void
.end method


# virtual methods
.method public a()Lcom/tencent/android/tpush/service/protocol/MessageType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@/siy b@@ tS@oi~K 1.@l~-cn@ ~@@@~@/d ~o~~rtoi  ~~~ ~b@  ~~ @m~oo ~ @las~ @ @@~4~~Mofu@b~f~v@ ~ @"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/tencent/android/tpush/service/protocol/MessageType;->ATTRIBUTE_INFO:Lcom/tencent/android/tpush/service/protocol/MessageType;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method

.method public a(Landroid/content/Context;)Lorg/json/JSONObject;
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x5

    new-instance p1, Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    const-string v0, "ascmcsIs"

    const-string/jumbo v0, "sascsIec"

    const/4 v4, 0x6

    const-string/jumbo v0, "scasoeId"

    const-string v0, "accessId"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/b;->a:J

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v0, "cmscKbaee"

    const-string v0, "eecmscKsa"

    const/4 v4, 0x5

    const-string/jumbo v0, "yssaeKucc"

    const-string v0, "accessKey"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/b;->b:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x2

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/b;->c:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-direct {v0, v1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string v1, "butreotpts"

    const-string/jumbo v1, "truboestit"

    const/4 v4, 0x4

    const-string/jumbo v1, "trubtiasqt"

    const-string v1, "attributes"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v0, "yespbrpatoe"

    const-string/jumbo v0, "reoyabteppe"

    const/4 v4, 0x3

    const-string/jumbo v0, "operateType"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    iget v1, p0, Lcom/tencent/android/tpush/service/protocol/b;->d:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string/jumbo v0, "iesmpttmu"

    const-string/jumbo v0, "tspemmuti"

    const/4 v4, 0x0

    const-string/jumbo v0, "ttmsoamie"

    const-string/jumbo v0, "timestamp"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/b;->e:J

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    const-string/jumbo v0, "nisosbpedV"

    const-string/jumbo v0, "orsiVdspen"

    const-string/jumbo v0, "ireVsnukod"

    const-string/jumbo v0, "sdkVersion"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/b;->f:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-object p1
.end method
