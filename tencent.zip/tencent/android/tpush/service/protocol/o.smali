.class public Lcom/tencent/android/tpush/service/protocol/o;
.super Ljava/lang/Object;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/o;->a:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/o;->b:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/o;->c:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/o;->d:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/o;->e:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/o;->f:Ljava/lang/String;

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/o;->g:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public a()Lorg/json/JSONObject;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~~sb @~~~@  bo ~~t@~@i ~i~@o~i@@f/~ @~M@oo@ @~~     d1/oKl@t~f.sa r~o 4 u@@v~@~ l~@@ -nc~S@~@ym@"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x5

    const-string v1, "embmioTo"

    const-string/jumbo v1, "oTsioemb"

    const/4 v4, 0x2

    const-string v1, "iTmooteo"

    const-string v1, "bootTime"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/o;->a:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string/jumbo v1, "nodcmbytruo"

    const-string/jumbo v1, "tndmouyoerc"

    const/4 v4, 0x2

    const-string/jumbo v1, "tyredCuuoco"

    const-string v1, "countryCode"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/o;->b:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v1, "maeodvcpeN"

    const-string v1, "emdNoicaev"

    const/4 v4, 0x3

    const-string/jumbo v1, "micdeeaNqe"

    const-string v1, "deviceName"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/o;->c:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v1, "Icsbreanrir"

    const-string v1, "anecobirrIr"

    const-string/jumbo v1, "racmoeIrirf"

    const-string v1, "carrierInfo"

    const/4 v4, 0x3

    const/4 v3, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/o;->d:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    const-string/jumbo v1, "moeyriuSez"

    const/4 v4, 0x6

    const-string v1, "emeSoozrim"

    const-string/jumbo v1, "memorySize"

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/o;->e:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v1, "ikzpibSd"

    const-string/jumbo v1, "zeSidikp"

    const/4 v4, 0x0

    const-string/jumbo v1, "zSidisue"

    const-string v1, "diskSize"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/o;->f:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v1, "yslTeispqem"

    const-string v1, "eelyiFsmqTs"

    const/4 v4, 0x2

    const-string v1, "FsyileTsqei"

    const-string/jumbo v1, "sysFileTime"

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/o;->g:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object v0
.end method
