.class public Lcom/tencent/android/tpush/service/protocol/f;
.super Ljava/lang/Object;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;

.field public h:Ljava/lang/String;

.field public i:Ljava/lang/String;

.field public j:Ljava/lang/String;

.field public k:J

.field public l:Ljava/lang/String;

.field public m:Ljava/lang/String;

.field public n:Ljava/lang/String;

.field public o:Ljava/lang/String;

.field public p:Ljava/lang/String;

.field public q:Ljava/lang/String;

.field public r:Ljava/lang/String;

.field public s:Ljava/lang/String;

.field public t:I

.field public u:Ljava/util/List;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/List<",
            "Lcom/tencent/android/tpush/service/util/c$a;",
            ">;"
        }
    .end annotation
.end field

.field public v:Lcom/tencent/android/tpush/service/protocol/o;


# direct methods
.method public constructor <init>()V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->a:Ljava/lang/String;

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->b:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->c:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->d:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->e:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->f:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->g:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->h:Ljava/lang/String;

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->i:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->j:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x6

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/f;->k:J

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->l:Ljava/lang/String;

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->m:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->n:Ljava/lang/String;

    const/4 v3, 0x1

    move v4, v3

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->o:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->p:Ljava/lang/String;

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->q:Ljava/lang/String;

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->r:Ljava/lang/String;

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->s:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x4

    const/4 v0, 0x3

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    iput v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->t:I

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    const/4 v0, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/f;->v:Lcom/tencent/android/tpush/service/protocol/o;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x6

    return-void
.end method


# virtual methods
.method public a()Lorg/json/JSONObject;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "o~s@@@soo~~~~@~v~c @~@@m~  @bi~r@~oul@MK~~n -f@~@ ~d S . /  ~4l/t@  ~@~~~ y ob~t@bao1@ i @@@f@ i"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x2

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x2

    move v5, v4

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string/jumbo v1, "meii"

    const-string/jumbo v1, "imei"

    const/4 v5, 0x0

    const/4 v4, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->a:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string v1, "dmsel"

    const-string v1, "demml"

    const-string/jumbo v1, "model"

    const/4 v5, 0x1

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->b:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v1, "os"

    const-string/jumbo v1, "os"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->c:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x3

    const-string v1, "ektnowo"

    const-string/jumbo v1, "network"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->d:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string v1, "admCdb"

    const-string v1, "ddCmar"

    const/4 v5, 0x7

    const-string/jumbo v1, "sdCard"

    const/4 v5, 0x1

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->e:Ljava/lang/String;

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x1

    const-string v1, "Doboslud"

    const-string/jumbo v1, "sebDodlo"

    const/4 v5, 0x0

    const-string/jumbo v1, "lbDdseup"

    const-string/jumbo v1, "sdDouble"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->f:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo v1, "ltubnioeqr"

    const-string/jumbo v1, "iunolbrteo"

    const-string/jumbo v1, "oostisleru"

    const-string/jumbo v1, "resolution"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->g:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string/jumbo v1, "namu"

    const-string v1, "amun"

    const/4 v5, 0x0

    const-string/jumbo v1, "manu"

    const-string/jumbo v1, "manu"

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->h:Ljava/lang/String;

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string v1, "Laimeeup"

    const-string/jumbo v1, "ilepLaue"

    const-string v1, "aeLpoelv"

    const-string v1, "apiLevel"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->i:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x6

    const-string v1, "dnkpmbsarNeosV"

    const-string/jumbo v1, "kamnsNipsoredV"

    const/4 v5, 0x6

    const-string v1, "eaniNsuodmVkes"

    const-string/jumbo v1, "sdkVersionName"

    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->j:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    const-string/jumbo v1, "toqidsep"

    const-string/jumbo v1, "qodeisto"

    const/4 v5, 0x6

    const-string/jumbo v1, "qeooiRdt"

    const-string/jumbo v1, "isRooted"

    const/4 v5, 0x4

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->k:J

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo v1, "pispstL"

    const-string v1, "iLsppta"

    const/4 v5, 0x1

    const-string/jumbo v1, "sitmapp"

    const-string v1, "appList"

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->l:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    const-string/jumbo v1, "mfpIoun"

    const-string/jumbo v1, "npumcIf"

    const/4 v5, 0x5

    const-string/jumbo v1, "pcIufbn"

    const-string v1, "cpuInfo"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->m:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x4

    move v5, v4

    const-string v1, "aluaggun"

    const-string/jumbo v1, "language"

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->n:Ljava/lang/String;

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x6

    const-string/jumbo v1, "ioenoezp"

    const-string/jumbo v1, "ntieoeoz"

    const/4 v5, 0x6

    const-string/jumbo v1, "qmteonei"

    const-string/jumbo v1, "timezone"

    const/4 v5, 0x3

    const/4 v4, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->o:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x7

    const-string v1, "cNslabnmeehu"

    const-string/jumbo v1, "ucnehbealrmN"

    const/4 v5, 0x0

    const-string v1, "Nlemuamrneha"

    const-string/jumbo v1, "launcherName"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->p:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    and-int/2addr v5, v4

    const-string v1, "AxipogstL"

    const-string/jumbo v1, "xgAppList"

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->q:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    const-string v1, "artufb"

    const-string/jumbo v1, "uarftn"

    const/4 v5, 0x1

    const-string/jumbo v1, "unrBaf"

    const-string/jumbo v1, "ntfBar"

    const/4 v5, 0x5

    const/4 v4, 0x2

    iget v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->t:I

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/f;->v:Lcom/tencent/android/tpush/service/protocol/o;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x3

    if-eqz v1, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x2

    const-string/jumbo v2, "ntiIUnop"

    const-string/jumbo v2, "tUinInfo"

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/protocol/o;->a()Lorg/json/JSONObject;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string/jumbo v1, "ospeiosnq"

    const-string/jumbo v1, "nseoioVps"

    const/4 v5, 0x0

    const-string/jumbo v1, "rVsnosose"

    const-string/jumbo v1, "osVersion"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->r:Ljava/lang/String;

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/f;->s:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string/jumbo v1, "isVmorehn"

    const-string/jumbo v1, "ohVersion"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->s:Ljava/lang/String;

    const/4 v4, 0x0

    move v5, v4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/f;->u:Ljava/util/List;

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x7

    if-eqz v1, :cond_3

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-interface {v1}, Ljava/util/List;->size()I

    move-result v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    if-lez v1, :cond_3

    const/4 v4, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    new-instance v1, Lorg/json/JSONArray;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-direct {v1}, Lorg/json/JSONArray;-><init>()V

    const/4 v5, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/f;->u:Ljava/util/List;

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {v2}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v2

    :catchall_0
    :goto_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-interface {v2}, Ljava/util/Iterator;->hasNext()Z

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x4

    if-eqz v3, :cond_2

    const/4 v5, 0x0

    invoke-interface {v2}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    check-cast v3, Lcom/tencent/android/tpush/service/util/c$a;

    :try_start_0
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v3}, Lcom/tencent/android/tpush/service/util/c$a;->a()Lorg/json/JSONObject;

    move-result-object v3

    const/4 v5, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, v3}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x2

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const-string/jumbo v2, "ncsaoqel"

    const-string/jumbo v2, "qclennas"

    const/4 v5, 0x4

    const-string/jumbo v2, "secnhbnl"

    const-string v2, "channels"

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_3
    const/4 v5, 0x1

    const/4 v4, 0x7

    return-object v0
.end method
