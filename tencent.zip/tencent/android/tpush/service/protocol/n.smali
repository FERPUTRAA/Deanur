.class public Lcom/tencent/android/tpush/service/protocol/n;
.super Lcom/tencent/android/tpush/service/protocol/e;


# instance fields
.field public a:J

.field public b:Ljava/lang/String;

.field public c:J

.field public d:J

.field public e:Ljava/lang/String;

.field public f:J

.field public g:J

.field public h:Ljava/lang/String;

.field public i:Ljava/lang/String;

.field public j:I

.field public k:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/e;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-wide/16 v0, 0x0

    const/4 v4, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/n;->a:J

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/n;->b:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/n;->c:J

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/n;->d:J

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/n;->e:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/n;->f:J

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/n;->g:J

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/n;->h:Ljava/lang/String;

    const/4 v3, 0x3

    move v4, v3

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/n;->i:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v0, -0x6

    const/4 v0, -0x1

    const/4 v3, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput v0, p0, Lcom/tencent/android/tpush/service/protocol/n;->j:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v0, 0x0

    move v4, v0

    const/4 v3, 0x6

    shl-int/2addr v4, v3

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/n;->k:Ljava/util/ArrayList;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    return-void
.end method

.method public static a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@~s@~Myo@  ~u@S@@~l  ~~1fib@.@~Kol@ns~@/ o   @v~r@cito@bot~@@~~m 4f/  @ @b  ~a~~i-~@o~~@  ~ ~d@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    const/4 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz p0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p0

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    if-eqz p0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    goto :goto_0

    :cond_0
    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    new-instance p0, Lorg/json/JSONObject;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {p0}, Lorg/json/JSONObject;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string/jumbo v1, "sntme"

    const-string/jumbo v1, "teskn"

    const/4 v3, 0x3

    const-string v1, "ektno"

    const-string/jumbo v1, "token"

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {p0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-virtual {p0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    return-object p0

    :catchall_0
    :cond_1
    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0
.end method


# virtual methods
.method public a()Lcom/tencent/android/tpush/service/protocol/MessageType;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/service/protocol/MessageType;->REGISTER:Lcom/tencent/android/tpush/service/protocol/MessageType;

    const/4 v2, 0x2

    return-object v0
.end method

.method public a(Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo p1, "nsVoibncerm"

    const-string/jumbo p1, "ionmcVsenor"

    const/4 v4, 0x4

    const-string/jumbo p1, "ncofriuoesV"

    const-string p1, "confVersion"

    const/4 v4, 0x4

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->a:J

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, p1, v1, v2}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->a:J

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string p1, "enpkt"

    const-string p1, "ektno"

    const/4 v4, 0x6

    const-string/jumbo p1, "nekqt"

    const-string/jumbo p1, "token"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->b:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/service/protocol/n;->b:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string p1, "diug"

    const-string p1, "gidu"

    const/4 v4, 0x1

    const-string p1, "gudi"

    const-string p1, "guid"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->c:J

    const/4 v3, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, p1, v1, v2}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    iput-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->c:J

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo p1, "phsTohseeorbknuyeP"

    const-string p1, "ePoTkbesruophtnehy"

    const/4 v4, 0x0

    const-string/jumbo p1, "onemyotkpPuTrseehT"

    const-string/jumbo p1, "otherPushTokenType"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->d:J

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, p1, v1, v2}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->d:J

    const/4 v4, 0x6

    const/4 v3, 0x7

    const-string/jumbo p1, "oePooTutenrhsk"

    const-string/jumbo p1, "tnsPkTueourheo"

    const/4 v4, 0x2

    const-string p1, "TesnhbhteorkoP"

    const-string/jumbo p1, "otherPushToken"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->e:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x2

    invoke-virtual {v0, p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/service/protocol/n;->e:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string p1, "ThucheuoPC2e3knrrso"

    const-string p1, "eerTCPupnsckhh2ro3o"

    const/4 v4, 0x4

    const-string p1, "hetT3kopruPhnorsc2C"

    const-string/jumbo p1, "otherPushTokenCrc32"

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->f:J

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, p1, v1, v2}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iput-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->f:J

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo p1, "nko32Ccrqt"

    const-string/jumbo p1, "tokenCrc32"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->g:J

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, p1, v1, v2}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    iput-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->g:J

    const/4 v4, 0x4

    const/4 v3, 0x2

    const-string p1, "eqsersrv"

    const-string/jumbo p1, "qeevesrr"

    const/4 v4, 0x0

    const-string/jumbo p1, "srdmeeev"

    const-string/jumbo p1, "reserved"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->h:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/service/protocol/n;->h:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string p1, "cektos"

    const-string p1, "ctstek"

    const-string/jumbo p1, "kiettb"

    const-string/jumbo p1, "ticket"

    const/4 v4, 0x5

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->i:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, p1, v1}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/service/protocol/n;->i:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const-string p1, "eyceiTukmt"

    const-string p1, "ceTmiykept"

    const/4 v4, 0x0

    const-string/jumbo p1, "tTitpecpye"

    const-string/jumbo p1, "ticketType"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->j:I

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, p1, v1}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput p1, p0, Lcom/tencent/android/tpush/service/protocol/n;->j:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo p1, "reyoopgsu"

    const/4 v4, 0x3

    const-string/jumbo p1, "pKuoeygsq"

    const-string p1, "groupKeys"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, p1}, Lorg/json/JSONObject;->optJSONArray(Ljava/lang/String;)Lorg/json/JSONArray;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    if-eqz p1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    new-instance v0, Ljava/util/ArrayList;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/n;->k:Ljava/util/ArrayList;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    const/4 v0, 0x0

    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1}, Lorg/json/JSONArray;->length()I

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-ge v0, v1, :cond_0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/n;->k:Ljava/util/ArrayList;

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Lorg/json/JSONArray;->getString(I)Ljava/lang/String;

    move-result-object v2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v3, 0x7

    move v4, v3

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    goto :goto_0

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method
