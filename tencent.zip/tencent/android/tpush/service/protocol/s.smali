.class public Lcom/tencent/android/tpush/service/protocol/s;
.super Lcom/tencent/android/tpush/service/protocol/d;


# instance fields
.field public a:J

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:J

.field public g:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/d;-><init>()V

    const/4 v4, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/s;->a:J

    const/4 v3, 0x6

    move v4, v3

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x6

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/s;->b:Ljava/lang/String;

    const/4 v4, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/s;->c:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/s;->d:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/s;->e:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/s;->f:J

    const/4 v3, 0x0

    const/4 v3, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/s;->g:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x1

    return-void
.end method

.method public constructor <init>(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/d;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    iput-wide p1, p0, Lcom/tencent/android/tpush/service/protocol/s;->a:J

    iput-object p3, p0, Lcom/tencent/android/tpush/service/protocol/s;->b:Ljava/lang/String;

    const/4 v0, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p4, p0, Lcom/tencent/android/tpush/service/protocol/s;->c:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p5, p0, Lcom/tencent/android/tpush/service/protocol/s;->d:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p6, p0, Lcom/tencent/android/tpush/service/protocol/s;->e:Ljava/lang/String;

    const/4 v1, 0x3

    iput-wide p7, p0, Lcom/tencent/android/tpush/service/protocol/s;->f:J

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p9, p0, Lcom/tencent/android/tpush/service/protocol/s;->g:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public a()Lcom/tencent/android/tpush/service/protocol/MessageType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, " osrKb ~~~b~ M~l@~~@@ oSb@~io-t~i@cf o/s u~~ @1  i@@n @@l~@oo  @~f@@ @ t~@~~@m @~y~~ @~~.da4 @v/"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/service/protocol/MessageType;->UPDATE_OTHER_TOKEN:Lcom/tencent/android/tpush/service/protocol/MessageType;

    const/4 v1, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public a(Landroid/content/Context;)Lorg/json/JSONObject;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x3

    new-instance p1, Lorg/json/JSONObject;

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    const-string v0, "dssmcIsc"

    const-string v0, "dcsssIca"

    const-string v0, "esdcosIc"

    const-string v0, "accessId"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/s;->a:J

    const/4 v4, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v0, "accessKey"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/s;->b:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string/jumbo v0, "yeemlbpahTn"

    const-string/jumbo v0, "laempnyTenh"

    const/4 v4, 0x0

    const-string v0, "elacnTupyen"

    const-string v0, "channelType"

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/s;->c:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v0, "oekconnpenah"

    const-string/jumbo v0, "knahoecnoneT"

    const/4 v4, 0x0

    const-string v0, "eonhnTklqcen"

    const-string v0, "channelToken"

    const/4 v3, 0x2

    and-int/2addr v4, v3

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/s;->d:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v0, "eiiRcbveodge"

    const/4 v4, 0x7

    const-string/jumbo v0, "iesRovegdcen"

    const-string v0, "deviceRegion"

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/s;->e:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo v0, "mutmspatm"

    const-string/jumbo v0, "tmiaspumt"

    const/4 v4, 0x6

    const-string/jumbo v0, "pettoaims"

    const-string/jumbo v0, "timestamp"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/s;->f:J

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string/jumbo v0, "isVkrbpsdo"

    const-string v0, "Vskdosnpri"

    const/4 v4, 0x2

    const-string/jumbo v0, "sdkVersion"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/s;->g:Ljava/lang/String;

    const/4 v4, 0x2

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-object p1
.end method
