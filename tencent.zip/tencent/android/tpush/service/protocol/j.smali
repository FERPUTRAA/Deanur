.class public Lcom/tencent/android/tpush/service/protocol/j;
.super Ljava/lang/Object;


# instance fields
.field public a:J

.field public b:J

.field public c:J

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:J

.field public g:Ljava/lang/String;

.field public h:J

.field public i:J

.field public j:Ljava/lang/String;

.field public k:J

.field public l:I

.field public m:J

.field public n:J

.field public o:J

.field public p:Ljava/lang/String;

.field public q:Ljava/lang/String;

.field public r:Ljava/lang/String;

.field public s:Ljava/lang/String;

.field public t:J

.field public u:J

.field public v:I

.field public w:Ljava/lang/String;

.field public x:Ljava/lang/String;

.field public y:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 6

    const/4 v5, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->b:J

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->c:J

    const/4 v5, 0x6

    const/4 v4, 0x6

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x7

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/j;->d:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/j;->e:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->f:J

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    const/4 v4, 0x4

    move v5, v4

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->h:J

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->i:J

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/j;->j:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->k:J

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    const/4 v3, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput v3, p0, Lcom/tencent/android/tpush/service/protocol/j;->l:I

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->m:J

    const/4 v4, 0x3

    move v5, v4

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->n:J

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->o:J

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x0

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/j;->p:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/j;->q:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/j;->r:Ljava/lang/String;

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/j;->s:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->t:J

    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->u:J

    const/4 v5, 0x2

    const/4 v4, 0x6

    iput v3, p0, Lcom/tencent/android/tpush/service/protocol/j;->v:I

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x7

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/j;->w:Ljava/lang/String;

    const/4 v4, 0x4

    and-int/2addr v5, v4

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/j;->x:Ljava/lang/String;

    const/4 v5, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/j;->y:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-void
.end method


# virtual methods
.method public a(Lorg/json/JSONObject;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@rsiod~~  f~~ av~/o@ ~K/.@   ~@l@o@n@~~@~fu- @~~o~stSm @ ci ~b~~~@~~b@@4o1@ @ ~~M@  blo@y@t  @@i"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/service/protocol/j;->b(Lorg/json/JSONObject;)V

    const/4 v2, 0x7

    const-string v0, "ecstton"

    const/4 v2, 0x7

    const-string/jumbo v0, "ncometn"

    const-string v0, "content"

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-eqz v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/j;->e:Ljava/lang/String;

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x0

    const-string v0, "Msgmo"

    const-string/jumbo v0, "sgMmn"

    const-string v0, "bnigM"

    const-string/jumbo v0, "inMsg"

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    if-eqz p1, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-virtual {p1}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/service/protocol/j;->y:Ljava/lang/String;

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    return-void
.end method

.method b(Lorg/json/JSONObject;)V
    .locals 10

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string v0, ""

    const-string v0, ""

    const/4 v9, 0x7

    const-string v0, ""

    const-string v0, ""

    :try_start_0
    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string/jumbo v1, "xg"

    const-string/jumbo v1, "xg"

    const/4 v9, 0x3

    const-string/jumbo v1, "xg"

    const-string/jumbo v1, "xg"

    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-virtual {p1, v1}, Lorg/json/JSONObject;->optJSONObject(Ljava/lang/String;)Lorg/json/JSONObject;

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    const-string v2, "eoMagsuPshs"

    const-string/jumbo v2, "shaPosuegMs"

    const/4 v9, 0x7

    const-string v2, "PugMesepssh"

    const-string v2, "PushMessage"

    const/4 v9, 0x6

    const/4 v8, 0x7

    if-eqz v1, :cond_0

    :try_start_1
    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x2

    const-string p1, " t/m bnpygxic/k/tgoqr/m ae nstsea"

    const/4 v9, 0x3

    const-string/jumbo p1, "parse mqtt msg contain key \"xg\""

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {v2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    move-object p1, v1

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    goto :goto_0

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string v1, " ng/ro  q unyemkin s/gttsc/qam/txo tp"

    const-string v1, " exem/u qtstt op /noknncag/itrmy/ gs "

    const-string/jumbo v1, "mcs ynike/ /tampget sqx ot/g/roat ns "

    const-string/jumbo v1, "parse mqtt msg not contain key \"xg\""

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    const-string v1, "gsmmp"

    const-string v1, "dspgm"

    const/4 v9, 0x2

    const-string v1, "Idgmo"

    const-string/jumbo v1, "msgId"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x0

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x7

    iput-wide v4, p0, Lcom/tencent/android/tpush/service/protocol/j;->a:J

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string v1, "asIsebdc"

    const-string/jumbo v1, "qsdIecas"

    const/4 v9, 0x5

    const-string v1, "dIceasus"

    const-string v1, "accessId"

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x2

    iput-wide v4, p0, Lcom/tencent/android/tpush/service/protocol/j;->b:J

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x4

    const-string/jumbo v1, "sMIsbiups"

    const-string v1, "busgissMI"

    const/4 v9, 0x6

    const-string v1, "dMsIusibq"

    const-string v1, "busiMsgId"

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v9, 0x0

    const/4 v8, 0x2

    iput-wide v4, p0, Lcom/tencent/android/tpush/service/protocol/j;->c:J

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string/jumbo v1, "iesml"

    const-string v1, "etlmi"

    const-string v1, "ettmi"

    const-string/jumbo v1, "title"

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpush/service/protocol/j;->d:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string v1, "epty"

    const-string/jumbo v1, "ypte"

    const/4 v9, 0x3

    const-string/jumbo v1, "tpey"

    const-string/jumbo v1, "type"

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x2

    iput-wide v4, p0, Lcom/tencent/android/tpush/service/protocol/j;->f:J

    const/4 v8, 0x1

    or-int/2addr v9, v8

    cmp-long v1, v4, v2

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x6

    if-nez v1, :cond_1

    const/4 v9, 0x4

    const/4 v8, 0x6

    const-string/jumbo v1, "psgeoTy"

    const/4 v9, 0x2

    const-string/jumbo v1, "mTeyogp"

    const-string/jumbo v1, "msgType"

    const/4 v9, 0x0

    const/4 v8, 0x5

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    iput-wide v4, p0, Lcom/tencent/android/tpush/service/protocol/j;->f:J

    :cond_1
    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string v1, "NapgPbkmeb"

    const-string/jumbo v1, "mkNPpbaage"

    const/4 v9, 0x7

    const-string/jumbo v1, "mgapNkuPpe"

    const-string v1, "appPkgName"

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x7

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpush/service/protocol/j;->g:Ljava/lang/String;

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x1

    const-string/jumbo v1, "tiummaeps"

    const-string v1, "iaesmtump"

    const/4 v9, 0x2

    const-string/jumbo v1, "timestamp"

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const/4 v9, 0x4

    const-wide/16 v6, 0x3e8

    const-wide/16 v6, 0x3e8

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x0

    mul-long/2addr v4, v6

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    iput-wide v4, p0, Lcom/tencent/android/tpush/service/protocol/j;->h:J

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    const-string/jumbo v1, "qipkPumg"

    const-string/jumbo v1, "ukmtPgip"

    const/4 v9, 0x6

    const-string/jumbo v1, "uisPmtlg"

    const-string/jumbo v1, "multiPkg"

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v9, 0x3

    const/4 v8, 0x4

    iput-wide v4, p0, Lcom/tencent/android/tpush/service/protocol/j;->i:J

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string v1, "dtea"

    const-string v1, "dtea"

    const/4 v9, 0x1

    const-string v1, "deta"

    const-string v1, "date"

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x3

    iput-object v1, p0, Lcom/tencent/android/tpush/service/protocol/j;->j:Ljava/lang/String;

    const/4 v8, 0x4

    shr-int/2addr v9, v8

    const-string v1, "ervmqesTrm"

    const-string v1, "Teesvremqr"

    const/4 v9, 0x4

    const-string/jumbo v1, "mrTroesvie"

    const-string/jumbo v1, "serverTime"

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v9, 0x6

    const/4 v8, 0x5

    const-wide/32 v6, 0xf4240

    const-wide/32 v6, 0xf4240

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x5

    mul-long/2addr v4, v6

    const/4 v9, 0x7

    const/4 v8, 0x7

    iput-wide v4, p0, Lcom/tencent/android/tpush/service/protocol/j;->k:J

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-string/jumbo v1, "ttl"

    const-string/jumbo v1, "ttl"

    const/4 v9, 0x1

    const-string/jumbo v1, "ttl"

    const-string/jumbo v1, "ttl"

    const/4 v8, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    const/4 v4, 0x0

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-virtual {p1, v1, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    iput v1, p0, Lcom/tencent/android/tpush/service/protocol/j;->l:I

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    const-string/jumbo v1, "lhaenbncd"

    const-string v1, "channelId"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v5

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    iput-wide v5, p0, Lcom/tencent/android/tpush/service/protocol/j;->m:J

    const/4 v9, 0x4

    const/4 v8, 0x6

    const-string/jumbo v1, "usshda"

    const-string v1, "hdsPas"

    const/4 v9, 0x3

    const-string/jumbo v1, "sphduP"

    const-string v1, "adPush"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v5

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x7

    iput-wide v5, p0, Lcom/tencent/android/tpush/service/protocol/j;->n:J

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string/jumbo v1, "reseverId"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v5

    const/4 v9, 0x0

    const/4 v8, 0x2

    iput-wide v5, p0, Lcom/tencent/android/tpush/service/protocol/j;->o:J

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string v1, "aqtasmg"

    const-string/jumbo v1, "stgmtaa"

    const/4 v9, 0x3

    const-string/jumbo v1, "stsagTa"

    const-string/jumbo v1, "statTag"

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    iput-object v1, p0, Lcom/tencent/android/tpush/service/protocol/j;->p:Ljava/lang/String;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string v1, "gpudoro"

    const/4 v9, 0x1

    const-string/jumbo v1, "pdrmogu"

    const-string v1, "groupId"

    const/4 v9, 0x1

    const/4 v8, 0x3

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x2

    const/4 v8, 0x0

    iput-object v1, p0, Lcom/tencent/android/tpush/service/protocol/j;->r:Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string/jumbo v1, "ytpeotTbga"

    const-string/jumbo v1, "yegtTbtape"

    const/4 v9, 0x2

    const-string/jumbo v1, "treyebptag"

    const-string/jumbo v1, "targetType"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v5

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x7

    iput-wide v5, p0, Lcom/tencent/android/tpush/service/protocol/j;->t:J

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x6

    const-string/jumbo v1, "usuroe"

    const/4 v9, 0x1

    const-string/jumbo v1, "urouse"

    const-string/jumbo v1, "source"

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {p1, v1, v2, v3}, Lorg/json/JSONObject;->optLong(Ljava/lang/String;J)J

    move-result-wide v1

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x1

    iput-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/j;->u:J

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-string/jumbo v1, "vpIokdep"

    const-string v1, "deveIokp"

    const/4 v9, 0x3

    const-string/jumbo v1, "qoerkevd"

    const-string/jumbo v1, "revokeId"

    const/4 v9, 0x6

    invoke-virtual {p1, v1, v4}, Lorg/json/JSONObject;->optInt(Ljava/lang/String;I)I

    move-result v1

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x1

    iput v1, p0, Lcom/tencent/android/tpush/service/protocol/j;->v:I

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    const-string/jumbo v1, "mdttplIeqa"

    const/4 v9, 0x6

    const-string v1, "apsttemdeI"

    const-string/jumbo v1, "templateId"

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x7

    iput-object v1, p0, Lcom/tencent/android/tpush/service/protocol/j;->w:Ljava/lang/String;

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string v1, "dsemaIr"

    const-string/jumbo v1, "tIsreda"

    const/4 v9, 0x3

    const-string v1, "acIeodr"

    const-string/jumbo v1, "traceId"

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->optString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/service/protocol/j;->x:Ljava/lang/String;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    return-void
.end method
