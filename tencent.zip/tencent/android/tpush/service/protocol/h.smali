.class public Lcom/tencent/android/tpush/service/protocol/h;
.super Ljava/lang/Object;


# instance fields
.field public a:Ljava/lang/String;

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;


# virtual methods
.method public a()Lorg/json/JSONObject;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " Ssob@@~o @.@o~ @ KM d/@@~bo@i  @~  r@~v@/ bc~~ o~@@i@a~~ @i@~ o@~~l~~~ t~u ~@ sl4y-f~ @t~@n~1fm"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string/jumbo v1, "sids"

    const-string/jumbo v1, "issd"

    const/4 v4, 0x6

    const-string/jumbo v1, "isds"

    const-string/jumbo v1, "ssid"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/h;->a:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string v1, "dbsmi"

    const-string/jumbo v1, "sbsdi"

    const/4 v4, 0x4

    const-string v1, "bssid"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/h;->b:Ljava/lang/String;

    const/4 v3, 0x2

    xor-int/2addr v4, v3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v1, "acm"

    const-string/jumbo v1, "mac"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/h;->c:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v1, "msitof"

    const-string/jumbo v1, "wstmif"

    const/4 v4, 0x6

    const-string/jumbo v1, "itfswb"

    const-string/jumbo v1, "wflist"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/h;->d:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    return-object v0
.end method
