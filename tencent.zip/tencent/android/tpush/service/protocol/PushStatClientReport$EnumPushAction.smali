.class public final enum Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;
.super Ljava/lang/Enum;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "EnumPushAction"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

.field public static final enum PUSH_ACTION_MOBILE_APP_RECEIVED:Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

.field public static final enum PUSH_ACTION_MOBILE_CLEAN_UP:Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

.field public static final enum PUSH_ACTION_MOBILE_SERVICE_RECEIVED:Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

.field public static final enum PUSH_ACTION_MOBILE_USER_CLICK:Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;


# instance fields
.field private type:J


# direct methods
.method static constructor <clinit>()V
    .locals 13

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x0

    new-instance v0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x5

    const-wide/16 v1, 0x4

    const-wide/16 v1, 0x4

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x1

    const-string v3, "IHsEP__DIMVOE__BEAROICRTSUSEEECVCIL"

    const/4 v12, 0x6

    const-string v3, "_VsDIEOOCTRNIC_IBHEMEEEERC_P_ULSAIS"

    const-string v3, "PUSH_ACTION_MOBILE_SERVICE_RECEIVED"

    const/4 v12, 0x0

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x1

    invoke-direct {v0, v3, v4, v1, v2}, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;-><init>(Ljava/lang/String;IJ)V

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x2

    sput-object v0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;->PUSH_ACTION_MOBILE_SERVICE_RECEIVED:Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v12, 0x5

    const/4 v11, 0x2

    new-instance v1, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x1

    const-wide/16 v2, 0x8

    const-wide/16 v2, 0x8

    const/4 v12, 0x0

    const-wide/16 v2, 0x8

    const-wide/16 v2, 0x8

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x2

    const-string v5, "HOLmRNPCIP_B_EECAPmDIS_OUIEE_VM"

    const-string v5, "PDEm_OOUE_NLPCABEIARECI_PMIHVS_"

    const/4 v12, 0x1

    const-string v5, "ICNEoLECAO_DPE_BPEOSHP_ARIMIT_V"

    const-string v5, "PUSH_ACTION_MOBILE_APP_RECEIVED"

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x0

    const/4 v6, 0x1

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-direct {v1, v5, v6, v2, v3}, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;-><init>(Ljava/lang/String;IJ)V

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x7

    sput-object v1, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;->PUSH_ACTION_MOBILE_APP_RECEIVED:Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x4

    new-instance v2, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x6

    const-wide/16 v7, 0x10

    const-wide/16 v7, 0x10

    const/4 v12, 0x3

    const-wide/16 v7, 0x10

    const-wide/16 v7, 0x10

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    const-string v3, "TE_LAb_EC_IUHSoMICCBPK_RNUOSO"

    const-string v3, "OHRCoSEOMKULU__CBAE_CI_TIPNSL"

    const/4 v12, 0x2

    const-string v3, "AICCOLuCSIS_L_TUKUOE__HNEMRBI"

    const-string v3, "PUSH_ACTION_MOBILE_USER_CLICK"

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x2

    const/4 v5, 0x2

    const/4 v12, 0x0

    const/4 v11, 0x4

    invoke-direct {v2, v3, v5, v7, v8}, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;-><init>(Ljava/lang/String;IJ)V

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x1

    sput-object v2, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;->PUSH_ACTION_MOBILE_USER_CLICK:Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x7

    new-instance v3, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x0

    const-wide/16 v7, 0x20

    const-wide/16 v7, 0x20

    const/4 v12, 0x5

    const-wide/16 v7, 0x20

    const-wide/16 v7, 0x20

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x0

    const-string v9, "NHCOCbAIBT__SUUNLL_MOEPIE_A"

    const/4 v12, 0x7

    const-string v9, "UNUBLLOpMAAOHTEP_IP_S_NCEIC"

    const-string v9, "PUSH_ACTION_MOBILE_CLEAN_UP"

    const/4 v12, 0x6

    const/4 v10, 0x4

    const/4 v12, 0x6

    const/4 v10, 0x3

    const/4 v12, 0x4

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-direct {v3, v9, v10, v7, v8}, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;-><init>(Ljava/lang/String;IJ)V

    const/4 v12, 0x2

    const/4 v11, 0x6

    sput-object v3, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;->PUSH_ACTION_MOBILE_CLEAN_UP:Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v12, 0x4

    const/4 v11, 0x6

    const/4 v12, 0x2

    const/4 v7, 0x4

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x2

    new-array v7, v7, [Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v12, 0x4

    const/4 v11, 0x3

    aput-object v0, v7, v4

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x2

    aput-object v1, v7, v6

    const/4 v12, 0x7

    const/4 v11, 0x1

    const/4 v12, 0x0

    aput-object v2, v7, v5

    aput-object v3, v7, v10

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x3

    sput-object v7, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;->$VALUES:[Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x1

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;IJ)V
    .locals 2
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "(J)V"
        }
    .end annotation

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    iput-wide p3, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;->type:J

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~.~~@yooq  ~@ -  4io/ovSllt~@@n@c dt@~@/b @@@mM~ b~@@~~~ii@a @K~~1f u @ ~~ ~@  @~f~ s~~@o@ ~o~br"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-class v0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const-class v0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v1, 0x7

    move v2, v1

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    check-cast p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-object p0
.end method

.method public static values()[Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;->$VALUES:[Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, [Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;->clone()Ljava/lang/Object;

    move-result-object v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast v0, [Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public getType()J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x4

    iget-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;->type:J

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-wide v0
.end method
