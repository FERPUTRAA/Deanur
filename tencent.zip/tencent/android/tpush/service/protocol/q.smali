.class public Lcom/tencent/android/tpush/service/protocol/q;
.super Ljava/lang/Object;


# instance fields
.field a:I

.field b:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x0

    iput v0, p0, Lcom/tencent/android/tpush/service/protocol/q;->a:I

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v0, 0x0

    shr-int/2addr v2, v0

    const/4 v1, 0x1

    move v2, v1

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/q;->b:Ljava/lang/String;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method


# virtual methods
.method public a()Lorg/json/JSONObject;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, " ds Mi@@~ @ ~@yvs  ~ub@~@@-~@@4 ~Ktoo~ boi~~fo~l@i~~n~@Sf@@~@1@m~ ~/ @@~ ~.o crt~ oa@@/   ~~bl@ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/tencent/android/tpush/service/protocol/q;->b:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    const/4 v0, 0x0

    const/4 v4, 0x0

    return-object v0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    new-instance v0, Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo v1, "ypumcocetTs"

    const-string v1, "cTsetcounyp"

    const/4 v4, 0x2

    const-string/jumbo v1, "utyooeapTnc"

    const-string v1, "accountType"

    const/4 v4, 0x7

    iget v2, p0, Lcom/tencent/android/tpush/service/protocol/q;->a:I

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo v1, "uaotcbc"

    const-string v1, "account"

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/q;->b:Ljava/lang/String;

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    return-object v0
.end method

.method public a(I)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x3

    iput p1, p0, Lcom/tencent/android/tpush/service/protocol/q;->a:I

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/service/protocol/q;->b:Ljava/lang/String;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method
