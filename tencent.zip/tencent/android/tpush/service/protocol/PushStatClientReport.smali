.class public Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;
    }
.end annotation


# instance fields
.field public a:J

.field public b:J

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:J

.field public f:J

.field public g:Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

.field public h:J

.field public i:Ljava/lang/String;

.field public j:J

.field public k:Ljava/lang/String;


# virtual methods
.method public a()Lorg/json/JSONObject;
    .locals 8

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v6, "@ms  ~  ~~@~~~la oo/~S@db o@~Mi@~~c-~ ~~~  ~ .sff~ @r   @b ~@u~~~o@@o~@~yiil@@@@@  @b4vtt1n@@@oK"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x0

    new-instance v0, Lorg/json/JSONObject;

    const/4 v7, 0x3

    const/4 v6, 0x6

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string v1, "dmsmI"

    const-string/jumbo v1, "mgsId"

    const/4 v7, 0x5

    const-string v1, "dImgo"

    const-string/jumbo v1, "msgId"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;->a:J

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string v1, "daemcIss"

    const-string v1, "dccaIbss"

    const-string v1, "accessId"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;->b:J

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string v1, "ecsKoauys"

    const-string/jumbo v1, "yscaosKce"

    const/4 v7, 0x1

    const-string/jumbo v1, "yKasescpc"

    const-string v1, "accessKey"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;->c:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string/jumbo v1, "nktqo"

    const-string v1, "bntko"

    const/4 v7, 0x6

    const-string/jumbo v1, "tksoe"

    const-string/jumbo v1, "token"

    const/4 v7, 0x4

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;->d:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x3

    const/4 v6, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;->e:J

    const/4 v6, 0x4

    and-int/2addr v7, v6

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v7, 0x2

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    div-long/2addr v1, v3

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string v5, "epTmhsim"

    const-string/jumbo v5, "pushTime"

    const/4 v7, 0x4

    const/4 v6, 0x6

    invoke-virtual {v0, v5, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;->f:J

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    div-long/2addr v1, v3

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string/jumbo v3, "upiaotstm"

    const-string/jumbo v3, "msatteupi"

    const/4 v7, 0x1

    const-string v3, "etsmmbatp"

    const-string/jumbo v3, "timestamp"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v0, v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;->g:Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport$EnumPushAction;->getType()J

    move-result-wide v1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo v3, "phpuoAutis"

    const-string/jumbo v3, "uphsociptA"

    const/4 v7, 0x0

    const-string/jumbo v3, "tphucnipoA"

    const-string/jumbo v3, "pushAction"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0, v3, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x2

    const-string/jumbo v1, "sqyqeTm"

    const-string/jumbo v1, "mqeTgys"

    const/4 v7, 0x4

    const-string/jumbo v1, "msgType"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;->h:J

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x3

    const-string/jumbo v1, "pdsrosu"

    const-string/jumbo v1, "rpsgodu"

    const/4 v7, 0x5

    const-string/jumbo v1, "odgmrup"

    const-string v1, "groupId"

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;->i:Ljava/lang/String;

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string/jumbo v1, "upmaoChhnne"

    const-string/jumbo v1, "ushmahCnnep"

    const/4 v7, 0x5

    const-string v1, "hsCenbuplnh"

    const-string/jumbo v1, "pushChannel"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;->j:J

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string v1, "Vdkeniuroo"

    const-string/jumbo v1, "kVoiornsed"

    const/4 v7, 0x0

    const-string/jumbo v1, "ideksVoprn"

    const-string/jumbo v1, "sdkVersion"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;->k:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    return-object v0
.end method

.method public toString()Ljava/lang/String;
    .locals 3

    :try_start_0
    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/service/protocol/PushStatClientReport;->a()Lorg/json/JSONObject;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x4

    goto :goto_0

    :catch_0
    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string v0, "EJocSNepqnxbt"

    const-string v0, "exJtNbEniSpoc"

    const-string/jumbo v0, "onsOptSNxJiec"

    const-string v0, "JSONException"

    :goto_0
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method
