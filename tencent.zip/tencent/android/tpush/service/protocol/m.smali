.class public Lcom/tencent/android/tpush/service/protocol/m;
.super Lcom/tencent/android/tpush/service/protocol/d;


# instance fields
.field public A:Ljava/lang/String;

.field public B:Ljava/lang/String;

.field public C:Ljava/lang/String;

.field public D:Ljava/lang/String;

.field public E:I

.field public F:Lcom/tencent/android/tpush/service/protocol/g;

.field public G:I

.field public H:J

.field public I:Z

.field public J:Z

.field public K:Ljava/lang/String;

.field public L:Z

.field public M:Ljava/lang/String;

.field public N:Ljava/lang/String;

.field public a:J

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:Ljava/lang/String;

.field public f:S

.field public g:S

.field public h:Lcom/tencent/android/tpush/service/protocol/f;

.field public i:S

.field public j:B

.field public k:Lcom/tencent/android/tpush/service/protocol/h;

.field public l:S

.field public m:Ljava/lang/String;

.field public n:Ljava/lang/String;

.field public o:Ljava/lang/String;

.field public p:J

.field public q:J

.field public r:J

.field public s:J

.field public t:J

.field public u:J

.field public v:Ljava/lang/String;

.field public w:J

.field public x:J

.field public y:Ljava/lang/String;

.field public z:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 7

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/d;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/m;->a:J

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v6, 0x4

    const/4 v5, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->b:Ljava/lang/String;

    const/4 v5, 0x2

    and-int/2addr v6, v5

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->c:Ljava/lang/String;

    const/4 v5, 0x6

    move v6, v5

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->d:Ljava/lang/String;

    const/4 v6, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->e:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v3, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x6

    iput-short v3, p0, Lcom/tencent/android/tpush/service/protocol/m;->f:S

    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput-short v3, p0, Lcom/tencent/android/tpush/service/protocol/m;->g:S

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    const/4 v4, 0x0

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput-object v4, p0, Lcom/tencent/android/tpush/service/protocol/m;->h:Lcom/tencent/android/tpush/service/protocol/f;

    const/4 v5, 0x7

    xor-int/2addr v6, v5

    iput-short v3, p0, Lcom/tencent/android/tpush/service/protocol/m;->i:S

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    iput-byte v3, p0, Lcom/tencent/android/tpush/service/protocol/m;->j:B

    const/4 v6, 0x3

    iput-object v4, p0, Lcom/tencent/android/tpush/service/protocol/m;->k:Lcom/tencent/android/tpush/service/protocol/h;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    iput-short v3, p0, Lcom/tencent/android/tpush/service/protocol/m;->l:S

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x3

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->m:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->n:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->o:Ljava/lang/String;

    const/4 v5, 0x5

    move v6, v5

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/m;->p:J

    const/4 v6, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/m;->q:J

    const/4 v5, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/m;->r:J

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/m;->s:J

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/m;->t:J

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/m;->u:J

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->v:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/m;->w:J

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/m;->x:J

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->y:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->z:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->A:Ljava/lang/String;

    const/4 v5, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x7

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->B:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->C:Ljava/lang/String;

    const/4 v6, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->D:Ljava/lang/String;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    iput v3, p0, Lcom/tencent/android/tpush/service/protocol/m;->E:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    iput-object v4, p0, Lcom/tencent/android/tpush/service/protocol/m;->F:Lcom/tencent/android/tpush/service/protocol/g;

    const/4 v6, 0x7

    iput v3, p0, Lcom/tencent/android/tpush/service/protocol/m;->G:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/m;->H:J

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v0, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    iput-boolean v0, p0, Lcom/tencent/android/tpush/service/protocol/m;->I:Z

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    iput-boolean v3, p0, Lcom/tencent/android/tpush/service/protocol/m;->J:Z

    const/4 v5, 0x5

    move v6, v5

    iput-object v4, p0, Lcom/tencent/android/tpush/service/protocol/m;->K:Ljava/lang/String;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    iput-boolean v3, p0, Lcom/tencent/android/tpush/service/protocol/m;->L:Z

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x0

    return-void
.end method

.method public static a(Landroid/content/Context;Landroid/content/Intent;Z)Lcom/tencent/android/tpush/service/protocol/m;
    .locals 19

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v0, p0

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    move-object/from16 v1, p1

    const-string/jumbo v2, "soslaay"

    const-string v2, "apsoyla"

    const-string v2, "aypmaod"

    const-string/jumbo v2, "payload"

    const-string/jumbo v3, "lru"

    const-string/jumbo v3, "url"

    const-string/jumbo v3, "url"

    const-string v4, ","

    const-string v4, ","

    const-string v4, ","

    const-string v4, ","

    const/4 v5, 0x0

    const-string v6, "egqmoR"

    const-string/jumbo v6, "qeRmRg"

    const-string v6, "gRRqeb"

    const-string v6, "RegReq"

    if-nez v1, :cond_0

    const-string/jumbo v0, "nwettou lsilnua"

    const-string/jumbo v0, "wlnuos nteia lt"

    const-string/jumbo v0, "s ttnanpuewlnli"

    const-string/jumbo v0, "intent was null"

    invoke-static {v6, v0}, Lcom/tencent/tpns/baseapi/base/util/Logger;->w(Ljava/lang/String;Ljava/lang/String;)V

    return-object v5

    :cond_0
    if-nez v0, :cond_1

    const-string/jumbo v0, "osutx nnqeltla c"

    const-string v0, "context was null"

    invoke-static {v6, v0}, Lcom/tencent/tpns/baseapi/base/util/Logger;->w(Ljava/lang/String;Ljava/lang/String;)V

    return-object v5

    :cond_1
    :try_start_0
    new-instance v7, Lcom/tencent/android/tpush/service/protocol/m;

    invoke-direct {v7}, Lcom/tencent/android/tpush/service/protocol/m;-><init>()V

    const-string v8, "bIcdc"

    const-string v8, "accId"

    invoke-virtual {v1, v8}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v8

    iput-wide v8, v7, Lcom/tencent/android/tpush/service/protocol/m;->a:J

    const-string/jumbo v8, "uKcyca"

    const-string v8, "accKey"

    invoke-virtual {v1, v8}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    iput-object v8, v7, Lcom/tencent/android/tpush/service/protocol/m;->b:Ljava/lang/String;

    const-string/jumbo v8, "kaspcpea"

    const-string/jumbo v8, "mcpkeaap"

    const-string/jumbo v8, "kpemamNc"

    const-string/jumbo v8, "packName"

    invoke-virtual {v1, v8}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    iput-object v8, v7, Lcom/tencent/android/tpush/service/protocol/m;->K:Ljava/lang/String;

    const-string/jumbo v8, "teqiok"

    const-string/jumbo v8, "keqtci"

    const-string/jumbo v8, "ticket"

    invoke-virtual {v1, v8}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    iput-object v8, v7, Lcom/tencent/android/tpush/service/protocol/m;->e:Ljava/lang/String;

    const-string v8, "ctesTbtyke"

    const-string/jumbo v8, "tTsetykcpe"

    const-string/jumbo v8, "ptetTeukiy"

    const-string/jumbo v8, "ticketType"

    const/4 v9, -0x1

    invoke-virtual {v1, v8, v9}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v8

    int-to-short v8, v8

    iput-short v8, v7, Lcom/tencent/android/tpush/service/protocol/m;->f:S

    const-string/jumbo v8, "uqa"

    const-string v8, "auq"

    const-string v8, "aqu"

    const-string/jumbo v8, "qua"

    invoke-virtual {v1, v8}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    invoke-static {v8}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string/jumbo v9, "mpppre"

    const-string/jumbo v9, "raempp"

    const-string v9, "aVqprp"

    const-string v9, "appVer"

    invoke-virtual {v1, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    iput-object v9, v7, Lcom/tencent/android/tpush/service/protocol/m;->m:Ljava/lang/String;

    const-string v9, "eesesord"

    const-string v9, "esreodre"

    const-string v9, "evemders"

    const-string/jumbo v9, "reserved"

    invoke-virtual {v1, v9}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    invoke-static {v9}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    iput-object v9, v7, Lcom/tencent/android/tpush/service/protocol/m;->n:Ljava/lang/String;

    const-string v9, "eanlhbcnaC"

    const-string v9, "Cancoenlha"

    const-string v9, "accChannel"

    const-wide/16 v10, -0x1

    const-wide/16 v10, -0x1

    const-wide/16 v10, -0x1

    const-wide/16 v10, -0x1

    invoke-virtual {v1, v9, v10, v11}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v12

    iput-wide v12, v7, Lcom/tencent/android/tpush/service/protocol/m;->s:J

    invoke-virtual {v1, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const-string/jumbo v12, "orenhbtuek"

    const-string v12, "Throekunte"

    const-string/jumbo v12, "ohnoTkuere"

    const-string/jumbo v12, "otherToken"

    invoke-virtual {v1, v12}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    iput-object v12, v7, Lcom/tencent/android/tpush/service/protocol/m;->v:Ljava/lang/String;

    invoke-virtual {v1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v13, "PrusetTpyhoph"

    const-string/jumbo v13, "otherPushType"

    invoke-virtual {v1, v13, v10, v11}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v13

    iput-wide v13, v7, Lcom/tencent/android/tpush/service/protocol/m;->u:J

    const-string/jumbo v13, "uhehktopnpTyPoseOrpe"

    const-string/jumbo v13, "petenrkeqposyhuPTThO"

    const-string/jumbo v13, "otherPushTokenOpType"

    invoke-virtual {v1, v13, v10, v11}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v10

    iput-wide v10, v7, Lcom/tencent/android/tpush/service/protocol/m;->t:J

    const-string v10, "dila"

    const-string v10, "iald"

    const-string v10, "iald"

    const-string v10, "aidl"

    const/4 v11, 0x0

    invoke-virtual {v1, v10, v11}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v10

    iput-boolean v10, v7, Lcom/tencent/android/tpush/service/protocol/m;->J:Z

    const-string v10, "acsokhlnnTne"

    const-string/jumbo v10, "lennnoakqhTc"

    const-string/jumbo v10, "nTnmkeeloahn"

    const-string v10, "channelToken"

    invoke-virtual {v1, v10}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v10

    const-string/jumbo v13, "yashncepleT"

    const-string v13, "eeTloycnpha"

    const-string v13, "channelType"

    invoke-virtual {v1, v13}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const-string/jumbo v14, "iivcmbdgonee"

    const-string v14, "evcmgdieonie"

    const-string v14, "Regiecuideno"

    const-string v14, "deviceRegion"

    invoke-virtual {v1, v14}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    invoke-static/range {p0 .. p0}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getInstance(Landroid/content/Context;)Lcom/tencent/tpns/baseapi/base/util/CloudManager;

    move-result-object v15
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_5

    move-object/from16 v16, v6

    move-object/from16 v16, v6

    move-object/from16 v16, v6

    move-object/from16 v16, v6

    :try_start_1
    invoke-virtual {v15}, Lcom/tencent/tpns/baseapi/base/util/CloudManager;->getCloudVersion()J

    move-result-wide v5

    iput-wide v5, v7, Lcom/tencent/android/tpush/service/protocol/m;->H:J
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_4

    :try_start_2
    invoke-static {v8}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_2

    iget-wide v5, v7, Lcom/tencent/android/tpush/service/protocol/m;->a:J

    invoke-static {v0, v5, v6, v8}, Lcom/tencent/android/tpush/service/cache/CacheManager;->setQua(Landroid/content/Context;JLjava/lang/String;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    :catchall_0
    :cond_2
    :try_start_3
    iget-object v5, v7, Lcom/tencent/android/tpush/service/protocol/m;->K:Ljava/lang/String;

    invoke-virtual {v0, v5, v11}, Landroid/content/Context;->createPackageContext(Ljava/lang/String;I)Landroid/content/Context;

    move-result-object v5

    invoke-static {v5}, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->getEncryptAPKSignature(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, v7, Lcom/tencent/android/tpush/service/protocol/m;->d:Ljava/lang/String;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    :catchall_1
    :try_start_4
    invoke-static {}, Lcom/tencent/android/tpush/service/util/a;->a()Ljava/lang/String;

    move-result-object v5

    iput-object v5, v7, Lcom/tencent/android/tpush/service/protocol/m;->c:Ljava/lang/String;

    const-string/jumbo v5, "p9.o3.."

    const-string v5, ".943o.."

    const-string v5, "3q..1.9"

    const-string v5, "1.4.3.9"

    iput-object v5, v7, Lcom/tencent/android/tpush/service/protocol/m;->z:Ljava/lang/String;

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v5

    invoke-static {v5}, Lcom/tencent/android/tpush/service/c;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/service/protocol/f;

    move-result-object v5

    iput-object v5, v7, Lcom/tencent/android/tpush/service/protocol/m;->h:Lcom/tencent/android/tpush/service/protocol/f;

    if-eqz v5, :cond_3

    const-string/jumbo v5, "trssds5NMbt"

    const-string/jumbo v5, "tNdstbsrMl5"

    const-string v5, "5rMmdltasts"

    const-string/jumbo v5, "lastNMd5str"

    invoke-virtual {v1, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    iput-object v5, v7, Lcom/tencent/android/tpush/service/protocol/m;->N:Ljava/lang/String;

    :cond_3
    const/4 v5, 0x4

    iput-short v5, v7, Lcom/tencent/android/tpush/service/protocol/m;->i:S

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    iput-wide v5, v7, Lcom/tencent/android/tpush/service/protocol/m;->r:J

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    const-wide/16 v17, 0x3e8

    const-wide/16 v17, 0x3e8

    const-wide/16 v17, 0x3e8

    div-long v5, v5, v17

    iput-wide v5, v7, Lcom/tencent/android/tpush/service/protocol/m;->q:J

    invoke-static {v9}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v5

    if-nez v5, :cond_5

    new-instance v5, Lorg/json/JSONObject;

    invoke-direct {v5}, Lorg/json/JSONObject;-><init>()V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_4

    :try_start_5
    invoke-virtual {v5, v3, v9}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    invoke-static {v12}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    if-nez v3, :cond_4

    invoke-virtual {v5, v2, v12}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_5
    .catch Lorg/json/JSONException; {:try_start_5 .. :try_end_5} :catch_0
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    :catch_0
    :cond_4
    :try_start_6
    invoke-virtual {v5}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    iput-object v2, v7, Lcom/tencent/android/tpush/service/protocol/m;->y:Ljava/lang/String;

    :cond_5
    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v2

    invoke-static {v2}, Lcom/tencent/android/tpush/service/cache/CacheManager;->getGuid(Landroid/content/Context;)J

    move-result-wide v2

    iput-wide v2, v7, Lcom/tencent/android/tpush/service/protocol/m;->p:J

    if-eqz v10, :cond_6

    if-eqz v13, :cond_6

    iput-object v10, v7, Lcom/tencent/android/tpush/service/protocol/m;->A:Ljava/lang/String;

    iput-object v13, v7, Lcom/tencent/android/tpush/service/protocol/m;->B:Ljava/lang/String;

    iput-object v14, v7, Lcom/tencent/android/tpush/service/protocol/m;->C:Ljava/lang/String;

    :cond_6
    invoke-virtual/range {p0 .. p0}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v0

    iput-object v0, v7, Lcom/tencent/android/tpush/service/protocol/m;->D:Ljava/lang/String;
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_4

    :try_start_7
    const-string/jumbo v0, "vAiqoDuo.m..dtyAcqteac."

    const-string/jumbo v0, "t.Aqmou.yctqavDAcd..sie"

    const-string v0, "com.qq.e.ads.ADActivity"

    invoke-static {v0}, Ljava/lang/Class;->forName(Ljava/lang/String;)Ljava/lang/Class;
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_2

    const/4 v0, 0x1

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    goto :goto_0

    :catchall_2
    :try_start_8
    const-string/jumbo v0, "oier br dg tosf tn orpAtrdgAdetn eeuR"

    const-string v0, " t,dnnrpret dAr f tiu RdA goerseoegto"

    const-string v0, " df neune grots,utir  eeAodd RrogrAtt"

    const-string v0, "Register get tAd error, tAd not found"
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_4

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    :try_start_9
    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    move v0, v11

    move v0, v11

    move v0, v11

    move v0, v11

    :goto_0
    iput v0, v7, Lcom/tencent/android/tpush/service/protocol/m;->E:I

    invoke-static {}, Lcom/tencent/android/tpush/d/a;->a()I

    move-result v0

    iput v0, v7, Lcom/tencent/android/tpush/service/protocol/m;->G:I

    const-string/jumbo v0, "qshdtegpeRs"

    const-string v0, "ahtsdRseqge"

    const-string v0, "Risehdetqgs"

    const-string v0, "hasRegisted"

    invoke-virtual {v1, v0, v11}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v0

    iput-boolean v0, v7, Lcom/tencent/android/tpush/service/protocol/m;->L:Z

    const-string/jumbo v0, "snsok"

    const-string/jumbo v0, "kosen"

    const-string v0, "eknmo"

    const-string/jumbo v0, "token"

    invoke-virtual {v1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    iput-object v0, v7, Lcom/tencent/android/tpush/service/protocol/m;->M:Ljava/lang/String;

    new-instance v0, Ljava/lang/StringBuilder;

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const-string v1, "etRro(igm"

    const-string v1, "etemirg(R"

    const-string v1, "(reRebsgt"

    const-string v1, "Register("

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v5, v7, Lcom/tencent/android/tpush/service/protocol/m;->a:J

    invoke-virtual {v0, v5, v6}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, v7, Lcom/tencent/android/tpush/service/protocol/m;->c:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, v7, Lcom/tencent/android/tpush/service/protocol/m;->e:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-short v1, v7, Lcom/tencent/android/tpush/service/protocol/m;->f:S

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string v1, ",o:yoa)dlp "

    const-string/jumbo v1, "yd:po,u la)"

    const-string v1, "),payload: "

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, v7, Lcom/tencent/android/tpush/service/protocol/m;->y:Ljava/lang/String;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v1, "land cnpi e"

    const-string v1, " channel id"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-wide v3, v7, Lcom/tencent/android/tpush/service/protocol/m;->s:J

    invoke-virtual {v0, v3, v4}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->vv(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_9
    .catchall {:try_start_9 .. :try_end_9} :catchall_3

    return-object v7

    :catchall_3
    move-exception v0

    goto :goto_1

    :catchall_4
    move-exception v0

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    move-object/from16 v2, v16

    goto :goto_1

    :catchall_5
    move-exception v0

    move-object v2, v6

    move-object v2, v6

    move-object v2, v6

    move-object v2, v6

    :goto_1
    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "rirge  rqob rr>ts>"

    const-string/jumbo v3, "rirg b>ret rse >or"

    const-string v3, " >srtgerie rre>os "

    const-string v3, ">> register error "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "isgmo- >rer> terrr e"

    const-string/jumbo v3, "togeeiurr >>rse r r-"

    const-string v3, " e>>oirseo trg rr->r"

    const-string v3, ">> register error-> "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v0}, Lcom/tencent/android/tpush/logging/TLogger;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x0

    return-object v1
.end method


# virtual methods
.method public a()Lcom/tencent/android/tpush/service/protocol/MessageType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "to@ ob~~Ki@~~ o@m~~S@t  My~ ao c @4@~@ u@of~ri ~b~~ @~n1l~s@ /bl @~v ~b@@@~~~ o~@@i .f@@d-/~@@ ~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/service/protocol/MessageType;->REGISTER:Lcom/tencent/android/tpush/service/protocol/MessageType;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    return-object v0
.end method

.method public a(Landroid/content/Context;)Lorg/json/JSONObject;
    .locals 8

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x6

    new-instance v0, Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x0

    const-string/jumbo v1, "sdcesIup"

    const-string v1, "csecIsdp"

    const/4 v7, 0x6

    const-string/jumbo v1, "sIcsedap"

    const-string v1, "accessId"

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->a:J

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string v1, "aceeqKsyq"

    const-string v1, "Kcssaeeyq"

    const/4 v7, 0x1

    const-string/jumbo v1, "sKsycecse"

    const-string v1, "accessKey"

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->b:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v1, "edImcies"

    const-string v1, "dvseIiec"

    const/4 v7, 0x7

    const-string/jumbo v1, "ieveoddI"

    const-string v1, "deviceId"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->c:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x1

    shl-int/2addr v7, v6

    const-string/jumbo v1, "perpCba"

    const-string/jumbo v1, "peCmapr"

    const-string/jumbo v1, "repCapu"

    const-string v1, "appCert"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->d:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string/jumbo v1, "tpitec"

    const-string v1, "eittoc"

    const-string v1, "ecqikt"

    const-string/jumbo v1, "ticket"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->e:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string v1, "eksTbitycp"

    const-string v1, "ceytkbpTie"

    const/4 v7, 0x6

    const-string/jumbo v1, "yeTmkttpec"

    const-string/jumbo v1, "ticketType"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-short v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->f:S

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const-string v1, "cpudoeeyvi"

    const-string/jumbo v1, "ydeeicuvep"

    const/4 v7, 0x4

    const-string v1, "deeyvbTiec"

    const-string v1, "deviceType"

    const/4 v6, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    iget-short v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->g:S

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/m;->h:Lcom/tencent/android/tpush/service/protocol/f;

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    if-eqz v1, :cond_0

    const/4 v6, 0x3

    or-int/2addr v7, v6

    const-string v2, "fpeveiudon"

    const-string v2, "cnoefidpev"

    const/4 v7, 0x0

    const-string v2, "cfveonipde"

    const-string v2, "deviceInfo"

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/protocol/f;->a()Lorg/json/JSONObject;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/m;->h:Lcom/tencent/android/tpush/service/protocol/f;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget v2, v1, Lcom/tencent/android/tpush/service/protocol/f;->t:I

    const/4 v7, 0x0

    iget-object v1, v1, Lcom/tencent/android/tpush/service/protocol/f;->u:Ljava/util/List;

    const/4 v7, 0x5

    const/4 v6, 0x4

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/service/util/c;->a(ILjava/util/List;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpush/service/protocol/m;->N:Ljava/lang/String;

    :cond_0
    const/4 v7, 0x7

    const-string/jumbo v1, "vqeqsin"

    const-string/jumbo v1, "rqvseni"

    const/4 v7, 0x2

    const-string/jumbo v1, "oessvri"

    const-string/jumbo v1, "version"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    iget-short v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->i:S

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x0

    const-string/jumbo v1, "kepmrdneytEs"

    const-string/jumbo v1, "pksncyteeErd"

    const/4 v7, 0x4

    const-string v1, "dntcopyryekE"

    const-string/jumbo v1, "keyEncrypted"

    const/4 v7, 0x5

    iget-byte v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->j:B

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/m;->k:Lcom/tencent/android/tpush/service/protocol/h;

    const/4 v7, 0x3

    if-eqz v1, :cond_1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string v2, "fmbeIbonmtu"

    const-string v2, "aftmboeunIm"

    const/4 v7, 0x2

    const-string/jumbo v2, "tumbIouelfa"

    const-string/jumbo v2, "mutableInfo"

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/protocol/h;->a()Lorg/json/JSONObject;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_1
    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string/jumbo v1, "oapdeuoptauTt"

    const-string/jumbo v1, "tuodoaupAetaT"

    const/4 v7, 0x4

    const-string/jumbo v1, "tTupgoaAqeaut"

    const-string/jumbo v1, "updateAutoTag"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x0

    iget-short v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->l:S

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo v1, "paesVbrpon"

    const/4 v7, 0x0

    const-string v1, "apsnrepoVi"

    const-string v1, "appVersion"

    const/4 v7, 0x5

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->m:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string/jumbo v1, "undmcile"

    const-string v1, "cilndeui"

    const/4 v7, 0x4

    const-string/jumbo v1, "idnioetc"

    const-string v1, "clientid"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->o:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string/jumbo v1, "onoprbcsnVe"

    const-string/jumbo v1, "rVcnnoepnso"

    const/4 v7, 0x6

    const-string/jumbo v1, "irnVeoucosn"

    const-string v1, "connVersion"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x5

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->r:J

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x4

    const-string/jumbo v1, "lhacnIqpd"

    const-string v1, "Iadnhlcnq"

    const/4 v7, 0x1

    const-string/jumbo v1, "nnIeladcq"

    const-string v1, "channelId"

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x7

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->s:J

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string v1, "PesyuesptokhrnphTOTo"

    const-string/jumbo v1, "rysooupPekeTTOnstphh"

    const/4 v7, 0x7

    const-string/jumbo v1, "phomTkueetpneTOPysho"

    const-string/jumbo v1, "otherPushTokenOpType"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->t:J

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string v1, "epyroooPenhkTmuseT"

    const-string/jumbo v1, "tpsmeokurTnhyTPeoe"

    const/4 v7, 0x0

    const-string v1, "eTepobsTyhhkonuter"

    const-string/jumbo v1, "otherPushTokenType"

    const/4 v6, 0x5

    const/4 v6, 0x0

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->u:J

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-string/jumbo v1, "okTonhueheouPs"

    const-string v1, "TheoouheskPnot"

    const/4 v7, 0x7

    const-string/jumbo v1, "oekurThptosnhP"

    const-string/jumbo v1, "otherPushToken"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->v:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    const-string/jumbo v1, "okerPbhhrC2cunetoT3"

    const-string v1, "hPuhtc2sqnorC3Tekro"

    const-string/jumbo v1, "otherPushTokenCrc32"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->w:J

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x3

    const-string/jumbo v1, "ocsnCkt32r"

    const-string/jumbo v1, "tokenCrc32"

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->x:J

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v6, 0x7

    shr-int/2addr v7, v6

    const-string/jumbo v1, "uermostPahDut"

    const-string/jumbo v1, "oPhtauuhDters"

    const/4 v7, 0x3

    const-string v1, "atsPoroDhhuta"

    const-string/jumbo v1, "otherPushData"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->y:Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v1, "Vneoibdpsr"

    const-string v1, "eVdokrnpis"

    const/4 v7, 0x7

    const-string/jumbo v1, "nVkdsouire"

    const-string/jumbo v1, "sdkVersion"

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->z:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/m;->A:Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    if-nez v1, :cond_2

    const/4 v6, 0x6

    shl-int/2addr v7, v6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/m;->B:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    if-nez v1, :cond_2

    const/4 v6, 0x0

    move v7, v6

    const-string v1, "eqannlnpehco"

    const-string v1, "eknnhonlqaec"

    const-string v1, "ealkocneqTnh"

    const-string v1, "channelToken"

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->A:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v6, 0x4

    move v7, v6

    const-string/jumbo v1, "npsTaheslen"

    const-string v1, "Tasleynhenp"

    const/4 v7, 0x5

    const-string/jumbo v1, "nhlmpyencea"

    const-string v1, "channelType"

    const/4 v7, 0x1

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->B:Ljava/lang/String;

    const/4 v7, 0x0

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string/jumbo v1, "ivRmoegceind"

    const-string v1, "ceRmeiindogv"

    const/4 v7, 0x0

    const-string v1, "ceodgbiineRv"

    const-string v1, "deviceRegion"

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->C:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/m;->D:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-nez v1, :cond_3

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string/jumbo v1, "maepaguPNp"

    const-string/jumbo v1, "pmaNoPeagp"

    const/4 v7, 0x4

    const-string v1, "NgaampPppk"

    const-string v1, "appPkgName"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->D:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_3
    const/4 v7, 0x5

    const-string v1, "dAt"

    const/4 v7, 0x6

    const-string v1, "Adt"

    const-string/jumbo v1, "tAd"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x4

    iget v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->E:I

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/m;->F:Lcom/tencent/android/tpush/service/protocol/g;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    if-eqz v1, :cond_4

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/protocol/g;->a()Z

    move-result v1

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    if-eqz v1, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/m;->F:Lcom/tencent/android/tpush/service/protocol/g;

    const/4 v7, 0x0

    const/4 v6, 0x7

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/protocol/g;->b()Lorg/json/JSONObject;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x3

    const-string v2, "efernnsiqofbeIo"

    const-string v2, "efeIsbennoorifr"

    const/4 v7, 0x7

    const-string/jumbo v2, "resfeoninefoVrs"

    const-string v2, "freeVersionInfo"

    const/4 v7, 0x0

    invoke-virtual {v0, v2, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_4
    const/4 v7, 0x0

    const/4 v6, 0x3

    const-string/jumbo v1, "kdSmu"

    const-string v1, "Sudkh"

    const/4 v7, 0x7

    const-string/jumbo v1, "wdhko"

    const-string v1, "hwSdk"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->G:I

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string/jumbo v1, "sVupobeonicl"

    const-string v1, "coVnleupoids"

    const/4 v7, 0x0

    const-string/jumbo v1, "sViuonuerold"

    const-string v1, "cloudVersion"

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/m;->H:J

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    const/4 v1, 0x1

    :try_start_0
    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string/jumbo v4, "iebqooTp"

    const-string/jumbo v4, "qTotoebi"

    const/4 v7, 0x1

    const-string/jumbo v4, "qTbeoomt"

    const-string v4, "bootTime"

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v2, v4}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v4

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v5, 0x0

    const/4 v7, 0x6

    invoke-virtual {v2, v5, v4}, Ljava/lang/String;->substring(II)Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string/jumbo v4, "ncsoorystde"

    const-string v4, "Coscodynetr"

    const/4 v7, 0x1

    const-string/jumbo v4, "rocmedytonu"

    const-string v4, "countryCode"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v2, v4}, Ljava/lang/String;->indexOf(Ljava/lang/String;)I

    move-result v4

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v2, v4}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->a()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-static {p1, v3}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->get(Landroid/content/Context;Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x4

    check-cast v3, Ljava/lang/String;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v2}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x3

    if-eqz v2, :cond_5

    const/4 v7, 0x2

    invoke-virtual {v2, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-eqz v3, :cond_5

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x2

    iput-boolean v5, p0, Lcom/tencent/android/tpush/service/protocol/m;->I:Z

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x5

    goto :goto_0

    :cond_5
    const/4 v6, 0x0

    const/4 v7, 0x0

    iput-boolean v1, p0, Lcom/tencent/android/tpush/service/protocol/m;->I:Z

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-array v3, v1, [Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/e/b/a;->a()Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v4, v2}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;->set(Ljava/lang/Object;)Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;

    move-result-object v2

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    aput-object v2, v3, v5

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-static {p1, v3}, Lcom/tencent/tpns/baseapi/base/util/CacheHelper;->set(Landroid/content/Context;[Lcom/tencent/tpns/baseapi/base/util/CacheHelper$Key;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x5

    goto :goto_0

    :catchall_0
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    iput-boolean v1, p0, Lcom/tencent/android/tpush/service/protocol/m;->I:Z

    :goto_0
    const/4 v7, 0x4

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string p1, "aiteompmt"

    const-string/jumbo p1, "tsemampti"

    const/4 v7, 0x3

    const-string/jumbo p1, "mptmsbeta"

    const-string/jumbo p1, "timestamp"

    const/4 v7, 0x0

    const/4 v6, 0x6

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/m;->q:J

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v0, p1, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    return-object v0
.end method

.method public b(Landroid/content/Context;)Z
    .locals 4

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/service/protocol/m;->a(Landroid/content/Context;)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v1, ":of dpuurxeeent"

    const-string/jumbo v1, "tunood efe:xper"

    const/4 v3, 0x1

    const-string v1, "eco edtpur:pfne"

    const-string/jumbo v1, "unexpected for:"

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x2

    const-string v0, "eiRgqbetqse"

    const-string/jumbo v0, "sReRebgeiqt"

    const/4 v3, 0x7

    const-string v0, "etseRResqgi"

    const-string v0, "RegisterReq"

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-boolean p1, p0, Lcom/tencent/android/tpush/service/protocol/m;->I:Z

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    return p1
.end method
