.class public Lcom/tencent/android/tpush/service/protocol/a;
.super Lcom/tencent/android/tpush/service/protocol/d;


# instance fields
.field public a:J

.field public b:Ljava/lang/String;

.field public c:I

.field public d:J

.field public e:Ljava/lang/String;

.field public f:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/tencent/android/tpush/service/protocol/q;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/d;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/a;->a:J

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string v2, ""

    const/4 v5, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x6

    const/4 v4, 0x4

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/a;->b:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    const/4 v3, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput v3, p0, Lcom/tencent/android/tpush/service/protocol/a;->c:I

    const/4 v5, 0x4

    const/4 v4, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/a;->d:J

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/a;->e:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    const/4 v0, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/a;->f:Ljava/util/ArrayList;

    const/4 v4, 0x7

    const/4 v4, 0x5

    return-void
.end method


# virtual methods
.method public a()Lcom/tencent/android/tpush/service/protocol/MessageType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "bMs~@oufv @m@@nS~~@ / ~@~o @ Kt4f~@/i@.c  ~~@~-o~@@ ~@ ~ ~@~ d~@l@~oribbi~   o@l~@  ~@~s~1a ~@ot"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/tencent/android/tpush/service/protocol/MessageType;->ACCOUNT:Lcom/tencent/android/tpush/service/protocol/MessageType;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public a(Landroid/content/Context;)Lorg/json/JSONObject;
    .locals 5

    const/4 v3, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    new-instance p1, Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v0, "cIsmedca"

    const-string/jumbo v0, "scsIaedc"

    const-string/jumbo v0, "sIdaosce"

    const-string v0, "accessId"

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/a;->a:J

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v0, "cKeyabmec"

    const-string v0, "acsmKycee"

    const/4 v4, 0x1

    const-string v0, "ecacssuey"

    const-string v0, "accessKey"

    const/4 v4, 0x4

    const/4 v3, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/a;->b:Ljava/lang/String;

    const/4 v3, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string v0, "Topepoapety"

    const-string v0, "eeeooyTpatp"

    const/4 v4, 0x1

    const-string v0, "eoparpeyqte"

    const-string/jumbo v0, "operateType"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/service/protocol/a;->c:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo v0, "pbsitsatm"

    const-string/jumbo v0, "ptiasbtme"

    const/4 v4, 0x3

    const-string v0, "eiamttmmp"

    const-string/jumbo v0, "timestamp"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/a;->d:J

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo v0, "nsudoeisor"

    const-string/jumbo v0, "iesoVnursd"

    const/4 v4, 0x5

    const-string/jumbo v0, "sndrkbeVis"

    const-string/jumbo v0, "sdkVersion"

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/a;->e:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/service/protocol/a;->f:Ljava/util/ArrayList;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    new-instance v0, Lorg/json/JSONArray;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/a;->f:Ljava/util/ArrayList;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_0
    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz v2, :cond_1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x1

    check-cast v2, Lcom/tencent/android/tpush/service/protocol/q;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v2}, Lcom/tencent/android/tpush/service/protocol/q;->a()Lorg/json/JSONObject;

    move-result-object v2

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v2}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string/jumbo v1, "ocuyptuntsce"

    const-string v1, "cuetnctposAy"

    const/4 v4, 0x6

    const-string/jumbo v1, "otsuycppcetn"

    const-string/jumbo v1, "typeAccounts"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1, v1, v0}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_2
    const/4 v4, 0x0

    const/4 v3, 0x6

    return-object p1
.end method
