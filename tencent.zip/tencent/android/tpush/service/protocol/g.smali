.class public Lcom/tencent/android/tpush/service/protocol/g;
.super Ljava/lang/Object;


# instance fields
.field public a:J

.field public b:Ljava/lang/String;

.field public c:Ljava/lang/String;


# virtual methods
.method public a()Z
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, " @s~c  @ oa@~@i~f~ @Mmuvfn@oS@@yb@@tio ~o~ @ ~@l@o r@.@~it@@~ ~/@1K  ~~~~@~4s~~ b@d- ~l ~b~o~  /"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    iget-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/g;->a:J

    const/4 v5, 0x6

    const/4 v4, 0x6

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x2

    cmp-long v0, v0, v2

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-lez v0, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/service/protocol/g;->b:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/service/protocol/g;->b:Ljava/lang/String;

    const/4 v4, 0x3

    move v5, v4

    const-string v1, "0"

    const-string v1, "0"

    const/4 v5, 0x0

    const-string v1, "0"

    const-string v1, "0"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/service/protocol/g;->c:Ljava/lang/String;

    const/4 v5, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-nez v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    const/4 v0, 0x1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    const/4 v0, 0x0

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x0

    return v0
.end method

.method public b()Lorg/json/JSONObject;
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x7

    new-instance v0, Lorg/json/JSONObject;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v5, 0x5

    const-string v1, "essmccad"

    const-string v1, "essccdas"

    const/4 v5, 0x2

    const-string v1, "ceisoacs"

    const-string v1, "accessid"

    const/4 v5, 0x5

    const/4 v4, 0x7

    iget-wide v2, p0, Lcom/tencent/android/tpush/service/protocol/g;->a:J

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    const-string/jumbo v1, "koemt"

    const-string v1, "bkeon"

    const-string/jumbo v1, "token"

    const/4 v5, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/g;->b:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string v1, "ahlncou"

    const-string v1, "cealonh"

    const/4 v5, 0x6

    const-string v1, "channel"

    const/4 v5, 0x7

    const/4 v4, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/service/protocol/g;->c:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v5, 0x3

    return-object v0
.end method
