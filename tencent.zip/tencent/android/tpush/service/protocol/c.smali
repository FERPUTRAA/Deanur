.class public abstract Lcom/tencent/android/tpush/service/protocol/c;
.super Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public abstract a()Lcom/tencent/android/tpush/service/protocol/MessageType;
.end method
