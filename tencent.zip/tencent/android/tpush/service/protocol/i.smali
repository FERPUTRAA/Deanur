.class public Lcom/tencent/android/tpush/service/protocol/i;
.super Lcom/tencent/android/tpush/service/protocol/d;


# instance fields
.field public a:J

.field public b:J

.field public c:J

.field public d:J

.field public e:J

.field public f:J

.field public g:Ljava/lang/String;

.field public h:Ljava/lang/String;

.field public i:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/d;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x2

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/i;->a:J

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/i;->b:J

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/i;->c:J

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/i;->d:J

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/i;->e:J

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/i;->f:J

    const/4 v3, 0x5

    const/4 v2, 0x2

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x7

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/i;->g:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/i;->h:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/i;->i:Ljava/lang/String;

    const/4 v3, 0x0

    const/4 v2, 0x7

    return-void
.end method


# virtual methods
.method public a()Lcom/tencent/android/tpush/service/protocol/MessageType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "y~s  @K ~ t~mb~s ~@  ~ co@vuo@b o@~~ ~f~~~f~ @ d~oi@/~@o b4@.n@~t@lS~@/a@r ~1@i@~-@@o~ @~~@M@il "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x5

    sget-object v0, Lcom/tencent/android/tpush/service/protocol/MessageType;->COMMON_REPORT:Lcom/tencent/android/tpush/service/protocol/MessageType;

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public a(Landroid/content/Context;)Lorg/json/JSONObject;
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x0

    new-instance p1, Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string/jumbo v0, "tpey"

    const-string/jumbo v0, "type"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/i;->a:J

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v3, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v0, "cIsmcdsa"

    const-string v0, "Isscacds"

    const/4 v4, 0x7

    const-string v0, "edcIossa"

    const-string v0, "accessId"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/i;->b:J

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string v0, "bsgmd"

    const-string/jumbo v0, "sdgmI"

    const/4 v4, 0x6

    const-string v0, "gumdI"

    const-string/jumbo v0, "msgId"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/i;->c:J

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string/jumbo v0, "taddcarpIso"

    const-string v0, "acsIotdrbad"

    const/4 v4, 0x5

    const-string/jumbo v0, "soacdtIrqad"

    const-string v0, "broadcastId"

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/i;->d:J

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v0, "bmsmsateTsmi"

    const-string/jumbo v0, "mtTmpbesmsai"

    const/4 v4, 0x5

    const-string/jumbo v0, "stemmsgipTmm"

    const-string/jumbo v0, "msgTimestamp"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/i;->e:J

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    const-string v0, "clientTimestamp"

    const/4 v3, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/i;->f:J

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string v0, "gms"

    const-string/jumbo v0, "msg"

    const-string/jumbo v0, "sgm"

    const-string/jumbo v0, "msg"

    const/4 v3, 0x7

    shl-int/2addr v4, v3

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/i;->g:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string v0, "ext"

    const/4 v4, 0x2

    const-string/jumbo v0, "tex"

    const-string v0, "ext"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/i;->h:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const-string v0, "Nmpaoeg"

    const-string v0, "Ngapemu"

    const/4 v4, 0x3

    const-string v0, "epmagbN"

    const-string/jumbo v0, "pkgName"

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/i;->i:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x3

    return-object p1
.end method
