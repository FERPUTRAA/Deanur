.class public Lcom/tencent/android/tpush/service/protocol/r;
.super Lcom/tencent/android/tpush/service/protocol/d;


# instance fields
.field public a:S

.field public b:J

.field public c:Ljava/lang/String;

.field public d:Ljava/lang/String;

.field public e:B

.field public f:B

.field public g:J

.field public h:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/d;-><init>()V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    const/4 v0, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x1

    iput-short v0, p0, Lcom/tencent/android/tpush/service/protocol/r;->a:S

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x5

    const-wide/16 v1, 0x0

    const-wide/16 v1, 0x0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/r;->b:J

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x5

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x6

    iput-object v3, p0, Lcom/tencent/android/tpush/service/protocol/r;->c:Ljava/lang/String;

    const/4 v5, 0x4

    iput-object v3, p0, Lcom/tencent/android/tpush/service/protocol/r;->d:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x6

    iput-byte v0, p0, Lcom/tencent/android/tpush/service/protocol/r;->e:B

    const/4 v5, 0x7

    const/4 v4, 0x1

    iput-byte v0, p0, Lcom/tencent/android/tpush/service/protocol/r;->f:B

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x7

    iput-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/r;->g:J

    const/4 v5, 0x6

    iput-object v3, p0, Lcom/tencent/android/tpush/service/protocol/r;->h:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x6

    return-void
.end method


# virtual methods
.method public a()Lcom/tencent/android/tpush/service/protocol/MessageType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "oasbv@ @@ d~M@t ~~@~@~y~~~~1i~@@l/@@n@  if~~-@~ ~t bbo u@~@~ ~~ K @o~ sc~m.f~@ @@oo~or@i /4l@  S"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/service/protocol/MessageType;->UNREGISTER:Lcom/tencent/android/tpush/service/protocol/MessageType;

    const/4 v2, 0x1

    const/4 v1, 0x3

    return-object v0
.end method

.method public a(Landroid/content/Context;)Lorg/json/JSONObject;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance p1, Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v0, "sedmpcieyv"

    const-string/jumbo v0, "vesyecpTdi"

    const/4 v4, 0x6

    const-string/jumbo v0, "vTdyoepcee"

    const-string v0, "deviceType"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-short v1, p0, Lcom/tencent/android/tpush/service/protocol/r;->a:S

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v0, "csImedsa"

    const/4 v4, 0x2

    const-string v0, "ascecbsI"

    const-string v0, "accessId"

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/r;->b:J

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string v0, "Kesyoacse"

    const/4 v4, 0x4

    const-string/jumbo v0, "sceceyuKs"

    const-string v0, "accessKey"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/r;->c:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string/jumbo v0, "prptaeC"

    const-string v0, "appCert"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/r;->d:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const-string/jumbo v0, "yEkpenbeqdrc"

    const-string v0, "drknebcEtpye"

    const/4 v4, 0x1

    const-string/jumbo v0, "yesyntdeErpk"

    const-string/jumbo v0, "keyEncrypted"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-byte v1, p0, Lcom/tencent/android/tpush/service/protocol/r;->e:B

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v0, "uslmlitnnsi"

    const-string/jumbo v0, "linnasutsli"

    const/4 v4, 0x4

    const-string/jumbo v0, "tlUsoiailnn"

    const-string/jumbo v0, "isUninstall"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-byte v1, p0, Lcom/tencent/android/tpush/service/protocol/r;->f:B

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo v0, "mmtsibeap"

    const-string/jumbo v0, "miempsapt"

    const/4 v4, 0x1

    const-string/jumbo v0, "tmmseputa"

    const-string/jumbo v0, "timestamp"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/r;->g:J

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v0, "odkresqpVn"

    const-string v0, "erioVkdnqs"

    const/4 v4, 0x0

    const-string/jumbo v0, "sdkVersion"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/r;->h:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    return-object p1
.end method
