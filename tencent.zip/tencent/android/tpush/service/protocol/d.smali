.class public abstract Lcom/tencent/android/tpush/service/protocol/d;
.super Lcom/tencent/android/tpush/service/protocol/c;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/c;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public abstract a(Landroid/content/Context;)Lorg/json/JSONObject;
.end method
