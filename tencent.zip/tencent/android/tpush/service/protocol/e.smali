.class public abstract Lcom/tencent/android/tpush/service/protocol/e;
.super Lcom/tencent/android/tpush/service/protocol/c;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/c;-><init>()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method
