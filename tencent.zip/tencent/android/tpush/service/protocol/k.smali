.class public Lcom/tencent/android/tpush/service/protocol/k;
.super Lcom/tencent/android/tpush/service/protocol/e;


# instance fields
.field public a:J

.field public b:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Lcom/tencent/android/tpush/service/protocol/j;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/e;-><init>()V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/k;->a:J

    const/4 v3, 0x3

    const/4 v2, 0x7

    new-instance v0, Ljava/util/ArrayList;

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/service/protocol/k;->b:Ljava/util/ArrayList;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-void
.end method


# virtual methods
.method public a()Lcom/tencent/android/tpush/service/protocol/MessageType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ss~d~ m /na v~@~f@@ o~~~~~~   l~~ol@t @@o~~@~b1KMu@@@o~@@-  4@b~S@@@  ~ to@.@o@@ crb~~i i y~f/ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/service/protocol/MessageType;->PUSH_MESSAGE:Lcom/tencent/android/tpush/service/protocol/MessageType;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-object v0
.end method

.method public a(Ljava/lang/String;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v0, Lorg/json/JSONObject;

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {v0, p1}, Lorg/json/JSONObject;-><init>(Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x0

    new-instance p1, Lcom/tencent/android/tpush/service/protocol/j;

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-direct {p1}, Lcom/tencent/android/tpush/service/protocol/j;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p1, v0}, Lcom/tencent/android/tpush/service/protocol/j;->a(Lorg/json/JSONObject;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/service/protocol/k;->b:Ljava/util/ArrayList;

    const/4 v4, 0x4

    shr-int/2addr v5, v4

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x0

    iget-wide v0, p1, Lcom/tencent/android/tpush/service/protocol/j;->h:J

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-wide/32 v2, 0xf4240

    const-wide/32 v2, 0xf4240

    const/4 v5, 0x0

    const-wide/32 v2, 0xf4240

    const-wide/32 v2, 0xf4240

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x6

    mul-long/2addr v0, v2

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/k;->a:J

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-void
.end method
