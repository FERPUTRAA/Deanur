.class public Lcom/tencent/android/tpush/service/protocol/l;
.super Lcom/tencent/android/tpush/service/protocol/d;


# instance fields
.field public a:J

.field public b:Ljava/lang/String;

.field public c:I

.field public d:I

.field public e:J

.field public f:Ljava/lang/String;

.field public g:Ljava/lang/String;


# direct methods
.method public constructor <init>()V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/protocol/d;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x0

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/l;->a:J

    const/4 v5, 0x2

    const/4 v4, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/l;->b:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x6

    iput v3, p0, Lcom/tencent/android/tpush/service/protocol/l;->c:I

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/16 v3, 0x64

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x2

    iput v3, p0, Lcom/tencent/android/tpush/service/protocol/l;->d:I

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/protocol/l;->e:J

    const/4 v5, 0x4

    const/4 v4, 0x1

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/l;->f:Ljava/lang/String;

    const/4 v5, 0x7

    const/4 v4, 0x0

    iput-object v2, p0, Lcom/tencent/android/tpush/service/protocol/l;->g:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-void
.end method


# virtual methods
.method public a()Lcom/tencent/android/tpush/service/protocol/MessageType;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@@si/@ot n /i ~~~ fi@~ o~~@@u~@@d @@ ~~~ ~@l @y S@@b~4~at@lro~K  Ms1~m@~ ~o~~ ~-@ fv~.bco@@ ob@ "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    sget-object v0, Lcom/tencent/android/tpush/service/protocol/MessageType;->QUERY_TAGS:Lcom/tencent/android/tpush/service/protocol/MessageType;

    const/4 v2, 0x3

    const/4 v1, 0x4

    return-object v0
.end method

.method public a(Landroid/content/Context;)Lorg/json/JSONObject;
    .locals 5

    const/4 v3, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x6

    new-instance p1, Lorg/json/JSONObject;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {p1}, Lorg/json/JSONObject;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string v0, "csdmaess"

    const-string v0, "dcssasec"

    const/4 v4, 0x3

    const-string/jumbo v0, "scIcosad"

    const-string v0, "accessId"

    const/4 v4, 0x2

    const/4 v3, 0x1

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/l;->a:J

    const/4 v3, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v0, "Kecesbams"

    const-string/jumbo v0, "scsmecaKe"

    const/4 v4, 0x2

    const-string v0, "ccaeeKusy"

    const-string v0, "accessKey"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/l;->b:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v0, "fpefts"

    const-string/jumbo v0, "offset"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget v1, p0, Lcom/tencent/android/tpush/service/protocol/l;->c:I

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string/jumbo v0, "imiqo"

    const-string/jumbo v0, "lmiio"

    const/4 v4, 0x2

    const-string/jumbo v0, "itsml"

    const-string/jumbo v0, "limit"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v1, p0, Lcom/tencent/android/tpush/service/protocol/l;->d:I

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v4, 0x5

    const-string v0, "bmsmtpmae"

    const-string v0, "eapmtbmts"

    const/4 v4, 0x5

    const-string/jumbo v0, "tiemomapt"

    const-string/jumbo v0, "timestamp"

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/protocol/l;->e:J

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p1, v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const-string/jumbo v0, "oVssebrudn"

    const-string/jumbo v0, "knsdoeuVsr"

    const/4 v4, 0x4

    const-string/jumbo v0, "rVsoknuisd"

    const-string/jumbo v0, "sdkVersion"

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/l;->f:Ljava/lang/String;

    const/4 v3, 0x1

    xor-int/2addr v4, v3

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/service/protocol/l;->g:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo v0, "pptapye"

    const-string/jumbo v0, "pypeTat"

    const/4 v4, 0x0

    const-string v0, "aqeTtpg"

    const-string/jumbo v0, "tagType"

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/service/protocol/l;->g:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p1, v0, v1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-object p1
.end method
