.class Lcom/tencent/android/tpush/service/a$10;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/service/c/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a;->g(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:Lcom/tencent/android/tpush/service/a;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$10;->c:Lcom/tencent/android/tpush/service/a;

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/tencent/android/tpush/service/a$10;->a:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x5

    iput-object p3, p0, Lcom/tencent/android/tpush/service/a$10;->b:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "b~s@o~ yo~~n~s@@~~~4i t@~~@t/1@ . i@~f ~@c@  @bf M~ lm@@~~@@ bo@u@~@i~~l@~ o~oao-   KS~d/ v@ @~ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    const-string/jumbo p2, "rtdmvclearsiaHssedoncSaPheB"

    const-string/jumbo p2, "tosvlsSudaeraaBcPshHcneeird"

    const-string p2, "PushServiceBroadcastHandler"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    if-nez p1, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const-string/jumbo v1, "nma o esdaec> trti kRcUhi=I gw ["

    const-string/jumbo v1, "ng mkaeah  >[  id=ecit>wRI sctUr"

    const/4 v3, 0x2

    const-string v1, "=k c bca[e wt hngIc>>ai U Rstdri"

    const-string v1, ">> UnRegister ack with [accId = "

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$10;->a:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const-string v1, ",epca=u Nkm  a"

    const-string v1, " , packName = "

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$10;->b:Ljava/lang/String;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string v1, "]  sop =, "

    const-string v1, "]  sop =, "

    const/4 v3, 0x4

    const-string v1, " r=]s  pp,"

    const-string v1, " , rsp = ]"

    const/4 v3, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x6

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$10;->c:Lcom/tencent/android/tpush/service/a;

    const/4 v3, 0x1

    check-cast p3, Lcom/tencent/android/tpush/service/protocol/r;

    const/4 v3, 0x4

    const/4 v2, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$10;->b:Ljava/lang/String;

    const/4 v3, 0x2

    invoke-static {p2, p1, p3, v0}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILcom/tencent/android/tpush/service/protocol/r;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x6

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string/jumbo v1, "rnpgs> sqlkecrfou dsb>tiC dernee =aeeoe"

    const-string/jumbo v1, "tkceeb>resooerreCsagd>lsea fiup de  =nn"

    const/4 v3, 0x5

    const-string v1, "erseisgnsu>e=kofl a esearCep >enc drodt"

    const-string v1, ">> unregeister ack failed responseCode="

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    const/4 v2, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x3

    iget-object p2, p0, Lcom/tencent/android/tpush/service/a$10;->c:Lcom/tencent/android/tpush/service/a;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x7

    check-cast p3, Lcom/tencent/android/tpush/service/protocol/r;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$10;->b:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v1, "64um2f1uu//780/ufuuuu/e0e5d56u/239/61/dd/695/u75595du4/af5uc9f810/8u8406"

    const-string v1, "/8e5fuu/u219u49u8uu9f66/u/0cd508/64/d7807u3/fafu15656/2/u/u40d5ed5/5u1/9"

    const/4 v3, 0x2

    const-string v1, "/8/aouu4//92/d7f06ub416u/uu5//57549fduf/990duu5e00du2/u5/85686c11f865e/u"

    const-string/jumbo v1, "\u670d\u52a1\u5668\u5904\u7406\u5931\u8d25\uff0c\u8fd4\u56de\u9519\u8bef"

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-static {p2, p1, v1, p3, v0}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/r;Ljava/lang/String;)V

    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method

.method public b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 4

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string/jumbo v1, "nsno@bpeaeri adr@igssdtFugeMeeSlen"

    const-string/jumbo v1, "lsgsoetpiuM nriaede F@@eSenagsndre"

    const/4 v3, 0x1

    const-string/jumbo v1, "tueelguse@sr i nMFer@nsoeedndSaai "

    const-string v1, "@@ unregister onMessageSendFailed "

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v3, 0x7

    const-string v1, ","

    const-string v1, ","

    const/4 v3, 0x5

    const-string v1, ","

    const-string v1, ","

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    const-string v1, "cvBrneipsdsdSrruteHPaaeocah"

    const-string v1, "PushServiceBroadcastHandler"

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$10;->c:Lcom/tencent/android/tpush/service/a;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    check-cast p3, Lcom/tencent/android/tpush/service/protocol/r;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$10;->b:Ljava/lang/String;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {v0, p1, p2, p3, v1}, Lcom/tencent/android/tpush/service/a;->a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/r;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x5

    return-void
.end method
