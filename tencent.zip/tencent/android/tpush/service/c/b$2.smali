.class Lcom/tencent/android/tpush/service/c/b$2;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/service/c/b$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/c/b;->b(Landroid/content/Context;Lcom/tencent/android/tpush/service/protocol/d;Lcom/tencent/android/tpush/service/c/a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/protocol/d;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Lcom/tencent/android/tpush/service/c/a;

.field final synthetic d:Lcom/tencent/android/tpush/service/c/b;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/c/b;Lcom/tencent/android/tpush/service/protocol/d;Landroid/content/Context;Lcom/tencent/android/tpush/service/c/a;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/service/c/b$2;->d:Lcom/tencent/android/tpush/service/c/b;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/tencent/android/tpush/service/c/b$2;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/tencent/android/tpush/service/c/b$2;->b:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x3

    iput-object p4, p0, Lcom/tencent/android/tpush/service/c/b$2;->c:Lcom/tencent/android/tpush/service/c/a;

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public a()V
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "~@so1@ @@oM i ~ ~/b- b@@~~c@~o sy~@K  @~@ d@~bt@n @~~@~r@~~~/~lo~4o  .l @mf@@ iotu ~vi  S~~a@f~@"

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x1

    new-instance v0, Lorg/json/JSONObject;

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string v1, "id"

    const-string v1, "di"

    const/4 v8, 0x2

    const-string v1, "id"

    const-string v1, "id"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/service/c/b$2;->d:Lcom/tencent/android/tpush/service/c/b;

    const/4 v7, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x0

    invoke-static {v2}, Lcom/tencent/android/tpush/service/c/b;->a(Lcom/tencent/android/tpush/service/c/b;)J

    move-result-wide v2

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x3

    invoke-virtual {v0, v1, v2, v3}, Lorg/json/JSONObject;->put(Ljava/lang/String;J)Lorg/json/JSONObject;

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x4

    const-string v1, "cmd"

    const-string v1, "cmd"

    const/4 v8, 0x5

    const-string/jumbo v1, "mdc"

    const-string v1, "cmd"

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/service/c/b$2;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v7, 0x0

    move v8, v7

    invoke-virtual {v2}, Lcom/tencent/android/tpush/service/protocol/c;->a()Lcom/tencent/android/tpush/service/protocol/MessageType;

    move-result-object v2

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-virtual {v2}, Lcom/tencent/android/tpush/service/protocol/MessageType;->getStr()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x3

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string/jumbo v1, "sapmma"

    const-string/jumbo v1, "pasmar"

    const/4 v8, 0x4

    const-string/jumbo v1, "ramsop"

    const-string/jumbo v1, "params"

    const/4 v8, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/service/c/b$2;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v8, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/service/c/b$2;->b:Landroid/content/Context;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-virtual {v2, v3}, Lcom/tencent/android/tpush/service/protocol/d;->a(Landroid/content/Context;)Lorg/json/JSONObject;

    move-result-object v2

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-virtual {v0, v1, v2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object v1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x7

    iget-object v1, v1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string v2, "icvsdbtxeg_/emisctas/"

    const-string/jumbo v2, "ixvmsc/datstecisge_/i"

    const-string v2, "/cisi/utgceeaivdsxt_s"

    const-string v2, "_xg/device/statistics"

    const/4 v8, 0x2

    invoke-virtual {v0}, Lorg/json/JSONObject;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x0

    new-instance v3, Lcom/tencent/android/tpush/service/c/b$a;

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x4

    iget-object v4, p0, Lcom/tencent/android/tpush/service/c/b$2;->b:Landroid/content/Context;

    const/4 v8, 0x7

    const/4 v7, 0x4

    iget-object v5, p0, Lcom/tencent/android/tpush/service/c/b$2;->c:Lcom/tencent/android/tpush/service/c/a;

    const/4 v8, 0x4

    const/4 v7, 0x5

    iget-object v6, p0, Lcom/tencent/android/tpush/service/c/b$2;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v8, 0x2

    const/4 v7, 0x1

    const/4 v8, 0x1

    invoke-direct {v3, v4, v5, v6}, Lcom/tencent/android/tpush/service/c/b$a;-><init>(Landroid/content/Context;Lcom/tencent/android/tpush/service/c/a;Lcom/tencent/android/tpush/service/protocol/d;)V

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-virtual {v1, v2, v0, v3}, Lcom/tencent/android/tpush/c/a$a;->a(Ljava/lang/String;Ljava/lang/String;Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v8, 0x5

    const/4 v7, 0x5

    const/4 v8, 0x2

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/c/b$2;->c:Lcom/tencent/android/tpush/service/c/a;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x0

    if-eqz v1, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x1

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x3

    const-string/jumbo v3, "srsserepaoer :eng o"

    const-string/jumbo v3, "s oaonese:rM rseger"

    const/4 v8, 0x0

    const-string v3, ":Mser  rqeserodeasg"

    const-string/jumbo v3, "sendMessage error: "

    const/4 v8, 0x4

    const/4 v7, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x1

    const/4 v8, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/c/b$2;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x7

    const/16 v3, -0x321

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x0

    invoke-interface {v1, v3, v0, v2}, Lcom/tencent/android/tpush/service/c/a;->b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V

    :cond_0
    :goto_0
    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x0

    return-void

    :catchall_1
    move-exception v0

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-string/jumbo v1, "tbsGqMeCXhaln"

    const-string/jumbo v1, "nqlXebtGhtMCa"

    const/4 v8, 0x3

    const-string/jumbo v1, "ntGmleXahMntC"

    const-string v1, "XGMqttChannel"

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    const-string v2, ":t toSertwbnedaa lguMos"

    const-string v2, " oan:MuasgetedtrSbltws "

    const/4 v8, 0x2

    const-string/jumbo v2, "ttnMabebsh:towag Sdrl s"

    const-string/jumbo v2, "sendStatMsg throwable: "

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v8, 0x2

    const/4 v7, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/service/c/b$2;->c:Lcom/tencent/android/tpush/service/c/a;

    const/4 v7, 0x7

    const/4 v7, 0x5

    if-eqz v0, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x4

    const-string/jumbo v1, "rsgu eu etedrMoattnqSrser"

    const-string/jumbo v1, "sendStatMsg request error"

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/service/c/b$2;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v7, 0x4

    move v8, v7

    const/16 v3, -0x65

    const/4 v8, 0x5

    const/4 v7, 0x1

    invoke-interface {v0, v3, v1, v2}, Lcom/tencent/android/tpush/service/c/a;->b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V

    :cond_1
    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    return-void
.end method

.method public a(ILjava/lang/String;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/service/c/b$2;->c:Lcom/tencent/android/tpush/service/c/a;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/service/c/b$2;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-interface {v0, p1, p2, v1}, Lcom/tencent/android/tpush/service/c/a;->b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-void
.end method
