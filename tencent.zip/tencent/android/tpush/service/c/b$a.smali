.class Lcom/tencent/android/tpush/service/c/b$a;
.super Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/service/c/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x8
    name = "a"
.end annotation


# instance fields
.field private a:Lcom/tencent/android/tpush/service/c/a;

.field private b:Lcom/tencent/android/tpush/service/protocol/d;

.field private c:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/tencent/android/tpush/service/c/a;Lcom/tencent/android/tpush/service/protocol/d;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;-><init>()V

    const/4 v1, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/service/c/b$a;->c:Landroid/content/Context;

    const/4 v1, 0x0

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/tencent/android/tpush/service/c/b$a;->a:Lcom/tencent/android/tpush/service/c/a;

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x6

    iput-object p3, p0, Lcom/tencent/android/tpush/service/c/b$a;->b:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public callback(ILjava/lang/String;)V
    .locals 10

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v8, "~~siy /@o~l~@~~M ubK o@~b@@ 1 o~o@~ ~~~ ft~c@@r@i~ @@ @4t ~n@ @~i. ~~ @@d~m  ~/-~Ssl@@ @faoob~@ "

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v9, 0x5

    if-ltz p1, :cond_0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/service/c/b$a;->a:Lcom/tencent/android/tpush/service/c/a;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/c/b$a;->b:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v9, 0x4

    invoke-interface {v0, p1, p2, v1}, Lcom/tencent/android/tpush/service/c/a;->a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x4

    goto :goto_0

    :cond_0
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/service/c/b$a;->a:Lcom/tencent/android/tpush/service/c/a;

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/service/c/b$a;->b:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v8, 0x6

    and-int/2addr v9, v8

    invoke-interface {v0, p1, p2, v1}, Lcom/tencent/android/tpush/service/c/a;->b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V

    :goto_0
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/c/b$a;->c:Landroid/content/Context;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x1

    iget-wide v5, p0, Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;->requestId:J

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v7, p0, Lcom/tencent/android/tpush/service/c/b$a;->b:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    move v3, p1

    move v3, p1

    const/4 v9, 0x3

    move v3, p1

    move v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-static/range {v2 .. v7}, Lcom/tencent/android/tpush/service/c/b;->a(Landroid/content/Context;ILjava/lang/String;JLcom/tencent/android/tpush/service/protocol/d;)V

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    return-void
.end method
