.class public Lcom/tencent/android/tpush/service/c/b$c;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/service/c/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x9
    name = "c"
.end annotation


# static fields
.field public static a:Lcom/tencent/android/tpush/service/c/b;


# direct methods
.method static constructor <clinit>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    new-instance v0, Lcom/tencent/android/tpush/service/c/b;

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Lcom/tencent/android/tpush/service/c/b;-><init>(Lcom/tencent/android/tpush/service/c/b$1;)V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    sput-object v0, Lcom/tencent/android/tpush/service/c/b$c;->a:Lcom/tencent/android/tpush/service/c/b;

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x0

    return-void
.end method
