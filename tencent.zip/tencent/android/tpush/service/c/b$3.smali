.class Lcom/tencent/android/tpush/service/c/b$3;
.super Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/c/b;->a(Landroid/content/Context;Lcom/tencent/android/tpush/service/c/b$b;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/c/b$b;

.field final synthetic b:Lcom/tencent/android/tpush/service/c/b;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/c/b;Lcom/tencent/android/tpush/service/c/b$b;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/service/c/b$3;->b:Lcom/tencent/android/tpush/service/c/b;

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpush/service/c/b$3;->a:Lcom/tencent/android/tpush/service/c/b$b;

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public callback(ILjava/lang/String;)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@Ksc   y@ o~1~~ ~ t4 o~b.@l~@Mv@n~@ ~ ol~o@b@@i r@@~/~Si~f ~oi@@u@-s~  ~mbt@@d /@ ~@a~@~ ~@of~ ~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    const-string v1, "dIlmlisiad csnteie:Vd"

    const-string/jumbo v1, "iesia dddlVscnCIi:elt"

    const/4 v3, 0x0

    const-string v1, "ic:toiIdVnideoll adCs"

    const-string/jumbo v1, "isValidClientId code:"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const-string v1, ",seaebms m"

    const-string/jumbo v1, "s: m,semea"

    const/4 v3, 0x3

    const-string/jumbo v1, "s gae,u:es"

    const-string v1, ", message:"

    const/4 v2, 0x4

    move v3, v2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x3

    const/4 v2, 0x7

    const-string/jumbo v0, "tClqnXnpatGoh"

    const-string/jumbo v0, "lntaohGtqMCnX"

    const/4 v3, 0x3

    const-string v0, "GChneaqtqlMXt"

    const-string v0, "XGMqttChannel"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-nez p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/service/c/b$3;->a:Lcom/tencent/android/tpush/service/c/b$b;

    const/4 v3, 0x5

    invoke-interface {p1}, Lcom/tencent/android/tpush/service/c/b$b;->a()V

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x3

    goto :goto_0

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    iget-object p1, p1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance p2, Lcom/tencent/android/tpush/service/c/b$3$1;

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {p2, p0}, Lcom/tencent/android/tpush/service/c/b$3$1;-><init>(Lcom/tencent/android/tpush/service/c/b$3;)V

    invoke-virtual {p1, p2}, Lcom/tencent/android/tpush/c/a$a;->d(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    :goto_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x7

    return-void
.end method
