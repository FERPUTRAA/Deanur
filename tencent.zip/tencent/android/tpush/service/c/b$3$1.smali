.class Lcom/tencent/android/tpush/service/c/b$3$1;
.super Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/c/b$3;->callback(ILjava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/c/b$3;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/c/b$3;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/service/c/b$3$1;->a:Lcom/tencent/android/tpush/service/c/b$3;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-direct {p0}, Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public callback(ILjava/lang/String;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@osioy ~@i~~@~o4bv~@u~1-~ld ~ @l f @s~ c t@@M~S ~aK~ r~~f@@ o@ @b.@~  ~o@@@i~t/~no~/@@  b m~ ~@~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    if-nez p1, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p2}, Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;->valueOf(Ljava/lang/String;)Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;->CONNECTED:Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    if-eq p1, v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-static {p2}, Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;->valueOf(Ljava/lang/String;)Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x5

    sget-object p2, Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;->SUBTOPICS:Lcom/tencent/tpns/mqttchannel/api/MqttConnectState;

    const/4 v1, 0x0

    const/4 v1, 0x6

    if-ne p1, p2, :cond_0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x0

    goto :goto_0

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x7

    iget-object p1, p1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const/4 p2, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {p1, p2}, Lcom/tencent/android/tpush/c/a$a;->a(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    :cond_1
    :goto_0
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/service/c/b$3$1;->a:Lcom/tencent/android/tpush/service/c/b$3;

    const/4 v2, 0x7

    iget-object p1, p1, Lcom/tencent/android/tpush/service/c/b$3;->a:Lcom/tencent/android/tpush/service/c/b$b;

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-interface {p1}, Lcom/tencent/android/tpush/service/c/b$b;->a()V

    const/4 v2, 0x2

    const/4 v1, 0x7

    return-void
.end method
