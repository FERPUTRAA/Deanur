.class public Lcom/tencent/android/tpush/service/c/b;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/service/c/b$b;,
        Lcom/tencent/android/tpush/service/c/b$a;,
        Lcom/tencent/android/tpush/service/c/b$c;
    }
.end annotation


# static fields
.field private static volatile a:Z = true

.field private static volatile b:Z = true


# instance fields
.field private c:J


# direct methods
.method static constructor <clinit>()V
    .locals 2

    return-void
.end method

.method private constructor <init>()V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x0

    const/4 v2, 0x4

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/c/b;->b()J

    move-result-wide v0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x6

    iput-wide v0, p0, Lcom/tencent/android/tpush/service/c/b;->c:J

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-void
.end method

.method synthetic constructor <init>(Lcom/tencent/android/tpush/service/c/b$1;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x3

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/c/b;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/c/b;)J
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v4, "~~s/@@cls db nMS@@fl~  u @~@v~i.~    @ ~~~4~~~b@ritf o @@@~-yK@oa~o@o~@ o@~/ ~bot~@@~@@  ~~i@1~m"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    iget-wide v0, p0, Lcom/tencent/android/tpush/service/c/b;->c:J

    const/4 v5, 0x4

    const-wide/16 v2, 0x1

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    add-long/2addr v2, v0

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    iput-wide v2, p0, Lcom/tencent/android/tpush/service/c/b;->c:J

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x5

    return-wide v0
.end method

.method public static a()Lcom/tencent/android/tpush/service/c/b;
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/android/tpush/service/c/b$c;->a:Lcom/tencent/android/tpush/service/c/b;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method static synthetic a(Landroid/content/Context;ILjava/lang/String;JLcom/tencent/android/tpush/service/protocol/d;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x7

    invoke-static/range {p0 .. p5}, Lcom/tencent/android/tpush/service/c/b;->b(Landroid/content/Context;ILjava/lang/String;JLcom/tencent/android/tpush/service/protocol/d;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method private a(Landroid/content/Context;Lcom/tencent/android/tpush/service/c/b$b;)V
    .locals 4

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string p1, "GatmMesqXCnnh"

    const-string/jumbo p1, "tGsnMqahelnCX"

    const/4 v3, 0x5

    const-string p1, "XGMqttChannel"

    const/4 v3, 0x4

    const-string v0, "cdteodWotenncioenmonh"

    const-string v0, "ciemnWotnnoedhAdntoec"

    const/4 v3, 0x4

    const-string v0, "ccdthbnnnoiWoCeeoenAd"

    const-string v0, "doActionWhenConnected"

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object p1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    iget-object p1, p1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    new-instance v0, Lcom/tencent/android/tpush/service/c/b$3;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, p0, p2}, Lcom/tencent/android/tpush/service/c/b$3;-><init>(Lcom/tencent/android/tpush/service/c/b;Lcom/tencent/android/tpush/service/c/b$b;)V

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-virtual {p1, v0}, Lcom/tencent/android/tpush/c/a$a;->e(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v1, "rdItneu:loado knvieV ierliC or"

    const-string/jumbo v1, "isleoiait rdI enervrCod:oknVl "

    const/4 v3, 0x1

    const-string/jumbo v1, "orriCiVpoeiked:aenird  llstnvI"

    const-string/jumbo v1, "invoke isValidClientId error: "

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-virtual {p1}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/16 v0, -0x321

    const/4 v3, 0x7

    const/4 v2, 0x0

    invoke-interface {p2, v0, p1}, Lcom/tencent/android/tpush/service/c/b$b;->a(ILjava/lang/String;)V

    :goto_0
    const/4 v2, 0x0

    move v3, v2

    return-void
.end method

.method private b()J
    .locals 9

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x7

    invoke-static {}, Landroid/os/Process;->myPid()I

    move-result v0

    const/4 v8, 0x5

    const/4 v7, 0x0

    rem-int/lit16 v0, v0, 0x3e8

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    const-wide v3, 0x174876e800L

    const-wide v3, 0x174876e800L

    const/4 v8, 0x4

    const-wide v3, 0x174876e800L

    const-wide v3, 0x174876e800L

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x5

    rem-long/2addr v1, v3

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x5

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v8, 0x6

    const-wide/16 v3, 0x3e8

    const-wide/16 v3, 0x3e8

    const/4 v8, 0x3

    mul-long/2addr v1, v3

    const/4 v8, 0x6

    int-to-long v5, v0

    const/4 v7, 0x0

    and-int/2addr v8, v7

    add-long/2addr v1, v5

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x0

    mul-long/2addr v1, v3

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x1

    return-wide v1
.end method

.method private static b(Landroid/content/Context;ILjava/lang/String;JLcom/tencent/android/tpush/service/protocol/d;)V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x4

    if-eqz p1, :cond_4

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    const/16 v0, -0x44f

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v1, 0x0

    move v7, v1

    const/4 v6, 0x4

    move v7, v6

    if-ne p1, v0, :cond_0

    :try_start_0
    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x0

    sget-boolean v0, Lcom/tencent/android/tpush/service/c/b;->a:Z

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x4

    if-eqz v0, :cond_5

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x5

    sput-boolean v1, Lcom/tencent/android/tpush/service/c/b;->a:Z

    const/4 v6, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {p5}, Lcom/tencent/android/tpush/service/protocol/c;->a()Lcom/tencent/android/tpush/service/protocol/MessageType;

    move-result-object p5

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p5}, Lcom/tencent/android/tpush/service/protocol/MessageType;->getStr()Ljava/lang/String;

    move-result-object v5

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x2

    move v1, p1

    move v1, p1

    const/4 v7, 0x0

    move v1, p1

    move v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-wide v3, p3

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-static/range {v0 .. v5}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    goto/16 :goto_1

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    const/4 v0, -0x3

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x3

    if-eq p1, v0, :cond_3

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x3

    const/4 v0, -0x4

    const/4 v7, 0x2

    if-ne p1, v0, :cond_1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x2

    goto :goto_0

    :cond_1
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x6

    const v0, 0xf6950

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-le p1, v0, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    const v0, 0xf6d38

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    if-ge p1, v0, :cond_2

    const/4 v6, 0x6

    shr-int/2addr v7, v6

    goto/16 :goto_1

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x1

    invoke-virtual {p5}, Lcom/tencent/android/tpush/service/protocol/c;->a()Lcom/tencent/android/tpush/service/protocol/MessageType;

    move-result-object p5

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-virtual {p5}, Lcom/tencent/android/tpush/service/protocol/MessageType;->getStr()Ljava/lang/String;

    move-result-object v5

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    move v1, p1

    move v1, p1

    const/4 v7, 0x6

    move v1, p1

    move v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-wide v3, p3

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-static/range {v0 .. v5}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    const/4 v6, 0x1

    or-int/2addr v7, v6

    goto/16 :goto_1

    :cond_3
    :goto_0
    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x7

    sget-boolean v0, Lcom/tencent/android/tpush/service/c/b;->b:Z

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v0, :cond_5

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x5

    sput-boolean v1, Lcom/tencent/android/tpush/service/c/b;->b:Z

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {p5}, Lcom/tencent/android/tpush/service/protocol/c;->a()Lcom/tencent/android/tpush/service/protocol/MessageType;

    move-result-object p5

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {p5}, Lcom/tencent/android/tpush/service/protocol/MessageType;->getStr()Ljava/lang/String;

    move-result-object v5

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x7

    move v1, p1

    move v1, p1

    const/4 v7, 0x1

    move v1, p1

    move v1, p1

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-wide v3, p3

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-static/range {v0 .. v5}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    goto :goto_1

    :cond_4
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x5

    const/4 p0, 0x1

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x3

    sput-boolean p0, Lcom/tencent/android/tpush/service/c/b;->a:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    goto :goto_1

    :catchall_0
    move-exception p0

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x7

    const-string p2, "R rborEeq deprdoehC:anrrlrt"

    const-string/jumbo p2, "odl nb eaCtRorErpe:odrerrhr"

    const/4 v7, 0x1

    const-string p2, "handleErrCodeReport error: "

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    invoke-virtual {p0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x3

    const-string p1, "CasqtXuMnhnGl"

    const-string p1, "CMnqthutGaXnl"

    const/4 v7, 0x4

    const-string p1, "GtlmnMtaenCXh"

    const-string p1, "XGMqttChannel"

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-static {p1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_5
    :goto_1
    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x5

    return-void
.end method


# virtual methods
.method public a(Landroid/content/Context;Lcom/tencent/android/tpush/service/protocol/d;Lcom/tencent/android/tpush/service/c/a;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    new-instance v0, Lcom/tencent/android/tpush/service/c/b$1;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-direct {v0, p0, p2, p1, p3}, Lcom/tencent/android/tpush/service/c/b$1;-><init>(Lcom/tencent/android/tpush/service/c/b;Lcom/tencent/android/tpush/service/protocol/d;Landroid/content/Context;Lcom/tencent/android/tpush/service/c/a;)V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0, p1, v0}, Lcom/tencent/android/tpush/service/c/b;->a(Landroid/content/Context;Lcom/tencent/android/tpush/service/c/b$b;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    return-void
.end method

.method public b(Landroid/content/Context;Lcom/tencent/android/tpush/service/protocol/d;Lcom/tencent/android/tpush/service/c/a;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    new-instance v0, Lcom/tencent/android/tpush/service/c/b$2;

    const/4 v1, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0, p0, p2, p1, p3}, Lcom/tencent/android/tpush/service/c/b$2;-><init>(Lcom/tencent/android/tpush/service/c/b;Lcom/tencent/android/tpush/service/protocol/d;Landroid/content/Context;Lcom/tencent/android/tpush/service/c/a;)V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0, p1, v0}, Lcom/tencent/android/tpush/service/c/b;->a(Landroid/content/Context;Lcom/tencent/android/tpush/service/c/b$b;)V

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method
