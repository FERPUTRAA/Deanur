.class Lcom/tencent/android/tpush/service/c/b$1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/service/c/b$b;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/c/b;->a(Landroid/content/Context;Lcom/tencent/android/tpush/service/protocol/d;Lcom/tencent/android/tpush/service/c/a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/protocol/d;

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Lcom/tencent/android/tpush/service/c/a;

.field final synthetic d:Lcom/tencent/android/tpush/service/c/b;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/c/b;Lcom/tencent/android/tpush/service/protocol/d;Landroid/content/Context;Lcom/tencent/android/tpush/service/c/a;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/service/c/b$1;->d:Lcom/tencent/android/tpush/service/c/b;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/service/c/b$1;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    iput-object p3, p0, Lcom/tencent/android/tpush/service/c/b$1;->b:Landroid/content/Context;

    const/4 v1, 0x4

    iput-object p4, p0, Lcom/tencent/android/tpush/service/c/b$1;->c:Lcom/tencent/android/tpush/service/c/a;

    const/4 v1, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x0

    return-void
.end method


# virtual methods
.method public a()V
    .locals 11

    :try_start_0
    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, " -s  ~~ tM@Sa@u~b~~i~1/@@.@s~@@bv~milo@f ~ @~r~/~oK@~@@i  o@ ~@~ ~~@@ n~o@o@of ~t@ y @~~~   l4db"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/service/c/b$1;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/c/b$1;->b:Landroid/content/Context;

    const/4 v10, 0x7

    const/4 v9, 0x2

    const/4 v10, 0x4

    invoke-virtual {v0, v1}, Lcom/tencent/android/tpush/service/protocol/d;->a(Landroid/content/Context;)Lorg/json/JSONObject;

    move-result-object v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object v1

    const/4 v10, 0x4

    const/4 v9, 0x5

    const/4 v10, 0x0

    iget-object v1, v1, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/service/c/b$1;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x5

    invoke-virtual {v2}, Lcom/tencent/android/tpush/service/protocol/c;->a()Lcom/tencent/android/tpush/service/protocol/MessageType;

    move-result-object v2

    const/4 v10, 0x2

    const/4 v9, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/service/protocol/MessageType;->getStr()Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x1

    new-instance v3, Lcom/tencent/android/tpush/service/c/b$a;

    const/4 v10, 0x3

    iget-object v4, p0, Lcom/tencent/android/tpush/service/c/b$1;->b:Landroid/content/Context;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x3

    iget-object v5, p0, Lcom/tencent/android/tpush/service/c/b$1;->c:Lcom/tencent/android/tpush/service/c/a;

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget-object v6, p0, Lcom/tencent/android/tpush/service/c/b$1;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v10, 0x4

    invoke-direct {v3, v4, v5, v6}, Lcom/tencent/android/tpush/service/c/b$a;-><init>(Landroid/content/Context;Lcom/tencent/android/tpush/service/c/a;Lcom/tencent/android/tpush/service/protocol/d;)V

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v1, v2, v0, v3}, Lcom/tencent/android/tpush/c/a$a;->a(Ljava/lang/String;Lorg/json/JSONObject;Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/c/b$1;->c:Lcom/tencent/android/tpush/service/c/a;

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    if-eqz v1, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x5

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x7

    const-string/jumbo v3, "nremdassg esor:e es"

    const-string/jumbo v3, "sass:egor enered sr"

    const/4 v10, 0x2

    const-string v3, " Mgro:eer dnseraess"

    const-string/jumbo v3, "sendMessage error: "

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {v0}, Ljava/lang/Throwable;->getMessage()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x4

    const/4 v9, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/service/c/b$1;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x0

    const/16 v3, -0x321

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-interface {v1, v3, v0, v2}, Lcom/tencent/android/tpush/service/c/a;->b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V

    :cond_0
    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    return-void

    :catchall_1
    move-exception v0

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x3

    const-string v1, "MXhtabtqCemnG"

    const-string v1, "CatmGMtnehlqX"

    const/4 v10, 0x4

    const-string/jumbo v1, "tnCMnXuGqehat"

    const-string v1, "XGMqttChannel"

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-string v2, "eseers phoatoswlMbg ade"

    const-string v2, "Masnoeodhw  rebtessegla"

    const/4 v10, 0x1

    const-string/jumbo v2, "wlMg tebqedehsnrasa:ose"

    const-string/jumbo v2, "sendMessage throwable: "

    const/4 v10, 0x5

    const/4 v9, 0x2

    const/4 v10, 0x1

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x4

    const-string v0, "gssaerMter eeusbqr osedrn"

    const-string v0, "grq sbsuerrda osrMneeetes"

    const/4 v10, 0x6

    const-string v0, "gMsmreerqran edesto ueres"

    const-string/jumbo v0, "sendMessage request error"

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v3, p0, Lcom/tencent/android/tpush/service/c/b$1;->b:Landroid/content/Context;

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x1

    const/16 v4, -0x65

    const/4 v10, 0x4

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v10, 0x5

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const/4 v10, 0x5

    const/4 v9, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/c/b$1;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/protocol/c;->a()Lcom/tencent/android/tpush/service/protocol/MessageType;

    move-result-object v1

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/protocol/MessageType;->getStr()Ljava/lang/String;

    move-result-object v8

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    move-object v5, v0

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static/range {v3 .. v8}, Lcom/tencent/android/tpush/stat/ServiceStat;->reportErrCode(Landroid/content/Context;ILjava/lang/String;JLjava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/service/c/b$1;->c:Lcom/tencent/android/tpush/service/c/a;

    const/4 v9, 0x4

    shr-int/2addr v10, v9

    if-eqz v1, :cond_1

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    const/16 v2, -0x65

    const/4 v10, 0x0

    const/4 v9, 0x0

    const/4 v10, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/service/c/b$1;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-interface {v1, v2, v0, v3}, Lcom/tencent/android/tpush/service/c/a;->b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V

    :cond_1
    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x3

    return-void
.end method

.method public a(ILjava/lang/String;)V
    .locals 10

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/service/c/b$1;->c:Lcom/tencent/android/tpush/service/c/a;

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-eqz v0, :cond_0

    const/4 v9, 0x0

    const/4 v8, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/c/b$1;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v8, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-interface {v0, p1, p2, v1}, Lcom/tencent/android/tpush/service/c/a;->b(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/d;)V

    :cond_0
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/service/c/b$1;->b:Landroid/content/Context;

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v9, 0x5

    const-wide/16 v5, 0x0

    const-wide/16 v5, 0x0

    const/4 v8, 0x7

    move v9, v8

    iget-object v7, p0, Lcom/tencent/android/tpush/service/c/b$1;->a:Lcom/tencent/android/tpush/service/protocol/d;

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x0

    move v3, p1

    move v3, p1

    const/4 v9, 0x5

    move v3, p1

    move v3, p1

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    move-object v4, p2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static/range {v2 .. v7}, Lcom/tencent/android/tpush/service/c/b;->a(Landroid/content/Context;ILjava/lang/String;JLcom/tencent/android/tpush/service/protocol/d;)V

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    return-void
.end method
