.class public Lcom/tencent/android/tpush/service/d;
.super Ljava/lang/Object;


# static fields
.field private static a:Lcom/tencent/android/tpush/service/d;


# instance fields
.field private b:Landroid/os/PowerManager$WakeLock;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    shr-int/2addr v2, v1

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/service/d;->b:Landroid/os/PowerManager$WakeLock;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-void
.end method

.method public static a()Lcom/tencent/android/tpush/service/d;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "~ s~  @ ~ b@~ t.~@ b~~@4~~l~M1iS@m~f iKu@ ltf@@s o@ oo@~ o@~ ~~y ~~~/@@-~rocn@@@  ~~~vdoia@@/@@b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/service/d;->a:Lcom/tencent/android/tpush/service/d;

    const/4 v2, 0x5

    const/4 v1, 0x0

    if-nez v0, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lcom/tencent/android/tpush/service/d;

    const/4 v2, 0x1

    const/4 v1, 0x1

    invoke-direct {v0}, Lcom/tencent/android/tpush/service/d;-><init>()V

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x5

    sput-object v0, Lcom/tencent/android/tpush/service/d;->a:Lcom/tencent/android/tpush/service/d;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/service/d;->a:Lcom/tencent/android/tpush/service/d;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    return-object v0
.end method


# virtual methods
.method public b()Landroid/os/PowerManager$WakeLock;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/service/d;->b:Landroid/os/PowerManager$WakeLock;

    const/4 v2, 0x4

    return-object v0
.end method
