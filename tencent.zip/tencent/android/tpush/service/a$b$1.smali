.class Lcom/tencent/android/tpush/service/a$b$1;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger$WriteFileCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a$b;->TRun()V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Lcom/tencent/android/tpush/service/a$b;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a$b;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$b$1;->a:Lcom/tencent/android/tpush/service/a$b;

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onFinished()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@@s@t~ ~f o~@o ~~@@ ~la@ M td ~~ ioS~~~/n@o~~r @@~@l @.@-~~@c~K@ i~bbi~ @u  1~o4@~@/ vy ~@f boms"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    const-string/jumbo v0, "rrsSiePBeehslaravtnsocddHuc"

    const/4 v3, 0x5

    const-string/jumbo v0, "satmsiceduacrrrdveenhoaBHlS"

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string/jumbo v1, "lshgoinses o d rfpoilxfsge uh"

    const-string/jumbo v1, "xg process log flush finished"

    const/4 v3, 0x4

    const/4 v2, 0x5

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$b$1;->a:Lcom/tencent/android/tpush/service/a$b;

    invoke-static {v0}, Lcom/tencent/android/tpush/service/a$b;->a(Lcom/tencent/android/tpush/service/a$b;)Landroid/content/Intent;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v1, "kpamcbea"

    const-string/jumbo v1, "kcpmeaaN"

    const/4 v3, 0x4

    const-string v1, "Naapckum"

    const-string/jumbo v1, "packName"

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$b$1;->a:Lcom/tencent/android/tpush/service/a$b;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/service/a$b;->b(Lcom/tencent/android/tpush/service/a$b;)Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string v1, "LnnndiSptLo.mFiniSa.RoVoec.r.EHcgUd.co.Tpt.ve.tx4"

    const-string/jumbo v1, "vdc.oxnSnEoSnUFeLga4icrcp..toT..nttR.a.iedH.iomVL"

    const/4 v3, 0x6

    const-string/jumbo v1, "vF.cnUcoqTamHntUepciin.xgRnetELdr.oS..V.S.oLatd4."

    const-string v1, "com.tencent.android.xg.vip.action.FLUSH.RESULT.V4"

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x2

    return-void
.end method
