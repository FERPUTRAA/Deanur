.class public Lcom/tencent/android/tpush/service/channel/exception/NullReturnException;
.super Ljava/lang/Exception;


# static fields
.field private static final serialVersionUID:J = -0x2467dddfd16c8207L


# instance fields
.field private statusCode:I


# direct methods
.method public constructor <init>(Ljava/lang/Exception;)V
    .locals 2

    const/4 v0, 0x7

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/Throwable;)V

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x6

    const/4 p1, -0x1

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput p1, p0, Lcom/tencent/android/tpush/service/channel/exception/NullReturnException;->statusCode:I

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x6

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x0

    const/4 p1, -0x1

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    iput p1, p0, Lcom/tencent/android/tpush/service/channel/exception/NullReturnException;->statusCode:I

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;I)V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput p2, p0, Lcom/tencent/android/tpush/service/channel/exception/NullReturnException;->statusCode:I

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Exception;)V
    .locals 2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x0

    const/4 p1, -0x1

    const/4 v1, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput p1, p0, Lcom/tencent/android/tpush/service/channel/exception/NullReturnException;->statusCode:I

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Exception;I)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Ljava/lang/Exception;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x7

    iput p3, p0, Lcom/tencent/android/tpush/service/channel/exception/NullReturnException;->statusCode:I

    const/4 v1, 0x1

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public getStatusCode()I
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "1~sb~@@@/v~~@@@ ~   nr l@@ S~ ti cb~aM4-o~~~o d~ @@@~@K~i i ~@~/ u@~@~@ @l@@f~s y~~oot@~om fo~.b"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget v0, p0, Lcom/tencent/android/tpush/service/channel/exception/NullReturnException;->statusCode:I

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    return v0
.end method
