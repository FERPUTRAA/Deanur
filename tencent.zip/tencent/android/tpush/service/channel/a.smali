.class public Lcom/tencent/android/tpush/service/channel/a;
.super Ljava/lang/Object;


# static fields
.field private static a:Lcom/tencent/android/tpush/service/channel/a;


# instance fields
.field private b:Landroid/util/SparseArray;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Landroid/util/SparseArray<",
            "Ljava/lang/Object;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x0

    new-instance v0, Lcom/tencent/android/tpush/service/channel/a;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/tencent/android/tpush/service/channel/a;-><init>()V

    const/4 v2, 0x0

    sput-object v0, Lcom/tencent/android/tpush/service/channel/a;->a:Lcom/tencent/android/tpush/service/channel/a;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x7

    new-instance v0, Landroid/util/SparseArray;

    const/4 v2, 0x6

    const/4 v1, 0x6

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/service/channel/a;->b:Landroid/util/SparseArray;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    return-void
.end method

.method public varargs constructor <init>([Ljava/lang/Object;)V
    .locals 6

    const/4 v4, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x5

    new-instance v0, Landroid/util/SparseArray;

    const/4 v4, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v0}, Landroid/util/SparseArray;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/service/channel/a;->b:Landroid/util/SparseArray;

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x5

    const/4 v0, 0x0

    :goto_0
    array-length v1, p1

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-ge v0, v1, :cond_0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/service/channel/a;->b:Landroid/util/SparseArray;

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x4

    aget-object v2, p1, v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    check-cast v2, Ljava/lang/Integer;

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v2}, Ljava/lang/Integer;->intValue()I

    move-result v2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    add-int/lit8 v3, v0, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    aget-object v3, p1, v3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {v1, v2, v3}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    add-int/lit8 v0, v0, 0x2

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x1

    const/4 v5, 0x1

    return-void
.end method


# virtual methods
.method public a()Z
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  s@~1~f@u@~  of @o~.yb~4~~riit~@@@l@o~@@i/@ s~S@atK~~  don~@    ov~l~@o~M~@m-@ @ c~  ~~@ b~b~@/"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/service/channel/a;->b:Landroid/util/SparseArray;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v1, 0x4

    const/4 v1, 0x2

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    sget-object v2, Ljava/lang/Boolean;->FALSE:Ljava/lang/Boolean;

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->get(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    check-cast v0, Ljava/lang/Boolean;

    const/4 v3, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0}, Ljava/lang/Boolean;->booleanValue()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    return v0
.end method

.method public b()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/service/channel/a;->b:Landroid/util/SparseArray;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x2

    const-string v2, ""

    const-string v2, ""

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1, v2}, Landroid/util/SparseArray;->get(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    check-cast v0, Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    return-object v0
.end method

.method public c()I
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/service/channel/a;->b:Landroid/util/SparseArray;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/4 v1, 0x0

    const/4 v4, 0x1

    invoke-static {v1}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    move-result-object v1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v2, v1}, Landroid/util/SparseArray;->get(ILjava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x1

    check-cast v0, Ljava/lang/Integer;

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/Integer;->intValue()I

    move-result v0

    const/4 v3, 0x6

    shr-int/2addr v4, v3

    return v0
.end method
