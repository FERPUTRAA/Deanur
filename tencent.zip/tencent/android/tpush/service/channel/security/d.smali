.class public Lcom/tencent/android/tpush/service/channel/security/d;
.super Ljava/lang/Object;


# static fields
.field private static a:Ljava/security/interfaces/RSAPublicKey;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method public static a([BLjava/security/interfaces/RSAPublicKey;)Ljava/lang/String;
    .locals 8

    :try_start_0
    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "~ sit@~  @.-~l ~~bv~~@@s~id@~@u~ @ KSM~oo/ @~o~~~rn4 o@l1 ~~by@@~o@   cfa i  ~~/@@ t o~fm~@@@@@b"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    const-string/jumbo v0, "sBEmSnSdR/iC1dPaCAgP"

    const-string v0, "ECs1SRaBAPPiCddSng//"

    const/4 v7, 0x7

    const-string v0, "Ea/Ao/CCBiPSgR1PdnSK"

    const-string v0, "RSA/ECB/PKCS1Padding"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-static {v0}, Ljavax/crypto/Cipher;->getInstance(Ljava/lang/String;)Ljavax/crypto/Cipher;

    move-result-object v0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/4 v1, 0x2

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x0

    invoke-virtual {v0, v1, p1}, Ljavax/crypto/Cipher;->init(ILjava/security/Key;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-interface {p1}, Ljava/security/interfaces/RSAKey;->getModulus()Ljava/math/BigInteger;

    move-result-object p1

    const/4 v7, 0x3

    const/4 v6, 0x4

    invoke-virtual {p1}, Ljava/math/BigInteger;->bitLength()I

    move-result p1

    const/4 v7, 0x7

    const/4 v6, 0x3

    div-int/lit8 p1, p1, 0x8

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x2

    if-eqz p1, :cond_1

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string v1, ""

    const/4 v7, 0x7

    const-string v1, ""

    const-string v1, ""

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/service/channel/security/d;->a([BI)[[B

    move-result-object p0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    array-length p1, p0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x0

    const/4 v2, 0x0

    :goto_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    if-ge v2, p1, :cond_0

    const/4 v6, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x7

    aget-object v3, p0, v2

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v1, Ljava/lang/String;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v0, v3}, Ljavax/crypto/Cipher;->doFinal([B)[B

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x5

    const-string v5, "bUmF8"

    const-string v5, "-8UmF"

    const/4 v7, 0x1

    const-string v5, "FuU-T"

    const-string v5, "UTF-8"

    const/4 v7, 0x2

    const/4 v6, 0x1

    invoke-direct {v1, v3, v5}, Ljava/lang/String;-><init>([BLjava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x2

    add-int/lit8 v2, v2, 0x1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    goto :goto_0

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x7

    return-object v1

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x7

    new-instance p0, Ljava/lang/Exception;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string p1, "16/uu4/p523uaao/79f"

    const-string p1, "a/9uo5f6uua23e/14/7"

    const/4 v7, 0x2

    const-string p1, "1u69/3f7q5e/u2/04au"

    const-string/jumbo p1, "\u6a21\u957f\u4e3a0"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x5

    throw p0
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljavax/crypto/NoSuchPaddingException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/security/InvalidKeyException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljavax/crypto/IllegalBlockSizeException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljavax/crypto/BadPaddingException; {:try_start_0 .. :try_end_0} :catch_0

    :catch_0
    const/4 v7, 0x7

    new-instance p0, Ljava/lang/Exception;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string p1, "5csfu5568/47/5562uu/3660u/567/uuf/3d7f6bue"

    const-string p1, "6f5uub/f577u3/e/0235uu6c6/674f5bu55u668//d"

    const/4 v7, 0x1

    const-string p1, "f/um/773f666/05u5bud/465f62ce/u5u/uu58/736"

    const-string/jumbo p1, "\u5bc6\u6587\u6570\u636e\u5df2\u635f\u574f"

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    move v7, v6

    throw p0

    :catch_1
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    new-instance p0, Ljava/lang/Exception;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x6

    const-string/jumbo p1, "u6d5o5//5/5/c/ueuu6ua6f77c7e5bu9986/"

    const-string p1, "7/6cufu959audu55eu65u//c6/6u775b8//e"

    const/4 v7, 0x3

    const-string/jumbo p1, "u/u6ab578uufce/76/c9/956b6u/55ud/57e"

    const-string/jumbo p1, "\u5bc6\u6587\u957f\u5ea6\u975e\u6cd5"

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x1

    throw p0

    :catch_2
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x1

    new-instance p0, Ljava/lang/Exception;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string p1, "6/p7u7u/16u95ece5u56u7u7/c//5088bu5,/f869dua4ce/9/buc/u"

    const-string p1, "81663//p69ecb/b//5477/0cu788,uu5c9euuu5/ucd/f6u75/ea5u9"

    const/4 v7, 0x0

    const-string p1, "/cu7587peu0a967/9b6u357ucecu56c/5,54d//1euf9/u8/u8bu/9/"

    const-string/jumbo p1, "\u89e3\u5bc6\u79c1\u94a5\u975e\u6cd5,\u8bf7\u68c0\u67e5"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x3

    throw p0

    :catch_3
    move-exception p0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {p0}, Ljava/lang/Throwable;->printStackTrace()V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    const/4 p0, 0x0

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    return-object p0

    :catch_4
    const/4 v6, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    new-instance p0, Ljava/lang/Exception;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    const-string/jumbo p1, "u5u873ubq4//u65/9b6/6076dec/5e69qbc/"

    const-string p1, "e75//d66q993euu07c/b/u5/b68cu/bu6456"

    const/4 v7, 0x0

    const-string p1, "49s7u7ebu556u//bue66u96/d/3cc8b50//u"

    const-string/jumbo p1, "\u65e0\u6b64\u89e3\u5bc6\u7b97\u6cd5"

    const/4 v6, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {p0, p1}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    throw p0
.end method

.method public static a(Ljava/lang/String;)Ljava/security/interfaces/RSAPublicKey;
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/service/channel/security/a;->a(Ljava/lang/String;I)[B

    move-result-object p0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x2

    const-string v0, "RAS"

    const-string v0, "SAR"

    const-string v0, "RAS"

    const-string v0, "RSA"

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {v0}, Ljava/security/KeyFactory;->getInstance(Ljava/lang/String;)Ljava/security/KeyFactory;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v1, Ljava/security/spec/X509EncodedKeySpec;

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x1

    invoke-direct {v1, p0}, Ljava/security/spec/X509EncodedKeySpec;-><init>([B)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/security/KeyFactory;->generatePublic(Ljava/security/spec/KeySpec;)Ljava/security/PublicKey;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    check-cast p0, Ljava/security/interfaces/RSAPublicKey;
    :try_end_0
    .catch Ljava/security/NoSuchAlgorithmException; {:try_start_0 .. :try_end_0} :catch_2
    .catch Ljava/security/spec/InvalidKeySpecException; {:try_start_0 .. :try_end_0} :catch_1
    .catch Ljava/lang/NullPointerException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    return-object p0

    :catch_0
    const/4 v3, 0x2

    new-instance p0, Ljava/lang/Exception;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    const-string v0, "/5/meu7a61474/36uea5su//a9c56uu/7u30"

    const-string v0, "66s0/u5u6735c/au4//5/u4e7e6uaa97u/31"

    const/4 v3, 0x0

    const-string v0, "3//uo6/9ea7uu7c4a/6u6a765uu0435a51/e"

    const-string/jumbo v0, "\u516c\u94a5\u6570\u636e\u4e3a\u7a7a"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    throw p0

    :catch_1
    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/Exception;

    const/4 v3, 0x6

    const-string/jumbo v0, "u/u5cb9/654/557ed1au/m96"

    const-string v0, "51cm796/9/uu5/u/5au564ed"

    const/4 v3, 0x7

    const-string v0, "15u7eau94c56/c/556/uuu9/"

    const-string/jumbo v0, "\u516c\u94a5\u975e\u6cd5"

    const/4 v2, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    throw p0

    :catch_2
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    new-instance p0, Ljava/lang/Exception;

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x2

    const-string v0, "bd5/u67puco4/66ueu/950/7"

    const-string v0, "b/ubo64cue/u7d65/650/7u9"

    const/4 v3, 0x6

    const-string/jumbo v0, "u6uuu576q6d/ec57/9/046/b"

    const-string/jumbo v0, "\u65e0\u6b64\u7b97\u6cd5"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-direct {p0, v0}, Ljava/lang/Exception;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x1

    throw p0
.end method

.method public static a([BI)[[B
    .locals 9

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x1

    array-length v0, p0

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x5

    div-int/2addr v0, p1

    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x7

    array-length v1, p0

    const/4 v8, 0x3

    const/4 v7, 0x5

    rem-int/2addr v1, p1

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x3

    const/4 v2, 0x0

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-eqz v1, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x6

    const/4 v3, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x2

    goto :goto_0

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    move v3, v2

    move v3, v2

    const/4 v8, 0x5

    move v3, v2

    move v3, v2

    :goto_0
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    add-int/2addr v0, v3

    const/4 v8, 0x7

    new-array v3, v0, [[B

    const/4 v7, 0x2

    move v8, v7

    move v4, v2

    move v4, v2

    const/4 v8, 0x3

    move v4, v2

    :goto_1
    const/4 v8, 0x2

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-ge v4, v0, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x5

    new-array v5, p1, [B

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x6

    add-int/lit8 v6, v0, -0x1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x5

    if-ne v4, v6, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x2

    const/4 v8, 0x7

    if-eqz v1, :cond_1

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x5

    mul-int v6, v4, p1

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x2

    invoke-static {p0, v6, v5, v2, v1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x4

    goto :goto_2

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x5

    mul-int v6, v4, p1

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {p0, v6, v5, v2, p1}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    :goto_2
    const/4 v8, 0x3

    const/4 v7, 0x7

    aput-object v5, v3, v4

    const/4 v8, 0x7

    const/4 v7, 0x7

    const/4 v8, 0x5

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x6

    goto :goto_1

    :cond_2
    const/4 v8, 0x1

    const/4 v7, 0x1

    const/4 v8, 0x4

    return-object v3
.end method
