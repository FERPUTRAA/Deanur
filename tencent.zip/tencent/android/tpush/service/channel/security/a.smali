.class public Lcom/tencent/android/tpush/service/channel/security/a;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/service/channel/security/a$c;,
        Lcom/tencent/android/tpush/service/channel/security/a$b;,
        Lcom/tencent/android/tpush/service/channel/security/a$a;
    }
.end annotation


# static fields
.field static final synthetic a:Z = true


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x3

    return-void
.end method

.method private constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method public static a(Ljava/lang/String;I)[B
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, " bs @~/ri ~~~@@~~@ i~~1y@~t-@aK4~ @b~Mos  c~S@du~f   m~@oot~@@fno@@@@~o~l ~@@@@ ~b@   v~ /~. oil"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    invoke-virtual {p0}, Ljava/lang/String;->getBytes()[B

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x4

    invoke-static {p0, p1}, Lcom/tencent/android/tpush/service/channel/security/a;->a([BI)[B

    move-result-object p0

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    return-object p0
.end method

.method public static a([BI)[B
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    array-length v0, p0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x3

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x3

    invoke-static {p0, v1, v0, p1}, Lcom/tencent/android/tpush/service/channel/security/a;->a([BIII)[B

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object p0
.end method

.method public static a([BIII)[B
    .locals 4

    const/4 v3, 0x7

    new-instance v0, Lcom/tencent/android/tpush/service/channel/security/a$b;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    mul-int/lit8 v1, p2, 0x3

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x7

    div-int/lit8 v1, v1, 0x4

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x5

    new-array v1, v1, [B

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-direct {v0, p3, v1}, Lcom/tencent/android/tpush/service/channel/security/a$b;-><init>(I[B)V

    const/4 v3, 0x7

    const/4 p3, 0x7

    const/4 v3, 0x3

    const/4 p3, 0x1

    const/4 v2, 0x0

    or-int/2addr v3, v2

    invoke-virtual {v0, p0, p1, p2, p3}, Lcom/tencent/android/tpush/service/channel/security/a$b;->a([BIIZ)Z

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    if-eqz p0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    iget p0, v0, Lcom/tencent/android/tpush/service/channel/security/a$a;->b:I

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    iget-object p1, v0, Lcom/tencent/android/tpush/service/channel/security/a$a;->a:[B

    const/4 v3, 0x1

    const/4 v2, 0x7

    array-length p2, p1

    const/4 v2, 0x0

    const/4 v3, 0x2

    if-ne p0, p2, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x5

    return-object p1

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x5

    new-array p2, p0, [B

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 p3, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-static {p1, p3, p2, p3, p0}, Ljava/lang/System;->arraycopy(Ljava/lang/Object;ILjava/lang/Object;II)V

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    return-object p2

    :cond_1
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    new-instance p0, Ljava/lang/IllegalArgumentException;

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string p1, "abem4sbad s"

    const-string p1, "d ssbab-4ae"

    const/4 v3, 0x4

    const-string p1, "d a-o46ebab"

    const-string p1, "bad base-64"

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-direct {p0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    throw p0
.end method

.method public static b([BI)[B
    .locals 4

    const/4 v3, 0x0

    array-length v0, p0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {p0, v1, v0, p1}, Lcom/tencent/android/tpush/service/channel/security/a;->b([BIII)[B

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    return-object p0
.end method

.method public static b([BIII)[B
    .locals 7

    const/4 v6, 0x7

    const/4 v5, 0x6

    new-instance v0, Lcom/tencent/android/tpush/service/channel/security/a$c;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x4

    const/4 v1, 0x0

    const/4 v5, 0x1

    move v6, v5

    invoke-direct {v0, p3, v1}, Lcom/tencent/android/tpush/service/channel/security/a$c;-><init>(I[B)V

    const/4 v6, 0x2

    const/4 v5, 0x3

    div-int/lit8 p3, p2, 0x3

    const/4 v6, 0x5

    mul-int/lit8 p3, p3, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x2

    iget-boolean v1, v0, Lcom/tencent/android/tpush/service/channel/security/a$c;->d:Z

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    const/4 v2, 0x2

    const/4 v6, 0x1

    const/4 v3, 0x1

    const/4 v6, 0x6

    move v5, v3

    move v5, v3

    const/4 v6, 0x6

    if-eqz v1, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x7

    rem-int/lit8 v1, p2, 0x3

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x0

    if-lez v1, :cond_3

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x1

    add-int/lit8 p3, p3, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x4

    goto :goto_0

    :cond_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x4

    rem-int/lit8 v1, p2, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eq v1, v3, :cond_2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    if-eq v1, v2, :cond_1

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    goto :goto_0

    :cond_1
    const/4 v5, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    add-int/lit8 p3, p3, 0x3

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    goto :goto_0

    :cond_2
    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    add-int/lit8 p3, p3, 0x2

    :cond_3
    :goto_0
    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-boolean v1, v0, Lcom/tencent/android/tpush/service/channel/security/a$c;->e:Z

    if-eqz v1, :cond_5

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    if-lez p2, :cond_5

    const/4 v6, 0x1

    add-int/lit8 v1, p2, -0x1

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x7

    div-int/lit8 v1, v1, 0x39

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    add-int/2addr v1, v3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    iget-boolean v4, v0, Lcom/tencent/android/tpush/service/channel/security/a$c;->f:Z

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x7

    if-eqz v4, :cond_4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    goto :goto_1

    :cond_4
    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x4

    move v2, v3

    move v2, v3

    :goto_1
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x1

    mul-int/2addr v1, v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x1

    add-int/2addr p3, v1

    :cond_5
    const/4 v6, 0x3

    new-array v1, p3, [B

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x0

    iput-object v1, v0, Lcom/tencent/android/tpush/service/channel/security/a$a;->a:[B

    const/4 v5, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-virtual {v0, p0, p1, p2, v3}, Lcom/tencent/android/tpush/service/channel/security/a$c;->a([BIIZ)Z

    const/4 v5, 0x4

    move v6, v5

    sget-boolean p0, Lcom/tencent/android/tpush/service/channel/security/a;->a:Z

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-nez p0, :cond_7

    const/4 v6, 0x4

    const/4 v5, 0x6

    iget p0, v0, Lcom/tencent/android/tpush/service/channel/security/a$a;->b:I

    const/4 v5, 0x7

    move v6, v5

    if-ne p0, p3, :cond_6

    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x7

    goto :goto_2

    :cond_6
    const/4 v6, 0x3

    new-instance p0, Ljava/lang/AssertionError;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-direct {p0}, Ljava/lang/AssertionError;-><init>()V

    const/4 v6, 0x0

    throw p0

    :cond_7
    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x4

    iget-object p0, v0, Lcom/tencent/android/tpush/service/channel/security/a$a;->a:[B

    const/4 v6, 0x7

    const/4 v5, 0x0

    return-object p0
.end method
