.class public Lcom/tencent/android/tpush/service/channel/security/e;
.super Ljava/lang/Object;


# static fields
.field static final synthetic a:Z = true


# instance fields
.field private b:[I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v0, 0x4

    const/4 v1, 0x3

    return-void
.end method

.method public constructor <init>([B)V
    .locals 9

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x6

    const/4 v0, 0x4

    const/4 v8, 0x0

    const/4 v7, 0x1

    new-array v1, v0, [I

    const/4 v8, 0x6

    const/4 v7, 0x0

    const/4 v8, 0x4

    iput-object v1, p0, Lcom/tencent/android/tpush/service/channel/security/e;->b:[I

    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x7

    if-eqz p1, :cond_2

    const/4 v8, 0x5

    array-length v1, p1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    const/16 v2, 0x10

    const/4 v7, 0x1

    and-int/2addr v8, v7

    if-lt v1, v2, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x5

    const/4 v8, 0x5

    const/4 v1, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    move v3, v1

    move v3, v1

    const/4 v8, 0x1

    move v3, v1

    :goto_0
    const/4 v7, 0x2

    const/4 v8, 0x3

    if-ge v1, v0, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x6

    iget-object v4, p0, Lcom/tencent/android/tpush/service/channel/security/e;->b:[I

    const/4 v8, 0x7

    add-int/lit8 v5, v3, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x3

    const/4 v8, 0x6

    aget-byte v3, p1, v3

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x3

    and-int/lit16 v3, v3, 0xff

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x5

    add-int/lit8 v6, v5, 0x1

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x3

    aget-byte v5, p1, v5

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x4

    and-int/lit16 v5, v5, 0xff

    const/4 v8, 0x6

    const/4 v7, 0x4

    shl-int/lit8 v5, v5, 0x8

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x5

    or-int/2addr v3, v5

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x5

    add-int/lit8 v5, v6, 0x1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x2

    aget-byte v6, p1, v6

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x7

    and-int/lit16 v6, v6, 0xff

    const/4 v8, 0x6

    const/4 v7, 0x3

    const/4 v8, 0x2

    shl-int/2addr v6, v2

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x5

    or-int/2addr v3, v6

    const/4 v8, 0x1

    const/4 v7, 0x7

    const/4 v8, 0x5

    add-int/lit8 v6, v5, 0x1

    const/4 v8, 0x3

    const/4 v7, 0x7

    const/4 v8, 0x3

    aget-byte v5, p1, v5

    const/4 v8, 0x3

    const/4 v7, 0x5

    const/4 v8, 0x0

    and-int/lit16 v5, v5, 0xff

    const/4 v7, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x2

    shl-int/lit8 v5, v5, 0x18

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x6

    or-int/2addr v3, v5

    const/4 v8, 0x1

    const/4 v7, 0x3

    const/4 v8, 0x6

    aput v3, v4, v1

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    add-int/lit8 v1, v1, 0x1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x2

    move v3, v6

    move v3, v6

    const/4 v8, 0x4

    move v3, v6

    move v3, v6

    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x3

    goto :goto_0

    :cond_0
    const/4 v8, 0x0

    return-void

    :cond_1
    const/4 v8, 0x5

    const/4 v7, 0x7

    const/4 v8, 0x0

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string/jumbo v0, "s1ssesntnaLg tk:e vdwhI a 6bae st liyyes l"

    const-string/jumbo v0, "sgslyet : kt Insl Le ehydsisa anb6tewvha1 "

    const/4 v8, 0x0

    const-string/jumbo v0, "se6my k L  dsnIe atbs1 hnagly:lsew tntahie"

    const-string v0, "Invalid key: Length was less than 16 bytes"

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x7

    throw p1

    :cond_2
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x3

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v8, 0x5

    const/4 v7, 0x4

    const/4 v8, 0x7

    const-string/jumbo v0, "nlalowayIynv Ks:euei m lk"

    const-string v0, " namlu eiwsedly:Kl navIky"

    const/4 v8, 0x2

    const-string v0, "ei ldbwlnvkueyyn laI sK :"

    const-string v0, "Invalid key: Key was null"

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x3

    const/4 v7, 0x0

    const/4 v8, 0x5

    throw p1
.end method
