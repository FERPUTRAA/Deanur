.class public Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;
.super Ljava/lang/Object;


# static fields
.field private static final DEVICE_ID_KEY_NAME:Ljava/lang/String; = "deviceId_v1"

.field private static final DEVICE_ID_PREFIX:Ljava/lang/String; = "deviceId_"

.field private static final DEVICE_ID_VERSION:Ljava/lang/String; = "v1"

.field private static final SETTINGS_DEVICE_ID_KEY_NAME:Ljava/lang/String; = ".com.tencent.tpush.cache.deviceId_v1"

.field private static final SETTINGS_DEVICE_ID_PREFIX:Ljava/lang/String; = ".com.tencent.tpush.cache"

.field private static final SHAREPREFERENCE_FILE_NAME:Ljava/lang/String; = "device_id.vip"

.field private static final TAG:Ljava/lang/String; = "TpnsSecurity"

.field private static sApkSignature:Ljava/lang/String; = ""

.field public static tea:Lcom/tencent/android/tpush/service/channel/security/e;


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x0

    const/4 v1, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method public static generateLocalSocketServieName(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " 1s ~b-s@ @~o rbS@~aomM@u@~@Koo c~  ~@~~do@ l@ f~~  v~~@~t@~i@@~n~ f@l  o~~iy@~@~ /4@ .~/@~bt@@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x5

    if-eqz p0, :cond_0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/security/Security;->generateLocalSocketServieNameNative(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x7

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x2

    const-string v0, "TsymcSptresn"

    const-string/jumbo v0, "npsTisctyreS"

    const/4 v3, 0x0

    const-string v0, "ecrtoynuiSps"

    const-string v0, "TpnsSecurity"

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string v1, "SLf5ob9ra25ameu7i7v7cue1Se6k/ne8eN9t tgele/erbemu//auc"

    const-string v1, "Lr/mele1Suvf/uoNc79keeir9b/aaa52eem7g78teSu6nuea/ e5ct"

    const/4 v3, 0x5

    const-string v1, "/e/Scruae7c7u/oSut5521nNu6tf7abeleao9meguaLe 9irkee/e8"

    const-string v1, "generateLocalSocketServieName \u672a\u77e5\u9519\u8bef"

    invoke-static {v0, v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    const/4 v2, 0x5

    move v3, v2

    new-instance p0, Ljava/lang/SecurityException;

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    const-string/jumbo v0, "nclsoeepeeoatstoa e arerckrmel gn vrr r"

    const-string v0, "generate local socket server name error"

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-direct {p0, v0}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x2

    throw p0
.end method

.method public static getBusinessDeviceId(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz p0, :cond_2

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->getSettingsLocalDeviceId(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    return-object v0

    :cond_0
    const/4 v1, 0x5

    invoke-static {p0}, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->getPreferenceLocalDeviceId(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->setSettingsLocalDeviceId(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v1, 0x5

    move v2, v1

    return-object v0

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/security/Security;->getBusinessDeviceIdNative(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object v0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->setPreferenceLocalDeviceId(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->setSettingsLocalDeviceId(Landroid/content/Context;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x1

    return-object v0

    :cond_2
    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x7

    new-instance p0, Ljava/lang/SecurityException;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string/jumbo v0, "sulreelxqe o r etdbgeestn ioruiov  su snccecnitdai"

    const-string/jumbo v0, "nes onuleenribcselred uodveu iscti  ogrc extat is "

    const/4 v2, 0x0

    const-string v0, "essoxb dtn uerusu arceigcn ceer n s lvissted itoil"

    const-string v0, "get business device id error cause context is null"

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    throw p0
.end method

.method public static getEncryptAPKSignature(Landroid/content/Context;)Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->sApkSignature:Ljava/lang/String;

    const/4 v1, 0x2

    shr-int/2addr v2, v1

    invoke-static {v0}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x5

    if-nez v0, :cond_0

    const/4 v2, 0x2

    const-string/jumbo p0, "yTsmStbneriu"

    const-string/jumbo p0, "tiuTSbpsrney"

    const/4 v2, 0x2

    const-string/jumbo p0, "ntiuoseycTrp"

    const-string p0, "TpnsSecurity"

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string/jumbo v0, "udgalb nectcerhuaera kaapdSy"

    const-string/jumbo v0, "uakaScue daarnacelegd  thyrp"

    const/4 v2, 0x6

    const-string v0, "eahceauidyetakac rdn lurpga "

    const-string v0, "apkSignature already cached "

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    sget-object p0, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->sApkSignature:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-object p0

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    if-eqz p0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/security/Security;->getEncryptAPKSignatureNative(Ljava/lang/Object;)Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    sput-object p0, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->sApkSignature:Ljava/lang/String;

    const/4 v1, 0x1

    move v2, v1

    return-object p0

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x5

    new-instance p0, Ljava/lang/SecurityException;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string/jumbo v0, "nreurskperacrpeepp ot rigtg tya"

    const-string/jumbo v0, "traeet pgratr  rpceneuopysrigkn"

    const-string/jumbo v0, "rspaotceqeag t rtrn krrpeuegiyn"

    const-string v0, "get encrypt apk signature error"

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Ljava/lang/SecurityException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    throw p0
.end method

.method private static getPreferenceLocalDeviceId(Landroid/content/Context;)Ljava/lang/String;
    .locals 5

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x5

    const-string/jumbo v0, "iqsi.v_pceeid"

    const-string v0, "edv_evipqii.c"

    const/4 v4, 0x2

    const-string v0, "d._mcivvpedii"

    const-string v0, "device_id.vip"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v0, "evcvoI_desi"

    const-string/jumbo v0, "ivsv_e1ecId"

    const/4 v4, 0x0

    const-string v0, "edv_Ibed1vc"

    const-string v0, "deviceId_v1"

    const/4 v4, 0x7

    const/4 v3, 0x3

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-interface {p0, v1}, Landroid/content/SharedPreferences;->contains(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x2

    const/4 v2, 0x0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez v1, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    return-object v2

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-interface {p0, v0, v2}, Landroid/content/SharedPreferences;->getString(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz p0, :cond_3

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {p0}, Ljava/lang/String;->trim()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x4

    const-string v1, ""

    const-string v1, ""

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    if-eqz v0, :cond_1

    const/4 v4, 0x3

    goto :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x5

    if-eqz v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    return-object v2

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    return-object p0

    :cond_3
    :goto_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object v2
.end method

.method private static getSettingsLocalDeviceId(Landroid/content/Context;)Ljava/lang/String;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string/jumbo v0, "th.euauv.cchcdimte_1eme.c.notpcIvns."

    const-string v0, "cammv1..voeeitc.ncsn_phcIeut.cd.htde"

    const/4 v3, 0x2

    const-string v0, "cdts..vppt.thee._ncie1.menuocdchveaI"

    const-string v0, ".com.tencent.tpush.cache.deviceId_v1"

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p0, v0}, Lcom/tencent/android/tpush/service/util/e;->a(Landroid/content/Context;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v2, 0x6

    move v3, v2

    if-nez p0, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x3

    return-object v0

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x7

    if-eqz v1, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x3

    return-object v0

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object p0
.end method

.method public static getTEA()Lcom/tencent/android/tpush/service/channel/security/e;
    .locals 4

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->tea:Lcom/tencent/android/tpush/service/channel/security/e;

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x6

    if-nez v0, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v0, Lcom/tencent/android/tpush/service/channel/security/e;

    const/4 v3, 0x3

    const-string v1, "49b8oed2c067fa13"

    const/4 v3, 0x3

    const-string v1, "f6c25e01q48da379"

    const-string v1, "0123456789abcdef"

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->getBytes()[B

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {v0, v1}, Lcom/tencent/android/tpush/service/channel/security/e;-><init>([B)V

    const/4 v2, 0x2

    const/4 v3, 0x6

    sput-object v0, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->tea:Lcom/tencent/android/tpush/service/channel/security/e;

    :cond_0
    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/service/channel/security/TpnsSecurity;->tea:Lcom/tencent/android/tpush/service/channel/security/e;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x1

    return-object v0
.end method

.method public static oiSymmetryDecrypt2(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x0

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x2

    invoke-virtual {v0}, Ljava/lang/String;->getBytes()[B

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x6

    const-string v1, "aisdbl"

    const-string v1, "dlieab"

    const/4 v5, 0x6

    const-string/jumbo v1, "laimef"

    const-string v1, "failed"

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string/jumbo v2, "iecpouStyusn"

    const-string v2, "TuntyiueScsp"

    const/4 v5, 0x1

    const-string/jumbo v2, "reuiTbnStsyc"

    const-string v2, "TpnsSecurity"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-eqz p0, :cond_5

    :try_start_0
    const/4 v5, 0x4

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x4

    if-gtz v3, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    goto :goto_2

    :cond_0
    const/4 v5, 0x1

    invoke-static {p0}, Lcom/tencent/android/tpush/service/channel/security/b;->a(Ljava/lang/String;)[B

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eqz p0, :cond_4

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    array-length v0, p0

    const/4 v4, 0x5

    move v5, v4

    if-gtz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x3

    goto :goto_1

    :cond_1
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/security/Security;->oiSymmetryDecrypt2Byte([B)[B

    move-result-object p0

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-eqz p0, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    array-length v0, p0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    if-gtz v0, :cond_2

    const/4 v4, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x2

    new-instance v0, Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-direct {v0, p0}, Ljava/lang/String;-><init>([B)V

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x3

    return-object v0

    :cond_3
    :goto_0
    :try_start_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x5

    const-string p0, "5 u7D1u3e>mrfe56/29p 8/du2bumyu/f4/365/yu5a7/3u>c7u0/f//ydeact2bide6pruc8e75/S985tuuub2/"

    const-string p0, " u>aa/epc/ub/r5y8u4d9cubuu/3y7p//06uSryuei/d254t5//u2u meed67t6/3/1f5>u7fc597D825bef2m38"

    const/4 v5, 0x0

    const-string/jumbo p0, "uy/ du7poc/09u2y>e/fSu6>/d169fc5ma35/i5t ey3rbeu5b/Db38e/22t/eu/6p4/274umu5f8drucu57a8u7"

    const-string p0, ">> oiSymmetryDecrypt2 \u89e3\u5bc6\u5931\u8d25\uff0c\u8fd4\u56de\u7a7a\u5b57\u7b26\u4e32"

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-object v1

    :cond_4
    :goto_1
    const/4 v4, 0x0

    move v5, v4

    const-string p0, ">r0e5/37q7bu88e9y2fumty619u/7uamu>/d063//7/uu2e/b fD/8pe4tScieoy/c22q58fd/au4r13d55/57 u"

    const-string p0, "d79/u151q74m8u2y0e06fe/pyu/784/53uatbd276fu fu/>/t/dr2e8/ae3u/c>u587u3cb//9yD e5uoi52mSr"

    const-string p0, "77s9yu/5/du6p5/r5b61d7Se/7/32co/9yf1b2u785ayu/52/m/uu4cDma>ue2e>futu8e4f8t803r /ui0ud/e "

    const-string p0, ">> oiSymmetryDecrypt2 \u89e3\u7801\u5931\u8d25\uff0c\u8fd4\u56de\u7a7a\u5b57\u7b26\u4e32"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-object v1

    :catchall_0
    move-exception p0

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_3

    :cond_5
    :goto_2
    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo p0, "um3m5D8ty/7euat/>eba43/biyou5ca79/p35816uy1f65>b r//e5c/ue/ 9m9u2su8r5"

    const-string p0, "i/stt72e981yu/5apbrD3c4uS6 eu9uu3 uyc/o56a/5/rfyb53/bm8/918e5e/>am>u75"

    const/4 v5, 0x5

    const-string/jumbo p0, "u5/yoy/6/b5e2eue/78953/1t43yma7 /6u a85/9uc>3SDrmb/oa5u1iu>ue5f8cut9rp"

    const-string p0, ">> oiSymmetryDecrypt2 \u89e3\u5bc6\u5185\u5bb9\u8f93\u5165\u4e3a\u7a7a"

    invoke-static {v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x0

    return-object v0

    :goto_3
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    const-string/jumbo v0, "uit2mb/y7rre mc eb1>yunf78SpE///2my6a95t9ou5>7"

    const-string v0, "icem 5nmr//6o 9ey>y/751/9m>7ur2f7ybEe2taupt8Su"

    const/4 v5, 0x1

    const-string v0, ">> oiSymmetryEncrypt2 \u672a\u77e5\u9519\u8bef"

    const/4 v5, 0x4

    const/4 v4, 0x5

    invoke-static {v2, v0, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x5

    return-object v1
.end method

.method public static oiSymmetryEncrypt2(Ljava/lang/String;)Ljava/lang/String;
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string/jumbo v0, "uifald"

    const-string v0, "failed"

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const-string v1, "iTSpscrptyun"

    const-string v1, "cnyposSrtiTu"

    const/4 v5, 0x6

    const-string v1, "TpnsSecurity"

    const/4 v5, 0x7

    if-eqz p0, :cond_3

    :try_start_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p0}, Ljava/lang/String;->length()I

    move-result v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-gtz v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x6

    const/4 v4, 0x0

    invoke-static {p0}, Lcom/tencent/tpns/baseapi/base/security/Security;->oiSymmetryEncrypt2Byte(Ljava/lang/String;)[B

    move-result-object v2

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x4

    const-string v3, "777bu0o>quu5r1bua9nc/06u/4E22b/ 3255daf 6n/u>icf2i/pudd/536/um7uuteu52ryb5eS/fefB4amf:y/t8uc8/ y"

    const-string v3, "ff80SbB7ue4u5oua9u6ym du/ r/i/u yE7b:/f>u56u/i53afr//b7/5muc2436byd2555dt>n1uft/e2ncu22u8pe0/ac7"

    const/4 v5, 0x4

    const-string v3, "b/s5fpfyd/r7u//8b:r6/nun/t/y2/u5e/0fiu1/5S6a57E ucaou >3u2>447uuicfumuee/3dt2aufc59m05672bd8B52 "

    const-string v3, ">> oiSymmetryEncrypt2 \u52a0\u5bc6\u5931\u8d25\uff0c\u8fd4\u56de\u7a7a\u5b57\u7b26\u4e32 inBuff:"

    const/4 v5, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v2, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x7

    return-object v0

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-static {v2}, Lcom/tencent/android/tpush/service/channel/security/c;->a([B)Ljava/lang/String;

    move-result-object p0

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    if-nez p0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x0

    const-string p0, "/7/mi930u5a1/ty6u7uet//18/f// 47ua67ce2u12 554/dod>78sB/ru5fES54ue2/fnud20uemuuu36r6yfbc>mp8by"

    const-string p0, "e78i/0u/um/o82u t36651BftE ur//>emuf6p7u//015yyeuu/4/un64792fda4e1/sr7cua25c55d8a/bbdSuy7>fu32"

    const/4 v5, 0x5

    const-string p0, "46u7o0fuuo8is8db>/t/6B/u/aurn5cd67u56d/3yE32p5fe1e82b /2>uy/9ma 0e7745u/1uuSa7ru1c5/e7y/fmf4/t"

    const-string p0, ">> oiSymmetryEncrypt2 Base64\u7f16\u7801\u5931\u8d25\uff0c\u8fd4\u56de\u7a7a\u5b57\u7b26\u4e32"

    const/4 v5, 0x5

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-object v0

    :cond_2
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x3

    return-object p0

    :catchall_0
    move-exception p0

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_1

    :cond_3
    :goto_0
    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string p0, ">umapb/5n//25i58>e/29c75b1u3554pyb9y3au8f rtbuu/1oc/5 yam676/eauruStE/"

    const-string p0, "/51epubpn/a5 5b/3y9/>264/7/E ar2frcte1>i5uS85c/83youtya/705uuua5u6m9bm"

    const/4 v5, 0x5

    const-string p0, ">> oiSymmetryEncrypt2 \u52a0\u5bc6\u5185\u5bb9\u8f93\u5165\u4e3a\u7a7a"

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-static {v1, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x6

    const-string p0, ""

    const-string p0, ""

    const/4 v5, 0x7

    const-string p0, ""

    const-string p0, ""
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x6

    return-object p0

    :goto_1
    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string/jumbo v2, "teoap6u5r7/um8miSye//u9y7ufq>97nrbye tc>251/E "

    const-string v2, "1>Ere5 mq/8 uu6oy5c/m//iubp977>r7292yyftenatSe"

    const/4 v5, 0x3

    const-string/jumbo v2, "u7/urbyp/u2 /tS>/925nmai7me> 5puye1ytf8r7co96e"

    const-string v2, ">> oiSymmetryEncrypt2 \u672a\u77e5\u9519\u8bef"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v1, v2, p0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-object v0
.end method

.method private static setPreferenceLocalDeviceId(Landroid/content/Context;Ljava/lang/String;)V
    .locals 4

    const/4 v2, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x7

    const-string/jumbo v0, "sed_p.viqivdi"

    const-string v0, "_psv.ievdedii"

    const/4 v3, 0x7

    const-string v0, "cvse.pdieid_i"

    const-string v0, "device_id.vip"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x2

    invoke-virtual {p0, v0, v1}, Landroid/content/Context;->getSharedPreferences(Ljava/lang/String;I)Landroid/content/SharedPreferences;

    move-result-object p0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    invoke-interface {p0}, Landroid/content/SharedPreferences;->edit()Landroid/content/SharedPreferences$Editor;

    move-result-object p0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x5

    const-string v0, "emImi_1edvd"

    const-string v0, "eddmic1e_Iv"

    const/4 v3, 0x2

    const-string v0, "c1idode_eIv"

    const-string v0, "deviceId_v1"

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/base/util/Md5;->md5(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-interface {p0, v0, p1}, Landroid/content/SharedPreferences$Editor;->putString(Ljava/lang/String;Ljava/lang/String;)Landroid/content/SharedPreferences$Editor;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-interface {p0}, Landroid/content/SharedPreferences$Editor;->commit()Z

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-void
.end method

.method private static setSettingsLocalDeviceId(Landroid/content/Context;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string v0, "ep_eibcocn.cvtce1heaItvdnds.tcme.uh."

    const-string v0, "I.idoa_eecpdntv1tet..hchcccne.evms.u"

    const/4 v2, 0x7

    const-string v0, "hocvs.ute.p.nc_.n.h1cdtacIveimeteduc"

    const-string v0, ".com.tencent.tpush.cache.deviceId_v1"

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    invoke-static {p0, v0, p1}, Lcom/tencent/android/tpush/service/util/e;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Z

    const/4 v1, 0x1

    and-int/2addr v2, v1

    return-void
.end method
