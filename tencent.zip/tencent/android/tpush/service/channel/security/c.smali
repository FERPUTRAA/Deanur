.class public Lcom/tencent/android/tpush/service/channel/security/c;
.super Ljava/io/FilterOutputStream;


# static fields
.field private static final a:[C


# instance fields
.field private b:I

.field private c:I


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/16 v0, 0x40

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    new-array v0, v0, [C

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    fill-array-data v0, :array_0

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x1

    sput-object v0, Lcom/tencent/android/tpush/service/channel/security/c;->a:[C

    const/4 v2, 0x4

    return-void

    nop

    :array_0
    .array-data 2
        0x41s
        0x42s
        0x43s
        0x44s
        0x45s
        0x46s
        0x47s
        0x48s
        0x49s
        0x4as
        0x4bs
        0x4cs
        0x4ds
        0x4es
        0x4fs
        0x50s
        0x51s
        0x52s
        0x53s
        0x54s
        0x55s
        0x56s
        0x57s
        0x58s
        0x59s
        0x5as
        0x61s
        0x62s
        0x63s
        0x64s
        0x65s
        0x66s
        0x67s
        0x68s
        0x69s
        0x6as
        0x6bs
        0x6cs
        0x6ds
        0x6es
        0x6fs
        0x70s
        0x71s
        0x72s
        0x73s
        0x74s
        0x75s
        0x76s
        0x77s
        0x78s
        0x79s
        0x7as
        0x30s
        0x31s
        0x32s
        0x33s
        0x34s
        0x35s
        0x36s
        0x37s
        0x38s
        0x39s
        0x2bs
        0x2fs
    .end array-data
.end method

.method public constructor <init>(Ljava/io/OutputStream;)V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0, p1}, Ljava/io/FilterOutputStream;-><init>(Ljava/io/OutputStream;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method public static a([B)Ljava/lang/String;
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v5, "o@s ~f~~ @o@i~sl1u o @. i ~~@~~~@~@dnty~-~v@@4or@~  ~bo/ ~mM KS@b i~@t@ b~c~~ o@~a@ l/@@f@~   @@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x2

    new-instance v0, Ljava/io/ByteArrayOutputStream;

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    array-length v1, p0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x2

    int-to-double v1, v1

    const/4 v6, 0x7

    const-wide v3, 0x3ff5eb851eb851ecL    # 1.37

    const-wide v3, 0x3ff5eb851eb851ecL    # 1.37

    const/4 v6, 0x3

    const-wide v3, 0x3ff5eb851eb851ecL    # 1.37

    const-wide v3, 0x3ff5eb851eb851ecL    # 1.37

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x3

    mul-double/2addr v1, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    double-to-int v1, v1

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-direct {v0, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    new-instance v1, Lcom/tencent/android/tpush/service/channel/security/c;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-direct {v1, v0}, Lcom/tencent/android/tpush/service/channel/security/c;-><init>(Ljava/io/OutputStream;)V

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v1, p0}, Ljava/io/OutputStream;->write([B)V

    const/4 v5, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpush/service/channel/security/c;->close()V

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v0}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string p0, "-sTm8"

    const-string p0, "8TsF-"

    const/4 v6, 0x1

    const-string p0, "UT8-o"

    const-string p0, "UTF-8"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v0, p0}, Ljava/io/ByteArrayOutputStream;->toString(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p0
    :try_end_0
    .catch Ljava/io/IOException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    return-object p0

    :catch_0
    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 p0, 0x2

    const/4 p0, 0x0

    const/4 v6, 0x6

    return-object p0
.end method


# virtual methods
.method public close()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    iget v0, p0, Lcom/tencent/android/tpush/service/channel/security/c;->b:I

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x5

    rem-int/lit8 v1, v0, 0x3

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    const/4 v2, 0x1

    const/4 v5, 0x4

    const/16 v3, 0x3d

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-ne v1, v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget v0, p0, Lcom/tencent/android/tpush/service/channel/security/c;->c:I

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x6

    shl-int/lit8 v0, v0, 0x4

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    and-int/lit8 v0, v0, 0x3f

    const/4 v5, 0x4

    iget-object v1, p0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    sget-object v2, Lcom/tencent/android/tpush/service/channel/security/c;->a:[C

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    aget-char v0, v2, v0

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    invoke-virtual {v1, v0}, Ljava/io/OutputStream;->write(I)V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x5

    iget-object v0, p0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-virtual {v0, v3}, Ljava/io/OutputStream;->write(I)V

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x1

    iget-object v0, p0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {v0, v3}, Ljava/io/OutputStream;->write(I)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    rem-int/lit8 v0, v0, 0x3

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x6

    const/4 v1, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    if-ne v0, v1, :cond_1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x1

    iget v0, p0, Lcom/tencent/android/tpush/service/channel/security/c;->c:I

    const/4 v4, 0x0

    move v5, v4

    shl-int/2addr v0, v1

    const/4 v5, 0x3

    const/4 v4, 0x6

    and-int/lit8 v0, v0, 0x3f

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    iget-object v1, p0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v2, Lcom/tencent/android/tpush/service/channel/security/c;->a:[C

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    aget-char v0, v2, v0

    const/4 v5, 0x0

    invoke-virtual {v1, v0}, Ljava/io/OutputStream;->write(I)V

    const/4 v5, 0x2

    iget-object v0, p0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    const/4 v4, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {v0, v3}, Ljava/io/OutputStream;->write(I)V

    :cond_1
    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x5

    invoke-super {p0}, Ljava/io/FilterOutputStream;->close()V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void
.end method

.method public write(I)V
    .locals 6

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-gez p1, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    add-int/lit16 p1, p1, 0x100

    :cond_0
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/service/channel/security/c;->b:I

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x1

    rem-int/lit8 v1, v0, 0x3

    const/4 v5, 0x6

    const/4 v2, 0x5

    const/4 v5, 0x5

    const/4 v2, 0x1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-nez v1, :cond_1

    const/4 v4, 0x4

    const/4 v5, 0x0

    shr-int/lit8 v0, p1, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x1

    and-int/lit8 p1, p1, 0x3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x2

    iput p1, p0, Lcom/tencent/android/tpush/service/channel/security/c;->c:I

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    iget-object p1, p0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x3

    sget-object v1, Lcom/tencent/android/tpush/service/channel/security/c;->a:[C

    const/4 v5, 0x4

    const/4 v4, 0x2

    aget-char v0, v1, v0

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write(I)V

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x2

    goto/16 :goto_0

    :cond_1
    const/4 v4, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x0

    rem-int/lit8 v1, v0, 0x3

    const/4 v5, 0x3

    if-ne v1, v2, :cond_2

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    iget v0, p0, Lcom/tencent/android/tpush/service/channel/security/c;->c:I

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    shl-int/lit8 v0, v0, 0x4

    const/4 v5, 0x1

    const/4 v4, 0x5

    shr-int/lit8 v1, p1, 0x4

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x7

    add-int/2addr v0, v1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    and-int/lit8 v0, v0, 0x3f

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x2

    and-int/lit8 p1, p1, 0xf

    const/4 v5, 0x0

    iput p1, p0, Lcom/tencent/android/tpush/service/channel/security/c;->c:I

    iget-object p1, p0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x5

    sget-object v1, Lcom/tencent/android/tpush/service/channel/security/c;->a:[C

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x3

    aget-char v0, v1, v0

    const/4 v5, 0x4

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write(I)V

    const/4 v5, 0x1

    const/4 v4, 0x3

    goto :goto_0

    :cond_2
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    rem-int/lit8 v0, v0, 0x3

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v1, 0x6

    const/4 v1, 0x2

    const/4 v5, 0x6

    const/4 v4, 0x3

    if-ne v0, v1, :cond_3

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    iget v0, p0, Lcom/tencent/android/tpush/service/channel/security/c;->c:I

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    shl-int/2addr v0, v1

    const/4 v5, 0x3

    shr-int/lit8 v1, p1, 0x6

    const/4 v5, 0x1

    add-int/2addr v0, v1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    and-int/lit8 v0, v0, 0x3f

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x3

    iget-object v1, p0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x2

    sget-object v3, Lcom/tencent/android/tpush/service/channel/security/c;->a:[C

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    aget-char v0, v3, v0

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-virtual {v1, v0}, Ljava/io/OutputStream;->write(I)V

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x1

    and-int/lit8 p1, p1, 0x3f

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x7

    iget-object v0, p0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    const/4 v4, 0x7

    and-int/2addr v5, v4

    aget-char p1, v3, p1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {v0, p1}, Ljava/io/OutputStream;->write(I)V

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    const/4 p1, 0x0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    iput p1, p0, Lcom/tencent/android/tpush/service/channel/security/c;->c:I

    :cond_3
    :goto_0
    const/4 v4, 0x0

    move v5, v4

    iget p1, p0, Lcom/tencent/android/tpush/service/channel/security/c;->b:I

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    add-int/2addr p1, v2

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    iput p1, p0, Lcom/tencent/android/tpush/service/channel/security/c;->b:I

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x2

    rem-int/lit8 p1, p1, 0x39

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x2

    if-nez p1, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x3

    iget-object p1, p0, Ljava/io/FilterOutputStream;->out:Ljava/io/OutputStream;

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x4

    const/16 v0, 0xa

    const/4 v5, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1, v0}, Ljava/io/OutputStream;->write(I)V

    :cond_4
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x3

    return-void
.end method

.method public write([BII)V
    .locals 4

    const/4 v2, 0x5

    move v3, v2

    const/4 v0, 0x0

    or-int/2addr v3, v0

    :goto_0
    const/4 v2, 0x1

    const/4 v3, 0x2

    if-ge v0, p3, :cond_0

    const/4 v3, 0x0

    add-int v1, p2, v0

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x5

    aget-byte v1, p1, v1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x7

    invoke-virtual {p0, v1}, Lcom/tencent/android/tpush/service/channel/security/c;->write(I)V

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    goto :goto_0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    return-void
.end method
