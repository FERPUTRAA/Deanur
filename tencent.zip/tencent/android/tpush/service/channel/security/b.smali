.class public Lcom/tencent/android/tpush/service/channel/security/b;
.super Ljava/io/FilterInputStream;


# static fields
.field private static final a:[C

.field private static final b:[I


# instance fields
.field private c:I

.field private d:I


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    const/16 v0, 0x40

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    new-array v1, v0, [C

    const/4 v5, 0x6

    fill-array-data v1, :array_0

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x6

    sput-object v1, Lcom/tencent/android/tpush/service/channel/security/b;->a:[C

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    const/16 v1, 0x80

    const/4 v5, 0x4

    new-array v1, v1, [I

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x5

    sput-object v1, Lcom/tencent/android/tpush/service/channel/security/b;->b:[I

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x6

    const/4 v1, 0x0

    :goto_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x5

    if-ge v1, v0, :cond_0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x1

    sget-object v2, Lcom/tencent/android/tpush/service/channel/security/b;->b:[I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    sget-object v3, Lcom/tencent/android/tpush/service/channel/security/b;->a:[C

    const/4 v5, 0x1

    const/4 v4, 0x5

    aget-char v3, v3, v1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    aput v1, v2, v3

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    add-int/lit8 v1, v1, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x6

    goto :goto_0

    :cond_0
    const/4 v5, 0x1

    return-void

    nop

    :array_0
    .array-data 2
        0x41s
        0x42s
        0x43s
        0x44s
        0x45s
        0x46s
        0x47s
        0x48s
        0x49s
        0x4as
        0x4bs
        0x4cs
        0x4ds
        0x4es
        0x4fs
        0x50s
        0x51s
        0x52s
        0x53s
        0x54s
        0x55s
        0x56s
        0x57s
        0x58s
        0x59s
        0x5as
        0x61s
        0x62s
        0x63s
        0x64s
        0x65s
        0x66s
        0x67s
        0x68s
        0x69s
        0x6as
        0x6bs
        0x6cs
        0x6ds
        0x6es
        0x6fs
        0x70s
        0x71s
        0x72s
        0x73s
        0x74s
        0x75s
        0x76s
        0x77s
        0x78s
        0x79s
        0x7as
        0x30s
        0x31s
        0x32s
        0x33s
        0x34s
        0x35s
        0x36s
        0x37s
        0x38s
        0x39s
        0x2bs
        0x2fs
    .end array-data
.end method

.method public constructor <init>(Ljava/io/InputStream;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x4

    invoke-direct {p0, p1}, Ljava/io/FilterInputStream;-><init>(Ljava/io/InputStream;)V

    return-void
.end method

.method public static a(Ljava/lang/String;)[B
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v7, "m~s~ ra@  d./ ~@ i @b@y~@ o~i @~ n~@ of@~tou-1@~f~~~ bSlK@ ~~@/@~o~ @@tc@s ~~@vb~@ i o@4o@~~~lM "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x0

    const/4 v0, 0x0

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x5

    new-array v1, v0, [B

    :try_start_0
    const/4 v8, 0x0

    const/4 v7, 0x6

    const/4 v8, 0x1

    const-string/jumbo v2, "sF8m-"

    const-string v2, "8-sUF"

    const/4 v8, 0x1

    const-string v2, "T-8Uo"

    const-string v2, "UTF-8"

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x0

    invoke-virtual {p0, v2}, Ljava/lang/String;->getBytes(Ljava/lang/String;)[B

    move-result-object v1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    const/4 v8, 0x3

    const/4 v7, 0x6

    const/4 v8, 0x7

    new-instance p0, Lcom/tencent/android/tpush/service/channel/security/b;

    const/4 v7, 0x4

    move v8, v7

    new-instance v2, Ljava/io/ByteArrayInputStream;

    const/4 v8, 0x3

    invoke-direct {v2, v1}, Ljava/io/ByteArrayInputStream;-><init>([B)V

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-direct {p0, v2}, Lcom/tencent/android/tpush/service/channel/security/b;-><init>(Ljava/io/InputStream;)V

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-instance v2, Ljava/io/ByteArrayOutputStream;

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x1

    array-length v1, v1

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x3

    int-to-double v3, v1

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x0

    const-wide v5, 0x3fe570a3d70a3d71L    # 0.67

    const-wide v5, 0x3fe570a3d70a3d71L    # 0.67

    const/4 v8, 0x5

    const-wide v5, 0x3fe570a3d70a3d71L    # 0.67

    const-wide v5, 0x3fe570a3d70a3d71L    # 0.67

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    mul-double/2addr v3, v5

    const/4 v8, 0x3

    const/4 v7, 0x2

    const/4 v8, 0x3

    double-to-int v1, v3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x6

    invoke-direct {v2, v1}, Ljava/io/ByteArrayOutputStream;-><init>(I)V

    const/4 v8, 0x1

    const/4 v7, 0x2

    const/4 v8, 0x5

    const/16 v1, 0x1000

    :try_start_1
    const/4 v8, 0x5

    const/4 v7, 0x3

    const/4 v8, 0x1

    new-array v1, v1, [B

    :goto_0
    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x1

    invoke-virtual {p0, v1}, Ljava/io/InputStream;->read([B)I

    move-result v3

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x1

    const/4 v4, -0x1

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    if-eq v3, v4, :cond_0

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x2

    invoke-virtual {v2, v1, v0, v3}, Ljava/io/ByteArrayOutputStream;->write([BII)V

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x4

    goto :goto_0

    :cond_0
    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x1

    invoke-virtual {p0}, Ljava/io/InputStream;->close()V

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->close()V

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    invoke-virtual {v2}, Ljava/io/ByteArrayOutputStream;->toByteArray()[B

    move-result-object p0
    :try_end_1
    .catch Ljava/io/IOException; {:try_start_1 .. :try_end_1} :catch_0

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    return-object p0

    :catch_0
    const/4 v8, 0x3

    const/4 p0, 0x0

    const/4 v8, 0x1

    move v7, p0

    move v7, p0

    const/4 v8, 0x2

    return-object p0
.end method


# virtual methods
.method public read()I
    .locals 7

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    iget-object v0, p0, Ljava/io/FilterInputStream;->in:Ljava/io/InputStream;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v0}, Ljava/io/InputStream;->read()I

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x0

    const/4 v1, -0x1

    const/4 v6, 0x1

    const/4 v5, 0x2

    if-ne v0, v1, :cond_1

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    return v1

    :cond_1
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    int-to-char v2, v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {v2}, Ljava/lang/Character;->isWhitespace(C)Z

    move-result v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-nez v2, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    iget v2, p0, Lcom/tencent/android/tpush/service/channel/security/b;->c:I

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x6

    const/4 v3, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    add-int/2addr v2, v3

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    iput v2, p0, Lcom/tencent/android/tpush/service/channel/security/b;->c:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x1

    const/16 v4, 0x3d

    const/4 v6, 0x7

    const/4 v5, 0x1

    if-ne v0, v4, :cond_2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    return v1

    :cond_2
    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x6

    sget-object v4, Lcom/tencent/android/tpush/service/channel/security/b;->b:[I

    const/4 v5, 0x6

    shl-int/2addr v6, v5

    aget v0, v4, v0

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x2

    sub-int/2addr v2, v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x0

    rem-int/lit8 v2, v2, 0x4

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-nez v2, :cond_3

    const/4 v6, 0x2

    const/4 v5, 0x1

    and-int/lit8 v0, v0, 0x3f

    const/4 v6, 0x1

    iput v0, p0, Lcom/tencent/android/tpush/service/channel/security/b;->d:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpush/service/channel/security/b;->read()I

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x7

    return v0

    :cond_3
    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x1

    if-ne v2, v3, :cond_4

    const/4 v5, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    iget v1, p0, Lcom/tencent/android/tpush/service/channel/security/b;->d:I

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    shl-int/2addr v1, v4

    const/4 v6, 0x5

    shr-int/lit8 v2, v0, 0x4

    const/4 v6, 0x6

    add-int/2addr v1, v2

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x7

    and-int/lit16 v1, v1, 0xff

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    and-int/lit8 v0, v0, 0xf

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    iput v0, p0, Lcom/tencent/android/tpush/service/channel/security/b;->d:I

    const/4 v6, 0x5

    return v1

    :cond_4
    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v3, 0x5

    const/4 v3, 0x3

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-ne v2, v4, :cond_5

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget v1, p0, Lcom/tencent/android/tpush/service/channel/security/b;->d:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    shl-int/lit8 v1, v1, 0x4

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    shr-int/lit8 v2, v0, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    add-int/2addr v1, v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    and-int/lit16 v1, v1, 0xff

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x6

    and-int/2addr v0, v3

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput v0, p0, Lcom/tencent/android/tpush/service/channel/security/b;->d:I

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    return v1

    :cond_5
    const/4 v6, 0x4

    const/4 v5, 0x6

    if-ne v2, v3, :cond_6

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/service/channel/security/b;->d:I

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x2

    shl-int/lit8 v1, v1, 0x6

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x1

    add-int/2addr v1, v0

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    and-int/lit16 v0, v1, 0xff

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    return v0

    :cond_6
    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x3

    return v1
.end method

.method public read([BII)I
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x2

    array-length v0, p1

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    add-int v1, p3, p2

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    add-int/lit8 v1, v1, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    if-lt v0, v1, :cond_3

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x2

    shr-int/2addr v3, v0

    :goto_0
    const/4 v4, 0x3

    if-ge v0, p3, :cond_2

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {p0}, Lcom/tencent/android/tpush/service/channel/security/b;->read()I

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    const/4 v2, -0x1

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    if-ne v1, v2, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    return v2

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-ne v1, v2, :cond_1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x4

    goto :goto_1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x0

    add-int v2, p2, v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    int-to-byte v1, v1

    const/4 v4, 0x3

    aput-byte v1, p1, v2

    const/4 v3, 0x2

    add-int/lit8 v0, v0, 0x1

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    goto :goto_0

    :cond_2
    :goto_1
    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x6

    return v0

    :cond_3
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    new-instance v0, Ljava/io/IOException;

    const/4 v3, 0x7

    shr-int/2addr v4, v3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x1

    const-string/jumbo v2, "m  ehbimiopTf:l etu sonrtf a bs"

    const-string/jumbo v2, "r umiusptostfl:bm  eh nTfeao i "

    const/4 v4, 0x3

    const-string/jumbo v2, "rte  auTeumlinuisb   sof :hflpt"

    const-string v2, "The input buffer is too small: "

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string p3, " snrboqp eft e tttud reoesystga fasi"

    const-string p3, "   sotrese otstnte b giyreaafstudfeq"

    const/4 v4, 0x2

    const-string p3, "eotyfstsqtgtsr sf naq  re ueideb tet"

    const-string p3, " bytes requested starting at offset "

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-virtual {v1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string p2, "he ifbryi  fbloltsh wu  ee "

    const/4 v4, 0x6

    const-string p2, "ewsl ffsnu  h o yiretb eil "

    const-string p2, " while the buffer  is only "

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    array-length p1, p1

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string/jumbo p1, "ut mb.snegyo"

    const-string p1, ".tynlbuo ges"

    const/4 v4, 0x4

    const-string/jumbo p1, "oyb ogslt e."

    const-string p1, " bytes long."

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x1

    const/4 v3, 0x1

    invoke-direct {v0, p1}, Ljava/io/IOException;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    throw v0
.end method
