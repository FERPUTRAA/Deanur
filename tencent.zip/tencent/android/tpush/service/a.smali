.class public Lcom/tencent/android/tpush/service/a;
.super Ljava/lang/Object;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20150316"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;
    }
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/service/a$b;,
        Lcom/tencent/android/tpush/service/a$d;,
        Lcom/tencent/android/tpush/service/a$c;,
        Lcom/tencent/android/tpush/service/a$a;
    }
.end annotation


# static fields
.field private static a:Lcom/tencent/android/tpush/service/a;

.field private static volatile b:Lcom/tencent/android/tpush/service/a$a;

.field private static volatile c:Lcom/tencent/android/tpush/service/a$c;

.field private static volatile d:Lcom/tencent/android/tpush/service/a$d;


# instance fields
.field private volatile e:Z

.field private f:Ljava/util/ArrayList;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/ArrayList<",
            "Landroid/content/Intent;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    const/4 v0, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    iput-boolean v0, p0, Lcom/tencent/android/tpush/service/a;->e:Z

    const/4 v2, 0x6

    const/4 v1, 0x4

    new-instance v0, Ljava/util/ArrayList;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/service/a;->f:Ljava/util/ArrayList;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x6

    return-void
.end method

.method public static declared-synchronized a()Lcom/tencent/android/tpush/service/a;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "r@s~@K/ /~~@~@ ~1@vm~f~~ ~~o~ii@~i~cS~l @da  ~~M@@b@@ @o ~yb.~ot@n      @@@~@@~~~-@ofs u4blot @ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-class v0, Lcom/tencent/android/tpush/service/a;

    const-class v0, Lcom/tencent/android/tpush/service/a;

    const/4 v3, 0x6

    const-class v0, Lcom/tencent/android/tpush/service/a;

    const-class v0, Lcom/tencent/android/tpush/service/a;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    sget-object v1, Lcom/tencent/android/tpush/service/a;->a:Lcom/tencent/android/tpush/service/a;

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x7

    new-instance v1, Lcom/tencent/android/tpush/service/a;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-direct {v1}, Lcom/tencent/android/tpush/service/a;-><init>()V

    const/4 v2, 0x2

    move v3, v2

    sput-object v1, Lcom/tencent/android/tpush/service/a;->a:Lcom/tencent/android/tpush/service/a;

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x4

    sget-object v1, Lcom/tencent/android/tpush/service/a;->a:Lcom/tencent/android/tpush/service/a;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object v1

    :catchall_0
    move-exception v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    monitor-exit v0

    const/4 v2, 0x1

    const/4 v3, 0x3

    throw v1
.end method

.method private a(IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x4

    new-instance p2, Landroid/content/Intent;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    const-string p3, "com.tencent.android.xg.vip.action.QUERYTAGS.RESULT.V4"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {p2, p3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string/jumbo p3, "tada"

    const-string p3, "atda"

    const/4 v2, 0x3

    const-string p3, "data"

    const-string p3, "data"

    const/4 v1, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p2, p3, p5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string p3, "antmoriep"

    const-string/jumbo p3, "operation"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x1

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-virtual {p2, p3, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    invoke-static {p4}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x6

    if-nez p3, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x2

    invoke-virtual {p2, p4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p3, p2}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x7

    const/4 v1, 0x2

    invoke-direct {p0, p1, p4, p5, p6}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x0

    return-void
.end method

.method private a(ILcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v0, 0x1

    const/4 v4, 0x6

    const/4 v3, 0x2

    invoke-static {p1, p4, v0}, Lcom/tencent/android/tpush/service/util/g;->a(ILjava/lang/String;I)Landroid/content/Intent;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-wide v1, p2, Lcom/tencent/android/tpush/service/protocol/m;->a:J

    const/4 v3, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string p4, "dIsco"

    const-string p4, "Idsca"

    const/4 v4, 0x1

    const-string p4, "bcadc"

    const-string p4, "accId"

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {p1, p4, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz p3, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result p4

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz p4, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    const-string/jumbo p4, "oenmt"

    const/4 v4, 0x1

    const-string/jumbo p4, "nuteo"

    const-string/jumbo p4, "token"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {p1, p4, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x0

    iget-object p3, p2, Lcom/tencent/android/tpush/service/protocol/m;->e:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-eqz p3, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result p3

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz p3, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo p3, "kettoc"

    const/4 v4, 0x6

    const-string/jumbo p3, "tpceti"

    const-string/jumbo p3, "ticket"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object p4, p2, Lcom/tencent/android/tpush/service/protocol/m;->e:Ljava/lang/String;

    const/4 v4, 0x5

    invoke-virtual {p1, p3, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string p3, "bTyeceikqt"

    const-string/jumbo p3, "teiyebcTkt"

    const/4 v4, 0x4

    const-string/jumbo p3, "yesetTkcit"

    const-string/jumbo p3, "ticketType"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    iget-short p4, p2, Lcom/tencent/android/tpush/service/protocol/m;->f:S

    const/4 v4, 0x1

    invoke-virtual {p1, p3, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;S)Landroid/content/Intent;

    :cond_1
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget-object p3, p2, Lcom/tencent/android/tpush/service/protocol/m;->c:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    if-eqz p3, :cond_2

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {p3}, Ljava/lang/String;->length()I

    move-result p3

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    if-eqz p3, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string p3, "eddmIvie"

    const-string p3, "diIeeduv"

    const/4 v4, 0x7

    const-string p3, "deviceId"

    const/4 v4, 0x7

    iget-object p4, p2, Lcom/tencent/android/tpush/service/protocol/m;->c:Ljava/lang/String;

    const/4 v4, 0x7

    invoke-virtual {p1, p3, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-wide/16 p3, 0x0

    const-wide/16 p3, 0x0

    const/4 v4, 0x1

    const-wide/16 p3, 0x0

    const-wide/16 p3, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    cmp-long p3, p5, p3

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    if-ltz p3, :cond_3

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string/jumbo p3, "uptPoryesohpT"

    const-string/jumbo p3, "oePsTuepphtyr"

    const/4 v4, 0x5

    const-string/jumbo p3, "rTyhtbsepuPhe"

    const-string/jumbo p3, "otherPushType"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p1, p3, p5, p6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p7}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p3

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-nez p3, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string/jumbo p3, "tThhPqurksuone"

    const-string/jumbo p3, "keuhhsrtqnTooP"

    const/4 v4, 0x4

    const-string p3, "ThPotehpuenrok"

    const-string/jumbo p3, "otherPushToken"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {p1, p3, p7}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_3
    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p2}, Lcom/tencent/android/tpush/service/a;->a(Ljava/lang/Object;)Z

    move-result p2

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    if-eqz p2, :cond_4

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string/jumbo p2, "ntrorliCqdCorleormFgstuo"

    const-string/jumbo p2, "oesrtiCloCrrnosgtmFroudl"

    const/4 v4, 0x1

    const-string p2, "FosulrosCCietoerogtndrrl"

    const-string/jumbo p2, "registerFromCloudControl"

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {p1, p2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Z)Landroid/content/Intent;

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p2

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    return-void
.end method

.method private a(ILcom/tencent/android/tpush/service/protocol/n;Lcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;ZLjava/lang/String;)V
    .locals 9

    const/4 v8, 0x6

    new-instance p5, Landroid/content/Intent;

    const/4 v8, 0x3

    const-string/jumbo v0, "oecmo...VRmca4EpgEd.ETiIUnicxteS.GinL..mSdRttnvo.TRa"

    const-string v0, "dEtmGv.nVTcnSS.cgxERREc.4iTa.LoUm.Rno.oead.nt.eptIii"

    const-string v0, ".GtpoonEonISU...L4oningRacVm.i.TtvEdSarERicc.eRdTxe."

    const-string v0, "com.tencent.android.xg.vip.action.REGISTER.RESULT.V4"

    invoke-direct {p5, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x5

    iget-wide v0, p3, Lcom/tencent/android/tpush/service/protocol/m;->a:J

    const/4 v8, 0x1

    const-string v2, "bodIc"

    const-string v2, "dcaIo"

    const-string v2, "Iuadc"

    const-string v2, "accId"

    const/4 v8, 0x0

    invoke-virtual {p5, v2, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v8, 0x2

    iget-object v0, p2, Lcom/tencent/android/tpush/service/protocol/n;->b:Ljava/lang/String;

    const/4 v8, 0x1

    const-string v1, "data"

    const-string/jumbo v1, "taad"

    const-string v1, "data"

    const-string v1, "data"

    const/4 v8, 0x0

    invoke-virtual {p5, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v8, 0x4

    sget-object v0, Lcom/tencent/android/tpush/common/ReturnCode;->FLAG_ONLINE:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v8, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v0

    const/4 v8, 0x3

    const-string/jumbo v1, "lagf"

    const-string v1, "gafl"

    const-string/jumbo v1, "lfag"

    const-string v1, "flag"

    const/4 v8, 0x2

    invoke-virtual {p5, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v8, 0x3

    const-string v0, "deoc"

    const-string v0, "edoc"

    const-string v0, "deco"

    const-string v0, "code"

    const/4 v8, 0x6

    invoke-virtual {p5, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v8, 0x5

    const-string/jumbo v0, "ineropapb"

    const-string/jumbo v0, "roanobepi"

    const-string/jumbo v0, "intpearoq"

    const-string/jumbo v0, "operation"

    const/4 v8, 0x1

    const/4 v1, 0x0

    const/4 v8, 0x0

    invoke-virtual {p5, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v8, 0x0

    const-string v0, "esseouPhtTuph"

    const-string/jumbo v0, "oeyuhsuPtTehp"

    const-string/jumbo v0, "oepmehPuhsytT"

    const-string/jumbo v0, "otherPushType"

    const/4 v8, 0x1

    iget-wide v1, p2, Lcom/tencent/android/tpush/service/protocol/n;->d:J

    const/4 v8, 0x1

    invoke-virtual {p5, v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v8, 0x5

    const-string v0, "eThhoeuotopksn"

    const-string/jumbo v0, "kterhhepsounoT"

    const-string/jumbo v0, "netoubhesTkoPr"

    const-string/jumbo v0, "otherPushToken"

    const/4 v8, 0x3

    iget-object v1, p2, Lcom/tencent/android/tpush/service/protocol/n;->e:Ljava/lang/String;

    const/4 v8, 0x6

    invoke-virtual {p5, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v8, 0x4

    const-string/jumbo v0, "st5tlsudMNr"

    const-string/jumbo v0, "lastNMd5str"

    const/4 v8, 0x5

    invoke-virtual {p5, v0, p6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v8, 0x5

    new-instance p6, Lcom/tencent/android/tpush/data/RegisterEntity;

    const/4 v8, 0x4

    invoke-direct {p6}, Lcom/tencent/android/tpush/data/RegisterEntity;-><init>()V

    const/4 v8, 0x0

    iget-wide v0, p3, Lcom/tencent/android/tpush/service/protocol/m;->a:J

    const/4 v8, 0x7

    iput-wide v0, p6, Lcom/tencent/android/tpush/data/RegisterEntity;->accessId:J

    const/4 v8, 0x1

    iget-object v0, p3, Lcom/tencent/android/tpush/service/protocol/m;->b:Ljava/lang/String;

    const/4 v8, 0x2

    iput-object v0, p6, Lcom/tencent/android/tpush/data/RegisterEntity;->accessKey:Ljava/lang/String;

    const/4 v8, 0x2

    iget-object v0, p2, Lcom/tencent/android/tpush/service/protocol/n;->b:Ljava/lang/String;

    const/4 v8, 0x0

    iput-object v0, p6, Lcom/tencent/android/tpush/data/RegisterEntity;->token:Ljava/lang/String;

    const/4 v8, 0x4

    iget-wide v0, p3, Lcom/tencent/android/tpush/service/protocol/m;->s:J

    const/4 v8, 0x6

    iput-wide v0, p6, Lcom/tencent/android/tpush/data/RegisterEntity;->channelId:J

    const/4 v8, 0x2

    iput-object p4, p6, Lcom/tencent/android/tpush/data/RegisterEntity;->packageName:Ljava/lang/String;

    const/4 v8, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v8, 0x0

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const-wide/16 v2, 0x3e8

    const/4 v8, 0x0

    div-long/2addr v0, v2

    const/4 v8, 0x2

    iput-wide v0, p6, Lcom/tencent/android/tpush/data/RegisterEntity;->timestamp:J

    const/4 v8, 0x7

    invoke-static {p6}, Lcom/tencent/android/tpush/service/cache/CacheManager;->addRegisterInfo(Lcom/tencent/android/tpush/data/RegisterEntity;)V

    const/4 v8, 0x4

    iget-wide v0, p2, Lcom/tencent/android/tpush/service/protocol/n;->c:J

    const/4 v8, 0x7

    iput-wide v0, p6, Lcom/tencent/android/tpush/data/RegisterEntity;->guid:J

    const/4 v8, 0x0

    invoke-static {p4}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p6

    const/4 v8, 0x1

    if-nez p6, :cond_0

    const/4 v8, 0x5

    invoke-virtual {p5, p4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v8, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p6

    const/4 v8, 0x5

    invoke-static {p6, p5}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    :try_start_0
    const/4 v8, 0x5

    iget-object p5, p2, Lcom/tencent/android/tpush/service/protocol/n;->i:Ljava/lang/String;

    const/4 v8, 0x2

    invoke-static {p5}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p6

    const/4 v8, 0x4

    if-eqz p6, :cond_1

    const/4 v8, 0x1

    iget-object v3, p2, Lcom/tencent/android/tpush/service/protocol/n;->b:Ljava/lang/String;

    const/4 v8, 0x6

    iget-wide v5, p2, Lcom/tencent/android/tpush/service/protocol/n;->d:J

    const/4 v8, 0x2

    iget-object v7, p2, Lcom/tencent/android/tpush/service/protocol/n;->e:Ljava/lang/String;

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v8, 0x0

    move v1, p1

    move v1, p1

    move v1, p1

    move v1, p1

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    const/4 v8, 0x2

    invoke-direct/range {v0 .. v7}, Lcom/tencent/android/tpush/service/a;->a(ILcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V

    const/4 v8, 0x3

    goto :goto_0

    :cond_1
    const/4 v8, 0x0

    iget p2, p2, Lcom/tencent/android/tpush/service/protocol/n;->j:I

    const/4 v8, 0x6

    invoke-direct {p0, p1, p5, p2, p4}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x2

    goto :goto_0

    :catchall_0
    const/4 v8, 0x6

    const-string/jumbo p1, "isPatcopdHelnscrqSaehvuraBe"

    const-string p1, "BaeedrsrquavHePandclScthois"

    const-string/jumbo p1, "ieatsnBhquSaHcovdalrPerrces"

    const-string p1, "PushServiceBroadcastHandler"

    const/4 v8, 0x0

    const-string/jumbo p2, "xesgsrsasnectrHit dprlesueeScdreucon "

    const-string/jumbo p2, "nesiecuxrudnseclreeHrspaeoS c dtsterg"

    const-string/jumbo p2, "us mScexrretncpHrelfessgarctuieod dne"

    const-string/jumbo p2, "unexpected for registerSuccessHandler"

    const/4 v8, 0x1

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v8, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p1

    const/4 v8, 0x6

    if-eqz p1, :cond_2

    const/4 v8, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p1

    const/4 v8, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/a;->b(Landroid/content/Context;)V

    :cond_2
    const/4 v8, 0x2

    return-void
.end method

.method private a(ILcom/tencent/android/tpush/service/protocol/r;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x4

    new-instance p2, Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string v0, "Sa.No.TtcdcitVn.pdomnEtiU..g.o.eTU4mrneoREnR.LxvESicRG"

    const-string v0, "LximIRntR.oeUGnm..nVtoRUr.cEEae.TSSi.vN.cdTEt4ngopd.ci"

    const-string v0, "eaUgpboTRvd.tntn.TtiESGaNRImdEnExRn....io.ocVUrSc4ec.i"

    const-string v0, "com.tencent.android.xg.vip.action.UNREGISTER.RESULT.V4"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-direct {p2, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/common/ReturnCode;->FLAG_ONLINE:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x1

    const-string v1, "alfg"

    const/4 v3, 0x7

    const-string v1, "fagl"

    const-string v1, "flag"

    const/4 v2, 0x7

    const/4 v3, 0x3

    invoke-virtual {p2, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    const-string/jumbo v0, "oatrnoueo"

    const-string/jumbo v0, "ooraoetnp"

    const/4 v3, 0x4

    const-string v0, "aonetripp"

    const-string/jumbo v0, "operation"

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {p3}, Lcom/tencent/android/tpush/service/cache/CacheManager;->UnregisterInfoSuccessByPkgName(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {p3}, Lcom/tencent/android/tpush/service/cache/CacheManager;->removeRegisterInfos(Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-static {p3}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-nez v0, :cond_0

    const/4 v3, 0x7

    invoke-virtual {p2, p3}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-direct {p0, p1, p3}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;)V

    const/4 v2, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method private a(ILjava/lang/String;)V
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 v0, 0x2

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/service/util/g;->a(ILjava/lang/String;I)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    return-void
.end method

.method private a(ILjava/lang/String;ILjava/lang/String;)V
    .locals 11

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x3

    if-nez v0, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x7

    new-instance v0, Lorg/json/JSONArray;

    const/4 v10, 0x3

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x1

    new-instance v1, Lorg/json/JSONObject;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x2

    invoke-direct {v1}, Lorg/json/JSONObject;-><init>()V

    :try_start_0
    const/4 v10, 0x3

    const/4 v9, 0x5

    const/4 v10, 0x1

    const-string v2, "bqotnac"

    const-string v2, "ccoanbt"

    const/4 v10, 0x5

    const-string/jumbo v2, "onsucct"

    const-string v2, "account"

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-virtual {v1, v2, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v9, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    const-string/jumbo v2, "punmcoctTyu"

    const-string/jumbo v2, "oTytcpucenu"

    const/4 v10, 0x3

    const-string v2, "Taucocnopye"

    const-string v2, "accountType"

    const/4 v10, 0x3

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-virtual {v1, v2, p3}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {v0, v1}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x6

    invoke-virtual {v0}, Lorg/json/JSONArray;->toString()Ljava/lang/String;

    move-result-object v5

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x5

    const/4 v7, 0x0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x1

    move v4, p1

    move v4, p1

    const/4 v10, 0x6

    move v4, p1

    move v4, p1

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    move-object v8, p4

    move-object v8, p4

    move-object v8, p4

    move-object v8, p4

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-direct/range {v3 .. v8}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x7

    const-string/jumbo p2, "raeiPbhradsaSnHvtueslcroedB"

    const-string p2, "PushServiceBroadcastHandler"

    const/4 v10, 0x5

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-string/jumbo p3, "nyApesuypSr:ocargAttJTnuotsr"

    const-string/jumbo p3, "rnoorytpSeuAa:ptrJgstcTAncsy"

    const/4 v10, 0x4

    const-string/jumbo p3, "tcTy:rcpuoArtSgpnenAtyeosJas"

    const-string p3, "getTypeAccountsJsonArrayStr:"

    const/4 v10, 0x1

    invoke-static {p2, p3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ww(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v10, 0x0

    const/4 v9, 0x1

    return-void
.end method

.method private a(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x7

    const/4 v0, 0x3

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-static {p1, p4, v0}, Lcom/tencent/android/tpush/service/util/g;->a(ILjava/lang/String;I)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string p4, "aqagNtq"

    const-string/jumbo p4, "mqgNaat"

    const/4 v2, 0x6

    const-string p4, "Ntsaamg"

    const-string/jumbo p4, "tagName"

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p1, p4, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x1

    const-string p2, "gaamstg"

    const-string p2, "gFsaagt"

    const/4 v2, 0x7

    const-string/jumbo p2, "lFagotg"

    const-string/jumbo p2, "tagFlag"

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-virtual {p1, p2, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x3

    const-string p2, "gpmNrbegaOaaet"

    const-string/jumbo p2, "tagOperageName"

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p1, p2, p5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x3

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    return-void
.end method

.method private a(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v1, ".d..EouceITdUnnRE.oA.Ltmiv4txangTTt.Bi.TcURomp.iracnS"

    const-string v1, "RITmngeoaTc.Tp4LtR.VtrEcUaUi..nmc.ion.ASTBdE.ot.ivxdn"

    const/4 v4, 0x5

    const-string v1, "iL4xUnvpTnocddge..SUt.nRcEpaAt.T.B.a.oom.nTiTriRtcIVe"

    const-string v1, "com.tencent.android.xg.vip.action.ATTRIBUTE.RESULT.V4"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string v1, "fagl"

    const-string v1, "flag"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string v1, "eopoaionq"

    const-string/jumbo v1, "nioooaetp"

    const/4 v4, 0x7

    const-string/jumbo v1, "otsaprieo"

    const-string/jumbo v1, "operation"

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {p4}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez v1, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, p4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-static {p6}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x5

    if-nez v1, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v1, "data"

    const-string v1, "data"

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1, p6}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p6

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {p6, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-direct/range {p0 .. p5}, Lcom/tencent/android/tpush/service/a;->b(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x5

    return-void
.end method

.method private a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;)V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x0

    const-string/jumbo v1, "nbVmnnrt4.gSTpeREcoR.vioaSEGc.ITtRd.tUcmd..aE.oni.iL"

    const-string/jumbo v1, "oono.bm4.aR.EcTcUiGgaSet..TcnnI.itirdESLdVe..nEtvpRR"

    const/4 v9, 0x7

    const-string v1, "cvaEo.oIrSx.U.noeRi.cSpt.Eg.LTV.ToEctniGdeinat4mRd.n"

    const-string v1, "com.tencent.android.xg.vip.action.REGISTER.RESULT.V4"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v8, 0x6

    move v9, v8

    const-string v1, "adta"

    const-string v1, "data"

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v9, 0x5

    const-string v2, ""

    const-string v2, ""

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x5

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-string v1, "deoc"

    const-string v1, "edco"

    const/4 v9, 0x1

    const-string v1, "doec"

    const-string v1, "code"

    const/4 v8, 0x6

    or-int/2addr v9, v8

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x4

    const-string/jumbo v1, "smg"

    const-string/jumbo v1, "msg"

    const/4 v9, 0x0

    const-string v1, "gms"

    const-string/jumbo v1, "msg"

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v9, 0x1

    sget-object p2, Lcom/tencent/android/tpush/common/ReturnCode;->FLAG_ONLINE:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v8, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    invoke-virtual {p2}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result p2

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    const-string v1, "gafl"

    const-string/jumbo v1, "lgfa"

    const/4 v9, 0x6

    const-string v1, "flag"

    const-string v1, "flag"

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-string/jumbo p2, "putorboea"

    const-string/jumbo p2, "troiopuae"

    const/4 v9, 0x3

    const-string/jumbo p2, "oiaornupe"

    const-string/jumbo p2, "operation"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    const/4 v1, 0x1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x7

    invoke-virtual {v0, p2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v9, 0x5

    const/4 v8, 0x0

    invoke-static {p4}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x0

    if-nez p2, :cond_0

    const/4 v8, 0x4

    move v9, v8

    invoke-virtual {v0, p4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    :try_start_0
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p2

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-eqz p3, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    iget-object p2, p3, Lcom/tencent/android/tpush/service/protocol/m;->e:Ljava/lang/String;

    const/4 v9, 0x3

    invoke-static {p2}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v0, :cond_1

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p2

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static {p2}, Lcom/tencent/tpns/baseapi/base/device/GuidInfoManager;->getToken(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-wide/16 v5, -0x1

    const/4 v9, 0x6

    const-wide/16 v5, -0x1

    const-wide/16 v5, -0x1

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x2

    const/4 v7, 0x0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x2

    move v1, p1

    move v1, p1

    const/4 v9, 0x0

    move v1, p1

    move v1, p1

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    move-object v4, p4

    move-object v4, p4

    move-object v4, p4

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-direct/range {v0 .. v7}, Lcom/tencent/android/tpush/service/a;->a(ILcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;)V

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    goto :goto_0

    :cond_1
    const/4 v8, 0x5

    move v9, v8

    iget-short p3, p3, Lcom/tencent/android/tpush/service/protocol/m;->f:S

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;ILjava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x4

    goto :goto_0

    :catchall_0
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x6

    const-string/jumbo p1, "scaPputpneeBsdiaHlodcaerrSh"

    const-string p1, "SurntohpdclesaaPsrdiBeHeacr"

    const/4 v9, 0x7

    const-string p1, "derhoevsqdaelcHtirunSBcaras"

    const-string p1, "PushServiceBroadcastHandler"

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    const-string p2, "ersqdreaoanFegHeltel idsrpfnctxuri"

    const-string p2, "dpenufxeqeenlea coariHFgertrtilsrd"

    const/4 v9, 0x2

    const-string/jumbo p2, "xrrmrenesaicgifeotl  pnadtrdeHueeF"

    const-string/jumbo p2, "unexpected for registerFailHandler"

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->w(Ljava/lang/String;Ljava/lang/String;)V

    :cond_2
    :goto_0
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x7

    return-void
.end method

.method private a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/r;Ljava/lang/String;)V
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x5

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x7

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x4

    const-string/jumbo v1, "wilfoFHane iiegdsahaitrldstr ru enl"

    const-string v1, "desedin traieFHnsrei llgwifthula ra"

    const/4 v3, 0x3

    const-string v1, "erahabdigetwFlinnrlulafi e i( etrHs"

    const-string/jumbo v1, "unregisterFailHandler failed with ("

    const/4 v2, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    const-string v1, ","

    const-string v1, ","

    const/4 v3, 0x5

    const-string v1, ","

    const-string v1, ","

    const/4 v3, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x3

    invoke-virtual {v0, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    const-string p3, ")"

    const-string p3, ")"

    const/4 v3, 0x7

    const-string p3, ")"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-virtual {v0, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p3

    const/4 v3, 0x0

    const/4 v2, 0x5

    const-string v0, "HiePanuBShcuradosraldcevers"

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, p3}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    new-instance p3, Landroid/content/Intent;

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string/jumbo v0, "idetvEcpn..4dE.Srm.iiRoTRtEIGUnoULxoT.mS.Vtcpne..cNgRn"

    const-string v0, "E..mEERcrnaoo.LI4..dRe.VRUcNncTivgi.xmStinSTo.tGeptdUn"

    const/4 v3, 0x2

    const-string/jumbo v0, "n.o.Ute.qTmga.LoEidEUcVRtinTEvicceG..Io4.dnnRRrNS.xptS"

    const-string v0, "com.tencent.android.xg.vip.action.UNREGISTER.RESULT.V4"

    const/4 v2, 0x4

    xor-int/2addr v3, v2

    invoke-direct {p3, v0}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    sget-object v0, Lcom/tencent/android/tpush/common/ReturnCode;->FLAG_ONLINE:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v3, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-string v1, "afgl"

    const/4 v3, 0x3

    const-string v1, "galf"

    const-string v1, "flag"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    invoke-virtual {p3, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string v0, "dceo"

    const-string v0, "eodc"

    const/4 v3, 0x6

    const-string v0, "ecdo"

    const-string v0, "code"

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p3, v0, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x7

    const-string v0, "gsm"

    const-string/jumbo v0, "msg"

    const-string v0, "gsm"

    const-string/jumbo v0, "msg"

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p3, v0, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-string p2, "etspaionr"

    const-string p2, "eotnoiapr"

    const/4 v3, 0x7

    const-string/jumbo p2, "niomprota"

    const-string/jumbo p2, "operation"

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-virtual {p3, p2, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-static {p4}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez p2, :cond_0

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {p3, p4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x2

    or-int/2addr v3, v2

    invoke-static {p2, p3}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-direct {p0, p1, p4}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x6

    return-void
.end method

.method private a(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x7

    const/4 v0, 0x6

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {p1, p5, v0}, Lcom/tencent/android/tpush/service/util/g;->a(ILjava/lang/String;I)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string/jumbo p5, "mteconocNau"

    const-string p5, "accountName"

    const/4 v1, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-static {p2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-virtual {p1, p5, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x5

    const-string/jumbo p2, "ktaBeboceFcunbc"

    const-string p2, "auceebconcktdFB"

    const/4 v2, 0x2

    const-string/jumbo p2, "tcedFuuBnocaack"

    const-string p2, "accountFeedBack"

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p1, p2, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string p2, "etupapopere"

    const-string p2, "aeeepyutpro"

    const/4 v2, 0x2

    const-string p2, "Teyrpeaeqot"

    const-string/jumbo p2, "operateType"

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-virtual {p1, p2, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-void
.end method

.method private a(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 8

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x6

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x7

    const-string/jumbo v1, "pbslreF ia eduafia(tdtwairsletHlihn"

    const-string v1, "ah(ituFpbdriseteiwlHaa ldr a tilnef"

    const/4 v7, 0x0

    const-string/jumbo v1, "urfmaHtdiiawhtiabedetl(e rt Finasll"

    const-string v1, "attributesFailHandler failed with ("

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    const-string v1, ","

    const/4 v7, 0x0

    const-string v1, ","

    const-string v1, ","

    const/4 v6, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    const-string v1, ")"

    const/4 v7, 0x5

    const-string v1, ")"

    const-string v1, ")"

    const/4 v7, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v1, "daSeocsausreilqhonHcraBPedr"

    const-string v1, "ehSesPdsqrioBadcHuacvlrrnae"

    const/4 v7, 0x1

    const-string v1, "caelubacvsndHSrdahsreBiPero"

    const-string v1, "PushServiceBroadcastHandler"

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v1, ".a.nxLuaTpiSoU.RBin.encmUVr.deiAEITTcETv4ctg.doRn.t.s"

    const-string v1, "TxsrSTVTU.Rge.RnLE.d.aoeoncBE..pinccta4I..vimtUAitTnd"

    const-string/jumbo v1, "rmtRU.Ipoao4Ei.TcTLvin.g.teaci.RBodnTx.TActnEndV.U.ep"

    const-string v1, "com.tencent.android.xg.vip.action.ATTRIBUTE.RESULT.V4"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string v1, "alfg"

    const-string v1, "aglf"

    const/4 v7, 0x0

    const-string v1, "flag"

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    invoke-virtual {v0, v1, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string v1, "eodc"

    const-string v1, "cdoe"

    const/4 v7, 0x7

    const-string/jumbo v1, "oced"

    const-string v1, "code"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string/jumbo v1, "msg"

    const-string v1, "gms"

    const/4 v7, 0x0

    const-string/jumbo v1, "mgs"

    const-string/jumbo v1, "msg"

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x1

    const-string/jumbo p2, "inteporaq"

    const-string/jumbo p2, "operation"

    const/4 v7, 0x2

    const/4 v6, 0x2

    const/4 v7, 0x2

    const/4 v1, 0x1

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v0, p2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {p5}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p2

    const/4 v7, 0x3

    const/4 v6, 0x3

    if-nez p2, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0, p5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p2

    const/4 v7, 0x2

    const/4 v6, 0x5

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x3

    move v1, p1

    move v1, p1

    const/4 v7, 0x2

    move v1, p1

    move v1, p1

    move-object v2, p3

    move-object v2, p3

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    move v3, p4

    move v3, p4

    const/4 v7, 0x1

    move v3, p4

    move v3, p4

    move-object v4, p5

    move-object v4, p5

    move-object v4, p5

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/tencent/android/tpush/service/a;->b(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x2

    return-void
.end method

.method private a(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/16 v0, 0x8

    const/4 v1, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/service/util/g;->a(ILjava/lang/String;I)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p2

    const/4 v2, 0x2

    const/4 v1, 0x1

    if-nez p2, :cond_0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const-string p2, "aadt"

    const/4 v2, 0x1

    const-string/jumbo p2, "tdaa"

    const-string p2, "data"

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-static {p3}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p3

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-virtual {p1, p2, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string p2, "aesuTarmNyesq"

    const-string p2, "eymmaTuqrNsea"

    const/4 v2, 0x3

    const-string p2, "TyumeNesqgaam"

    const-string/jumbo p2, "queryTagsName"

    const/4 v1, 0x2

    xor-int/2addr v2, v1

    invoke-virtual {p1, p2, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-void
.end method

.method private a(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .locals 8

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x3

    const-string v1, "dwuaoittcdHohina lolen(lacF fir "

    const-string/jumbo v1, "leiooa iw Fcn ltlacat(didrhfunHe"

    const-string/jumbo v1, "ncatfbaoul adhec(daiFrlt eniiwH "

    const-string v1, "accountFailHandler failed with ("

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x4

    const-string v1, ","

    const-string v1, ","

    const/4 v7, 0x0

    const-string v1, ","

    const-string v1, ","

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x3

    invoke-virtual {v0, p6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x0

    const-string v1, ")"

    const-string v1, ")"

    const/4 v7, 0x1

    const-string v1, ")"

    const/4 v7, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string v1, "dsSBucuaPhnriHeadserlvoatrb"

    const-string v1, "adhaobBdeanSicsrevsuPcHrtlr"

    const/4 v7, 0x2

    const-string v1, "SlPcisdpucodeBsarareHatvneh"

    const-string v1, "PushServiceBroadcastHandler"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string v1, "O.puxtLnqaR.TedvnriU..i.tU.eC.4iAnoccSgdnoaVtoT.NEm"

    const-string v1, "caTVoSuextciopcCL..URgEn.o.NriUdT4ne.i..nat.tAOvdmn"

    const/4 v7, 0x3

    const-string v1, "VcseU.AtvtieERoiN.dcoSaoCgn...tpnTnLC4n.cdr.Txa.iOU"

    const-string v1, "com.tencent.android.xg.vip.action.ACCOUNT.RESULT.V4"

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string v1, "flag"

    const-string v1, "gfla"

    const/4 v7, 0x4

    const-string v1, "agfl"

    const-string v1, "flag"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v0, v1, p5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string v1, "dceo"

    const-string/jumbo v1, "oced"

    const/4 v7, 0x2

    const-string v1, "deoc"

    const-string v1, "code"

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x1

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x2

    const-string/jumbo v1, "msg"

    const-string/jumbo v1, "sgm"

    const/4 v7, 0x2

    const-string/jumbo v1, "smg"

    const-string/jumbo v1, "msg"

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x5

    const-string p2, "appmieoor"

    const-string/jumbo p2, "roaioptpe"

    const-string/jumbo p2, "tooroepin"

    const-string/jumbo p2, "operation"

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    const/4 v1, 0x1

    const/4 v7, 0x3

    invoke-virtual {v0, p2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-static {p6}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p2

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    if-nez p2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v0, p6}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p2

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x4

    move v1, p1

    move v1, p1

    const/4 v7, 0x2

    move v1, p1

    move v1, p1

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    move-object v3, p4

    move-object v3, p4

    move-object v3, p4

    move-object v3, p4

    const/4 v7, 0x7

    const/4 v6, 0x7

    move v4, p5

    move v4, p5

    const/4 v7, 0x0

    move v4, p5

    move v4, p5

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct/range {v0 .. v5}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x4

    const/4 v7, 0x3

    return-void
.end method

.method private a(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 3

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/c/a;->a()Lcom/tencent/android/tpush/c/a;

    move-result-object p2

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object p2, p2, Lcom/tencent/android/tpush/c/a;->b:Lcom/tencent/android/tpush/c/a$a;

    const/4 v1, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x0

    new-instance v0, Lcom/tencent/android/tpush/service/a$4;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x1

    invoke-direct {v0, p0, p1}, Lcom/tencent/android/tpush/service/a$4;-><init>(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-virtual {p2, v0}, Lcom/tencent/android/tpush/c/a$a;->d(Lcom/tencent/tpns/mqttchannel/api/OnMqttCallback;)V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/service/a;->b()V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a;IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct/range {p0 .. p6}, Lcom/tencent/android/tpush/service/a;->a(IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a;ILcom/tencent/android/tpush/service/protocol/n;Lcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;ZLjava/lang/String;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x2

    invoke-direct/range {p0 .. p6}, Lcom/tencent/android/tpush/service/a;->a(ILcom/tencent/android/tpush/service/protocol/n;Lcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;ZLjava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a;ILcom/tencent/android/tpush/service/protocol/r;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2, p3}, Lcom/tencent/android/tpush/service/a;->a(ILcom/tencent/android/tpush/service/protocol/r;Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x0

    invoke-direct/range {p0 .. p5}, Lcom/tencent/android/tpush/service/a;->c(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x7

    invoke-direct/range {p0 .. p6}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x3

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/m;Ljava/lang/String;)V

    const/4 v0, 0x4

    or-int/2addr v1, v0

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/r;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;Lcom/tencent/android/tpush/service/protocol/r;Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x1

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x6

    invoke-direct/range {p0 .. p5}, Lcom/tencent/android/tpush/service/a;->b(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    const/4 v0, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct/range {p0 .. p6}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    invoke-direct/range {p0 .. p6}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/a;->a(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x2

    return-void
.end method

.method private static a(Ljava/lang/Object;)Z
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x4

    const/4 p0, 0x0

    const/4 v1, 0x5

    return p0
.end method

.method private b()V
    .locals 5

    :try_start_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v1, "OA...bmvnqtELSdpKVHEO..TdoNoUg.Rt4.oitDPx.eTTn.cRcneTniaEiU.aE"

    const-string v1, "VeErdUTiqvHROD.gm4UnSit.PKA.OtE.ix.pTLn.adt.eT.Ec.oTonoERNcan."

    const/4 v4, 0x1

    const-string v1, ".RE.dcunT.RnTTt..ogn.TmiPni.aKt.rAL.ExOOvEUtNoDe.4VcdaUiESpcoH"

    const-string v1, "com.tencent.android.xg.vip.action.UPDATE.OTHER.TOKEN.RESULT.V4"

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v1, "lgaf"

    const-string v1, "aflg"

    const/4 v4, 0x7

    const-string/jumbo v1, "lafg"

    const-string v1, "flag"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    sget-object v2, Lcom/tencent/android/tpush/common/ReturnCode;->FLAG_ONLINE:Lcom/tencent/android/tpush/common/ReturnCode;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/common/ReturnCode;->getType()I

    move-result v2

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v1, "rteainspp"

    const-string v1, "atspeonri"

    const/4 v4, 0x7

    const-string v1, "aootierpq"

    const-string/jumbo v1, "operation"

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x2

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    move v4, v3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v2, "raemotsc:eerresroa  peOnhedlducunHPkurTthS"

    const/4 v4, 0x7

    const-string/jumbo v2, "updateOtherPushTokenSuccessHandler error: "

    const/4 v4, 0x1

    const/4 v3, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0}, Ljava/lang/Throwable;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v1, "acsdtorraosBeirHhvsnlPSeedc"

    const-string v1, "BohtoHearcararcdsndvePsSlie"

    const/4 v4, 0x7

    const-string/jumbo v1, "rrlmevdnsucsaerhcHPadetSBai"

    const-string v1, "PushServiceBroadcastHandler"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    return-void
.end method

.method private b(IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x3

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    const-string/jumbo p3, "trfioena(tlaHaegd  ildFahw l"

    const-string/jumbo p3, "tagFailHandler failed with ("

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x5

    const-string p3, ","

    const/4 v2, 0x7

    const-string p3, ","

    const-string p3, ","

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x4

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-virtual {p2, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p2, p4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    const-string p3, ")"

    const-string p3, ")"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string/jumbo p3, "lctcebrHBuhParsioavedbednaS"

    const-string p3, "eBshaboaSnrsrediccHvdatleuP"

    const/4 v2, 0x0

    const-string p3, "claBnHuPuesaroaSvrcedrdiste"

    const-string p3, "PushServiceBroadcastHandler"

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {p3, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x2

    new-instance p2, Landroid/content/Intent;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    const-string p3, "UnGL.napi.peAidEvn.n.a.4dTToVtt.gtuooicS.mrccRx"

    const-string p3, "UTndxLut.RicASn.dcivoatiTo.neg..VacnrmGE4po...t"

    const/4 v2, 0x4

    const-string p3, "..TELpocqe4.aA.o.a.RticUgnnxe.c.dGrttSviTioVnnd"

    const-string p3, "com.tencent.android.xg.vip.action.TAG.RESULT.V4"

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-direct {p2, p3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    const-string p3, "code"

    const-string/jumbo p3, "odec"

    const/4 v2, 0x0

    const-string p3, "edoc"

    const-string p3, "code"

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-virtual {p2, p3, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x4

    const-string/jumbo p3, "mgs"

    const-string/jumbo p3, "sgm"

    const/4 v2, 0x2

    const-string/jumbo p3, "msg"

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x6

    invoke-virtual {p2, p3, p5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x4

    const-string/jumbo p3, "resipnopo"

    const-string/jumbo p3, "ioetrnppo"

    const/4 v2, 0x4

    const-string/jumbo p3, "opemntioa"

    const-string/jumbo p3, "operation"

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x1

    const/4 v2, 0x3

    const/4 v1, 0x5

    invoke-virtual {p2, p3, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p4}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    if-nez p3, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p2, p4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p3

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p3, p2}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x7

    move v2, v1

    invoke-direct {p0, p1, p4, p5, p6}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    return-void
.end method

.method private b(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p1, p4, v0}, Lcom/tencent/android/tpush/service/util/g;->a(ILjava/lang/String;I)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x0

    const-string p4, "amtNoaesuitrbt"

    const-string/jumbo p4, "smratbuNqittea"

    const/4 v2, 0x5

    const-string p4, "atemebrisuttba"

    const-string p4, "attributesName"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-static {p2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->encrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {p1, p4, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string/jumbo p2, "lttbiuuaFsaser"

    const-string/jumbo p2, "tassailFtbuert"

    const/4 v2, 0x6

    const-string/jumbo p2, "leutatFprsgibt"

    const-string p2, "attributesFlag"

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {p1, p2, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x7

    const-string p2, "aeumeeastebitpNrOtatr"

    const/4 v2, 0x7

    const-string/jumbo p2, "rratiaetqatuebOtmNpse"

    const-string p2, "attributesOperateName"

    const/4 v2, 0x0

    invoke-virtual {p1, p2, p5}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v2, 0x7

    const/4 v1, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p2

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    return-void
.end method

.method private b(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V
    .locals 5

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x4

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string v1, "Sc4roEap.CenTgCLat..O.niUdotmvU.RniotnNi.cVoTAdex.c"

    const/4 v4, 0x4

    const-string v1, "EasdnviT.oCp4.n.Ugm.iOe.VrcCiLnUttT.ANt.cRSaenoxdc."

    const-string v1, "com.tencent.android.xg.vip.action.ACCOUNT.RESULT.V4"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string v1, "gfal"

    const/4 v4, 0x6

    const-string v1, "aglf"

    const-string v1, "flag"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v1, "epambront"

    const-string/jumbo v1, "niptaboer"

    const-string v1, "eopooarin"

    const-string/jumbo v1, "operation"

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    const/4 v2, 0x0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p5}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-nez v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x5

    invoke-virtual {v0, p5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-direct/range {p0 .. p5}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;)V

    const/4 v4, 0x7

    return-void
.end method

.method private b(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x3

    const-string/jumbo v1, "ligHdbiuahFfaewltat ade rnil"

    const-string v1, "aFltfduHa (naaleilewitghrd i"

    const/4 v7, 0x1

    const-string v1, "Hei  autlaedldiaiwag(lt rFnf"

    const-string/jumbo v1, "tagFailHandler failed with ("

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string v1, ","

    const-string v1, ","

    const/4 v7, 0x4

    const-string v1, ","

    const/4 v7, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v0, p5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    const-string v1, ")"

    const-string v1, ")"

    const/4 v7, 0x1

    const-string v1, ")"

    const-string v1, ")"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string/jumbo v1, "oBvPuecpdalStenrpdrhcisaaHs"

    const-string/jumbo v1, "rdaaiuHpccoenvhreSalBtePdss"

    const/4 v7, 0x6

    const-string v1, "aerarseuqPdarHoSslenhtccdvi"

    const-string v1, "PushServiceBroadcastHandler"

    const/4 v6, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x2

    const-string/jumbo v1, "morttxcTqont.GiV.4.ie.aETR.ddpAcUnvcgSoe.Lain.n"

    const/4 v7, 0x5

    const-string v1, "i.sxTid4ivtUo.dnrS..cTa.mcpR.engaoAecE.VL.nttno"

    const-string v1, "com.tencent.android.xg.vip.action.TAG.RESULT.V4"

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string v1, "aflg"

    const-string/jumbo v1, "lafg"

    const/4 v7, 0x4

    const-string/jumbo v1, "lfag"

    const-string v1, "flag"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v0, v1, p4}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    const-string/jumbo v1, "oedc"

    const-string/jumbo v1, "oecd"

    const/4 v7, 0x6

    const-string v1, "cdeo"

    const-string v1, "code"

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v0, v1, p1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    const-string/jumbo v1, "mgs"

    const-string v1, "gms"

    const/4 v7, 0x3

    const-string/jumbo v1, "mgs"

    const-string/jumbo v1, "msg"

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x5

    invoke-virtual {v0, v1, p2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x0

    const-string/jumbo p2, "sopmoenit"

    const-string/jumbo p2, "oasnptoie"

    const/4 v7, 0x4

    const-string/jumbo p2, "operation"

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x2

    const/4 v1, 0x1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v0, p2, v1}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-static {p5}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result p2

    const/4 v7, 0x2

    const/4 v6, 0x2

    if-nez p2, :cond_0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v0, p5}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object p2

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-static {p2, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    move-object v0, p0

    move-object v0, p0

    move-object v0, p0

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x6

    move v1, p1

    move v1, p1

    const/4 v7, 0x5

    move v1, p1

    move v1, p1

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    move-object v2, p3

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x5

    move v3, p4

    move v3, p4

    const/4 v7, 0x0

    move v3, p4

    move v3, p4

    move-object v4, p5

    move-object v4, p5

    move-object v4, p5

    move-object v4, p5

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    move-object v5, p6

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-direct/range {v0 .. v5}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x6

    return-void
.end method

.method private b(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    const/4 v0, 0x0

    const/4 v3, 0x0

    invoke-static {p1, p2, v0}, Lcom/tencent/android/tpush/service/protocol/m;->a(Landroid/content/Context;Landroid/content/Intent;Z)Lcom/tencent/android/tpush/service/protocol/m;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    if-eqz p1, :cond_0

    const/4 v2, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-eqz p2, :cond_0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {}, Lcom/tencent/android/tpush/service/c;->a()Lcom/tencent/android/tpush/service/c;

    move-result-object p2

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v1, Lcom/tencent/android/tpush/service/a$5;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x7

    invoke-direct {v1, p0, p1, v0}, Lcom/tencent/android/tpush/service/a$5;-><init>(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Lcom/tencent/android/tpush/service/protocol/m;)V

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {p2, p1, v0, v1}, Lcom/tencent/android/tpush/service/c;->a(Landroid/content/Context;Lcom/tencent/android/tpush/service/protocol/m;Lcom/tencent/android/tpush/service/c/a;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x0

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string v0, "ers oor >ertrg eir"

    const-string v0, ">> register error "

    const/4 v3, 0x2

    const/4 v2, 0x4

    const/4 v3, 0x4

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo v0, "rrdvhbcHdlamrBtSsceiosPenua"

    const-string v0, "deSmrtaHcshnusaerodBivlPerc"

    const/4 v3, 0x4

    const-string/jumbo v0, "serPvsuBSceruraoaHhlientadd"

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    const-string/jumbo v1, "trre-srp>i or r>o eg"

    const-string v1, " reeo>trr>os- er irg"

    const/4 v3, 0x1

    const-string v1, ">teg ei q>reror>rr -"

    const-string v1, ">> register error-> "

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/tencent/android/tpush/logging/TLogger;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    return-void
.end method

.method static synthetic b(Lcom/tencent/android/tpush/service/a;IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v0, 0x6

    move v1, v0

    invoke-direct/range {p0 .. p6}, Lcom/tencent/android/tpush/service/a;->b(IIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x5

    return-void
.end method

.method static synthetic b(Lcom/tencent/android/tpush/service/a;ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x1

    invoke-direct/range {p0 .. p6}, Lcom/tencent/android/tpush/service/a;->b(ILjava/lang/String;Ljava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x3

    return-void
.end method

.method static synthetic b(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/a;->b(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method static synthetic b(Lcom/tencent/android/tpush/service/a;)Z
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x4

    iget-boolean p0, p0, Lcom/tencent/android/tpush/service/a;->e:Z

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x4

    return p0
.end method

.method static synthetic c(Lcom/tencent/android/tpush/service/a;)Ljava/util/ArrayList;
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    const/4 v1, 0x4

    iget-object p0, p0, Lcom/tencent/android/tpush/service/a;->f:Ljava/util/ArrayList;

    const/4 v1, 0x0

    const/4 v0, 0x0

    return-object p0
.end method

.method private c(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V
    .locals 5

    const/4 v3, 0x0

    const/4 v4, 0x1

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const-string/jumbo v1, "nUscvgno.dncSdipt.xoaemAG.i4LiTRr.b..aEte.tTonc"

    const-string v1, "iccvmbG.nUdt.o.c.rTLexg4SiRotEo.andia.t.e.nAnTp"

    const/4 v4, 0x3

    const-string v1, ".nimnc.ATUidES.Le.tamnx4cVopa.ignR.ttvGoTeodr.."

    const-string v1, "com.tencent.android.xg.vip.action.TAG.RESULT.V4"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v1, "gafl"

    const-string/jumbo v1, "lfag"

    const/4 v4, 0x4

    const-string v1, "flag"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1, p3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v1, "ireoonpoa"

    const-string/jumbo v1, "operation"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x7

    const/4 v2, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;I)Landroid/content/Intent;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {p4}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x3

    const/4 v3, 0x7

    if-nez v1, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, p4}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    :cond_0
    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-direct/range {p0 .. p5}, Lcom/tencent/android/tpush/service/a;->a(ILjava/lang/String;ILjava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    return-void
.end method

.method private c(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 13

    if-eqz p1, :cond_0

    if-eqz p2, :cond_0

    const-string p1, "bcudI"

    const-string p1, "duccI"

    const-string p1, "duccI"

    const-string p1, "accId"

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    const-wide/16 v0, -0x1

    invoke-virtual {p2, p1, v0, v1}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const-string/jumbo p1, "ppeKca"

    const-string p1, "apyecK"

    const-string p1, "eaqccy"

    const-string p1, "accKey"

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const-string v2, "etsepapyoeq"

    const-string v2, "eeapoeTyqpt"

    const-string v2, "eyrmtTppeoe"

    const-string/jumbo v2, "operateType"

    const/4 v3, -0x1

    invoke-virtual {p2, v2, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v10

    const-string/jumbo v2, "ucasoto"

    const-string/jumbo v2, "ouscatc"

    const-string v2, "cncuobt"

    const-string v2, "account"

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    invoke-static {v2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    const-string v2, "amtcdcueancFkoe"

    const-string/jumbo v2, "ncomkecaatdFecu"

    const-string/jumbo v2, "tcdeuckpeFBonaa"

    const-string v2, "accountFeedBack"

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const-string/jumbo v2, "qeacoNam"

    const-string v2, "aacpomNe"

    const-string/jumbo v2, "packName"

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    invoke-static {p2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    :try_start_0
    invoke-static {}, Lcom/tencent/android/tpush/service/c;->a()Lcom/tencent/android/tpush/service/c;

    move-result-object p2

    new-instance v12, Lcom/tencent/android/tpush/service/a$6;

    move-object v2, v12

    move-object v2, v12

    move-object v2, v12

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-object v3, p0

    move-wide v4, v0

    move-object v7, v11

    move-object v7, v11

    move-object v7, v11

    move-object v7, v11

    move v9, v10

    move v9, v10

    invoke-direct/range {v2 .. v9}, Lcom/tencent/android/tpush/service/a$6;-><init>(Lcom/tencent/android/tpush/service/a;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;I)V

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-object v2, p2

    move-wide v3, v0

    move-object v5, p1

    move-object v5, p1

    move-object v6, v11

    move-object v6, v11

    move-object v6, v11

    move-object v6, v11

    move v7, v10

    move v7, v10

    move v7, v10

    move v7, v10

    move-object v8, v12

    move-object v8, v12

    invoke-virtual/range {v2 .. v8}, Lcom/tencent/android/tpush/service/c;->a(JLjava/lang/String;Ljava/lang/String;ILcom/tencent/android/tpush/service/c/a;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception p1

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string v0, "a srrorH> eduelAntr nocb"

    const-string/jumbo v0, "n>e rbaturHreo rodn >lAc"

    const-string/jumbo v0, "ordmter H>nArunelc ca>ro"

    const-string v0, ">> AccountHandler error "

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const-string v0, "avnuohcProuesedsBdScHlerrat"

    const-string/jumbo v0, "uePnSausHeaBcdlehtavdsrrorc"

    const-string v0, "hsaccbSvesarteunoiPaBeHdrrd"

    const-string v0, "PushServiceBroadcastHandler"

    invoke-static {v0, p2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    new-instance p2, Ljava/lang/StringBuilder;

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v1, "or>tcuu A ereoHnrl>p darn>"

    const-string/jumbo v1, "rruee tpdroAc>n> cHra oln>"

    const-string v1, ">erneAtp >od o-r>Hnrlcu rc"

    const-string v1, ">> AccountHandler error-> "

    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {p1}, Lcom/tencent/android/tpush/logging/TLogger;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object p1

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    return-void
.end method

.method static synthetic c(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x4

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/a;->g(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x5

    return-void
.end method

.method private d(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 16

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    if-eqz p1, :cond_1

    if-nez v0, :cond_0

    goto/16 :goto_0

    :cond_0
    const-string/jumbo v1, "qaIqc"

    const-string v1, "caIqc"

    const-string v1, "accId"

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v1

    const-string v3, "ecscys"

    const-string/jumbo v3, "ycseac"

    const-string v3, "Kyamce"

    const-string v3, "accKey"

    invoke-virtual {v0, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "maNmepka"

    const-string/jumbo v4, "mceNopaa"

    const-string/jumbo v4, "packName"

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string v4, "gtrsFbltboiaea"

    const-string v4, "Ftglosatbieatr"

    const-string v4, "attributesFlag"

    const/4 v5, -0x1

    invoke-virtual {v0, v4, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v13

    const-string v4, "aaeibrutesutbt"

    const-string/jumbo v4, "stiaubrtmaetbe"

    const-string/jumbo v4, "sitrNampbtueet"

    const-string v4, "attributesName"

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string/jumbo v4, "ueatraruqiaseOtetbNpe"

    const-string v4, "NtpsatuOraabueieteert"

    const-string v4, "attributesOperateName"

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    :try_start_0
    invoke-static {}, Lcom/tencent/android/tpush/service/c;->a()Lcom/tencent/android/tpush/service/c;

    move-result-object v0

    new-instance v15, Lcom/tencent/android/tpush/service/a$7;

    move-object v4, v15

    move-object v4, v15

    move-object v4, v15

    move-object v4, v15

    move-object/from16 v5, p0

    move-object/from16 v5, p0

    move-object/from16 v5, p0

    move-object/from16 v5, p0

    move-wide v6, v1

    move v8, v13

    move v8, v13

    move v8, v13

    move v8, v13

    move-object v9, v14

    move-object v9, v14

    move-object v9, v14

    move-object v9, v14

    move-object v10, v12

    move-object v10, v12

    move-object v10, v12

    move-object v10, v12

    invoke-direct/range {v4 .. v11}, Lcom/tencent/android/tpush/service/a$7;-><init>(Lcom/tencent/android/tpush/service/a;JILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-wide v5, v1

    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    move-object v8, v12

    move-object v8, v12

    move-object v8, v12

    move v9, v13

    move v9, v13

    move v9, v13

    move v9, v13

    move-object v10, v14

    move-object v10, v14

    move-object v10, v14

    move-object v10, v14

    move-object v11, v15

    move-object v11, v15

    move-object v11, v15

    move-object v11, v15

    invoke-virtual/range {v4 .. v11}, Lcom/tencent/android/tpush/service/c;->b(JLjava/lang/String;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/service/c/a;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, " >stoatsianrr p rHe tuebder>"

    const-string v2, "eHrnu>ep rdest> i atratbrr o"

    const-string/jumbo v2, "r rma iuser>rtl tbeedHt> nra"

    const-string v2, ">> attributes Handler error "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const-string/jumbo v1, "srhnoBeuSiedceqcdrorasvaHPl"

    const-string/jumbo v1, "oPtHBeasqcnirrsledvdaSuherc"

    const-string/jumbo v1, "seranborchelidtecsuBPHadarv"

    const-string v1, "PushServiceBroadcastHandler"

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    return-void
.end method

.method static synthetic d(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/a;->k(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method

.method private e(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 18

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    if-eqz p1, :cond_0

    if-eqz v0, :cond_0

    const-string v1, "cuIds"

    const-string v1, "Idscc"

    const-string v1, "adpcI"

    const-string v1, "accId"

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v1

    const-string/jumbo v3, "yeqmKc"

    const-string v3, "aeymKc"

    const-string v3, "cyseaK"

    const-string v3, "accKey"

    invoke-virtual {v0, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string/jumbo v4, "oaammepc"

    const-string v4, "cmkaopea"

    const-string v4, "eapcoNmk"

    const-string/jumbo v4, "packName"

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v13

    const-string v4, "fsebfb"

    const-string/jumbo v4, "sftefb"

    const-string/jumbo v4, "offset"

    const/4 v5, -0x1

    invoke-virtual {v0, v4, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v14

    const-string/jumbo v4, "uumti"

    const-string/jumbo v4, "tulmi"

    const-string/jumbo v4, "tlpim"

    const-string/jumbo v4, "limit"

    invoke-virtual {v0, v4, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v15

    const-string v4, "eqtypTa"

    const-string/jumbo v4, "pTptaye"

    const-string/jumbo v4, "pesTgay"

    const-string/jumbo v4, "tagType"

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v16

    const-string v4, "NyqgmaTequser"

    const-string/jumbo v4, "qeamNaseTryum"

    const-string/jumbo v4, "queryTagsName"

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    :try_start_0
    invoke-static {}, Lcom/tencent/android/tpush/service/c;->a()Lcom/tencent/android/tpush/service/c;

    move-result-object v0

    new-instance v17, Lcom/tencent/android/tpush/service/a$8;

    move-object/from16 v4, v17

    move-object/from16 v4, v17

    move-object/from16 v4, v17

    move-object/from16 v4, v17

    move-object/from16 v5, p0

    move-object/from16 v5, p0

    move-object/from16 v5, p0

    move-object/from16 v5, p0

    move-wide v6, v1

    move v8, v14

    move v8, v14

    move v8, v14

    move v8, v14

    move v9, v15

    move v9, v15

    move v9, v15

    move v9, v15

    move-object v10, v13

    move-object v10, v13

    move-object v10, v13

    move-object v10, v13

    move-object/from16 v12, v16

    move-object/from16 v12, v16

    move-object/from16 v12, v16

    move-object/from16 v12, v16

    invoke-direct/range {v4 .. v12}, Lcom/tencent/android/tpush/service/a$8;-><init>(Lcom/tencent/android/tpush/service/a;JIILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-wide v5, v1

    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    move-object v8, v13

    move-object v8, v13

    move-object v8, v13

    move-object v8, v13

    move v9, v14

    move v9, v14

    move v9, v14

    move v9, v14

    move v10, v15

    move v10, v15

    move v10, v15

    move v10, v15

    move-object/from16 v11, v16

    move-object/from16 v11, v16

    move-object/from16 v11, v16

    move-object/from16 v11, v16

    move-object/from16 v12, v17

    move-object/from16 v12, v17

    move-object/from16 v12, v17

    move-object/from16 v12, v17

    invoke-virtual/range {v4 .. v12}, Lcom/tencent/android/tpush/service/c;->a(JLjava/lang/String;Ljava/lang/String;IILjava/lang/String;Lcom/tencent/android/tpush/service/c/a;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "Qr>yosdnseaTa> rHlrrgur  o"

    const-string/jumbo v2, "n>soery agrlrdTe s>rQaHr u"

    const-string/jumbo v2, "rs>a bTrrrgeQ ornely>Hd eu"

    const-string v2, ">> QueryTagsHandler error "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string/jumbo v2, "sdtSmeuiaanHcrheBerdlocavrs"

    const-string/jumbo v2, "tsPmelerHhaoBvnSiedaccardrs"

    const-string/jumbo v2, "tSBaeHopcrdeurrnsalPicdaevh"

    const-string v2, "PushServiceBroadcastHandler"

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v3, ">yrH dQrq rao>lurT-aor>e esn"

    const-string/jumbo v3, "lr>oo>d-e  eenuaayr rH>QrTsr"

    const-string v3, ">Hsen T>rr>egrau-royes Qdl r"

    const-string v3, ">> QueryTagsHandler error-> "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v0}, Lcom/tencent/android/tpush/logging/TLogger;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    return-void
.end method

.method static synthetic e(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x4

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/a;->j(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x1

    const/4 v0, 0x2

    return-void
.end method

.method private f(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 16

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    move-object/from16 v0, p2

    if-eqz p1, :cond_0

    if-eqz v0, :cond_0

    const-string v1, "cIbmc"

    const-string v1, "bdccI"

    const-string v1, "Icdco"

    const-string v1, "accId"

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    invoke-virtual {v0, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v1

    const-string v3, "ceycab"

    const-string/jumbo v3, "uyecca"

    const-string/jumbo v3, "ueaKcy"

    const-string v3, "accKey"

    invoke-virtual {v0, v3}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    invoke-static {v3}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const-string v4, "ekNampcp"

    const-string v4, "Nckempap"

    const-string/jumbo v4, "qkamacpe"

    const-string/jumbo v4, "packName"

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v12

    const-string/jumbo v4, "tlsgaga"

    const-string v4, "gqgtlaa"

    const-string v4, "agamltF"

    const-string/jumbo v4, "tagFlag"

    const/4 v5, -0x1

    invoke-virtual {v0, v4, v5}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v13

    const-string/jumbo v4, "smaeogN"

    const-string/jumbo v4, "tgsaeNm"

    const-string v4, "Nemgtba"

    const-string/jumbo v4, "tagName"

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    invoke-static {v4}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v14

    const-string/jumbo v4, "raNpOeueegtmag"

    const-string/jumbo v4, "tagOperageName"

    invoke-virtual {v0, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v11

    :try_start_0
    invoke-static {}, Lcom/tencent/android/tpush/service/c;->a()Lcom/tencent/android/tpush/service/c;

    move-result-object v0

    new-instance v15, Lcom/tencent/android/tpush/service/a$9;

    move-object v4, v15

    move-object v4, v15

    move-object v4, v15

    move-object v4, v15

    move-object/from16 v5, p0

    move-object/from16 v5, p0

    move-wide v6, v1

    move v8, v13

    move v8, v13

    move v8, v13

    move-object v9, v14

    move-object v9, v14

    move-object v9, v14

    move-object v9, v14

    move-object v10, v12

    move-object v10, v12

    move-object v10, v12

    invoke-direct/range {v4 .. v11}, Lcom/tencent/android/tpush/service/a$9;-><init>(Lcom/tencent/android/tpush/service/a;JILjava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-object v4, v0

    move-wide v5, v1

    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    move-object v7, v3

    move-object v8, v12

    move-object v8, v12

    move-object v8, v12

    move-object v8, v12

    move v9, v13

    move v9, v13

    move v9, v13

    move v9, v13

    move-object v10, v14

    move-object v10, v14

    move-object v10, v14

    move-object v11, v15

    move-object v11, v15

    move-object v11, v15

    move-object v11, v15

    invoke-virtual/range {v4 .. v11}, Lcom/tencent/android/tpush/service/c;->a(JLjava/lang/String;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/service/c/a;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    goto :goto_0

    :catchall_0
    move-exception v0

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string v2, "  eTemlprgHoarr> >ad"

    const-string v2, " grmao>err r al>deTH"

    const-string v2, "arro n rqTe>>deHlrg "

    const-string v2, ">> TagHandler error "

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const-string v2, "eosrceadiaasnvurcesotPlhrHd"

    const-string v2, "cerBodeacanreaoHutlriPvsshd"

    const-string/jumbo v2, "oeamcPlurenSceaHsihrBstadvd"

    const-string v2, "PushServiceBroadcastHandler"

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    new-instance v1, Ljava/lang/StringBuilder;

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const-string/jumbo v3, "oragoT>e-n> adH l err>"

    const-string v3, ">> TagHandler error-> "

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {v0}, Lcom/tencent/android/tpush/logging/TLogger;->getStackTraceString(Ljava/lang/Throwable;)Ljava/lang/String;

    move-result-object v0

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    return-void
.end method

.method static synthetic f(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/a;->c(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method private g(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 11

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x3

    if-eqz p1, :cond_0

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-eqz p2, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-string p1, "bacdb"

    const-string p1, "bdaIc"

    const/4 v10, 0x1

    const-string p1, "cuadc"

    const-string p1, "accId"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x4

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-string v0, "cpuyce"

    const-string/jumbo v0, "ucayec"

    const/4 v10, 0x1

    const-string v0, "Keqcay"

    const-string v0, "accKey"

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x6

    const-string/jumbo v0, "kesacNma"

    const-string/jumbo v0, "packName"

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x5

    const/4 v9, 0x2

    const-string/jumbo v0, "ntpme"

    const-string/jumbo v0, "tnpek"

    const/4 v10, 0x7

    const-string/jumbo v0, "tenoo"

    const-string/jumbo v0, "token"

    const/4 v10, 0x7

    const/4 v9, 0x3

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x3

    const/4 v9, 0x1

    invoke-static {p2}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x3

    const/4 v9, 0x1

    const/4 v10, 0x1

    invoke-static {v7}, Lcom/tencent/android/tpush/service/cache/CacheManager;->UnregisterInfoByPkgName(Ljava/lang/String;)V

    :try_start_0
    const/4 v10, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/service/c;->a()Lcom/tencent/android/tpush/service/c;

    move-result-object v1

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/service/util/a;->a()Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-static {p1}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v4

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x2

    new-instance v8, Lcom/tencent/android/tpush/service/a$10;

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-direct {v8, p0, p1, v7}, Lcom/tencent/android/tpush/service/a$10;-><init>(Lcom/tencent/android/tpush/service/a;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x1

    invoke-virtual/range {v1 .. v8}, Lcom/tencent/android/tpush/service/c;->a(Ljava/lang/String;Ljava/lang/String;JLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/service/c/a;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x4

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x2

    new-instance p2, Ljava/lang/StringBuilder;

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x1

    invoke-direct {p2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x7

    const-string/jumbo v0, "n ee u>rqt>rr>erorsig"

    const-string/jumbo v0, "rsrorbt>err e>iegu >n"

    const-string v0, ">>> unregister error "

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x3

    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x7

    const/4 v9, 0x5

    const/4 v10, 0x5

    const-string p2, "dcotrluacSasHevesrPdihBeunr"

    const-string/jumbo p2, "tPsSdaeciurhnHcarvrsoaedleB"

    const/4 v10, 0x4

    const-string p2, "PushServiceBroadcastHandler"

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    :goto_0
    const/4 v9, 0x5

    move v10, v9

    return-void
.end method

.method static synthetic g(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/a;->f(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x2

    return-void
.end method

.method private h(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 13

    const/4 v12, 0x1

    if-eqz p1, :cond_0

    const/4 v12, 0x7

    if-eqz p2, :cond_0

    const/4 v12, 0x7

    const-string p1, "cdpIm"

    const-string p1, "aIdmc"

    const-string p1, "accqI"

    const-string p1, "accId"

    const/4 v12, 0x3

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x7

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x1

    const-string/jumbo p1, "ycsKco"

    const-string p1, "caKyoc"

    const-string p1, "Kcymae"

    const-string p1, "accKey"

    const/4 v12, 0x4

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v6

    const/4 v12, 0x3

    const-string p1, "bokto"

    const-string p1, "beotk"

    const-string p1, "betkn"

    const-string/jumbo p1, "token"

    const/4 v12, 0x4

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x2

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x1

    const-string/jumbo p1, "tyusohupept_ru_"

    const-string/jumbo p1, "tytpsoueh_hrp_u"

    const-string/jumbo p1, "steouyhp_tpre_h"

    const-string/jumbo p1, "other_push_type"

    const/4 v12, 0x1

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v7

    const/4 v12, 0x2

    const-string/jumbo p1, "suth_ktpeon_rohe"

    const-string/jumbo p1, "other_push_token"

    const/4 v12, 0x1

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v8

    const/4 v12, 0x3

    const-string p1, "hqon__grqriptoese"

    const-string/jumbo p1, "ohnsp_hrq_eetgior"

    const-string/jumbo p1, "ioshs__eprgnoturh"

    const-string/jumbo p1, "other_push_region"

    const/4 v12, 0x4

    invoke-virtual {p2, p1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v9

    const/4 v12, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x5

    const-string/jumbo p2, "k emchetnhstgtu wd es  cnOa=rsIodP iihni"

    const-string p2, "Pus ncodrtsn haci  =ihesd egtwbeOnkt Iih"

    const-string/jumbo p2, "itcton dekot=a uPs hd  cwsibnghIehsrn iO"

    const-string p2, "binding OtherPush token with accessId = "

    const/4 v12, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    invoke-virtual {p1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const-string p2, " o mk =t e"

    const-string/jumbo p2, "n = ebo kt"

    const-string p2, "  token = "

    const/4 v12, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const-string p2, "h oPr uuety=shp e"

    const-string/jumbo p2, "yuh oro Pts ehpe="

    const-string p2, " otherPushType = "

    const/4 v12, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {p1, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    const-string p2, "hPeeouspno=k bT h "

    const-string p2, "heoPhbk=n T s etou"

    const-string p2, "Po rhesuq= otekThn"

    const-string p2, " otherPushToken = "

    const/4 v12, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x7

    invoke-virtual {p1, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x1

    const-string p2, "ess huhrupron teo:i "

    const-string p2, "hteu rursenoi  p:ogh"

    const-string p2, " rhm r tog: euphisne"

    const-string p2, " other push region: "

    const/4 v12, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x5

    invoke-virtual {p1, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x7

    const-string p2, "aBnooeasvrtSPcsHelaucrhedir"

    const-string p2, "PushServiceBroadcastHandler"

    const/4 v12, 0x3

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/service/c;->a()Lcom/tencent/android/tpush/service/c;

    move-result-object p1

    const/4 v12, 0x4

    invoke-static {v2}, Ljava/lang/Long;->parseLong(Ljava/lang/String;)J

    move-result-wide v10

    const/4 v12, 0x1

    new-instance p2, Lcom/tencent/android/tpush/service/a$2;

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v0, p2

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v1, p0

    move-object v4, v7

    move-object v4, v7

    move-object v4, v7

    move-object v4, v7

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    move-object v5, v8

    const/4 v12, 0x7

    invoke-direct/range {v0 .. v5}, Lcom/tencent/android/tpush/service/a$2;-><init>(Lcom/tencent/android/tpush/service/a;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-object v3, p1

    move-wide v4, v10

    move-object v10, p2

    move-object v10, p2

    move-object v10, p2

    const/4 v12, 0x2

    invoke-virtual/range {v3 .. v10}, Lcom/tencent/android/tpush/service/c;->a(JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/service/c/a;)V

    :cond_0
    const/4 v12, 0x3

    return-void
.end method

.method static synthetic h(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/a;->e(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method

.method private i(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 10

    const/4 v8, 0x5

    move v9, v8

    if-eqz p1, :cond_0

    const/4 v9, 0x3

    if-eqz p2, :cond_0

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    const-string v0, "cedIssap"

    const/4 v9, 0x5

    const-string/jumbo v0, "saIcdbec"

    const-string v0, "accessId"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string v0, "akpeNgu"

    const-string v0, "aqkpNge"

    const/4 v9, 0x3

    const-string/jumbo v0, "pmgkNpe"

    const-string/jumbo v0, "pkgName"

    const/4 v9, 0x3

    const/4 v8, 0x4

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/service/c;->a()Lcom/tencent/android/tpush/service/c;

    move-result-object v0

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    new-instance v7, Lcom/tencent/android/tpush/service/a$3;

    move-object v1, v7

    move-object v1, v7

    move-object v2, p0

    move-object v2, p0

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v4, p1

    move-object v6, p2

    move-object v6, p2

    move-object v6, p2

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-direct/range {v1 .. v6}, Lcom/tencent/android/tpush/service/a$3;-><init>(Lcom/tencent/android/tpush/service/a;Ljava/lang/String;Landroid/content/Context;Ljava/lang/String;Landroid/content/Intent;)V

    const/4 v9, 0x1

    invoke-virtual {v0, p2, v7}, Lcom/tencent/android/tpush/service/c;->a(Landroid/content/Intent;Lcom/tencent/android/tpush/service/c/a;)V

    :cond_0
    const/4 v9, 0x4

    const/4 v8, 0x0

    return-void
.end method

.method static synthetic i(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/a;->h(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x7

    return-void
.end method

.method private j(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x3

    if-eqz p2, :cond_0

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz p1, :cond_0

    const/4 v3, 0x7

    const-string/jumbo v0, "qnitesrv"

    const-string/jumbo v0, "irstaven"

    const/4 v3, 0x2

    const-string/jumbo v0, "vislrean"

    const-string/jumbo v0, "interval"

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    const/4 v1, -0x1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/16 v0, 0xa

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x5

    if-lt p2, v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x0

    const v0, 0x8ca0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x5

    if-ge p2, v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-static {p1, p2}, Lcom/tencent/tpns/mqttchannel/api/MqttConfig;->setKeepAliveInterval(Landroid/content/Context;I)V

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x7

    return-void
.end method

.method static synthetic j(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/a;->i(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method

.method private k(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4

    const/4 v3, 0x1

    if-eqz p2, :cond_0

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x4

    const-string/jumbo v0, "oubmMgdmd"

    const-string v0, "Mgdmdoube"

    const/4 v3, 0x3

    const-string v0, "Mobeoeddu"

    const-string v0, "debugMode"

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x3

    sput-boolean p2, Lcom/tencent/android/tpush/XGPushConfig;->enableDebug:Z

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/logging/TLogger;->enableDebug(Landroid/content/Context;Z)V

    :cond_0
    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-void
.end method

.method static synthetic k(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/service/a;->d(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x3

    return-void
.end method


# virtual methods
.method public declared-synchronized a(Landroid/content/Context;)V
    .locals 7

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    monitor-enter p0

    :try_start_0
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string/jumbo v0, "surncbiaSHtBreecaeoPvlsddah"

    const-string v0, "essaolrtnaeSvBHodhiruccPead"

    const-string/jumbo v0, "ratPvnuaohurcesBadeScHsdile"

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v6, 0x3

    const/4 v5, 0x1

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string v2, "iIeetsiptIdeentSe:n, neildevrtnhIesrfbcnbodzae"

    const-string/jumbo v2, "teIvhbnIred:esbInceteeoerdi ttnSild,neeasnifz "

    const/4 v6, 0x1

    const-string v2, "SvidnnieqstnoIecnatnfbreIlhee,sezI d :teirdete"

    const-string v2, "handleServiceInited, beforeInitedIntents size:"

    const/4 v5, 0x6

    and-int/2addr v6, v5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    move v6, v5

    iget-object v2, p0, Lcom/tencent/android/tpush/service/a;->f:Ljava/util/ArrayList;

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    const/4 v0, 0x1

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x3

    iput-boolean v0, p0, Lcom/tencent/android/tpush/service/a;->e:Z
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_1

    :try_start_1
    const/4 v6, 0x2

    new-instance v0, Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x0

    const-string/jumbo v1, "trsScaRuiaiRV.toxeTAoot...pVndSncgvEcCn.n.i_Em.4eI"

    const-string/jumbo v1, "n.AtaSuc.opRnioo.RecTnEcEgdSmivt.rIx_V.n4t.eTaCV.i"

    const/4 v6, 0x0

    const-string v1, "com.tencent.android.xg.vip.action.SERVICE_START.V4"

    const/4 v6, 0x4

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string/jumbo v1, "kgp"

    const-string/jumbo v1, "kgp"

    const/4 v6, 0x0

    const-string/jumbo v1, "kpg"

    const-string/jumbo v1, "pkg"

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v2

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v2}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v5, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v1, "rve"

    const-string/jumbo v1, "ver"

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string v2, "4..m931"

    const-string/jumbo v2, "p4..319"

    const/4 v6, 0x5

    const-string v2, "1.4.3.9"

    const/4 v6, 0x0

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x5

    goto :goto_0

    :catchall_0
    move-exception v0

    :try_start_2
    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x5

    const-string/jumbo v1, "trcasaSHqnoavddBPsrhelcieur"

    const/4 v6, 0x0

    const-string v1, "dhvPolusHcotreienrsraeacBaS"

    const-string v1, "PushServiceBroadcastHandler"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x5

    const-string v2, "dersBbaasdosc"

    const-string/jumbo v2, "tssocaadBdrse"

    const/4 v6, 0x0

    const-string v2, "addcnsurosaeB"

    const-string/jumbo v2, "sendBroadcast"

    const/4 v6, 0x4

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a;->f:Ljava/util/ArrayList;

    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :goto_1
    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    if-eqz v1, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x3

    check-cast v1, Landroid/content/Intent;

    const/4 v5, 0x3

    move v6, v5

    const-string/jumbo v2, "oelmhsHpcuevdenrrSarBiaasct"

    const-string v2, "aSamesouihevrrtnscdBHrePcal"

    const/4 v6, 0x5

    const-string/jumbo v2, "odeshHlPqeiranBcavSdtruceas"

    const-string v2, "PushServiceBroadcastHandler"

    const/4 v6, 0x7

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    const-string/jumbo v4, "ooszretee ie enId:tuftcb,sitsnxIe"

    const-string v4, " z :oeixtenttIuIniberontsfesceed,"

    const/4 v6, 0x5

    const-string/jumbo v4, "retmbnsenzeItIefunsio t ,xedietc:"

    const-string v4, "excute, beforeInitedIntents size:"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    iget-object v4, p0, Lcom/tencent/android/tpush/service/a;->f:Ljava/util/ArrayList;

    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    move-result v4

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x3

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x4

    new-instance v3, Lcom/tencent/android/tpush/service/a$b;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-direct {v3, p0, p1, v1}, Lcom/tencent/android/tpush/service/a$b;-><init>(Lcom/tencent/android/tpush/service/a;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x5

    invoke-virtual {v2, v3}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    goto :goto_1

    :cond_0
    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    iget-object p1, p0, Lcom/tencent/android/tpush/service/a;->f:Ljava/util/ArrayList;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x7

    monitor-exit p0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-void

    :catchall_1
    move-exception p1

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x7

    monitor-exit p0

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x0

    throw p1
.end method

.method public declared-synchronized b(Landroid/content/Context;)V
    .locals 8

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string/jumbo v0, "riecodnsuorbhSvtHarealBPadc"

    const-string/jumbo v0, "leoarbviedahPradBnecrutsHcS"

    const/4 v7, 0x7

    const-string/jumbo v0, "sorcubarlBePvtaSeadehirHsnd"

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v1, "eeva ouiuri -tegrcrRistcn"

    const-string v1, " easvguittieeeRnrrcirc -o"

    const/4 v7, 0x4

    const-string v1, "eicos iprrretieR-vn eatge"

    const-string v1, "action - registerReceiver"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    if-eqz p1, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x3

    const/4 v0, 0x4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/4 v1, 0x0

    :try_start_1
    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    sget-object v2, Lcom/tencent/android/tpush/service/a;->c:Lcom/tencent/android/tpush/service/a$c;

    const/4 v7, 0x1

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-nez v2, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x6

    new-instance v2, Lcom/tencent/android/tpush/service/a$c;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-direct {v2, p0, v1}, Lcom/tencent/android/tpush/service/a$c;-><init>(Lcom/tencent/android/tpush/service/a;Lcom/tencent/android/tpush/service/a$1;)V

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x1

    sput-object v2, Lcom/tencent/android/tpush/service/a;->c:Lcom/tencent/android/tpush/service/a$c;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    new-instance v2, Landroid/content/IntentFilter;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-direct {v2}, Landroid/content/IntentFilter;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string v4, "TgdotCtxqd.EVtvi_4Hcp.mCoCATOToiN.caEn..Sena.icpN.eC_Enr"

    const-string/jumbo v4, "v4cCi.EpeAn_rNCEacgSiNaot.nnmO.iCxoonc_pEdTttC.H.d.TTV.e"

    const/4 v7, 0x4

    const-string v4, "CEsSd..E4xc.iKCoide__TiCtAg.NnT.CnE..atoTncmrVtHvOopcNen"

    const-string v4, "com.tencent.android.xg.vip.action.CHECK_CONNECT_STATE.V4"

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x7

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string/jumbo v5, "nmemoRgvx.VtE.nE..cerGocdi.i4cptnTnRdot..IaSa"

    const-string v5, "com.tencent.android.xg.vip.action.REGISTER.V4"

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x7

    const-string/jumbo v5, "xn.ooev4..nNTEiqiVatmc..npaGoUcinogcEdSR.dtet.r"

    const-string v5, "Gpd.edtmqctN.vnn4gEoRUc.i.r.exoVcnESiT..tonRaai"

    const/4 v7, 0x7

    const-string/jumbo v5, "inreNbnoiam.Tg4c.SetvnR.EGttccR..iadpUoxI.V.odE"

    const-string v5, "com.tencent.android.xg.vip.action.UNREGISTER.V4"

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string v5, ".EU.oauNgtBenocvixdntAeopcadr.._4.VBLmDGn.isnEcEi"

    const-string/jumbo v5, "xEsN.nmoe..LBEntcctB.ig_eEUnVdD.4Gvodropica.n.aAi"

    const-string v5, "EEt.ntepi.cixtoL.enA4odDi._B.mnacE.oNpUGrgdVn.Bav"

    const-string v5, "com.tencent.android.xg.vip.action.ENABLE_DEBUG.V4"

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const-string/jumbo v5, "ncTHaS.Eqv.n.picgNTxSTLim.i.dcAnV4_MdR.oteneortaEV.It"

    const-string v5, "com.tencent.android.xg.vip.action.SET_HTINTERVALMS.V4"

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x0

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x2

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x2

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x5

    const-string v5, "c.s.dCG.Ai.tce.ooctmngetmnidK.ivnMpaVSr4a_on"

    const-string v5, "ai.mMreK.Ct_cSnnoicngpGmdAoeo.ca4nivt.x.dV.t"

    const/4 v7, 0x6

    const-string v5, ".nCm.rAcaxnietSGMd_tV....icndmo.o4picenKvato"

    const-string v5, "com.tencent.android.xg.vip.action.MSG_ACK.V4"

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x2

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x7

    const-string/jumbo v5, "ir..otCpOUtV.4ecaoioT.iCnd.ecntnagnx.NodvAom"

    const-string v5, "Uco.onT.Co4OVd.xga.nin.ircmp.nNtoattedeA.viC"

    const/4 v7, 0x4

    const-string v5, "ceoxibdnitveNn.p.ac..otCd.AToUVOng4tr.Cn.mac"

    const-string v5, "com.tencent.android.xg.vip.action.ACCOUNT.V4"

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string/jumbo v5, "tncovdua.bnxronge..Vinm.c..iA4ati.GpdctT"

    const-string v5, "ccid.bg.cdotVn.mei4tvnxn.aaAiG.oTnp..tre"

    const/4 v7, 0x0

    const-string v5, ".donocGpnve..Vgitx4ioAniepanttamTc..d.c."

    const-string v5, "com.tencent.android.xg.vip.action.TAG.V4"

    const/4 v7, 0x1

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x4

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x2

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x5

    const-string/jumbo v5, "tioodcu.x.tdrinG.Ae.eS.EVav.ocTnQtc.pgm4RanYUi"

    const/4 v7, 0x5

    const-string v5, "c.n.o.vRqQ4t.T.a.megUpdGAtcoV.reidExSaonYitcnn"

    const-string v5, "com.tencent.android.xg.vip.action.QUERYTAGS.V4"

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x2

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x1

    const-string/jumbo v4, "m_snSKEoR.og4cP..aoxdtaLird.LenIiicn.CvCUTceHp.VtpUt.n"

    const-string v4, "T..idH.pV.4aIKtL_nUtContoiLPcc.S.Ucx.aeEvionmCnRSdregp"

    const/4 v7, 0x2

    const-string v4, "ainmItU.edcov..n_..4r.ponocCRHUCScLtSg.xdePVtLinimKaET"

    const-string v4, "com.tencent.android.xg.vip.action.PUSH_CLICK.RESULT.V4"

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x3

    const-string v4, "EEi4oL.PcDtct.R.CUSS_.L.adUrvioeaxHo.L.goiAntNdCqemnnp.nVc"

    const-string v4, ".iotHSicqdeSg.E..UcLtpnatcERLLAeox_.UCin.rdCvmNo.En.VaPn4D"

    const-string v4, ".erLSbomLvLcT.co_U.CntVpi4.A.itiRDSdoCNcPnedgnH.UEEEx.at.n"

    const-string v4, "com.tencent.android.xg.vip.action.PUSH_CANCELLED.RESULT.V4"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x1

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    const-string/jumbo v5, "oenocsur.dgvinxrd..sin..ptk.ndi2.oscct4Vvacaamke"

    const-string/jumbo v5, "x.siprntaen.tc.vdeiamk.na.cVitorcs4sd.kcno2d.gov"

    const/4 v7, 0x0

    const-string/jumbo v5, "n.eig.cpetn.nd.avit.kkvo...msoadrV2icda4xnspctrc"

    const-string v5, "com.tencent.android.xg.vip.action.ack.sdk2srv.V4"

    const/4 v7, 0x1

    const/4 v6, 0x2

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    or-int/2addr v7, v6

    const-string/jumbo v5, "mdomonagdnni.rcentveic..txtctV.oasre.ip4rcaed.e.."

    const/4 v7, 0x5

    const-string v5, ".c.eavirqosed..o.Vxoe.tvma4.cgntecdrntdncp.aienri"

    const-string v5, "com.tencent.android.xg.vip.action.reserved.act.V4"

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x4

    const/4 v6, 0x0

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    const-string v5, "UtsTEOPHOn_.Nmr.dcK..aii.SoeEcodixnDP4vcVEptR_UAe.ntg.T_aTon"

    const-string v5, "com.tencent.android.xg.vip.action.UPDATE_OTHER_PUSH_TOKEN.V4"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x3

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x1

    const/4 v6, 0x7

    const/4 v7, 0x3

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    move v7, v6

    const-string v5, "atimVRvg_nix..cCMddoMnopEO.oT.oRO.mcPt4.aetrenic"

    const-string v5, "gdMcoOot4VenaOinC.R.t.Rd..tcaErvomPcM.pi._oniexT"

    const/4 v7, 0x4

    const-string/jumbo v5, "ndi.onimaOo.cRcdtie.Mt.oacxpMt_OPCTogn4.env.VErR"

    const-string v5, "com.tencent.android.xg.vip.action.COMM_REPORT.V4"

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x6

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x0

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string v5, "eHV.cbrv..ngd.cmLtc4diSinbnoion.x.oaepaUtF"

    const-string v5, "d.g.Fb.daVSoHnnaoL.ccoert.timiip.4nvx.cUen"

    const/4 v7, 0x3

    const-string v5, "LnHaneuoioVvFti4npcUctdeSm.o.xgc...rta.i.d"

    const-string v5, "com.tencent.android.xg.vip.action.FLUSH.V4"

    const/4 v6, 0x7

    and-int/2addr v7, v6

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x5

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x1

    const-string/jumbo v5, "nnmtrUnpIvc.dcgiT.nTTBR.eouAa4icp.ot.Veoia..dx"

    const-string/jumbo v5, "tVa.nmuBpIo.t.onvedeiicncxAcUdrgnitTRToa..4T.."

    const/4 v7, 0x6

    const-string/jumbo v5, "tnRpnT.oqd..ci.c.oEgndnitVTrmvtT.BAIieoeaxU4ac"

    const-string v5, "com.tencent.android.xg.vip.action.ATTRIBUTE.V4"

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {v2, v4}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v6, 0x7

    move v7, v6

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x1

    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x4

    const/4 v7, 0x1

    const-string v3, "LtsmerRI.E4VOnLSSVop.tgnE.naCco.ce.iRxdvan.ic.PiSCotIdp"

    const-string v3, ".ntgL.ipxIEV.ceaInvioc.o.dE4ma.iSReRVr.CpntSnEoctPdOLSC"

    const-string v3, ".CEmKenn..SVpatcioxELiiE.mdR.ecIgCcSdLS.vP4tona.tOrnRIV"

    const-string v3, "com.tencent.android.xg.vip.action.KILLSERVICEPROCESS.V4"

    const/4 v6, 0x3

    shl-int/2addr v7, v6

    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x4

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v7, 0x1

    const/4 v6, 0x6

    invoke-virtual {v2, v3}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x0

    const/4 v6, 0x1

    sget-object v3, Lcom/tencent/android/tpush/service/a;->c:Lcom/tencent/android/tpush/service/a$c;

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x3

    invoke-static {p1, v3, v2, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->registerReceiver(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    goto :goto_0

    :catchall_0
    move-exception v2

    :try_start_2
    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x7

    const-string v3, "asieoPuaHcnqSteshorcrrevadd"

    const-string/jumbo v3, "oeSdstrhqPcearsinuacvHaedBr"

    const/4 v7, 0x6

    const-string v3, "HBrtebcdruPversdlaScoasniha"

    const-string v3, "PushServiceBroadcastHandler"

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string/jumbo v4, "isticeuRevrresge"

    const-string v4, "grsieRseerveetci"

    const/4 v7, 0x7

    const-string/jumbo v4, "stgceRipeereerri"

    const-string/jumbo v4, "registerReceiver"

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-static {v3, v4, v2}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_2

    :cond_0
    :goto_0
    :try_start_3
    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x7

    sget-object v2, Lcom/tencent/android/tpush/service/a;->d:Lcom/tencent/android/tpush/service/a$d;

    const/4 v6, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-nez v2, :cond_2

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x4

    new-instance v2, Lcom/tencent/android/tpush/service/a$d;

    const/4 v7, 0x4

    invoke-direct {v2, p0, v1}, Lcom/tencent/android/tpush/service/a$d;-><init>(Lcom/tencent/android/tpush/service/a;Lcom/tencent/android/tpush/service/a$1;)V

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x0

    sput-object v2, Lcom/tencent/android/tpush/service/a;->d:Lcom/tencent/android/tpush/service/a$d;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    new-instance v1, Landroid/content/IntentFilter;

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x7

    invoke-direct {v1}, Landroid/content/IntentFilter;-><init>()V

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x7

    const-string/jumbo v2, "ndiReUatqTt.oNtmEnSrnRaiSPo.idE.c_"

    const-string v2, "iSRmrninSdadEE.nittTRaPUot.e.nNco_"

    const/4 v7, 0x4

    const-string/jumbo v2, "r.sRinREn.UPaNeTnnEtddSStEio_a.tco"

    const-string v2, "android.intent.action.USER_PRESENT"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x2

    const-string/jumbo v2, "tENmnntO.tnRoiiadrdc.aoEeiNnSCo"

    const-string v2, ".etaoESOdtioN.n.iandRctinoCrNEn"

    const/4 v7, 0x2

    const-string v2, "i.OSoENadRo.ndiettninc.ECoa_ntN"

    const-string v2, "android.intent.action.SCREEN_ON"

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const-string v2, "EtTnEbd.riEaAnRCItoPCDt.nOdi__ONaOcNTNieonWb"

    const-string v2, "dTic.bECnNEREDNro_tPiWOniao_tNAdtOnT.anOeIC."

    const/4 v7, 0x2

    const-string v2, "attoC.undOTCcTENniEoIdWOiC_.NNRerEDOP.i_tAan"

    const-string v2, "android.intent.action.ACTION_POWER_CONNECTED"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    const-string v2, "T.CODEIpEoEoOAtdRnnO.tSaadiuicPrN.nn_eNCtICTWiN"

    const-string v2, "NIESnIudTN.iOnaniaCOntEOCtiPr.RCoENWtA.Dodc_e_T"

    const/4 v7, 0x0

    const-string v2, "android.intent.action.ACTION_POWER_DISCONNECTED"

    const/4 v7, 0x1

    const/4 v6, 0x0

    const/4 v7, 0x5

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v7, 0x7

    const-string/jumbo v2, "nrnCcCTOqGCnEdI.NYAodaiNTe_nNIH.pEV."

    const-string/jumbo v2, "o.NHNVCpnONdnaT.icAIE.YTrenEnIdCCG_o"

    const/4 v7, 0x0

    const-string v2, "dCsHTcINAVeO_CEIn.TnNdCE.oarYnoiGt.N"

    const-string v2, "android.net.conn.CONNECTIVITY_CHANGE"

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v1, v2}, Landroid/content/IntentFilter;->addAction(Ljava/lang/String;)V

    const/4 v6, 0x2

    move v7, v6

    sget v2, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/16 v3, 0x21

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-lt v2, v3, :cond_1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x5

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v6, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x0

    sget-object v2, Lcom/tencent/android/tpush/service/a;->d:Lcom/tencent/android/tpush/service/a$d;

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x5

    invoke-static {p1, v2, v1, v0}, Ld3/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;I)Landroid/content/Intent;

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x6

    goto :goto_1

    :cond_1
    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x5

    sget-object v0, Lcom/tencent/android/tpush/service/a;->d:Lcom/tencent/android/tpush/service/a$d;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p1, v0, v1}, Landroid/content/Context;->registerReceiver(Landroid/content/BroadcastReceiver;Landroid/content/IntentFilter;)Landroid/content/Intent;
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_1

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    goto :goto_1

    :catchall_1
    move-exception p1

    :try_start_4
    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string/jumbo v0, "udtedaBrqorenaerhcclHvisSsa"

    const/4 v7, 0x0

    const-string/jumbo v0, "tramiasscdnevBhuaoreSecHdPr"

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x3

    const-string/jumbo v1, "ier o:Rtrereetievieerr ecsesnoPecrerersrguR"

    const-string/jumbo v1, "visrrrsror eereteirce:egtisPucereReere seRn"

    const/4 v7, 0x2

    const-string/jumbo v1, "tscr bue:neeeveRrerioirestvPesrrreeceregiR "

    const-string/jumbo v1, "registerReceiver userPresentReceiver error:"

    const/4 v7, 0x2

    const/4 v6, 0x5

    const/4 v7, 0x0

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_2

    :cond_2
    :goto_1
    const/4 v7, 0x3

    const/4 v6, 0x4

    const/4 v7, 0x0

    monitor-exit p0

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x5

    return-void

    :catchall_2
    move-exception p1

    const/4 v7, 0x5

    const/4 v6, 0x3

    monitor-exit p0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    throw p1
.end method

.method public declared-synchronized c(Landroid/content/Context;)V
    .locals 4

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x0

    monitor-enter p0

    :try_start_0
    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a;->f:Ljava/util/ArrayList;

    const/4 v3, 0x5

    const/4 v2, 0x6

    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-eqz p1, :cond_2

    const/4 v3, 0x5

    sget-object v0, Lcom/tencent/android/tpush/service/a;->b:Lcom/tencent/android/tpush/service/a$a;

    const/4 v3, 0x7

    const/4 v1, 0x0

    const/4 v3, 0x3

    shl-int/2addr v2, v1

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x7

    sget-object v0, Lcom/tencent/android/tpush/service/a;->b:Lcom/tencent/android/tpush/service/a$a;

    const/4 v3, 0x7

    const/4 v2, 0x0

    const/4 v3, 0x7

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;)Z

    const/4 v3, 0x7

    const/4 v2, 0x3

    sput-object v1, Lcom/tencent/android/tpush/service/a;->b:Lcom/tencent/android/tpush/service/a$a;

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x6

    sget-object v0, Lcom/tencent/android/tpush/service/a;->c:Lcom/tencent/android/tpush/service/a$c;

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x6

    sget-object v0, Lcom/tencent/android/tpush/service/a;->c:Lcom/tencent/android/tpush/service/a$c;

    const/4 v3, 0x3

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;)Z

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    sput-object v1, Lcom/tencent/android/tpush/service/a;->c:Lcom/tencent/android/tpush/service/a$c;

    :cond_1
    sget-object v0, Lcom/tencent/android/tpush/service/a;->d:Lcom/tencent/android/tpush/service/a$d;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/service/a;->d:Lcom/tencent/android/tpush/service/a$d;

    const/4 v3, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;)Z

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    sput-object v1, Lcom/tencent/android/tpush/service/a;->d:Lcom/tencent/android/tpush/service/a$d;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :cond_2
    const/4 v2, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    monitor-exit p0

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-void

    :catchall_0
    move-exception p1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    monitor-exit p0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x4

    throw p1
.end method
