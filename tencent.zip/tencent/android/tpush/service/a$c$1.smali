.class Lcom/tencent/android/tpush/service/a$c$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/service/a$c;->onReceive(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/android/tpush/service/a$c;


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/service/a$c;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a$c$1;->b:Lcom/tencent/android/tpush/service/a$c;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/service/a$c$1;->a:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v0, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 5

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~~s~ .@b~@ c~ i~~/~ionf~~u @l/~~oi~14@r~ @@  @at @tov@s @o-loy~~@@o @ @ @~ @@ S~@~~b@b f~@dM  ~m"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$c$1;->a:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x6

    invoke-static {v0}, Lcom/tencent/tpns/baseapi/XGApiConfig;->isEnableService(Landroid/content/Context;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    if-eqz v0, :cond_0

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v0, "BSamoaseerHacrusscdetvnhrPl"

    const-string/jumbo v0, "nBssPrasheeaStcoedvurliHcar"

    const/4 v4, 0x5

    const-string/jumbo v0, "saSroeatiddsraorHhnvcBPeeuc"

    const-string v0, "PushServiceBroadcastHandler"

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string/jumbo v1, "re a,b srrve ictdgbas s rusttmityteiiaencyeetvdn inr it loaeerg "

    const-string v1, " romtatve scgst etyiaen ersieigbein rvter,aan sitcleir  urdt day"

    const/4 v4, 0x0

    const-string v1, " sdttrurcg etveyit nbrnre,alisrae eo tgiends yaivrtsieatc   iera"

    const-string v1, "already registered but service not init, try start service again"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x0

    new-instance v0, Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x4

    invoke-direct {v0}, Landroid/content/Intent;-><init>()V

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$c$1;->a:Landroid/content/Context;

    const/4 v4, 0x0

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v4, 0x0

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const-class v2, Lcom/tencent/android/tpush/service/XGVipPushService;

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v1, v2}, Landroid/content/Intent;->setClass(Landroid/content/Context;Ljava/lang/Class;)Landroid/content/Intent;

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v1, "irindc.pa.iogetpntleetc.xed.kopvaonv..mncie"

    const-string v1, "d.rtoaceegkavnc.l..iin.ditxpoiepen.onecotvm"

    const/4 v4, 0x1

    const-string/jumbo v1, "io.xitgnqvdenaiteacepe.c.okprvetilcd..nmona"

    const-string v1, "com.tencent.android.xg.vip.action.keepalive"

    const/4 v3, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setAction(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a$c$1;->a:Landroid/content/Context;

    const/4 v4, 0x0

    const/4 v3, 0x7

    invoke-virtual {v1, v0}, Landroid/content/Context;->startService(Landroid/content/Intent;)Landroid/content/ComponentName;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    :catchall_0
    :cond_0
    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void
.end method
