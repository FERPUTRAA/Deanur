.class Lcom/tencent/android/tpush/service/a$1;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/service/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# virtual methods
.method public TRun()V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "tus@~st  a y~v@~~ @~@o~bo@S n ~ ~@imf~@4b-@ibdl ~@M@~l f~~@ r~@ ~@~cK~i @@1~.@~  o/ ~@o@~o~o@ / "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/service/a$1;->a:Landroid/content/Context;

    const/4 v1, 0x7

    move v2, v1

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->f(Landroid/content/Context;)V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-void
.end method
