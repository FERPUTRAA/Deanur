.class public Lcom/tencent/android/tpush/service/a/a;
.super Ljava/lang/Object;


# static fields
.field private static volatile L:Lcom/tencent/android/tpush/service/a/a;


# instance fields
.field public A:I

.field public B:I

.field public C:I

.field public D:I

.field public E:I

.field public F:I

.field public G:I

.field public H:I

.field public I:Ljava/lang/String;

.field public J:Lorg/json/JSONArray;

.field public K:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation
.end field

.field private M:Landroid/content/Context;

.field public a:J

.field public b:I

.field public c:I

.field public d:I

.field public e:I

.field public f:I

.field public g:I

.field public h:I

.field public i:I

.field public j:I

.field public k:I

.field public l:I

.field public m:I

.field public n:I

.field public o:I

.field public p:I

.field public q:I

.field public r:I

.field public s:I

.field public t:I

.field public u:Ljava/lang/String;

.field public v:I

.field public w:I

.field public x:Ljava/lang/String;

.field public y:I

.field public z:I


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x2

    return-void
.end method

.method private constructor <init>()V
    .locals 5

    const/4 v4, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v0, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/service/a/a;->M:Landroid/content/Context;

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/service/a/a;->x:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->y:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->z:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const v2, 0xea60

    const/4 v4, 0x4

    iput v2, p0, Lcom/tencent/android/tpush/service/a/a;->A:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->B:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->C:I

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->D:I

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 v1, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x0

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->E:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->F:I

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->G:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->H:I

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v1, "iasmos"

    const-string v1, "amsoii"

    const/4 v4, 0x0

    const-string/jumbo v1, "imamix"

    const-string/jumbo v1, "xiaomi"

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput-object v1, p0, Lcom/tencent/android/tpush/service/a/a;->I:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/service/a/a;->J:Lorg/json/JSONArray;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 5

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/4 v0, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/service/a/a;->M:Landroid/content/Context;

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/service/a/a;->x:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x6

    const/4 v1, 0x1

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->y:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->z:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    const v2, 0xea60

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x5

    iput v2, p0, Lcom/tencent/android/tpush/service/a/a;->A:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x0

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->B:I

    const/4 v4, 0x3

    const/4 v3, 0x0

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->C:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->D:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v1, -0x1

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->E:I

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x1

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->F:I

    const/4 v4, 0x0

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->G:I

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput v1, p0, Lcom/tencent/android/tpush/service/a/a;->H:I

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo v1, "oimmoa"

    const-string/jumbo v1, "oammxi"

    const/4 v4, 0x6

    const-string v1, "aoimib"

    const-string/jumbo v1, "xiaomi"

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    iput-object v1, p0, Lcom/tencent/android/tpush/service/a/a;->I:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/service/a/a;->J:Lorg/json/JSONArray;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {p1}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/service/a/a;->M:Landroid/content/Context;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/tencent/android/tpush/service/a/a;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    sget-object v0, Lcom/tencent/android/tpush/service/a/a;->L:Lcom/tencent/android/tpush/service/a/a;

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x3

    const-class v0, Lcom/tencent/android/tpush/service/a/a;

    const-class v0, Lcom/tencent/android/tpush/service/a/a;

    const-class v0, Lcom/tencent/android/tpush/service/a/a;

    const-class v0, Lcom/tencent/android/tpush/service/a/a;

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x0

    sget-object v1, Lcom/tencent/android/tpush/service/a/a;->L:Lcom/tencent/android/tpush/service/a/a;

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    new-instance v1, Lcom/tencent/android/tpush/service/a/a;

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/service/a/a;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x4

    sput-object v1, Lcom/tencent/android/tpush/service/a/a;->L:Lcom/tencent/android/tpush/service/a/a;

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    monitor-exit v0

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x0

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x4

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    sget-object p0, Lcom/tencent/android/tpush/service/a/a;->L:Lcom/tencent/android/tpush/service/a/a;

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x1

    return-object p0
.end method


# virtual methods
.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v1, "xout=ouecagrnitooann[ gCiManfr"

    const-string v1, "a utogocgfnxeC[nr=ennraMtiiooa"

    const/4 v4, 0x1

    const-string v1, "ConfigurationManager [context="

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a/a;->M:Landroid/content/Context;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    const-string/jumbo v1, "t=cniagpnr,iuonfibV rso"

    const-string v1, "fi,oibensnuto nri=rgacV"

    const/4 v4, 0x1

    const-string v1, "esta=co qgrroonufniiV,n"

    const-string v1, ", configurationVersion="

    const/4 v3, 0x2

    or-int/2addr v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget-wide v1, p0, Lcom/tencent/android/tpush/service/a/a;->a:J

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string/jumbo v1, "irseo ecmuievTeut"

    const-string v1, "eeevceuitTrou m,i"

    const/4 v4, 0x0

    const-string/jumbo v1, "iucmire tmeeTove,"

    const-string v1, ", receiveTimeout="

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x5

    move v4, v3

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->b:I

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string v1, "hIt,o=natpvetbe arle"

    const-string/jumbo v1, "vth,lnIperaa etaebt="

    const/4 v4, 0x3

    const-string v1, "ateI=bvartt ab,elehr"

    const-string v1, ", heartbeatInterval="

    const/4 v4, 0x2

    const/4 v3, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->c:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v1, "IHapehurra tvnbtetat,le="

    const-string v1, ", httpHeartbeatInterval="

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->d:I

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v1, "r,easpepIenT=ts tdeq"

    const-string v1, "ersete=aqTnd Ie,svtp"

    const/4 v4, 0x4

    const-string v1, "dtresptIqTvelsee,n ="

    const-string v1, ", speedTestInterval="

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->e:I

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v1, "= ssespaencEsxsneaglrh,e"

    const-string/jumbo v1, "sns,nex sE=ereMpsegchala"

    const/4 v4, 0x7

    const-string/jumbo v1, "saMmshnes pex=cieE,rlgae"

    const-string v1, ", channelMessageExpires="

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->f:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string v1, "e, uosmnqsery=eccc"

    const-string v1, "Seymerucscq nsce,="

    const/4 v4, 0x7

    const-string v1, "esccyburqfeensS= ,"

    const-string v1, ", freqencySuccess="

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->g:I

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    const-string/jumbo v1, "qd Foncyie=al,fee"

    const/4 v4, 0x0

    const-string v1, "endc,=uqyFrifl ea"

    const-string v1, ", freqencyFailed="

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->h:I

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const-string/jumbo v1, "tnlr, opbepat=evr"

    const-string/jumbo v1, "o lr=btepraenv,tr"

    const/4 v4, 0x0

    const-string/jumbo v1, "trrIeovaq=,rn elt"

    const-string v1, ", reportInterval="

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->i:I

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const-string v1, "a,snMo uoutrCetx="

    const-string/jumbo v1, "rMtoo,un=eCtpxua "

    const/4 v4, 0x3

    const-string v1, "=M,motnruCrtxe ap"

    const-string v1, ", reportMaxCount="

    const/4 v3, 0x4

    move v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->j:I

    const/4 v3, 0x3

    move v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v1, "thtyo,=ptponCtrR "

    const-string/jumbo v1, "yR tetCpnt=poh,rt"

    const/4 v4, 0x5

    const-string v1, "Crn,ebpyoRhttt=u "

    const-string v1, ", httpRetryCount="

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->k:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x0

    const-string v1, "aut =xuaMc,qoC"

    const-string/jumbo v1, "oCuaMtnaq=,cx "

    const-string/jumbo v1, "koC,an ptMuax="

    const-string v1, ", ackMaxCount="

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x5

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->l:I

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v1, "n rsa,o=qatcku"

    const-string/jumbo v1, "rtska=nua,D co"

    const-string v1, "aos,tDa=nkuci "

    const-string v1, ", ackDuration="

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->m:I

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v1, " ,vmInlrmae=load"

    const-string v1, " aImr=vl,lIeaond"

    const/4 v4, 0x5

    const-string/jumbo v1, "vllooea ,=pnIrId"

    const-string v1, ", loadIpInerval="

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->n:I

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string/jumbo v1, "toOucb CttdeeT=inrroecn,i"

    const-string v1, "deruont,nieom=C TrOcittce"

    const/4 v4, 0x2

    const-string v1, "cie=, urdcOnTtuieeeCotrnm"

    const-string v1, ", redirectConnectTimeOut="

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x7

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->o:I

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v1, " treuTSpr=Oedceoiimt"

    const-string v1, ", redirectSoTimeOut="

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->p:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string v1, "di ybprEqe,atsxrTemtig"

    const-string/jumbo v1, "sta= bpexTtrmiEeyir,gd"

    const/4 v4, 0x1

    const-string v1, "epseg=irEdT,sta ixyemt"

    const-string v1, ", strategyExpiredTime="

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->q:I

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    const-string/jumbo v1, "vl m,Lgolue"

    const-string/jumbo v1, "l ,lveuL=go"

    const-string v1, "evelo l=L,o"

    const-string v1, ", logLevel="

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->r:I

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    move v4, v3

    const-string v1, "eit mbi=iLF,olzegSi"

    const-string v1, ", logFileSizeLimit="

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->s:I

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v1, "=tCr,euu pn"

    const-string v1, " ruo,nCp=te"

    const/4 v4, 0x4

    const-string/jumbo v1, "noCur rpt=,"

    const-string v1, ", errCount="

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->t:I

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v1, "=omqaUgaqp lon,oiD"

    const-string v1, "agd,pioaqD lon=Uom"

    const/4 v4, 0x3

    const-string v1, ", logUploadDomain="

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a/a;->u:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string/jumbo v1, "t,se=rL ip"

    const-string v1, ", rptLive="

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->v:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string/jumbo v1, "rIimt,nlt spvve"

    const-string/jumbo v1, "l s,vineIvrpt=t"

    const-string/jumbo v1, "r,=eontvtilvL I"

    const-string v1, ", rptLiveIntvl="

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->w:I

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const-string v1, ",aeXlbmsbiG="

    const-string v1, "=bemXa,Gsldi"

    const/4 v4, 0x2

    const-string v1, "GXbi=aulde s"

    const-string v1, ", disableXG="

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a/a;->x:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v1, ", enableNewWd="

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->y:I

    const/4 v3, 0x5

    move v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    const-string v1, ",nobMetpi nola=o"

    const-string/jumbo v1, "r=beon aiot,Mlon"

    const/4 v4, 0x4

    const-string v1, " e=noretqoabliM,"

    const-string v1, ", enableMonitor="

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->z:I

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const-string/jumbo v1, "nrsrog,i emF=b"

    const-string v1, "e= rgbtronm,iF"

    const/4 v4, 0x2

    const-string/jumbo v1, "monm=rrgi ,Fto"

    const-string v1, ", monitorFreg="

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->A:I

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const-string v1, "aee=o urebnl,to"

    const-string/jumbo v1, "tren,lue oabRe="

    const/4 v4, 0x0

    const-string/jumbo v1, "tl=,eb rneeobpa"

    const-string v1, ", enableReport="

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->B:I

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const-string/jumbo v1, "sTnr,buo iaeV=te"

    const-string v1, ", abTestVersion="

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x4

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->C:I

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v4, 0x7

    const-string/jumbo v1, "nEt=Niaps,bleS ptH"

    const/4 v4, 0x6

    const-string v1, "StaEN ippHlben,s=t"

    const-string v1, ", isHttpDNSEnable="

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x5

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->D:I

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string/jumbo v1, "qLlsabBnqE =iS"

    const-string v1, "=L,basElq iBnS"

    const/4 v4, 0x6

    const-string v1, "=SsanbeEs,BlL "

    const-string v1, ", isLBSEnable="

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->E:I

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v1, ",stmsPeiPnaA=LibEl"

    const-string v1, "ibslLPn=iE,sPstaAe"

    const/4 v4, 0x7

    const-string/jumbo v1, "letEo PssnP=Ai,Lab"

    const-string v1, ", isAPPListEnable="

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->F:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string/jumbo v1, "oE anbb=t,ifistlsotcSNaamebti"

    const-string v1, "= imcSnaeoiEtNtiasibosltbaft,"

    const/4 v4, 0x0

    const-string v1, "focae,utsSnaEaisibitt=utbNio "

    const-string v1, ", isNotificatiobStatusEnable="

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    move v4, v3

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->G:I

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string v1, "=ealEngp Qeiosam"

    const-string v1, "ealno am,=QiEesg"

    const/4 v4, 0x5

    const-string/jumbo v1, "na=QgEs,qai eelm"

    const-string v1, ", isQgameEnable="

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x1

    iget v1, p0, Lcom/tencent/android/tpush/service/a/a;->H:I

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    const-string v1, "b_stiruvrpdr,dec_ A=lyuAtnArlovP"

    const-string v1, "=ucAlbtvnrvrduA A_ridPerpi_o,tyl"

    const/4 v4, 0x6

    const-string v1, ", pullup_Arr_ProviderAndActivty="

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a/a;->J:Lorg/json/JSONArray;

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v1, "kc_p gumuapalpp_ue=,s"

    const/4 v4, 0x6

    const-string/jumbo v1, "lmam p_ce=psap_l,pguu"

    const-string v1, ", pullup_packges_map="

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a/a;->K:Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-string v1, "eat=ouwClp kp"

    const-string/jumbo v1, "wtlpa= preukC"

    const/4 v4, 0x5

    const-string/jumbo v1, "k wC=bulteap,"

    const-string v1, ", wakeupCtrl="

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    move v4, v3

    iget-object v1, p0, Lcom/tencent/android/tpush/service/a/a;->I:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x5

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    return-object v0
.end method
