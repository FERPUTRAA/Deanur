.class Lcom/tencent/android/tpush/XGPushManager$22;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;JJ)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:J

.field final synthetic b:Landroid/content/Context;

.field final synthetic c:Ljava/lang/String;

.field final synthetic d:I

.field final synthetic e:Ljava/lang/String;

.field final synthetic f:J

.field final synthetic g:Ljava/lang/String;

.field final synthetic h:Ljava/lang/String;

.field final synthetic i:Ljava/lang/String;

.field final synthetic j:Ljava/lang/String;

.field final synthetic k:J


# direct methods
.method constructor <init>(JLandroid/content/Context;Ljava/lang/String;ILjava/lang/String;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    .locals 1

    const/4 v0, 0x6

    iput-wide p1, p0, Lcom/tencent/android/tpush/XGPushManager$22;->a:J

    const/4 v0, 0x4

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPushManager$22;->b:Landroid/content/Context;

    const/4 v0, 0x2

    iput-object p4, p0, Lcom/tencent/android/tpush/XGPushManager$22;->c:Ljava/lang/String;

    const/4 v0, 0x0

    iput p5, p0, Lcom/tencent/android/tpush/XGPushManager$22;->d:I

    const/4 v0, 0x0

    iput-object p6, p0, Lcom/tencent/android/tpush/XGPushManager$22;->e:Ljava/lang/String;

    const/4 v0, 0x1

    iput-wide p7, p0, Lcom/tencent/android/tpush/XGPushManager$22;->f:J

    const/4 v0, 0x0

    iput-object p9, p0, Lcom/tencent/android/tpush/XGPushManager$22;->g:Ljava/lang/String;

    const/4 v0, 0x2

    iput-object p10, p0, Lcom/tencent/android/tpush/XGPushManager$22;->h:Ljava/lang/String;

    const/4 v0, 0x4

    iput-object p11, p0, Lcom/tencent/android/tpush/XGPushManager$22;->i:Ljava/lang/String;

    const/4 v0, 0x7

    iput-object p12, p0, Lcom/tencent/android/tpush/XGPushManager$22;->j:Ljava/lang/String;

    const/4 v0, 0x0

    iput-wide p13, p0, Lcom/tencent/android/tpush/XGPushManager$22;->k:J

    const/4 v0, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 15

    const-string/jumbo v14, "~@sa@i~m.~@-b@t~~@~ @oS @ ~@~~@1b ~oou ~ol @~~ yt~lr@o4n@/@K @i@@   i~ ~f~@o~f  @~ bcv@~@~ds M/~"

    const-string v14, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v0, "saumgsMeGnXPa"

    const-string/jumbo v0, "nssXgaauGhMeP"

    const-string v0, "gGahouaePMnrs"

    const-string v0, "XGPushManager"

    :try_start_0
    const/4 v14, 0x7

    new-instance v5, Lcom/tencent/android/tpush/XGPushManager$22$1;

    const/4 v14, 0x5

    invoke-direct {v5, p0}, Lcom/tencent/android/tpush/XGPushManager$22$1;-><init>(Lcom/tencent/android/tpush/XGPushManager$22;)V

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v14, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v14, 0x3

    const-string v2, " gimMtRl4slnrnvidee:scwlaeubNea,eeiyrieD"

    const-string v2, "e4ll,btgbesidNnM:lvaescleruiRaDrieewe yi"

    const-string/jumbo v2, "registerRunnable4NewDevice, delayMillis:"

    const/4 v14, 0x5

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v14, 0x5

    iget-wide v2, p0, Lcom/tencent/android/tpush/XGPushManager$22;->a:J

    const/4 v14, 0x5

    invoke-virtual {v1, v2, v3}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v14, 0x2

    const-string/jumbo v2, "riusiouewDrlnent4e,abgNRevc:"

    const-string v2, "eDeuov,gaRwilrrncneNs4etb:ie"

    const-string v2, "e4eisnNpwgnl,it:raeDeeevcbRr"

    const-string v2, ",registerRunnable4NewDevice:"

    const/4 v14, 0x7

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->c()Lcom/tencent/tpns/baseapi/base/util/TTask;

    move-result-object v2

    const/4 v14, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v14, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v14, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v14, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$22;->b:Landroid/content/Context;

    const/4 v14, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$22;->c:Ljava/lang/String;

    const/4 v14, 0x5

    iget v3, p0, Lcom/tencent/android/tpush/XGPushManager$22;->d:I

    const/4 v14, 0x3

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$22;->e:Ljava/lang/String;

    const/4 v14, 0x0

    iget-wide v6, p0, Lcom/tencent/android/tpush/XGPushManager$22;->f:J

    const/4 v14, 0x3

    iget-object v8, p0, Lcom/tencent/android/tpush/XGPushManager$22;->g:Ljava/lang/String;

    const/4 v14, 0x5

    iget-object v9, p0, Lcom/tencent/android/tpush/XGPushManager$22;->h:Ljava/lang/String;

    const/4 v14, 0x3

    iget-object v10, p0, Lcom/tencent/android/tpush/XGPushManager$22;->i:Ljava/lang/String;

    const/4 v14, 0x2

    iget-object v11, p0, Lcom/tencent/android/tpush/XGPushManager$22;->j:Ljava/lang/String;

    const/4 v14, 0x0

    iget-wide v12, p0, Lcom/tencent/android/tpush/XGPushManager$22;->k:J

    const/4 v14, 0x7

    invoke-static/range {v1 .. v13}, Lcom/tencent/android/tpush/XGPushManager;->c(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;JLjava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;J)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v14, 0x5

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v14, 0x4

    const-string/jumbo v2, "uewuo ieqctsrrpRgnreDeorv4drNime e"

    const-string v2, "doDumpRegister4NewDevice run error"

    const/4 v14, 0x2

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v14, 0x6

    return-void
.end method
