.class Lcom/tencent/android/tpush/XGPushManager$28;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->uploadLogFile(Landroid/content/Context;Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;

.field final synthetic c:Landroid/content/BroadcastReceiver;


# direct methods
.method constructor <init>(Landroid/content/Context;Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;Landroid/content/BroadcastReceiver;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$28;->a:Landroid/content/Context;

    const/4 v1, 0x3

    const/4 v0, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$28;->b:Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;

    const/4 v1, 0x4

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPushManager$28;->c:Landroid/content/BroadcastReceiver;

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x7

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "oosf~@@ .@@i~o~~ b~f@~~~o/r/ @n~~  ~~ @Kiy tsaoucv@@@@4~~S@ @t bb M@@ @  1l@@idl  m~@~~o  ~~-~~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    const-string v0, "aGhmraseugnXs"

    const-string/jumbo v0, "nGsXehuMarasg"

    const/4 v3, 0x7

    const-string/jumbo v0, "rsXMoPeaGhgun"

    const-string v0, "XGPushManager"

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x0

    const-string/jumbo v1, "teietbmx AeacTn-meutoc"

    const-string v1, "a-emuonx eAetccte imtT"

    const/4 v3, 0x2

    const-string v1, "action - executeAtTime"

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$28;->a:Landroid/content/Context;

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {v0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object v0

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$28;->b:Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-static {v0, v1}, Lcom/tencent/tpns/baseapi/base/logger/TBaseLogger;->uploadLogFile(Landroid/content/Context;Lcom/tencent/tpns/baseapi/core/net/HttpRequestCallback;)V

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$28;->a:Landroid/content/Context;

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$28;->c:Landroid/content/BroadcastReceiver;

    const/4 v3, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/common/j;->a(Landroid/content/Context;Landroid/content/BroadcastReceiver;)Z

    const/4 v3, 0x1

    return-void
.end method
