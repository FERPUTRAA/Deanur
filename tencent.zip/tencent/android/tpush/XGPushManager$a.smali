.class Lcom/tencent/android/tpush/XGPushManager$a;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/XGPushManager;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# instance fields
.field private a:Landroid/content/Context;

.field private b:Landroid/content/Intent;

.field private c:Lcom/tencent/android/tpush/XGIOperateCallback;

.field private d:I

.field private e:I

.field private f:Z


# direct methods
.method constructor <init>(Lcom/tencent/android/tpush/XGIOperateCallback;Landroid/content/Context;Landroid/content/Intent;IIZ)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo v0, "nssnOubaRepeltr"

    const-string v0, "OtsRnapuenarleb"

    const/4 v2, 0x7

    const-string/jumbo v0, "uOnmabpeRtnerea"

    const-string v0, "OperateRunnable"

    const/4 v2, 0x5

    const/4 v1, 0x6

    invoke-direct {p0, v0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$a;->c:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x2

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$a;->a:Landroid/content/Context;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    iput-object p3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x5

    iput p4, p0, Lcom/tencent/android/tpush/XGPushManager$a;->d:I

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    iput p5, p0, Lcom/tencent/android/tpush/XGPushManager$a;->e:I

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    iput-boolean p6, p0, Lcom/tencent/android/tpush/XGPushManager$a;->f:Z

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 13

    const-string v12, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v11, " ~c~o~@Mn@~ ~oo~@bb~b   /~~~~@ @@@@ ~ @o@u@4o@@ KS ~ytii~ @vfi@ da~-~o@ l m.rf@o1~/ @s @~ l~~~~t"

    const-string v11, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v12, 0x2

    const-string/jumbo v0, "ttMdrbsNa5l"

    const-string/jumbo v0, "tdtmrN5sMal"

    const/4 v12, 0x1

    const-string v0, "5rsdtauMlNt"

    const-string/jumbo v0, "lastNMd5str"

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x2

    const-string v1, "hegraoMpPGsXn"

    const-string v1, "MGXeoPrsngahu"

    const/4 v12, 0x4

    const-string/jumbo v1, "naXasuheqgMPG"

    const-string v1, "XGPushManager"

    :try_start_0
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x0

    const/4 v11, 0x1

    const/4 v12, 0x7

    const-string v3, "btsarso"

    const-string v3, "estarbo"

    const/4 v12, 0x7

    const-string/jumbo v3, "tormges"

    const-string/jumbo v3, "storage"

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x0

    invoke-virtual {v2, v3}, Landroid/content/Intent;->removeExtra(Ljava/lang/String;)V

    const/4 v12, 0x7

    const/4 v11, 0x5

    const/4 v12, 0x4

    iget v2, p0, Lcom/tencent/android/tpush/XGPushManager$a;->d:I
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x7

    const-string/jumbo v3, "po:eo, uT"

    const-string v3, "e: Topu,p"

    const/4 v12, 0x4

    const-string/jumbo v3, "peT:ybop,"

    const-string v3, ", opType:"

    const/4 v11, 0x0

    or-int/2addr v12, v11

    const-string/jumbo v4, "raioteupo"

    const-string/jumbo v4, "iortepopa"

    const/4 v12, 0x3

    const-string/jumbo v4, "iepontapr"

    const-string/jumbo v4, "operation"

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x0

    const/4 v5, 0x1

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x3

    const/4 v6, -0x1

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x0

    if-ne v2, v5, :cond_c

    :try_start_1
    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x1

    const-string/jumbo v7, "tdaa"

    const-string v7, "aadt"

    const/4 v12, 0x5

    const-string v7, "daat"

    const-string v7, "data"

    const/4 v12, 0x1

    invoke-virtual {v2, v7}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    if-nez v2, :cond_0

    const/4 v12, 0x3

    const-string v2, ""

    const-string v2, ""

    const/4 v12, 0x7

    const-string v2, ""

    const-string v2, ""

    :cond_0
    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x0

    iget-object v7, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    invoke-virtual {v7, v4, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v4

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x0

    new-instance v7, Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-direct {v7}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x1

    const-string/jumbo v8, "r-oapiETq:SPnto PY qR"

    const-string v8, ":nt PRPrqo-ToiEpaY _S"

    const/4 v12, 0x7

    const-string/jumbo v8, "pTsEeat_YRiS- Prn:oPo"

    const-string v8, "TYPE_RSP - operation:"

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x5

    invoke-virtual {v7, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x7

    const/4 v12, 0x7

    invoke-virtual {v7, v4}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x0

    const/4 v11, 0x3

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x7

    iget v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->e:I

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x6

    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x0

    const/4 v12, 0x7

    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-static {v1, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x1

    move v12, v11

    if-eqz v4, :cond_2

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x0

    if-eq v4, v5, :cond_1

    const/4 v11, 0x0

    const/4 v12, 0x6

    goto/16 :goto_2

    :cond_1
    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$a;->c:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v11, 0x7

    const/4 v12, 0x6

    const-string/jumbo v4, "oedc"

    const-string v4, "dceo"

    const/4 v12, 0x7

    const-string/jumbo v4, "odec"

    const-string v4, "code"

    const/4 v12, 0x2

    const/4 v11, 0x1

    const/4 v12, 0x1

    invoke-virtual {v3, v4, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v3

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x1

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x1

    const-string/jumbo v5, "smg"

    const-string v5, "gsm"

    const-string/jumbo v5, "msg"

    const/4 v11, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-virtual {v4, v5}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    invoke-interface {v0, v2, v3, v4}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x7

    goto/16 :goto_2

    :cond_2
    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x5

    const/4 v11, 0x6

    const/4 v12, 0x7

    const-string/jumbo v4, "thsmPeehnrkToo"

    const-string v4, "eosrohsTknPeht"

    const/4 v12, 0x3

    const-string/jumbo v4, "otherPushToken"

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-virtual {v3, v4}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x1

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v11, 0x3

    const/4 v11, 0x6

    const-string v7, "TPhoohetuemsr"

    const-string v7, "eTtmuyoePrshh"

    const/4 v12, 0x7

    const-string v7, "PeuorbpThthye"

    const-string/jumbo v7, "otherPushType"

    const/4 v12, 0x2

    const-wide/16 v8, -0x1

    const-wide/16 v8, -0x1

    const/4 v12, 0x0

    const-wide/16 v8, -0x1

    const-wide/16 v8, -0x1

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-virtual {v4, v7, v8, v9}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v7

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x0

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-virtual {v4}, Ljava/lang/Long;->longValue()J

    move-result-wide v7

    const/4 v12, 0x2

    const/4 v11, 0x7

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    const/4 v12, 0x1

    const-wide/16 v9, 0x0

    const-wide/16 v9, 0x0

    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x5

    cmp-long v4, v7, v9

    const/4 v12, 0x2

    if-lez v4, :cond_4

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x5

    invoke-static {v3}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v4

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x1

    if-nez v4, :cond_3

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v12, 0x5

    const/4 v11, 0x3

    invoke-static {v4}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v4

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x2

    if-nez v4, :cond_3

    const/4 v12, 0x0

    const/4 v11, 0x3

    const/4 v12, 0x3

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$a;->a:Landroid/content/Context;

    const/4 v12, 0x3

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-virtual {v2}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x5

    const/4 v11, 0x2

    const/4 v12, 0x6

    invoke-static {v4, v3, v2}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_3
    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    move-object v2, v3

    :cond_4
    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x2

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-virtual {v3, v0}, Landroid/content/Intent;->hasExtra(Ljava/lang/String;)Z

    move-result v3

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x6

    if-eqz v3, :cond_5

    const/4 v12, 0x5

    const/4 v11, 0x5

    const/4 v12, 0x7

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x6

    invoke-virtual {v3, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/service/util/c;->a(Ljava/lang/String;)V

    :cond_5
    const/4 v12, 0x1

    const/4 v11, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$a;->c:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x7

    if-eqz v0, :cond_8

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x7

    instance-of v3, v0, Lcom/tencent/android/tpush/b;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x7

    const-string v4, "algf"

    const-string v4, "aglf"

    const/4 v12, 0x3

    const-string v4, "fgal"

    const-string v4, "flag"

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x6

    if-eqz v3, :cond_6

    :try_start_2
    const/4 v12, 0x4

    const/4 v11, 0x2

    const/4 v12, 0x6

    check-cast v0, Lcom/tencent/android/tpush/b;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x3

    invoke-virtual {v3, v4, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v3

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x5

    iget-boolean v7, p0, Lcom/tencent/android/tpush/XGPushManager$a;->f:Z

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-interface {v0, v2, v3, v7}, Lcom/tencent/android/tpush/b;->a(Ljava/lang/Object;IZ)V

    :cond_6
    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x6

    iget-boolean v0, p0, Lcom/tencent/android/tpush/XGPushManager$a;->f:Z

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x1

    if-nez v0, :cond_7

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$a;->c:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x6

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x0

    const/4 v11, 0x5

    const/4 v12, 0x3

    invoke-virtual {v3, v4, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v3

    const/4 v12, 0x3

    const/4 v11, 0x6

    const/4 v12, 0x7

    invoke-interface {v0, v2, v3}, Lcom/tencent/android/tpush/XGIOperateCallback;->onSuccess(Ljava/lang/Object;I)V

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x2

    goto :goto_0

    :cond_7
    const/4 v12, 0x5

    const-string v0, "TYPE_RSP - has invoked callback"

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_8
    :goto_0
    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x6

    new-instance v0, Lcom/tencent/android/tpush/data/RegisterEntity;

    const/4 v12, 0x3

    const/4 v11, 0x5

    invoke-direct {v0}, Lcom/tencent/android/tpush/data/RegisterEntity;-><init>()V

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x5

    iget v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->e:I

    const/4 v12, 0x7

    const/4 v11, 0x6

    const/4 v12, 0x7

    if-nez v3, :cond_9

    const/4 v11, 0x3

    const/4 v11, 0x7

    const/4 v12, 0x4

    const/4 v3, 0x0

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x5

    iput v3, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->state:I

    const/4 v12, 0x5

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->c()Lcom/tencent/tpns/baseapi/base/util/TTask;

    move-result-object v3

    const/4 v12, 0x3

    const/4 v11, 0x3

    if-eqz v3, :cond_a

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x1

    const-string/jumbo v3, "rnonivuse iereceeNeDrue4voglaRwtb"

    const-string/jumbo v3, "ubrroe Rveatnewir4eneceieNDesglov"

    const/4 v12, 0x1

    const-string v3, "esRNv npeeerrevgbrcleowieeD4amtin"

    const-string/jumbo v3, "remove registerRunnable4NewDevice"

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-static {v1, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v11, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x7

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v3

    const/4 v12, 0x1

    const/4 v11, 0x7

    const/4 v12, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/XGPushManager;->c()Lcom/tencent/tpns/baseapi/base/util/TTask;

    move-result-object v4

    const/4 v12, 0x0

    const/4 v11, 0x0

    const/4 v12, 0x0

    invoke-virtual {v3, v4}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->remove(Lcom/tencent/tpns/baseapi/base/util/TTask;)V

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x2

    const/4 v3, 0x0

    const/4 v12, 0x3

    const/4 v11, 0x2

    invoke-static {v3}, Lcom/tencent/android/tpush/XGPushManager;->a(Lcom/tencent/tpns/baseapi/base/util/TTask;)Lcom/tencent/tpns/baseapi/base/util/TTask;

    const/4 v12, 0x1

    const/4 v11, 0x6

    goto :goto_1

    :cond_9
    const/4 v11, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x1

    iput v5, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->state:I

    :cond_a
    :goto_1
    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x3

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x1

    const-string v4, "accId"

    const/4 v12, 0x3

    const/4 v11, 0x5

    const/4 v12, 0x4

    invoke-virtual {v3, v4, v9, v10}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v3

    const/4 v11, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x1

    iput-wide v3, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->accessId:J

    const/4 v12, 0x6

    const/4 v11, 0x4

    const/4 v12, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->a:Landroid/content/Context;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-virtual {v3}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x1

    iput-object v3, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->packageName:Ljava/lang/String;

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x0

    iput-object v2, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->token:Ljava/lang/String;

    const/4 v12, 0x6

    const/4 v11, 0x6

    const/4 v12, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v3

    const/4 v12, 0x4

    const/4 v11, 0x4

    const/4 v12, 0x1

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const/4 v12, 0x5

    const-wide/16 v5, 0x3e8

    const-wide/16 v5, 0x3e8

    const/4 v12, 0x0

    const/4 v11, 0x7

    const/4 v12, 0x6

    div-long/2addr v3, v5

    const/4 v12, 0x2

    const/4 v11, 0x7

    const/4 v12, 0x0

    iput-wide v3, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->timestamp:J

    const/4 v12, 0x3

    const-string v3, "4qb3.19"

    const-string v3, "1.93.b4"

    const/4 v12, 0x6

    const-string v3, ".4s19.3"

    const-string v3, "1.4.3.9"

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x5

    iput-object v3, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->xgSDKVersion:Ljava/lang/String;

    const/4 v12, 0x0

    const/4 v11, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->a:Landroid/content/Context;

    const/4 v12, 0x2

    const/4 v11, 0x2

    const/4 v12, 0x0

    invoke-static {v3}, Lcom/tencent/android/tpush/common/AppInfos;->getCurAppVersion(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v3

    const/4 v12, 0x7

    const/4 v11, 0x0

    const/4 v12, 0x4

    iput-object v3, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->appVersion:Ljava/lang/String;

    const/4 v12, 0x2

    const/4 v11, 0x5

    const/4 v12, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->a:Landroid/content/Context;

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x1

    invoke-static {v3, v0}, Lcom/tencent/android/tpush/service/cache/CacheManager;->setCurrentAppRegisterEntity(Landroid/content/Context;Lcom/tencent/android/tpush/data/RegisterEntity;)V

    const/4 v12, 0x0

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget-object v3, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->packageName:Ljava/lang/String;

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x3

    invoke-static {v3}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x1

    if-nez v3, :cond_b

    const/4 v12, 0x4

    const/4 v11, 0x0

    sget-object v3, Lcom/tencent/android/tpush/XGPushManager;->lastSuccessRegisterMap:Ljava/util/Map;

    const/4 v11, 0x4

    move v12, v11

    iget-object v0, v0, Lcom/tencent/android/tpush/data/RegisterEntity;->packageName:Ljava/lang/String;

    const/4 v12, 0x4

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v7

    const/4 v12, 0x6

    const/4 v11, 0x3

    const/4 v12, 0x1

    div-long/2addr v7, v5

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x4

    invoke-static {v7, v8}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v4

    const/4 v12, 0x4

    const/4 v11, 0x4

    invoke-interface {v3, v0, v4}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    :cond_b
    const/4 v12, 0x2

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget v0, p0, Lcom/tencent/android/tpush/XGPushManager$a;->e:I

    const/4 v12, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x3

    if-nez v0, :cond_f

    const/4 v11, 0x4

    and-int/2addr v12, v11

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$a;->a:Landroid/content/Context;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/d/b;->a(Landroid/content/Context;)V

    const/4 v11, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/XGPushManager$a;->e:I

    const/4 v12, 0x7

    const/4 v11, 0x7

    const/4 v12, 0x7

    if-nez v0, :cond_f

    const/4 v12, 0x4

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$a;->a:Landroid/content/Context;

    const/4 v12, 0x4

    const/4 v11, 0x0

    const/4 v12, 0x6

    const-string/jumbo v3, "uRemsrtgitsre"

    const-string/jumbo v3, "tsietiurrgseR"

    const-string/jumbo v3, "tsrioifsRetgr"

    const-string v3, "firstRegister"

    const/4 v12, 0x6

    const/4 v11, 0x5

    const/4 v12, 0x7

    invoke-static {v0, v2, v3}, Lcom/tencent/android/tpush/stat/a/a;->a(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x3

    const/4 v11, 0x2

    const/4 v12, 0x4

    goto/16 :goto_2

    :cond_c
    const/4 v11, 0x7

    const/4 v11, 0x2

    const/4 v12, 0x7

    if-nez v2, :cond_f

    const/4 v12, 0x2

    const/4 v11, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x0

    const/4 v11, 0x4

    const/4 v12, 0x4

    invoke-virtual {v0, v4, v6}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v12, 0x2

    const/4 v11, 0x4

    const/4 v12, 0x0

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v12, 0x6

    const/4 v11, 0x1

    const/4 v12, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x7

    const-string/jumbo v4, "teYR_orponiEQPa:TE p-"

    const/4 v12, 0x7

    const-string v4, " pYnib: ToER_oaP-EetQ"

    const-string v4, "TYPE_REQ - operation:"

    const/4 v12, 0x1

    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    const/4 v11, 0x1

    const/4 v12, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x1

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x2

    iget v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->e:I

    const/4 v12, 0x0

    const/4 v11, 0x2

    const/4 v12, 0x5

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v12, 0x4

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v12, 0x1

    const/4 v11, 0x4

    const/4 v12, 0x6

    invoke-static {v1, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x0

    const/16 v2, 0x64

    const/4 v12, 0x1

    const/4 v11, 0x3

    const/4 v12, 0x7

    if-eq v0, v2, :cond_e

    const/4 v12, 0x1

    const/16 v2, 0x65

    const/4 v12, 0x1

    const/4 v11, 0x0

    const/4 v12, 0x3

    if-eq v0, v2, :cond_d

    const/4 v12, 0x1

    const/4 v11, 0x2

    const/4 v12, 0x6

    goto :goto_2

    :cond_d
    const/4 v12, 0x7

    const/4 v11, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$a;->a:Landroid/content/Context;

    const/4 v12, 0x3

    const/4 v11, 0x4

    const/4 v12, 0x5

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x6

    const/4 v11, 0x0

    const/4 v12, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->c:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v11, 0x7

    xor-int/2addr v12, v11

    invoke-static {v0, v2, v3}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v12, 0x2

    const/4 v11, 0x0

    const/4 v12, 0x6

    goto :goto_2

    :cond_e
    const/4 v12, 0x1

    const/4 v11, 0x6

    const/4 v12, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$a;->a:Landroid/content/Context;

    const/4 v12, 0x6

    const/4 v11, 0x7

    const/4 v12, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$a;->b:Landroid/content/Intent;

    const/4 v12, 0x6

    const/4 v11, 0x2

    const/4 v12, 0x0

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$a;->c:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v12, 0x3

    const/4 v11, 0x1

    const/4 v12, 0x5

    invoke-static {v0, v2, v3}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Landroid/content/Intent;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    :cond_f
    :goto_2
    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$a;->a:Landroid/content/Context;

    const/4 v12, 0x7

    const/4 v11, 0x4

    const/4 v12, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/common/b;->a(Landroid/content/Context;)V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_0

    const/4 v12, 0x7

    goto :goto_3

    :catchall_0
    move-exception v0

    const/4 v12, 0x5

    const/4 v11, 0x7

    const/4 v12, 0x5

    const-string/jumbo v2, "nORlutubpeeraea"

    const-string/jumbo v2, "rpeObauRqtnlaee"

    const/4 v12, 0x3

    const-string v2, "aORrpelpentanbe"

    const-string v2, "OperateRunnable"

    const/4 v12, 0x4

    const/4 v11, 0x3

    const/4 v12, 0x1

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_3
    const/4 v12, 0x1

    const/4 v11, 0x1

    const/4 v12, 0x3

    return-void
.end method
