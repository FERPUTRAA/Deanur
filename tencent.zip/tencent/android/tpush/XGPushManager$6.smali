.class Lcom/tencent/android/tpush/XGPushManager$6;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/XGIOperateCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->queryTags(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:I

.field final synthetic d:I

.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Lcom/tencent/android/tpush/XGIOperateCallback;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$6;->a:Landroid/content/Context;

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$6;->b:Ljava/lang/String;

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x5

    iput p3, p0, Lcom/tencent/android/tpush/XGPushManager$6;->c:I

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x4

    iput p4, p0, Lcom/tencent/android/tpush/XGPushManager$6;->d:I

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p5, p0, Lcom/tencent/android/tpush/XGPushManager$6;->e:Ljava/lang/String;

    const/4 v1, 0x1

    iput-object p6, p0, Lcom/tencent/android/tpush/XGPushManager$6;->f:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public onFail(Ljava/lang/Object;ILjava/lang/String;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v1, "l~sc@ ~~ ~~~   tr~@~o - @ ~l@~a@ o v~@~f ~o 4i@@b@M~on@~/ o~/m@b@u  1ts@@~y~@.~ ~i@b@S f@~@o@~iK"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$6;->f:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-interface {v0, p1, p2, p3}, Lcom/tencent/android/tpush/XGIOperateCallback;->onFail(Ljava/lang/Object;ILjava/lang/String;)V

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x3

    return-void
.end method

.method public onSuccess(Ljava/lang/Object;I)V
    .locals 8

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$6;->a:Landroid/content/Context;

    const/4 v7, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$6;->b:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x0

    iget v2, p0, Lcom/tencent/android/tpush/XGPushManager$6;->c:I

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x7

    iget v3, p0, Lcom/tencent/android/tpush/XGPushManager$6;->d:I

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x1

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$6;->e:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x6

    const/4 v7, 0x5

    iget-object v5, p0, Lcom/tencent/android/tpush/XGPushManager$6;->f:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v7, 0x3

    const/4 v6, 0x2

    const/4 v7, 0x5

    invoke-static/range {v0 .. v5}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x2

    return-void
.end method
