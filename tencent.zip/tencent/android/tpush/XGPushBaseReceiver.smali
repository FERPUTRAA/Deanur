.class public abstract Lcom/tencent/android/tpush/XGPushBaseReceiver;
.super Landroid/content/BroadcastReceiver;


# static fields
.field public static final SUCCESS:I

.field private static b:J


# instance fields
.field private a:J


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x4

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-direct {p0}, Landroid/content/BroadcastReceiver;-><init>()V

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGPushBaseReceiver;->a:J

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-void
.end method

.method private a(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " @su~m 4Ko~@~io@nb~.@ o~fMr~d/ ~~S of 1@@@o~ocs@b~i~t/a~~@ @@i y@@~@l -  ~   t~~l@v @ @~@~@~b ~@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x1

    const-string v0, "NUCmSLNPsHAH"

    const-string v0, "LAs.SHCNHNUP"

    const/4 v6, 0x7

    const-string v0, "NPA.oNHLSCUH"

    const-string v0, "PUSH.CHANNEL"

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    const/16 v1, 0x64

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-ne v0, v1, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {p1, p2}, Lcom/tencent/android/tpush/message/PushMessageManager;->getInstance(Landroid/content/Context;Landroid/content/Intent;)Lcom/tencent/android/tpush/message/PushMessageManager;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMessageHolder()Lcom/tencent/android/tpush/message/a;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v2}, Lcom/tencent/android/tpush/message/a;->b()I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x3

    const/4 v3, 0x2

    const/4 v6, 0x7

    if-ne v2, v3, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    new-instance v2, Lcom/tencent/android/tpush/XGPushTextMessage;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-direct {v2}, Lcom/tencent/android/tpush/XGPushTextMessage;-><init>()V

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMsgId()J

    move-result-wide v3

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x4

    iput-wide v3, v2, Lcom/tencent/android/tpush/XGPushTextMessage;->a:J

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x6

    iput v0, v2, Lcom/tencent/android/tpush/XGPushTextMessage;->e:I

    const/4 v6, 0x4

    const/4 v5, 0x0

    invoke-virtual {v1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMessageHolder()Lcom/tencent/android/tpush/message/a;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpush/message/a;->d()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput-object v0, v2, Lcom/tencent/android/tpush/XGPushTextMessage;->b:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMessageHolder()Lcom/tencent/android/tpush/message/a;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpush/message/a;->e()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x6

    iput-object v0, v2, Lcom/tencent/android/tpush/XGPushTextMessage;->c:Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-virtual {v1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getMessageHolder()Lcom/tencent/android/tpush/message/a;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpush/message/a;->f()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x1

    iput-object v0, v2, Lcom/tencent/android/tpush/XGPushTextMessage;->d:Ljava/lang/String;

    const/4 v6, 0x6

    invoke-virtual {v1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getTemplateId()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    iput-object v0, v2, Lcom/tencent/android/tpush/XGPushTextMessage;->f:Ljava/lang/String;

    const/4 v6, 0x1

    const/4 v5, 0x7

    invoke-virtual {v1}, Lcom/tencent/android/tpush/message/PushMessageManager;->getTraceId()Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x3

    iput-object v0, v2, Lcom/tencent/android/tpush/XGPushTextMessage;->g:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-virtual {v2, p2}, Lcom/tencent/android/tpush/XGPushTextMessage;->a(Landroid/content/Intent;)V

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-virtual {p0, p1, v2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onTextMessage(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushTextMessage;)V

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    goto/16 :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    new-instance v1, Lcom/tencent/android/tpush/XGPushTextMessage;

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-direct {v1}, Lcom/tencent/android/tpush/XGPushTextMessage;-><init>()V

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string/jumbo v2, "msgId"

    const/4 v6, 0x1

    const/4 v5, 0x5

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v6, 0x5

    const-wide/16 v3, -0x1

    const-wide/16 v3, -0x1

    const/4 v6, 0x3

    const/4 v5, 0x3

    invoke-virtual {p2, v2, v3, v4}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    iput-wide v2, v1, Lcom/tencent/android/tpush/XGPushTextMessage;->a:J

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x5

    iput v0, v1, Lcom/tencent/android/tpush/XGPushTextMessage;->e:I

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string/jumbo v0, "nctmtbo"

    const-string v0, "conmett"

    const/4 v6, 0x4

    const-string/jumbo v0, "nnttceu"

    const-string v0, "content"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x2

    iput-object v0, v1, Lcom/tencent/android/tpush/XGPushTextMessage;->c:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo v0, "tiplt"

    const-string/jumbo v0, "title"

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x6

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x4

    iput-object v0, v1, Lcom/tencent/android/tpush/XGPushTextMessage;->b:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x3

    const-string/jumbo v0, "n_ocsucmqnotet"

    const-string/jumbo v0, "tnctont_oscuem"

    const/4 v6, 0x1

    const-string v0, "cos_utettcsomn"

    const-string v0, "custom_content"

    const/4 v6, 0x1

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    iput-object v0, v1, Lcom/tencent/android/tpush/XGPushTextMessage;->d:Ljava/lang/String;

    const/4 v5, 0x6

    move v6, v5

    const-string/jumbo v0, "mtdmIeltbp"

    const-string/jumbo v0, "tepIlbtmed"

    const/4 v6, 0x6

    const-string/jumbo v0, "medpotaIle"

    const-string/jumbo v0, "templateId"

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x3

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x5

    iput-object v0, v1, Lcom/tencent/android/tpush/XGPushTextMessage;->f:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x6

    const-string v0, "ctudabI"

    const-string v0, "adetcIu"

    const/4 v6, 0x7

    const-string/jumbo v0, "rIteadu"

    const-string/jumbo v0, "traceId"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x3

    iput-object v0, v1, Lcom/tencent/android/tpush/XGPushTextMessage;->g:Ljava/lang/String;

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x4

    const-string v0, "dcpIc"

    const-string v0, "cIpdc"

    const/4 v6, 0x4

    const-string v0, "acdqc"

    const-string v0, "accId"

    const/4 v6, 0x6

    const/4 v5, 0x2

    const/4 v6, 0x5

    invoke-static {p1}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {p2, v0, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v6, 0x7

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->e(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x0

    invoke-virtual {p0, p1, v1}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onTextMessage(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushTextMessage;)V

    :cond_1
    :goto_0
    const/4 v5, 0x7

    move v6, v5

    return-void
.end method

.method private a(Landroid/content/Context;Landroid/content/Intent;I)V
    .locals 4

    :try_start_0
    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x1

    const-string/jumbo v0, "tada"

    const-string v0, "daat"

    const/4 v3, 0x2

    const-string v0, "atda"

    const-string v0, "data"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x5

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x4

    const-string v1, "aTsasgqumeqyr"

    const-string v1, "asgTNyrqquame"

    const/4 v3, 0x3

    const-string/jumbo v1, "queryTagsName"

    const/4 v3, 0x1

    invoke-virtual {p2, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-virtual {p0, p1, p3, v0, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onQueryTagsResult(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x6

    const-string p2, "PsvmiecauReeXGrssB"

    const-string p2, "RvsGsasheceirPeBuX"

    const/4 v3, 0x0

    const-string p2, "esBeoGvihuecPaRerX"

    const-string p2, "XGPushBaseReceiver"

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo p3, "kyarQbcaTeskfgeeu:"

    const-string p3, "feekbackQueryTags:"

    const/4 v3, 0x3

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p2, p3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x5

    return-void
.end method

.method static synthetic a(Lcom/tencent/android/tpush/XGPushBaseReceiver;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x0

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->f(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x3

    return-void
.end method

.method private b(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 6

    const/4 v5, 0x7

    const/4 v4, 0x0

    const-string v0, "UDA.PHuKFEmEBT"

    const-string v0, "UHBmETKFSAP.DE"

    const/4 v5, 0x3

    const-string v0, "FBDEHKSpEPTU.C"

    const-string v0, "TPUSH.FEEDBACK"

    const/4 v5, 0x7

    const/4 v1, -0x4

    const/4 v5, 0x0

    const/4 v1, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x5

    const-string v2, "HRUOoR.EDROTCES"

    const/4 v5, 0x3

    const-string v2, "RDTOOPSRqU.REEC"

    const-string v2, "TPUSH.ERRORCODE"

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p2, v2, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v3, ",kseceybea-ac fabaobkleTtdecid  nfn:dp e"

    const-string/jumbo v3, "latadb eeen-necfpck o,bee ab:dyacrdkfi T"

    const/4 v5, 0x4

    const-string v3, "i emeekatro ,pny-cnfTeek:daHaedfdlc bc a"

    const-string v3, "action - feedbackHandler, feedbackType: "

    const/4 v5, 0x1

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x5

    const-string/jumbo v3, "ivaPesuecesrRBehuG"

    const-string v3, "XGPushBaseReceiver"

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x6

    packed-switch v0, :pswitch_data_0

    :pswitch_0
    const/4 v4, 0x0

    move v5, v4

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x1

    const-string p2, "b74:oeuaTdp2p/k7587c7ye6/eueu/f"

    const-string p2, "b5u77papd//akf/Tue7ey64:82ee7cu"

    const/4 v5, 0x6

    const-string/jumbo p2, "\u672a\u77e5\u7684feedbackType:"

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x6

    invoke-static {v3, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x7

    move v5, v4

    goto :goto_0

    :pswitch_1
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->h(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x1

    goto :goto_0

    :pswitch_2
    const/4 v5, 0x5

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->g(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :pswitch_3
    const/4 v5, 0x5

    invoke-direct {p0, p1, p2, v1}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->a(Landroid/content/Context;Landroid/content/Intent;I)V

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x0

    goto :goto_0

    :pswitch_4
    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    invoke-direct {p0, p1, p2, v1}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->b(Landroid/content/Context;Landroid/content/Intent;I)V

    const/4 v4, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x4

    goto :goto_0

    :pswitch_5
    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-direct {p0, p1, p2, v1}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->c(Landroid/content/Context;Landroid/content/Intent;I)V

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x4

    goto :goto_0

    :pswitch_6
    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->c(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v4, 0x2

    move v5, v4

    goto :goto_0

    :pswitch_7
    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->d(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v5, 0x3

    goto :goto_0

    :pswitch_8
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-direct {p0, p1, p2, v1}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->d(Landroid/content/Context;Landroid/content/Intent;I)V

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x6

    goto :goto_0

    :pswitch_9
    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x6

    new-instance v0, Lcom/tencent/android/tpush/XGPushRegisterResult;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGPushRegisterResult;-><init>()V

    const/4 v4, 0x4

    move v5, v4

    invoke-virtual {v0, p2}, Lcom/tencent/android/tpush/XGPushRegisterResult;->parseIntent(Landroid/content/Intent;)V

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-virtual {p0, p1, v1}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onUnregisterResult(Landroid/content/Context;I)V

    const/4 v4, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    goto :goto_0

    :pswitch_a
    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x6

    invoke-direct {p0, p1, p2, v1}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->e(Landroid/content/Context;Landroid/content/Intent;I)V

    :goto_0
    const/4 v4, 0x1

    const/4 v5, 0x3

    return-void

    nop

    :pswitch_data_0
    .packed-switch 0x1
        :pswitch_a
        :pswitch_9
        :pswitch_8
        :pswitch_7
        :pswitch_6
        :pswitch_5
        :pswitch_4
        :pswitch_3
        :pswitch_0
        :pswitch_2
        :pswitch_1
    .end packed-switch
.end method

.method private b(Landroid/content/Context;Landroid/content/Intent;I)V
    .locals 7

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    const-string/jumbo v0, "rqastbautemeti"

    const-string/jumbo v0, "mratstiaqNeteu"

    const-string v0, "Nmteuaubetatrs"

    const-string v0, "attributesName"

    const/4 v6, 0x7

    const/4 v5, 0x6

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x5

    if-nez v1, :cond_4

    const/4 v6, 0x7

    const-string/jumbo v1, "strgFltptbsiae"

    const-string/jumbo v1, "tFstbatgriusle"

    const/4 v6, 0x4

    const-string v1, "attributesFlag"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    const/4 v2, -0x1

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x2

    const-string v2, "aemutNmtqrsaepetaiOtb"

    const-string/jumbo v2, "irtmsteeaaeNpeattbmuO"

    const-string v2, "attributesOperateName"

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-string/jumbo v4, "osse oupTbtrtea,iyp"

    const-string/jumbo v4, "rtyeob,asp:puit eTo"

    const-string/jumbo v4, "rTamyptbe:i eto,ust"

    const-string v4, "attributes, opType:"

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x1

    const-string v4, "a,bttb :rtuNeiams"

    const/4 v6, 0x5

    const-string/jumbo v4, "trb o,smtei:aeauN"

    const-string v4, " ,attributesName:"

    const/4 v6, 0x0

    const/4 v5, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    const-string v4, "e:op,betae Nur"

    const-string v4, "etao pu:erea,N"

    const/4 v6, 0x2

    const-string/jumbo v4, "per:Naua oetme"

    const-string v4, ", operateName:"

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo v4, "ueeGrpRpeBevXasPis"

    const-string v4, "eesBeuPpGRsevXirah"

    const/4 v6, 0x3

    const-string v4, "XGPushBaseReceiver"

    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {v4, v3}, Lcom/tencent/android/tpush/logging/TLogger;->i(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x7

    const/4 v3, 0x2

    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-eq v1, v3, :cond_3

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    const/4 v3, 0x1

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-ne v1, v3, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    goto/16 :goto_1

    :cond_0
    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    const/4 v3, 0x4

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x7

    if-eq v1, v3, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x2

    const/4 v3, 0x3

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-ne v1, v3, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x3

    goto :goto_0

    :cond_1
    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    const-string p3, "efsrtf/rqato aturerub1"

    const/4 v6, 0x4

    const-string p3, "1sor/iuuqretarfb ftret"

    const-string p3, "error attributes\uff1a"

    const/4 v5, 0x7

    and-int/2addr v6, v5

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x7

    const-string/jumbo p3, "utsteausi Neff/b,aa1rs"

    const-string p3, "i/seu1atuNe raafbtsm,f"

    const/4 v6, 0x3

    const-string/jumbo p3, "stamef1amb uiatftN/re,"

    const-string p3, " ,attributesName\uff1a"

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    const-string/jumbo p3, "tnnto,eim"

    const-string/jumbo p3, "ntnme,t i"

    const/4 v6, 0x0

    const-string/jumbo p3, "nei,nbt t"

    const-string p3, ", intent:"

    const/4 v6, 0x2

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x2

    invoke-virtual {p2}, Landroid/content/Intent;->getExtras()Landroid/os/Bundle;

    move-result-object p2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-static {v4, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x4

    goto :goto_2

    :cond_2
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-virtual {p0, p1, p3, v2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onDeleteAttributeResult(Landroid/content/Context;ILjava/lang/String;)V

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    goto :goto_2

    :cond_3
    :goto_1
    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {p0, p1, p3, v2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onSetAttributeResult(Landroid/content/Context;ILjava/lang/String;)V

    :cond_4
    :goto_2
    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x5

    return-void
.end method

.method static synthetic b(Lcom/tencent/android/tpush/XGPushBaseReceiver;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->a(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-void
.end method

.method private c(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 6

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    new-instance v0, Lcom/tencent/android/tpush/XGPushShowedResult;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x7

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGPushShowedResult;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x0

    const-string/jumbo v1, "oEHCU.uLSNPA"

    const-string v1, "CLSUo.PANEHH"

    const/4 v5, 0x5

    const-string v1, "PUSH.CHANNEL"

    const/4 v5, 0x0

    const/16 v2, 0x64

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v3

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x7

    if-eq v3, v2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/16 v2, 0x65

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eq v3, v2, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    const/16 v2, 0x63

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x0

    if-ne v3, v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x0

    goto :goto_0

    :cond_0
    const-string/jumbo v2, "pctbtne"

    const-string/jumbo v2, "tecnnbt"

    const/4 v5, 0x2

    const-string v2, "eqotntn"

    const-string v2, "content"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    iput-object v2, v0, Lcom/tencent/android/tpush/XGPushShowedResult;->c:Ljava/lang/String;

    const/4 v4, 0x2

    shl-int/2addr v5, v4

    const-string/jumbo v2, "iustl"

    const-string v2, "eutil"

    const/4 v5, 0x5

    const-string/jumbo v2, "iteml"

    const-string/jumbo v2, "title"

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-object v2, v0, Lcom/tencent/android/tpush/XGPushShowedResult;->b:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x1

    const-string/jumbo v2, "mooconnctp_stt"

    const-string/jumbo v2, "ntmescopocntt_"

    const/4 v5, 0x0

    const-string/jumbo v2, "tnmsubnootetc_"

    const-string v2, "custom_content"

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    iput-object v2, v0, Lcom/tencent/android/tpush/XGPushShowedResult;->d:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x3

    const/4 v2, 0x0

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    iput v1, v0, Lcom/tencent/android/tpush/XGPushShowedResult;->h:I

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    const-string v1, "Iudca"

    const-string v1, "Icaqd"

    const/4 v5, 0x3

    const-string v1, "Icpac"

    const-string v1, "accId"

    const/4 v5, 0x3

    invoke-static {p1}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessId(Landroid/content/Context;)J

    move-result-wide v2

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-virtual {p2, v1, v2, v3}, Landroid/content/Intent;->putExtra(Ljava/lang/String;J)Landroid/content/Intent;

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x6

    goto :goto_1

    :cond_1
    :goto_0
    const/4 v4, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    invoke-virtual {v0, p2}, Lcom/tencent/android/tpush/XGPushShowedResult;->parseIntent(Landroid/content/Intent;)V

    :goto_1
    const/4 v5, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onNotificationShowedResult(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushShowedResult;)V

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void
.end method

.method private c(Landroid/content/Context;Landroid/content/Intent;I)V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x3

    const-string/jumbo v0, "usNacotnqmc"

    const-string v0, "acsmNunoect"

    const/4 v5, 0x6

    const-string/jumbo v0, "tcsnaeaoucN"

    const-string v0, "accountName"

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x4

    const-string v1, "erTmyempopa"

    const-string v1, "arpmoetyTep"

    const/4 v5, 0x7

    const-string v1, "aeTeorytpop"

    const-string/jumbo v1, "operateType"

    const/4 v5, 0x3

    const/4 v2, -0x1

    const/4 v5, 0x0

    const/4 v2, -0x1

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x4

    const-string v2, "FcutdbeeonaBcac"

    const-string v2, "ctBaoekFnceacud"

    const/4 v5, 0x5

    const-string/jumbo v2, "oBeFceuakcdunta"

    const-string v2, "accountFeedBack"

    const/4 v5, 0x5

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v2, 0x1

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-ne v1, v2, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {p0, p1, p3, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onDeleteAccountResult(Landroid/content/Context;ILjava/lang/String;)V

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x7

    goto/16 :goto_2

    :cond_0
    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v3, :cond_5

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x7

    if-eqz v1, :cond_4

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    const/4 v3, 0x2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-eq v1, v3, :cond_4

    const/4 v5, 0x4

    const/4 v3, 0x6

    const/4 v5, 0x0

    and-int/2addr v4, v3

    const/4 v5, 0x2

    if-ne v1, v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x3

    goto :goto_1

    :cond_1
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    const/4 v3, 0x3

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-eq v1, v3, :cond_3

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x5

    if-eq v1, v2, :cond_3

    const/4 v4, 0x1

    move v5, v4

    const/4 v2, 0x2

    const/4 v2, 0x7

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-ne v1, v2, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x1

    goto :goto_0

    :cond_2
    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string p2, "/91u01up84/7f7f3ub46/u/uu5707feu504/a//c8ub75//5/b17be9u5u8f"

    const-string p2, "//a/ub/7775490f5b8051/uuu/uuu4uf9/1b/fef5416778u59ce3/87b/0u"

    const/4 v5, 0x2

    const-string p2, "1u//97/0q45u95uub/3f44u6/88cu0b0/57//u87/u/9f7fbu6u1e1e77fa5"

    const-string/jumbo p2, "\u9519\u8bef\u7684\u5e10\u53f7\u5904\u7406\u7c7b\u578b\uff1a"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x7

    const/4 v4, 0x1

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x3

    const-string p2, "c stoe,mNafaf1cauu/"

    const-string p2, " camatuaNu/n1feof,c"

    const-string p2, "N/1mfauntmoeca, cfu"

    const-string p2, " ,accountName\uff1a"

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x0

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    const-string/jumbo p2, "ssGhopeveuereiXaBc"

    const-string p2, "BeueecspaGrhseiXRv"

    const/4 v5, 0x4

    const-string p2, "euaeRbXsheseiPGrcB"

    const-string p2, "XGPushBaseReceiver"

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x3

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    goto :goto_2

    :cond_3
    :goto_0
    const/4 v4, 0x7

    move v5, v4

    invoke-virtual {p0, p1, p3, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onDeleteAccountResult(Landroid/content/Context;ILjava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x1

    goto :goto_2

    :cond_4
    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    invoke-virtual {p0, p1, p3, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onSetAccountResult(Landroid/content/Context;ILjava/lang/String;)V

    :cond_5
    :goto_2
    const/4 v4, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x6

    return-void
.end method

.method static synthetic c(Lcom/tencent/android/tpush/XGPushBaseReceiver;Landroid/content/Context;Landroid/content/Intent;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0, p1, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->b(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x1

    return-void
.end method

.method private d(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 11

    const/4 v10, 0x1

    const/4 v9, 0x7

    const/4 v0, -0x3

    const/4 v0, -0x1

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x7

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/XGPushConfig;->changeHuaweiBadgeNum(Landroid/content/Context;I)V

    const/4 v10, 0x2

    const/4 v9, 0x7

    const/4 v10, 0x7

    const-string v0, "PC.SENuNLHAU"

    const-string v0, "PUSH.CHANNEL"

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    const/16 v1, 0x64

    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-virtual {p2, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v2

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x3

    const-string v3, "dcaqI"

    const/4 v10, 0x4

    const-string v3, "capcd"

    const-string v3, "accId"

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x2

    const-wide/16 v4, 0x0

    const/4 v10, 0x1

    const-wide/16 v4, 0x0

    const-wide/16 v4, 0x0

    const/4 v10, 0x0

    invoke-virtual {p2, v3, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v6

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    invoke-static {p1}, Lcom/tencent/android/tpush/XGPushConfig;->getAccessidList(Landroid/content/Context;)Ljava/util/List;

    move-result-object v3

    const/4 v10, 0x4

    const/4 v9, 0x3

    if-eqz v3, :cond_2

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-interface {v3}, Ljava/util/List;->size()I

    move-result v8

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x4

    if-lez v8, :cond_2

    const/4 v10, 0x7

    const/4 v9, 0x1

    const/4 v10, 0x4

    invoke-static {v6, v7}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v6

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    invoke-interface {v3, v6}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-eqz v3, :cond_1

    const/4 v9, 0x4

    move v10, v9

    if-eq v2, v1, :cond_0

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x3

    const/16 v1, 0x65

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x0

    if-eq v2, v1, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    const/16 v1, 0x63

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x6

    if-ne v2, v1, :cond_1

    :cond_0
    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    new-instance v0, Lcom/tencent/android/tpush/XGPushClickedResult;

    const/4 v10, 0x4

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGPushClickedResult;-><init>()V

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {v0, p2}, Lcom/tencent/android/tpush/XGPushClickedResult;->parseIntent(Landroid/content/Intent;)V

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onNotificationClickedResult(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushClickedResult;)V

    const/4 v10, 0x3

    goto/16 :goto_0

    :cond_1
    const/4 v10, 0x0

    const/4 v9, 0x5

    new-instance v1, Lcom/tencent/android/tpush/XGPushClickedResult;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x5

    invoke-direct {v1}, Lcom/tencent/android/tpush/XGPushClickedResult;-><init>()V

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    const-string v2, "cqenont"

    const-string/jumbo v2, "ncsetno"

    const/4 v10, 0x0

    const-string v2, "etsnonc"

    const-string v2, "content"

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    iput-object v2, v1, Lcom/tencent/android/tpush/XGPushClickedResult;->content:Ljava/lang/String;

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x3

    const-string/jumbo v2, "mttml"

    const-string/jumbo v2, "telmt"

    const-string/jumbo v2, "title"

    const/4 v10, 0x3

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v2

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x5

    iput-object v2, v1, Lcom/tencent/android/tpush/XGPushClickedResult;->title:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x5

    const-string/jumbo v2, "on_mocsctnoeou"

    const-string v2, "cc_ootuostnenm"

    const/4 v10, 0x0

    const-string/jumbo v2, "u_onobsmtcenct"

    const-string v2, "custom_content"

    const/4 v10, 0x5

    const/4 v9, 0x1

    const/4 v10, 0x2

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v3

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x0

    iput-object v3, v1, Lcom/tencent/android/tpush/XGPushClickedResult;->customContent:Ljava/lang/String;

    const/4 v9, 0x4

    and-int/2addr v10, v9

    const/4 v3, 0x0

    shl-int/2addr v10, v3

    const/4 v9, 0x0

    or-int/2addr v10, v9

    invoke-virtual {p2, v0, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x0

    const/4 v10, 0x5

    iput v0, v1, Lcom/tencent/android/tpush/XGPushClickedResult;->pushChannel:I

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x1

    const-string/jumbo v0, "ucinbt"

    const-string/jumbo v0, "ticnab"

    const/4 v10, 0x0

    const-string v0, "cpinta"

    const-string v0, "action"

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x2

    invoke-virtual {p2, v0, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x4

    iput v0, v1, Lcom/tencent/android/tpush/XGPushClickedResult;->actionType:I

    const/4 v10, 0x4

    const/4 v9, 0x3

    const/4 v10, 0x6

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x7

    iput-object v0, v1, Lcom/tencent/android/tpush/XGPushClickedResult;->customContent:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x5

    const-string/jumbo v0, "msgId"

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x6

    invoke-virtual {p2, v0, v4, v5}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v2

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x2

    iput-wide v2, v1, Lcom/tencent/android/tpush/XGPushClickedResult;->msgId:J

    const/4 v10, 0x5

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v9, 0x3

    const/4 v9, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x6

    const-string/jumbo v2, "notificationActionType"

    const/4 v10, 0x1

    const/4 v9, 0x0

    const/4 v10, 0x1

    invoke-virtual {p2, v2, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x3

    iput v0, v1, Lcom/tencent/android/tpush/XGPushClickedResult;->notificationActionType:I

    const/4 v10, 0x1

    const/4 v9, 0x2

    const/4 v10, 0x5

    const-string/jumbo v0, "qcvitiat"

    const-string v0, "civtitua"

    const/4 v10, 0x1

    const-string v0, "icstavit"

    const-string v0, "activity"

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x7

    iput-object v0, v1, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    const/4 v10, 0x3

    const-string v0, "dtImppmelt"

    const-string v0, "Ipttaedplm"

    const/4 v10, 0x2

    const-string v0, "eelaodImpt"

    const-string/jumbo v0, "templateId"

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x7

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x7

    iput-object v0, v1, Lcom/tencent/android/tpush/XGPushClickedResult;->templateId:Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x1

    const-string v0, "caIerbq"

    const-string/jumbo v0, "rqaeIdc"

    const/4 v10, 0x5

    const-string/jumbo v0, "tIcdeau"

    const-string/jumbo v0, "traceId"

    const/4 v9, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v10, 0x7

    const/4 v9, 0x4

    const/4 v10, 0x3

    iput-object p2, v1, Lcom/tencent/android/tpush/XGPushClickedResult;->traceId:Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x4

    invoke-virtual {p0, p1, v1}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onNotificationClickedResult(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushClickedResult;)V

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x1

    goto :goto_0

    :cond_2
    const/4 v10, 0x6

    const/4 v9, 0x2

    const/4 v10, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v10, 0x3

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x1

    move v10, v9

    const-string p2, " cisasIpLstce"

    const-string p2, "dtsisecacL Is"

    const/4 v10, 0x1

    const-string p2, "ILdcas sqicts"

    const-string p2, "accessIdList "

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    invoke-virtual {p1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const-string p2, "dascclam oc eis "

    const-string p2, " admlacc o icsle"

    const/4 v10, 0x7

    const-string p2, "adcmsiso e lacc "

    const-string p2, " local accessid "

    const/4 v10, 0x3

    const/4 v9, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p1, v6, v7}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x0

    const-string/jumbo p2, "scaioBesXrvhuReGeP"

    const-string p2, "XGPushBaseReceiver"

    const/4 v10, 0x0

    const/4 v9, 0x7

    const/4 v10, 0x4

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x6

    const/4 v10, 0x6

    const-string/jumbo p1, "mugpvbsi go"

    const-string/jumbo p1, "ivpuog esgm"

    const/4 v10, 0x4

    const-string p1, " gmiegup vs"

    const-string p1, "give up msg"

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x7

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    :goto_0
    const/4 v10, 0x0

    return-void
.end method

.method private d(Landroid/content/Context;Landroid/content/Intent;I)V
    .locals 6

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x7

    const-string/jumbo v0, "pgeamta"

    const-string v0, "egamtba"

    const/4 v5, 0x6

    const-string v0, "eqtgaNm"

    const-string/jumbo v0, "tagName"

    const/4 v5, 0x6

    const/4 v4, 0x2

    const/4 v5, 0x4

    invoke-virtual {p2, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string v1, "aasgltF"

    const-string/jumbo v1, "tlFaagu"

    const/4 v5, 0x0

    const-string v1, "atgmalF"

    const-string/jumbo v1, "tagFlag"

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v2, -0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x2

    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    const/4 v5, 0x2

    const-string v2, "eOaaomNpprggee"

    const-string v2, "egmrpNOpeaaage"

    const/4 v5, 0x0

    const-string v2, "eegOtbNpeaaamr"

    const-string/jumbo v2, "tagOperageName"

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x6

    invoke-virtual {p2, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object p2

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x1

    const/16 v2, 0x8

    const/4 v5, 0x6

    if-ne v1, v2, :cond_0

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-virtual {p0, p1, p3, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onDeleteTagResult(Landroid/content/Context;ILjava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x4

    goto/16 :goto_2

    :cond_0
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v3

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    if-nez v3, :cond_5

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x6

    const/4 v3, 0x1

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x4

    if-eq v1, v3, :cond_4

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x2

    if-eq v1, v3, :cond_4

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/4 v4, 0x5

    if-ne v1, v3, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x4

    goto :goto_1

    :cond_1
    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    if-eq v1, v3, :cond_3

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    xor-int/2addr v5, v4

    if-eq v1, v3, :cond_3

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-ne v1, v2, :cond_2

    const/4 v5, 0x7

    goto :goto_0

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x1

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string p2, "844e77uu9f5/c86/7/0uu8/55674b8bf/u/0//uuu0b79u7u9u7a1q7/1efb"

    const-string p2, "bub/e5a7qbu7u1uu0/078b01/eff476//56/u//u48/9f75c8u7994/77u8u"

    const-string p2, "75u7e09p89fub4ubuu/e718a5/7uu/7/u/6//b/1fb7f674//u9u586c8704"

    const-string/jumbo p2, "\u9519\u8bef\u7684\u6807\u7b7e\u5904\u7406\u7c7b\u578b\uff1a"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-virtual {p1, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    move v5, v4

    const-string p2, "7/s74a,0q0/d865b/u7 u1fueu"

    const-string p2, " ,s7ue0uf8//7ab0/u5467fdu1"

    const/4 v5, 0x4

    const-string p2, "f1sf/d77euu0u/4au6//8,b57 "

    const-string p2, " ,\u6807\u7b7e\u540d\uff1a"

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v5, 0x4

    const/4 v4, 0x6

    const/4 v5, 0x1

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x4

    const-string p2, "PcBmRumssvXheeeiea"

    const-string p2, "csvmGuXhPBisaeReee"

    const/4 v5, 0x3

    const-string/jumbo p2, "isueoaehGBrveXecsR"

    const-string p2, "XGPushBaseReceiver"

    const/4 v5, 0x4

    const/4 v4, 0x4

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x0

    goto :goto_2

    :cond_3
    :goto_0
    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    invoke-virtual {p0, p1, p3, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onDeleteTagResult(Landroid/content/Context;ILjava/lang/String;)V

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x5

    goto :goto_2

    :cond_4
    :goto_1
    const/4 v4, 0x4

    const/4 v5, 0x0

    invoke-virtual {p0, p1, p3, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onSetTagResult(Landroid/content/Context;ILjava/lang/String;)V

    :cond_5
    :goto_2
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x5

    return-void
.end method

.method private e(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x5

    new-instance v0, Lcom/tencent/android/tpush/data/MessageId;

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x4

    invoke-direct {v0}, Lcom/tencent/android/tpush/data/MessageId;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string v1, "bIomg"

    const-string/jumbo v1, "mgdIo"

    const/4 v7, 0x5

    const-string v1, "gusmd"

    const-string/jumbo v1, "msgId"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x4

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-virtual {p2, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x7

    iput-wide v4, v0, Lcom/tencent/android/tpush/data/MessageId;->id:J

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x2

    const/4 v1, 0x0

    const/4 v7, 0x4

    iput-short v1, v0, Lcom/tencent/android/tpush/data/MessageId;->isAck:S

    const/4 v7, 0x2

    const/4 v6, 0x5

    const-string v4, "bapdI"

    const-string v4, "bIacd"

    const/4 v7, 0x5

    const-string v4, "ccaqd"

    const-string v4, "accId"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x1

    invoke-virtual {p2, v4, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-wide v4, v0, Lcom/tencent/android/tpush/data/MessageId;->accessId:J

    const/4 v6, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x6

    const-string/jumbo v4, "o_srastxeu"

    const-string/jumbo v4, "trahe_uoxs"

    const/4 v7, 0x3

    const-string/jumbo v4, "stemxohtar"

    const-string v4, "extra_host"

    const/4 v7, 0x6

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-virtual {p2, v4, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    iput-wide v4, v0, Lcom/tencent/android/tpush/data/MessageId;->host:J

    const/4 v7, 0x5

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string/jumbo v4, "xptaortp_r"

    const-string/jumbo v4, "xttar_rpop"

    const/4 v7, 0x5

    const-string v4, "axe_pborrt"

    const-string v4, "extra_port"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p2, v4, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x3

    iput v4, v0, Lcom/tencent/android/tpush/data/MessageId;->port:I

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x0

    const-string/jumbo v4, "r_tctaxpqa"

    const/4 v7, 0x0

    const-string v4, "ctp_eautxa"

    const-string v4, "extra_pact"

    const/4 v7, 0x4

    const/4 v6, 0x3

    const/4 v7, 0x4

    invoke-virtual {p2, v4, v1}, Landroid/content/Intent;->getByteExtra(Ljava/lang/String;B)B

    move-result v1

    const/4 v7, 0x6

    const/4 v6, 0x2

    const/4 v7, 0x1

    iput-byte v1, v0, Lcom/tencent/android/tpush/data/MessageId;->pact:B

    const/4 v6, 0x0

    move v7, v6

    invoke-static {p1}, Lcom/tencent/tpns/dataacquisition/DeviceInfos;->getNetworkType(Landroid/content/Context;)B

    move-result v1

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    iput-byte v1, v0, Lcom/tencent/android/tpush/data/MessageId;->apn:B

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {p1}, Lcom/tencent/android/tpush/common/j;->p(Landroid/content/Context;)B

    move-result v1

    const/4 v7, 0x1

    const/4 v6, 0x0

    iput-byte v1, v0, Lcom/tencent/android/tpush/data/MessageId;->isp:B

    const/4 v6, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x4

    const-string/jumbo v1, "kvsmaegpNr"

    const-string/jumbo v1, "maskvreNgs"

    const/4 v7, 0x5

    const-string/jumbo v1, "sNavrmPgqk"

    const-string/jumbo v1, "svrPkgName"

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x7

    invoke-virtual {p2, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x6

    iput-object v1, v0, Lcom/tencent/android/tpush/data/MessageId;->serviceHost:Ljava/lang/String;

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v4

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x5

    iput-wide v4, v0, Lcom/tencent/android/tpush/data/MessageId;->receivedTime:J

    const/4 v7, 0x1

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x2

    iput-object v1, v0, Lcom/tencent/android/tpush/data/MessageId;->pkgName:Ljava/lang/String;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x5

    const-string v1, "Misbdumss"

    const-string/jumbo v1, "isgmdsuMb"

    const/4 v7, 0x1

    const-string v1, "IgMmsdsub"

    const-string v1, "busiMsgId"

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p2, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x1

    iput-wide v4, v0, Lcom/tencent/android/tpush/data/MessageId;->busiMsgId:J

    const/4 v7, 0x0

    const/4 v6, 0x1

    const-string/jumbo v1, "tsetoasimm"

    const/4 v7, 0x6

    const-string/jumbo v1, "psemomistt"

    const-string/jumbo v1, "timestamps"

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    invoke-virtual {p2, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x0

    iput-wide v4, v0, Lcom/tencent/android/tpush/data/MessageId;->timestamp:J

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x4

    const-string/jumbo v1, "teyp"

    const-string/jumbo v1, "ypte"

    const/4 v7, 0x1

    const-string/jumbo v1, "tepy"

    const-string/jumbo v1, "type"

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x2

    invoke-virtual {p2, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v4

    const/4 v7, 0x2

    const/4 v6, 0x6

    const/4 v7, 0x4

    iput-wide v4, v0, Lcom/tencent/android/tpush/data/MessageId;->msgType:J

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    const-string/jumbo v1, "umklbbPi"

    const-string v1, "Puglibmk"

    const/4 v7, 0x3

    const-string/jumbo v1, "lutmPguk"

    const-string/jumbo v1, "multiPkg"

    const/4 v7, 0x7

    const/4 v6, 0x2

    const/4 v7, 0x2

    invoke-virtual {p2, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v1

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x6

    iput-wide v1, v0, Lcom/tencent/android/tpush/data/MessageId;->multiPkg:J

    const/4 v7, 0x4

    new-instance v1, Ljava/text/SimpleDateFormat;

    const/4 v7, 0x0

    const/4 v6, 0x6

    const/4 v7, 0x5

    const-string/jumbo v2, "yMuydyMp"

    const-string v2, "dyyyMMud"

    const/4 v7, 0x2

    const-string/jumbo v2, "qdydyyyM"

    const-string/jumbo v2, "yyyyMMdd"

    const/4 v7, 0x6

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {v1, v2}, Ljava/text/SimpleDateFormat;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x3

    const/4 v6, 0x6

    const/4 v7, 0x0

    new-instance v2, Ljava/util/Date;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x0

    invoke-direct {v2}, Ljava/util/Date;-><init>()V

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {v1, v2}, Ljava/text/DateFormat;->format(Ljava/util/Date;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x5

    const/4 v6, 0x0

    const/4 v7, 0x1

    iput-object v1, v0, Lcom/tencent/android/tpush/data/MessageId;->date:Ljava/lang/String;

    const/4 v7, 0x7

    const-string/jumbo v1, "opsup_ig"

    const-string/jumbo v1, "u_prigop"

    const/4 v7, 0x7

    const-string/jumbo v1, "pogmrdi_"

    const-string v1, "group_id"

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x5

    invoke-virtual {p2, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v7, 0x6

    const/4 v6, 0x1

    const/4 v7, 0x2

    if-nez v2, :cond_0

    const/4 v7, 0x6

    const/4 v6, 0x4

    iput-object v1, v0, Lcom/tencent/android/tpush/data/MessageId;->groupId:Ljava/lang/String;

    :cond_0
    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    const-string v1, "adMeosesg"

    const-string v1, "agsesdeMq"

    const/4 v7, 0x6

    const-string v1, "edagsbesM"

    const-string v1, "MessageId"

    const/4 v7, 0x4

    const/4 v6, 0x7

    const/4 v7, 0x6

    invoke-virtual {p2, v1, v0}, Landroid/content/Intent;->putExtra(Ljava/lang/String;Ljava/io/Serializable;)Landroid/content/Intent;

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x2

    new-instance v0, Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x4

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x2

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v7, 0x3

    const/4 v6, 0x1

    const/4 v7, 0x0

    invoke-virtual {p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x7

    const/4 v7, 0x4

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x6

    const-string/jumbo v2, "opniMduc.x.eintneAo.saamrg..4vKd_i.nVStcC.tc"

    const-string v2, "Mps.gv.cx.St_netKa4na.miV.ocedGdit.r.AconnCi"

    const/4 v7, 0x5

    const-string v2, "com.tencent.android.xg.vip.action.MSG_ACK.V4"

    const/4 v7, 0x4

    const/4 v6, 0x2

    const/4 v7, 0x0

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    and-int/2addr v7, v6

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v7, 0x0

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v7, 0x7

    invoke-virtual {v0, p2}, Landroid/content/Intent;->putExtras(Landroid/content/Intent;)Landroid/content/Intent;

    const/4 v7, 0x7

    const/4 v6, 0x6

    const/4 v7, 0x4

    invoke-static {p1, v0}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x2

    return-void
.end method

.method private e(Landroid/content/Context;Landroid/content/Intent;I)V
    .locals 9

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x7

    new-instance v0, Lcom/tencent/android/tpush/XGPushRegisterResult;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x4

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGPushRegisterResult;-><init>()V

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x2

    const-string/jumbo v1, "roentlrpeurCrdoimmloFtgo"

    const-string/jumbo v1, "rdCmeroFnmrorogCeoultitl"

    const/4 v8, 0x1

    const-string/jumbo v1, "ugoCleeCqlotionrotrdsFrm"

    const-string/jumbo v1, "registerFromCloudControl"

    const/4 v8, 0x4

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v2, 0x0

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x3

    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result v1

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x7

    if-nez v1, :cond_2

    const/4 v8, 0x3

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string v1, "CosH.NNHPUES"

    const-string v1, "HLSCoPHUNN.E"

    const/4 v8, 0x4

    const-string v1, "UHNm.SANCPLE"

    const-string v1, "PUSH.CHANNEL"

    const/4 v8, 0x4

    const/16 v3, 0x64

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x7

    invoke-virtual {p2, v1, v3}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v4

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x6

    if-ne v4, v3, :cond_0

    const/4 v8, 0x6

    const/4 v7, 0x7

    const/4 v8, 0x6

    invoke-virtual {v0, p2}, Lcom/tencent/android/tpush/XGPushRegisterResult;->parseIntent(Landroid/content/Intent;)V

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    goto/16 :goto_0

    :cond_0
    const/4 v8, 0x7

    const/4 v7, 0x5

    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x2

    iput v1, v0, Lcom/tencent/android/tpush/XGPushRegisterResult;->h:I

    const/4 v8, 0x0

    const/4 v7, 0x2

    const/4 v8, 0x1

    const-string v1, "e_pnoshobtkth_ro"

    const-string/jumbo v1, "k_e_rbpsothtnouh"

    const/4 v8, 0x3

    const-string/jumbo v1, "rpeu_bhetthko_no"

    const-string/jumbo v1, "other_push_token"

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x4

    invoke-virtual {p2, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x6

    iput-object v1, v0, Lcom/tencent/android/tpush/XGPushRegisterResult;->g:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x3

    const-string v1, "ATTU.HuNuOP..UOEEKNSPT"

    const-string v1, "E.HUSPuA.DETT.ONKTNUOP"

    const/4 v8, 0x1

    const-string v1, "OUUS.ONpE.TPTTDEPA.HNK"

    const-string v1, "TPUSH.NOT.UPDATE.TOKEN"

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x6

    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result p2

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x6

    if-nez p3, :cond_1

    const/4 v8, 0x1

    const/4 v7, 0x4

    const/4 v8, 0x7

    iget-object v1, v0, Lcom/tencent/android/tpush/XGPushRegisterResult;->g:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v1

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x0

    if-nez v1, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x2

    const/4 v8, 0x1

    if-nez p2, :cond_1

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v8, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x6

    sget-wide v3, Lcom/tencent/android/tpush/XGPushBaseReceiver;->b:J

    const/4 v8, 0x7

    const/4 v7, 0x0

    const/4 v8, 0x0

    sub-long v3, v1, v3

    const/4 v8, 0x5

    const/4 v7, 0x6

    const/4 v8, 0x4

    const-wide/16 v5, 0x2710

    const-wide/16 v5, 0x2710

    const/4 v8, 0x3

    const-wide/16 v5, 0x2710

    const-wide/16 v5, 0x2710

    const/4 v7, 0x2

    or-int/2addr v8, v7

    cmp-long p2, v3, v5

    const/4 v8, 0x7

    const/4 v7, 0x6

    if-lez p2, :cond_1

    const/4 v8, 0x7

    sput-wide v1, Lcom/tencent/android/tpush/XGPushBaseReceiver;->b:J

    const/4 v7, 0x6

    const/4 v7, 0x4

    const/4 v8, 0x7

    invoke-static {p1}, Lcom/tencent/android/tpush/d/b;->a(Landroid/content/Context;)V

    :cond_1
    :goto_0
    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {p0, p1, p3, v0}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onRegisterResult(Landroid/content/Context;ILcom/tencent/android/tpush/XGPushRegisterResult;)V

    :cond_2
    const/4 v8, 0x2

    return-void
.end method

.method private f(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 6

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    new-instance v0, Lcom/tencent/android/tpush/XGPushTextMessage;

    const/4 v5, 0x6

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGPushTextMessage;-><init>()V

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x7

    const-string/jumbo v1, "pmIqg"

    const-string/jumbo v1, "sIpgm"

    const/4 v5, 0x5

    const-string/jumbo v1, "mgsds"

    const-string/jumbo v1, "msgId"

    const/4 v5, 0x7

    const/4 v4, 0x5

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x3

    const-wide/16 v2, 0x0

    const-wide/16 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-virtual {p2, v1, v2, v3}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x0

    iput-wide v1, v0, Lcom/tencent/android/tpush/XGPushTextMessage;->a:J

    const/4 v5, 0x5

    const/4 v4, 0x0

    const-string v1, "HPNmA.SNLEUC"

    const-string v1, "PUSH.CHANNEL"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x0

    const/16 v2, 0x64

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x1

    invoke-virtual {p2, v1, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v1

    const/4 v5, 0x1

    const/4 v4, 0x6

    iput v1, v0, Lcom/tencent/android/tpush/XGPushTextMessage;->e:I

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v1, "eilto"

    const-string/jumbo v1, "litqe"

    const/4 v5, 0x7

    const-string v1, "bietl"

    const-string/jumbo v1, "title"

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x7

    invoke-virtual {p2, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {v1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x5

    iput-object v1, v0, Lcom/tencent/android/tpush/XGPushTextMessage;->b:Ljava/lang/String;

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    const-string/jumbo v1, "stetnnu"

    const-string/jumbo v1, "ttsennc"

    const-string/jumbo v1, "ptoctne"

    const-string v1, "content"

    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x1

    invoke-virtual {p2, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x0

    const/4 v5, 0x1

    iput-object v1, v0, Lcom/tencent/android/tpush/XGPushTextMessage;->c:Ljava/lang/String;

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x0

    const-string/jumbo v1, "otmocutsqcnmt_"

    const-string/jumbo v1, "usnmt_ttcmeooc"

    const/4 v5, 0x7

    const-string v1, "cosutntecsot_n"

    const-string v1, "custom_content"

    const/4 v5, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p2, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {v1}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x4

    iput-object v1, v0, Lcom/tencent/android/tpush/XGPushTextMessage;->d:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x2

    const/4 v5, 0x6

    const-string/jumbo v1, "laempmoetd"

    const-string v1, "aedeotmlpt"

    const/4 v5, 0x6

    const-string v1, "eepmoIaltd"

    const-string/jumbo v1, "templateId"

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-virtual {p2, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x6

    const/4 v4, 0x5

    iput-object v1, v0, Lcom/tencent/android/tpush/XGPushTextMessage;->f:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    const-string/jumbo v1, "tIdebba"

    const-string v1, "Iertdba"

    const/4 v5, 0x5

    const-string/jumbo v1, "tceIdau"

    const-string/jumbo v1, "traceId"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-virtual {p2, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x5

    iput-object v1, v0, Lcom/tencent/android/tpush/XGPushTextMessage;->g:Ljava/lang/String;

    const/4 v5, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, p2}, Lcom/tencent/android/tpush/XGPushTextMessage;->a(Landroid/content/Intent;)V

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-virtual {p0, p1, v0}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onInMsgReceivedResult(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushTextMessage;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x5

    return-void
.end method

.method private g(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x3

    new-instance v0, Lcom/tencent/android/tpush/XGPushShowedResult;

    const/4 v2, 0x7

    const/4 v1, 0x1

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGPushShowedResult;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-virtual {v0, p2}, Lcom/tencent/android/tpush/XGPushShowedResult;->parseIntent(Landroid/content/Intent;)V

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x0

    invoke-virtual {p0, p1, v0}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onInMsgShowedResult(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushShowedResult;)V

    const/4 v1, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x3

    return-void
.end method

.method private h(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    new-instance v0, Lcom/tencent/android/tpush/XGPushClickedResult;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {v0}, Lcom/tencent/android/tpush/XGPushClickedResult;-><init>()V

    const/4 v1, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0, p2}, Lcom/tencent/android/tpush/XGPushClickedResult;->parseIntent(Landroid/content/Intent;)V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {p0, p1, v0}, Lcom/tencent/android/tpush/XGPushBaseReceiver;->onInMsgClickedResult(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushClickedResult;)V

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x0

    return-void
.end method


# virtual methods
.method public abstract onDeleteAccountResult(Landroid/content/Context;ILjava/lang/String;)V
.end method

.method public abstract onDeleteAttributeResult(Landroid/content/Context;ILjava/lang/String;)V
.end method

.method public abstract onDeleteTagResult(Landroid/content/Context;ILjava/lang/String;)V
.end method

.method public onInMsgClickedResult(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushClickedResult;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method public onInMsgReceivedResult(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushTextMessage;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public onInMsgShowedResult(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushShowedResult;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method

.method public abstract onNotificationClickedResult(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushClickedResult;)V
.end method

.method public abstract onNotificationShowedResult(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushShowedResult;)V
.end method

.method public abstract onQueryTagsResult(Landroid/content/Context;ILjava/lang/String;Ljava/lang/String;)V
.end method

.method public final onReceive(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    if-eqz p1, :cond_0

    const/4 v2, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    if-eqz p2, :cond_0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->getInstance()Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;

    move-result-object v0

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x5

    new-instance v1, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v1, p0, p1, p2}, Lcom/tencent/android/tpush/XGPushBaseReceiver$1;-><init>(Lcom/tencent/android/tpush/XGPushBaseReceiver;Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-virtual {v0, v1}, Lcom/tencent/tpns/baseapi/base/util/CommonWorkingThread;->execute(Lcom/tencent/tpns/baseapi/base/util/TTask;)Z

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x2

    return-void
.end method

.method public abstract onRegisterResult(Landroid/content/Context;ILcom/tencent/android/tpush/XGPushRegisterResult;)V
.end method

.method public abstract onSetAccountResult(Landroid/content/Context;ILjava/lang/String;)V
.end method

.method public abstract onSetAttributeResult(Landroid/content/Context;ILjava/lang/String;)V
.end method

.method public abstract onSetTagResult(Landroid/content/Context;ILjava/lang/String;)V
.end method

.method public abstract onTextMessage(Landroid/content/Context;Lcom/tencent/android/tpush/XGPushTextMessage;)V
.end method

.method public abstract onUnregisterResult(Landroid/content/Context;I)V
.end method
