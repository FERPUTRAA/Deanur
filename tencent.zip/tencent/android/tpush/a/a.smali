.class public Lcom/tencent/android/tpush/a/a;
.super Ljava/lang/Object;


# static fields
.field private static volatile a:Lcom/tencent/android/tpush/a/a;


# instance fields
.field private b:Landroid/content/Context;

.field private c:Landroid/content/pm/PackageManager;

.field private d:Ljava/util/HashMap;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/HashMap<",
            "Ljava/lang/String;",
            "Lcom/tencent/android/tpush/a/b;",
            ">;"
        }
    .end annotation
.end field

.field private e:Ljava/util/Map;
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "Ljava/util/Map<",
            "Ljava/lang/String;",
            "Ljava/lang/Long;",
            ">;"
        }
    .end annotation
.end field


# direct methods
.method static constructor <clinit>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x3

    const/4 v1, 0x3

    return-void
.end method

.method private constructor <init>(Landroid/content/Context;)V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x0

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/a/a;->b:Landroid/content/Context;

    const/4 v2, 0x5

    const/4 v1, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/a/a;->c:Landroid/content/pm/PackageManager;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x2

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/a/a;->d:Ljava/util/HashMap;

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x1

    new-instance v0, Ljava/util/HashMap;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-direct {v0}, Ljava/util/HashMap;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/a/a;->e:Ljava/util/Map;

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/a/a;->b:Landroid/content/Context;

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-virtual {p1}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/a/a;->c:Landroid/content/pm/PackageManager;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    return-void
.end method

.method public static a(Landroid/content/Context;)Lcom/tencent/android/tpush/a/a;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "@ls@os K~i@ @ai~@~~~ @o~~@~  ~~d~M@ v ~r l~y c @b @~b o@u . /~~@@b@i~~-@@m/ ~to4@1o ~f~~n@St @@o"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    sget-object v0, Lcom/tencent/android/tpush/a/a;->a:Lcom/tencent/android/tpush/a/a;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-nez v0, :cond_1

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x3

    const-class v0, Lcom/tencent/android/tpush/a/a;

    const/4 v3, 0x1

    monitor-enter v0

    :try_start_0
    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    sget-object v1, Lcom/tencent/android/tpush/a/a;->a:Lcom/tencent/android/tpush/a/a;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x6

    new-instance v1, Lcom/tencent/android/tpush/a/a;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-direct {v1, p0}, Lcom/tencent/android/tpush/a/a;-><init>(Landroid/content/Context;)V

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x7

    sput-object v1, Lcom/tencent/android/tpush/a/a;->a:Lcom/tencent/android/tpush/a/a;

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x1

    monitor-exit v0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x2

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v3, 0x1

    const/4 v2, 0x3

    monitor-exit v0
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x1

    throw p0

    :cond_1
    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x7

    sget-object p0, Lcom/tencent/android/tpush/a/a;->a:Lcom/tencent/android/tpush/a/a;

    const/4 v2, 0x1

    shr-int/2addr v3, v2

    return-object p0
.end method

.method private c(Ljava/lang/String;)V
    .locals 7

    const/4 v5, 0x3

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/a/a;->e:Ljava/util/Map;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-interface {v0, p1}, Ljava/util/Map;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x6

    check-cast v0, Ljava/lang/Long;

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x4

    if-eqz v0, :cond_0

    const/4 v6, 0x6

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v1

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v0}, Ljava/lang/Long;->longValue()J

    move-result-wide v3

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    cmp-long v0, v1, v3

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    if-lez v0, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x1

    return-void

    :cond_0
    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {p0, p1}, Lcom/tencent/android/tpush/a/a;->b(Ljava/lang/String;)Lcom/tencent/android/tpush/a/b;

    move-result-object v0

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x0

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x3

    const-string/jumbo v2, "npAmIpsfAp cUe:papryitkp"

    const-string/jumbo v2, "rpsfippnyAkcIa:pApWpUe t"

    const/4 v6, 0x5

    const-string/jumbo v2, "ypkAopopUppI ptrineaAW:f"

    const-string/jumbo v2, "tryWakeUpApp ipcAppInfo:"

    const/4 v6, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x6

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x0

    const-string v2, "gnImMbPrCa"

    const-string v2, "MrnmIePagC"

    const/4 v6, 0x2

    const-string v2, "anrCMaueIP"

    const-string v2, "IPCManager"

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    if-eqz v0, :cond_2

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpush/a/b;->a()Ljava/util/ArrayList;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x5

    const-string/jumbo v3, "poakoAvpWyLdtfnU:rpspI ipreeto"

    const-string/jumbo v3, "krpLoWe yrnopptatfdIsp:UvrAeoi"

    const-string/jumbo v3, "tryWakeUpApp providerInfoList:"

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x6

    const/4 v5, 0x7

    const/4 v6, 0x7

    invoke-static {v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    if-eqz v0, :cond_2

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_1
    :goto_0
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x3

    if-eqz v1, :cond_2

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v1

    const/4 v6, 0x5

    const/4 v5, 0x6

    check-cast v1, Landroid/content/pm/ProviderInfo;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-boolean v3, v1, Landroid/content/pm/ProviderInfo;->exported:Z

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x2

    if-eqz v3, :cond_1

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v1, v1, Landroid/content/pm/ProviderInfo;->authority:Ljava/lang/String;

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x6

    const-string/jumbo v4, "nbeotn/cq/"

    const-string v4, "/nn/obet:c"

    const/4 v6, 0x4

    const-string v4, ":oset//ncn"

    const-string v4, "content://"

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x2

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x5

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x0

    invoke-static {v1}, Landroid/net/Uri;->parse(Ljava/lang/String;)Landroid/net/Uri;

    move-result-object v1

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    new-instance v3, Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v6, 0x6

    const-string v4, "AkumyrpiU:ep atuW"

    const-string v4, "epUAptuk ayurWp:i"

    const/4 v6, 0x3

    const-string/jumbo v4, "purpokWUiep:rA ya"

    const-string/jumbo v4, "tryWakeUpApp uri:"

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-virtual {v3, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {v2, v3}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x2

    iget-object v3, p0, Lcom/tencent/android/tpush/a/a;->b:Landroid/content/Context;

    const/4 v5, 0x6

    move v6, v5

    invoke-virtual {v3}, Landroid/content/Context;->getContentResolver()Landroid/content/ContentResolver;

    move-result-object v3

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x3

    invoke-virtual {v3, v1}, Landroid/content/ContentResolver;->getType(Landroid/net/Uri;)Ljava/lang/String;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x2

    goto/16 :goto_0

    :cond_2
    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x7

    const-wide/32 v2, 0x36ee80

    const-wide/32 v2, 0x36ee80

    const-wide/32 v2, 0x36ee80

    const-wide/32 v2, 0x36ee80

    const/4 v6, 0x4

    add-long/2addr v0, v2

    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-static {v0, v1}, Ljava/lang/Long;->valueOf(J)Ljava/lang/Long;

    move-result-object v0

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/a/a;->e:Ljava/util/Map;

    const/4 v6, 0x3

    const/4 v5, 0x0

    const/4 v6, 0x2

    invoke-interface {v1, p1, v0}, Ljava/util/Map;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v6, 0x3

    return-void
.end method

.method private d()Z
    .locals 9

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/a/a;->b:Landroid/content/Context;

    const/4 v8, 0x5

    const/4 v7, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/service/a/a;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/service/a/a;

    move-result-object v0

    const/4 v8, 0x7

    const/4 v7, 0x4

    const/4 v8, 0x7

    iget-object v0, v0, Lcom/tencent/android/tpush/service/a/a;->I:Ljava/lang/String;

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x6

    sget-object v1, Landroid/os/Build;->MANUFACTURER:Ljava/lang/String;

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    new-instance v2, Ljava/lang/StringBuilder;

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x2

    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v8, 0x0

    const/4 v7, 0x4

    const-string v3, "etr:abkw"

    const-string v3, "a:tkwrep"

    const/4 v8, 0x3

    const-string/jumbo v3, "taCwreuk"

    const-string/jumbo v3, "wakeCtr:"

    const/4 v8, 0x4

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v7, 0x2

    xor-int/2addr v8, v7

    invoke-virtual {v2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    const/4 v7, 0x6

    const/4 v8, 0x3

    const-string/jumbo v3, "mf,:"

    const-string v3, "fm:,"

    const/4 v8, 0x5

    const-string v3, ":f,m"

    const-string v3, ",mf:"

    const/4 v8, 0x4

    const/4 v7, 0x6

    const/4 v8, 0x0

    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x0

    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    const/4 v7, 0x2

    const/4 v8, 0x0

    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v2

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x0

    const-string/jumbo v3, "nMPIegrpCa"

    const-string v3, "IPCManager"

    const/4 v8, 0x5

    const/4 v7, 0x2

    const/4 v8, 0x1

    invoke-static {v3, v2}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x4

    const/4 v8, 0x4

    const/4 v3, 0x0

    const/4 v8, 0x4

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-eqz v2, :cond_0

    const/4 v8, 0x4

    const/4 v7, 0x7

    const/4 v8, 0x4

    invoke-static {v1}, Lcom/tencent/android/tpush/common/j;->b(Ljava/lang/String;)Z

    move-result v2

    const/4 v8, 0x2

    const/4 v7, 0x0

    if-nez v2, :cond_2

    :cond_0
    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x2

    const-string v2, ","

    const-string v2, ","

    const/4 v8, 0x7

    const-string v2, ","

    const-string v2, ","

    const/4 v8, 0x2

    const/4 v7, 0x0

    const/4 v8, 0x5

    invoke-virtual {v0, v2}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v0

    const/4 v8, 0x0

    const/4 v7, 0x5

    const/4 v8, 0x2

    array-length v2, v0

    const/4 v8, 0x2

    const/4 v7, 0x7

    const/4 v8, 0x5

    move v4, v3

    move v4, v3

    const/4 v8, 0x4

    move v4, v3

    move v4, v3

    :goto_0
    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x3

    if-ge v4, v2, :cond_2

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x2

    aget-object v5, v0, v4

    const/4 v8, 0x5

    const/4 v7, 0x0

    const/4 v8, 0x7

    invoke-virtual {v5}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v5

    const/4 v8, 0x2

    const/4 v7, 0x3

    invoke-virtual {v1}, Ljava/lang/String;->toLowerCase()Ljava/lang/String;

    move-result-object v6

    const/4 v8, 0x6

    const/4 v7, 0x1

    const/4 v8, 0x7

    invoke-virtual {v5, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v5

    const/4 v8, 0x7

    const/4 v7, 0x5

    const/4 v8, 0x7

    if-eqz v5, :cond_1

    const/4 v8, 0x2

    const/4 v7, 0x6

    const/4 v8, 0x7

    const/4 v0, 0x1

    const/4 v8, 0x0

    return v0

    :cond_1
    const/4 v8, 0x7

    const/4 v7, 0x4

    add-int/lit8 v4, v4, 0x1

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x6

    goto :goto_0

    :cond_2
    const/4 v8, 0x2

    return v3
.end method


# virtual methods
.method public a()V
    .locals 5

    :try_start_0
    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/a/a;->b()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v1, "ePqCaMnaqr"

    const-string v1, "aPeMgraCqn"

    const/4 v4, 0x6

    const-string v1, "ansCrIPaMe"

    const-string v1, "IPCManager"

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string/jumbo v2, "niti"

    const-string/jumbo v2, "itni"

    const/4 v4, 0x2

    const-string/jumbo v2, "ntii"

    const-string/jumbo v2, "init"

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    return-void
.end method

.method public a(Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x4

    const-string v0, "CesMaPnaIg"

    const/4 v4, 0x3

    const-string v0, "gnrmMaIaPe"

    const-string v0, "IPCManager"

    :try_start_0
    const/4 v4, 0x7

    invoke-direct {p0}, Lcom/tencent/android/tpush/a/a;->d()Z

    move-result v1

    const/4 v4, 0x4

    const/4 v3, 0x7

    if-eqz v1, :cond_0

    const/4 v4, 0x2

    iget-object v1, p0, Lcom/tencent/android/tpush/a/a;->b:Landroid/content/Context;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-virtual {v1, p1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x4

    move v4, v3

    new-instance v1, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    invoke-direct {v1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v2, "WyAeoceUmepakaatgpaN rm:p"

    const-string v2, "e:AmrNagam pUcWpeepptayak"

    const/4 v4, 0x4

    const-string v2, "Agpe bmWaarkaaetyp:UppecN"

    const-string/jumbo v2, "tryWakeUpApp packageName:"

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Lcom/tencent/android/tpush/a/a;->c(Ljava/lang/String;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo v1, "oeppUWurykAt"

    const-string v1, "AtUropWakpey"

    const-string/jumbo v1, "ppepUarpAykW"

    const-string/jumbo v1, "tryWakeUpApp"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v0, v1, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-void
.end method

.method public b(Ljava/lang/String;)Lcom/tencent/android/tpush/a/b;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/a/a;->d:Ljava/util/HashMap;

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x3

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->containsKey(Ljava/lang/Object;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    if-nez v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-virtual {p0}, Lcom/tencent/android/tpush/a/a;->a()V

    :cond_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/a/a;->d:Ljava/util/HashMap;

    const/4 v2, 0x1

    const/4 v1, 0x3

    invoke-virtual {v0, p1}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x0

    check-cast p1, Lcom/tencent/android/tpush/a/b;

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-object p1
.end method

.method public b()V
    .locals 8

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x5

    const-string v0, "grnIPeMaqb"

    const-string/jumbo v0, "rPegabnaMI"

    const/4 v7, 0x0

    const-string v0, "easaCIrPnM"

    const-string v0, "IPCManager"

    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x4

    const-string/jumbo v1, "teomPviindtrrci snaiu "

    const-string/jumbo v1, "itadnrutirisvPoi ecno "

    const/4 v7, 0x2

    const-string v1, "action - initProviders"

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v7, 0x7

    const/4 v6, 0x3

    const/4 v7, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/a/a;->c:Landroid/content/pm/PackageManager;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x1

    const/4 v1, 0x0

    const/4 v6, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x4

    const/4 v2, 0x0

    const/4 v7, 0x5

    invoke-virtual {v0, v1, v2, v2}, Landroid/content/pm/PackageManager;->queryContentProviders(Ljava/lang/String;II)Ljava/util/List;

    move-result-object v0

    const/4 v7, 0x4

    const/4 v6, 0x4

    const/4 v7, 0x3

    invoke-virtual {p0}, Lcom/tencent/android/tpush/a/a;->c()Ljava/util/List;

    move-result-object v1

    const/4 v7, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x3

    if-eqz v0, :cond_3

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x6

    if-eqz v1, :cond_3

    invoke-interface {v0}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v0

    :cond_0
    :goto_0
    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x4

    invoke-interface {v0}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x0

    if-eqz v2, :cond_3

    const/4 v6, 0x2

    const/4 v7, 0x1

    invoke-interface {v0}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x2

    check-cast v2, Landroid/content/pm/ProviderInfo;

    const/4 v6, 0x0

    move v7, v6

    iget-object v3, v2, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    invoke-interface {v1, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    if-eqz v3, :cond_0

    const/4 v7, 0x7

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-boolean v3, v2, Landroid/content/pm/ProviderInfo;->exported:Z

    const/4 v7, 0x0

    const/4 v6, 0x7

    const/4 v7, 0x0

    if-eqz v3, :cond_0

    const/4 v6, 0x1

    move v7, v6

    iget-object v3, p0, Lcom/tencent/android/tpush/a/a;->d:Ljava/util/HashMap;

    const/4 v7, 0x3

    const/4 v6, 0x0

    const/4 v7, 0x3

    iget-object v4, v2, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    const/4 v6, 0x4

    move v7, v6

    invoke-virtual {v3, v4}, Ljava/util/HashMap;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v7, 0x2

    const/4 v6, 0x0

    const/4 v7, 0x0

    check-cast v3, Lcom/tencent/android/tpush/a/b;

    const/4 v7, 0x0

    const/4 v6, 0x1

    const/4 v7, 0x6

    if-nez v3, :cond_1

    const/4 v7, 0x6

    new-instance v3, Lcom/tencent/android/tpush/a/b;

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x7

    invoke-direct {v3}, Lcom/tencent/android/tpush/a/b;-><init>()V

    :cond_1
    const/4 v7, 0x7

    const/4 v6, 0x0

    const/4 v7, 0x1

    iget-object v4, v2, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x1

    invoke-virtual {v3, v4}, Lcom/tencent/android/tpush/a/b;->a(Ljava/lang/String;)V

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x5

    iget-object v4, v2, Landroid/content/pm/ProviderInfo;->name:Ljava/lang/String;

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x3

    const-class v5, Lcom/tencent/android/tpush/XGPushProvider;

    const-class v5, Lcom/tencent/android/tpush/XGPushProvider;

    const/4 v7, 0x3

    const-class v5, Lcom/tencent/android/tpush/XGPushProvider;

    const-class v5, Lcom/tencent/android/tpush/XGPushProvider;

    const/4 v7, 0x1

    const/4 v6, 0x6

    const/4 v7, 0x2

    invoke-virtual {v5}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v5

    const/4 v7, 0x5

    const/4 v6, 0x4

    const/4 v7, 0x7

    invoke-virtual {v4, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v4

    const/4 v7, 0x0

    const/4 v6, 0x5

    const/4 v7, 0x5

    if-eqz v4, :cond_2

    const/4 v6, 0x0

    xor-int/2addr v7, v6

    invoke-virtual {v3, v2}, Lcom/tencent/android/tpush/a/b;->a(Landroid/content/pm/ProviderInfo;)V

    const/4 v7, 0x4

    const/4 v6, 0x6

    const/4 v7, 0x5

    goto :goto_1

    :cond_2
    const/4 v7, 0x1

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-virtual {v3, v2}, Lcom/tencent/android/tpush/a/b;->b(Landroid/content/pm/ProviderInfo;)V

    :goto_1
    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x1

    iget-object v4, p0, Lcom/tencent/android/tpush/a/a;->d:Ljava/util/HashMap;

    const/4 v7, 0x5

    const/4 v6, 0x6

    iget-object v2, v2, Landroid/content/pm/ProviderInfo;->packageName:Ljava/lang/String;

    const/4 v7, 0x5

    const/4 v6, 0x5

    const/4 v7, 0x7

    invoke-virtual {v4, v2, v3}, Ljava/util/HashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    const/4 v7, 0x6

    const/4 v6, 0x0

    const/4 v7, 0x2

    goto/16 :goto_0

    :cond_3
    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x4

    return-void
.end method

.method public c()Ljava/util/List;
    .locals 6
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()",
            "Ljava/util/List<",
            "Ljava/lang/String;",
            ">;"
        }
    .end annotation

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v0, "MargoCenaI"

    const-string v0, "IPCManager"

    const/4 v5, 0x6

    const/4 v4, 0x7

    const/4 v5, 0x3

    const-string/jumbo v1, "laippbstcolop GganA lLAce-"

    const-string/jumbo v1, "osLaaocpc-tltpgGAnAe lil p"

    const/4 v5, 0x5

    const-string/jumbo v1, "laGsXcutLaAooAteicgpp-nl l"

    const-string v1, "action - getAllLocalXGApps"

    const/4 v5, 0x0

    const/4 v4, 0x2

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x5

    const/4 v4, 0x1

    new-instance v0, Ljava/util/ArrayList;

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/a/a;->c:Landroid/content/pm/PackageManager;

    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x2

    new-instance v2, Landroid/content/Intent;

    const/4 v5, 0x6

    const-string v3, ".Kaqtitp.dtDaonon.rx.pgnoiSd.ic.cmvec"

    const-string/jumbo v3, "one.cticqdo.irotv..gdK..DnSmaicnatpnx"

    const/4 v5, 0x1

    const-string/jumbo v3, "ipnmcottq.eenrn.gioK.ncvo..Saadxdtc.i"

    const-string v3, "com.tencent.android.xg.vip.action.SDK"

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-direct {v2, v3}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v4, 0x7

    const/4 v5, 0x1

    const/4 v3, 0x0

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v5, 0x0

    invoke-virtual {v1, v2, v3}, Landroid/content/pm/PackageManager;->queryBroadcastReceivers(Landroid/content/Intent;I)Ljava/util/List;

    move-result-object v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x6

    if-eqz v1, :cond_0

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v1}, Ljava/util/List;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :goto_0
    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x4

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x6

    if-eqz v2, :cond_0

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x7

    const/4 v4, 0x3

    check-cast v2, Landroid/content/pm/ResolveInfo;

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v2, v2, Landroid/content/pm/ResolveInfo;->resolvePackageName:Ljava/lang/String;

    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x0

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x5

    goto :goto_0

    :cond_0
    const/4 v5, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/a/a;->b:Landroid/content/Context;

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x0

    invoke-static {v1}, Lcom/tencent/android/tpush/a;->a(Landroid/content/Context;)Ljava/util/Map;

    move-result-object v1

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x0

    if-eqz v1, :cond_2

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {v1}, Ljava/util/Map;->entrySet()Ljava/util/Set;

    move-result-object v1

    const/4 v5, 0x2

    const/4 v4, 0x2

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Set;->iterator()Ljava/util/Iterator;

    move-result-object v1

    :cond_1
    :goto_1
    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x5

    invoke-interface {v1}, Ljava/util/Iterator;->hasNext()Z

    move-result v2

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x5

    if-eqz v2, :cond_2

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-interface {v1}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x4

    const/4 v4, 0x3

    check-cast v2, Ljava/util/Map$Entry;

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x2

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v3

    const/4 v5, 0x3

    invoke-interface {v0, v3}, Ljava/util/List;->contains(Ljava/lang/Object;)Z

    move-result v3

    const/4 v5, 0x5

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-nez v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-interface {v2}, Ljava/util/Map$Entry;->getKey()Ljava/lang/Object;

    move-result-object v2

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-interface {v0, v2}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    const/4 v5, 0x5

    const/4 v4, 0x7

    const/4 v5, 0x3

    goto :goto_1

    :cond_2
    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x4

    return-object v0
.end method
