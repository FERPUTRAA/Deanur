.class Lcom/tencent/android/tpush/XGPush4Msdk$8;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPush4Msdk;->setTag(Landroid/content/Context;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;

.field final synthetic b:Landroid/content/Context;


# direct methods
.method constructor <init>(Ljava/lang/String;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$8;->a:Ljava/lang/String;

    const/4 v1, 0x3

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$8;->b:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x6

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x0

    const/4 v0, 0x5

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "rosisao ~i@  ~ 1o4@o@ @~@mMul/K@ ~~~@~~v~ ~t~@@ n@@@~- ~@@f @od t~ i~ ~~@l@o~ b~~fb /@ .bc S@~y~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v9, 0x1

    and-int/2addr v10, v9

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v10, 0x7

    const/4 v9, 0x2

    const-string v1, ":sem=sgNtagmea T"

    const-string v1, "gesa= atgst:mTNe"

    const/4 v10, 0x3

    const-string/jumbo v1, "s=tgoTe aN:gtaea"

    const-string/jumbo v1, "setTag: tagName="

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$8;->a:Ljava/lang/String;

    const/4 v9, 0x1

    or-int/2addr v10, v9

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x1

    const-string/jumbo v1, "mpqqdbpAi"

    const-string v1, "=pAmidpqq"

    const/4 v10, 0x4

    const-string v1, "A=pidquq,"

    const-string v1, ",qqAppid="

    const/4 v10, 0x2

    const/4 v9, 0x6

    const/4 v10, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x1

    const/4 v9, 0x4

    const/4 v10, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/XGPush4Msdk;->c()J

    move-result-wide v1

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x2

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x0

    const/4 v9, 0x6

    const/4 v10, 0x3

    const-string v1, "ac,gs_dpcso=e"

    const-string/jumbo v1, "scxcosd_aeg=,"

    const/4 v10, 0x4

    const-string/jumbo v1, "seidcs_gq=xa,"

    const-string v1, ",xg_accessid="

    const/4 v10, 0x0

    const/4 v9, 0x5

    const/4 v10, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v10, 0x7

    const/4 v9, 0x6

    const/4 v10, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPush4Msdk$8;->b:Landroid/content/Context;

    const/4 v10, 0x2

    const/4 v9, 0x5

    const/4 v10, 0x5

    invoke-static {v1}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v1

    const/4 v10, 0x7

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x7

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v10, 0x2

    const/4 v9, 0x1

    const/4 v10, 0x6

    const-string/jumbo v1, "ubshsP4MksG"

    const-string v1, "Ms4sGbPhudk"

    const/4 v10, 0x4

    const-string v1, "hsPmGudM4sX"

    const-string v1, "XGPush4Msdk"

    const/4 v10, 0x1

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static {v1, v0}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPush4Msdk$8;->b:Landroid/content/Context;

    const/4 v10, 0x6

    const/4 v9, 0x7

    const/4 v10, 0x1

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPush4Msdk$8;->a:Ljava/lang/String;

    const/4 v10, 0x6

    const/4 v9, 0x1

    const/4 v10, 0x7

    const/4 v4, 0x1

    const/4 v10, 0x3

    const/4 v9, 0x3

    const/4 v10, 0x5

    invoke-static {v2}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAccessId(Landroid/content/Context;)J

    move-result-wide v5

    const/4 v10, 0x4

    const/4 v9, 0x1

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPush4Msdk$8;->b:Landroid/content/Context;

    const/4 v10, 0x1

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPush4Msdk;->getQQAppKey(Landroid/content/Context;)Ljava/lang/String;

    move-result-object v7

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x7

    iget-object v8, p0, Lcom/tencent/android/tpush/XGPush4Msdk$8;->a:Ljava/lang/String;

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x0

    invoke-static/range {v2 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;)V

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x1

    return-void
.end method
