.class Lcom/tencent/android/tpush/XGPushManager$8;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->c(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:I

.field final synthetic d:J

.field final synthetic e:Ljava/lang/String;

.field final synthetic f:Ljava/lang/String;

.field final synthetic g:Lcom/tencent/android/tpush/XGIOperateCallback;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v1, 0x7

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$8;->a:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x3

    const/4 v1, 0x3

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$8;->b:Ljava/lang/String;

    const/4 v0, 0x7

    shl-int/2addr v1, v0

    iput p3, p0, Lcom/tencent/android/tpush/XGPushManager$8;->c:I

    const/4 v1, 0x7

    iput-wide p4, p0, Lcom/tencent/android/tpush/XGPushManager$8;->d:J

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x0

    iput-object p6, p0, Lcom/tencent/android/tpush/XGPushManager$8;->e:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x7

    iput-object p7, p0, Lcom/tencent/android/tpush/XGPushManager$8;->f:Ljava/lang/String;

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x4

    iput-object p8, p0, Lcom/tencent/android/tpush/XGPushManager$8;->g:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    const/4 v1, 0x5

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v9, "r~s~y@@~Kl~@a1 ~t  @m o@~ 4osn~ Mlb  f obi~~@@i @Soi~v@u~~@ /coot@~ ~  b~ ~~ f@~d@@@~-.@@@/@~ @~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$8;->a:Landroid/content/Context;

    const/4 v9, 0x7

    xor-int/2addr v10, v9

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v10, 0x7

    const/4 v9, 0x7

    const/4 v10, 0x4

    if-eqz v0, :cond_0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$8;->a:Landroid/content/Context;

    const/4 v9, 0x5

    const/4 v9, 0x5

    const/4 v10, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->i(Landroid/content/Context;)Z

    move-result v0

    const/4 v10, 0x2

    const/4 v9, 0x3

    const/4 v10, 0x4

    if-eqz v0, :cond_0

    const/4 v10, 0x3

    const/4 v9, 0x2

    const/4 v10, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$8;->a:Landroid/content/Context;

    const/4 v10, 0x0

    const/4 v9, 0x4

    const/4 v10, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$8;->b:Ljava/lang/String;

    const/4 v10, 0x1

    const/4 v9, 0x5

    const/4 v10, 0x4

    iget v3, p0, Lcom/tencent/android/tpush/XGPushManager$8;->c:I

    const/4 v10, 0x4

    const/4 v9, 0x1

    iget-wide v4, p0, Lcom/tencent/android/tpush/XGPushManager$8;->d:J

    const/4 v10, 0x4

    const/4 v9, 0x6

    const/4 v10, 0x1

    iget-object v6, p0, Lcom/tencent/android/tpush/XGPushManager$8;->e:Ljava/lang/String;

    const/4 v10, 0x1

    iget-object v7, p0, Lcom/tencent/android/tpush/XGPushManager$8;->f:Ljava/lang/String;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x2

    iget-object v8, p0, Lcom/tencent/android/tpush/XGPushManager$8;->g:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v10, 0x0

    const/4 v9, 0x2

    const/4 v10, 0x2

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;IJLjava/lang/String;Ljava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x6

    goto :goto_0

    :cond_0
    const/4 v10, 0x5

    const/4 v9, 0x3

    const/4 v10, 0x7

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$8$1;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x6

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/XGPushManager$8$1;-><init>(Lcom/tencent/android/tpush/XGPushManager$8;)V

    const/4 v10, 0x6

    new-instance v1, Lcom/tencent/android/tpush/XGPushManager$d;

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$8;->g:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x6

    const-string/jumbo v3, "tag"

    const-string v3, "gat"

    const/4 v10, 0x1

    const-string v3, "gta"

    const-string/jumbo v3, "tag"

    invoke-direct {v1, v2, v0, v3}, Lcom/tencent/android/tpush/XGPushManager$d;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;Lcom/tencent/tpns/baseapi/base/util/TTask;Ljava/lang/String;)V

    const/4 v10, 0x7

    const/4 v9, 0x0

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$8;->a:Landroid/content/Context;

    const/4 v10, 0x5

    const/4 v9, 0x6

    const/4 v10, 0x1

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/XGPushManager;->registerPush(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    :goto_0
    const/4 v10, 0x4

    const/4 v9, 0x2

    const/4 v10, 0x4

    return-void
.end method
