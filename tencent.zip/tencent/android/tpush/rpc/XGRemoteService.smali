.class public Lcom/tencent/android/tpush/rpc/XGRemoteService;
.super Landroid/app/Service;


# annotations
.annotation build Lcom/jg/JgClassChecked;
    author = 0x1
    fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
    lastDate = "20150316"
    reviewer = 0x3
    vComment = {
        .enum Lcom/jg/EType;->SERVICESCHECK:Lcom/jg/EType;
    }
.end annotation


# instance fields
.field private a:Lcom/tencent/android/tpush/rpc/a$a;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-direct {p0}, Landroid/app/Service;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    new-instance v0, Lcom/tencent/android/tpush/rpc/d;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-direct {v0}, Lcom/tencent/android/tpush/rpc/d;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/rpc/XGRemoteService;->a:Lcom/tencent/android/tpush/rpc/a$a;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method


# virtual methods
.method public onBind(Landroid/content/Intent;)Landroid/os/IBinder;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "i@stl~@mt@~   i/o ~@f   @~by~cs~@ ~@@S~n@~ ~@.-v@u~ad~@~~~KM1o@o@@@i~ ~@b/ ~~~@ ~ l4@f o~r @b  o"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x4

    invoke-virtual {p0}, Landroid/content/Context;->getApplicationContext()Landroid/content/Context;

    move-result-object p1

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x1

    invoke-static {p1}, Lcom/tencent/android/tpush/service/b;->b(Landroid/content/Context;)V

    const/4 v1, 0x0

    iget-object p1, p0, Lcom/tencent/android/tpush/rpc/XGRemoteService;->a:Lcom/tencent/android/tpush/rpc/a$a;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    return-object p1
.end method

.method public onCreate()V
    .locals 2

    const/4 v1, 0x6

    invoke-super {p0}, Landroid/app/Service;->onCreate()V

    const/4 v1, 0x3

    const/4 v0, 0x1

    return-void
.end method

.method public onStartCommand(Landroid/content/Intent;II)I
    .locals 2

    const/4 v1, 0x1

    const/4 p1, 0x1

    const/4 v1, 0x2

    const/4 p1, 0x2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x1

    return p1
.end method
