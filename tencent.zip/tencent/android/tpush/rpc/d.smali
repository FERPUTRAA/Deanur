.class public Lcom/tencent/android/tpush/rpc/d;
.super Lcom/tencent/android/tpush/rpc/a$a;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/tencent/android/tpush/rpc/a$a;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public a()V
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v3, "~as~rd@@@-@MS~ v~~@/@~n~~ @ ~~@~bbm@@@@iK l@~~io @o@~yif~~~ ~f~o @o1 @  b@l@@~os4o  c~t~   .t /u"

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x3

    const-string/jumbo v0, "pTamIsIkl"

    const-string v0, "ITaskImpl"

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string/jumbo v1, "seesorXGacSv ti"

    const-string v1, "ersrvX aitcsGeS"

    const/4 v4, 0x4

    const-string/jumbo v1, "ttcXibaeG reSsv"

    const-string/jumbo v1, "start XGService"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-static {v1}, Lcom/tencent/android/tpush/service/b;->a(Landroid/content/Context;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto :goto_0

    :catchall_0
    move-exception v1

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo v2, "tcitrSuamerv"

    const-string/jumbo v2, "rtamvieretSc"

    const/4 v4, 0x3

    const-string/jumbo v2, "iercvSspraet"

    const-string/jumbo v2, "startService"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {v0, v2, v1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    return-void
.end method

.method public a(Ljava/lang/String;Lcom/tencent/android/tpush/rpc/b;)V
    .locals 3
    .annotation build Lcom/jg/JgMethodChecked;
        author = 0x1
        fComment = "\u786e\u8ba4\u5df2\u8fdb\u884c\u5b89\u5168\u6821\u9a8c"
        lastDate = "20150316"
        reviewer = 0x3
        vComment = {
            .enum Lcom/jg/EType;->INTENTSCHEMECHECK:Lcom/jg/EType;,
            .enum Lcom/jg/EType;->INTENTCHECK:Lcom/jg/EType;
        }
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    const/4 v0, 0x0

    :try_start_0
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p1, v0}, Landroid/content/Intent;->parseUri(Ljava/lang/String;I)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/message/e;->a(Landroid/content/Context;)Lcom/tencent/android/tpush/message/e;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-virtual {v0, p1}, Lcom/tencent/android/tpush/message/e;->a(Landroid/content/Intent;)V

    invoke-interface {p2}, Lcom/tencent/android/tpush/rpc/b;->a()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    goto :goto_0

    :catchall_0
    move-exception p1

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    const-string p2, "TapoIsIkq"

    const-string/jumbo p2, "sklpoTIIa"

    const/4 v2, 0x1

    const-string p2, "IpsTkmsla"

    const-string p2, "ITaskImpl"

    const/4 v1, 0x7

    and-int/2addr v2, v1

    const-string/jumbo v0, "woSh"

    const-string v0, "hSwo"

    const/4 v2, 0x4

    const-string v0, "hwSo"

    const-string v0, "Show"

    const/4 v2, 0x3

    const/4 v1, 0x3

    invoke-static {p2, v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    return-void
.end method

.method public b()V
    .locals 2

    const/4 v1, 0x1

    return-void
.end method
