.class public abstract Lcom/tencent/android/tpush/rpc/b$a;
.super Landroid/os/Binder;

# interfaces
.implements Lcom/tencent/android/tpush/rpc/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/rpc/b;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/rpc/b$a$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const/4 v2, 0x1

    const-string v0, ".astnakcknIcT.sh.tsllsacopCodtbrcrid.neepum"

    const-string/jumbo v0, "nesmistar.ck.lpc.dp.clatsdb.eCotkInucahTrno"

    const/4 v2, 0x7

    const-string v0, "com.tencent.android.tpush.rpc.ITaskCallback"

    const/4 v2, 0x4

    const/4 v1, 0x6

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x7

    return-void
.end method

.method public static a(Landroid/os/IBinder;)Lcom/tencent/android/tpush/rpc/b;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " ~~moi @ ~@ .d~~@t @~ ~ci~@vf@@ba@n@ @~o@o~u r-~@il  M lbyt@1moS @o~  K~@@~  s@@~ ~~~@b4/~~~@~fo"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x7

    const/4 p0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-object p0

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string/jumbo v0, "lpneottc..t.rramTeCl.c.ckknbshodcoiuIadasmp"

    const-string v0, "Calmhmtict.cdeTnsr.rpstka.kIa.cnde.lnucbopo"

    const/4 v3, 0x3

    const-string/jumbo v0, "laotsb.c.cbaCrucstnaarp.knipcmetnTIo.ehkl.d"

    const-string v0, "com.tencent.android.tpush.rpc.ITaskCallback"

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x0

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x3

    instance-of v1, v0, Lcom/tencent/android/tpush/rpc/b;

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x4

    if-eqz v1, :cond_1

    const/4 v2, 0x6

    move v3, v2

    check-cast v0, Lcom/tencent/android/tpush/rpc/b;

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0

    :cond_1
    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/android/tpush/rpc/b$a$a;

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/rpc/b$a$a;-><init>(Landroid/os/IBinder;)V

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0
.end method

.method public static b()Lcom/tencent/android/tpush/rpc/b;
    .locals 3

    const/4 v1, 0x0

    move v2, v1

    sget-object v0, Lcom/tencent/android/tpush/rpc/b$a$a;->a:Lcom/tencent/android/tpush/rpc/b;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x2

    return-object v0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 2

    const/4 v1, 0x3

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 5

    const/4 v4, 0x4

    const/4 v0, 0x6

    const/4 v4, 0x0

    const/4 v0, 0x1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const-string v1, "acnl.nurTehdcCo.rmcsbattkdspoIoi.laektpn.a."

    const-string v1, "an.koetCpi.brenaa.lpn.roaccTss.cddtkmIuothl"

    const-string v1, "chaspnpplenme.acdCrTubdnat.calrctokkIs.oti."

    const-string v1, "com.tencent.android.tpush.rpc.ITaskCallback"

    if-eq p1, v0, :cond_1

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    const v2, 0x5f4e5446

    const/4 v4, 0x4

    if-eq p1, v2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    return p1

    :cond_0
    const/4 v4, 0x1

    const/4 v3, 0x2

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v3, 0x0

    return v0

    :cond_1
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-interface {p0}, Lcom/tencent/android/tpush/rpc/b;->a()V

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    return v0
.end method
