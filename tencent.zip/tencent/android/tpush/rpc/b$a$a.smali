.class Lcom/tencent/android/tpush/rpc/b$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/rpc/b;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/rpc/b$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# static fields
.field public static a:Lcom/tencent/android/tpush/rpc/b;


# instance fields
.field private b:Landroid/os/IBinder;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .locals 2

    const/4 v1, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x1

    const/4 v0, 0x6

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/rpc/b$a$a;->b:Landroid/os/IBinder;

    const/4 v1, 0x2

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public a()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " cs1u@ ~~ @i~~b~ o@aK imbs@@~~ .t  ~@~ nb~~~@l~@o~@orf@ / ~@~o-~~@Sy i@@ ~/@~l@@~vo@@o4f@ d ~M t"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x0

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v2, "csampc..abnunli.hldrCtaTspsekIkamcd.ot.coen"

    const-string v2, "ers.Cbkutap.hcedtacolac.siTkdn.asnpIlomcr.n"

    const/4 v6, 0x2

    const-string/jumbo v2, "snkmoarkei.nctcpots.ldp.aTcb.elCah.aonIutcd"

    const-string v2, "com.tencent.android.tpush.rpc.ITaskCallback"

    const/4 v6, 0x5

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x3

    iget-object v2, p0, Lcom/tencent/android/tpush/rpc/b$a$a;->b:Landroid/os/IBinder;

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/4 v3, 0x1

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v4, 0x7

    const/4 v4, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x7

    invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-nez v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/rpc/b$a;->b()Lcom/tencent/android/tpush/rpc/b;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-eqz v2, :cond_0

    const/4 v6, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/rpc/b$a;->b()Lcom/tencent/android/tpush/rpc/b;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-interface {v2}, Lcom/tencent/android/tpush/rpc/b;->a()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x7

    const/4 v5, 0x2

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x2

    return-void

    :cond_0
    :try_start_1
    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x4

    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x2

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    return-void

    :catchall_0
    move-exception v2

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x3

    const/4 v5, 0x4

    const/4 v6, 0x7

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x6

    throw v2
.end method

.method public asBinder()Landroid/os/IBinder;
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/rpc/b$a$a;->b:Landroid/os/IBinder;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x7

    return-object v0
.end method
