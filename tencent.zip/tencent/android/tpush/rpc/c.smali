.class public Lcom/tencent/android/tpush/rpc/c;
.super Lcom/tencent/android/tpush/rpc/b$a;


# instance fields
.field private a:Landroid/content/ServiceConnection;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/android/tpush/rpc/b$a;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method


# virtual methods
.method public a()V
    .locals 5

    :try_start_0
    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-eqz v0, :cond_0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {}, Lcom/tencent/android/tpush/service/b;->e()Landroid/content/Context;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/rpc/c;->a:Landroid/content/ServiceConnection;

    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/content/Context;->unbindService(Landroid/content/ServiceConnection;)V

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x3

    const/4 v0, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x6

    iput-object v0, p0, Lcom/tencent/android/tpush/rpc/c;->a:Landroid/content/ServiceConnection;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :catchall_0
    move-exception v0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const-string/jumbo v1, "lpssCkkblalcasTIa"

    const-string/jumbo v1, "slspTlIkkaIblaacC"

    const/4 v4, 0x5

    const-string v1, "ckTmCpslablkIamlI"

    const-string v1, "ITaskCallbackImpl"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    const-string v2, "Bnumod"

    const-string/jumbo v2, "unimBd"

    const/4 v4, 0x7

    const-string/jumbo v2, "nniudb"

    const-string/jumbo v2, "unBind"

    const/4 v3, 0x6

    shr-int/2addr v4, v3

    invoke-static {v1, v2, v0}, Lcom/tencent/android/tpush/logging/TLogger;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)V

    :cond_0
    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x2

    return-void
.end method

.method public a(Landroid/content/ServiceConnection;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/rpc/c;->a:Landroid/content/ServiceConnection;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x4

    return-void
.end method
