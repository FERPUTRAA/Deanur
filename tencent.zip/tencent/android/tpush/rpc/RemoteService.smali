.class public Lcom/tencent/android/tpush/rpc/RemoteService;
.super Lcom/tencent/android/tpush/rpc/XGRemoteService;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x7

    const/4 v1, 0x0

    invoke-direct {p0}, Lcom/tencent/android/tpush/rpc/XGRemoteService;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x0

    return-void
.end method
