.class Lcom/tencent/android/tpush/rpc/a$a$a;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/rpc/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/rpc/a$a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0xa
    name = "a"
.end annotation


# static fields
.field public static a:Lcom/tencent/android/tpush/rpc/a;


# instance fields
.field private b:Landroid/os/IBinder;


# direct methods
.method constructor <init>(Landroid/os/IBinder;)V
    .locals 2

    const/4 v0, 0x7

    const/4 v0, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p1, p0, Lcom/tencent/android/tpush/rpc/a$a$a;->b:Landroid/os/IBinder;

    const/4 v1, 0x3

    const/4 v0, 0x1

    const/4 v1, 0x1

    return-void
.end method


# virtual methods
.method public a()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@~s@.@@@f ~l@S ~@~~t ~K ~~o@~~ bn@oi@/i~o@@M c@ am 1o@/b~@@~~ y @~ ob4 ~~ @li~s~dv-@~t  ro@~  fu"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v6, 0x5

    const/4 v5, 0x4

    const/4 v6, 0x2

    const-string v2, "casTdrknn.aooeeIcttiupr.np..htds.sm"

    const/4 v6, 0x7

    const-string/jumbo v2, "poumnorkradcse.im.dtTtcetnp..ncas.I"

    const-string v2, "com.tencent.android.tpush.rpc.ITask"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    iget-object v2, p0, Lcom/tencent/android/tpush/rpc/a$a$a;->b:Landroid/os/IBinder;

    const/4 v6, 0x5

    const/4 v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    const/4 v4, 0x0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x7

    invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v2

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x4

    if-nez v2, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-static {}, Lcom/tencent/android/tpush/rpc/a$a;->c()Lcom/tencent/android/tpush/rpc/a;

    move-result-object v2

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x7

    if-eqz v2, :cond_0

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-static {}, Lcom/tencent/android/tpush/rpc/a$a;->c()Lcom/tencent/android/tpush/rpc/a;

    move-result-object v2

    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-interface {v2}, Lcom/tencent/android/tpush/rpc/a;->a()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x5

    const/4 v5, 0x2

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x5

    return-void

    :cond_0
    :try_start_1
    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x7

    return-void

    :catchall_0
    move-exception v2

    const/4 v6, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x1

    throw v2
.end method

.method public a(Ljava/lang/String;Lcom/tencent/android/tpush/rpc/b;)V
    .locals 7

    const/4 v6, 0x2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x2

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x2

    const-string/jumbo v2, "os.tonar.kntptI.Tapdmedicer.hnmcsoc"

    const-string/jumbo v2, "ospmek.ideptct.aathn.nscnmTc.rI.rdo"

    const/4 v6, 0x2

    const-string v2, "com.tencent.android.tpush.rpc.ITask"

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v5, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0, p1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v6, 0x6

    if-eqz p2, :cond_0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {p2}, Landroid/os/IInterface;->asBinder()Landroid/os/IBinder;

    move-result-object v2

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x6

    goto :goto_0

    :cond_0
    const/4 v6, 0x0

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeStrongBinder(Landroid/os/IBinder;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/rpc/a$a$a;->b:Landroid/os/IBinder;

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x0

    const/4 v3, 0x3

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x1

    invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x2

    if-nez v2, :cond_1

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/rpc/a$a;->c()Lcom/tencent/android/tpush/rpc/a;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-eqz v2, :cond_1

    const/4 v6, 0x2

    invoke-static {}, Lcom/tencent/android/tpush/rpc/a$a;->c()Lcom/tencent/android/tpush/rpc/a;

    move-result-object v2

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x4

    invoke-interface {v2, p1, p2}, Lcom/tencent/android/tpush/rpc/a;->a(Ljava/lang/String;Lcom/tencent/android/tpush/rpc/b;)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x2

    const/4 v5, 0x5

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    return-void

    :cond_1
    :try_start_1
    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x4

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x4

    const/4 v5, 0x7

    return-void

    :catchall_0
    move-exception p1

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x4

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x1

    const/4 v5, 0x5

    const/4 v6, 0x6

    throw p1
.end method

.method public asBinder()Landroid/os/IBinder;
    .locals 3

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/rpc/a$a$a;->b:Landroid/os/IBinder;

    const/4 v2, 0x7

    return-object v0
.end method

.method public b()V
    .locals 7

    const/4 v6, 0x0

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v0

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {}, Landroid/os/Parcel;->obtain()Landroid/os/Parcel;

    move-result-object v1

    :try_start_0
    const/4 v5, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x5

    const-string/jumbo v2, "r.tpnban...Tenuemdotcdahcotsrsp.koi"

    const-string v2, "htnmo.dkptouaT.ipcdrses.c.cnt.ernao"

    const/4 v6, 0x0

    const-string v2, "anmtttu.pu.seTo.cnnicdIdsoke.rrcap."

    const-string v2, "com.tencent.android.tpush.rpc.ITask"

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-virtual {v0, v2}, Landroid/os/Parcel;->writeInterfaceToken(Ljava/lang/String;)V

    const/4 v6, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/rpc/a$a$a;->b:Landroid/os/IBinder;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x4

    const/4 v3, 0x2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    const/4 v4, 0x0

    const/4 v6, 0x0

    const/4 v5, 0x1

    const/4 v6, 0x0

    invoke-interface {v2, v3, v0, v1, v4}, Landroid/os/IBinder;->transact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result v2

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x3

    if-nez v2, :cond_0

    const/4 v6, 0x3

    const/4 v5, 0x3

    const/4 v6, 0x1

    invoke-static {}, Lcom/tencent/android/tpush/rpc/a$a;->c()Lcom/tencent/android/tpush/rpc/a;

    move-result-object v2

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x4

    if-eqz v2, :cond_0

    const/4 v6, 0x6

    const/4 v5, 0x6

    const/4 v6, 0x5

    invoke-static {}, Lcom/tencent/android/tpush/rpc/a$a;->c()Lcom/tencent/android/tpush/rpc/a;

    move-result-object v2

    const/4 v6, 0x6

    const/4 v5, 0x3

    const/4 v6, 0x7

    invoke-interface {v2}, Lcom/tencent/android/tpush/rpc/a;->b()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x2

    move v6, v5

    return-void

    :cond_0
    :try_start_1
    const/4 v5, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-virtual {v1}, Landroid/os/Parcel;->readException()V
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x2

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v5, 0x2

    or-int/2addr v6, v5

    return-void

    :catchall_0
    move-exception v2

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-virtual {v1}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    invoke-virtual {v0}, Landroid/os/Parcel;->recycle()V

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    throw v2
.end method
