.class public abstract Lcom/tencent/android/tpush/rpc/a$a;
.super Landroid/os/Binder;

# interfaces
.implements Lcom/tencent/android/tpush/rpc/a;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/tencent/android/tpush/rpc/a;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x409
    name = "a"
.end annotation

.annotation system Ldalvik/annotation/MemberClasses;
    value = {
        Lcom/tencent/android/tpush/rpc/a$a$a;
    }
.end annotation


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x1

    invoke-direct {p0}, Landroid/os/Binder;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string/jumbo v0, "tasts.drndort.occ.puIkpnsTcn.e.siea"

    const-string v0, "cdsmpnrtdkasco.tTeconp.u.at.e.nrIsi"

    const/4 v2, 0x2

    const-string v0, "eaTmamo.Ihor.tsd.ruensdp.ktptn.cicc"

    const-string v0, "com.tencent.android.tpush.rpc.ITask"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    invoke-virtual {p0, p0, v0}, Landroid/os/Binder;->attachInterface(Landroid/os/IInterface;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-void
.end method

.method public static a(Landroid/os/IBinder;)Lcom/tencent/android/tpush/rpc/a;
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/~~@o~~d@l@lt~ yo@@ b@ o~1cS~@aK@ i~m@@ ft@ i~fs~ @~ v  b~ @4@ ~ .r~ @/o~o~@@un ~~~o b@oM-i~@~@ "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    if-nez p0, :cond_0

    const/4 v2, 0x6

    move v3, v2

    const/4 p0, 0x0

    move v3, p0

    const/4 v2, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x5

    return-object p0

    :cond_0
    const/4 v3, 0x1

    const/4 v2, 0x0

    const-string v0, "a.tchb.utprnmnekstmT...dpsnaIioorec"

    const-string/jumbo v0, "t.imoccapnsrsnI.ot..huTkptedcmae.nr"

    const/4 v3, 0x1

    const-string/jumbo v0, "oti.mtuacnIrTaph.o.ptcucskdd..renen"

    const-string v0, "com.tencent.android.tpush.rpc.ITask"

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-interface {p0, v0}, Landroid/os/IBinder;->queryLocalInterface(Ljava/lang/String;)Landroid/os/IInterface;

    move-result-object v0

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x0

    if-eqz v0, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x3

    instance-of v1, v0, Lcom/tencent/android/tpush/rpc/a;

    const/4 v3, 0x6

    const/4 v2, 0x6

    if-eqz v1, :cond_1

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v3, 0x1

    check-cast v0, Lcom/tencent/android/tpush/rpc/a;

    const/4 v3, 0x5

    const/4 v2, 0x1

    return-object v0

    :cond_1
    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    new-instance v0, Lcom/tencent/android/tpush/rpc/a$a$a;

    const/4 v3, 0x5

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/rpc/a$a$a;-><init>(Landroid/os/IBinder;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x1

    return-object v0
.end method

.method public static c()Lcom/tencent/android/tpush/rpc/a;
    .locals 3

    const/4 v2, 0x1

    sget-object v0, Lcom/tencent/android/tpush/rpc/a$a$a;->a:Lcom/tencent/android/tpush/rpc/a;

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    return-object v0
.end method


# virtual methods
.method public asBinder()Landroid/os/IBinder;
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x0

    return-object p0
.end method

.method public onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x4

    const/4 v0, 0x1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-string/jumbo v1, "kapintspetpt.duc.aoTc..mcehn.rorInd"

    const-string/jumbo v1, "nI.co.tskToottpian.e.urcn.dpdcemhra"

    const/4 v4, 0x5

    const-string/jumbo v1, "na.hntcIq.ukpmosTotdicrende.ta.cprs"

    const-string v1, "com.tencent.android.tpush.rpc.ITask"

    const/4 v4, 0x3

    const/4 v3, 0x7

    if-eq p1, v0, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x5

    const/4 v2, 0x2

    const/4 v4, 0x7

    if-eq p1, v2, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    const/4 v2, 0x3

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eq p1, v2, :cond_1

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x1

    const v2, 0x5f4e5446

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-eq p1, v2, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-super {p0, p1, p2, p3, p4}, Landroid/os/Binder;->onTransact(ILandroid/os/Parcel;Landroid/os/Parcel;I)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    return p1

    :cond_0
    const/4 v4, 0x2

    invoke-virtual {p3, v1}, Landroid/os/Parcel;->writeString(Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v0

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {p2}, Landroid/os/Parcel;->readString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {p2}, Landroid/os/Parcel;->readStrongBinder()Landroid/os/IBinder;

    move-result-object p2

    const/4 v4, 0x3

    const/4 v3, 0x1

    invoke-static {p2}, Lcom/tencent/android/tpush/rpc/b$a;->a(Landroid/os/IBinder;)Lcom/tencent/android/tpush/rpc/b;

    move-result-object p2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-interface {p0, p1, p2}, Lcom/tencent/android/tpush/rpc/a;->a(Ljava/lang/String;Lcom/tencent/android/tpush/rpc/b;)V

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v0

    :cond_2
    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-interface {p0}, Lcom/tencent/android/tpush/rpc/a;->b()V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x4

    return v0

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x1

    invoke-virtual {p2, v1}, Landroid/os/Parcel;->enforceInterface(Ljava/lang/String;)V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x3

    invoke-interface {p0}, Lcom/tencent/android/tpush/rpc/a;->a()V

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x5

    invoke-virtual {p3}, Landroid/os/Parcel;->writeNoException()V

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x1

    return v0
.end method
