.class public Lcom/tencent/android/tpush/XGPushShowedResult;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/XGIResult;


# static fields
.field public static final NOTIFICATION_ACTION_ACTIVITY:I

.field public static final NOTIFICATION_ACTION_INTENT:I

.field public static final NOTIFICATION_ACTION_INTENT_WIHT_ACTION:I

.field public static final NOTIFICATION_ACTION_PACKAGE:I

.field public static final NOTIFICATION_ACTION_URL:I


# instance fields
.field a:J

.field b:Ljava/lang/String;

.field c:Ljava/lang/String;

.field d:Ljava/lang/String;

.field e:Ljava/lang/String;

.field f:I

.field g:I

.field h:I

.field i:Z

.field public templateId:Ljava/lang/String;

.field public traceId:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x1

    sput v0, Lcom/tencent/android/tpush/XGPushShowedResult;->NOTIFICATION_ACTION_ACTIVITY:I

    const/4 v2, 0x6

    const/4 v1, 0x1

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->url:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x4

    sput v0, Lcom/tencent/android/tpush/XGPushShowedResult;->NOTIFICATION_ACTION_URL:I

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x6

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->intent:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x5

    sput v0, Lcom/tencent/android/tpush/XGPushShowedResult;->NOTIFICATION_ACTION_INTENT:I

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->action_package:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v2, 0x1

    const/4 v1, 0x0

    sput v0, Lcom/tencent/android/tpush/XGPushShowedResult;->NOTIFICATION_ACTION_PACKAGE:I

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->intent_with_action:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v1, 0x1

    xor-int/2addr v2, v1

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x1

    sput v0, Lcom/tencent/android/tpush/XGPushShowedResult;->NOTIFICATION_ACTION_INTENT_WIHT_ACTION:I

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->a:J

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v4, 0x6

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x2

    shr-int/2addr v4, v3

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->b:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->c:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->d:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->e:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    iput v1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->f:I

    const/4 v4, 0x2

    sget-object v2, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v2}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x2

    iput v2, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->g:I

    const/4 v3, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    const/16 v2, 0x64

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x3

    iput v2, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->h:I

    const/4 v4, 0x7

    const/4 v3, 0x0

    iput-boolean v1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->i:Z

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->templateId:Ljava/lang/String;

    const/4 v3, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->traceId:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x1

    return-void
.end method


# virtual methods
.method public getActivity()Ljava/lang/String;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@~so b@@@~~@fu@@~  bd@oc bSr~-@tii~o~tm~/.~@   @y~~ / ~@i K~ a4@~o@@sfl@n~@~1o  v~M~ o~~@ @~ ~l "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->e:Ljava/lang/String;

    const/4 v2, 0x5

    return-object v0
.end method

.method public getContent()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->c:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public getCustomContent()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->d:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x5

    return-object v0
.end method

.method public getMsgId()J
    .locals 4

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x3

    iget-wide v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->a:J

    const/4 v3, 0x7

    const/4 v2, 0x1

    return-wide v0
.end method

.method public getNotifactionId()I
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->f:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x4

    return v0
.end method

.method public getNotificationActionType()I
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    iget v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->g:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x0

    return v0
.end method

.method public getPushChannel()I
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x2

    iget v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->h:I

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x0

    return v0
.end method

.method public getTemplateId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->templateId:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->b:Ljava/lang/String;

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x1

    return-object v0
.end method

.method public getTraceId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->traceId:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public isCustomLayout()Z
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    iget-boolean v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->i:Z

    const/4 v2, 0x1

    return v0
.end method

.method public parseIntent(Landroid/content/Intent;)V
    .locals 5

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-string/jumbo v0, "smdmg"

    const-string v0, "dmsgs"

    const/4 v4, 0x0

    const-string/jumbo v0, "msgId"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x3

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1, v2}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->a:J

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string/jumbo v0, "yvatoicm"

    const-string/jumbo v0, "vtymacit"

    const/4 v4, 0x1

    const-string v0, "ayiicbvt"

    const-string v0, "activity"

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->e:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v0, "eutoi"

    const-string/jumbo v0, "ileto"

    const/4 v4, 0x3

    const-string/jumbo v0, "tepli"

    const-string/jumbo v0, "title"

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->b:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string/jumbo v0, "nqnoetc"

    const-string v0, "content"

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->c:Ljava/lang/String;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v4, 0x5

    const/4 v3, 0x7

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string/jumbo v1, "tisATyioebtonptanncico"

    const-string/jumbo v1, "nafntbiioyTecnitocpotA"

    const/4 v4, 0x0

    const-string/jumbo v1, "iicmptnooctytAninioafe"

    const-string/jumbo v1, "notificationActionType"

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {p1, v1, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x5

    iput v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->g:I

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string v0, "cmnnoeuuot_cto"

    const-string v0, "cno_ttucusnmoe"

    const/4 v4, 0x3

    const-string/jumbo v0, "somonbtutcce_t"

    const-string v0, "custom_content"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->d:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string/jumbo v0, "npitcouadtn_oi"

    const-string v0, "danttcipo_oini"

    const-string/jumbo v0, "it_dnfipioocat"

    const-string/jumbo v0, "notifaction_id"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x5

    const/4 v1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    iput v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->f:I

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x6

    const-string v0, "SUHCNqAPq.LH"

    const-string v0, "SUN.CANLqHPH"

    const/4 v4, 0x7

    const-string v0, "UNsPE.ASHNHC"

    const-string v0, "PUSH.CHANNEL"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x2

    const/16 v2, 0x64

    const/4 v4, 0x4

    const/4 v3, 0x6

    invoke-virtual {p1, v0, v2}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->h:I

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    const-string/jumbo v0, "setmdamIpe"

    const-string v0, "epsltaemId"

    const/4 v4, 0x5

    const-string v0, "eateolmdIp"

    const-string/jumbo v0, "templateId"

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->templateId:Ljava/lang/String;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v0, "atmecbr"

    const-string v0, "Iecmtra"

    const/4 v4, 0x5

    const-string v0, "eratIcu"

    const-string/jumbo v0, "traceId"

    const/4 v4, 0x1

    const/4 v3, 0x7

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->traceId:Ljava/lang/String;

    const/4 v3, 0x3

    and-int/2addr v4, v3

    const-string/jumbo v0, "osLuamopuoCtsy"

    const-string v0, "aLtuooyssCutom"

    const/4 v4, 0x3

    const-string/jumbo v0, "tuuLstoCqyisom"

    const-string/jumbo v0, "isCustomLayout"

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    iput-boolean p1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->i:Z

    const/4 v3, 0x0

    const/4 v3, 0x0

    iget p1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->h:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    const/16 v0, 0x65

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-eq p1, v0, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x6

    const/16 v0, 0x63

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x1

    if-ne p1, v0, :cond_1

    :cond_0
    :try_start_0
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->e:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x4

    const-string v0, "8-sbU"

    const-string v0, "b8U-T"

    const/4 v4, 0x7

    const-string v0, "-U8mF"

    const-string v0, "UTF-8"

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p1, v0}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x2

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->e:Ljava/lang/String;
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x1

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v1, " tIaoesiniauyatNn rmetepc:"

    const-string v1, "eetr cue ntts:ayIanNptimia"

    const/4 v4, 0x7

    const-string v1, "aIsypbctvrn tmintiaee:etNa"

    const-string/jumbo v1, "parseIntent activityName :"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string v0, "hthueSuoRwPpldueGs"

    const-string v0, "XRwulsPpdSuohGeeth"

    const/4 v4, 0x5

    const-string v0, "XuhleGopsRhsewPudS"

    const-string v0, "XGPushShowedResult"

    const/4 v3, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x0

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x7

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-string/jumbo v1, "ldshg[sPqXtGIumeo h w= uSRes"

    const/4 v4, 0x3

    const-string/jumbo v1, "wsP sm [q dl=XeuRghdIeohsGut"

    const-string v1, "XGPushShowedResult [msgId = "

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    iget-wide v1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->a:J

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    const-string/jumbo v1, "lts= t,  e"

    const-string v1, "=est ,l  t"

    const/4 v4, 0x5

    const-string v1, ", title = "

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->b:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string v1, " emm ,nnct ="

    const-string/jumbo v1, "o cmne,= tn "

    const/4 v4, 0x6

    const-string v1, " encont = o,"

    const-string v1, ", content = "

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->c:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    const-string v1, "cntm btCotsno=o,"

    const-string/jumbo v1, "t onos=uttmCcn,o"

    const/4 v4, 0x2

    const-string/jumbo v1, "o=o,tcuesC nttnu"

    const-string v1, ", customContent="

    const/4 v3, 0x2

    and-int/2addr v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->d:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    const-string/jumbo v1, "y iatctpb vi="

    const-string/jumbo v1, "t=iaybi  ctv,"

    const/4 v4, 0x2

    const-string v1, " ,ii =v qtaty"

    const-string v1, ", activity = "

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->e:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const-string v1, "f=sAi Tnoa eiyoonttcptnuci,"

    const-string v1, "ai=t,nuTifn occnoyoieAt ipt"

    const/4 v4, 0x6

    const-string/jumbo v1, "ntimc,onfAticeoya ip= oni T"

    const-string v1, ", notificationActionType = "

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget v1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->g:I

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x1

    const-string/jumbo v1, "nlhpo  n=auhCep "

    const-string v1, "=nsahhup n l Cep"

    const/4 v4, 0x7

    const-string v1, "h=uahb pCsnel, n"

    const-string v1, ", pushChannel = "

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x0

    iget v1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->h:I

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x4

    const-string/jumbo v1, "p  eaIud =eml,q"

    const-string v1, "d emlae qtI p,="

    const/4 v4, 0x3

    const-string v1, "a=,l ptpd te Ie"

    const-string v1, ", templateId = "

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->templateId:Ljava/lang/String;

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-string v1, ", dtc  eqas="

    const-string v1, "c=ste   rad,"

    const/4 v4, 0x5

    const-string v1, "c sr, Ie= td"

    const-string v1, ", traceId = "

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->traceId:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string/jumbo v1, "sLmmo =y uuso iattm"

    const-string/jumbo v1, "umamsoy ,i tso= tLu"

    const/4 v4, 0x0

    const-string/jumbo v1, "u  yoamtLosu=t Co,s"

    const-string v1, ", isCustomLayout = "

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x6

    iget-boolean v1, p0, Lcom/tencent/android/tpush/XGPushShowedResult;->i:Z

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x1

    const-string v1, "]"

    const-string v1, "]"

    const/4 v3, 0x3

    shl-int/2addr v4, v3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    return-object v0
.end method
