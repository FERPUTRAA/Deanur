.class public Lcom/tencent/android/tpush/XGServerInfo;
.super Ljava/lang/Object;


# static fields
.field public static final TAG_IP:Ljava/lang/String; = "ip"

.field public static final TAG_PORT:Ljava/lang/String; = "port"

.field public static final TAG_PROXY_IP:Ljava/lang/String; = "p_ip"

.field public static final TAG_PROXY_PORT:Ljava/lang/String; = "p_port"


# instance fields
.field private a:Lorg/json/JSONArray;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    new-instance v0, Lorg/json/JSONArray;

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGServerInfo;->a:Lorg/json/JSONArray;

    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x7

    new-instance v0, Lorg/json/JSONArray;

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/XGServerInfo;->a:Lorg/json/JSONArray;

    const/4 v2, 0x2

    const/4 v1, 0x3

    const/4 v2, 0x3

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x5

    if-nez v0, :cond_0

    :try_start_0
    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x5

    new-instance v0, Lorg/json/JSONArray;

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x4

    invoke-direct {v0, p1}, Lorg/json/JSONArray;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    iput-object v0, p0, Lcom/tencent/android/tpush/XGServerInfo;->a:Lorg/json/JSONArray;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_0
    :goto_0
    const/4 v2, 0x5

    return-void
.end method

.method private a(Ljava/lang/String;ILjava/lang/String;I)V
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "/ s~n@@@@ @o i~~u s~@@Kb~ b~1 ~to   @ r  @~~~~@ ~-@id M~ai ~y~cf~~@@f~ o@@/o.@@@~mo@4t S~o@v~b~l"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    invoke-static {p1}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    if-lez p2, :cond_1

    :try_start_0
    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x4

    new-instance v0, Lorg/json/JSONObject;

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-direct {v0}, Lorg/json/JSONObject;-><init>()V

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo v1, "pi"

    const-string/jumbo v1, "pi"

    const/4 v3, 0x4

    const-string/jumbo v1, "ip"

    const/4 v2, 0x0

    move v3, v2

    invoke-virtual {v0, v1, p1}, Lorg/json/JSONObject;->put(Ljava/lang/String;Ljava/lang/Object;)Lorg/json/JSONObject;

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x5

    const-string/jumbo p1, "oprt"

    const-string/jumbo p1, "tpro"

    const/4 v3, 0x2

    const-string/jumbo p1, "tpor"

    const-string/jumbo p1, "port"

    const/4 v3, 0x7

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-virtual {v0, p1, p2}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v3, 0x4

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-static {p3}, Landroid/text/TextUtils;->isEmpty(Ljava/lang/CharSequence;)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x6

    const/4 v3, 0x2

    if-nez p1, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x6

    const-string/jumbo p1, "pp_i"

    const-string/jumbo p1, "pp_i"

    const/4 v3, 0x7

    const-string/jumbo p1, "pip_"

    const-string/jumbo p1, "p_ip"

    const/4 v3, 0x3

    const/4 v2, 0x5

    invoke-virtual {v0, p1, p4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-string/jumbo p1, "rosm_p"

    const-string/jumbo p1, "opsr_t"

    const-string/jumbo p1, "pproo_"

    const-string/jumbo p1, "p_port"

    const/4 v3, 0x6

    const/4 v2, 0x1

    const/4 v3, 0x1

    invoke-virtual {v0, p1, p4}, Lorg/json/JSONObject;->put(Ljava/lang/String;I)Lorg/json/JSONObject;

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x2

    iget-object p1, p0, Lcom/tencent/android/tpush/XGServerInfo;->a:Lorg/json/JSONArray;

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x4

    invoke-virtual {p1, v0}, Lorg/json/JSONArray;->put(Ljava/lang/Object;)Lorg/json/JSONArray;
    :try_end_0
    .catch Lorg/json/JSONException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x0

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x0

    invoke-virtual {p1}, Ljava/lang/Throwable;->printStackTrace()V

    :cond_1
    :goto_0
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x1

    return-void
.end method


# virtual methods
.method public addServerIp(Ljava/lang/String;I)Lcom/tencent/android/tpush/XGServerInfo;
    .locals 4

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x2

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-direct {p0, p1, p2, v0, v1}, Lcom/tencent/android/tpush/XGServerInfo;->a(Ljava/lang/String;ILjava/lang/String;I)V

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x3

    return-object p0
.end method

.method public addServerIp(Ljava/lang/String;ILjava/lang/String;I)Lcom/tencent/android/tpush/XGServerInfo;
    .locals 2

    const/4 v0, 0x1

    move v1, v0

    invoke-direct {p0, p1, p2, p3, p4}, Lcom/tencent/android/tpush/XGServerInfo;->a(Ljava/lang/String;ILjava/lang/String;I)V

    const/4 v1, 0x4

    return-object p0
.end method

.method public getIpArray()Lorg/json/JSONArray;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGServerInfo;->a:Lorg/json/JSONArray;

    return-object v0
.end method

.method public isEmpty()Z
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    iget-object v0, p0, Lcom/tencent/android/tpush/XGServerInfo;->a:Lorg/json/JSONArray;

    const/4 v1, 0x0

    and-int/2addr v2, v1

    if-eqz v0, :cond_0

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-virtual {v0}, Lorg/json/JSONArray;->length()I

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x0

    if-lez v0, :cond_0

    const/4 v1, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    const/4 v0, 0x1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    goto :goto_0

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x2

    const/4 v0, 0x0

    :goto_0
    const/4 v2, 0x2

    const/4 v1, 0x2

    return v0
.end method

.method public reset()V
    .locals 3

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x1

    new-instance v0, Lorg/json/JSONArray;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-direct {v0}, Lorg/json/JSONArray;-><init>()V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/XGServerInfo;->a:Lorg/json/JSONArray;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x2

    return-void
.end method
