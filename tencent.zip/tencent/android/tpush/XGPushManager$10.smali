.class Lcom/tencent/android/tpush/XGPushManager$10;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:J

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:I

.field final synthetic f:Ljava/lang/String;

.field final synthetic g:Lcom/tencent/android/tpush/XGIOperateCallback;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x4

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$10;->a:Landroid/content/Context;

    const/4 v1, 0x0

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$10;->b:Ljava/lang/String;

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x0

    iput-wide p3, p0, Lcom/tencent/android/tpush/XGPushManager$10;->c:J

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x0

    iput-object p5, p0, Lcom/tencent/android/tpush/XGPushManager$10;->d:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x5

    iput p6, p0, Lcom/tencent/android/tpush/XGPushManager$10;->e:I

    const/4 v1, 0x5

    const/4 v0, 0x1

    iput-object p7, p0, Lcom/tencent/android/tpush/XGPushManager$10;->f:Ljava/lang/String;

    const/4 v0, 0x2

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p8, p0, Lcom/tencent/android/tpush/XGPushManager$10;->g:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x4

    const/4 v0, 0x7

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 11

    const-string v10, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v9, " @s~@ ~1K~o ~~n@4@M~  ~ ~st~@v@y @@@m@~@@@~ tfud~ao @ lib ~~~.~o~@-@of/@ oS oib@ b l~c i~/@ ~r~~"

    const-string v9, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$10;->a:Landroid/content/Context;

    const/4 v10, 0x6

    const/4 v9, 0x3

    const/4 v10, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x4

    if-eqz v0, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x6

    const/4 v10, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$10;->a:Landroid/content/Context;

    const/4 v10, 0x6

    const/4 v9, 0x4

    const/4 v10, 0x5

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->i(Landroid/content/Context;)Z

    move-result v0

    const/4 v10, 0x6

    const/4 v9, 0x3

    if-eqz v0, :cond_0

    const/4 v10, 0x1

    const/4 v9, 0x3

    const/4 v10, 0x7

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$10;->a:Landroid/content/Context;

    const/4 v10, 0x0

    const/4 v9, 0x3

    const/4 v10, 0x2

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$10;->b:Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v9, 0x5

    iget-wide v3, p0, Lcom/tencent/android/tpush/XGPushManager$10;->c:J

    const/4 v10, 0x5

    const/4 v9, 0x4

    const/4 v10, 0x6

    iget-object v5, p0, Lcom/tencent/android/tpush/XGPushManager$10;->d:Ljava/lang/String;

    const/4 v10, 0x5

    const/4 v9, 0x0

    const/4 v10, 0x5

    iget v6, p0, Lcom/tencent/android/tpush/XGPushManager$10;->e:I

    const/4 v10, 0x2

    const/4 v9, 0x0

    const/4 v10, 0x3

    iget-object v7, p0, Lcom/tencent/android/tpush/XGPushManager$10;->f:Ljava/lang/String;

    const/4 v10, 0x4

    const/4 v9, 0x4

    const/4 v10, 0x2

    iget-object v8, p0, Lcom/tencent/android/tpush/XGPushManager$10;->g:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v10, 0x4

    const/4 v9, 0x0

    const/4 v10, 0x6

    invoke-static/range {v1 .. v8}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;JLjava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v10, 0x0

    const/4 v9, 0x1

    const/4 v10, 0x5

    goto :goto_0

    :cond_0
    const/4 v10, 0x2

    const/4 v9, 0x2

    const/4 v10, 0x5

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$10$1;

    const/4 v9, 0x6

    move v10, v9

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/XGPushManager$10$1;-><init>(Lcom/tencent/android/tpush/XGPushManager$10;)V

    const/4 v10, 0x3

    const/4 v9, 0x0

    const/4 v10, 0x1

    new-instance v1, Lcom/tencent/android/tpush/XGPushManager$d;

    const/4 v10, 0x1

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$10;->g:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v10, 0x6

    const-string v3, "canmsto"

    const-string/jumbo v3, "onsatuc"

    const-string/jumbo v3, "noacouc"

    const-string v3, "account"

    const/4 v10, 0x5

    invoke-direct {v1, v2, v0, v3}, Lcom/tencent/android/tpush/XGPushManager$d;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;Lcom/tencent/tpns/baseapi/base/util/TTask;Ljava/lang/String;)V

    const/4 v10, 0x3

    const/4 v9, 0x6

    const/4 v10, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$10;->a:Landroid/content/Context;

    const/4 v9, 0x5

    move v10, v9

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/XGPushManager;->registerPush(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    :goto_0
    const/4 v10, 0x4

    return-void
.end method
