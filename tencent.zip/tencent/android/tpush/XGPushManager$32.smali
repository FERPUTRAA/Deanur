.class Lcom/tencent/android/tpush/XGPushManager$32;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/XGIOperateCallback;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->upsertAccounts(Landroid/content/Context;Ljava/lang/String;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Ljava/lang/String;


# direct methods
.method constructor <init>(Ljava/lang/String;)V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x6

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$32;->a:Ljava/lang/String;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x4

    return-void
.end method


# virtual methods
.method public onFail(Ljava/lang/Object;ILjava/lang/String;)V
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "@is~~b ~ o@~@@ no~ o ~ds@.4 ~~~i  ~fof~/ ~ b~ @ @@@@@a tK@l@@~ u~1 M@l/~Sib  @v~~o@m-~@y~c~~@or@"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x6

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x2

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x1

    const-string/jumbo v0, "sunm aocpT dNpeAPcS"

    const-string v0, "cTsnN e AdtaopcSPpu"

    const-string v0, "ccuNoodTpaPnS eptn "

    const-string v0, "TPNS appendAccount "

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$32;->a:Ljava/lang/String;

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x3

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x5

    const-string v0, "Cd i,befre  mla  deo"

    const-string v0, "i rm eo eC=da,e  fdl"

    const-string v0, "Ceoldiu, =  d  earer"

    const-string v0, " failed, errCode =  "

    const/4 v2, 0x0

    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x6

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x7

    const-string/jumbo p2, "o , =s p"

    const-string p2, ",s= om  "

    const/4 v2, 0x4

    const-string/jumbo p2, "q=g  s m"

    const-string p2, ", msg = "

    const/4 v1, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    move v2, v1

    invoke-virtual {p1, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    const-string/jumbo p2, "rGsnhaPaXguMb"

    const-string p2, "aMruPbhXGasgn"

    const/4 v2, 0x3

    const-string p2, "XGPushManager"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ee(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x1

    return-void
.end method

.method public onSuccess(Ljava/lang/Object;I)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x7

    const/4 v1, 0x3

    new-instance p1, Ljava/lang/StringBuilder;

    const/4 v1, 0x4

    const/4 v0, 0x6

    const/4 v1, 0x1

    invoke-direct {p1}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x6

    const/4 v1, 0x2

    const-string/jumbo p2, "peAmotaS T nNdcPpun"

    const-string p2, "TPNS appendAccount "

    const/4 v0, 0x3

    and-int/2addr v1, v0

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x5

    iget-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$32;->a:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x5

    const/4 v1, 0x1

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x7

    const/4 v0, 0x6

    const/4 v1, 0x7

    const-string/jumbo p2, "scu ousc"

    const-string p2, " sccsuus"

    const/4 v1, 0x0

    const-string/jumbo p2, "s csebus"

    const-string p2, " success"

    const/4 v1, 0x1

    const/4 v0, 0x7

    const/4 v1, 0x4

    invoke-virtual {p1, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v1, 0x1

    const/4 v0, 0x5

    const/4 v1, 0x2

    const-string p2, "PaXnMhuGguepa"

    const-string p2, "XMunaaGpPrheg"

    const/4 v1, 0x2

    const-string/jumbo p2, "saXPnerpahuGg"

    const-string p2, "XGPushManager"

    const/4 v1, 0x2

    const/4 v0, 0x0

    const/4 v1, 0x6

    invoke-static {p2, p1}, Lcom/tencent/android/tpush/logging/TLogger;->ii(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x2

    const/4 v1, 0x7

    return-void
.end method
