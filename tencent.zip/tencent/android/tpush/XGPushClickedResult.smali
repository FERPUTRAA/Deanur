.class public Lcom/tencent/android/tpush/XGPushClickedResult;
.super Ljava/lang/Object;

# interfaces
.implements Lcom/tencent/android/tpush/XGIResult;
.implements Ljava/io/Serializable;


# static fields
.field public static final NOTIFACTION_CLICKED_TYPE:I

.field public static final NOTIFACTION_DELETED_TYPE:I

.field public static final NOTIFACTION_DOWNLOAD_CANCEL_TYPE:I

.field public static final NOTIFACTION_DOWNLOAD_TYPE:I

.field public static final NOTIFACTION_OPEN_CANCEL_TYPE:I

.field public static final NOTIFACTION_OPEN_TYPE:I

.field public static final NOTIFICATION_ACTION_ACTIVITY:I

.field private static final TAG:Ljava/lang/String; = "XGPushClickedResult"

.field private static final serialVersionUID:J = 0x4c1f95f7e5ba3b43L


# instance fields
.field actionType:I

.field activityName:Ljava/lang/String;

.field content:Ljava/lang/String;

.field customContent:Ljava/lang/String;

.field isCustomLayout:Z

.field msgId:J

.field notificationActionType:I

.field pushChannel:I

.field templateId:Ljava/lang/String;

.field title:Ljava/lang/String;

.field traceId:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .locals 3

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->clicked:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x3

    sput v0, Lcom/tencent/android/tpush/XGPushClickedResult;->NOTIFACTION_CLICKED_TYPE:I

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    sput v0, Lcom/tencent/android/tpush/XGPushClickedResult;->NOTIFICATION_ACTION_ACTIVITY:I

    const/4 v1, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->delete:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x0

    sput v0, Lcom/tencent/android/tpush/XGPushClickedResult;->NOTIFACTION_DELETED_TYPE:I

    const/4 v2, 0x2

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->open:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x3

    sput v0, Lcom/tencent/android/tpush/XGPushClickedResult;->NOTIFACTION_OPEN_TYPE:I

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x4

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->open_cancel:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x0

    sput v0, Lcom/tencent/android/tpush/XGPushClickedResult;->NOTIFACTION_OPEN_CANCEL_TYPE:I

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x0

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->download:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x5

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x0

    const/4 v2, 0x2

    sput v0, Lcom/tencent/android/tpush/XGPushClickedResult;->NOTIFACTION_DOWNLOAD_TYPE:I

    const/4 v2, 0x6

    const/4 v1, 0x2

    const/4 v2, 0x3

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->download_cancel:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    sput v0, Lcom/tencent/android/tpush/XGPushClickedResult;->NOTIFACTION_DOWNLOAD_CANCEL_TYPE:I

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x5

    return-void
.end method

.method public constructor <init>()V
    .locals 4

    const/4 v2, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x4

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x3

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x4

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->msgId:J

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const-string v0, ""

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->title:Ljava/lang/String;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->content:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x5

    const/4 v3, 0x2

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->customContent:Ljava/lang/String;

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    const/4 v2, 0x2

    move v3, v2

    sget-object v1, Lcom/tencent/android/tpush/NotificationAction;->clicked:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v1

    const/4 v3, 0x3

    iput v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->actionType:I

    const/4 v3, 0x5

    const/4 v2, 0x6

    sget-object v1, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-virtual {v1}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x4

    iput v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->notificationActionType:I

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/16 v1, 0x64

    const/4 v2, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    iput v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->pushChannel:I

    const/4 v2, 0x0

    move v3, v2

    const/4 v1, 0x0

    move v3, v1

    const/4 v2, 0x3

    const/4 v3, 0x7

    iput-boolean v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->isCustomLayout:Z

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->templateId:Ljava/lang/String;

    const/4 v3, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->traceId:Ljava/lang/String;

    const/4 v2, 0x2

    xor-int/2addr v3, v2

    return-void
.end method


# virtual methods
.method public getActionType()J
    .locals 4

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, " bsc@ u@~K@ @~t /oli~o  ~ b@@~ ~~~@~.@~~4o@~ rat~@@ /~@ @s~ @ foS~1l @vdMn~ o-~y@ib~ ~o@ mfi@@~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x0

    iget v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->actionType:I

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x0

    int-to-long v0, v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    return-wide v0
.end method

.method public getActivityName()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x1

    return-object v0
.end method

.method public getContent()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->content:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public getCustomContent()Ljava/lang/String;
    .locals 3

    const/4 v1, 0x2

    move v2, v1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->customContent:Ljava/lang/String;

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x4

    return-object v0
.end method

.method public getMsgId()J
    .locals 4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x7

    iget-wide v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->msgId:J

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x6

    return-wide v0
.end method

.method public getNotificationActionType()I
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x4

    iget v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->notificationActionType:I

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method

.method public getPushChannel()I
    .locals 3

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x0

    iget v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->pushChannel:I

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    return v0
.end method

.method public getTemplateId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->templateId:Ljava/lang/String;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x2

    return-object v0
.end method

.method public getTitle()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->title:Ljava/lang/String;

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object v0
.end method

.method public getTraceId()Ljava/lang/String;
    .locals 3

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->traceId:Ljava/lang/String;

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x4

    return-object v0
.end method

.method public isCustomLayout()Z
    .locals 3

    const/4 v2, 0x7

    iget-boolean v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->isCustomLayout:Z

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x2

    return v0
.end method

.method public parseIntent(Landroid/content/Intent;)V
    .locals 5

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v0, "dmgms"

    const-string/jumbo v0, "mgsds"

    const/4 v4, 0x0

    const-string v0, "Imsdo"

    const-string/jumbo v0, "msgId"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-wide/16 v1, -0x1

    const-wide/16 v1, -0x1

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {p1, v0, v1, v2}, Landroid/content/Intent;->getLongExtra(Ljava/lang/String;J)J

    move-result-wide v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x1

    iput-wide v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->msgId:J

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string/jumbo v0, "itmicbav"

    const-string/jumbo v0, "itcmiavy"

    const/4 v4, 0x4

    const-string/jumbo v0, "tiiytcuv"

    const-string v0, "activity"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x4

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v0, "eopit"

    const-string/jumbo v0, "teito"

    const/4 v4, 0x5

    const-string/jumbo v0, "ittqe"

    const-string/jumbo v0, "title"

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x0

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->title:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v0, "btscetn"

    const-string v0, "eottnbc"

    const/4 v4, 0x3

    const-string/jumbo v0, "ottmnec"

    const-string v0, "content"

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->content:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const-string/jumbo v0, "ucnooesnocttm_"

    const-string/jumbo v0, "t_snncutecomot"

    const/4 v4, 0x5

    const-string/jumbo v0, "tnu_nbcsotetcm"

    const-string v0, "custom_content"

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {v0}, Lcom/tencent/android/tpush/encrypt/Rijndael;->decrypt(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x1

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->customContent:Ljava/lang/String;

    const/4 v3, 0x2

    move v4, v3

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->clicked:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const-string/jumbo v1, "ucnoit"

    const-string v1, "action"

    const/4 v4, 0x2

    const/4 v3, 0x3

    invoke-virtual {p1, v1, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    iput v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->actionType:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x6

    sget-object v0, Lcom/tencent/android/tpush/NotificationAction;->activity:Lcom/tencent/android/tpush/NotificationAction;

    const/4 v4, 0x4

    invoke-virtual {v0}, Lcom/tencent/android/tpush/NotificationAction;->getType()I

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    const-string v1, "encaoiopotnTytAinficpi"

    const/4 v4, 0x2

    const-string v1, "cftitiaponpAyTinntoeic"

    const-string/jumbo v1, "notificationActionType"

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    invoke-virtual {p1, v1, v0}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    iput v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->notificationActionType:I

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    const-string v0, "PCq.NUSAqEHH"

    const-string v0, "ECHSUALNqHP."

    const/4 v4, 0x1

    const-string v0, "UHsLS.HECPAN"

    const-string v0, "PUSH.CHANNEL"

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x6

    const/16 v1, 0x64

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    iput v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->pushChannel:I

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    const-string v0, "dIlmstaeep"

    const-string v0, "eesadplttI"

    const/4 v4, 0x2

    const-string/jumbo v0, "tlteopamdI"

    const-string/jumbo v0, "templateId"

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x7

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->templateId:Ljava/lang/String;

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string/jumbo v0, "rdamIbt"

    const-string v0, "Idtmaer"

    const/4 v4, 0x6

    const-string v0, "eItcaru"

    const-string/jumbo v0, "traceId"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p1, v0}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    iput-object v0, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->traceId:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo v0, "ssutoLopatyCim"

    const-string/jumbo v0, "utasoosuLCmity"

    const-string/jumbo v0, "tiyLamuuqtssCo"

    const-string/jumbo v0, "isCustomLayout"

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x0

    const/4 v1, 0x0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {p1, v0, v1}, Landroid/content/Intent;->getBooleanExtra(Ljava/lang/String;Z)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    iput-boolean p1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->isCustomLayout:Z

    const/4 v3, 0x1

    const/4 v3, 0x6

    iget p1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->pushChannel:I

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/16 v0, 0x65

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-eq p1, v0, :cond_0

    const/4 v4, 0x0

    const/16 v0, 0x63

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    if-ne p1, v0, :cond_1

    :cond_0
    :try_start_0
    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x1

    iget-object p1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v0, "FTs8U"

    const-string v0, "bF8TU"

    const/4 v4, 0x2

    const-string v0, "-T8mF"

    const-string v0, "UTF-8"

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-static {p1, v0}, Ljava/net/URLDecoder;->decode(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;
    :try_end_0
    .catch Ljava/io/UnsupportedEncodingException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    goto :goto_0

    :catch_0
    move-exception p1

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x1

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    const-string/jumbo v1, "rIm:oiantiateettpnNsc  uye"

    const-string/jumbo v1, "vyetiiunmneatt acptIr :Nse"

    const/4 v4, 0x2

    const-string v1, " vpatbiyenrtetisnacNmIa te"

    const-string/jumbo v1, "parseIntent activityName :"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x1

    or-int/2addr v4, v3

    invoke-virtual {p1}, Ljava/lang/Object;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x3

    const-string/jumbo v0, "uclPdeutkCsRGsuiehX"

    const-string v0, "huCldiPpktcReXGsesu"

    const/4 v4, 0x0

    const-string/jumbo v0, "leutlsipekchCGXdsuP"

    const-string v0, "XGPushClickedResult"

    const/4 v4, 0x0

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {v0, p1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    :cond_1
    :goto_0
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    return-void
.end method

.method public toString()Ljava/lang/String;
    .locals 5

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    new-instance v0, Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    move v4, v3

    invoke-direct {v0}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v4, 0x0

    const-string/jumbo v1, "lCdsqPsXqsRmGeu kuli g= Ite[d"

    const-string v1, "edCkcgliq[sse t =P udlXRImusG"

    const/4 v4, 0x2

    const-string/jumbo v1, "ses dXllgiCesdsR =GuhuPt[mkc "

    const-string v1, "XGPushClickedResult [msgId = "

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x5

    iget-wide v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->msgId:J

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v0, v1, v2}, Ljava/lang/StringBuilder;->append(J)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const-string/jumbo v1, "tes tli , "

    const-string/jumbo v1, "tes tli , "

    const/4 v4, 0x0

    const-string v1, " l=mt it ,"

    const-string v1, ", title = "

    const/4 v3, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x6

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->title:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x0

    const-string/jumbo v1, "otetom ncn, "

    const-string v1, "ec m,n tt no"

    const/4 v4, 0x7

    const-string/jumbo v1, "n ectb ,not="

    const-string v1, ", content = "

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->content:Ljava/lang/String;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v1, " toos,ue tCo n=mun"

    const-string v1, "=oCsontt n oeu t,m"

    const/4 v4, 0x4

    const-string/jumbo v1, "tenmosop  ,=t cnut"

    const-string v1, ", customContent = "

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->customContent:Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v1, " im=atyvqaic etbN"

    const-string v1, " e mabyi=vctiN,at"

    const/4 v4, 0x0

    const-string/jumbo v1, "vtsc im e,aati= N"

    const-string v1, ", activityName = "

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->activityName:Ljava/lang/String;

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string/jumbo v1, "t um ep ony,ic="

    const-string v1, "=a  nyuocet, pi"

    const/4 v4, 0x1

    const-string v1, "iao oec  ,nT=yt"

    const-string v1, ", actionType = "

    const/4 v4, 0x5

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x3

    iget v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->actionType:I

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    const-string v1, " p s,bnhne=p huC"

    const-string/jumbo v1, "n,suehhpn l p=C "

    const/4 v4, 0x5

    const-string v1, "=hn ,euunhCla  s"

    const-string v1, ", pushChannel = "

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x4

    iget v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->pushChannel:I

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string/jumbo v1, "tpqycanpT  tneocnii Aoif=o,"

    const-string/jumbo v1, "ooinnTy=qAan t pietfi icco,"

    const/4 v4, 0x1

    const-string v1, "Tiino=  qopyiAnce ,tatfncto"

    const-string v1, ", notificationActionType = "

    const/4 v4, 0x0

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x5

    iget v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->notificationActionType:I

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x5

    const-string v1, "=dseatptI l e, "

    const-string v1, ", templateId = "

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x0

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->templateId:Ljava/lang/String;

    const/4 v4, 0x6

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v1, " Itm,r=dca e"

    const-string v1, "I sd r,eca=t"

    const/4 v4, 0x6

    const-string v1, "cta,o  reI= "

    const-string v1, ", traceId = "

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->traceId:Ljava/lang/String;

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x3

    const-string v1, " tmi bLs ya=mtos,uC"

    const-string v1, "Cosm, ttu  Limy=sau"

    const/4 v4, 0x1

    const-string/jumbo v1, "t =smuusC,oyi u oaL"

    const-string v1, ", isCustomLayout = "

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x4

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x3

    iget-boolean v1, p0, Lcom/tencent/android/tpush/XGPushClickedResult;->isCustomLayout:Z

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    const/4 v3, 0x7

    const/4 v3, 0x4

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x7

    const-string v1, "]"

    const-string v1, "]"

    const/4 v4, 0x5

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v3, 0x4

    xor-int/2addr v4, v3

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x6

    return-object v0
.end method
