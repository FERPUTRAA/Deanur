.class Lcom/tencent/android/tpush/XGPushManager$3;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->b(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;

.field final synthetic b:Ljava/lang/String;

.field final synthetic c:I

.field final synthetic d:Ljava/lang/String;

.field final synthetic e:Lcom/tencent/android/tpush/XGIOperateCallback;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x0

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$3;->a:Landroid/content/Context;

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$3;->b:Ljava/lang/String;

    const/4 v1, 0x6

    const/4 v0, 0x0

    const/4 v1, 0x0

    iput p3, p0, Lcom/tencent/android/tpush/XGPushManager$3;->c:I

    const/4 v1, 0x3

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p4, p0, Lcom/tencent/android/tpush/XGPushManager$3;->d:Ljava/lang/String;

    const/4 v1, 0x4

    iput-object p5, p0, Lcom/tencent/android/tpush/XGPushManager$3;->e:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x5

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x7

    const/4 v1, 0x0

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, "@osbmic~ ~/@d~o@~~i @ ~  ~ /Mf@snl@~~t~  @oSvf@ ~ ~l~ u  @@ba. 1~~@  K~- o4i~@@@@oo~@@b@~y~~rt@@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$3;->a:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;)Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x0

    const/4 v6, 0x0

    if-eqz v0, :cond_0

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$3;->a:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x2

    invoke-static {v0}, Lcom/tencent/android/tpush/common/j;->i(Landroid/content/Context;)Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x2

    const/4 v6, 0x2

    if-eqz v0, :cond_0

    const/4 v6, 0x7

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$3;->a:Landroid/content/Context;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x4

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$3;->b:Ljava/lang/String;

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x1

    iget v2, p0, Lcom/tencent/android/tpush/XGPushManager$3;->c:I

    const/4 v6, 0x1

    const/4 v5, 0x4

    iget-object v3, p0, Lcom/tencent/android/tpush/XGPushManager$3;->d:Ljava/lang/String;

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x2

    iget-object v4, p0, Lcom/tencent/android/tpush/XGPushManager$3;->e:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v6, 0x0

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v0, v1, v2, v3, v4}, Lcom/tencent/android/tpush/XGPushManager;->a(Landroid/content/Context;Ljava/lang/String;ILjava/lang/String;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    const/4 v6, 0x6

    const/4 v5, 0x3

    goto :goto_0

    :cond_0
    const/4 v6, 0x4

    new-instance v0, Lcom/tencent/android/tpush/XGPushManager$3$1;

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-direct {v0, p0}, Lcom/tencent/android/tpush/XGPushManager$3$1;-><init>(Lcom/tencent/android/tpush/XGPushManager$3;)V

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x7

    new-instance v1, Lcom/tencent/android/tpush/XGPushManager$d;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$3;->e:Lcom/tencent/android/tpush/XGIOperateCallback;

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x4

    const-string v3, "ertmitasbu"

    const-string/jumbo v3, "rtsiebatus"

    const/4 v6, 0x4

    const-string v3, "ebitostaut"

    const-string v3, "attributes"

    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-direct {v1, v2, v0, v3}, Lcom/tencent/android/tpush/XGPushManager$d;-><init>(Lcom/tencent/android/tpush/XGIOperateCallback;Lcom/tencent/tpns/baseapi/base/util/TTask;Ljava/lang/String;)V

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x6

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$3;->a:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/XGPushManager;->registerPush(Landroid/content/Context;Lcom/tencent/android/tpush/XGIOperateCallback;)V

    :goto_0
    const/4 v6, 0x4

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-void
.end method
