.class Lcom/tencent/android/tpush/XGPushManager$29;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushManager;->onOtherPushRegister(Landroid/content/Context;Landroid/content/Intent;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Intent;

.field final synthetic b:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Intent;Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushManager$29;->a:Landroid/content/Intent;

    const/4 v0, 0x3

    const/4 v0, 0x6

    const/4 v1, 0x5

    iput-object p2, p0, Lcom/tencent/android/tpush/XGPushManager$29;->b:Landroid/content/Context;

    const/4 v1, 0x5

    const/4 v0, 0x0

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x3

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 7

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v5, " @s b~ ~@/fi~ ~ ~b~ S@@ ro~mit~ n~o~  ovl@y@~~a~o~ -@l4i ~b~M@t~@@f@~.@c@@o@ K~/u  @@ ~o@1 s~~d@"

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v6, 0x7

    const-string v0, "XuMmasaPGngsh"

    const-string/jumbo v0, "uXsagnhPsGMar"

    const/4 v6, 0x2

    const-string v0, "greuoXnGhsPaa"

    const-string v0, "XGPushManager"

    const/4 v6, 0x4

    const-string v1, " essebtOinrrRtmexgcuuPhoet"

    const-string/jumbo v1, "tsxmtePrOhreiReuenotsg huc"

    const-string v1, "cerusOuthrentoRsiu eeehtPg"

    const-string v1, "excute onOtherPushRegister"

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/logging/TLogger;->d(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v6, 0x1

    const/4 v5, 0x5

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$29;->a:Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x1

    const-string v1, "TETHEPKpOEURYoOHTUSKN.PH"

    const-string v1, "HEHEoUPTOOYSPKRKT.SEUNTH"

    const/4 v6, 0x0

    const-string v1, "N.UK.PUHqHTEHTESOKSTPYEO"

    const-string v1, "TPUSH.OTHERPUSH.TOKENKEY"

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x3

    invoke-virtual {v0, v1}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x5

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$29;->a:Landroid/content/Intent;

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x7

    const-string/jumbo v2, "nksot_ehesprbhut"

    const-string/jumbo v2, "nurpkbeo_tsheth_"

    const/4 v6, 0x0

    const-string v2, "ehtm__stoukhonep"

    const-string/jumbo v2, "other_push_token"

    const/4 v6, 0x7

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-virtual {v1, v2}, Landroid/content/Intent;->getStringExtra(Ljava/lang/String;)Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$29;->a:Landroid/content/Intent;

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x7

    const-string v3, "HNSHoLPAUuEN"

    const-string v3, "HUHPSLuNAN.E"

    const/4 v6, 0x5

    const-string v3, "PUSH.CHANNEL"

    const/4 v6, 0x4

    const/4 v5, 0x3

    const/4 v6, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x3

    or-int/2addr v6, v5

    invoke-virtual {v2, v3, v4}, Landroid/content/Intent;->getIntExtra(Ljava/lang/String;I)I

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x6

    const/16 v3, 0x64

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-eq v2, v3, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x5

    const/4 v6, 0x3

    invoke-static {v0}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x1

    const/4 v5, 0x7

    const/4 v6, 0x0

    if-nez v2, :cond_0

    const/4 v6, 0x6

    invoke-static {v1}, Lcom/tencent/android/tpush/service/util/h;->a(Ljava/lang/String;)Z

    move-result v2

    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x0

    if-nez v2, :cond_0

    const/4 v6, 0x5

    const/4 v5, 0x0

    const/4 v6, 0x0

    iget-object v2, p0, Lcom/tencent/android/tpush/XGPushManager$29;->b:Landroid/content/Context;

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x0

    invoke-static {v2, v0, v1}, Lcom/tencent/android/tpush/service/util/SharePrefsUtil;->setString(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V

    :cond_0
    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$29;->a:Landroid/content/Intent;

    const/4 v6, 0x0

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$29;->b:Landroid/content/Context;

    const/4 v6, 0x2

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-virtual {v1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    move-result-object v1

    const/4 v6, 0x2

    const/4 v5, 0x0

    const/4 v6, 0x5

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setPackage(Ljava/lang/String;)Landroid/content/Intent;

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x0

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushManager$29;->b:Landroid/content/Context;

    iget-object v1, p0, Lcom/tencent/android/tpush/XGPushManager$29;->a:Landroid/content/Intent;

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x7

    invoke-static {v0, v1}, Lcom/tencent/android/tpush/common/BroadcastAgent;->sendBroadcast(Landroid/content/Context;Landroid/content/Intent;)V

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x3

    return-void
.end method
