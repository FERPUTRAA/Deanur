.class Lcom/tencent/android/tpush/XGPushConfig$3;
.super Lcom/tencent/tpns/baseapi/base/util/TTask;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/tencent/android/tpush/XGPushConfig;->setUseFcmFirst(Landroid/content/Context;Z)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x0
    name = null
.end annotation


# instance fields
.field final synthetic a:Landroid/content/Context;


# direct methods
.method constructor <init>(Landroid/content/Context;)V
    .locals 2

    const/4 v1, 0x5

    iput-object p1, p0, Lcom/tencent/android/tpush/XGPushConfig$3;->a:Landroid/content/Context;

    invoke-direct {p0}, Lcom/tencent/tpns/baseapi/base/util/TTask;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x4

    return-void
.end method


# virtual methods
.method public TRun()V
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "fss @oo /@@1~@ ~K@~amM@ b .~u@@@il@i~odr @~n~4@~@S  ~~@ib@ b@  @o~~v~  o/l~f~t~ @c~~ - @ ~ot~~~y"

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$3;->a:Landroid/content/Context;

    const/4 v5, 0x7

    const/4 v4, 0x4

    const/4 v5, 0x0

    const/4 v1, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const-wide/16 v2, -0x1

    const/4 v5, 0x0

    invoke-static {v0, v1, v2, v3}, Lcom/tencent/android/tpush/XGPushManager;->loadOtherPushToken(Landroid/content/Context;ZJ)Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x2

    iget-object v0, p0, Lcom/tencent/android/tpush/XGPushConfig$3;->a:Landroid/content/Context;

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-static {v0}, Lcom/tencent/android/tpush/d/b;->a(Landroid/content/Context;)V

    const/4 v4, 0x2

    const/4 v5, 0x1

    return-void
.end method
