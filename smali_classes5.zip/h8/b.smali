.class public interface abstract annotation Lh8/b;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation runtime La8/f;
    allowedTargets = {
        .enum La8/b;->i:La8/b;,
        .enum La8/b;->d:La8/b;
    }
.end annotation

.annotation runtime Ljava/lang/annotation/Retention;
    value = .enum Ljava/lang/annotation/RetentionPolicy;->RUNTIME:Ljava/lang/annotation/RetentionPolicy;
.end annotation

.annotation runtime Ljava/lang/annotation/Target;
    value = {
        .enum Ljava/lang/annotation/ElementType;->METHOD:Ljava/lang/annotation/ElementType;
    }
.end annotation

.annotation build Lkotlin/g1;
    version = "1.2"
.end annotation

.annotation runtime Lkotlin/k;
    level = .enum Lkotlin/m;->b:Lkotlin/m;
    message = "Switch to new -Xjvm-default modes: `all` or `all-compatibility`"
.end annotation
