.class public interface abstract annotation Lh8/j;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation runtime La8/c;
.end annotation

.annotation runtime La8/e;
    value = .enum La8/a;->a:La8/a;
.end annotation

.annotation runtime La8/f;
    allowedTargets = {
        .enum La8/b;->n:La8/b;
    }
.end annotation

.annotation runtime Ljava/lang/annotation/Documented;
.end annotation

.annotation runtime Ljava/lang/annotation/Retention;
    value = .enum Ljava/lang/annotation/RetentionPolicy;->SOURCE:Ljava/lang/annotation/RetentionPolicy;
.end annotation

.annotation runtime Ljava/lang/annotation/Target;
    value = {}
.end annotation

.annotation build Lkotlin/g1;
    version = "1.2"
.end annotation


# virtual methods
.method public abstract name()Ljava/lang/String;
.end method
