.class public Lh8/q;
.super Ljava/lang/Error;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string v0, "efsu pn oenekeaousiauivi pfscaot ooitnlnlfint hcl.tilrec rnyneKortsmn.ei sehjs mhlti te  ortmnled trakeaaat- t M"

    const-string v0, "slsecat nham tiltit.nkio  ntitnouae eKpendlrtsitneaahetkhernMjl c re lficav uifuly irsoen.a om  m or ftnoepest-o"

    const/4 v2, 0x7

    const-string v0, "m lminan atotmuesitepc  M ton vnee lasytandteotmttt-o cpaonairern lo lhfe.ro srslhinu.hiklkueefnauc K rfi ietji "

    const-string v0, "Kotlin reflection implementation is not found at runtime. Make sure you have kotlin-reflect.jar in the classpath"

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-direct {p0, v0}, Ljava/lang/Error;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;)V
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x3

    const/4 v0, 0x3

    const/4 v1, 0x3

    invoke-direct {p0, p1}, Ljava/lang/Error;-><init>(Ljava/lang/String;)V

    const/4 v1, 0x7

    const/4 v0, 0x6

    return-void
.end method

.method public constructor <init>(Ljava/lang/String;Ljava/lang/Throwable;)V
    .locals 2
    .param p1    # Ljava/lang/String;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p2    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v1, 0x6

    invoke-direct {p0, p1, p2}, Ljava/lang/Error;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    const/4 v1, 0x3

    const/4 v0, 0x0

    return-void
.end method

.method public constructor <init>(Ljava/lang/Throwable;)V
    .locals 2
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param

    const/4 v0, 0x1

    const/4 v0, 0x3

    const/4 v1, 0x6

    invoke-direct {p0, p1}, Ljava/lang/Error;-><init>(Ljava/lang/Throwable;)V

    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x6

    return-void
.end method
