.class public interface abstract annotation Lh8/h;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation runtime La8/c;
.end annotation

.annotation runtime La8/e;
    value = .enum La8/a;->b:La8/a;
.end annotation

.annotation runtime La8/f;
    allowedTargets = {
        .enum La8/b;->i:La8/b;,
        .enum La8/b;->j:La8/b;,
        .enum La8/b;->k:La8/b;,
        .enum La8/b;->n:La8/b;
    }
.end annotation

.annotation runtime Ljava/lang/annotation/Documented;
.end annotation

.annotation runtime Ljava/lang/annotation/Retention;
    value = .enum Ljava/lang/annotation/RetentionPolicy;->CLASS:Ljava/lang/annotation/RetentionPolicy;
.end annotation

.annotation runtime Ljava/lang/annotation/Target;
    value = {
        .enum Ljava/lang/annotation/ElementType;->METHOD:Ljava/lang/annotation/ElementType;
    }
.end annotation


# virtual methods
.method public abstract name()Ljava/lang/String;
.end method
