.class public final Lh8/a;
.super Ljava/lang/Object;


# annotations
.annotation build Lh8/h;
    name = "JvmClassMappingKt"
.end annotation


# direct methods
.method public static final a(Ljava/lang/annotation/Annotation;)Lkotlin/reflect/d;
    .locals 3
    .param p0    # Ljava/lang/annotation/Annotation;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/annotation/Annotation;",
            ">(TT;)",
            "Lkotlin/reflect/d<",
            "+TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    const-string v0, "><shts"

    const-string v0, "t>si<h"

    const/4 v2, 0x0

    const-string v0, "<this>"

    const/4 v2, 0x5

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    invoke-interface {p0}, Ljava/lang/annotation/Annotation;->annotationType()Ljava/lang/Class;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x0

    const-string/jumbo v0, "tetm2otona .n(2ay.6a)t)/sjna nvtTuapiimnoanoahngiatl0so"

    const-string/jumbo v0, "tstmjaht aa.oi(igT)ootnas0en2y oaatt2a.vin)nnunao/6panl"

    const-string/jumbo v0, "tsoao)t0/ngsa(onalo .Toa tin.tptui2oivyaj2aa6t.eanannn)"

    const-string/jumbo v0, "this as java.lang.annota\u2026otation).annotationType()"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p0}, Lh8/a;->i(Ljava/lang/Class;)Lkotlin/reflect/d;

    move-result-object p0

    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string v0, "syttabjnalt.tTiKltnneemonrun<nCl-elle.ouCfosm>J .n i.l ea o lnifb ntictlot-g< o.Mattscooalnon>an ptvssgkspl okatucas KC"

    const-string v0, "olulofoe -Csun<lnKo.p  l>b ite>taugnlsJ nrgovntcials- nlKttoksajtsC.T.meankomtCotnil.va Ms tnto.aafanntlo eespnct<ylic "

    const/4 v2, 0x4

    const-string v0, "nnfosrut.avJlC.otltK<j-mloocsnspntuneo caCtio ntiba Ts. aktlntgefiett in k>san Kc<-l >Cen.g.aus latMloseppvu lmolylnont"

    const-string v0, "null cannot be cast to non-null type kotlin.reflect.KClass<out T of kotlin.jvm.JvmClassMappingKt.<get-annotationClass>>"

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->n(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p0
.end method

.method private static final b(Ljava/lang/Enum;)Ljava/lang/Class;
    .locals 3
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<E:",
            "Ljava/lang/Enum<",
            "TE;>;>(",
            "Ljava/lang/Enum<",
            "TE;>;)",
            "Ljava/lang/Class<",
            "TE;>;"
        }
    .end annotation

    const/4 v2, 0x1

    const-string v0, ">pb<ts"

    const-string v0, "si><tb"

    const/4 v2, 0x5

    const-string v0, "hiq>ts"

    const-string v0, "<this>"

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/lang/Enum;->getDeclaringClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x7

    const-string v0, "aaslsvsne<aas.gdElct. uarChgi>sn.nEl)mji "

    const-string/jumbo v0, "this as java.lang.Enum<E>).declaringClass"

    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->o(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p0
.end method

.method public static synthetic c(Ljava/lang/Enum;)V
    .locals 2
    .annotation build Lkotlin/g1;
        version = "1.7"
    .end annotation

    .annotation build Lkotlin/internal/f;
    .end annotation

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x7

    return-void
.end method

.method public static final d(Ljava/lang/Object;)Ljava/lang/Class;
    .locals 3
    .param p0    # Ljava/lang/Object;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(TT;)",
            "Ljava/lang/Class<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x7

    const-string/jumbo v0, "thsm<i"

    const-string/jumbo v0, "utsih<"

    const/4 v2, 0x4

    const-string v0, "<this>"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x0

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string v0, "p-afoanlaaatn.JM<nle-.sbnlcseaa eagtTp.glCtt vk pn<ul.io co vlsolnj>mmjsngj >io poa lvCy.naCts navuKtsl"

    const-string v0, "mnaesM.p> sbav.saKllapinlnn o p<.CoafjnCjJgmatt-v. suint<o.nnao  tClkncvey-sa jstlplllogu taag vTlec>at"

    const/4 v2, 0x2

    const-string v0, "aspCab.a sotnlsvlk<ao-n.caanaa M>p vjsvsjg> a atgCCotenJ un. ii<flt.bsloynttoTj.Klltnn m-gevpallumcsnle"

    const-string v0, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-javaClass>>"

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x3

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->n(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x2

    return-object p0
.end method

.method public static final e(Lkotlin/reflect/d;)Ljava/lang/Class;
    .locals 3
    .param p0    # Lkotlin/reflect/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlin/reflect/d<",
            "TT;>;)",
            "Ljava/lang/Class<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lh8/h;
        name = "getJavaClass"
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x3

    const-string/jumbo v0, "uqs>th"

    const-string v0, "hiqt>s"

    const/4 v2, 0x1

    const-string v0, ">phsit"

    const-string v0, "<this>"

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x7

    check-cast p0, Lkotlin/jvm/internal/t;

    const/4 v1, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x5

    invoke-interface {p0}, Lkotlin/jvm/internal/t;->q()Ljava/lang/Class;

    move-result-object p0

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x6

    const-string v0, "Csol.bayqt fJval- ssnnponMngaa.laep jtlknc-jmCl<a>s o mpiKt. tjtnautn..c autlaelsvT<logovne as gin"

    const-string v0, "n sjmljojiJgvennk.oa.lvpc.t aatvnsoama.nlntyin tTtagl ColMfsa-tgp<a <leun>bpKaleac ssn v-o l sutC."

    const/4 v2, 0x7

    const-string v0, "g saeanna n ovmjosus. vnmnCtkel>lpJlnat<fpljiyl>.-saMtn u.najtbaKclogvcat.lgln<s.ap ia otCtevs  T-"

    const-string v0, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-java>>"

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->n(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x0

    return-object p0
.end method

.method public static synthetic f(Lkotlin/reflect/d;)V
    .locals 2

    const/4 v1, 0x3

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method public static final g(Lkotlin/reflect/d;)Ljava/lang/Class;
    .locals 5
    .param p0    # Lkotlin/reflect/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlin/reflect/d<",
            "TT;>;)",
            "Ljava/lang/Class<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v4, 0x1

    const/4 v3, 0x0

    const/4 v4, 0x2

    const-string v0, "ithm>s"

    const-string v0, "<this>"

    const/4 v4, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x2

    check-cast p0, Lkotlin/jvm/internal/t;

    invoke-interface {p0}, Lkotlin/jvm/internal/t;->q()Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x5

    invoke-virtual {p0}, Ljava/lang/Class;->isPrimitive()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    const-string v1, "avaeomanjn b.tsCgleelMy. i vCv TfcKbnn.<ptmpn Joo-j .piTlasn<cl ltn-osa>.acnpajosnyvgtt>llm  gOoualsetkeatut"

    const-string v1, "aonmnslTjtaa.gc-anvaanT-laopjybmlseetteitvutCsmbl o<l nnslepkaf.uOMjo>nl .<acspg tjo. t>KJ pcyvve .gln iC nt"

    const/4 v4, 0x6

    const-string v1, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-javaObjectType>>"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-nez v0, :cond_0

    const/4 v4, 0x6

    invoke-static {p0, v1}, Lkotlin/jvm/internal/l0;->n(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x5

    move v4, v3

    return-object p0

    :cond_0
    const/4 v4, 0x0

    const/4 v3, 0x3

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-virtual {v0}, Ljava/lang/String;->hashCode()I

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    sparse-switch v2, :sswitch_data_0

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x6

    goto/16 :goto_0

    :sswitch_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v2, "bhoos"

    const-string/jumbo v2, "tsoho"

    const/4 v4, 0x1

    const-string v2, "sutrh"

    const-string v2, "short"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x3

    goto/16 :goto_0

    :cond_1
    const/4 v4, 0x0

    const/4 v3, 0x5

    const-class p0, Ljava/lang/Short;

    const-class p0, Ljava/lang/Short;

    const/4 v4, 0x5

    const-class p0, Ljava/lang/Short;

    const-class p0, Ljava/lang/Short;

    const/4 v4, 0x2

    const/4 v3, 0x2

    goto/16 :goto_0

    :sswitch_1
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-string v2, "ftpba"

    const-string v2, "btfao"

    const/4 v4, 0x5

    const-string/jumbo v2, "tlfqo"

    const-string v2, "float"

    const/4 v3, 0x0

    move v4, v3

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    if-nez v0, :cond_2

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x2

    goto/16 :goto_0

    :cond_2
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x7

    const-class p0, Ljava/lang/Float;

    const-class p0, Ljava/lang/Float;

    const/4 v4, 0x7

    const-class p0, Ljava/lang/Float;

    const-class p0, Ljava/lang/Float;

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x3

    goto/16 :goto_0

    :sswitch_2
    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    const-string v2, "aosleuo"

    const-string v2, "olaneou"

    const-string v2, "blomoen"

    const-string v2, "boolean"

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    if-nez v0, :cond_3

    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x7

    goto/16 :goto_0

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-class p0, Ljava/lang/Boolean;

    const-class p0, Ljava/lang/Boolean;

    const/4 v4, 0x5

    const-class p0, Ljava/lang/Boolean;

    const-class p0, Ljava/lang/Boolean;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    goto/16 :goto_0

    :sswitch_3
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string/jumbo v2, "vodi"

    const-string/jumbo v2, "vodi"

    const/4 v4, 0x4

    const-string v2, "ivdo"

    const-string/jumbo v2, "void"

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x5

    if-nez v0, :cond_4

    const/4 v3, 0x4

    shr-int/2addr v4, v3

    goto/16 :goto_0

    :cond_4
    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x7

    const-class p0, Ljava/lang/Void;

    const-class p0, Ljava/lang/Void;

    const/4 v4, 0x6

    const-class p0, Ljava/lang/Void;

    const-class p0, Ljava/lang/Void;

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    goto/16 :goto_0

    :sswitch_4
    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x3

    const-string v2, "ngol"

    const-string v2, "glno"

    const-string v2, "ogln"

    const-string v2, "long"

    const/4 v3, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x3

    if-nez v0, :cond_5

    const/4 v4, 0x6

    const/4 v3, 0x5

    goto/16 :goto_0

    :cond_5
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    const-class p0, Ljava/lang/Long;

    const-class p0, Ljava/lang/Long;

    const/4 v4, 0x6

    const-class p0, Ljava/lang/Long;

    const-class p0, Ljava/lang/Long;

    const/4 v4, 0x7

    const/4 v3, 0x0

    const/4 v4, 0x6

    goto/16 :goto_0

    :sswitch_5
    const/4 v4, 0x4

    const-string v2, "harc"

    const-string v2, "achr"

    const/4 v4, 0x5

    const-string v2, "hrca"

    const-string v2, "char"

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x7

    if-nez v0, :cond_6

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    goto/16 :goto_0

    :cond_6
    const/4 v4, 0x0

    const/4 v3, 0x7

    const-class p0, Ljava/lang/Character;

    const-class p0, Ljava/lang/Character;

    const/4 v4, 0x3

    const-class p0, Ljava/lang/Character;

    const-class p0, Ljava/lang/Character;

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x3

    goto :goto_0

    :sswitch_6
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    const-string/jumbo v2, "yebt"

    const-string/jumbo v2, "teby"

    const/4 v4, 0x3

    const-string/jumbo v2, "teyb"

    const-string v2, "byte"

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x2

    if-nez v0, :cond_7

    const/4 v4, 0x0

    goto :goto_0

    :cond_7
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x5

    const-class p0, Ljava/lang/Byte;

    const-class p0, Ljava/lang/Byte;

    const/4 v4, 0x0

    const-class p0, Ljava/lang/Byte;

    const-class p0, Ljava/lang/Byte;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x0

    goto :goto_0

    :sswitch_7
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x5

    const-string v2, "itn"

    const-string v2, "int"

    const/4 v4, 0x0

    const-string/jumbo v2, "tni"

    const-string v2, "int"

    const/4 v4, 0x6

    const/4 v3, 0x6

    const/4 v4, 0x7

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x1

    if-nez v0, :cond_8

    const/4 v3, 0x3

    move v4, v3

    goto :goto_0

    :cond_8
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-class p0, Ljava/lang/Integer;

    const-class p0, Ljava/lang/Integer;

    const/4 v4, 0x0

    const-class p0, Ljava/lang/Integer;

    const-class p0, Ljava/lang/Integer;

    const/4 v4, 0x0

    const/4 v3, 0x1

    goto :goto_0

    :sswitch_8
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    const-string v2, "epbool"

    const-string v2, "epldob"

    const/4 v4, 0x0

    const-string v2, "oldebb"

    const-string v2, "double"

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x4

    invoke-virtual {v0, v2}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x2

    if-nez v0, :cond_9

    const/4 v4, 0x4

    const/4 v3, 0x2

    goto :goto_0

    :cond_9
    const/4 v4, 0x7

    const/4 v3, 0x6

    const/4 v4, 0x0

    const-class p0, Ljava/lang/Double;

    const-class p0, Ljava/lang/Double;

    const/4 v4, 0x7

    const-class p0, Ljava/lang/Double;

    const-class p0, Ljava/lang/Double;

    :goto_0
    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x2

    invoke-static {p0, v1}, Lkotlin/jvm/internal/l0;->n(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x5

    return-object p0

    nop

    :sswitch_data_0
    .sparse-switch
        -0x4f08842f -> :sswitch_8
        0x197ef -> :sswitch_7
        0x2e6108 -> :sswitch_6
        0x2e9356 -> :sswitch_5
        0x32c67c -> :sswitch_4
        0x375194 -> :sswitch_3
        0x3db6c28 -> :sswitch_2
        0x5d0225c -> :sswitch_1
        0x685847c -> :sswitch_0
    .end sparse-switch
.end method

.method public static final h(Lkotlin/reflect/d;)Ljava/lang/Class;
    .locals 3
    .param p0    # Lkotlin/reflect/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlin/reflect/d<",
            "TT;>;)",
            "Ljava/lang/Class<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lia/e;
    .end annotation

    const/4 v2, 0x2

    const-string v0, "<this>"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x1

    check-cast p0, Lkotlin/jvm/internal/t;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    invoke-interface {p0}, Lkotlin/jvm/internal/t;->q()Ljava/lang/Class;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-virtual {p0}, Ljava/lang/Class;->isPrimitive()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    if-eqz v0, :cond_0

    const/4 v2, 0x2

    const/4 v1, 0x5

    const/4 v2, 0x6

    const-string v0, "iltgg uotifp.e> nln>talasal-n.cn eMeiujtC. ajovvnm<ppvmTiqJlCio<jTso.yPskm .-es tltnyautag peancvrl atonlsbvnaa"

    const-string v0, "p.Mm<vafqlci-svmgaonrPieJlsTTkivtaasys  . jt i nllC.nmen.taanunegupv>stlant.tl jlneb> ocavnCi yalgtpe ap-<jtooo"

    const/4 v2, 0x6

    const-string v0, "-PvTl>gptn.m.anCrpocl jps Jajtactlnungtkb<a>tetsspvmaaef  tas.istalipMjnon mnnei loli<-o vg aloyTnv.e yCvKual.e"

    const-string v0, "null cannot be cast to non-null type java.lang.Class<T of kotlin.jvm.JvmClassMappingKt.<get-javaPrimitiveType>>"

    const/4 v2, 0x1

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->n(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x2

    return-object p0

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Ljava/lang/Class;->getName()Ljava/lang/String;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0}, Ljava/lang/String;->hashCode()I

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    sparse-switch v0, :sswitch_data_0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    goto/16 :goto_0

    :sswitch_0
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string/jumbo v0, "usb.vnagq.Djoaal"

    const-string v0, "n.sauajaogv.bllD"

    const/4 v2, 0x2

    const-string v0, ".asloDjnvagb.uel"

    const-string v0, "java.lang.Double"

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez p0, :cond_1

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x6

    goto/16 :goto_0

    :cond_1
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object p0, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    goto/16 :goto_1

    :sswitch_1
    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x6

    const-string v0, "laVmdmanoaj..i"

    const-string v0, "la.mgjon.idVaa"

    const/4 v2, 0x1

    const-string v0, "jlVnogdoi.av.a"

    const-string v0, "java.lang.Void"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x4

    if-nez p0, :cond_2

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    goto/16 :goto_0

    :cond_2
    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x0

    sget-object p0, Ljava/lang/Void;->TYPE:Ljava/lang/Class;

    const/4 v1, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    goto/16 :goto_1

    :sswitch_2
    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string v0, "aavogbnagoLnl."

    const-string v0, "nalaoovngL.agj"

    const/4 v2, 0x6

    const-string v0, "Laal.aunv.ggjo"

    const-string v0, "java.lang.Long"

    const/4 v2, 0x2

    const/4 v1, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x5

    const/4 v1, 0x2

    if-nez p0, :cond_3

    const/4 v2, 0x5

    goto/16 :goto_0

    :cond_3
    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x1

    sget-object p0, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x2

    goto/16 :goto_1

    :sswitch_3
    const/4 v2, 0x4

    const/4 v1, 0x3

    const-string v0, "agaBeb.jtlnyva"

    const/4 v2, 0x7

    const-string v0, "java.lang.Byte"

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x0

    const/4 v1, 0x4

    if-nez p0, :cond_4

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x0

    goto/16 :goto_0

    :cond_4
    const/4 v2, 0x6

    const/4 v1, 0x5

    const/4 v2, 0x1

    sget-object p0, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x4

    goto/16 :goto_1

    :sswitch_4
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    const-string v0, "ajB.olgpeanva.onl"

    const-string v0, "java.lang.Boolean"

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x6

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x2

    if-nez p0, :cond_5

    const/4 v1, 0x2

    move v2, v1

    goto/16 :goto_0

    :cond_5
    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x2

    sget-object p0, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    goto/16 :goto_1

    :sswitch_5
    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x1

    const-string v0, "rc.taClaqhgvaaje.ra"

    const-string v0, "java.lang.Character"

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez p0, :cond_6

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x4

    goto :goto_0

    :cond_6
    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    sget-object p0, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    goto :goto_1

    :sswitch_6
    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    const-string v0, "arsvStung..ahol"

    const-string v0, "a.ngoruh.tSalva"

    const/4 v2, 0x7

    const-string/jumbo v0, "tjoma.rSvl.aagh"

    const-string v0, "java.lang.Short"

    const/4 v2, 0x7

    const/4 v1, 0x2

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x7

    if-nez p0, :cond_7

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x4

    goto :goto_0

    :cond_7
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    sget-object p0, Ljava/lang/Short;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x4

    goto :goto_1

    :sswitch_7
    const/4 v2, 0x7

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string v0, "a.plovoFja.gnat"

    const-string v0, "avoFlltpnaj.ga."

    const/4 v2, 0x0

    const-string v0, ".Fa.tbjvoallang"

    const-string v0, "java.lang.Float"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x2

    const/4 v1, 0x0

    const/4 v2, 0x2

    if-nez p0, :cond_8

    const/4 v2, 0x5

    goto :goto_0

    :cond_8
    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x7

    sget-object p0, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x7

    goto :goto_1

    :sswitch_8
    const/4 v2, 0x2

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "..neatugajaevInqr"

    const-string v0, "jrvaelneqI.ganat."

    const/4 v2, 0x4

    const-string/jumbo v0, "telggvrp.eana.jna"

    const-string v0, "java.lang.Integer"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-virtual {p0, v0}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result p0

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x5

    if-nez p0, :cond_9

    const/4 v2, 0x3

    const/4 v1, 0x3

    const/4 v2, 0x3

    goto :goto_0

    :cond_9
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x5

    sget-object p0, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x4

    const/4 v1, 0x1

    goto :goto_1

    :goto_0
    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x6

    const/4 p0, 0x0

    :goto_1
    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x4

    return-object p0

    :sswitch_data_0
    .sparse-switch
        -0x7a988a96 -> :sswitch_8
        -0x1f76ce78 -> :sswitch_7
        -0x1ec16c58 -> :sswitch_6
        0x9415455 -> :sswitch_5
        0x148d6054 -> :sswitch_4
        0x17c0bc5c -> :sswitch_3
        0x17c521d0 -> :sswitch_2
        0x17c9ace8 -> :sswitch_1
        0x2d605225 -> :sswitch_0
    .end sparse-switch
.end method

.method public static final i(Ljava/lang/Class;)Lkotlin/reflect/d;
    .locals 3
    .param p0    # Ljava/lang/Class;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Ljava/lang/Class<",
            "TT;>;)",
            "Lkotlin/reflect/d<",
            "TT;>;"
        }
    .end annotation

    .annotation build Lh8/h;
        name = "getKotlinClass"
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    const-string v0, "isq>s<"

    const-string v0, "<is>ts"

    const/4 v2, 0x2

    const-string v0, "hsst><"

    const-string v0, "<this>"

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x6

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-static {p0}, Lkotlin/jvm/internal/l1;->d(Ljava/lang/Class;)Lkotlin/reflect/d;

    move-result-object p0

    const/4 v2, 0x0

    const/4 v1, 0x0

    const/4 v2, 0x7

    return-object p0
.end method

.method public static final j(Lkotlin/reflect/d;)Ljava/lang/Class;
    .locals 3
    .param p0    # Lkotlin/reflect/d;
        .annotation build Lia/d;
        .end annotation
    .end param
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T:",
            "Ljava/lang/Object;",
            ">(",
            "Lkotlin/reflect/d<",
            "TT;>;)",
            "Ljava/lang/Class<",
            "Lkotlin/reflect/d<",
            "TT;>;>;"
        }
    .end annotation

    .annotation build Lh8/h;
        name = "getRuntimeClassOfKClassInstance"
    .end annotation

    .annotation build Lia/d;
    .end annotation

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x5

    const-string v0, "stimh<"

    const-string v0, "<shmti"

    const/4 v2, 0x3

    const-string v0, "it>ho<"

    const-string v0, "<this>"

    const/4 v2, 0x6

    const/4 v1, 0x0

    const/4 v2, 0x4

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v1, 0x4

    move v2, v1

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v2, 0x4

    const/4 v1, 0x6

    const/4 v2, 0x2

    const-string v0, " l.apb<ueljs >.tM.Cpe>tl.unli Knvot sekft vtnv-ov<osloam.Csg laas olgiabin<lnjglcn-tnltaa rnonas>ClftjCacTas.a.sJsepatnyo Kmcl"

    const-string v0, "saM-onatem..alKsljtssntaobmst.iaplt oa<agCcagpntlnu jTk yvkpat llto<ioiea os> n>l.ll o.< vntCKleJC.nevC>-cnfrllusvcssaanfj.ng "

    const-string/jumbo v0, "tf gv>u <evallv<s-rsan otlmtpKutnontflMvlJliCln netanigc.CCokasasa>mojan. .nesK.at.ssonga<leaspyu  -jjollp>Cn i.ccatkaebls. lT"

    const-string v0, "null cannot be cast to non-null type java.lang.Class<kotlin.reflect.KClass<T of kotlin.jvm.JvmClassMappingKt.<get-javaClass>>>"

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x7

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->n(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x3

    return-object p0
.end method

.method public static synthetic k(Lkotlin/reflect/d;)V
    .locals 2
    .annotation runtime Lkotlin/k;
        level = .enum Lkotlin/m;->b:Lkotlin/m;
        message = "Use \'java\' property to get Java class corresponding to this Kotlin class or cast this instance to Any if you really want to get the runtime Java class of this implementation of KClass."
        replaceWith = .subannotation Lkotlin/b1;
            expression = "(this as Any).javaClass"
            imports = {}
        .end subannotation
    .end annotation

    const/4 v0, 0x6

    const/4 v1, 0x6

    return-void
.end method

.method public static final synthetic l([Ljava/lang/Object;)Z
    .locals 4

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-string/jumbo v0, "tphs<i"

    const-string v0, "s<thib"

    const/4 v3, 0x6

    const-string v0, ">tqsih"

    const-string v0, "<this>"

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x3

    invoke-static {p0, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x3

    const/4 v0, 0x4

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x1

    const-string v1, "T"

    const-string v1, "T"

    const/4 v3, 0x1

    const-string v1, "T"

    const-string v1, "T"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {v0, v1}, Lkotlin/jvm/internal/l0;->y(ILjava/lang/String;)V

    const/4 v3, 0x1

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object p0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-virtual {p0}, Ljava/lang/Class;->getComponentType()Ljava/lang/Class;

    move-result-object p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    const/4 v3, 0x0

    const-class v0, Ljava/lang/Object;

    const-class v0, Ljava/lang/Object;

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-virtual {v0, p0}, Ljava/lang/Class;->isAssignableFrom(Ljava/lang/Class;)Z

    move-result p0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x5

    return p0
.end method
