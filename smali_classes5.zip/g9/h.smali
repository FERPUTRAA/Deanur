.class public interface abstract annotation Lg9/h;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/annotation/Annotation;


# annotations
.annotation runtime Lga/e;
    value = {
        .enum Lga/i0;->d:Lga/i0;
    }
.end annotation

.annotation runtime Lga/f0;
    value = {
        Lg9/g;
    }
.end annotation

.annotation runtime Lga/h;
.end annotation

.annotation runtime Ljava/lang/annotation/Documented;
.end annotation

.annotation runtime Ljava/lang/annotation/Retention;
    value = .enum Ljava/lang/annotation/RetentionPolicy;->RUNTIME:Ljava/lang/annotation/RetentionPolicy;
.end annotation

.annotation runtime Ljava/lang/annotation/Target;
    value = {}
.end annotation
