.class public final Lf8/a;
.super Ljava/lang/Object;


# annotations
.annotation build Lh8/h;
    name = "AutoCloseableKt"
.end annotation


# direct methods
.method public static final a(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V
    .locals 2
    .param p0    # Ljava/lang/AutoCloseable;
        .annotation build Lia/e;
        .end annotation
    .end param
    .param p1    # Ljava/lang/Throwable;
        .annotation build Lia/e;
        .end annotation
    .end param
    .annotation build Lkotlin/a1;
    .end annotation

    .annotation build Lkotlin/g1;
        version = "1.2"
    .end annotation

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x0

    if-eqz p0, :cond_1

    const/4 v1, 0x6

    const/4 v0, 0x0

    if-nez p1, :cond_0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-interface {p0}, Ljava/lang/AutoCloseable;->close()V

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x2

    goto :goto_0

    :cond_0
    :try_start_0
    const/4 v1, 0x0

    const/4 v0, 0x0

    const/4 v1, 0x7

    invoke-interface {p0}, Ljava/lang/AutoCloseable;->close()V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v1, 0x0

    goto :goto_0

    :catchall_0
    move-exception p0

    const/4 v1, 0x7

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-static {p1, p0}, Lkotlin/o;->a(Ljava/lang/Throwable;Ljava/lang/Throwable;)V

    :cond_1
    :goto_0
    const/4 v1, 0x4

    const/4 v0, 0x4

    const/4 v1, 0x2

    return-void
.end method

.method private static final b(Ljava/lang/AutoCloseable;Li8/l;)Ljava/lang/Object;
    .locals 4
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "<T::",
            "Ljava/lang/AutoCloseable;",
            "R:",
            "Ljava/lang/Object;",
            ">(TT;",
            "Li8/l<",
            "-TT;+TR;>;)TR;"
        }
    .end annotation

    .annotation build Lkotlin/g1;
        version = "1.2"
    .end annotation

    .annotation build Lkotlin/internal/f;
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x7

    const/4 v3, 0x0

    const-string v0, "sosck"

    const-string v0, "cosbk"

    const/4 v3, 0x6

    const-string v0, "cokml"

    const-string v0, "block"

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1, v0}, Lkotlin/jvm/internal/l0;->p(Ljava/lang/Object;Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    const/4 v0, 0x1

    :try_start_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-interface {p1, p0}, Li8/l;->invoke(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p1
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x0

    const/4 v1, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    invoke-static {p0, v1}, Lf8/a;->a(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x5

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v3, 0x5

    const/4 v2, 0x7

    const/4 v3, 0x6

    return-object p1

    :catchall_0
    move-exception p1

    :try_start_1
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    throw p1
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_1

    :catchall_1
    move-exception v1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x3

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->d(I)V

    const/4 v2, 0x2

    const/4 v3, 0x5

    invoke-static {p0, p1}, Lf8/a;->a(Ljava/lang/AutoCloseable;Ljava/lang/Throwable;)V

    const/4 v2, 0x7

    const/4 v2, 0x2

    invoke-static {v0}, Lkotlin/jvm/internal/i0;->c(I)V

    const/4 v3, 0x3

    throw v1
.end method
