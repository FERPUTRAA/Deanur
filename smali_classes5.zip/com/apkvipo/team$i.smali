.class public final synthetic Lcom/apkvipo/team$i;
.super Ljava/lang/Object;


# direct methods
.method public static bridge synthetic a(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/reflect/Field;)Ljava/lang/invoke/MethodHandle;
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "@ts c@@~~@@@4~~/nfd~ ~@/@   ~  ~@~maS ~u@~@v~y@. @@iM s~@ ~t@l~i~lbb~i@~ooo ~-@1K roo~ @@ o ~f b"

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x7

    invoke-virtual {p0, p1}, Ljava/lang/invoke/MethodHandles$Lookup;->unreflectGetter(Ljava/lang/reflect/Field;)Ljava/lang/invoke/MethodHandle;

    move-result-object p0

    const/4 v1, 0x4

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-object p0
.end method

.method public static bridge synthetic b(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/reflect/Method;)Ljava/lang/invoke/MethodHandle;
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x5

    const/4 v1, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/invoke/MethodHandles$Lookup;->unreflect(Ljava/lang/reflect/Method;)Ljava/lang/invoke/MethodHandle;

    move-result-object p0

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-object p0
.end method

.method public static bridge synthetic c()Ljava/lang/invoke/MethodHandles$Lookup;
    .locals 3

    const/4 v2, 0x5

    const/4 v1, 0x5

    invoke-static {}, Ljava/lang/invoke/MethodHandles;->lookup()Ljava/lang/invoke/MethodHandles$Lookup;

    move-result-object v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object v0
.end method
