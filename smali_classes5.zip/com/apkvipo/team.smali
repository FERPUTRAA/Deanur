.class public Lcom/apkvipo/team;
.super Landroid/app/Application;


# static fields
.field public static final URL:Ljava/lang/String; = "https://github.com/L-JINBIN/ApkSignatureKillerEx"


# direct methods
.method static constructor <clinit>()V
    .locals 6

    const/4 v5, 0x6

    const/4 v4, 0x6

    const/4 v5, 0x7

    const-string v0, "YFsWMstrY92iNSJiyvrNxInYyEyDTQzD+Ww1v1IqPQLpg5nE3MvjnYMIR1A7RACeH9UwHETnwwBLlPzAFhgo2/IQneFABTsao+QYHT5MBfhRU6vKjI/MfJS9MszZ46V1IqQY9QvWDjAoMVfnmZEkTg3DDHu1EyBEeM2KE+Sbj7S+AkAHjnMsHkgaDPiXYIIGCTENnaIkAmUxekDZVYAt8VMwe5MAHMG1CzTIzuNPDGoqIlw8ss7TnRMMxADSywEMmQ5fUwyVxGQxExNPXJTT0HwMYKF+Gwk0oMgjwEwMmMZY4BHEO0NMBAmuMWnc0w6DhVeRpd/0xRgAqDEQLawBVk/x/AXERVVEnEB/HEIMGLAHt+EhyUkOmnnafvAEEkxAlMA+WlCEyANudZ9EQSNpjEljq1pX9ThKypTx5TiIiTUkQDmBJIxTVAZTcMEN/RM2yUc3xhwjZkAAiVewG/Nwjg9TCDq9EEDD3MOQlBAGGw0w4KATaaEovMNF1nCBjr7AEc6gFmsTAnrMBQQ/MAkgTwxvEbwIcAvJE2xAtM35tmamTAvMnuLweN0AP3WMae/8bOBEhSsDkGsN6QozDNWAw6DJITEECDVw5dR1Vj=N3eMrsuhMxB/vwUMPYzDegogdyFB0BxNSwJFffDN//eDwy12AVIQBcI7kLJMjRNMDGQgG5yXJlzcTDKb2gEFFZNBABiPEM0Tx16VoIlxDNMP/DgBPTxne6FykY6cCxN5TS1Vbdyt0pIOEV+AbXMGt0gABMHdwAPnTMRTwnwAVMBTJnpEQgZnwgsKYnjsMZh1ex/FIVljU/6LDKTfyIXxRoYTSTQbsnACHpYpweDWQy0MQFDgGOVIGMO3G23AfTMMCddh1xqEUUq0NxMoBB0AoDALnDbUAB9MrDiTIOaEKl9yUK/SZ7NoRiVejVUwETybNUInwNMwnglTHkLc4F5w79HuwAnGZyFAviyPE0VMxXMWEDy3Yt//GohupwwIZMsqxxN4I1MgdDMMaA9xAuQQFx53wQDnE/MPwsSVQACsSIw+URWsEgfFGDMITHAfpMj6fNll9kLFw0NghM3vEQIDaZBIIDIQlUD9wrbQAMIxQMA1nxQZvdyQjABAmbA/I0R4+dIznDz0LhEQ5UUGrUixwBxeqDHgmBDMfnMBxAvYe9k/THqvQvxw7VDTUuuxyKEninwr/BBeA7AQXeoOQ+L3dpQMM8Z/CBdlj/H0j0DOKSENYpoBPiAvMIZwnMGwM/iu9gECDAas5BMrOAMaY4wAG4Q0IMokTkx4AgiJTAEAaANxrjcCECb"

    const-string v0, "EIsTHCwBQy3IAUFn7JNYHqSFQM0TIPjQOPxlgEaXCyjZTiHG0NAxZMymFynMnAnDIGAUOEeZVAxkUI5qYykE97Oh4TkwRA8pPQewEI/JLbBjz0MH4IKdeAVOBWkT+A6+AMo/ExG24ZJD0BBe/fwRMIZqorVul9iq3PwTMrlQMPFkGwMvRxMBFR1jwQNAaWswQbMND74MAEeCWIMXEEQwM9BAyYnDEXcAzdUGgbKrenFXYlqMGn1M/QB3MlAwQq5wQUwaQYEnwM/jbIQQJVG6R50MTsKkmQDeKPgoAR/MTABYp0hGfBAwzpA32DfZwuxGKuxVxmkIM11YaqucBMPhSxIIRf1BYkOYTnRSECVQPGHwz25I2HYWwppuoUNDLpVzon1uByAjBFVBQVnTINEe6twvDO9EAPtTKxG8MEDAAh0xM3pUvxGyiMCGGEag/Midi5nowPysMBZINAQxAueyBcRKSAiImsvABx0C/kpTVI1IHMHwIxxVwdTpDIi/yCBDw0BxtEILlW6TrgXCpDnoDCgQwMohELYATMETgFok1giUcSYx+Q74T0cAtWhgTBlHoNxDGA4wSa9Mu6HTSwwDUnFI/EQesIAfDAFVDDAUxwbZTbev/nUCDetDneSM0Ij2IDTwmZwzrQAQkQtm+MHNgI4DLUMHVNDTsUhgT/vNtnlThyqMTjjk9rYMQxBTEMYjCWlMMMXM/LEvTFAAeONgeJ60z3EdNHYlnLdfc2BnTrgT0ZCDzZEEunUvQOAGEa0NkeM/VQx/naN0MiGMMVx0nVDQE9/EHO3cBLUDA/r5payYrJykQffETAwADKSg5vLBMxBePTB9JhGTD9wyjaQgaSUPDbX/pLbAEVCwM7AIkvmCnwsAxjv+iwCAJnVgAwfNH/ZvyIDS3EmvMw18BsDldmMs50vzMTy19EL+ZHNwG/9NVAwMskBxynkEdvBUEn3DMNihIw6/FPEEDZwDMgAEBDE+s6M/l1FEo7ZIEHy+wbM55M0wQg3gXFMVwMsEEWTnwZqUYeyR2QaA9DnIkq8YfN1NNVM7LAixDBe5vD71RJxvMTAagx9I3wbTQgID+ENKAOwoWMTzYQHj9oufAjExwl70MDjIxibn/NAxg9FWZbBxARMI3cfs5QmFMiDDooxShIVSrM3BNJkToF6yE1tT4PQnxMMX6yiKmsshsc4MOyEDV//SdMxRUFTRAprVwgVJwAjEHNEgMl9AgsdD1+1Ajqw/+NhumA6yAGQEANlDdojGcvxKUjnN5AIEBMkGenxad=ANjnT0EfRT0aUMdAunA2AKjM"

    const/4 v5, 0x5

    const-string v0, "DxEmAod2isIxEeMMCGDfXTOn/TMe6QQhvHzh7YgrA/IwhKTM5DG//CnMDD5QgSQPW2EslhQIh0kcTIRABE8DslAvQfFkwipIIHwiwWnEAjn/90QMKMuneQknwxxwWTMRMugPkykoLD11w3wtOpAMzEU0Q0QMBjluxUEEbIMmZwPUknA9vLAA3oASGxiAkeNwS3EnGxrx5VSUAIwVawMChiqDpZ3DFbqHnUoNM4VgpCHVgkyQsRTMj2emyyFA0YAB8lDHQcWIEoZ5AMADJUlGxMYqwNw8Uw6nBwwQCEOOM/1IDmMkgDGjxygM0wEwbb6KeV/ZEcN7E0wwOD6+AMA4wA3M2ykMAEAKojAyCoPxDvMRT7x9E7MVYEoIDi06Vv5aQxEDmN6FD1BIBGrRuyBAMewXTM1wvVsTLydBBleGnvZv/AHxBALlM50DSVMqJIRDkEdcHx+FwMLnMQDLgMOEMTNxBCIQw0CLUmUw9Al31Mn1AYwn+yTzOTdvhaCsNEyIUBWkMnTVbgy+DTaFS4KKkKfECc69NsYJQfeCHDI+qUCMRe0xWvTJlRATww/YFZXvJuBDNP6BTGN5EDh9Ap/M/mx4ZBAIoZHMnzGY0JsAIrTAIENrhDagxjVMwE0bTTBsMhERYQGM3zeUIIBsCZwUUNBBMA4QDkqAonQAAGEIsLgD00A0xyVyy+wInEMAq/MMlM9lYEBdZFD+TTywwGwAAumT/IiXIHMvFzTMklxExv8Aevi/RNfQvmiMdd1ijEKwdEr3TlDIAHsMwrMWEAjUHb9uMtOM+QaTHigy1VndV+NtKUEitAxgIju3SagIr/QxtQQQJAK1n7cAQ9QGUw1HgeG+eJnjQwEjNc536jZn9DSGrEzVgPnE1ouAuBZ7wuqDThdIY3PGmfxToANsO5MxeMesYDefMYjqpDDXyTjEMiwagB9B9nMnGVIBqB/AUhEnDeEwbg/WYAKQbT4EAP=XARAr4MxxAdVFKNw75oP9DigI9LtuIygYxTsjfDFSTcxIy0X/IshQIlfe/MEpSRjACjpywEiTL4wADNEBmQaAaTMAvMdELxqJ5SQpPzxWXBBnDTNjE/BmxDM16ynN2Vjg1fdRb7/Z5MGIENongtVVZRn2/QUP1S+bwxNA1mWkc/9SFoATMDf5aFyVGNaxGD2vzxYODTT4I7yxMFpEHkkCBZPjATEVH3PwHNMvnUAGnNlTU/FHkSMgABQVMcJeBZNNfPapZ6fnMp20EFLYgYpJ9EDwMVYV/FTk0wAzoTNXaBBtgATb/H0nFIQ0sNoMBMRrOaNQx3"

    const-string v0, "MIIDtTCCAp2gAwIBAgIENspgiDANBgkqhkiG9w0BAQsFADCBijEVMBMGA1UEBhMMeTUwMTIwMjAx\nMDE0MRUwEwYDVQQIEwx5NTAxMjAyMDEwMTQxFTATBgNVBAcTDHk1MDEyMDIwMTAxNDEVMBMGA1UE\nChMMeTUwMTIwMjAxMDE0MRUwEwYDVQQLEwx5NTAxMjAyMDEwMTQxFTATBgNVBAMTDHk1MDEyMDIw\nMTAxNDAeFw0yMDEwMTQxMzE0MDVaFw00NTEwMDgxMzE0MDVaMIGKMRUwEwYDVQQGEwx5NTAxMjAy\nMDEwMTQxFTATBgNVBAgTDHk1MDEyMDIwMTAxNDEVMBMGA1UEBxMMeTUwMTIwMjAxMDE0MRUwEwYD\nVQQKEwx5NTAxMjAyMDEwMTQxFTATBgNVBAsTDHk1MDEyMDIwMTAxNDEVMBMGA1UEAxMMeTUwMTIw\nMjAxMDE0MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAyIzYHew1snHdkrn9JIEFpPoT\nbFQjixfxnbejnDbsZyFfWt6VeW7e6iXuKOGNILWKLprHqkAOYdQn0e6ftyxuG9QGhPw6reHqPzvZ\nmBFggBZs1pY2ZzGqAsO+xg3jxSiEHHOfwavGNb/Z3SHnqxyT96aeNoyusJpwvhdVSRm9ZcbRvJ/6\nomOiemKdLno+Yj03kk+5SZNu4fSIk6rbiUpIl2mjvtb9+TwicrHhZQwRl+DZtsSkSWtv+xj7vVuO\nvaQmdPdGsxWwk5AAhDxaiAxvo7ao4n2xCVCNuW4bG8iSZ9Ex9RgBdLqDW0X2ZcY7JR7hNEOc5AUn\nYlY3Xrulg3S8EQIDAQABoyEwHzAdBgNVHQ4EFgQUBs/CYIuGdqzlWopHrwDhQC6vvtkwDQYJKoZI\nhvcNAQELBQADggEBAK0HFpTw+0o2EOfKlSl7y1aEezKA5I9lEREaSOlAxwEHsUASz1IdnpymPfal\n022A75YFQ5hHIuePj5g+QF6eCnvKnBoPaeodEXAgyfmLrBpLVijJ//0y145lJTNIp4YMbVvls6u/\nooPnAGrxU+kTVoIDSjpLmfYZX9wGVPJ9c8H7cqcoDT3b1SZyinaP3vyC4PfvNhA36JwIyB0abwWT\na4BNZ9vnmeQg1Xlma/sjG3Y95zQMnsV0RdZWJs9uq9IPkvnCOBPLR3MfkFlorcUNRN7C3rRP3yjU\nVsAtf+qyfNQGXR4Z/QeM0bXQIdiLKGAUlG3gMEJU/euYkYXIL+1mFII=\n"

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x2

    const-string v1, "0asoo.a1ysadm.e8.gdmgc557ru"

    const-string v1, "adgm.aeu5d5.ma8mocyss0.g7r1"

    const/4 v5, 0x3

    const-string v1, "mds1gb.m7r5.asad.gocusa8ey5"

    const-string v1, "com.sagadsg.user.mady501857"

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x7

    invoke-static {v1, v0}, Lcom/apkvipo/team;->killPM(Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x6

    const/4 v4, 0x3

    const/4 v5, 0x5

    const-string v0, ""

    const-string v0, ""

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x0

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x1

    const-string v2, ""

    const-string v2, ""

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x5

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x0

    const-string v3, ""

    const-string v3, ""

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x7

    invoke-static {v1, v3, v0, v2}, Lcom/apkvipo/team;->killOpen(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V

    const/4 v5, 0x2

    const/4 v4, 0x5

    const/4 v5, 0x7

    return-void
.end method

.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x0

    const/4 v1, 0x3

    invoke-direct {p0}, Landroid/app/Application;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x7

    return-void
.end method

.method public static a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;
    .locals 5

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v3, "@~~  @u~to S@c @4bi~1 @@ s@@/~r~ ~@~ /@ y ~MoKvb-@~ @mf~~@o bu ~~l~n~@~~@@~d aoto@~@i  ~.of@il~ "

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v0, 0x1

    :try_start_0
    const/4 v4, 0x3

    const/4 v3, 0x0

    const/4 v4, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_0
    .catch Ljava/lang/NoSuchFieldException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x3

    return-object v1

    :catch_0
    move-exception v1

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/Class;->getSuperclass()Ljava/lang/Class;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz p0, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-class v2, Ljava/lang/Object;

    const-class v2, Ljava/lang/Object;

    const/4 v4, 0x5

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-virtual {p0, v2}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    move-result v2

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x3

    if-nez v2, :cond_0

    :try_start_1
    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-virtual {p0, p1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v2

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x0

    invoke-virtual {v2, v0}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V
    :try_end_1
    .catch Ljava/lang/NoSuchFieldException; {:try_start_1 .. :try_end_1} :catch_1

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    return-object v2

    :catch_1
    nop

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x7

    goto :goto_0

    :cond_0
    const/4 v4, 0x4

    const/4 v3, 0x2

    throw v1
.end method

.method public static b(Ljava/lang/String;Ljava/lang/String;)Z
    .locals 13

    const/4 v12, 0x6

    const-string v0, "/"

    const-string v0, "/"

    const-string v0, "/"

    const-string v0, "/"

    const/4 v12, 0x1

    invoke-virtual {p1, v0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v12, 0x2

    const/4 v2, 0x0

    const/4 v12, 0x1

    if-eqz v1, :cond_5

    const/4 v12, 0x2

    const-string v1, ".pak"

    const-string v1, "ap.k"

    const-string v1, "ak.p"

    const-string v1, ".apk"

    invoke-virtual {p1, v1}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result v1

    const/4 v12, 0x5

    if-nez v1, :cond_0

    const/4 v12, 0x6

    goto/16 :goto_1

    :cond_0
    const/4 v12, 0x7

    const/4 v1, 0x1

    const/4 v12, 0x0

    invoke-virtual {p1, v1}, Ljava/lang/String;->substring(I)Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x6

    const/4 v3, 0x6

    const/4 v12, 0x1

    invoke-virtual {p1, v0, v3}, Ljava/lang/String;->split(Ljava/lang/String;I)[Ljava/lang/String;

    move-result-object p1

    const/4 v12, 0x3

    array-length v0, p1

    const/4 v12, 0x5

    const-string v4, "kbaepasp"

    const-string v4, "base.apk"

    const/4 v12, 0x4

    const-string v5, "ntm"

    const-string v5, "mtn"

    const-string v5, "ntm"

    const-string v5, "mnt"

    const-string v6, "adta"

    const-string v6, "taad"

    const-string v6, "adta"

    const-string v6, "data"

    const/4 v12, 0x3

    const/4 v7, 0x4

    const/4 v12, 0x1

    const/4 v8, 0x2

    const/4 v12, 0x6

    const-string v9, "ppa"

    const-string v9, "pap"

    const-string v9, "ppa"

    const-string v9, "app"

    const/4 v12, 0x7

    if-eq v0, v7, :cond_3

    const/4 v12, 0x6

    const/4 v10, 0x5

    const/4 v12, 0x1

    if-ne v0, v10, :cond_1

    const/4 v12, 0x0

    goto :goto_0

    :cond_1
    const/4 v12, 0x2

    const/4 v11, 0x3

    const/4 v12, 0x6

    if-ne v0, v11, :cond_2

    const/4 v12, 0x7

    aget-object v0, p1, v2

    const/4 v12, 0x5

    invoke-virtual {v0, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v12, 0x1

    if-eqz v0, :cond_5

    const/4 v12, 0x6

    aget-object v0, p1, v1

    const/4 v12, 0x0

    invoke-virtual {v0, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v12, 0x2

    if-eqz v0, :cond_5

    const/4 v12, 0x7

    aget-object p1, p1, v8

    const/4 v12, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v12, 0x6

    return p0

    :cond_2
    const/4 v12, 0x3

    if-ne v0, v3, :cond_5

    const/4 v12, 0x2

    aget-object v0, p1, v2

    const/4 v12, 0x5

    invoke-virtual {v0, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v12, 0x2

    if-eqz v0, :cond_5

    const/4 v12, 0x0

    aget-object v0, p1, v1

    const/4 v12, 0x0

    const-string v1, "dxqoep"

    const-string v1, "eadxop"

    const-string v1, "adsnep"

    const-string v1, "expand"

    const/4 v12, 0x7

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v12, 0x0

    if-eqz v0, :cond_5

    const/4 v12, 0x6

    aget-object v0, p1, v11

    const/4 v12, 0x4

    invoke-virtual {v0, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v12, 0x7

    if-eqz v0, :cond_5

    aget-object v0, p1, v10

    const/4 v12, 0x2

    invoke-virtual {v0, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v12, 0x5

    if-eqz v0, :cond_5

    const/4 v12, 0x3

    aget-object p1, p1, v7

    const/4 v12, 0x3

    invoke-virtual {p1, p0}, Ljava/lang/String;->endsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v12, 0x7

    return p0

    :cond_3
    :goto_0
    aget-object v3, p1, v2

    const/4 v12, 0x4

    invoke-virtual {v3, v6}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v12, 0x5

    if-eqz v3, :cond_4

    const/4 v12, 0x0

    aget-object v3, p1, v1

    const/4 v12, 0x4

    invoke-virtual {v3, v9}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v12, 0x2

    if-eqz v3, :cond_4

    const/4 v12, 0x5

    add-int/lit8 v3, v0, -0x1

    const/4 v12, 0x7

    aget-object v3, p1, v3

    const/4 v12, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v12, 0x0

    if-eqz v3, :cond_4

    const/4 v12, 0x1

    sub-int/2addr v0, v8

    const/4 v12, 0x1

    aget-object p1, p1, v0

    const/4 v12, 0x4

    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v12, 0x0

    return p0

    :cond_4
    const/4 v12, 0x1

    aget-object v3, p1, v2

    const/4 v12, 0x5

    invoke-virtual {v3, v5}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v3

    const/4 v12, 0x5

    if-eqz v3, :cond_5

    const/4 v12, 0x5

    aget-object v1, p1, v1

    const/4 v12, 0x5

    const-string v3, "aces"

    const-string v3, "aces"

    const-string v3, "asec"

    const/4 v12, 0x0

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v12, 0x4

    if-eqz v1, :cond_5

    const/4 v12, 0x1

    add-int/lit8 v1, v0, -0x1

    const/4 v12, 0x1

    aget-object v1, p1, v1

    const-string v3, "kk.gpbp"

    const-string v3, ".pkmagp"

    const-string v3, "pkg.apk"

    const/4 v12, 0x2

    invoke-virtual {v1, v3}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v1

    const/4 v12, 0x4

    if-eqz v1, :cond_5

    const/4 v12, 0x2

    sub-int/2addr v0, v8

    const/4 v12, 0x3

    aget-object p1, p1, v0

    invoke-virtual {p1, p0}, Ljava/lang/String;->startsWith(Ljava/lang/String;)Z

    move-result p0

    const/4 v12, 0x3

    return p0

    :cond_5
    :goto_1
    const/4 v12, 0x1

    return v2
.end method

.method private static killOpen(Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;Ljava/lang/String;)V
    .locals 10

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string v0, "s..ioletg.nauuetrhtrpma2i"

    const-string v0, "ls2mp.ur.lnateuathitgire."

    const/4 v9, 0x3

    const-string v0, "gt.mlbareuie.kpstnlhtr2ai"

    const-string v0, "mt.signature.killer.path2"

    const/4 v9, 0x7

    const/4 v8, 0x5

    const-string v1, "ermhreuipkga..l1ttu.lnapt"

    const-string v1, "ilramaephknetgr.i.u.tl1pt"

    const/4 v9, 0x1

    const-string v1, "..ltpghp.klrea1iauernsimt"

    const-string v1, "mt.signature.killer.path1"

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p1}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    const/4 v9, 0x7

    const/4 v8, 0x1

    if-nez v2, :cond_a

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-virtual {p2}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-nez v2, :cond_a

    const/4 v9, 0x4

    const/4 v8, 0x7

    invoke-virtual {p3}, Ljava/lang/String;->isEmpty()Z

    move-result v2

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-eqz v2, :cond_0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x6

    goto/16 :goto_e

    :cond_0
    :try_start_0
    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    new-instance v2, Ljava/io/BufferedReader;

    const/4 v9, 0x0

    new-instance v3, Ljava/io/FileReader;

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    const-string v4, "/frqosl/qc/pesm"

    const-string v4, "smfsec/pq/rl/po"

    const/4 v9, 0x0

    const-string v4, "/asfspc/srml/po"

    const-string v4, "/proc/self/maps"

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-direct {v3, v4}, Ljava/io/FileReader;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-direct {v2, v3}, Ljava/io/BufferedReader;-><init>(Ljava/io/Reader;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    :cond_1
    :try_start_1
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v2}, Ljava/io/BufferedReader;->readLine()Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x7

    if-eqz v3, :cond_2

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x7

    const-string v4, "s+//"

    const-string v4, "//+s"

    const/4 v9, 0x7

    const-string v4, "//s+"

    const-string v4, "\\s+"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x1

    invoke-virtual {v3, v4}, Ljava/lang/String;->split(Ljava/lang/String;)[Ljava/lang/String;

    move-result-object v3

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x5

    array-length v4, v3

    const/4 v8, 0x7

    move v9, v8

    add-int/lit8 v4, v4, -0x1

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    aget-object v3, v3, v4

    const/4 v9, 0x3

    invoke-static {p0, v3}, Lcom/apkvipo/team;->b(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v4
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x1

    if-eqz v4, :cond_1

    :try_start_2
    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_0

    :catch_0
    move-exception p0

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x7

    goto/16 :goto_d

    :catchall_0
    move-exception p0

    const/4 v9, 0x6

    const/4 v8, 0x1

    goto/16 :goto_b

    :cond_2
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_2
    .catch Ljava/lang/Exception; {:try_start_2 .. :try_end_2} :catch_0

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x4

    const/4 v3, 0x0

    :goto_0
    const/4 v9, 0x6

    const/4 v8, 0x1

    if-nez v3, :cond_3

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    sget-object p0, Ljava/lang/System;->err:Ljava/io/PrintStream;

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    const-string p1, " akmpGpditeta af sl"

    const-string p1, "dasptpaiGfhl a  ekt"

    const/4 v9, 0x0

    const-string p1, "iaGhoaeatp ld tfpe "

    const-string p1, "Get apk path failed"

    const/4 v8, 0x1

    move v9, v8

    invoke-virtual {p0, p1}, Ljava/io/PrintStream;->println(Ljava/lang/String;)V

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    return-void

    :cond_3
    const/4 v9, 0x6

    new-instance v2, Ljava/io/File;

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-direct {v2, v3}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    new-instance v3, Ljava/io/File;

    const/4 v9, 0x3

    const/4 v8, 0x4

    invoke-static {}, Landroid/os/Environment;->getExternalStorageDirectory()Ljava/io/File;

    move-result-object v4

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-virtual {v4}, Ljava/io/File;->getName()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x1

    const-string v5, "+d//"

    const-string v5, "d/+/"

    const/4 v9, 0x1

    const-string v5, "//+d"

    const-string v5, "\\d+"

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-virtual {v4, v5}, Ljava/lang/String;->matches(Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    if-eqz v5, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x0

    new-instance v5, Ljava/io/File;

    const/4 v9, 0x6

    const/4 v8, 0x7

    new-instance v6, Ljava/lang/StringBuilder;

    const/4 v8, 0x6

    move v9, v8

    const-string v7, "eau/dbt/r/s"

    const-string v7, "/samt//rdue"

    const/4 v9, 0x7

    const-string v7, "//rtauud/ae"

    const-string v7, "/data/user/"

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x0

    invoke-direct {v6, v7}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    const-string v4, "/"

    const-string v4, "/"

    const/4 v9, 0x4

    const-string v4, "/"

    const-string v4, "/"

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-virtual {v6, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v8, 0x7

    move v9, v8

    invoke-virtual {v6, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-virtual {v6}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v4

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x1

    invoke-direct {v5, v4}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {v5}, Ljava/io/File;->canWrite()Z

    move-result v4

    const/4 v9, 0x1

    const/4 v8, 0x4

    if-eqz v4, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x6

    goto :goto_1

    :cond_4
    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x7

    new-instance v5, Ljava/io/File;

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    new-instance v4, Ljava/lang/StringBuilder;

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    const-string v6, "d/oat//paat"

    const-string/jumbo v6, "td//oa/tada"

    const/4 v9, 0x7

    const-string/jumbo v6, "tta//aa/qda"

    const-string v6, "/data/data/"

    const/4 v9, 0x2

    invoke-direct {v4, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-virtual {v4, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-direct {v5, p0}, Ljava/io/File;-><init>(Ljava/lang/String;)V

    :goto_1
    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-direct {v3, v5, p3}, Ljava/io/File;-><init>(Ljava/io/File;Ljava/lang/String;)V

    const/4 v9, 0x4

    const/4 v8, 0x4

    invoke-virtual {v3}, Ljava/io/File;->getParentFile()Ljava/io/File;

    move-result-object p0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-virtual {p0}, Ljava/io/File;->mkdirs()Z

    :try_start_3
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    new-instance p0, Ljava/util/zip/ZipFile;

    const/4 v9, 0x0

    invoke-direct {p0, v2}, Ljava/util/zip/ZipFile;-><init>(Ljava/io/File;)V
    :try_end_3
    .catch Ljava/io/IOException; {:try_start_3 .. :try_end_3} :catch_1

    :try_start_4
    invoke-virtual {p0, p2}, Ljava/util/zip/ZipFile;->getEntry(Ljava/lang/String;)Ljava/util/zip/ZipEntry;

    move-result-object p3

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x2

    if-eqz p3, :cond_9

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-virtual {v3}, Ljava/io/File;->exists()Z

    move-result p2

    const/4 v9, 0x1

    if-eqz p2, :cond_5

    const/4 v9, 0x5

    invoke-virtual {v3}, Ljava/io/File;->length()J

    move-result-wide v4

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x4

    invoke-virtual {p3}, Ljava/util/zip/ZipEntry;->getSize()J

    move-result-wide v6

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    cmp-long p2, v4, v6

    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-eqz p2, :cond_7

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    goto :goto_2

    :catchall_1
    move-exception p1

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x1

    goto/16 :goto_8

    :cond_5
    :goto_2
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-virtual {p0, p3}, Ljava/util/zip/ZipFile;->getInputStream(Ljava/util/zip/ZipEntry;)Ljava/io/InputStream;

    move-result-object p2
    :try_end_4
    .catchall {:try_start_4 .. :try_end_4} :catchall_1

    :try_start_5
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x7

    new-instance p3, Ljava/io/FileOutputStream;

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-direct {p3, v3}, Ljava/io/FileOutputStream;-><init>(Ljava/io/File;)V
    :try_end_5
    .catchall {:try_start_5 .. :try_end_5} :catchall_4

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    const v4, 0x19000

    :try_start_6
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    new-array v4, v4, [B

    :goto_3
    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x4

    invoke-virtual {p2, v4}, Ljava/io/InputStream;->read([B)I

    move-result v5

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    const/4 v6, -0x1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-eq v5, v6, :cond_6

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x2

    const/4 v6, 0x0

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x7

    invoke-virtual {p3, v4, v6, v5}, Ljava/io/OutputStream;->write([BII)V
    :try_end_6
    .catchall {:try_start_6 .. :try_end_6} :catchall_2

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    goto :goto_3

    :catchall_2
    move-exception p1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    goto :goto_4

    :cond_6
    :try_start_7
    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x3

    invoke-virtual {p3}, Ljava/io/OutputStream;->close()V
    :try_end_7
    .catchall {:try_start_7 .. :try_end_7} :catchall_4

    :try_start_8
    const/4 v8, 0x3

    move v9, v8

    invoke-virtual {p2}, Ljava/io/InputStream;->close()V
    :try_end_8
    .catchall {:try_start_8 .. :try_end_8} :catchall_1

    :cond_7
    :try_start_9
    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    invoke-virtual {p0}, Ljava/util/zip/ZipFile;->close()V
    :try_end_9
    .catch Ljava/io/IOException; {:try_start_9 .. :try_end_9} :catch_1

    :try_start_a
    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-virtual {v2}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x6

    const/4 v8, 0x6

    invoke-static {v1, p0}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x0

    invoke-virtual {v3}, Ljava/io/File;->getAbsolutePath()Ljava/lang/String;

    move-result-object p0

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {v0, p0}, Ljava/lang/System;->setProperty(Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {p1}, Ljava/lang/System;->loadLibrary(Ljava/lang/String;)V
    :try_end_a
    .catchall {:try_start_a .. :try_end_a} :catchall_3

    const/4 v8, 0x0

    move v9, v8

    invoke-static {v1}, Ljava/lang/System;->clearProperty(Ljava/lang/String;)Ljava/lang/String;

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {v0}, Ljava/lang/System;->clearProperty(Ljava/lang/String;)Ljava/lang/String;

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    return-void

    :catchall_3
    move-exception p0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-static {v1}, Ljava/lang/System;->clearProperty(Ljava/lang/String;)Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x4

    invoke-static {v0}, Ljava/lang/System;->clearProperty(Ljava/lang/String;)Ljava/lang/String;

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x4

    throw p0

    :catch_1
    move-exception p0

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x0

    goto :goto_a

    :catchall_4
    move-exception p1

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    goto :goto_6

    :goto_4
    :try_start_b
    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x5

    invoke-virtual {p3}, Ljava/io/OutputStream;->close()V
    :try_end_b
    .catchall {:try_start_b .. :try_end_b} :catchall_5

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x3

    goto :goto_5

    :catchall_5
    move-exception p3

    :try_start_c
    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-virtual {p1, p3}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_5
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x2

    throw p1
    :try_end_c
    .catchall {:try_start_c .. :try_end_c} :catchall_4

    :goto_6
    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-eqz p2, :cond_8

    :try_start_d
    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-virtual {p2}, Ljava/io/InputStream;->close()V
    :try_end_d
    .catchall {:try_start_d .. :try_end_d} :catchall_6

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    goto :goto_7

    :catchall_6
    move-exception p2

    :try_start_e
    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x7

    invoke-virtual {p1, p2}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :cond_8
    :goto_7
    const/4 v8, 0x7

    const/4 v9, 0x2

    throw p1

    :cond_9
    const/4 v8, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x2

    new-instance p3, Ljava/lang/StringBuilder;

    const/4 v8, 0x4

    move v9, v8

    invoke-direct {p3}, Ljava/lang/StringBuilder;-><init>()V

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x2

    const-string/jumbo v0, "ursodybEtn nn of:"

    const-string v0, "ntunobyfE: rn tod"

    const/4 v9, 0x4

    const-string v0, "n :mtotnoErn fdy "

    const-string v0, "Entry not found: "

    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x2

    invoke-virtual {p3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x7

    const/4 v8, 0x4

    invoke-virtual {p3, p2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const/4 v9, 0x6

    invoke-virtual {p3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p2

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-direct {p1, p2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x7

    throw p1
    :try_end_e
    .catchall {:try_start_e .. :try_end_e} :catchall_1

    :goto_8
    :try_start_f
    const/4 v9, 0x2

    const/4 v8, 0x4

    invoke-virtual {p0}, Ljava/util/zip/ZipFile;->close()V
    :try_end_f
    .catchall {:try_start_f .. :try_end_f} :catchall_7

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x7

    goto :goto_9

    :catchall_7
    move-exception p0

    :try_start_10
    const/4 v9, 0x1

    const/4 v8, 0x0

    const/4 v9, 0x2

    invoke-virtual {p1, p0}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_9
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    throw p1
    :try_end_10
    .catch Ljava/io/IOException; {:try_start_10 .. :try_end_10} :catch_1

    :goto_a
    const/4 v9, 0x2

    const/4 v8, 0x3

    const/4 v9, 0x3

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v9, 0x3

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    throw p1

    :goto_b
    :try_start_11
    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-virtual {v2}, Ljava/io/BufferedReader;->close()V
    :try_end_11
    .catchall {:try_start_11 .. :try_end_11} :catchall_8

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x0

    goto :goto_c

    :catchall_8
    move-exception p1

    :try_start_12
    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x1

    invoke-virtual {p0, p1}, Ljava/lang/Throwable;->addSuppressed(Ljava/lang/Throwable;)V

    :goto_c
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x6

    throw p0
    :try_end_12
    .catch Ljava/lang/Exception; {:try_start_12 .. :try_end_12} :catch_0

    :goto_d
    const/4 v9, 0x1

    const/4 v8, 0x7

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x6

    throw p1

    :cond_a
    :goto_e
    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x0

    return-void
.end method

.method private static killPM(Ljava/lang/String;Ljava/lang/String;)V
    .locals 5

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-class v0, Landroid/os/Parcel;

    const-class v0, Landroid/os/Parcel;

    const/4 v4, 0x7

    const-class v0, Landroid/os/Parcel;

    const-class v0, Landroid/os/Parcel;

    const/4 v4, 0x4

    const/4 v3, 0x3

    const/4 v4, 0x3

    new-instance v1, Landroid/content/pm/Signature;

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v2, 0x3

    const/4 v2, 0x0

    const/4 v3, 0x7

    xor-int/2addr v4, v3

    invoke-static {p1, v2}, Landroid/util/Base64;->decode(Ljava/lang/String;I)[B

    move-result-object p1

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-direct {v1, p1}, Landroid/content/pm/Signature;-><init>([B)V

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x3

    sget-object p1, Landroid/content/pm/PackageInfo;->CREATOR:Landroid/os/Parcelable$Creator;

    const/4 v3, 0x6

    const/4 v3, 0x6

    new-instance v2, Lcom/apkvipo/team$l;

    const/4 v3, 0x7

    const/4 v3, 0x4

    invoke-direct {v2, p1, p0, v1}, Lcom/apkvipo/team$l;-><init>(Landroid/os/Parcelable$Creator;Ljava/lang/String;Landroid/content/pm/Signature;)V

    :try_start_0
    const/4 v4, 0x0

    const/4 v3, 0x1

    const-class p0, Landroid/content/pm/PackageInfo;

    const/4 v4, 0x6

    const-class p0, Landroid/content/pm/PackageInfo;

    const-class p0, Landroid/content/pm/PackageInfo;

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x1

    const-string p1, "TOAEoCR"

    const-string p1, "RECAOTu"

    const/4 v4, 0x2

    const-string p1, "TAORCbR"

    const-string p1, "CREATOR"

    const/4 v4, 0x0

    invoke-static {p0, p1}, Lcom/apkvipo/team;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x1

    const/4 p1, 0x0

    const/4 v4, 0x4

    const/4 v3, 0x7

    invoke-virtual {p0, p1, v2}, Ljava/lang/reflect/Field;->set(Ljava/lang/Object;Ljava/lang/Object;)V
    :try_end_0
    .catch Ljava/lang/Exception; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x2

    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v4, 0x0

    const/4 v3, 0x0

    const/4 v4, 0x4

    const/16 v1, 0x1c

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    if-lt p0, v1, :cond_0

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x6

    const-string p0, "i/aLrpupddop"

    const-string p0, "dpdpLiapo/ar"

    const/4 v4, 0x4

    const-string p0, "dpr/naapopid"

    const-string p0, "Landroid/app"

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x1

    const-string v1, "orei/Lr/qldPcndaaos"

    const-string v1, "Landroid/os/Parcel;"

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    const-string v2, "qpstdor/nmenoLcanti"

    const-string/jumbo v2, "teidLctnqp/mnoandro"

    const/4 v4, 0x1

    const-string v2, "/itmeranm/tnLdcdpno"

    const-string v2, "Landroid/content/pm"

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    filled-new-array {v1, v2, p0}, [Ljava/lang/String;

    move-result-object p0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    sget-object v1, Lcom/apkvipo/team$j;->f:Ljava/util/HashSet;

    const/4 v3, 0x0

    shl-int/2addr v4, v3

    invoke-static {p0}, Ljava/util/Arrays;->asList([Ljava/lang/Object;)Ljava/util/List;

    move-result-object p0

    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-interface {v1, p0}, Ljava/util/Set;->addAll(Ljava/util/Collection;)Z

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-virtual {v1}, Ljava/util/HashSet;->size()I

    move-result p0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x3

    new-array p0, p0, [Ljava/lang/String;

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x1

    invoke-virtual {v1, p0}, Ljava/util/HashSet;->toArray([Ljava/lang/Object;)[Ljava/lang/Object;

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {p0}, Lcom/apkvipo/team$j;->b([Ljava/lang/String;)Z

    :cond_0
    :try_start_1
    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-class p0, Landroid/content/pm/PackageManager;

    const-class p0, Landroid/content/pm/PackageManager;

    const/4 v4, 0x0

    const-class p0, Landroid/content/pm/PackageManager;

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v1, "sPackageInfoCache"

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-static {p0, v1}, Lcom/apkvipo/team;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-virtual {p0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    move-result-object v1

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    const-string v2, "serco"

    const-string v2, "acser"

    const/4 v4, 0x4

    const-string v2, "blrec"

    const-string v2, "clear"

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-virtual {v1, v2, p1}, Ljava/lang/Class;->getMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x1

    invoke-virtual {v1, p0, p1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_1
    .catchall {:try_start_1 .. :try_end_1} :catchall_0

    :catchall_0
    :try_start_2
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x4

    const-string/jumbo p0, "trasomure"

    const-string p0, "Coemstrra"

    const-string p0, "Camorsepr"

    const-string p0, "mCreators"

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x1

    invoke-static {v0, p0}, Lcom/apkvipo/team;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-virtual {p0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    check-cast p0, Ljava/util/Map;

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x6

    invoke-interface {p0}, Ljava/util/Map;->clear()V
    :try_end_2
    .catchall {:try_start_2 .. :try_end_2} :catchall_1

    :catchall_1
    :try_start_3
    const/4 v4, 0x3

    const/4 v3, 0x6

    const/4 v4, 0x3

    const-string p0, "raPaiCrdqoeerot"

    const-string p0, "aetaoriCserdroP"

    const/4 v4, 0x0

    const-string/jumbo p0, "tssPesaredrariC"

    const-string p0, "sPairedCreators"

    const/4 v4, 0x5

    invoke-static {v0, p0}, Lcom/apkvipo/team;->a(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object p0

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-virtual {p0, p1}, Ljava/lang/reflect/Field;->get(Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object p0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    check-cast p0, Ljava/util/Map;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x4

    invoke-interface {p0}, Ljava/util/Map;->clear()V
    :try_end_3
    .catchall {:try_start_3 .. :try_end_3} :catchall_2

    :catchall_2
    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    return-void

    :catch_0
    move-exception p0

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x0

    new-instance p1, Ljava/lang/RuntimeException;

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x3

    invoke-direct {p1, p0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/Throwable;)V

    const/4 v4, 0x6

    const/4 v3, 0x0

    const/4 v4, 0x7

    throw p1
.end method
