.class public final Lcom/apkvipo/team$l;
.super Ljava/lang/Object;

# interfaces
.implements Landroid/os/Parcelable$Creator;


# instance fields
.field public final synthetic a:Landroid/os/Parcelable$Creator;

.field public final synthetic b:Ljava/lang/String;

.field public final synthetic c:Landroid/content/pm/Signature;


# direct methods
.method public constructor <init>(Landroid/os/Parcelable$Creator;Ljava/lang/String;Landroid/content/pm/Signature;)V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x3

    const/4 v1, 0x5

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x7

    const/4 v1, 0x7

    iput-object p1, p0, Lcom/apkvipo/team$l;->a:Landroid/os/Parcelable$Creator;

    iput-object p2, p0, Lcom/apkvipo/team$l;->b:Ljava/lang/String;

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    iput-object p3, p0, Lcom/apkvipo/team$l;->c:Landroid/content/pm/Signature;

    const/4 v1, 0x7

    const/4 v0, 0x7

    const/4 v1, 0x2

    return-void
.end method


# virtual methods
.method public final createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;
    .locals 6

    const-string v5, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v4, "./s~@~~~@  o~@@t @/M@o~s~@@~@i-@@ o ~K~~lbc @y~f@@d @~ in ~f~~  ~@muo~ ~bSr@@@    ~1ibvoo@a4t~~ "

    const-string v4, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v5, 0x7

    iget-object v0, p0, Lcom/apkvipo/team$l;->a:Landroid/os/Parcelable$Creator;

    const/4 v5, 0x5

    invoke-interface {v0, p1}, Landroid/os/Parcelable$Creator;->createFromParcel(Landroid/os/Parcel;)Ljava/lang/Object;

    move-result-object p1

    const/4 v5, 0x4

    const/4 v4, 0x3

    check-cast p1, Landroid/content/pm/PackageInfo;

    const/4 v5, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x7

    iget-object v0, p1, Landroid/content/pm/PackageInfo;->packageName:Ljava/lang/String;

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x6

    iget-object v1, p0, Lcom/apkvipo/team$l;->b:Ljava/lang/String;

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x1

    invoke-virtual {v0, v1}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x3

    if-eqz v0, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x3

    const/4 v5, 0x6

    iget-object v0, p1, Landroid/content/pm/PackageInfo;->signatures:[Landroid/content/pm/Signature;

    const/4 v5, 0x7

    iget-object v1, p0, Lcom/apkvipo/team$l;->c:Landroid/content/pm/Signature;

    const/4 v5, 0x0

    const/4 v4, 0x3

    const/4 v5, 0x0

    const/4 v2, 0x0

    const/4 v5, 0x0

    const/4 v4, 0x1

    const/4 v5, 0x1

    if-eqz v0, :cond_0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    array-length v3, v0

    const/4 v5, 0x4

    const/4 v4, 0x2

    const/4 v5, 0x0

    if-lez v3, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    aput-object v1, v0, v2

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x3

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v5, 0x5

    const/4 v4, 0x0

    const/4 v5, 0x5

    const/16 v3, 0x1c

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-lt v0, v3, :cond_1

    const/4 v5, 0x5

    const/4 v4, 0x6

    invoke-static {p1}, Lcom/apkvipo/team$k;->a(Landroid/content/pm/PackageInfo;)Landroid/content/pm/SigningInfo;

    move-result-object v0

    const/4 v5, 0x2

    const/4 v4, 0x3

    const/4 v5, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x2

    invoke-static {p1}, Lcom/apkvipo/team$k;->a(Landroid/content/pm/PackageInfo;)Landroid/content/pm/SigningInfo;

    move-result-object v0

    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {v0}, Lcom/apkvipo/team$k;->b(Landroid/content/pm/SigningInfo;)[Landroid/content/pm/Signature;

    move-result-object v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    if-eqz v0, :cond_1

    const/4 v5, 0x1

    const/4 v4, 0x3

    const/4 v5, 0x2

    array-length v3, v0

    const/4 v5, 0x5

    const/4 v4, 0x5

    const/4 v5, 0x2

    if-lez v3, :cond_1

    const/4 v5, 0x2

    const/4 v4, 0x0

    const/4 v5, 0x0

    aput-object v1, v0, v2

    :cond_1
    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x7

    return-object p1
.end method

.method public final newArray(I)[Ljava/lang/Object;
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x1

    iget-object v0, p0, Lcom/apkvipo/team$l;->a:Landroid/os/Parcelable$Creator;

    const/4 v2, 0x2

    const/4 v1, 0x7

    const/4 v2, 0x3

    invoke-interface {v0, p1}, Landroid/os/Parcelable$Creator;->newArray(I)[Ljava/lang/Object;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x5

    check-cast p1, [Landroid/content/pm/PackageInfo;

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    return-object p1
.end method
