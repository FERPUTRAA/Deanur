.class public final Lcom/apkvipo/team$e;
.super Ljava/lang/Object;


# direct methods
.method private varargs constructor <init>([Ljava/lang/Object;)V
    .locals 3

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x3

    new-instance p1, Ljava/lang/IllegalStateException;

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x5

    const-string v0, "eisse  aodnnwlF sn titac"

    const-string v0, "nesa n tiisaFdtc  wealon"

    const-string v0, "notmin dcenFateaa slwei "

    const-string v0, "Failed to new a instance"

    const/4 v2, 0x2

    const/4 v1, 0x6

    const/4 v2, 0x2

    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x5

    const/4 v1, 0x0

    const/4 v2, 0x3

    throw p1
.end method

.method private static varargs invoke([Ljava/lang/Object;)Ljava/lang/Object;
    .locals 3

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "fit~of@l~~@K~ @~@-~@n~  o@ r~ s/oyd@b@ @@o@4@o~t@~~MS~@@1   @ @ u@~/lo~  b~ @ @i~~.m ~ v~bcaio~~"

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v2, 0x3

    new-instance p0, Ljava/lang/IllegalStateException;

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x1

    const-string/jumbo v0, "td kibmvloeone ei edaho tmF"

    const-string v0, "Fommv ei nhelht tioa ekoedd"

    const/4 v2, 0x7

    const-string v0, "oelo iuta dedtvt nkheoeFi m"

    const-string v0, "Failed to invoke the method"

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x3

    invoke-direct {p0, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x0

    throw p0
.end method
