.class public Lcom/apkvipo/team$f;
.super Ljava/lang/Object;


# instance fields
.field protected final artFieldOrMethod:J

.field private cachedSpreadInvoker:Lcom/apkvipo/team$f;

.field protected final handleKind:I

.field private nominalType:Ljava/lang/invoke/MethodType;

.field private final type:Ljava/lang/invoke/MethodType;


# direct methods
.method public constructor <init>()V
    .locals 4

    const/4 v2, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v3, 0x1

    const/4 v0, 0x1

    const/4 v3, 0x3

    const/4 v0, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    iput-object v0, p0, Lcom/apkvipo/team$f;->type:Ljava/lang/invoke/MethodType;

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    const/4 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x6

    const/4 v3, 0x1

    iput v0, p0, Lcom/apkvipo/team$f;->handleKind:I

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x1

    const-wide/16 v0, 0x0

    const-wide/16 v0, 0x0

    const/4 v3, 0x2

    const/4 v2, 0x1

    iput-wide v0, p0, Lcom/apkvipo/team$f;->artFieldOrMethod:J

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x7

    return-void
.end method
