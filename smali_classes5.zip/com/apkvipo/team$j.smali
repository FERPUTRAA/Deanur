.class public final Lcom/apkvipo/team$j;
.super Ljava/lang/Object;


# static fields
.field public static final a:Lsun/misc/Unsafe;

.field public static final b:J

.field public static final c:J

.field public static final d:J

.field public static final e:J

.field public static final f:Ljava/util/HashSet;


# direct methods
.method static constructor <clinit>()V
    .locals 15

    const/4 v14, 0x0

    const-class v0, Lcom/apkvipo/team$c;

    const-class v0, Lcom/apkvipo/team$c;

    const-class v0, Lcom/apkvipo/team$c;

    const-class v0, Lcom/apkvipo/team$c;

    const/4 v14, 0x3

    const-class v1, Lcom/apkvipo/team$b;

    const-class v1, Lcom/apkvipo/team$b;

    const-class v1, Lcom/apkvipo/team$b;

    const-class v1, Lcom/apkvipo/team$b;

    const-class v2, Lcom/apkvipo/team$h;

    const-class v2, Lcom/apkvipo/team$h;

    const-class v2, Lcom/apkvipo/team$h;

    const-class v2, Lcom/apkvipo/team$h;

    const/4 v14, 0x1

    new-instance v3, Ljava/util/HashSet;

    const/4 v14, 0x6

    invoke-direct {v3}, Ljava/util/HashSet;-><init>()V

    const/4 v14, 0x4

    sput-object v3, Lcom/apkvipo/team$j;->f:Ljava/util/HashSet;

    :try_start_0
    const/4 v14, 0x7

    const-class v3, Lsun/misc/Unsafe;

    const-class v3, Lsun/misc/Unsafe;

    const-class v3, Lsun/misc/Unsafe;

    const-class v3, Lsun/misc/Unsafe;

    const/4 v14, 0x3

    const-string v4, "stsUsenge"

    const-string v4, "essgUtean"

    const-string v4, "getUnsafe"

    const/4 v14, 0x3

    const/4 v5, 0x0

    const/4 v14, 0x6

    invoke-virtual {v3, v4, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v3

    const/4 v14, 0x1

    invoke-virtual {v3, v5, v5}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v14, 0x5

    check-cast v3, Lsun/misc/Unsafe;

    const/4 v14, 0x2

    sput-object v3, Lcom/apkvipo/team$j;->a:Lsun/misc/Unsafe;

    const/4 v14, 0x3

    const-string v4, "mtrmadeMh"

    const-string v4, "hdtmMerat"

    const-string v4, "otedortMh"

    const-string v4, "artMethod"

    const/4 v14, 0x4

    invoke-virtual {v0, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v4

    const/4 v14, 0x6

    invoke-virtual {v3, v4}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v6

    const/4 v14, 0x0

    sput-wide v6, Lcom/apkvipo/team$j;->b:J

    const/4 v14, 0x1

    const-string v4, "nascrbeldoaglC"

    const-string v4, "raCaolelcnssdg"

    const-string v4, "algCeiulrsdnas"

    const-string v4, "declaringClass"

    const/4 v14, 0x7

    invoke-virtual {v0, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v14, 0x5

    invoke-virtual {v3, v0}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    const/4 v14, 0x5

    const-class v0, Lcom/apkvipo/team$f;

    const-class v0, Lcom/apkvipo/team$f;

    const-class v0, Lcom/apkvipo/team$f;

    const-class v0, Lcom/apkvipo/team$f;

    const/4 v14, 0x4

    const-string v4, "leebMripFrdtohad"

    const-string v4, "heldtbatoirrMFed"

    const-string v4, "OirroMeeqdldtthF"

    const-string v4, "artFieldOrMethod"

    const/4 v14, 0x1

    invoke-virtual {v0, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v14, 0x3

    invoke-virtual {v3, v0}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v6

    const/4 v14, 0x1

    const-class v0, Lcom/apkvipo/team$g;

    const-class v0, Lcom/apkvipo/team$g;

    const-class v0, Lcom/apkvipo/team$g;

    const-class v0, Lcom/apkvipo/team$g;

    const/4 v14, 0x2

    const-string v4, "nifo"

    const-string v4, "niof"

    const-string v4, "nfio"

    const-string v4, "info"

    invoke-virtual {v0, v4}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v14, 0x0

    invoke-virtual {v3, v0}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    const/4 v14, 0x7

    const-string v0, "edsmstu"

    const-string v0, "ehtsmdu"

    const-string v0, "otmmdhs"

    const-string v0, "methods"

    const/4 v14, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v14, 0x5

    invoke-virtual {v3, v0}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v8

    const/4 v14, 0x7

    sput-wide v8, Lcom/apkvipo/team$j;->c:J

    const/4 v14, 0x3

    const-string v0, "eidposi"

    const-string v0, "pdeilis"

    const-string v0, "Fsiedbi"

    const-string v0, "iFields"

    const/4 v14, 0x7

    invoke-virtual {v1, v0}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v14, 0x0

    invoke-virtual {v3, v0}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    move-result-wide v10

    const/4 v14, 0x5

    const-string v0, "sqFdlis"

    const-string v0, "Fsisedu"

    const-string v0, "sFields"

    const/4 v14, 0x1

    invoke-virtual {v1, v0}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v14, 0x0

    invoke-virtual {v3, v0}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    const/4 v14, 0x6

    const-class v0, Lcom/apkvipo/team$d;

    const-class v0, Lcom/apkvipo/team$d;

    const-class v0, Lcom/apkvipo/team$d;

    const/4 v14, 0x0

    const-string v1, "rpemms"

    const-string v1, "resemm"

    const-string v1, "mrqmeb"

    const-string v1, "member"

    const/4 v14, 0x6

    invoke-virtual {v0, v1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v14, 0x0

    invoke-virtual {v3, v0}, Lsun/misc/Unsafe;->objectFieldOffset(Ljava/lang/reflect/Field;)J

    const/4 v14, 0x7

    const-string v0, "a"

    const-string v0, "a"

    const-string v0, "a"

    const-string v0, "a"

    const/4 v14, 0x4

    invoke-virtual {v2, v0, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v0

    const/4 v14, 0x4

    const-string v1, "b"

    const-string v1, "b"

    const-string v1, "b"

    const/4 v14, 0x4

    invoke-virtual {v2, v1, v5}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v1

    const/4 v14, 0x5

    const/4 v4, 0x1

    const/4 v14, 0x0

    invoke-virtual {v0, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v14, 0x0

    invoke-virtual {v1, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    invoke-static {}, Lcom/apkvipo/team$i;->c()Ljava/lang/invoke/MethodHandles$Lookup;

    move-result-object v5

    const/4 v14, 0x3

    invoke-static {v5, v0}, Lcom/apkvipo/team$i;->b(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/reflect/Method;)Ljava/lang/invoke/MethodHandle;

    move-result-object v0

    const/4 v14, 0x0

    invoke-static {}, Lcom/apkvipo/team$i;->c()Ljava/lang/invoke/MethodHandles$Lookup;

    move-result-object v5

    const/4 v14, 0x5

    invoke-static {v5, v1}, Lcom/apkvipo/team$i;->b(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/reflect/Method;)Ljava/lang/invoke/MethodHandle;

    move-result-object v1

    const/4 v14, 0x7

    invoke-virtual {v3, v0, v6, v7}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v12

    const/4 v14, 0x5

    invoke-virtual {v3, v1, v6, v7}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v0

    const/4 v14, 0x6

    invoke-virtual {v3, v2, v8, v9}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v8

    const/4 v14, 0x0

    sub-long/2addr v0, v12

    const/4 v14, 0x5

    sput-wide v0, Lcom/apkvipo/team$j;->d:J

    const/4 v14, 0x7

    sub-long/2addr v12, v8

    const/4 v14, 0x6

    sub-long/2addr v12, v0

    const/4 v14, 0x6

    sput-wide v12, Lcom/apkvipo/team$j;->e:J

    const/4 v14, 0x1

    const-string v0, "i"

    const-string v0, "i"

    const-string v0, "i"

    const-string v0, "i"

    const/4 v14, 0x3

    invoke-virtual {v2, v0}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v0

    const/4 v14, 0x0

    const-string v1, "j"

    const-string v1, "j"

    const-string v1, "j"

    const/4 v14, 0x1

    invoke-virtual {v2, v1}, Ljava/lang/Class;->getDeclaredField(Ljava/lang/String;)Ljava/lang/reflect/Field;

    move-result-object v1

    const/4 v14, 0x5

    invoke-virtual {v0, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v14, 0x7

    invoke-virtual {v1, v4}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    const/4 v14, 0x3

    invoke-static {}, Lcom/apkvipo/team$i;->c()Ljava/lang/invoke/MethodHandles$Lookup;

    move-result-object v4

    const/4 v14, 0x7

    invoke-static {v4, v0}, Lcom/apkvipo/team$i;->a(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/reflect/Field;)Ljava/lang/invoke/MethodHandle;

    move-result-object v0

    const/4 v14, 0x3

    invoke-static {}, Lcom/apkvipo/team$i;->c()Ljava/lang/invoke/MethodHandles$Lookup;

    move-result-object v4

    const/4 v14, 0x7

    invoke-static {v4, v1}, Lcom/apkvipo/team$i;->a(Ljava/lang/invoke/MethodHandles$Lookup;Ljava/lang/reflect/Field;)Ljava/lang/invoke/MethodHandle;

    move-result-object v1

    const/4 v14, 0x7

    invoke-virtual {v3, v0, v6, v7}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    const/4 v14, 0x1

    invoke-virtual {v3, v1, v6, v7}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    const/4 v14, 0x5

    invoke-virtual {v3, v2, v10, v11}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J
    :try_end_0
    .catch Ljava/lang/ReflectiveOperationException; {:try_start_0 .. :try_end_0} :catch_0

    const/4 v14, 0x2

    return-void

    :catch_0
    move-exception v0

    const/4 v14, 0x5

    const-string/jumbo v1, "yssBiansdHAipde"

    const-string v1, "BdemiHpinasdAys"

    const-string v1, "BsymnipapdsiAHd"

    const-string v1, "HiddenApiBypass"

    const-string v2, "arieo zieirotolI"

    const-string v2, "retiorilzoie nIa"

    const-string/jumbo v2, "zIirebtrae lniro"

    const-string v2, "Initialize error"

    const/4 v14, 0x1

    invoke-static {v1, v2, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v14, 0x5

    new-instance v1, Ljava/lang/ExceptionInInitializerError;

    const/4 v14, 0x0

    invoke-direct {v1, v0}, Ljava/lang/ExceptionInInitializerError;-><init>(Ljava/lang/Throwable;)V

    const/4 v14, 0x4

    throw v1
.end method

.method public static varargs a(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    .locals 16

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v0, p1

    move-object/from16 v1, p3

    move-object/from16 v1, p3

    move-object/from16 v1, p3

    move-object/from16 v1, p3

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz v0, :cond_1

    invoke-virtual/range {p0 .. p1}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v4

    if-eqz v4, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    const-string/jumbo v1, "v toesuaohsigbi leen  cjthnice nbtst fasa i ntc n"

    const-string v1, "hattnbs ola gcfaeen s i nbocssvii  nstten  hjiect"

    const-string v1, "nivjon p sitio facetactsehsgi nabeh tse co nlt  n"

    const-string/jumbo v1, "this object is not an instance of the given class"

    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    :goto_0
    new-array v4, v3, [Ljava/lang/Class;

    const-class v5, [Ljava/lang/Object;

    const-class v5, [Ljava/lang/Object;

    const-class v5, [Ljava/lang/Object;

    const-class v5, [Ljava/lang/Object;

    aput-object v5, v4, v2

    const-class v5, Lcom/apkvipo/team$e;

    const-class v5, Lcom/apkvipo/team$e;

    const-class v5, Lcom/apkvipo/team$e;

    const-class v5, Lcom/apkvipo/team$e;

    const-string v6, "kvqenu"

    const-string/jumbo v6, "uvnoek"

    const-string v6, "kvsnio"

    const-string v6, "invoke"

    invoke-virtual {v5, v6, v4}, Ljava/lang/Class;->getDeclaredMethod(Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;

    move-result-object v4

    invoke-virtual {v4, v3}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    sget-object v5, Lcom/apkvipo/team$j;->a:Lsun/misc/Unsafe;

    sget-wide v6, Lcom/apkvipo/team$j;->c:J

    move-object/from16 v8, p0

    move-object/from16 v8, p0

    move-object/from16 v8, p0

    move-object/from16 v8, p0

    invoke-virtual {v5, v8, v6, v7}, Lsun/misc/Unsafe;->getLong(Ljava/lang/Object;J)J

    move-result-wide v13

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-wide/16 v6, 0x0

    const-string v15, "gocmnepn ohadm tmidttiaf hn"

    const-string v15, "ncag oapthtdimdmnnC  ihfeto"

    const-string v15, "Cannot find matching method"

    cmp-long v8, v13, v6

    if-eqz v8, :cond_f

    invoke-virtual {v5, v13, v14}, Lsun/misc/Unsafe;->getInt(J)I

    move-result v5

    const/4 v6, 0x0

    :goto_1
    if-ge v6, v5, :cond_e

    int-to-long v7, v6

    sget-wide v9, Lcom/apkvipo/team$j;->d:J

    mul-long v7, v7, v9

    add-long/2addr v7, v13

    sget-wide v9, Lcom/apkvipo/team$j;->e:J

    add-long v11, v7, v9

    sget-object v7, Lcom/apkvipo/team$j;->a:Lsun/misc/Unsafe;

    sget-wide v9, Lcom/apkvipo/team$j;->b:J

    move-object v8, v4

    move-object v8, v4

    move-object v8, v4

    invoke-virtual/range {v7 .. v12}, Lsun/misc/Unsafe;->putLong(Ljava/lang/Object;JJ)V

    invoke-virtual {v4}, Ljava/lang/reflect/Method;->getName()Ljava/lang/String;

    move-result-object v7

    move-object/from16 v8, p2

    move-object/from16 v8, p2

    move-object/from16 v8, p2

    move-object/from16 v8, p2

    invoke-virtual {v8, v7}, Ljava/lang/String;->equals(Ljava/lang/Object;)Z

    move-result v7

    if-eqz v7, :cond_d

    invoke-virtual {v4}, Ljava/lang/reflect/Method;->getParameterTypes()[Ljava/lang/Class;

    move-result-object v7

    array-length v9, v7

    array-length v10, v1

    if-eq v9, v10, :cond_2

    goto/16 :goto_3

    :cond_2
    const/4 v9, 0x0

    :goto_2
    array-length v10, v7

    if-ge v9, v10, :cond_c

    aget-object v10, v7, v9

    invoke-virtual {v10}, Ljava/lang/Class;->isPrimitive()Z

    move-result v10

    if-eqz v10, :cond_a

    aget-object v10, v7, v9

    sget-object v11, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    if-ne v10, v11, :cond_3

    aget-object v11, v1, v9

    instance-of v11, v11, Ljava/lang/Integer;

    if-nez v11, :cond_3

    goto/16 :goto_3

    :cond_3
    sget-object v11, Ljava/lang/Byte;->TYPE:Ljava/lang/Class;

    if-ne v10, v11, :cond_4

    aget-object v11, v1, v9

    instance-of v11, v11, Ljava/lang/Byte;

    if-nez v11, :cond_4

    goto :goto_3

    :cond_4
    sget-object v11, Ljava/lang/Character;->TYPE:Ljava/lang/Class;

    if-ne v10, v11, :cond_5

    aget-object v11, v1, v9

    instance-of v11, v11, Ljava/lang/Character;

    if-nez v11, :cond_5

    goto :goto_3

    :cond_5
    sget-object v11, Ljava/lang/Boolean;->TYPE:Ljava/lang/Class;

    if-ne v10, v11, :cond_6

    aget-object v11, v1, v9

    instance-of v11, v11, Ljava/lang/Boolean;

    if-nez v11, :cond_6

    goto :goto_3

    :cond_6
    sget-object v11, Ljava/lang/Double;->TYPE:Ljava/lang/Class;

    if-ne v10, v11, :cond_7

    aget-object v11, v1, v9

    instance-of v11, v11, Ljava/lang/Double;

    if-nez v11, :cond_7

    goto :goto_3

    :cond_7
    sget-object v11, Ljava/lang/Float;->TYPE:Ljava/lang/Class;

    if-ne v10, v11, :cond_8

    aget-object v11, v1, v9

    instance-of v11, v11, Ljava/lang/Float;

    if-nez v11, :cond_8

    goto :goto_3

    :cond_8
    sget-object v11, Ljava/lang/Long;->TYPE:Ljava/lang/Class;

    if-ne v10, v11, :cond_9

    aget-object v11, v1, v9

    instance-of v11, v11, Ljava/lang/Long;

    if-nez v11, :cond_9

    goto :goto_3

    :cond_9
    sget-object v11, Ljava/lang/Short;->TYPE:Ljava/lang/Class;

    if-ne v10, v11, :cond_b

    aget-object v10, v1, v9

    instance-of v10, v10, Ljava/lang/Short;

    if-nez v10, :cond_b

    goto :goto_3

    :cond_a
    aget-object v10, v1, v9

    if-eqz v10, :cond_b

    aget-object v11, v7, v9

    invoke-virtual {v11, v10}, Ljava/lang/Class;->isInstance(Ljava/lang/Object;)Z

    move-result v10

    if-nez v10, :cond_b

    goto :goto_3

    :cond_b
    add-int/2addr v9, v3

    goto :goto_2

    :cond_c
    invoke-virtual {v4, v0, v1}, Ljava/lang/reflect/Method;->invoke(Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v0

    return-object v0

    :cond_d
    :goto_3
    add-int/2addr v6, v3

    goto/16 :goto_1

    :cond_e
    new-instance v0, Ljava/lang/NoSuchMethodException;

    invoke-direct {v0, v15}, Ljava/lang/NoSuchMethodException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_f
    new-instance v0, Ljava/lang/NoSuchMethodException;

    invoke-direct {v0, v15}, Ljava/lang/NoSuchMethodException;-><init>(Ljava/lang/String;)V

    throw v0
.end method

.method public static varargs b([Ljava/lang/String;)Z
    .locals 9

    const-string v8, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v7, "@~M@ov~~  y@  K/s~~~ . u@  ~ ~~@bd~i  ~l @~@o~fo@@ ~@lt~~ob~ @c~o@r /4@Sma@o-i~@nof@i~~@1@ t~b@ "

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v8, 0x5

    const/4 v0, 0x1

    const/4 v8, 0x0

    const/4 v7, 0x0

    const/4 v8, 0x3

    const/4 v1, 0x0

    const/4 v8, 0x2

    const/4 v7, 0x3

    const/4 v8, 0x6

    const-string v2, "iAeiobpdEqmnsetHxtnise"

    const-string/jumbo v2, "tsiixAEnqieotsHmpeendd"

    const/4 v8, 0x6

    const-string v2, "eExAppusetHntiieidsnod"

    const-string v2, "setHiddenApiExemptions"

    :try_start_0
    const/4 v7, 0x7

    const/4 v8, 0x3

    const-class v3, Ldalvik/system/VMRuntime;

    const-class v3, Ldalvik/system/VMRuntime;

    const/4 v8, 0x4

    const-class v3, Ldalvik/system/VMRuntime;

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x1

    const-string v4, "igmeettpnu"

    const-string v4, "getRuntime"

    const/4 v8, 0x7

    const/4 v7, 0x6

    const/4 v8, 0x1

    new-array v5, v1, [Ljava/lang/Object;

    const/4 v8, 0x0

    const/4 v7, 0x7

    const/4 v8, 0x2

    const/4 v6, 0x0

    const/4 v8, 0x7

    const/4 v7, 0x3

    const/4 v8, 0x6

    invoke-static {v3, v6, v4, v5}, Lcom/apkvipo/team$j;->a(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;

    move-result-object v3

    const/4 v8, 0x5

    const/4 v7, 0x1

    const/4 v8, 0x0

    const-class v4, Ldalvik/system/VMRuntime;

    const-class v4, Ldalvik/system/VMRuntime;

    const/4 v8, 0x5

    const-class v4, Ldalvik/system/VMRuntime;

    const-class v4, Ldalvik/system/VMRuntime;

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x4

    new-array v5, v0, [Ljava/lang/Object;

    const/4 v8, 0x3

    const/4 v7, 0x4

    const/4 v8, 0x2

    aput-object p0, v5, v1

    invoke-static {v4, v3, v2, v5}, Lcom/apkvipo/team$j;->a(Ljava/lang/Class;Ljava/lang/Object;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/Object;
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    const/4 v8, 0x6

    const/4 v7, 0x2

    const/4 v8, 0x5

    return v0

    :catchall_0
    move-exception p0

    const/4 v8, 0x7

    const/4 v7, 0x1

    const/4 v8, 0x7

    const-string v0, "sdsHsiBpypinaeA"

    const/4 v8, 0x5

    const-string v0, "BHasipsnqpdieAd"

    const-string v0, "HiddenApiBypass"

    const/4 v8, 0x1

    const/4 v7, 0x0

    const/4 v8, 0x1

    invoke-static {v0, v2, p0}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    const/4 v8, 0x4

    const/4 v7, 0x3

    const/4 v8, 0x7

    return v1
.end method
