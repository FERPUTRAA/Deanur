.class public final Lcom/apkvipo/team$h;
.super Ljava/lang/Object;


# static fields
.field private static s:I

.field private static t:I


# instance fields
.field private i:I

.field private j:I


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x2

    const/4 v0, 0x2

    const/4 v1, 0x7

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v1, 0x6

    const/4 v0, 0x2

    const/4 v1, 0x6

    return-void
.end method

.method private static a()V
    .locals 2

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, "m s@@o/ ol@@~ 1@~/ b~-~~a@@~oi~@b ~ blir@to~o. ~~ t~ ~S@od~@iM@@~K ~~   nf s4vy@~@~~ @~@@@c@ ~f "

    const-string v0, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v1, 0x0

    return-void
.end method

.method private static b()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x6

    const/4 v1, 0x5

    return-void
.end method
