.class public final Lcom/apkvipo/team$c;
.super Lcom/apkvipo/team$a;


# instance fields
.field private accessFlags:I

.field private artMethod:J

.field private declaringClass:Lcom/apkvipo/team$b;

.field private declaringClassOfOverriddenMethod:Lcom/apkvipo/team$b;

.field private parameters:[Ljava/lang/Object;


# direct methods
.method public constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/apkvipo/team$a;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x6

    const/4 v1, 0x0

    return-void
.end method
