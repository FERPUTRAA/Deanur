.class public final Lcom/apkvipo/team$g;
.super Lcom/apkvipo/team$f;


# instance fields
.field private final info:Ljava/lang/invoke/MethodHandleInfo;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x0

    const/4 v1, 0x4

    const/4 v2, 0x2

    invoke-direct {p0}, Lcom/apkvipo/team$f;-><init>()V

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x7

    const/4 v0, 0x0

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x6

    iput-object v0, p0, Lcom/apkvipo/team$g;->info:Ljava/lang/invoke/MethodHandleInfo;

    const/4 v2, 0x6

    const/4 v1, 0x7

    const/4 v2, 0x7

    return-void
.end method
