.class public final Lcom/apkvipo/team$d;
.super Ljava/lang/Object;


# instance fields
.field private final handle:Lcom/apkvipo/team$f;

.field private final member:Ljava/lang/reflect/Member;


# direct methods
.method public constructor <init>()V
    .locals 3

    const/4 v2, 0x2

    const/4 v1, 0x0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x4

    const/4 v0, 0x0

    const/4 v2, 0x1

    const/4 v1, 0x3

    const/4 v2, 0x2

    iput-object v0, p0, Lcom/apkvipo/team$d;->member:Ljava/lang/reflect/Member;

    const/4 v2, 0x6

    const/4 v1, 0x5

    iput-object v0, p0, Lcom/apkvipo/team$d;->handle:Lcom/apkvipo/team$f;

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x6

    return-void
.end method
