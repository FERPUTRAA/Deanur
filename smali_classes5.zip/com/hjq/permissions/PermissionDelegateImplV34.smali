.class Lcom/hjq/permissions/PermissionDelegateImplV34;
.super Lcom/hjq/permissions/PermissionDelegateImplV33;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    invoke-direct {p0}, Lcom/hjq/permissions/PermissionDelegateImplV33;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x2

    return-void
.end method


# virtual methods
.method public isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z
    .locals 4
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x1

    const-string v0, "_ssosEMICr_mEESdREEEaidTUL.UVILSDAr_pie.ASisoRnDn_"

    const-string v0, "_AsRUV.ID_SnsAimEEErn_LE_EdRISp.oMETesiroaASLCUdiD"

    const/4 v3, 0x2

    const-string v0, "UoimAir.mLrETSAEeSUEdsVnRanDED_Ed_pi__I.DRAIELMoSs"

    const-string v0, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x4

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x1

    if-eqz v0, :cond_2

    const/4 v3, 0x1

    const/4 v2, 0x0

    const/4 v3, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid14()Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    const/4 v1, 0x0

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez v0, :cond_0

    const/4 v3, 0x0

    const/4 v2, 0x6

    const/4 v3, 0x1

    return v1

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x2

    if-nez v0, :cond_1

    const/4 v3, 0x3

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x5

    if-nez p1, :cond_1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    const/4 v1, 0x1

    :cond_1
    const/4 v2, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x4

    return v1

    :cond_2
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV33;->isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x5

    return p1
.end method

.method public isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x0

    const-string v0, "DsURoEi_SRdIariSIUTM_iECAEE.eVAmLD_pALSnDoo_mnrs.d"

    const-string v0, "ViUmosEEnSnCDI_eApDASaUm.rLoTASsiEiRrdMDR_L_dI_E.E"

    const/4 v2, 0x1

    const-string v0, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x4

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid14()Z

    move-result v0

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    if-nez v0, :cond_0

    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x7

    const/4 p1, 0x1

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x4

    return p1

    :cond_0
    const/4 v2, 0x7

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x6

    return p1

    :cond_1
    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x5

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV33;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x1

    const/4 v1, 0x6

    const/4 v2, 0x4

    return p1
.end method

.method public recheckPermissionResult(Landroid/content/Context;Ljava/lang/String;Z)Z
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid14()Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x4

    if-eqz v0, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string v0, "D.o.abdd_irEnIAnASeREDsomE_MpAsirMIG"

    const-string v0, "android.permission.READ_MEDIA_IMAGES"

    const/4 v3, 0x1

    const-string v1, "_oRoEduOAreVDoiEsn_aErdDiMnAIsIpm.i"

    const-string v1, "_rIAoEnaiiDr.InsVdOAmDEsDdepio_MERo"

    const/4 v3, 0x4

    const-string v1, "DeIoEsApIipDnrrAodsi_VnEmM_EdOi.aRD"

    const-string v1, "android.permission.READ_MEDIA_VIDEO"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x2

    filled-new-array {v0, v1}, [Ljava/lang/String;

    move-result-object v0

    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {v0, p2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x4

    const-string p2, "r_eAUbSES_spaDEEI_iiE.dRr_MmEDLRAdLiUnIDAsVETo.onC"

    const/4 v3, 0x3

    const-string p2, "android.permission.READ_MEDIA_VISUAL_USER_SELECTED"

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV34;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x5

    return p1

    :cond_0
    const/4 v3, 0x3

    invoke-super {p0, p1, p2, p3}, Lcom/hjq/permissions/PermissionDelegateImplV33;->recheckPermissionResult(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x4

    return p1
.end method
