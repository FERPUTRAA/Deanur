.class Lcom/hjq/permissions/PermissionDelegateImplV33;
.super Lcom/hjq/permissions/PermissionDelegateImplV31;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x4

    const/4 v0, 0x2

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/hjq/permissions/PermissionDelegateImplV31;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    return-void
.end method


# virtual methods
.method public getPermissionSettingIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v1, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v0, ".OsAPa.oiCSoedFNnsTiIiTOrnISpITdONsmr"

    const/4 v2, 0x7

    const-string v0, "android.permission.POST_NOTIFICATIONS"

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-eqz v0, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/hjq/permissions/NotificationPermissionCompat;->getPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x4

    return-object p1

    :cond_0
    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV31;->getPermissionSettingIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x4

    const/4 v2, 0x5

    return-object p1
.end method

.method public isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z
    .locals 10
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x6

    const-string v0, "i.soRNUd.rnEpSma_KiRAmOSosDsdNDSniBBr_GeOO"

    const-string v0, "aErmNiUeKSoiBpn.OrG_sYRSoSDOmB.dN_sOdADRin"

    const/4 v9, 0x5

    const-string v0, "pS_mdDYGRSNsOoKnCR.dOisi_nBrAOr.UEeBoSmiaN"

    const-string v0, "android.permission.BODY_SENSORS_BACKGROUND"

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v1, 0x4

    const/4 v1, 0x1

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x4

    const/4 v2, 0x0

    const/4 v9, 0x1

    const/4 v8, 0x7

    if-eqz v0, :cond_5

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x7

    if-nez v0, :cond_0

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x6

    return v2

    :cond_0
    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x1

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x1

    const-string v3, "SoadosYSRnoidois.eimOOnr_BNpESD"

    const-string v3, ".soYoSOSDpdNnndaiosROBEi.Srie_m"

    const/4 v9, 0x6

    const-string v3, "SmsrpbdSiEOnDa.dnNeoROBiiYo_S.s"

    const-string v3, "android.permission.BODY_SENSORS"

    const/4 v9, 0x7

    if-nez v0, :cond_2

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x3

    if-nez p2, :cond_1

    const/4 v8, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x3

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-nez p1, :cond_1

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x3

    goto :goto_0

    :cond_1
    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x2

    move v1, v2

    move v1, v2

    const/4 v9, 0x4

    move v1, v2

    move v1, v2

    :goto_0
    return v1

    :cond_2
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x1

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-nez v0, :cond_3

    const/4 v8, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x0

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x1

    xor-int/2addr p1, v1

    const/4 v9, 0x0

    return p1

    :cond_3
    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x7

    if-nez v0, :cond_4

    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x7

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-nez p1, :cond_4

    const/4 v9, 0x2

    const/4 v8, 0x1

    const/4 v9, 0x0

    goto :goto_1

    :cond_4
    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x2

    move v1, v2

    move v1, v2

    const/4 v9, 0x0

    move v1, v2

    move v1, v2

    :goto_1
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x6

    return v1

    :cond_5
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x5

    const-string v0, "iipFsTuaIonb_sSNiONdrdOeTrnIm.CPIoTSA"

    const-string v0, "IsCoSbsTaiPmOTd.NOoid_ISeOnFniANrrTIp"

    const/4 v9, 0x4

    const-string v0, "rmArOoOpnCdiT.iFOIoiTaP.dNsp_nsIIeNST"

    const-string v0, "android.permission.POST_NOTIFICATIONS"

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-eqz v0, :cond_8

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x7

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    if-nez v0, :cond_6

    const/4 v9, 0x1

    return v2

    :cond_6
    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x1

    if-nez v0, :cond_7

    const/4 v9, 0x0

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x7

    const/4 v8, 0x4

    const/4 v9, 0x4

    if-nez p1, :cond_7

    const/4 v9, 0x7

    const/4 v8, 0x2

    const/4 v9, 0x7

    goto :goto_2

    :cond_7
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x1

    move v1, v2

    move v1, v2

    :goto_2
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x4

    return v1

    :cond_8
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x0

    const-string v0, "DRFiSip_qmoYCEondrEBAVsIIird.sanIN.EWe"

    const-string v0, "android.permission.NEARBY_WIFI_DEVICES"

    const/4 v9, 0x5

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    if-eqz v0, :cond_d

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x1

    if-nez v0, :cond_9

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x6

    return v2

    :cond_9
    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x6

    const/4 v9, 0x5

    if-nez v0, :cond_b

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x7

    const-string p2, "FosrdsirAmuiICSEASa_O.NnpoIeNiCO.LdCsET"

    const-string p2, "AAONdTuiFnanmSseOEd.or.NC_siiSCICErIpoL"

    const/4 v9, 0x2

    const-string p2, "iOTmEIdoCFnNiE.pnISACN_SdeO.msisro_CrLA"

    const-string p2, "android.permission.ACCESS_FINE_LOCATION"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x6

    const/4 v9, 0x6

    if-nez v0, :cond_a

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x6

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x0

    if-nez p1, :cond_a

    const/4 v9, 0x2

    goto :goto_3

    :cond_a
    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x3

    move v1, v2

    move v1, v2

    const/4 v9, 0x6

    move v1, v2

    move v1, v2

    :goto_3
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    return v1

    :cond_b
    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x2

    if-nez v0, :cond_c

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x4

    if-nez p1, :cond_c

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_4

    :cond_c
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x3

    move v1, v2

    const/4 v9, 0x0

    move v1, v2

    move v1, v2

    :goto_4
    const/4 v9, 0x0

    const/4 v8, 0x6

    return v1

    :cond_d
    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x7

    const-string v0, "ADDronpEoRdpoMSs.I_dariAIGiM.iE_AnEs"

    const-string v0, "ARoirnIpiMsdA_sMnDEeI.rodEiG_EAap.DS"

    const/4 v9, 0x1

    const-string v0, "onI_MbDpDonE.RIerrAmdGsasEii.AM_iAdS"

    const-string v0, "android.permission.READ_MEDIA_IMAGES"

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x6

    const-string v3, "AmRiEiunrdsOEo_MAI_i.EVqaonD.DsDrpI"

    const-string v3, "adMsDRn.q__iIoDrArDdmOn.EVopsEiEIAi"

    const/4 v9, 0x3

    const-string v3, "iseiIRApoaEIndD_DODrMVAinp_rd.Es.oE"

    const-string v3, "android.permission.READ_MEDIA_VIDEO"

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x4

    const-string v4, "i_doI.Aoq_mIRDAsrDiMspUAOdinreDsnEa"

    const-string v4, "oAsessdDRAoAnEdIDpD.EOIrianr_Mii_Um"

    const/4 v9, 0x2

    const-string v4, "android.permission.READ_MEDIA_AUDIO"

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x5

    filled-new-array {v0, v3, v4}, [Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x4

    const/4 v8, 0x4

    const/4 v9, 0x2

    invoke-static {v5, p2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x7

    const-string v6, "rdsXnTDemORSonEEEopEArRasiLAmR_G_NsT.idA"

    const-string v6, "mrAmTdnerENaLRRdEoiXTD_EpAii_sORSAnsoE.G"

    const/4 v9, 0x3

    const-string v6, "TAEmn_rEm.odi.RAaNRdOXesiriRDTsnpoE_EALS"

    const-string v6, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v9, 0x1

    if-eqz v5, :cond_12

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x0

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-nez v0, :cond_e

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x0

    return v2

    :cond_e
    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x6

    if-nez v0, :cond_10

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x1

    invoke-static {p1, v6}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x5

    if-nez p2, :cond_f

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x5

    invoke-static {p1, v6}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    if-nez p1, :cond_f

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x7

    goto :goto_5

    :cond_f
    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x6

    move v1, v2

    move v1, v2

    const/4 v9, 0x1

    move v1, v2

    :goto_5
    const/4 v9, 0x5

    return v1

    :cond_10
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x7

    const/4 v9, 0x3

    if-nez v0, :cond_11

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x3

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x1

    const/4 v8, 0x7

    const/4 v9, 0x2

    if-nez p1, :cond_11

    const/4 v8, 0x1

    move v9, v8

    goto :goto_6

    :cond_11
    const/4 v9, 0x7

    const/4 v8, 0x0

    const/4 v9, 0x6

    move v1, v2

    move v1, v2

    const/4 v9, 0x4

    move v1, v2

    move v1, v2

    :goto_6
    const/4 v9, 0x0

    const/4 v8, 0x7

    const/4 v9, 0x1

    return v1

    :cond_12
    const/4 v8, 0x6

    move v9, v8

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v5

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-eqz v5, :cond_15

    const/4 v9, 0x3

    const/4 v8, 0x1

    const/4 v9, 0x5

    invoke-static {p1}, Lcom/hjq/permissions/AndroidVersion;->getTargetSdkVersionCode(Landroid/content/Context;)I

    move-result v5

    const/4 v9, 0x2

    const/4 v8, 0x3

    const/16 v7, 0x21

    const/4 v8, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    if-lt v5, v7, :cond_15

    const/4 v9, 0x4

    const/4 v8, 0x1

    const-string v5, "mdaAoNopWssEreSrdTRXi_GOi.ERAREIE_TionnLo"

    const-string v5, "rRoTodpESW_AATeindO_snRELaNoiTEsmri.RXIGE"

    const/4 v9, 0x5

    const-string v5, "NEsmsbLpTXTr_diiAGordaoROER_eTE.iEnSWAI.R"

    const-string v5, "android.permission.WRITE_EXTERNAL_STORAGE"

    const/4 v9, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {p2, v5}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x0

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-eqz v5, :cond_13

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x7

    return v2

    :cond_13
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x2

    invoke-static {p2, v6}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-eqz v5, :cond_15

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x4

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x1

    if-nez p2, :cond_14

    const/4 v9, 0x5

    const/4 v8, 0x7

    const/4 v9, 0x6

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-nez p2, :cond_14

    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x5

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x3

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-nez p2, :cond_14

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x4

    if-nez p2, :cond_14

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-static {p1, v4}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x5

    const/4 v8, 0x4

    const/4 v9, 0x3

    if-nez p2, :cond_14

    const/4 v8, 0x1

    move v9, v8

    invoke-static {p1, v4}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x4

    if-nez p1, :cond_14

    const/4 v9, 0x3

    const/4 v8, 0x7

    const/4 v9, 0x3

    goto :goto_7

    :cond_14
    const/4 v9, 0x6

    move v1, v2

    move v1, v2

    :goto_7
    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    return v1

    :cond_15
    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x0

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV31;->isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x0

    return p1
.end method

.method public isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 10
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x5

    const-string v0, "_rYSSiuoKDiordNAbanOsR.GsCUBdpNOem_nBiRSDO"

    const-string v0, "aSRndbdEOremisRio.oNOGpOBCn_SUiSN_KDYrADsB"

    const/4 v9, 0x2

    const-string v0, "oDNO_sApRd.GB_pDrdYamBiirSREOoUKCiOsNS.Sne"

    const-string v0, "android.permission.BODY_SENSORS_BACKGROUND"

    const/4 v9, 0x2

    const/4 v8, 0x4

    const/4 v9, 0x1

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x4

    const/4 v1, 0x0

    const/4 v9, 0x2

    const/4 v2, 0x0

    const/4 v9, 0x5

    const/4 v2, 0x1

    const/4 v9, 0x0

    const/4 v8, 0x0

    if-eqz v0, :cond_3

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x7

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v9, 0x7

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-nez v0, :cond_0

    const/4 v9, 0x3

    const/4 v8, 0x0

    const/4 v9, 0x0

    return v2

    :cond_0
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x6

    const/4 v9, 0x6

    const-string v3, "dasrnRsiqm_SinYpEN.OSid.uDroSBO"

    const-string v3, "edO.iOumNssaSidSnD_oRr.YipnEBSr"

    const/4 v9, 0x7

    const-string v3, ".DsSnirodmpRi_dNSnOsOoeSB.Yiras"

    const-string v3, "android.permission.BODY_SENSORS"

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x7

    if-nez v0, :cond_1

    const/4 v9, 0x2

    const/4 v8, 0x6

    const/4 v9, 0x6

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x2

    return p1

    :cond_1
    const/4 v9, 0x0

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-eqz v0, :cond_2

    const/4 v9, 0x6

    const/4 v8, 0x7

    const/4 v9, 0x0

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x4

    if-eqz p1, :cond_2

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x2

    move v1, v2

    move v1, v2

    const/4 v9, 0x3

    move v1, v2

    :cond_2
    const/4 v9, 0x7

    const/4 v8, 0x6

    const/4 v9, 0x4

    return v1

    :cond_3
    const/4 v8, 0x0

    move v9, v8

    const-string v0, "OOIAsSipnrpIro_.O.TFsddmniNiaNePSICTo"

    const/4 v9, 0x2

    const-string v0, "oramSmNITTCdOpO..sIAiToPFedii_NrSOnnI"

    const-string v0, "android.permission.POST_NOTIFICATIONS"

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x2

    const/4 v8, 0x5

    const/4 v9, 0x7

    if-eqz v0, :cond_5

    const/4 v9, 0x6

    const/4 v8, 0x3

    const/4 v9, 0x0

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v0

    const/4 v9, 0x1

    const/4 v8, 0x3

    const/4 v9, 0x2

    if-nez v0, :cond_4

    const/4 v9, 0x5

    const/4 v8, 0x5

    const/4 v9, 0x3

    invoke-static {p1}, Lcom/hjq/permissions/NotificationPermissionCompat;->isGrantedPermission(Landroid/content/Context;)Z

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x7

    const/4 v9, 0x2

    return p1

    :cond_4
    const/4 v9, 0x0

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x0

    const/4 v8, 0x0

    const/4 v9, 0x1

    return p1

    :cond_5
    const/4 v8, 0x5

    const/4 v8, 0x2

    const/4 v9, 0x1

    const-string v0, "mDrnopVCiEre_dI.oWiNBni.qdERIsESaFsIA_"

    const-string v0, "pRNEr.DCqdEIVmYie.rnBaI_WiAFEdnss_SoIi"

    const/4 v9, 0x0

    const-string v0, "BEI_YbdWinpEnCdmS_sr.os.IioEaFreNDAiVI"

    const-string v0, "android.permission.NEARBY_WIFI_DEVICES"

    const/4 v9, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x3

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v9, 0x3

    const/4 v8, 0x5

    const/4 v9, 0x5

    if-eqz v0, :cond_8

    const/4 v9, 0x3

    const/4 v8, 0x6

    const/4 v9, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v9, 0x0

    const/4 v8, 0x4

    const/4 v9, 0x1

    if-nez v0, :cond_6

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x1

    return v2

    :cond_6
    const/4 v9, 0x0

    const/4 v8, 0x2

    const/4 v9, 0x4

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v0

    const/4 v9, 0x6

    const/4 v8, 0x1

    const/4 v9, 0x3

    if-nez v0, :cond_7

    const/4 v9, 0x5

    const-string p2, "e.oiiduIdCsniCO_pArESIOE_aNNnsrmoFTASCs"

    const-string p2, "AFsd.IIrnSACENESOCo_iaiNrnp_CmesOisT.do"

    const/4 v9, 0x1

    const-string p2, "NrNCEiOpna_..sLeiprAsdOoITioFCmAnSdEC_S"

    const-string p2, "android.permission.ACCESS_FINE_LOCATION"

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x1

    const/4 v8, 0x1

    const/4 v9, 0x5

    return p1

    :cond_7
    const/4 v8, 0x0

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x6

    const/4 v8, 0x0

    const/4 v9, 0x4

    return p1

    :cond_8
    const/4 v9, 0x6

    const-string v0, "android.permission.READ_MEDIA_IMAGES"

    const/4 v9, 0x5

    const/4 v8, 0x6

    const/4 v9, 0x3

    const-string v3, "snDeEAiiqnmIAOM_VrprRiEa.dsDIod_oD."

    const-string v3, "sMomEDVEdnsEIoIiRdDirpOi_AaDn..A_re"

    const/4 v9, 0x5

    const-string v3, "aesEoIArmiVE_sipIdOiRD._rnsoDA.dMDn"

    const-string v3, "android.permission.READ_MEDIA_VIDEO"

    const/4 v9, 0x2

    const/4 v8, 0x2

    const/4 v9, 0x3

    const-string v4, "IoomDarsiORmA_dEUIAdMr.A_nnD.EseoiD"

    const-string v4, "dIDso.Rae_EoArpnADIro_DOMi.mdnAsEiU"

    const/4 v9, 0x7

    const-string v4, "DeDroodA_sndmAnDOEIiMRUa.rIpi_.Asoi"

    const-string v4, "android.permission.READ_MEDIA_AUDIO"

    const/4 v9, 0x4

    const/4 v8, 0x2

    filled-new-array {v0, v3, v4}, [Ljava/lang/String;

    move-result-object v5

    const/4 v9, 0x6

    const/4 v8, 0x2

    const/4 v9, 0x5

    invoke-static {v5, p2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x2

    const/4 v8, 0x2

    const-string v6, "ERoAdbEo.dNaAr_.nipRbiSEXEOAmT_sLrRnDeGs"

    const-string v6, "EiR_Eb_ALEmGAoXNsrdRoTiepDSd.aO.EriARsnn"

    const/4 v9, 0x3

    const-string v6, "i.AsGauDOnAoNRLrnRXdEi_T.seRiEdrASEpE_oT"

    const-string v6, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x6

    if-eqz v5, :cond_b

    const/4 v8, 0x7

    const/4 v8, 0x3

    const/4 v9, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x5

    const/4 v9, 0x1

    if-nez v0, :cond_9

    const/4 v9, 0x1

    return v2

    :cond_9
    const/4 v9, 0x0

    const/4 v8, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v0

    const/4 v9, 0x4

    const/4 v8, 0x7

    if-nez v0, :cond_a

    const/4 v9, 0x5

    const/4 v8, 0x3

    const/4 v9, 0x5

    invoke-static {p1, v6}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x7

    const/4 v8, 0x7

    const/4 v9, 0x7

    return p1

    :cond_a
    const/4 v9, 0x0

    const/4 v8, 0x1

    const/4 v9, 0x6

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x3

    const/4 v8, 0x2

    const/4 v9, 0x6

    return p1

    :cond_b
    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x4

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v5

    const/4 v9, 0x2

    const/4 v8, 0x0

    const/4 v9, 0x3

    if-eqz v5, :cond_e

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x4

    invoke-static {p1}, Lcom/hjq/permissions/AndroidVersion;->getTargetSdkVersionCode(Landroid/content/Context;)I

    move-result v5

    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x0

    const/16 v7, 0x21

    const/4 v9, 0x4

    const/4 v8, 0x1

    const/4 v9, 0x0

    if-lt v5, v7, :cond_e

    const/4 v9, 0x2

    const-string v5, "WXepduspALSrRmIO_niGiAnTsE.NRoiRoErTEa_dE"

    const-string v5, "RSnAERuGds_ipTLXrdri.nNom.WAEsOTEiIoae_ER"

    const/4 v9, 0x1

    const-string v5, "WRSAALsdqI_.TmdRXnTprERENG.o_aioeirEiTnsO"

    const-string v5, "android.permission.WRITE_EXTERNAL_STORAGE"

    const/4 v8, 0x3

    move v9, v8

    invoke-static {p2, v5}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x1

    const/4 v8, 0x2

    const/4 v9, 0x0

    if-eqz v5, :cond_c

    const/4 v9, 0x4

    const/4 v8, 0x3

    const/4 v9, 0x2

    return v2

    :cond_c
    const/4 v9, 0x3

    invoke-static {p2, v6}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v5

    const/4 v9, 0x7

    const/4 v8, 0x1

    const/4 v9, 0x6

    if-eqz v5, :cond_e

    const/4 v9, 0x4

    const/4 v8, 0x2

    const/4 v9, 0x2

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x5

    const/4 v8, 0x1

    const/4 v9, 0x5

    if-eqz p2, :cond_d

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x4

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p2

    const/4 v9, 0x5

    const/4 v8, 0x6

    if-eqz p2, :cond_d

    const/4 v9, 0x5

    const/4 v8, 0x0

    const/4 v9, 0x6

    invoke-static {p1, v4}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x4

    const/4 v8, 0x0

    const/4 v9, 0x4

    if-eqz p1, :cond_d

    const/4 v9, 0x6

    const/4 v8, 0x6

    const/4 v9, 0x0

    move v1, v2

    move v1, v2

    const/4 v9, 0x1

    move v1, v2

    move v1, v2

    :cond_d
    const/4 v9, 0x3

    const/4 v8, 0x4

    const/4 v9, 0x1

    return v1

    :cond_e
    const/4 v9, 0x6

    const/4 v8, 0x4

    const/4 v9, 0x6

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV31;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v9, 0x1

    const/4 v8, 0x5

    const/4 v9, 0x2

    return p1
.end method

.method public recheckPermissionResult(Landroid/content/Context;Ljava/lang/String;Z)Z
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    if-eqz v0, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p1}, Lcom/hjq/permissions/AndroidVersion;->getTargetSdkVersionCode(Landroid/content/Context;)I

    move-result v0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x1

    const/16 v1, 0x21

    const/4 v3, 0x0

    const/4 v2, 0x3

    if-lt v0, v1, :cond_0

    const/4 v2, 0x3

    move v3, v2

    const-string v0, "rAsio_SWmRRpdTpTasiLXEis.oeEETGROE.Nd_nnA"

    const-string v0, "dmsEo.EpETriNeIRWGsidEaRRTo_.XTiOpnnASAL_"

    const/4 v3, 0x0

    const-string v0, "sEEmooaARrdLRT.X_iGRTiINpeEnASrEOdTWimns_"

    const-string v0, "android.permission.WRITE_EXTERNAL_STORAGE"

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x5

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-eqz v0, :cond_0

    const/4 v3, 0x5

    const/4 v2, 0x0

    const/4 v3, 0x1

    invoke-virtual {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV33;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x1

    return p1

    :cond_0
    const/4 v3, 0x0

    const/4 v2, 0x0

    invoke-super {p0, p1, p2, p3}, Lcom/hjq/permissions/PermissionDelegateImplV23;->recheckPermissionResult(Landroid/content/Context;Ljava/lang/String;Z)Z

    move-result p1

    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x1

    return p1
.end method
