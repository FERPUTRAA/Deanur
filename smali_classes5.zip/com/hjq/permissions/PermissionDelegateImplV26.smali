.class Lcom/hjq/permissions/PermissionDelegateImplV26;
.super Lcom/hjq/permissions/PermissionDelegateImplV23;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x6

    const/4 v0, 0x1

    const/4 v1, 0x2

    invoke-direct {p0}, Lcom/hjq/permissions/PermissionDelegateImplV23;-><init>()V

    const/4 v1, 0x7

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method private static getInstallPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x1a
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string v2, "bss@  @dc b~om@v~~a~lf n~@. y-@  K~ @ i  ~ t~uM/@~b@~~@~~ @~@ ~@@ifolo/ r~S ~o~@@~~t~4@i@o1~o@@@"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x7

    const/4 v2, 0x7

    const-string v1, "RCrmAdsEWGnnNMe.S_sAOsANN.UUtPEtaNg_odiiS_O"

    const-string v1, "StsgiMNsiNE.eAOaCWn.ANrUtP_EoR_P_GdsOSAUNdn"

    const-string v1, "ENtioNe.UOM_niPWaSo_AdgCGsNAE_Ps.OKRtUNnrdA"

    const-string v1, "android.settings.MANAGE_UNKNOWN_APP_SOURCES"

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->getPackageNameUri(Landroid/content/Context;)Landroid/net/Uri;

    move-result-object v1

    const/4 v3, 0x3

    const/4 v2, 0x2

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v3, 0x1

    const/4 v2, 0x6

    const/4 v3, 0x6

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v1

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x6

    if-nez v1, :cond_0

    const/4 v3, 0x4

    const/4 v2, 0x0

    invoke-static {p0}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    :cond_0
    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x4

    return-object v0
.end method

.method private static getPictureInPicturePermissionIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x1a
    .end annotation

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x0

    new-instance v0, Landroid/content/Intent;

    const/4 v2, 0x7

    const/4 v2, 0x2

    const/4 v3, 0x3

    const-string v1, "IE.mGCst_nUPaIi_dIPTUdTNSTseotSTNnr_iERgECI."

    const/4 v3, 0x0

    const-string v1, "dITECbISdCsiENIg_o.iTt_TPsTnEnarGRR.tUUIP_eN"

    const-string v1, "android.settings.PICTURE_IN_PICTURE_SETTINGS"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x0

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->getPackageNameUri(Landroid/content/Context;)Landroid/net/Uri;

    move-result-object v1

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x3

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x2

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v1

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez v1, :cond_0

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p0}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    return-object v0
.end method

.method private static isGrantedInstallPermission(Landroid/content/Context;)Z
    .locals 2
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x1a
    .end annotation

    const/4 v1, 0x0

    const/4 v0, 0x4

    const/4 v1, 0x2

    invoke-virtual {p0}, Landroid/content/Context;->getPackageManager()Landroid/content/pm/PackageManager;

    move-result-object p0

    const/4 v1, 0x1

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-static {p0}, Lcom/hjq/permissions/e;->a(Landroid/content/pm/PackageManager;)Z

    move-result p0

    const/4 v1, 0x5

    const/4 v0, 0x4

    const/4 v1, 0x3

    return p0
.end method

.method private static isGrantedPictureInPicturePermission(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x1a
    .end annotation

    const/4 v2, 0x5

    const/4 v1, 0x3

    const/4 v2, 0x2

    const-string v0, "in_coerar:tuditrdpuni_cpoe"

    const/4 v2, 0x4

    const-string/jumbo v0, "unto_tua_rireduiride:cpcin"

    const-string v0, "android:picture_in_picture"

    const/4 v2, 0x5

    const/4 v1, 0x1

    const/4 v2, 0x2

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->checkOpNoThrow(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p0

    const/4 v2, 0x3

    const/4 v1, 0x5

    const/4 v2, 0x3

    return p0
.end method


# virtual methods
.method public getPermissionSettingIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x2

    const/4 v2, 0x0

    const-string v0, "NSAiSb.pdasIUL.sPGe_iA_KrnEoErdATmoSEQRnTCp"

    const-string v0, ".ATEEbe.iQLoTrSGAiNdssCmKEnndP_SA_UISaiorpR"

    const/4 v2, 0x2

    const-string v0, "ApP.C_.mqLSNAeIndUGTEroEi_iTaLRsAisnESSrKoQ"

    const-string v0, "android.permission.REQUEST_INSTALL_PACKAGES"

    const/4 v2, 0x4

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x7

    const/4 v1, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x6

    const/4 v1, 0x6

    const/4 v2, 0x0

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid8()Z

    move-result p2

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x4

    if-nez p2, :cond_0

    const/4 v2, 0x1

    const/4 v1, 0x0

    const/4 v2, 0x7

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p1

    :cond_0
    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV26;->getInstallPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    return-object p1

    :cond_1
    const/4 v2, 0x4

    const-string v0, "P_sme.UECsTrspodio.IITrRnRP_InNECauid"

    const-string v0, "EEC.TsuodNriTen.ImIiRPU_sainRor_PpIdC"

    const-string v0, "oP.mpERiURnasiNIdTn_CrICieUsdP_moT.IE"

    const-string v0, "android.permission.PICTURE_IN_PICTURE"

    const/4 v2, 0x0

    const/4 v1, 0x6

    const/4 v2, 0x7

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x6

    if-eqz v0, :cond_3

    const/4 v2, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid8()Z

    move-result p2

    const/4 v2, 0x6

    const/4 v1, 0x4

    const/4 v2, 0x4

    if-nez p2, :cond_2

    const/4 v2, 0x2

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x0

    return-object p1

    :cond_2
    const/4 v2, 0x7

    const/4 v1, 0x4

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV26;->getPictureInPicturePermissionIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x1

    return-object p1

    :cond_3
    const/4 v2, 0x4

    const/4 v1, 0x3

    const/4 v2, 0x1

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV23;->getPermissionSettingIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x4

    return-object p1
.end method

.method public isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z
    .locals 5
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x2

    const-string v0, "_iA.or_TTSsod.oARINSULrnGCApiLPKmSdeiEQanEE"

    const-string v0, "android.permission.REQUEST_INSTALL_PACKAGES"

    const/4 v4, 0x2

    const/4 v3, 0x7

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x4

    const/4 v1, 0x0

    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x2

    if-eqz v0, :cond_0

    const/4 v4, 0x4

    const/4 v3, 0x6

    return v1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    const-string v0, "sEeTPbm.Esp_CoPnUiUTRnCIaoiI_prdRNIri"

    const-string v0, "CeEmo.UpoIdPn_sTTiaEpiCndNsRr_RIUrIiP"

    const/4 v4, 0x1

    const-string v0, ".EaETeu_soI_CrsRPidnTUoNrUIiImdnip.RP"

    const-string v0, "android.permission.PICTURE_IN_PICTURE"

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x7

    const/4 v4, 0x2

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x5

    return v1

    :cond_1
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    const-string v0, "NErRnMNpaUH__n.eSOopiAsPrisDqRmEo.diE"

    const-string v0, "OSMoiRrEqUPdRAEiHeNsD_N.rnisonmEad_p."

    const/4 v4, 0x1

    const-string v0, "ENEo_Os_qnaMiiBSm.EUniReRHr.oADspddPr"

    const-string v0, "android.permission.READ_PHONE_NUMBERS"

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x5

    const/4 v4, 0x2

    const/4 v2, 0x1

    const/4 v4, 0x3

    if-eqz v0, :cond_6

    const/4 v4, 0x2

    const/4 v3, 0x5

    const/4 v4, 0x7

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    if-nez v0, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x2

    return v1

    :cond_2
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid8()Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x0

    if-nez v0, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x3

    const-string p2, "oisOAEipe_TsA.HnrEdTrNmSD_ioEds.nRP"

    const-string p2, "dosOE.H_TdnpR.inTDNm_ArriSsoAsiPeEE"

    const/4 v4, 0x5

    const-string p2, "iAdmPeniETNATsSop_rEO.RDi._dEHnsrma"

    const-string p2, "android.permission.READ_PHONE_STATE"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x3

    if-nez v0, :cond_3

    const/4 v4, 0x5

    const/4 v3, 0x4

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez p1, :cond_3

    const/4 v4, 0x2

    const/4 v3, 0x4

    const/4 v4, 0x4

    move v1, v2

    move v1, v2

    :cond_3
    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x1

    return v1

    :cond_4
    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x7

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x1

    if-nez v0, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x3

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x7

    if-nez p1, :cond_5

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x3

    move v1, v2

    const/4 v4, 0x2

    move v1, v2

    move v1, v2

    :cond_5
    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x6

    return v1

    :cond_6
    const/4 v4, 0x4

    const/4 v3, 0x1

    const-string v0, "snpmCN_Pond..oRmiirSsW_ELAeiASHrNOadL"

    const/4 v4, 0x5

    const-string v0, "SpiAoHnPN.AdOnEeisSo_riWaodr.sELNRmC_"

    const-string v0, "android.permission.ANSWER_PHONE_CALLS"

    const/4 v4, 0x4

    const/4 v3, 0x7

    const/4 v4, 0x2

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    if-eqz v0, :cond_9

    const/4 v4, 0x0

    const/4 v3, 0x7

    const/4 v4, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid8()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x1

    if-nez v0, :cond_7

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x5

    return v1

    :cond_7
    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x0

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x3

    if-nez v0, :cond_8

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x3

    if-nez p1, :cond_8

    const/4 v4, 0x5

    const/4 v3, 0x2

    const/4 v4, 0x7

    move v1, v2

    move v1, v2

    const/4 v4, 0x5

    move v1, v2

    move v1, v2

    :cond_8
    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    return v1

    :cond_9
    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV23;->isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x2

    const/4 v4, 0x7

    return p1
.end method

.method public isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x0

    const-string v0, "n_Up_bACme.GSTTiSRnsPaAiEoE.drLsEIKoSdoQLNr"

    const-string v0, "nT_aoTooRSLQISrnrAEmEsGd.P.AiCeASEdKiUN_sLp"

    const/4 v3, 0x0

    const-string v0, "Tmio_surUn.iTr.dSRaL_GKECAisSApLoQENIeSEdAn"

    const-string v0, "android.permission.REQUEST_INSTALL_PACKAGES"

    const/4 v2, 0x4

    move v3, v2

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x2

    const/4 v1, 0x1

    const/4 v3, 0x3

    if-eqz v0, :cond_1

    const/4 v3, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid8()Z

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-nez p2, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x5

    const/4 v3, 0x6

    return v1

    :cond_0
    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x3

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV26;->isGrantedInstallPermission(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x1

    return p1

    :cond_1
    const/4 v3, 0x3

    const/4 v2, 0x7

    const/4 v3, 0x2

    const-string v0, "EIaniRopTPUCeCiTipRIdUro__ENP.Idm.sns"

    const-string v0, "android.permission.PICTURE_IN_PICTURE"

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x7

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-eqz v0, :cond_3

    const/4 v3, 0x2

    const/4 v2, 0x5

    const/4 v3, 0x4

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid8()Z

    move-result p2

    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x4

    if-nez p2, :cond_2

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x3

    return v1

    :cond_2
    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x0

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV26;->isGrantedPictureInPicturePermission(Landroid/content/Context;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    return p1

    :cond_3
    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x7

    const-string v0, "_aNr.ns_qUEOioobNSep.siABDniEdRdmMERr"

    const-string v0, "oEiidbBdriN__nrsnOERMEapPRoDUm.sSNAe."

    const/4 v3, 0x7

    const-string v0, "RasrNpSEidsiAnRHO.Br_ioEPd_mDeo.EUnsN"

    const-string v0, "android.permission.READ_PHONE_NUMBERS"

    const/4 v3, 0x0

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    if-eqz v0, :cond_6

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x0

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v3, 0x4

    const/4 v2, 0x7

    const/4 v3, 0x7

    if-nez v0, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x1

    return v1

    :cond_4
    const/4 v3, 0x1

    const/4 v2, 0x4

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid8()Z

    move-result v0

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x3

    if-nez v0, :cond_5

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x3

    const-string p2, "OmAmdEdSs_EiTr.siAaRoTeN.oPiEr_nnpD"

    const-string p2, "android.permission.READ_PHONE_STATE"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x4

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x0

    const/4 v3, 0x2

    return p1

    :cond_5
    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x7

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x5

    const/4 v3, 0x5

    return p1

    :cond_6
    const/4 v2, 0x0

    const/4 v2, 0x0

    const/4 v3, 0x5

    const-string v0, "oS.SouEARdsW_A.rEaCiOLnpiorPiNLsHdnme"

    const-string v0, "dWneiruSEmisdapO.LSHRoPoniA_C.NLrsE_A"

    const/4 v3, 0x7

    const-string v0, "S.anrbWLS_N.soidHNPAonEOiRspCeAmEriL_"

    const-string v0, "android.permission.ANSWER_PHONE_CALLS"

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-eqz v0, :cond_8

    const/4 v3, 0x1

    const/4 v2, 0x7

    const/4 v3, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid8()Z

    move-result v0

    const/4 v3, 0x0

    const/4 v2, 0x7

    const/4 v3, 0x2

    if-nez v0, :cond_7

    const/4 v3, 0x5

    const/4 v2, 0x5

    const/4 v3, 0x4

    return v1

    :cond_7
    const/4 v3, 0x1

    const/4 v2, 0x4

    const/4 v3, 0x6

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x4

    const/4 v3, 0x3

    return p1

    :cond_8
    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV23;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x6

    const/4 v3, 0x1

    return p1
.end method
