.class Lcom/hjq/permissions/PermissionDelegateImplV30;
.super Lcom/hjq/permissions/PermissionDelegateImplV29;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x1

    const/4 v0, 0x1

    invoke-direct {p0}, Lcom/hjq/permissions/PermissionDelegateImplV29;-><init>()V

    const/4 v1, 0x5

    const/4 v0, 0x1

    const/4 v1, 0x5

    return-void
.end method

.method private static getManageStoragePermissionIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x1e
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~bs@~a ~@@ui~ @@ S  Klil~~@~~d-~~@@ Mo f~co/m@@ o~ rs@ ~@b 1@on~ 4~@iv@~@fot ~~t@ /bo ~~~.y  @@~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x7

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x6

    const-string v1, "ALMmsEoAGNiMdOigI_SSPCAS_AtSAs_SnItFEPIE_.dRLrPLaEC_sne"

    const-string v1, "tasAC__ALs.SI_iPAALsMoEFMdIEgOtSdeNCiPEInSSn.rS_LEARGP_"

    const/4 v3, 0x1

    const-string v1, "NdEsot_iLAi_.nMIrAIENACtAdEgRFPMsSPnEPGISLSaC_AS.L_Oo_e"

    const-string v1, "android.settings.MANAGE_APP_ALL_FILES_ACCESS_PERMISSION"

    const/4 v3, 0x2

    const/4 v2, 0x2

    const/4 v3, 0x0

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v3, 0x3

    const/4 v2, 0x5

    const/4 v3, 0x6

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->getPackageNameUri(Landroid/content/Context;)Landroid/net/Uri;

    move-result-object v1

    const/4 v3, 0x0

    const/4 v2, 0x3

    const/4 v3, 0x1

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v3, 0x2

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v1

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x1

    if-nez v1, :cond_0

    const/4 v3, 0x3

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x5

    const-string v1, "FNnLabt.CSdIitEISIRSLonOA.LsG_mCr_SeidAAAgs_SMEE_EN"

    const-string v1, "_EnmASiPC_LIAdSLg.no_NIsO.CEsSed_rALFtaEMtSAEiSGIRN"

    const/4 v3, 0x4

    const-string v1, "LPO.EiuLSrdSdMA_AAAEE_NNaCSsIg_IenMLR_EiIsFttSGCo.S"

    const-string v1, "android.settings.MANAGE_ALL_FILES_ACCESS_PERMISSION"

    const/4 v3, 0x2

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    :cond_0
    const/4 v2, 0x6

    const/4 v3, 0x2

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v1

    const/4 v3, 0x0

    const/4 v2, 0x7

    if-nez v1, :cond_1

    const/4 v3, 0x2

    const/4 v2, 0x7

    const/4 v3, 0x2

    invoke-static {p0}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    :cond_1
    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x2

    return-object v0
.end method

.method private static isGrantedManageStoragePermission()Z
    .locals 3
    .annotation build Landroidx/annotation/w0;
        value = 0x1e
    .end annotation

    const/4 v2, 0x2

    invoke-static {}, Lcom/hjq/permissions/f;->a()Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x5

    return v0
.end method

.method private static isUseDeprecationExternalStorage()Z
    .locals 3
    .annotation build Landroidx/annotation/w0;
        value = 0x1d
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-static {}, Lcom/bumptech/glide/load/model/stream/g;->a()Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x1

    const/4 v2, 0x0

    return v0
.end method


# virtual methods
.method public getPermissionSettingIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x0

    const/4 v1, 0x5

    const/4 v2, 0x7

    const-string v0, "ATrdoENiORpminioE_SRTAnrMasEoN.dEG_.AXLesG"

    const/4 v2, 0x5

    const-string v0, "psSEEdipARGnNrNLO_d.EXRTsioeAAAiEGT_an.Mom"

    const-string v0, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v1, 0x6

    move v2, v1

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x5

    const/4 v1, 0x4

    const/4 v2, 0x2

    if-eqz v0, :cond_1

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid11()Z

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x1

    const/4 v2, 0x1

    if-nez p2, :cond_0

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x7

    const/4 v2, 0x3

    return-object p1

    :cond_0
    const/4 v2, 0x3

    const/4 v1, 0x6

    const/4 v2, 0x5

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV30;->getManageStoragePermissionIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x5

    const/4 v1, 0x2

    const/4 v2, 0x6

    return-object p1

    :cond_1
    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x4

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV26;->getPermissionSettingIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x3

    const/4 v1, 0x2

    const/4 v2, 0x3

    return-object p1
.end method

.method public isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z
    .locals 3
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x5

    const/4 v1, 0x6

    const-string v0, "pd_ioTiMqGdES.aNnRinseOoAEX_.rAERLEANsTAmG"

    const-string v0, "dnL.rbRssSNOoi_GMiEaAnemAiTXAdAGEE_TEo.pNR"

    const/4 v2, 0x7

    const-string v0, "NnsEGAAmEd.rReaoi.NSiX_LTpOsronGRATdE_iEsM"

    const-string v0, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v2, 0x2

    const/4 v1, 0x4

    const/4 v2, 0x4

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x4

    const/4 v1, 0x0

    const/4 v2, 0x3

    if-eqz v0, :cond_0

    const/4 v2, 0x7

    const/4 v1, 0x6

    const/4 v2, 0x1

    const/4 p1, 0x0

    const/4 v2, 0x5

    const/4 v1, 0x7

    const/4 v2, 0x4

    return p1

    :cond_0
    const/4 v2, 0x1

    const/4 v1, 0x7

    const/4 v2, 0x0

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV29;->isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v2, 0x3

    const/4 v1, 0x0

    const/4 v2, 0x3

    return p1
.end method

.method public isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 4
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x3

    move v3, v2

    const-string v0, "pr.m_NGndEEAnNMiiXadm_AGeLESORus.EorTiAToA"

    const-string v0, "Aa.eANuEEnrdMOips_.NRLiosAT_oEdAGESXTirmGn"

    const/4 v3, 0x5

    const-string v0, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x1

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v3, 0x3

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-eqz v0, :cond_4

    const/4 v3, 0x2

    const/4 v2, 0x0

    const/4 v3, 0x4

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result p2

    const/4 v3, 0x1

    const/4 v2, 0x3

    const/4 v0, 0x6

    const/4 v0, 0x1

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x7

    if-nez p2, :cond_0

    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x6

    return v0

    :cond_0
    const/4 v3, 0x5

    const/4 v2, 0x1

    const/4 v3, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid11()Z

    move-result p2

    const/4 v3, 0x6

    const/4 v2, 0x6

    const/4 v3, 0x0

    if-nez p2, :cond_3

    const/4 v3, 0x6

    const/4 v2, 0x1

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result p2

    const/4 v3, 0x2

    const/4 v2, 0x3

    const/4 v3, 0x2

    const/4 v1, 0x0

    const/4 v3, 0x1

    if-eqz p2, :cond_1

    const/4 v3, 0x5

    const/4 v2, 0x3

    const/4 v3, 0x6

    invoke-static {}, Lcom/hjq/permissions/PermissionDelegateImplV30;->isUseDeprecationExternalStorage()Z

    move-result p2

    const/4 v2, 0x5

    const/4 v2, 0x2

    const/4 v3, 0x7

    if-nez p2, :cond_1

    const/4 v2, 0x0

    move v3, v2

    return v1

    :cond_1
    const/4 v3, 0x4

    const/4 v2, 0x1

    const/4 v3, 0x3

    const-string p2, "dSONoRnTedsoaALR__AmrpEARTEGErpD..iisoni"

    const-string p2, "en_dsNTpiLmi._ErDRpasRRdASiAEOAEE.noGroT"

    const/4 v3, 0x4

    const-string p2, ".isAobEADo_rEdisEOadSX_GTLiNpREm.AnreRRT"

    const-string p2, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v3, 0x1

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p2

    const/4 v3, 0x4

    const/4 v2, 0x1

    if-eqz p2, :cond_2

    const/4 v2, 0x5

    move v3, v2

    const-string p2, "WS_GrLuE_ER.ipsETAT.oRemoIiqOXndsradTnEAN"

    const-string p2, "eEnSirROqda_RiTm_WGTroRETNoAIpXsEs..dnELA"

    const/4 v3, 0x0

    const-string p2, "AETeWsNpOdEnm_..TosSErinGRdXErTIipa_RALiR"

    const-string p2, "android.permission.WRITE_EXTERNAL_STORAGE"

    const/4 v3, 0x2

    const/4 v2, 0x2

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x4

    const/4 v2, 0x5

    const/4 v3, 0x7

    if-eqz p1, :cond_2

    const/4 v3, 0x6

    goto :goto_0

    :cond_2
    const/4 v3, 0x3

    move v0, v1

    move v0, v1

    const/4 v3, 0x7

    move v0, v1

    move v0, v1

    :goto_0
    const/4 v3, 0x7

    const/4 v2, 0x7

    const/4 v3, 0x5

    return v0

    :cond_3
    const/4 v3, 0x7

    const/4 v2, 0x1

    const/4 v3, 0x5

    invoke-static {}, Lcom/hjq/permissions/PermissionDelegateImplV30;->isGrantedManageStoragePermission()Z

    move-result p1

    const/4 v3, 0x0

    const/4 v2, 0x2

    const/4 v3, 0x5

    return p1

    :cond_4
    const/4 v2, 0x1

    const/4 v2, 0x3

    const/4 v3, 0x2

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV29;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v3, 0x1

    const/4 v2, 0x1

    const/4 v3, 0x4

    return p1
.end method
