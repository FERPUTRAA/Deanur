.class Lcom/hjq/permissions/PermissionDelegateImplV31;
.super Lcom/hjq/permissions/PermissionDelegateImplV30;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x0

    const/4 v0, 0x1

    const/4 v1, 0x1

    invoke-direct {p0}, Lcom/hjq/permissions/PermissionDelegateImplV30;-><init>()V

    const/4 v1, 0x4

    const/4 v0, 0x7

    const/4 v1, 0x5

    return-void
.end method

.method private static getAlarmPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;
    .locals 4
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x1f
    .end annotation

    const-string v3, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v2, "~@sr@ l b@f@@~a o~~~ o ~i ld~cs @@@~tM.@@@n@ @~o~~ @~u@o@v@ot@~ -i~~ 1i~y~Sb/   b@ o~ ~/4m@~K ~~"

    const-string v2, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v3, 0x3

    new-instance v0, Landroid/content/Intent;

    const/4 v3, 0x0

    const/4 v2, 0x4

    const/4 v3, 0x3

    const-string v1, ".SEmdeCLLQXAE_rasCRDi.StHdgsEiTR_EtnnsoMTAUU_"

    const-string v1, "REsnCXTtDgMtis.as_HASSEETdUoniEEULLRAdr__QeC."

    const/4 v3, 0x6

    const-string v1, "UrSto.UeAtsH_dCEEdLXgsTARnELSDTEaREQoMC_Ai_.i"

    const-string v1, "android.settings.REQUEST_SCHEDULE_EXACT_ALARM"

    const/4 v3, 0x4

    const/4 v2, 0x2

    const/4 v3, 0x6

    invoke-direct {v0, v1}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V

    const/4 v2, 0x4

    move v3, v2

    invoke-static {p0}, Lcom/hjq/permissions/PermissionUtils;->getPackageNameUri(Landroid/content/Context;)Landroid/net/Uri;

    move-result-object v1

    const/4 v3, 0x1

    const/4 v2, 0x2

    const/4 v3, 0x7

    invoke-virtual {v0, v1}, Landroid/content/Intent;->setData(Landroid/net/Uri;)Landroid/content/Intent;

    const/4 v3, 0x6

    const/4 v2, 0x0

    const/4 v3, 0x0

    invoke-static {p0, v0}, Lcom/hjq/permissions/PermissionUtils;->areActivityIntent(Landroid/content/Context;Landroid/content/Intent;)Z

    move-result v1

    const/4 v3, 0x7

    const/4 v2, 0x4

    const/4 v3, 0x2

    if-nez v1, :cond_0

    const/4 v3, 0x6

    const/4 v2, 0x4

    const/4 v3, 0x7

    invoke-static {p0}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object v0

    :cond_0
    const/4 v3, 0x6

    const/4 v2, 0x2

    const/4 v3, 0x2

    return-object v0
.end method

.method private static isGrantedAlarmPermission(Landroid/content/Context;)Z
    .locals 3
    .param p0    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x1f
    .end annotation

    const/4 v2, 0x1

    const/4 v1, 0x2

    const/4 v2, 0x7

    const-class v0, Landroid/app/AlarmManager;

    const-class v0, Landroid/app/AlarmManager;

    const/4 v2, 0x0

    const-class v0, Landroid/app/AlarmManager;

    const-class v0, Landroid/app/AlarmManager;

    const/4 v2, 0x5

    const/4 v1, 0x5

    const/4 v2, 0x0

    invoke-virtual {p0, v0}, Landroid/content/Context;->getSystemService(Ljava/lang/Class;)Ljava/lang/Object;

    move-result-object p0

    const/4 v2, 0x6

    const/4 v1, 0x1

    const/4 v2, 0x6

    check-cast p0, Landroid/app/AlarmManager;

    const/4 v2, 0x3

    const/4 v1, 0x1

    const/4 v2, 0x1

    invoke-static {p0}, Lcom/hjq/permissions/g;->a(Landroid/app/AlarmManager;)Z

    move-result p0

    const/4 v2, 0x4

    const/4 v1, 0x5

    const/4 v2, 0x0

    return p0
.end method


# virtual methods
.method public getPermissionSettingIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;
    .locals 3
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v2, 0x2

    const/4 v1, 0x1

    const/4 v2, 0x6

    const-string v0, "o_LmsnE.SXAsAirCoDMEa_mAiCeURdHTrpidLEn"

    const/4 v2, 0x4

    const-string v0, "_arCobLid.EAiodAAsHinDUrSC_nXTp.sMmeLEE"

    const-string v0, "android.permission.SCHEDULE_EXACT_ALARM"

    const/4 v2, 0x6

    const/4 v1, 0x3

    const/4 v2, 0x7

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v2, 0x3

    const/4 v1, 0x4

    const/4 v2, 0x1

    if-eqz v0, :cond_1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid12()Z

    move-result p2

    const/4 v2, 0x7

    const/4 v1, 0x5

    const/4 v2, 0x2

    if-nez p2, :cond_0

    const/4 v2, 0x0

    const/4 v1, 0x3

    const/4 v2, 0x6

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplBase;->getApplicationDetailsIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x7

    const/4 v1, 0x2

    const/4 v2, 0x1

    return-object p1

    :cond_0
    const/4 v2, 0x0

    const/4 v1, 0x7

    const/4 v2, 0x1

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV31;->getAlarmPermissionIntent(Landroid/content/Context;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x4

    const/4 v2, 0x6

    return-object p1

    :cond_1
    const/4 v2, 0x0

    const/4 v1, 0x5

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV30;->getPermissionSettingIntent(Landroid/content/Context;Ljava/lang/String;)Landroid/content/Intent;

    move-result-object p1

    const/4 v2, 0x4

    const/4 v1, 0x2

    const/4 v2, 0x5

    return-object p1
.end method

.method public isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z
    .locals 7
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    const-string v0, "apEdHiuArUi.eXCACLioToESdDnonM.Em__srAs"

    const-string v0, "UdLioD_A.iRTM.H_oEiEmsSrneAdsaoCpnAECXr"

    const/4 v6, 0x0

    const-string v0, "android.permission.SCHEDULE_EXACT_ALARM"

    const/4 v6, 0x4

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x6

    const/4 v6, 0x5

    const/4 v1, 0x0

    const/4 v5, 0x3

    and-int/2addr v6, v5

    if-eqz v0, :cond_0

    const/4 v6, 0x4

    return v1

    :cond_0
    const/4 v6, 0x4

    const/4 v5, 0x0

    const/4 v6, 0x5

    const-string v0, "ridONBUpsiemsHSo_CLAOT.rdToanin.E"

    const-string v0, "aLTNsbdrEHmsnnor_.ieidOo.SiAOUCBT"

    const-string v0, "SToiieUdqmaOL.CN_nHA.sopTrdrBisOE"

    const-string v0, "android.permission.BLUETOOTH_SCAN"

    const/4 v6, 0x7

    const/4 v5, 0x0

    const/4 v6, 0x1

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x4

    const/4 v6, 0x6

    const-string v2, "sosI.Cid_CdnruOTNiaEoeNO.AEL_InsFSmrApC"

    const-string v2, "ms.ITCuNOreSdEFN_iondCOiaI.nCELs_AoSpAr"

    const/4 v6, 0x7

    const-string v2, "LEamdCsspTI.drNAN_OiomoE.riOFiSeIA_CnSn"

    const-string v2, "android.permission.ACCESS_FINE_LOCATION"

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x6

    const/4 v3, 0x1

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x5

    if-eqz v0, :cond_5

    const/4 v6, 0x7

    const/4 v5, 0x1

    const/4 v6, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez v0, :cond_1

    const/4 v6, 0x1

    const/4 v5, 0x6

    const/4 v6, 0x5

    return v1

    :cond_1
    const/4 v6, 0x3

    const/4 v5, 0x1

    const/4 v6, 0x3

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid12()Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez v0, :cond_3

    const/4 v6, 0x6

    const/4 v5, 0x1

    invoke-static {p1, v2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p2

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez p2, :cond_2

    const/4 v5, 0x5

    or-int/2addr v6, v5

    invoke-static {p1, v2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v6, 0x4

    const/4 v5, 0x4

    const/4 v6, 0x5

    if-nez p1, :cond_2

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    move v1, v3

    move v1, v3

    const/4 v6, 0x7

    move v1, v3

    move v1, v3

    :cond_2
    const/4 v6, 0x6

    const/4 v5, 0x5

    const/4 v6, 0x4

    return v1

    :cond_3
    const/4 v6, 0x1

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x2

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez v0, :cond_4

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x1

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x7

    if-nez p1, :cond_4

    const/4 v6, 0x4

    const/4 v5, 0x2

    const/4 v6, 0x4

    move v1, v3

    move v1, v3

    const/4 v6, 0x2

    move v1, v3

    move v1, v3

    :cond_4
    const/4 v6, 0x3

    return v1

    :cond_5
    const/4 v6, 0x5

    const-string v0, ".einorTCipraOpdsTNBnUNO.sL_dEEoOCTim"

    const-string v0, "CBroUOnpOss.iTdinL_EEOeN.pmaoCTTirNd"

    const/4 v6, 0x3

    const-string v0, "android.permission.BLUETOOTH_CONNECT"

    const/4 v6, 0x1

    const/4 v5, 0x2

    const/4 v6, 0x7

    const-string v4, "ESiq_bA.iDmTOEULTsoBn.rEIaOpVdRsHTdone"

    const-string v4, "_nUSdiTmqBHaTOE.ieoEnAELIVrR.pTiDOsosd"

    const/4 v6, 0x2

    const-string v4, "IiHBsiuOTrdAO_U.DdeV.TEiESoTLnRpoEsmnr"

    const-string v4, "android.permission.BLUETOOTH_ADVERTISE"

    const/4 v6, 0x1

    const/4 v5, 0x6

    filled-new-array {v0, v4}, [Ljava/lang/String;

    move-result-object v0

    const/4 v6, 0x4

    const/4 v5, 0x4

    invoke-static {v0, p2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x0

    if-eqz v0, :cond_8

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x1

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid12()Z

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x6

    const/4 v6, 0x6

    if-nez v0, :cond_6

    const/4 v6, 0x5

    const/4 v5, 0x1

    const/4 v6, 0x5

    return v1

    :cond_6
    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x2

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x4

    const/4 v5, 0x7

    const/4 v6, 0x3

    if-nez v0, :cond_7

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x4

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x1

    const/4 v6, 0x6

    if-nez p1, :cond_7

    const/4 v6, 0x2

    const/4 v5, 0x6

    const/4 v6, 0x0

    move v1, v3

    move v1, v3

    move v1, v3

    :cond_7
    const/4 v6, 0x2

    return v1

    :cond_8
    const/4 v6, 0x6

    const-string v0, "ONOAri_pseTKr.ssAiDdG.onNCCUd_EoLRpnBIOaSCmAC"

    const-string v0, "pNsnoIS.SmCasNCDeBsRddrTG_An._CKrCAELiAOOoUOi"

    const/4 v6, 0x4

    const-string v0, "NOSnDC.oqsr_eIUiamddSConCGiis_AEORTNLrCB.OAAK"

    const-string v0, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v6, 0x7

    const/4 v5, 0x3

    const/4 v6, 0x0

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x1

    if-eqz v0, :cond_c

    const/4 v6, 0x5

    const/4 v5, 0x3

    const/4 v6, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x6

    const/4 v6, 0x1

    if-eqz v0, :cond_c

    const/4 v6, 0x0

    const/4 v5, 0x5

    const/4 v6, 0x1

    invoke-static {p1}, Lcom/hjq/permissions/AndroidVersion;->getTargetSdkVersionCode(Landroid/content/Context;)I

    move-result v0

    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x0

    const/16 v4, 0x1f

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x4

    if-lt v0, v4, :cond_c

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x6

    invoke-static {p1, v2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x7

    if-nez v0, :cond_a

    const/4 v6, 0x6

    const/4 v5, 0x1

    const/4 v6, 0x0

    const-string v0, "sIsCSdaAonAe_SOCii.pCRE_mni.STrCmdNoAELrO"

    const-string v0, "iE_mC.oNOdeaisICdOLEnC.rp_mSAsiTSoAnCRrAS"

    const-string v0, "SENmIdiCSi_.AnoCOemndrapC_.OAsRLrEoCTAOsi"

    const-string v0, "android.permission.ACCESS_COARSE_LOCATION"

    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x5

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v4

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x3

    if-nez v4, :cond_a

    const/4 v5, 0x7

    move v6, v5

    invoke-static {p1, v2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p2

    const/4 v6, 0x7

    const/4 v5, 0x4

    const/4 v6, 0x4

    if-nez p2, :cond_9

    const/4 v6, 0x5

    const/4 v5, 0x2

    const/4 v6, 0x0

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v6, 0x5

    const/4 v5, 0x1

    if-nez p1, :cond_9

    const/4 v5, 0x1

    const/4 v5, 0x4

    const/4 v6, 0x6

    move v1, v3

    move v1, v3

    const/4 v6, 0x3

    move v1, v3

    move v1, v3

    :cond_9
    const/4 v6, 0x0

    const/4 v5, 0x0

    const/4 v6, 0x7

    return v1

    :cond_a
    const/4 v6, 0x7

    const/4 v5, 0x7

    const/4 v6, 0x4

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v6, 0x5

    const/4 v5, 0x7

    const/4 v6, 0x6

    if-nez v0, :cond_b

    const/4 v6, 0x7

    const/4 v5, 0x6

    const/4 v6, 0x0

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v6, 0x1

    const/4 v5, 0x3

    const/4 v6, 0x6

    if-nez p1, :cond_b

    const/4 v6, 0x3

    const/4 v5, 0x5

    const/4 v6, 0x5

    move v1, v3

    move v1, v3

    const/4 v6, 0x5

    move v1, v3

    move v1, v3

    :cond_b
    const/4 v6, 0x4

    const/4 v5, 0x5

    const/4 v6, 0x7

    return v1

    :cond_c
    const/4 v6, 0x4

    const/4 v5, 0x6

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV30;->isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v6, 0x6

    const/4 v5, 0x0

    const/4 v6, 0x6

    return p1
.end method

.method public isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x6

    const-string v0, "ECoAod_LMnAL_S.iUimraRroHiCsEseX.DEpndA"

    const-string v0, "android.permission.SCHEDULE_EXACT_ALARM"

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x6

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v1, 0x5

    const/4 v1, 0x1

    const/4 v3, 0x5

    xor-int/2addr v4, v3

    if-eqz v0, :cond_1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid12()Z

    move-result p2

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-nez p2, :cond_0

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x3

    return v1

    :cond_0
    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x7

    invoke-static {p1}, Lcom/hjq/permissions/PermissionDelegateImplV31;->isGrantedAlarmPermission(Landroid/content/Context;)Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x0

    const/4 v4, 0x3

    return p1

    :cond_1
    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x2

    const-string v0, "nALHrbOiNBrOeoS_nUamso.diEsoCTpTi"

    const-string v0, "Omdpo.HTrdn_LBsiaoAeoTNiiECUsnSOr"

    const-string v0, "nLmBdOuTsserHCApTrEoniad..oNiSOU_"

    const-string v0, "android.permission.BLUETOOTH_SCAN"

    const/4 v4, 0x4

    const/4 v3, 0x4

    const/4 v4, 0x7

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x3

    const/4 v4, 0x4

    if-eqz v0, :cond_4

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x4

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x4

    const/4 v4, 0x2

    if-nez v0, :cond_2

    const/4 v4, 0x3

    const/4 v3, 0x0

    return v1

    :cond_2
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid12()Z

    move-result v0

    const/4 v4, 0x3

    const/4 v3, 0x7

    const/4 v4, 0x4

    if-nez v0, :cond_3

    const/4 v4, 0x2

    const-string p2, "LFs.Tnopi_iC_ipCeAANOICaSm.OoNSsIErErnd"

    const-string p2, "android.permission.ACCESS_FINE_LOCATION"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x2

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x4

    return p1

    :cond_3
    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x7

    const/4 v3, 0x7

    const/4 v4, 0x4

    return p1

    :cond_4
    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x0

    const-string v0, "OTEiHipOqoNsesOmLBCCaodT_r.nidUb.Trn"

    const-string v0, "rarsibEe.nCOEimiH.oNLoTUsdOpOTC_BndT"

    const/4 v4, 0x1

    const-string v0, "EdsdUoisOEiieNHanpmTnTsrCoOLTN._r.CB"

    const-string v0, "android.permission.BLUETOOTH_CONNECT"

    const/4 v4, 0x6

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v2, "eTimOEnHAnTRapUid_mu.rEBD.ToidrLSsOosV"

    const-string v2, "eni.OaunTrVBpTSE.UiDdATEriREooLdH_mOss"

    const/4 v4, 0x3

    const-string v2, "eT_aoTOosnrUmsD.iHiTBSLEnAVEIrd.pOdoER"

    const-string v2, "android.permission.BLUETOOTH_ADVERTISE"

    const/4 v3, 0x5

    move v4, v3

    filled-new-array {v0, v2}, [Ljava/lang/String;

    move-result-object v0

    const/4 v4, 0x6

    const/4 v3, 0x2

    const/4 v4, 0x5

    invoke-static {v0, p2}, Lcom/hjq/permissions/PermissionUtils;->containsPermission([Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x4

    if-eqz v0, :cond_6

    const/4 v4, 0x5

    const/4 v3, 0x3

    const/4 v4, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid12()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x6

    if-nez v0, :cond_5

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x3

    return v1

    :cond_5
    const/4 v4, 0x4

    const/4 v3, 0x2

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x2

    return p1

    :cond_6
    const/4 v4, 0x2

    const/4 v3, 0x0

    const/4 v4, 0x5

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV30;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v4, 0x0

    return p1
.end method
