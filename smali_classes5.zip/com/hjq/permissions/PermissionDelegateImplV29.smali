.class Lcom/hjq/permissions/PermissionDelegateImplV29;
.super Lcom/hjq/permissions/PermissionDelegateImplV28;


# direct methods
.method constructor <init>()V
    .locals 2

    const/4 v1, 0x5

    const/4 v0, 0x2

    const/4 v1, 0x3

    invoke-direct {p0}, Lcom/hjq/permissions/PermissionDelegateImplV28;-><init>()V

    const/4 v1, 0x2

    const/4 v0, 0x5

    const/4 v1, 0x5

    return-void
.end method

.method private isGrantedReadStoragePermission(Landroid/content/Context;)Z
    .locals 8
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .annotation build Landroidx/annotation/w0;
        value = 0x17
    .end annotation

    const-string v7, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const-string/jumbo v6, "y~s bdoo@S@ b~ la@itb@@  @~  t of/l~~m~4o~~@@ @@Mi@~~~@noK@ou@/~  r@@ ~  1f@~~i~@ -v ~@~s~.c @~~"

    const-string v6, "  ~@~@~@~@~@~@~@~@~@~@~   Smob - Mod obfuscation tool v1.4 by Kirlif\'   ~@~@~@~@~@~@~@~@~@~@~  "

    const/4 v7, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid13()Z

    move-result v0

    const/4 v7, 0x2

    const/4 v6, 0x7

    const/4 v7, 0x4

    const/4 v1, 0x0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x6

    const-string v2, "GNTmAordoOn.snrA_i_N.XTMReEEAREiLAsdpSEima"

    const-string v2, "android.permission.MANAGE_EXTERNAL_STORAGE"

    const/4 v7, 0x3

    const/4 v6, 0x7

    const/4 v7, 0x0

    const/4 v3, 0x1

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x1

    if-eqz v0, :cond_2

    const/4 v7, 0x4

    const/4 v6, 0x0

    const/4 v7, 0x0

    invoke-static {p1}, Lcom/hjq/permissions/AndroidVersion;->getTargetSdkVersionCode(Landroid/content/Context;)I

    move-result v0

    const/4 v7, 0x4

    const/4 v6, 0x5

    const/4 v7, 0x0

    const/16 v4, 0x21

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-lt v0, v4, :cond_2

    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x7

    const-string v0, "dnAMorrEoEDeG.IadSmiRpoIn.EAs_isM_AD"

    const-string v0, "iIs_GsSrpD.IddromAE_i.RonnaMesAEADME"

    const/4 v7, 0x0

    const-string v0, "android.permission.READ_MEDIA_IMAGES"

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x0

    if-nez v0, :cond_0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x0

    invoke-virtual {p0, p1, v2}, Lcom/hjq/permissions/PermissionDelegateImplV29;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v7, 0x6

    const/4 v6, 0x7

    const/4 v7, 0x1

    if-eqz p1, :cond_1

    :cond_0
    const/4 v7, 0x6

    const/4 v6, 0x4

    const/4 v7, 0x2

    move v1, v3

    move v1, v3

    const/4 v7, 0x2

    move v1, v3

    move v1, v3

    :cond_1
    const/4 v7, 0x6

    return v1

    :cond_2
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x6

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid11()Z

    move-result v0

    const/4 v7, 0x5

    const/4 v6, 0x3

    const/4 v7, 0x1

    const-string v4, "SniOdb_rRRTmNrREsanAedopTmiAE.ED.GX_isEA"

    const-string v4, "DR.mRTXGnndiod_ESOEri_rRsaENAiLsEAAp.emT"

    const/4 v7, 0x6

    const-string v4, "AirSnRu.Ae_ApELdEmTDoRiXRsONno.iGEErTa_d"

    const-string v4, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v7, 0x1

    const/4 v6, 0x2

    const/4 v7, 0x3

    if-eqz v0, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x2

    const/4 v7, 0x7

    invoke-static {p1}, Lcom/hjq/permissions/AndroidVersion;->getTargetSdkVersionCode(Landroid/content/Context;)I

    move-result v0

    const/4 v7, 0x7

    const/4 v6, 0x4

    const/4 v7, 0x6

    const/16 v5, 0x1e

    const/4 v6, 0x2

    const/4 v6, 0x4

    const/4 v7, 0x4

    if-lt v0, v5, :cond_5

    const/4 v7, 0x0

    const/4 v6, 0x0

    const/4 v7, 0x6

    invoke-static {p1, v4}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v7, 0x6

    const/4 v6, 0x6

    const/4 v7, 0x3

    if-nez v0, :cond_3

    const/4 v7, 0x3

    const/4 v6, 0x5

    const/4 v7, 0x5

    invoke-virtual {p0, p1, v2}, Lcom/hjq/permissions/PermissionDelegateImplV29;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v7, 0x3

    const/4 v6, 0x3

    const/4 v7, 0x1

    if-eqz p1, :cond_4

    :cond_3
    const/4 v7, 0x2

    const/4 v6, 0x1

    const/4 v7, 0x0

    move v1, v3

    move v1, v3

    const/4 v7, 0x3

    move v1, v3

    move v1, v3

    :cond_4
    const/4 v7, 0x5

    const/4 v6, 0x1

    const/4 v7, 0x7

    return v1

    :cond_5
    const/4 v7, 0x7

    const/4 v6, 0x1

    const/4 v7, 0x3

    invoke-static {p1, v4}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v7, 0x2

    const/4 v6, 0x3

    const/4 v7, 0x2

    return p1
.end method


# virtual methods
.method public isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z
    .locals 6
    .param p1    # Landroid/app/Activity;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v5, 0x0

    const/4 v4, 0x2

    const/4 v5, 0x1

    const-string v0, "nLdidCBpUSpi._AeoiOnCC.NKNROrGoAsomSACODsa_TI"

    const-string v0, "IiodoOiSsDdBiAK__SGRrsNACmOaAEnLCeCNnTO.C.Uop"

    const/4 v5, 0x2

    const-string v0, "CUsLi.TdqOoE_iBGmp_NdDSRAornaNCSsO.rICnCAAiOe"

    const-string v0, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v5, 0x7

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x5

    const/4 v5, 0x5

    const/4 v1, 0x1

    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x6

    const/4 v2, 0x0

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-eqz v0, :cond_5

    const/4 v5, 0x1

    const/4 v4, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    if-nez v0, :cond_0

    const/4 v5, 0x0

    const/4 v4, 0x4

    return v2

    :cond_0
    const/4 v5, 0x2

    const/4 v4, 0x1

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x6

    const/4 v5, 0x3

    const-string v3, "iis_OrArnTnCIseaFbI.NSddm.OoSLsA_pENoiC"

    const-string v3, "IrreOb_osC.Tsndo_.OSanFCpEAiNEiidANSImL"

    const/4 v5, 0x1

    const-string v3, "_iImdACi.osesmAiCNOTCSnEdFoarnErp.SO_LI"

    const-string v3, "android.permission.ACCESS_FINE_LOCATION"

    const/4 v5, 0x1

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez v0, :cond_2

    const/4 v5, 0x3

    const/4 v4, 0x0

    const/4 v5, 0x7

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p2

    const/4 v5, 0x5

    const/4 v4, 0x6

    const/4 v5, 0x4

    if-nez p2, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x7

    if-nez p1, :cond_1

    const/4 v5, 0x4

    const/4 v4, 0x0

    goto :goto_0

    :cond_1
    const/4 v4, 0x7

    move v5, v4

    move v1, v2

    move v1, v2

    const/4 v5, 0x2

    move v1, v2

    :goto_0
    const/4 v5, 0x5

    const/4 v4, 0x2

    const/4 v5, 0x5

    return v1

    :cond_2
    const/4 v5, 0x2

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x6

    if-nez v0, :cond_3

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x0

    invoke-static {p1, v3}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x3

    const/4 v4, 0x3

    xor-int/2addr p1, v1

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x3

    return p1

    :cond_3
    const/4 v5, 0x0

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x4

    const/4 v5, 0x1

    if-nez v0, :cond_4

    const/4 v5, 0x2

    const/4 v4, 0x6

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x4

    if-nez p1, :cond_4

    const/4 v4, 0x3

    const/4 v4, 0x7

    const/4 v5, 0x7

    goto :goto_1

    :cond_4
    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x4

    move v1, v2

    move v1, v2

    const/4 v5, 0x0

    move v1, v2

    :goto_1
    const/4 v4, 0x6

    move v5, v4

    return v1

    :cond_5
    const/4 v5, 0x7

    const/4 v4, 0x2

    const/4 v5, 0x3

    const-string v0, "ECnroSNdpMiO.nCmriCOeAAIdsSoiEoDL_uIsAa_"

    const-string v0, "sACLSiunAAToma.IinpISEOroed_dMECNrD_CsOi"

    const/4 v5, 0x1

    const-string v0, "TrS.ibDniASodCECieNmOOdsnpA.aoEMACLr__sI"

    const-string v0, "android.permission.ACCESS_MEDIA_LOCATION"

    const/4 v4, 0x7

    const/4 v4, 0x3

    const/4 v5, 0x1

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x5

    const/4 v4, 0x3

    const/4 v5, 0x2

    if-eqz v0, :cond_a

    const/4 v5, 0x7

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x2

    if-nez v0, :cond_6

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x6

    return v2

    :cond_6
    const/4 v5, 0x3

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x4

    const/4 v5, 0x3

    if-nez v0, :cond_8

    const/4 v5, 0x1

    const/4 v4, 0x4

    const/4 v5, 0x1

    const-string p2, "dEiaRiun.ETEpAdosENTOR.pRnosir_DGA_AXSem"

    const-string p2, "EEs.RnopdXAGLiSmiDROiEErTaTd.nANAeRps_o_"

    const/4 v5, 0x5

    const-string p2, "SEXGNiopdEosTei.dApTrirRaR_mERnA_sA.EDnO"

    const-string p2, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v5, 0x6

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x5

    if-nez v0, :cond_7

    const/4 v5, 0x3

    const/4 v4, 0x3

    const/4 v5, 0x5

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez p1, :cond_7

    const/4 v5, 0x2

    const/4 v4, 0x1

    const/4 v5, 0x3

    goto :goto_2

    :cond_7
    const/4 v5, 0x5

    const/4 v4, 0x4

    const/4 v5, 0x4

    move v1, v2

    move v1, v2

    :goto_2
    const/4 v4, 0x3

    const/4 v4, 0x1

    const/4 v5, 0x2

    return v1

    :cond_8
    const/4 v5, 0x3

    const/4 v4, 0x6

    const/4 v5, 0x0

    invoke-direct {p0, p1}, Lcom/hjq/permissions/PermissionDelegateImplV29;->isGrantedReadStoragePermission(Landroid/content/Context;)Z

    move-result v0

    const/4 v5, 0x6

    const/4 v4, 0x1

    const/4 v5, 0x5

    if-eqz v0, :cond_9

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x1

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x7

    const/4 v4, 0x0

    const/4 v5, 0x6

    if-nez v0, :cond_9

    const/4 v5, 0x4

    const/4 v4, 0x0

    const/4 v5, 0x0

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x1

    const/4 v5, 0x2

    if-nez p1, :cond_9

    const/4 v4, 0x7

    or-int/2addr v5, v4

    goto :goto_3

    :cond_9
    const/4 v5, 0x6

    const/4 v4, 0x4

    const/4 v5, 0x0

    move v1, v2

    move v1, v2

    const/4 v5, 0x3

    move v1, v2

    move v1, v2

    :goto_3
    const/4 v4, 0x2

    move v5, v4

    return v1

    :cond_a
    const/4 v5, 0x1

    const/4 v4, 0x2

    const/4 v5, 0x2

    const-string v0, "NCdrrsVRqnGp.aNeTIEiqiC._OIoOIsTYomAdnI"

    const-string v0, ".nspnaiIqYroTeCdrIIi.dEoTGOTRNm_NCAsOIV"

    const/4 v5, 0x5

    const-string v0, "RVs_CoANsaYGTII.reOrTIidnnoTdiNIOmsEip."

    const-string v0, "android.permission.ACTIVITY_RECOGNITION"

    const/4 v5, 0x4

    const/4 v4, 0x7

    const/4 v5, 0x2

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x0

    const/4 v4, 0x5

    const/4 v5, 0x5

    if-eqz v0, :cond_d

    const/4 v5, 0x2

    const/4 v4, 0x7

    const/4 v5, 0x7

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x2

    if-nez v0, :cond_b

    const/4 v5, 0x7

    const/4 v4, 0x1

    const/4 v5, 0x4

    return v2

    :cond_b
    const/4 v5, 0x4

    const/4 v4, 0x2

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result v0

    const/4 v5, 0x1

    const/4 v4, 0x1

    const/4 v5, 0x0

    if-nez v0, :cond_c

    const/4 v5, 0x3

    const/4 v4, 0x4

    const/4 v5, 0x5

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->shouldShowRequestPermissionRationale(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x1

    const/4 v4, 0x0

    const/4 v5, 0x1

    if-nez p1, :cond_c

    const/4 v4, 0x0

    move v5, v4

    goto :goto_4

    :cond_c
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x5

    move v1, v2

    move v1, v2

    const/4 v5, 0x6

    move v1, v2

    move v1, v2

    :goto_4
    const/4 v4, 0x5

    const/4 v5, 0x1

    return v1

    :cond_d
    const/4 v5, 0x3

    const/4 v4, 0x5

    const/4 v5, 0x4

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV28;->isDoNotAskAgainPermission(Landroid/app/Activity;Ljava/lang/String;)Z

    move-result p1

    const/4 v5, 0x4

    const/4 v4, 0x5

    const/4 v5, 0x2

    return p1
.end method

.method public isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z
    .locals 5
    .param p1    # Landroid/content/Context;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param
    .param p2    # Ljava/lang/String;
        .annotation build Landroidx/annotation/o0;
        .end annotation
    .end param

    const/4 v4, 0x4

    const/4 v3, 0x5

    const/4 v4, 0x3

    const-string v0, "CODmSsoCLsdEA.pOiinnNds_CEAamTAIreo_Ir.i"

    const-string v0, "_CsAOiErAerANEmap.SLsD_nin.IOddCIiCoTsSo"

    const/4 v4, 0x2

    const-string v0, "CeOnoNdpSoSMimIsD_oArT.OEdLCasi_riAnIC.E"

    const-string v0, "android.permission.ACCESS_MEDIA_LOCATION"

    const/4 v4, 0x1

    const/4 v3, 0x3

    const/4 v4, 0x3

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v1

    const/4 v4, 0x1

    const/4 v3, 0x1

    const/4 v4, 0x5

    const/4 v2, 0x1

    const/4 v4, 0x7

    const/4 v3, 0x5

    const/4 v4, 0x6

    if-eqz v1, :cond_3

    const/4 v4, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result p2

    const/4 v4, 0x4

    const/4 v3, 0x0

    const/4 v4, 0x7

    if-nez p2, :cond_0

    const/4 v4, 0x6

    const/4 v3, 0x1

    const/4 v4, 0x6

    return v2

    :cond_0
    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x1

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result p2

    const/4 v4, 0x2

    const/4 v3, 0x2

    const/4 v4, 0x1

    if-nez p2, :cond_1

    const/4 v4, 0x0

    const/4 v3, 0x5

    const/4 v4, 0x6

    const-string p2, "O_dnRbemmSAoa_RsdEpELRA.XNi.orTDsEinAiTr"

    const-string p2, "_e.mRT.EEGRRoAdEo_ndTSmDpssALrnNriiOiXAa"

    const/4 v4, 0x5

    const-string p2, "EAa.dEuETsOADiLo.rSrp_nEiiGoRXsNmTne_ARR"

    const-string p2, "android.permission.READ_EXTERNAL_STORAGE"

    const/4 v4, 0x3

    const/4 v3, 0x1

    const/4 v4, 0x5

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x2

    const/4 v3, 0x1

    const/4 v4, 0x0

    return p1

    :cond_1
    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x0

    invoke-direct {p0, p1}, Lcom/hjq/permissions/PermissionDelegateImplV29;->isGrantedReadStoragePermission(Landroid/content/Context;)Z

    move-result p2

    const/4 v4, 0x3

    const/4 v3, 0x1

    if-eqz p2, :cond_2

    const/4 v4, 0x0

    const/4 v3, 0x6

    const/4 v4, 0x2

    invoke-static {p1, v0}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x3

    const/4 v4, 0x3

    if-eqz p1, :cond_2

    const/4 v4, 0x1

    const/4 v3, 0x4

    const/4 v4, 0x1

    goto :goto_0

    :cond_2
    const/4 v4, 0x1

    const/4 v3, 0x6

    const/4 v2, 0x3

    const/4 v2, 0x0

    :goto_0
    const/4 v4, 0x3

    const/4 v3, 0x4

    const/4 v4, 0x4

    return v2

    :cond_3
    const/4 v4, 0x3

    const/4 v3, 0x2

    const/4 v4, 0x4

    const-string v0, "ir.ASUBp.sEdnmGCdTNr_KoCp_NDOiLOCAOinoRsCAeaS"

    const-string v0, "android.permission.ACCESS_BACKGROUND_LOCATION"

    const/4 v3, 0x0

    move v4, v3

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x4

    const/4 v4, 0x7

    if-eqz v0, :cond_6

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x5

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid6()Z

    move-result v0

    const/4 v4, 0x5

    const/4 v3, 0x1

    const/4 v4, 0x2

    if-nez v0, :cond_4

    const/4 v4, 0x3

    const/4 v3, 0x3

    const/4 v4, 0x5

    return v2

    :cond_4
    const/4 v4, 0x2

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result v0

    const/4 v4, 0x1

    const/4 v3, 0x7

    const/4 v4, 0x0

    if-nez v0, :cond_5

    const/4 v4, 0x7

    const/4 v3, 0x1

    const/4 v4, 0x1

    const-string p2, "diA_IdNoqra.sF_CiSETpCOIiS.NCosnoeOrLnm"

    const-string p2, "sdCiomsI.FSrEiAoaL.CeOpr_nASoCIiTOdNn_N"

    const/4 v4, 0x5

    const-string p2, "nAssirOSIoCLOn_CNdomesEINTE.Spii.rdA_aF"

    const-string p2, "android.permission.ACCESS_FINE_LOCATION"

    const/4 v4, 0x7

    const/4 v3, 0x4

    const/4 v4, 0x3

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x6

    const/4 v3, 0x7

    const/4 v4, 0x3

    return p1

    :cond_5
    const/4 v4, 0x2

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x1

    const/4 v3, 0x5

    const/4 v4, 0x0

    return p1

    :cond_6
    const/4 v4, 0x2

    const/4 v3, 0x0

    const-string v0, "NbAmIYsoITGrIo.OsTpENeRid_dTmniCai.CIrO"

    const-string v0, ".COTnbIdsIraOnE_GiCTYTrdNIoRiIomNpAi.se"

    const/4 v4, 0x2

    const-string v0, "rTrYoTRE.npaeNN_inCOodoiAIImC.sTdsIOVIG"

    const-string v0, "android.permission.ACTIVITY_RECOGNITION"

    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x1

    invoke-static {p2, v0}, Lcom/hjq/permissions/PermissionUtils;->equalsPermission(Ljava/lang/String;Ljava/lang/String;)Z

    move-result v0

    const/4 v4, 0x2

    const/4 v3, 0x3

    const/4 v4, 0x2

    if-eqz v0, :cond_8

    const/4 v4, 0x7

    const/4 v3, 0x2

    const/4 v4, 0x0

    invoke-static {}, Lcom/hjq/permissions/AndroidVersion;->isAndroid10()Z

    move-result v0

    const/4 v4, 0x7

    const/4 v3, 0x3

    const/4 v4, 0x7

    if-nez v0, :cond_7

    const/4 v4, 0x4

    const/4 v3, 0x1

    const/4 v4, 0x2

    return v2

    :cond_7
    const/4 v4, 0x4

    const/4 v3, 0x2

    const/4 v4, 0x4

    invoke-static {p1, p2}, Lcom/hjq/permissions/PermissionUtils;->checkSelfPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x5

    const/4 v3, 0x6

    const/4 v4, 0x6

    return p1

    :cond_8
    const/4 v4, 0x4

    const/4 v3, 0x6

    const/4 v4, 0x6

    invoke-super {p0, p1, p2}, Lcom/hjq/permissions/PermissionDelegateImplV28;->isGrantedPermission(Landroid/content/Context;Ljava/lang/String;)Z

    move-result p1

    const/4 v4, 0x3

    const/4 v3, 0x5

    const/4 v4, 0x2

    return p1
.end method
